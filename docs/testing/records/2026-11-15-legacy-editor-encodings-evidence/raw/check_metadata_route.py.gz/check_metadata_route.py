"""Read official metadata through the host HTTP route, preserving raw public replies."""
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import urllib.request

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('batch_dependency_check', ROOT / 'scripts/check_dependencies.py')
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
raw = OUT / 'registry-metadata-r3'
raw.mkdir(exist_ok=False)


def fetch(url, timeout):
    if not url.startswith(module.API_ROOT) or not module.NAME.fullmatch(url[len(module.API_ROOT):]):
        raise module.CheckFailure('non_official_url_rejected')
    try:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler(), module.NoRedirect())
        request = urllib.request.Request(url, method='GET', headers={'Accept': 'application/json', 'User-Agent': 'KeelShell-dependency-check/1'})
        with opener.open(request, timeout=timeout) as response:
            if response.status != 200 or response.geturl() != url:
                raise module.CheckFailure('registry_http_failure')
            body = response.read(module.MAX_BYTES + 1)
        if len(body) > module.MAX_BYTES:
            raise module.CheckFailure('registry_response_too_large')
        content = json.loads(body)
        if not isinstance(content, dict):
            raise module.CheckFailure('registry_response_invalid')
        name = url[len(module.API_ROOT):]
        (raw / (name + '.json.gz')).write_bytes(gzip.compress(body, mtime=0))
        return content
    except module.CheckFailure:
        raise
    except Exception:
        raise module.CheckFailure('registry_request_failed') from None


report = module.run_check(ROOT, fetch=fetch, timeout=6, jobs=8)
report['metadata_route'] = 'host HTTP proxy routing; GET official crates.io only, no redirects or explicit authentication handlers'
report['raw_public_responses'] = {p.name: hashlib.sha256(gzip.decompress(p.read_bytes())).hexdigest() for p in sorted(raw.glob('*.gz'))}
(OUT / 'dependency-report-r3.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'requirements': len(report['rust']), 'raw_responses': len(report['raw_public_responses']), 'errors': report['errors']}))
raise SystemExit(0 if report['status'] == 'passed' else 1)
