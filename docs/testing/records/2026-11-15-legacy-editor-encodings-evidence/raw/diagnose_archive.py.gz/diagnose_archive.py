"""Bounded fixture reproduction with helper-only exception location capture."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent / "archive-diagnostic-r1"
OUT.mkdir()
log = (OUT.parent / "archive-suite-repro-r1.log").read_text()
relative = re.search(r"Running tests/server_archive.rs \(([^)]+)\)", log)[1]
binary = ROOT / relative
wrapper = OUT / "bin"
wrapper.mkdir()
traces = OUT / "traces"
traces.mkdir()
shim = wrapper / "python3"
shim.write_text(
    "#!" + sys.executable + "\n"
    + """import json, os, sys
from pathlib import Path
target = Path(os.environ['KEELSHELL_DIAGNOSTIC_TRACE']) / (str(os.getpid()) + '.jsonl')
def trace(frame, event, arg):
    if event == 'exception' and frame.f_code.co_filename == '<string>':
        kind, error, _ = arg
        if kind.__name__ == 'Rejected':
            record = {'function':frame.f_code.co_name, 'line':frame.f_lineno}
            # Record only numeric stat fields, never command, paths or contents.
            if frame.f_code.co_name == 'anchored_parent':
                for key in ('before', 'current', 'named'):
                    value = frame.f_locals.get(key)
                    if isinstance(value, dict) and all(type(v) is int for v in value.values()):
                        record[key] = value
            with target.open('a') as output:
                output.write(json.dumps(record) + '\\n')
    return trace
if len(sys.argv) < 3 or sys.argv[1] != '-c':
    raise SystemExit('unexpected diagnostic invocation')
code = sys.argv[2]
sys.argv = ['-c', *sys.argv[3:]]
sys.settrace(trace)
exec(compile(code, '<string>', 'exec'), {'__name__':'__main__'})
"""
)
shim.chmod(0o700)
results = []
with tempfile.TemporaryDirectory(prefix="keelshell-check-") as scratch:
    env = dict(os.environ, TMPDIR=str(Path(scratch).resolve()),
               PATH=str(wrapper) + os.pathsep + os.environ["PATH"],
               KEELSHELL_DIAGNOSTIC_TRACE=str(traces),
               PYTHONDONTWRITEBYTECODE="1")
    for index in range(20):
        result = subprocess.run(
            [str(binary), "--test-threads=4"], env=env, cwd=ROOT,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=20,
        )
        output = OUT / f"run-{index:02}.log"
        output.write_bytes(result.stdout)
        results.append({"run":index, "exit":result.returncode,
                        "log_sha256":hashlib.sha256(result.stdout).hexdigest()})
        if result.returncode:
            break
(OUT / "result.json").write_text(json.dumps({
    "binary":str(binary.relative_to(ROOT)),
    "binary_sha256":hashlib.sha256(binary.read_bytes()).hexdigest(),
    "diagnostic_only":True, "runs":results, "temporary_directory_removed":True,
}, indent=2) + "\n")
print(json.dumps({"runs":len(results), "failed":sum(x["exit"] != 0 for x in results),
                  "trace_files":len(list(traces.glob("*.jsonl")))}))
