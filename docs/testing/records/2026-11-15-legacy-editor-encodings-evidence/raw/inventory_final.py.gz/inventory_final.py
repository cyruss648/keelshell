"""Read the final Cargo executable inventory without creating redundant copies."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
freeze = json.loads((OUT / "frozen-inputs-r4.json").read_text())
assert all(hashlib.sha256((ROOT / p).read_bytes()).hexdigest() == s
           for p, s in freeze["files"].items())
old = json.loads((OUT / "final-review-inputs-r1.json").read_text())
record = {key: value for key, value in old.items() if key != "artifacts"}
record.update(freeze_file="frozen-inputs-r4.json", freeze_sha256=freeze["sha256"],
              frozen_engineering_count=freeze["count"], artifacts={})
wanted = {"keelshell_core": "core", "keelshell_session": "session",
          "keelshell-app": "app", "openssh_interop": "openssh"}
for line in (OUT / "final-test-build-r2.log").read_text().splitlines():
    try:
        row = json.loads(line)
    except ValueError:
        continue
    name = row.get("target", {}).get("name")
    if (row.get("reason") != "compiler-artifact" or name not in wanted
            or not row.get("profile", {}).get("test") or not row.get("executable")):
        continue
    label = wanted[name]
    binary = Path(row["executable"])
    before = hashlib.sha256(binary.read_bytes()).hexdigest()
    listed = subprocess.run([str(binary), "--list"], cwd=ROOT, capture_output=True,
                            timeout=30, check=True)
    assert not listed.stderr
    assert hashlib.sha256(binary.read_bytes()).hexdigest() == before
    path = OUT / f"{label}-final-inventory-r2.txt"
    assert not path.exists()
    path.write_bytes(listed.stdout)
    names = [line.removesuffix(": test") for line in listed.stdout.decode().splitlines()
             if line.endswith(": test")]
    assert set(old["expected_new_names"][label]).issubset(names)
    record["artifacts"][label] = {
        "source": str(binary.relative_to(ROOT)), "sha256": before,
        "inventory_file": path.name,
        "inventory_sha256": hashlib.sha256(listed.stdout).hexdigest(),
        "inventory_count": len(names), "fresh_in_this_no_run": row["fresh"],
    }
assert set(record["artifacts"]) == set(wanted.values())
record["r3_to_r4_changed_files"] = [
    "crates/keelshell-core/src/server_archive.py",
    "crates/keelshell-core/tests/server_archive.rs",
]
record["review_scope_note"] = (
    "Original codec/app source reviews bind unchanged r3 scope files. "
    "The r4 two-file archive delta has its own independent report. "
    "This parent-built final inventory and full gate do not represent independent rebuilding."
)
path = OUT / "final-review-inputs-r2.json"
assert not path.exists()
path.write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({key: value["inventory_count"]
                  for key, value in record["artifacts"].items()}))
