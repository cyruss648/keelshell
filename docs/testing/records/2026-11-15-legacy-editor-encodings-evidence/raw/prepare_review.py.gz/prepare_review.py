"""Bind test inventories and stable parent-built copies to the complete input freeze."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
freeze = json.loads((OUT / 'frozen-inputs-r3.json').read_text())
assert all(hashlib.sha256((ROOT / p).read_bytes()).hexdigest() == s for p, s in freeze['files'].items())
artifacts = {}
wanted = {'keelshell_core': 'core', 'keelshell_session': 'session', 'keelshell-app': 'app', 'openssh_interop': 'openssh'}
for line in (OUT / 'final-test-build-r1.log').read_text().splitlines():
    try:
        row = json.loads(line)
    except ValueError:
        continue
    target = row.get('target', {})
    name = target.get('name')
    if row.get('reason') != 'compiler-artifact' or name not in wanted or not row.get('profile', {}).get('test') or not row.get('executable'):
        continue
    source = Path(row['executable'])
    dest = OUT / 'final-review-binaries' / source.name
    dest.parent.mkdir(exist_ok=True)
    shutil.copyfile(source, dest)
    dest.chmod(0o700)
    output = subprocess.run([str(dest), '--list'], cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=30, check=True).stdout
    label = wanted[name]
    (OUT / f'{label}-final-inventory.txt').write_bytes(output)
    names = [l.removesuffix(': test') for l in output.decode().splitlines() if l.endswith(': test')]
    artifacts[label] = {'source': str(source.relative_to(ROOT)), 'copy': str(dest.relative_to(ROOT)), 'sha256': hashlib.sha256(dest.read_bytes()).hexdigest(), 'inventory_file': f'{label}-final-inventory.txt', 'inventory_sha256': hashlib.sha256(output).hexdigest(), 'inventory_count': len(names)}
assert set(artifacts) == {'core', 'session', 'app', 'openssh'}, set(artifacts)
new_sources = {'core': ('crates/keelshell-core/src/text_document/legacy_tests.rs','text_document::legacy_tests::'), 'session': ('crates/keelshell-session/src/sftp/editor_encoding_tests.rs','sftp::editor_encoding_tests::'), 'app': ('crates/keelshell-app/src/files/editor_encoding_tests.rs','files::transfer_tests::editor_encoding_tests::'), 'openssh': ('crates/keelshell-session/tests/support/openssh_editor_encoding.rs','editor_encoding::')}
expected = {}
for label, (path, prefix) in new_sources.items():
    text = (ROOT / path).read_text()
    names = re.findall(r'#\[(?:gpui_kit::|tokio::)?test\](?:\n#\[[^\n]*\])*\n(?:async )?fn ([A-Za-z0-9_]+)', text)
    expected[label] = [prefix + n for n in names]
    inventory = (OUT / artifacts[label]['inventory_file']).read_text()
    assert names and all(n + ': test' in inventory for n in expected[label]), label
record = {'base_sha': '2cfe0deb732db78f43a9b76d9e2c7e5c214a1f24','freeze_file':'frozen-inputs-r3.json','freeze_sha256':freeze['sha256'],'frozen_engineering_count':freeze['count'],'artifacts':artifacts,'expected_new_names':expected,'default_new_tests':sum(len(v) for k,v in expected.items() if k!='openssh'),'new_opt_in_tests':len(expected['openssh']),'independent_recompilation':False}
(OUT / 'final-review-inputs-r1.json').write_text(json.dumps(record,indent=2)+'\n')
old = json.loads((OUT / 'codec-transport-review-inputs-r1.json').read_text())
codec = {'base_sha':record['base_sha'],'scope_files':{p:freeze['files'][p] for p in old['scope_files']},'verified_parent_binaries':{k:artifacts[k] for k in ('core','session')},'freeze_file':'frozen-inputs-r3.json','freeze_sha256':freeze['sha256'],'independent_recompilation':False}
(OUT / 'codec-transport-review-inputs-r2.json').write_text(json.dumps(codec,indent=2)+'\n')
print(json.dumps({'freeze':freeze['sha256'],'artifacts':{k:v['inventory_count'] for k,v in artifacts.items()},'default_new':record['default_new_tests'],'opt_in_new':record['new_opt_in_tests']}))
