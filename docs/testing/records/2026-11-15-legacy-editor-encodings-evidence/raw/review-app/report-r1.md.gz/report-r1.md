**KeelShell 显式远程文本旧编码：app 集成、UI 与真实 OpenSSH 合同独立只读复核 r1**

签署时间：2026-11-16T00:19:27+08:00（Asia/Shanghai）。审查者为本批新的非作者。
结论：`APPROVE_SCOPED_SOURCE_AND_FUNCTION / FULL_GATE_PENDING / NATIVE_NOT_RUN`。

指定 app 差分、配套测试及 OpenSSH 测试合同未发现需要修订的问题，开放 **P0=0、P1=0、P2=0、P3=0**。
独立执行当前冻结的新 app 预构建副本：新增专项 **14/14**，相关回归 **54/54**，去重 **68/68**；
另独立核对父执行的真实 disposable localhost OpenSSH 原件 **17/17**，其中新增旧编码测试 **1** 项。
本审未独立重编译，也未独立重跑真实 OpenSSH。

合并建议：本范围源码与所测功能可以接受；待父取得并核对**同一 r3 冻结、完整路径集合无漂移的最终全仓门禁成功终态**后，建议合并本批。
本报告签署时全仓门禁仍为 `PENDING`。仅补充该同冻结门禁终态无需重开一轮源码审查；若工程输入变化，本签署不覆盖新输入。
macOS、Windows、Linux 的本批 native 桌面仍 `NOT_RUN`，完整产品、FILE-05/M4、IME/辅助技术和原生键盘验收不随上述合并建议完成。

**审查基准与只读边界**

- 主树：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`。
- 基线及现场 HEAD：`2cfe0deb732db78f43a9b76d9e2c7e5c214a1f24`；候选是此基线上的未提交工作树差分，包括新增未跟踪文件。
- 冻结：[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/frozen-inputs-r3.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/frozen-inputs-r3.json)，612 个 Rust/Cargo/Python/.cargo 工程输入。
- 集合 SHA-256：`bab1cc3f38f1d84e5ea5a9e2e93d8cad77fe9d06e4707e37c8bd84e54c2dadd3`。
- 冻结 JSON 文件本身 SHA-256：`a8392637a51b626c96c16561be3afeb7f557ae480faa94fe4989b476aa110678`；它与集合摘要含义不同。
- 按批次 snapshot 合同独立枚举完整路径集合，**612/612，mismatch=0、extra=0、missing=0**；未仅对 manifest 内路径做单向抽查。
- 原件：[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-app/freeze-verification-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-app/freeze-verification-r1.json)、[完整路径清单](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-app/full-input-paths-r1.txt)。工程冻结不包含用户指南、HANDOFF 和 Hallmark JSON，已将所读文档的摘要另记在 [source-review-inputs-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-app/source-review-inputs-r1.json)。
- 已读 RTK、根 AGENTS、HANDOFF 当前旧编码批、SHARED_TARGET、ADR 0140、HALLMARK_NATIVE 全文及适用 Rust 技能；用户的严格只读范围优先于技能中的编译、修复或门禁步骤。
- 写入只发生于 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-app/`；执行受授权的稳定预构建测试副本及隔离测试夹具。未编辑/格式化生产或测试源码，未执行 Cargo、build、clean、Clippy、原生应用启动、commit、push 或资源清理；共享 target 仅做来源摘要读取。
- core/session 生产内部由另一位独立非作者审查，本审只阅读其 app 调用合同、旧入口限制和 SSH 连接身份接口，没有重复签署其完整实现。

**严重级别与发现**

| 级别 | 开放发现数 | 触发、影响及修订要求 |
| --- | ---: | --- |
| P0 | 0 | 无已确认发现。 |
| P1 | 0 | 无已确认发现。 |
| P2 | 0 | 无已确认发现。 |
| P3 | 0 | 无已确认发现。 |

本报告没有待关闭的生产缺陷或测试合同发现。以下是逐项核对的正向证据及其实际边界；不将尚未执行的 native 验收列为已完成。

**app 差分与合同证据**

| 核对对象及触发 | 源码与行号 | 结论和证据边界 |
| --- | --- | --- |
| 同一显示主机但替换真实连接；选择旧回调；读取选项改后又改回 | [ReadBinding](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/editor_encoding.rs:14)、[is_current](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/editor_encoding.rs:33)、[选择回调](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/editor_encoding.rs:126) | 比较 session token、`same_connection`、choice 及独立 UUID revision。`same_connection` 的 [实现](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/ssh.rs:1019) 比较认证连接 handle 的 Arc 身份。旧回调不改变新 choice 或已待审核字节；选择行为不启动 I/O。 |
| 重读审核后或异步读取中，文档路径、完整基线、metadata、格式、reload 状态或草稿变化 | [ReadContext](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/editor_encoding.rs:45)、[完整 snapshot 比较](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/editor_encoding.rs:77)、[worker 结果 guard](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files.rs:1834) | 绑定 editing、snapshot、TextFormat、reload_required 和准确草稿；迟到结果退役 operation 后拒绝采用，保留当前内容。新增迟到测试实际替换连接且复用 public token，另覆盖 revision、metadata 和文档身份。 |
| 脏草稿重读取消、确认；审核后新草稿或 metadata；旧帧确认/取消 | [request_read](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files.rs:2159)、[审核 freshness](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files.rs:2250)、[确认 UUID](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/review.rs:95)、[取消 UUID](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/review.rs:119) | 编码随明确重读候选保存；取消清掉审核上下文而不改草稿/原字节/格式；待审核读取上下文变化时拒绝旧确认。旧帧按钮必须匹配当前 review identity。 |
| 默认读取、五种显式读取与本地 choice 分离 | [worker 读取](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/worker.rs:467)、[decode_read](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/editor_encoding.rs:98)、[打开结果采用](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files.rs:1865) | 默认仍调用 Unicode decode；只有显式 ReadEncoded 使用明确 codec。1 MiB 完整常规文件 snapshot 送往严格 codec。选择不重解释当前打开文档，也不把编码写入 profile。 |
| 保存、空/无换行连续保存、不可表示或 best-fit 草稿 | [准备字节](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files.rs:1319)、[保存审核](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/merge.rs:316)、[传送准确格式](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/worker.rs:840) | 从当前打开文档格式生成最终字节，并携带同一 format 调用新授权 API；非法或有损草稿在审核前拒绝。审核显示准确编码、BOM、字节数、换行及完整 Unicode 正文。 |
| 保存 ACK 后最后一个字节被竞争者改掉；保存期间出现较新草稿；Unicode U+FEFF | [完整目标比较](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/worker.rs:871)、[已知格式 body](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/worker.rs:878)、[Saved 采用](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files.rs:1892) | 全部读回字节必须等于审核字节才构造 Saved。失败保留旧基线/草稿与已存在备份；成功迟到时保留较新草稿及原 envelope。旧 UTF-8 BOM-less FEFF、BOM 和 UTF-16 回归均已在当前新副本通过。 |
| merge、diff、patch 及远端不兼容格式变化 | [MergeObservation](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/merge.rs:14)、[接收绑定](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/merge.rs:77)、[合并采用](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/merge.rs:281)、[merge_outcome](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/worker.rs:1000)、[diff](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files.rs:2316)、[patch](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/merge.rs:414) | 合并观察携带准确格式，base/draft/remote 使用 Unicode 正文，采用后仍需新的全文保存审核。旧编码非法序列或 BOM 观察进入显式重读锁；恢复旧远端字节不自动解锁。patch 仍只产生草稿，diff 为逻辑行预览。 |
| 原 Unicode API 与 MCP 限额 | [Unicode compatibility API](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:609)、[64 KiB 普通写入口](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:599)、[MCP 参数预算](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-mcp/src/server.rs:335) | app 的新显式 format 调用没有扩张 MCP schema 或普通 reviewed write 的 64 KiB。真实 OpenSSH 新测试对五种非 UTF-8 source 均检查旧 Unicode API 拒绝。MCP 服务未由本审另行启动。 |
| Kit Popover、两尺寸、三主题明暗双语、固定操作及真实文件行 | [原生 Kit 入口](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/editor_encoding.rs:148)、[浮层宽高](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/editor_encoding.rs:187)、[Palette/组件 token](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/editor_encoding.rs:201)、[标题集成](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/navigation_view.rs:75)、[布局回归](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/editor_encoding_tests.rs:672) | 当前副本实测 900×580、1440×900 × Frost/Graphite/Lavender × Light/Dark × 中英文，共 24 个循环组合，计作 1 项测试。浮层在窗口内、六选项可见且位于内容横界内；关闭后真实远端文件行可见，全文审核确认/取消仍固定可达。未使用 theme ID 业务分支或新增字面颜色/字体。 |
| 未见输入与审核正文键盘 | [隐藏输入焦点撤销](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/view.rs:379)、[审核键盘](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/review.rs:53)、[隐藏输入回归](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/review_viewport_tests.rs:1023)、[正文 Enter 负例](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/review_viewport_tests.rs:282) | 当前副本验证隐藏 editor/manual/settings 不消费模拟输入、正文 Enter 不批准、滚动不写文件。Kit 0.9.1 Popover 本地依赖实现会捕获/恢复焦点，内容 Enter/Space 不激活父触发器；应用新增选择测试记录 SFTP/exec/atomic write 零增量。未把该源审和 headless 结果扩大为实际桌面 PTY 键盘隔离证明。 |

本表涵盖相对基线的 11 个文件：9 个 app 文件（files.rs、editor_encoding.rs、editor_encoding_tests.rs、navigation_view.rs、review.rs、worker.rs、merge.rs、test_server.rs、transfer_tests.rs），以及 openssh_interop.rs 与 support/openssh_editor_encoding.rs。
测试支持差分只增加 SFTP subsystem 计数、注册新测试和让真实编码按钮可达，未放宽生产拒绝条件或现有断言。
各文件 SHA 与行数见 [源码输入记录](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-app/source-review-inputs-r1.json)。

**预构建来源、完整库存与本审实际执行**

父交付 [final-review-inputs-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/final-review-inputs-r1.json) 已核对基线、r3 集合摘要、612 输入及 app compiler-artifact。
父 `final-test-build-r1` 是 workspace `--no-run --message-format=json`，其日志摘要与成功退出/reaped 回执相符；app 对应 artifact `fresh=false`。
它证明的是父构建来源，本审没有独立重编译。未用旧 r7 的 14 项通过替代当前副本。

- 稳定 app 副本：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/final-review-binaries/keelshell_app-bb7e65d3f7e183e9`。
- SHA-256：`14133b094ead0ca9d0d2dce7f094713e9fc8419efd9834c07527f85ba3c35e3b`；与清单指定 source 文件相等。
- 本审独立运行 `--list`，完整输出与父库存逐字节相同：**1260 项**；库存 SHA-256 为 `042c9885efbafc6dac2561948940bdc66fbf7d605839295e4ae0138b49cd71d7`。
- 14 个新 app 测试名同时匹配冻结源文件、父清单与独立完整库存。父清单中的 core40/session30 及 84 个默认新测试总数不作为本审独立执行数。
- 来源原件：[app-artifact-verification-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-app/app-artifact-verification-r1.json)、[独立完整 --list](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-app/app-independent-list-r1.txt)。

| 本审执行 | 通过 | 失败 | 忽略 | filtered out | 耗时 | 退出/回收 |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| 新增 `legacy_editor` | 14 | 0 | 0 | 1246 | 13.056 s | 0 / reaped |
| 旧 Unicode/FEFF、merge、patch、read guard、焦点与审核回归 | 54 | 0 | 0 | 1206 | 35.565 s | 0 / reaped |
| 两组去重 | 68 | 0 | 0 | 不相加 | 不作单次耗时 | overlap=0 |

54 项中包含 33 项 conflict/merge（其中旧 editor-format 18 项）、12 项 review viewport、3 项 action view、3 项 editor search，及 3 项 suspend/late-result 回归。
仅运行一次每个所列测试，没有通过重试覆盖失败。两次执行前后 612 项摘要、app 副本 SHA 一致。

本审使用 [run_prebuilt.py](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-app/run_prebuilt.py) 直接调用稳定副本，过滤器与真实命令、超时和退出均保存在各 JSON；该脚本不调用 Cargo。
实际新专项原件：[日志](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-app/app-legacy-independent-r1.log)、[回执](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-app/app-legacy-independent-r1.json)。
旧回归原件：[日志](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-app/app-regressions-independent-r1.log)、[回执](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-app/app-regressions-independent-r1.json)。
逐名计数及去重原件：[independent-test-summary-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-app/independent-test-summary-r1.json)。
现场执行平台为 Darwin arm64；这是 headless GPUI 控制器加真实认证 TCP/SFTP 夹具，不是本批 native 桌面交互。

**真实 OpenSSH 合同及原件复核**

正确原件为 [openssh-r1/result.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/openssh-r1/result.json)，不是 receipt.json。
父先前派生核对 FileNotFound 不改变 runner 事实，作为 notice 保留；本审未修改父回执或日志。
外层 runner `exit=0 / reaped=true / timeout=false / 14.945s`；内层 `outcome=passed / 14.876s`。
[tests.log](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/openssh-r1/tests.log:13) 实际逐名 **17 passed、0 failed、0 ignored**，与独立核对的完整 OpenSSH 库存集合一致。
其中新增 `editor_encoding::openssh_legacy_editor_preserves_encoding_original_backup_and_rejects_invalid_writes` 是 17 项中的 1 项；五个编码向量不另计五项。

新增测试的 [源码](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/support/openssh_editor_encoding.rs:8) 使用 65 秒有界等待和独立固定字节向量。
在五种编码中分别验证完整 source、明确 format、旧 Unicode API 拒绝、撤权拒绝、NUL candidate 拒绝及错误 format 拒绝；
拒绝后目录项数、target bytes、mode 和 mtime 保持；成功后完整读取目标及备份并逐字节核对，最后确认 SSH exec 仍存活。
它通过 [Fixture](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/openssh_interop.rs:419) 使用固定 loopback、临时 client key 和固定 host fingerprint，创建 UUID 私有目录。
正常成功路径显式关闭 SFTP/SSH 并删除本测试文件，异常路径由 runner 有界清理其私有资源。

实际运行日志指向 `openssh_interop-a9d9337d91cd9fb1`，与最终 workspace manifest 中的 `openssh_interop-f544c20314903785` 不是同一二进制。
本审按各自身份单列：实际 runner 产物现场 SHA 为 `0f11e5dd8f0fd4d38009baf4e0852556c7bea5872e27cc8b54c1ff8f5327d29a`，mtime 在该 runner 执行窗口内；
workspace 稳定副本 SHA 为 `f9fc593f39e594234e54463ed6dd6510016c3146c151d3aa520c943b8be46881`。
二者不互相代签。真实执行按 runner 原日志归属和持续不变的工程输入核对；实际运行二进制的 SHA 是本审后续读回值，不冒充 runner 当时已记录的 SHA。
本审没有另起服务器或使用过期临时密钥重跑真实 OpenSSH。

清理回执显示 `owned_processes_stopped=true`、`observed_processes_stopped=true`、`ancestry_unverified=[]`、`temporary_directory_removed=true`，累计跟踪 104 个进程身份。
本审另以只读检查确认私有临时目录当前 absent，`lsof` 对原 `127.0.0.1:63068` 无监听（exit 1）。
清理保证限于 runner 基于 kernel birth identity 所观察并拥有的进程，不推导从未观察到的已脱离后代或其他任务资源已清理。
`sshd.log` 的 21 条 BSM `setaudit_addr ... Operation not permitted` 原样保留；它们不被隐去，也未导致这 17 项传输断言失败。

全部计数、日志摘要、现场产物摘要与清理观察见 [openssh-evidence-audit-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-app/openssh-evidence-audit-r1.json)。
OpenSSH 结论只覆盖本机 disposable server 的 transport/API 行为，不授予生产、远端客户机器或 macOS/Windows/Linux GUI 验收。

**用户指南、依赖和未签署范围**

[中文 README](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/README.md:93)、[英文 README](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/README.en.md:93)、[文件区指南](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/product/FILES_WORKSPACE.md:3) 与
[文本编码指南](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/product/REMOTE_TEXT_FORMAT.md:3) 均说明了下一次显式读取与当前格式分离、脏草稿重读审核、无损失败、WHATWG 映射、1 MiB/4096 行及真实/headless/native 边界。
指南也明确备份 ACK 与目标完整读回不同、普通 SFTP 不是 CAS、不保证 owner/ACL/特殊模式/崩溃耐久性、不自动重试。
这些是保留的产品合同边界，不被测试向量的备份读回扩大。

现场 Cargo.lock 包含 `encoding_rs 0.8.44`、`zip 9.6.0`、`rand 0.10.4`，同时保留其他依赖需要的 rand 0.8/0.9。
父 `dependency-report-r3.json` 是保留的失败快照，`dependency-report-r4.json` 为 112 声明通过，复用 r3 的 37 个官方 metadata 响应；r4 不是又一次网络抓取。
本审阅读报告并核对这些锁定版本，没有重签“当前所有依赖最新”、重跑依赖网络检查或覆盖此前失败。
原 app r1–r6、旧 r7、旧 freeze r1/r2 均不被本报告改签为新冻结通过，现有原件摘要记录于 source-review-inputs-r1.json。

以下状态继续开放：

- 本批完整全仓格式、strict Clippy、workspace 测试、dependency policy 与 controller 终态：`PENDING`，由父核对同冻结成功后满足合并条件。
- macOS/Windows/Linux 本批真实 GPUI 桌面、OS 几何、完整键盘/IME/辅助技术与主题矩阵：`NOT_RUN`。受控窗口尺寸测试不等于实际 OS 窗口验收。
- 编码 Popover 在完整工作区终端中的实际 PTY 字节隔离、系统焦点往返、原生截图/AX 和屏幕阅读器：本审未执行。源码焦点机制、选择零 SFTP/exec 增量与隐藏输入 headless 回归仅按其实际层次签署。
- core/session 全部生产内部、其他平台 OpenSSH、发布包、安装覆盖、生产 SSH、严格 Zmodem peer、用户中继、FILE-05/M4 与完整产品目标：不在本审签署范围。

本报告完成了最终冻结 app 副本的独立执行和真实 OpenSSH 原件复核，签署仅限上述源码与实测功能；没有开放 P0–P3。

**本审独立实际通过的新专项测试名（14）**

```text
files::transfer_tests::editor_encoding_tests::legacy_editor_changed_readback_retains_the_old_baseline_and_raw_backup
files::transfer_tests::editor_encoding_tests::legacy_editor_default_rejects_non_utf8_and_explicit_read_enables_lossless_save
files::transfer_tests::editor_encoding_tests::legacy_editor_choice_is_local_and_does_not_reinterpret_or_save_the_open_draft
files::transfer_tests::editor_encoding_tests::legacy_editor_all_explicit_codecs_keep_exact_review_backup_and_readback
files::transfer_tests::editor_encoding_tests::legacy_editor_dirty_reread_cancel_then_confirm_preserves_and_replaces_exact_format
files::transfer_tests::editor_encoding_tests::legacy_editor_empty_and_no_break_saves_keep_encoding_and_crlf_policy
files::transfer_tests::editor_encoding_tests::legacy_editor_encoding_controls_and_reviews_fit_all_themes_languages_and_sizes
files::transfer_tests::editor_encoding_tests::legacy_editor_incompatible_remote_bytes_require_explicit_reread_even_after_reversion
files::transfer_tests::editor_encoding_tests::legacy_editor_late_reads_reject_replaced_connection_choice_and_document
files::transfer_tests::editor_encoding_tests::legacy_editor_late_save_keeps_newer_draft_and_the_exact_save_encoding
files::transfer_tests::editor_encoding_tests::legacy_editor_merge_and_diff_use_unicode_and_save_with_the_original_encoding
files::transfer_tests::editor_encoding_tests::legacy_editor_old_choice_callbacks_cannot_change_a_new_choice_or_pending_review
files::transfer_tests::editor_encoding_tests::legacy_editor_reread_review_rejects_newer_draft_and_changed_document_metadata
files::transfer_tests::editor_encoding_tests::legacy_editor_unrepresentable_and_best_fit_drafts_fail_before_review_or_write
```

**本审独立实际通过的旧回归测试名（54）**

```text
files::editor_search_tests::tests::replacement_changes_only_the_requested_matches
files::editor_search_tests::tests::editor_search_and_patch_address_body_offsets_and_keep_bom_crlf_envelope
files::editor_search_tests::tests::literal_search_is_bounded_and_nonoverlapping
files::transfer_tests::action_view_tests::settings_disclosures_preserve_drafts_and_real_rows_across_all_theme_palettes
files::transfer_tests::conflict_merge_tests::changed_baseline_rejects_a_late_merge_plan_even_when_path_and_draft_match
files::transfer_tests::action_view_tests::queue_details_cannot_keep_keyboard_focus_in_the_hidden_editor
files::transfer_tests::action_view_tests::entering_review_unmounts_settings_without_typing_into_their_retained_draft
files::transfer_tests::conflict_merge_tests::changed_remote_version_after_merge_adoption_restarts_review_and_link_fails_closed
files::transfer_tests::conflict_merge_tests::changes_during_merge_read_patch_parse_review_and_suspend_preserve_draft
files::transfer_tests::conflict_merge_tests::complete_merge_versions_keep_literal_rows_and_two_axis_scroll_without_writes
files::transfer_tests::conflict_merge_tests::conflict_navigation_retains_manual_drafts_and_invalidates_edited_manual_choice
files::transfer_tests::conflict_merge_tests::editor_format_tests::editor_format_actual_enter_cancel_and_save_use_exact_bom_crlf_bytes
files::transfer_tests::conflict_merge_tests::editor_format_tests::editor_format_changed_last_readback_byte_never_adopts_a_saved_baseline
files::transfer_tests::conflict_merge_tests::editor_format_tests::editor_format_final_bom_expansion_line_and_nul_limits_refuse_before_write
files::transfer_tests::conflict_merge_tests::editor_format_tests::editor_format_full_review_and_fixed_actions_fit_all_families_and_languages
files::transfer_tests::conflict_merge_tests::editor_format_tests::editor_format_mixed_and_standalone_cr_remain_verbatim_through_review
files::transfer_tests::conflict_merge_tests::editor_format_tests::editor_format_open_separates_one_signature_without_false_dirty
files::transfer_tests::conflict_merge_tests::editor_format_tests::editor_format_ordinary_merge_retains_exactly_one_original_bom
files::transfer_tests::conflict_merge_tests::editor_format_tests::editor_format_remote_signature_or_eol_change_requires_explicit_reopen
files::transfer_tests::conflict_merge_tests::editor_format_tests::editor_format_stale_review_refuses_changed_draft_and_keeps_newer_edits
files::transfer_tests::conflict_merge_tests::editor_format_tests::editor_format_successful_save_preserves_bomless_leading_feff
files::transfer_tests::conflict_merge_tests::editor_format_tests::editor_format_uniform_lf_draft_is_byte_identical_to_crlf_baseline
files::transfer_tests::conflict_merge_tests::editor_format_tests::editor_format_utf16_diff_preview_uses_decoded_bodies
files::transfer_tests::conflict_merge_tests::editor_format_tests::editor_format_utf16_le_and_be_round_trip_through_reviewed_sftp
files::transfer_tests::conflict_merge_tests::editor_format_tests::editor_format_utf16_merge_uses_decoded_bodies_and_preserves_remote_encoding
files::transfer_tests::conflict_merge_tests::editor_format_tests::independent_editor_format_no_newline_keeps_lf_policy_across_empty_and_plain_saves
files::transfer_tests::conflict_merge_tests::editor_format_tests::independent_editor_format_r1_crlf_policy_survives_zero_break_save
files::transfer_tests::conflict_merge_tests::editor_format_tests::independent_editor_format_r1_late_save_rebases_new_bom_once
files::transfer_tests::conflict_merge_tests::editor_format_tests::independent_editor_format_r1_merge_keeps_new_leading_feff
files::transfer_tests::conflict_merge_tests::editor_search_replaces_draft_and_reviewed_save_keeps_original_backup
files::transfer_tests::conflict_merge_tests::independent_remote_changes_merge_to_reviewed_draft_and_full_readback
files::transfer_tests::conflict_merge_tests::logical_diff_does_not_claim_byte_equality_for_line_ending_changes
files::transfer_tests::conflict_merge_tests::manual_merge_and_patch_remain_drafts_until_full_review
files::transfer_tests::conflict_merge_tests::merge_adopt_save_keeps_late_newer_draft_and_rebases_next_save
files::transfer_tests::conflict_merge_tests::patch_rejection_and_bilingual_full_review_preserve_state
files::transfer_tests::conflict_merge_tests::queue_details_move_focus_out_of_the_manual_conflict_draft
files::transfer_tests::conflict_merge_tests::rereading_remote_revokes_old_merge_without_adopting_a_different_baseline
files::transfer_tests::conflict_merge_tests::stale_merge_frame_actions_cannot_mutate_a_replacement_review
files::transfer_tests::conflict_merge_tests::stale_save_creates_conflict_review_and_every_conflict_requires_choice
files::transfer_tests::late_save_acknowledges_remote_commit_without_rewriting_the_archived_baseline
files::transfer_tests::review_viewport_tests::expanded_merge_focus_keeps_hidden_editor_and_manual_inputs_isolated
files::transfer_tests::review_viewport_tests::expanded_merge_keyboard_scroll_reaches_body_end_behind_fixed_actions
files::transfer_tests::review_viewport_tests::expanded_merge_versions_and_review_actions_fit_minimum_file_pane
files::transfer_tests::review_viewport_tests::expanded_mirror_review_keeps_complete_hash_rows_and_cancel_never_mutates
files::transfer_tests::review_viewport_tests::expanded_review_preserves_changed_draft_and_suspension_guards
files::transfer_tests::review_viewport_tests::expanded_save_review_retains_complete_rows_and_keyboard_scroll_in_minimum_pane
files::transfer_tests::review_viewport_tests::file_entry_actions_reveal_and_focus_real_keyboard_targets_without_path_changes
files::transfer_tests::review_viewport_tests::inline_editor_scroll_extent_includes_wrapped_actions_and_diff
files::transfer_tests::review_viewport_tests::inline_merge_card_keeps_review_actions_visible_while_body_scrolls
files::transfer_tests::review_viewport_tests::old_painted_save_cancellation_cannot_cancel_replacement_read_review
files::transfer_tests::review_viewport_tests::old_painted_save_confirmation_cannot_approve_replacement_read_review
files::transfer_tests::review_viewport_tests::remote_editor_selects_filename_language_without_changing_draft
files::transfer_tests::suspended_editor_revokes_an_existing_save_review_without_losing_the_draft
files::transfer_tests::suspension_discards_successful_late_read_and_resume_plan_without_changing_archive
```

**已核对父真实 OpenSSH 实际通过测试名（17，其中 1 新增）**

```text
editor_encoding::openssh_legacy_editor_preserves_encoding_original_backup_and_rejects_invalid_writes
openssh_acknowledged_pause_stops_writes_and_cancel_preserves_the_session
openssh_archive_tool_inspection_observes_path_and_preserves_the_connection
openssh_archive_tool_validation_checks_streams_without_creating_files
openssh_batch_exec_preserves_results_policy_and_unknown_timeout
openssh_checked_content_reads_inspect_regular_files_and_refuse_truncation
openssh_directory_resume_fills_partial_trees_in_both_directions
openssh_file_resume_revalidates_content_and_works_on_a_new_connection
openssh_parallel_atomic_replacement_handles_hardlinks_and_canonical_aliases
openssh_remote_completion_is_literal_read_only_and_uses_canonical_paths
openssh_resume_rejects_a_replaced_inode_without_writing_either_file
openssh_reviewed_archive_preserves_a_concurrently_created_remote_target
openssh_reviewed_archives_pack_and_extract_zip_and_tar_gz_exactly
openssh_reviewed_workflow_runs_dependencies_and_blocks_failed_descendants
openssh_server_archive_packs_remote_sources_with_exact_manifest_and_readback
openssh_target_parameter_values_are_exact_literals_on_separate_reviewed_connections
openssh_workflow_ui_collection_keeps_exact_output_and_connection_identity
```
