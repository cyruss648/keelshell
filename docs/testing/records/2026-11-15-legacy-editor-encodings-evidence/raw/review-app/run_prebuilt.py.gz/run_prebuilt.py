"""Execute a verified stable test copy; never invoke Cargo or mutate the target."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
BATCH = ROOT / "work/legacy-editor-batch-20261115"
OUT = Path(__file__).resolve().parent


def inputs():
    freeze = json.loads((BATCH / "frozen-inputs-r3.json").read_bytes())
    actual = {
        path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
        for path in freeze["files"]
    }
    if actual != freeze["files"]:
        raise RuntimeError("Engineering inputs drifted from freeze r3")
    return freeze["sha256"]


label = sys.argv[1]
filters = sys.argv[2:]
if not filters or "/" in label or not label.replace("-", "").isalnum():
    raise ValueError("Provide one unique label and at least one test filter")
manifest = json.loads((BATCH / "final-review-inputs-r1.json").read_bytes())
artifact = manifest["artifacts"]["app"]
binary = ROOT / artifact["copy"]
digest_before = hashlib.sha256(binary.read_bytes()).hexdigest()
if digest_before != artifact["sha256"]:
    raise RuntimeError("Stable app binary hash mismatch")
freeze_before = inputs()
command = [str(binary), *filters, "--test-threads=4"]
started_utc = datetime.now(timezone.utc).isoformat()
started = time.monotonic()
expired = False
environment = dict(os.environ)
temporary = OUT / "tmp"
temporary.mkdir(exist_ok=True)
environment["TMPDIR"] = str(temporary) + "/"
environment["PYTHONDONTWRITEBYTECODE"] = "1"
with (OUT / f"{label}.log").open("xb") as stream:
    process = subprocess.Popen(
        command,
        cwd=ROOT,
        env=environment,
        stdout=stream,
        stderr=subprocess.STDOUT,
        start_new_session=True,
    )
    try:
        for _ in range(8):
            try:
                process.wait(timeout=30)
                break
            except subprocess.TimeoutExpired:
                continue
        else:
            expired = True
    except KeyboardInterrupt:
        expired = True
    if expired:
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=5)
freeze_after = inputs()
digest_after = hashlib.sha256(binary.read_bytes()).hexdigest()
log = (OUT / f"{label}.log").read_bytes()
record = {
    "command": command,
    "started_utc": started_utc,
    "finished_utc": datetime.now(timezone.utc).isoformat(),
    "elapsed_seconds": round(time.monotonic() - started, 3),
    "exit_code": process.returncode,
    "timeout_or_interrupt": expired,
    "reaped": True,
    "freeze_before": freeze_before,
    "freeze_after": freeze_after,
    "binary_sha256_before": digest_before,
    "binary_sha256_after": digest_after,
    "binary_unchanged": digest_before == digest_after,
    "log_sha256": hashlib.sha256(log).hexdigest(),
    "independent_execution": True,
    "independent_recompilation": False,
    "cargo_or_shared_target_write": False,
}
with (OUT / f"{label}.json").open("x") as stream:
    json.dump(record, stream, indent=2)
    stream.write("\n")
print(json.dumps(record, indent=2))
sys.exit(0 if process.returncode == 0 and not expired else 1)
