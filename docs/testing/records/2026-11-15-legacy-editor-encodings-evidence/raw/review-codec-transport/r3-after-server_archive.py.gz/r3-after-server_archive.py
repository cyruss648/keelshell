"""Reviewed server archive protocol v1. macOS/Linux Python 3.8+, stdlib only.

This file is embedded verbatim in the reviewed command. Importing it performs
no filesystem operation; only the explicit inspect and pack modes execute.
"""

import base64
import contextlib
import hashlib
import json
import os
import signal
import stat
import sys
import tarfile
import time
import unicodedata
import uuid
import zipfile
import zlib


MAX_RESPONSE = 1024 * 1024
MAX_INPUT = 1024 * 1024
MAX_ENCODED = 64 * 1024 * 1024
MAX_EXPANDED = 128 * 1024 * 1024
MAX_MEMBERS = 2048
MAX_NAMES = 48 * 1024
MAX_PATH = 4096
MAX_DEPTH = 32
MAX_TAR_STREAM = MAX_EXPANDED + MAX_MEMBERS * 2048 + MAX_NAMES * 2 + 1024
CHUNK = 64 * 1024
SECONDS = 60
PREFIX = ".keelshell-server-archive-"
PAYLOAD = "payload"
STAT_KEYS = {
    "dev", "ino", "mode", "nlink", "size", "mtime_ns", "ctime_ns",
    "uid", "gid", "flags",
}


class Rejected(Exception):
    """A fixed-message protocol or filesystem rejection."""


def require(condition):
    if not condition:
        raise Rejected()


def expired(*_args):
    raise Rejected()


def capabilities():
    require(sys.version_info >= (3, 8) and os.name == "posix")
    require(sys.platform == "darwin" or sys.platform.startswith("linux"))
    require(all(hasattr(os, flag) for flag in
                ("O_NOFOLLOW", "O_DIRECTORY", "O_NONBLOCK", "O_CLOEXEC")))
    require(os.O_NOFOLLOW != 0 and os.O_DIRECTORY != 0)
    require(all(function in os.supports_dir_fd for function in
                (os.open, os.stat, os.mkdir, os.link, os.unlink, os.rmdir)))
    require(os.stat in os.supports_follow_symlinks)
    require(os.link in os.supports_follow_symlinks)
    require(os.scandir in os.supports_fd)
    require(hasattr(signal, "SIGALRM") and hasattr(signal, "alarm"))
    if sys.platform.startswith("linux"):
        require(hasattr(os, "listxattr") and hasattr(os, "removexattr"))


def private_acl(descriptor, clear=False):
    # Mode bits do not restrict Darwin extended allow entries. Operate only on
    # newly owned descriptors, before source bytes, and verify again at readback.
    # ENOTSUP, unavailable APIs and unknown ACL families fail closed.
    if sys.platform == "darwin":
        import ctypes
        import errno
        library = ctypes.CDLL(None, use_errno=True)
        signatures = (
            ("acl_init", (ctypes.c_int,), ctypes.c_void_p),
            ("acl_free", (ctypes.c_void_p,), ctypes.c_int),
            ("acl_set_fd_np", (ctypes.c_int, ctypes.c_void_p, ctypes.c_int), ctypes.c_int),
            ("acl_get_fd_np", (ctypes.c_int, ctypes.c_int), ctypes.c_void_p),
            ("acl_valid", (ctypes.c_void_p,), ctypes.c_int),
            ("acl_get_entry", (ctypes.c_void_p, ctypes.c_int,
                               ctypes.POINTER(ctypes.c_void_p)), ctypes.c_int),
        )
        for name, arguments, result in signatures:
            function = getattr(library, name)
            function.argtypes, function.restype = arguments, result
        # Public Darwin sys/acl.h: ACL_TYPE_EXTENDED=0x100, ACL_FIRST_ENTRY=0.
        if clear:
            empty = library.acl_init(0)
            require(empty)
            try:
                require(library.acl_set_fd_np(descriptor, empty, 0x100) == 0)
            finally:
                library.acl_free(empty)
        ctypes.set_errno(0)
        acl = library.acl_get_fd_np(descriptor, 0x100)
        if not acl:
            # Darwin reports ENOENT for a valid descriptor with no extended ACL.
            # Any inability to inspect ACLs, including EOPNOTSUPP, is rejected.
            require(ctypes.get_errno() == errno.ENOENT)
            os.fstat(descriptor)
            return
        try:
            require(library.acl_valid(acl) == 0)
            entry = ctypes.c_void_p()
            ctypes.set_errno(0)
            result = library.acl_get_entry(acl, 0, ctypes.byref(entry))
            require(result == -1 and ctypes.get_errno() == errno.EINVAL)
        finally:
            library.acl_free(acl)
    else:
        require(sys.platform.startswith("linux"))
        known = {"system.posix_acl_access", "system.posix_acl_default"}
        names = set(os.listxattr(descriptor))
        require(not any("acl" in name.lower() and name not in known for name in names))
        if clear:
            for name in sorted(names & known):
                os.removexattr(descriptor, name)
        require(not any("acl" in name.lower() for name in os.listxattr(descriptor)))


def key(path):
    # Match the codec's scalar-by-scalar upper-then-lower alias rule, without
    # Python's context-sensitive whole-string lowercasing (final sigma).
    upper = "".join(character.upper() for character in path)
    return "".join(character.lower() for character in upper)


def portable(path):
    require(type(path) is str and 0 < len(path.encode("utf-8")) <= MAX_PATH)
    require(not any(unicodedata.category(c) in ("Cc", "Cf", "Cs")
                    or c in '\\:<>\"|?*' for c in path))
    parts = path.split("/")
    require(len(parts) <= MAX_DEPTH)
    for part in parts:
        require(part not in ("", ".", "..") and not part.endswith((".", " ")))
        stem = part.split(".")[0].rstrip(". ").upper()
        require(stem not in ("CON", "PRN", "AUX", "NUL", "CLOCK$",
                             "CONIN$", "CONOUT$"))
        require(not (stem[:3] in ("COM", "LPT")
                     and stem[3:] in tuple("123456789") + ("¹", "²", "³")))


def absolute(path):
    require(type(path) is str and path.startswith("/")
            and len(path.encode("utf-8")) <= MAX_PATH)
    portable(path[1:])
    parent, leaf = path.rsplit("/", 1)
    return parent or "/", leaf


def exact_keys(value, keys):
    require(type(value) is dict and set(value) == set(keys))


def integer(value, minimum=0, maximum=(1 << 64) - 1):
    require(type(value) is int and minimum <= value <= maximum)


def pairs(items):
    result = {}
    for name, value in items:
        require(name not in result)
        result[name] = value
    return result


def invalid_constant(_value):
    raise Rejected()


def load_json(raw, limit):
    require(0 < len(raw) <= limit)
    return json.loads(raw.decode("utf-8"), object_pairs_hook=pairs,
                      parse_constant=invalid_constant)


def json_bytes(value, limit):
    encoded = json.dumps(value, ensure_ascii=False, separators=(",", ":"),
                         allow_nan=False).encode("utf-8")
    require(len(encoded) <= limit)
    return encoded


def request_from_arg(argument):
    require(len(argument) <= (MAX_NAMES + 8192) * 8)
    raw = base64.b64decode(argument, validate=True)
    request = load_json(raw, MAX_INPUT)
    exact_keys(request, ("version", "sources", "destination", "format"))
    require(type(request["version"]) is int and request["version"] == 1)
    require(request["format"] in ("zip", "tar.gz"))
    sources = request["sources"]
    require(type(sources) is list and 1 <= len(sources) <= 32)
    parent, destination = absolute(request["destination"])
    suffix = ".zip" if request["format"] == "zip" else ".tar.gz"
    require(destination.endswith(suffix))
    total = 0
    seen = {key(destination)}
    for source in sources:
        source_parent, name = absolute(source)
        require(source_parent == parent and key(name) not in seen)
        seen.add(key(name))
        total += len(source.encode("utf-8"))
    require(total <= MAX_NAMES)
    return request, parent, destination


def snapshot(info):
    require(not (getattr(info, "st_file_attributes", 0)
                 & stat.FILE_ATTRIBUTE_REPARSE_POINT))
    require(not getattr(info, "st_reparse_tag", 0))
    require(not (getattr(info, "st_flags", 0)
                 & getattr(stat, "UF_REPARSE", 0)))
    result = {
        "dev": info.st_dev, "ino": info.st_ino, "mode": info.st_mode,
        "nlink": info.st_nlink, "size": info.st_size,
        "mtime_ns": info.st_mtime_ns, "ctime_ns": info.st_ctime_ns,
        "uid": info.st_uid, "gid": info.st_gid,
        "flags": getattr(info, "st_flags", 0),
    }
    validate_stat(result)
    return result


def validate_stat(value):
    exact_keys(value, STAT_KEYS)
    for name, number in value.items():
        if name in ("mtime_ns", "ctime_ns"):
            integer(number, -(1 << 63), (1 << 63) - 1)
        else:
            integer(number)
    require(value["ino"] > 0 and value["nlink"] > 0)
    require(value["mode"] <= 0o177777)
    require(stat.S_IFMT(value["mode"]) in (stat.S_IFREG, stat.S_IFDIR))
    require(not (value["flags"] & getattr(stat, "UF_REPARSE", 0)))
    if stat.S_ISREG(value["mode"]):
        require(value["nlink"] == 1)


def identity(info):
    return tuple(info[name] for name in ("dev", "ino", "mode", "uid", "gid", "flags"))


def nofollow_flags(directory=False):
    return (os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK
            | (os.O_DIRECTORY if directory else 0))


@contextlib.contextmanager
def opened(name, parent_fd, directory=False):
    before = snapshot(os.stat(name, dir_fd=parent_fd, follow_symlinks=False))
    require(stat.S_ISDIR(before["mode"]) if directory
            else stat.S_ISREG(before["mode"]))
    descriptor = os.open(name, nofollow_flags(directory), dir_fd=parent_fd)
    try:
        require(snapshot(os.fstat(descriptor)) == before)
        yield descriptor, before
        require(snapshot(os.fstat(descriptor)) == before)
        require(snapshot(os.stat(name, dir_fd=parent_fd,
                                 follow_symlinks=False)) == before)
    finally:
        os.close(descriptor)


@contextlib.contextmanager
def anchored_parent(parent):
    # Retain every ancestor descriptor: no pathname traversal follows a link.
    descriptors = [os.open("/", nofollow_flags(True))]
    chain = [snapshot(os.fstat(descriptors[0]))]
    names = [] if parent == "/" else parent[1:].split("/")
    try:
        for name in names:
            before = snapshot(os.stat(name, dir_fd=descriptors[-1],
                                      follow_symlinks=False))
            require(stat.S_ISDIR(before["mode"]))
            descriptor = os.open(name, nofollow_flags(True),
                                 dir_fd=descriptors[-1])
            descriptors.append(descriptor)
            current = snapshot(os.fstat(descriptor))
            # Unselected ancestors can gain or lose unrelated children during
            # open. Their timestamps, size and link count are not authority.
            # Require the same inode and security metadata, as at final recheck;
            # opened() and scan() still compare full selected-tree snapshots.
            require(identity(current) == identity(before))
            chain.append(current)
        yield descriptors[-1], chain
        # Our stage and publication change parent timestamps/link count. The
        # anchor check compares identity and security metadata, not these fields.
        require(identity(snapshot(os.fstat(descriptors[0]))) == identity(chain[0]))
        for index, name in enumerate(names):
            named = snapshot(os.stat(name, dir_fd=descriptors[index],
                                     follow_symlinks=False))
            require(identity(named) == identity(chain[index + 1]))
    finally:
        for descriptor in reversed(descriptors):
            os.close(descriptor)


def absent(parent_fd, name):
    try:
        os.stat(name, dir_fd=parent_fd, follow_symlinks=False)
    except FileNotFoundError:
        return
    raise Rejected()


class Inventory:
    def __init__(self, expected=None, writer=None):
        self.members = []
        self.names = 0
        self.expanded = 0
        self.nodes = {}
        self.expected = expected
        self.writer = writer
        self.deadline = time.monotonic() + SECONDS

    def check_time(self):
        require(time.monotonic() < self.deadline)

    def add(self, path, kind, before):
        self.check_time()
        portable(path)
        require(len(self.members) < MAX_MEMBERS)
        self.names += len(path.encode("utf-8")) + (kind == "directory")
        require(self.names <= MAX_NAMES)
        size = before["size"] if kind == "file" else 0
        self.expanded += size
        require(self.expanded <= MAX_EXPANDED)
        parts = path.split("/")
        for index in range(1, len(parts) + 1):
            prefix = "/".join(parts[:index])
            terminal = index == len(parts)
            node = (prefix, kind if terminal else "directory", terminal)
            alias = key(prefix)
            if alias in self.nodes:
                previous = self.nodes[alias]
                require(previous[:2] == node[:2]
                        and not (terminal and previous[2]))
                node = (node[0], node[1], terminal or previous[2])
            self.nodes[alias] = node
        member = {"path": path, "kind": kind, "bytes": size,
                  "sha256": None, "stat": before}
        if self.expected is not None:
            require(len(self.members) < len(self.expected))
            reviewed = self.expected[len(self.members)]
            require(all(member[field] == reviewed[field]
                        for field in ("path", "kind", "bytes", "stat")))
        self.members.append(member)
        return member

    def visit(self, parent_fd, name, path):
        self.check_time()
        before = snapshot(os.stat(name, dir_fd=parent_fd, follow_symlinks=False))
        directory = stat.S_ISDIR(before["mode"])
        member = self.add(path, "directory" if directory else "file", before)
        with opened(name, parent_fd, directory) as (descriptor, current):
            require(current == before)
            if directory:
                if self.writer is not None:
                    self.writer.directory(member)
                names = []
                listed_bytes = 0
                with os.scandir(descriptor) as entries:
                    for entry in entries:
                        self.check_time()
                        portable(entry.name)
                        listed_bytes += len(entry.name.encode("utf-8"))
                        require(len(names) + len(self.members) < MAX_MEMBERS
                                and listed_bytes <= MAX_NAMES)
                        names.append(entry.name)
                for child in sorted(names):
                    self.visit(descriptor, child, path + "/" + child)
            else:
                digest = hashlib.sha256()
                remaining = before["size"]
                sink = (self.writer.file(member) if self.writer is not None
                        else contextlib.nullcontext(None))
                with sink as output:
                    while remaining:
                        self.check_time()
                        chunk = os.read(descriptor, min(CHUNK, remaining))
                        require(chunk)
                        remaining -= len(chunk)
                        digest.update(chunk)
                        if output is not None:
                            output.write(chunk)
                    require(os.read(descriptor, 1) == b"")
                member["sha256"] = digest.hexdigest()
                if self.expected is not None:
                    require(member["sha256"] ==
                            self.expected[len(self.members) - 1]["sha256"])


def scan(request, parent_fd, expected=None, writer=None):
    inventory = Inventory(expected, writer)
    before = snapshot(os.fstat(parent_fd))
    for source in request["sources"]:
        name = source.rsplit("/", 1)[1]
        inventory.visit(parent_fd, name, name)
    require(snapshot(os.fstat(parent_fd)) == before)
    if expected is not None:
        require(inventory.members == expected)
    return {"version": 1, "request": request, "root": before,
            "members": inventory.members, "expanded_bytes": inventory.expanded}


def validate_report(report, request):
    exact_keys(report, ("version", "request", "root", "members", "expanded_bytes"))
    require(type(report["version"]) is int and report["version"] == 1)
    require(report["request"] == request)
    # Equality alone permits True == 1, so independently validate the binding.
    request_from_arg(base64.b64encode(json_bytes(report["request"], MAX_INPUT)))
    validate_stat(report["root"])
    require(stat.S_ISDIR(report["root"]["mode"]))
    members = report["members"]
    require(type(members) is list and 1 <= len(members) <= MAX_MEMBERS)
    integer(report["expanded_bytes"], 0, MAX_EXPANDED)
    inventory = Inventory()
    roots = {source.rsplit("/", 1)[1] for source in request["sources"]}
    explicit = {}
    for member in members:
        exact_keys(member, ("path", "kind", "bytes", "sha256", "stat"))
        validate_stat(member["stat"])
        require(member["kind"] in ("file", "directory"))
        integer(member["bytes"], 0, MAX_EXPANDED)
        directory = member["kind"] == "directory"
        require(stat.S_ISDIR(member["stat"]["mode"]) == directory)
        require(member["bytes"] == (0 if directory else member["stat"]["size"]))
        digest = member["sha256"]
        require(digest is None if directory else
                type(digest) is str and len(digest) == 64
                and all(c in "0123456789abcdef" for c in digest))
        portable(member["path"])
        require(member["path"].split("/")[0] in roots)
        inventory.add(member["path"], member["kind"], member["stat"])
        explicit[member["path"]] = member["kind"]
    require(all(root in explicit for root in roots))
    for path in explicit:
        parts = path.split("/")
        require(all(explicit.get("/".join(parts[:index])) == "directory"
                    for index in range(1, len(parts))))
    require(inventory.expanded == report["expanded_bytes"])


class BoundedWriter:
    def __init__(self, raw):
        self.raw = raw

    def write(self, data):
        require(self.raw.tell() + len(data) <= MAX_ENCODED)
        written = self.raw.write(data)
        require(written == len(data))
        return written

    def tell(self):
        return self.raw.tell()

    def seek(self, offset, whence=0):
        position = self.raw.seek(offset, whence)
        require(0 <= position <= MAX_ENCODED)
        return position

    def flush(self):
        self.raw.flush()


class ZipOutput:
    def __init__(self, output):
        self.archive = zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED,
                                       allowZip64=False, compresslevel=6)

    def info(self, member, directory):
        info = zipfile.ZipInfo(member["path"] + ("/" if directory else ""),
                               date_time=(1980, 1, 1, 0, 0, 0))
        info.create_system = 3
        info.external_attr = ((stat.S_IFDIR | 0o700) if directory
                              else (stat.S_IFREG | 0o600)) << 16
        if directory:
            info.external_attr |= 0x10
        info.compress_type = zipfile.ZIP_STORED if directory else zipfile.ZIP_DEFLATED
        info.file_size = member["bytes"]
        return info

    def directory(self, member):
        self.archive.writestr(self.info(member, True), b"")

    def file(self, member):
        return self.archive.open(self.info(member, False), "w", force_zip64=False)

    def close(self):
        self.archive.close()

    def abort(self):
        # Prevent __del__ from emitting an unbounded interpreter traceback after
        # a bounded-writer failure. The enclosing raw-file owner still closes it.
        self.archive.fp = None


class StreamingGzip:
    def __init__(self, output):
        self.output = output
        # A basic gzip wrapper has no filename, owner, or wall-clock timestamp.
        # Unlike buffered file objects, this compressor has no writing finalizer.
        self.compressor = zlib.compressobj(6, zlib.DEFLATED, 31)
        self.expanded = 0

    def write(self, data):
        self.expanded += len(data)
        require(self.expanded <= MAX_TAR_STREAM)
        self.output.write(self.compressor.compress(data))
        return len(data)

    def close(self):
        self.output.write(self.compressor.flush())
        self.compressor = None

    def abort(self):
        self.compressor = None


class TarOutput:
    def __init__(self, output):
        self.gzip = StreamingGzip(output)

    def header(self, member, directory):
        name = member["path"] + ("/" if directory else "")
        encoded = name.encode("utf-8")
        if len(encoded) > 100:
            long = tarfile.TarInfo("././@LongLink")
            long.type = tarfile.GNUTYPE_LONGNAME
            long.size = len(encoded) + 1
            long.mode = 0o600
            self.gzip.write(long.tobuf(format=tarfile.GNU_FORMAT, encoding="utf-8",
                                      errors="strict"))
            self.gzip.write(encoded + b"\0")
            self.gzip.write(b"\0" * (-(len(encoded) + 1) % 512))
            # A truncated UTF-8 name could fail the codec's raw-header checks.
            name = "member/" if directory else "member"
        info = tarfile.TarInfo(name)
        info.type = tarfile.DIRTYPE if directory else tarfile.REGTYPE
        info.mode = 0o700 if directory else 0o600
        info.size = member["bytes"]
        info.uid = info.gid = info.mtime = 0
        self.gzip.write(info.tobuf(format=tarfile.GNU_FORMAT, encoding="utf-8",
                                  errors="strict"))

    def directory(self, member):
        self.header(member, True)

    @contextlib.contextmanager
    def file(self, member):
        self.header(member, False)
        yield self.gzip
        self.gzip.write(b"\0" * (-member["bytes"] % 512))

    def close(self):
        self.gzip.write(b"\0" * 1024)
        self.gzip.close()

    def abort(self):
        self.gzip.abort()


def stage_name(staging, parent, request):
    stage_parent, name = absolute(staging)
    require(stage_parent == parent and name.startswith(PREFIX))
    suffix = name[len(PREFIX):]
    require(str(uuid.UUID(suffix)) == suffix)
    require(key(name) not in {key(p.rsplit("/", 1)[1])
                             for p in request["sources"] + [request["destination"]]})
    return name


def own_directory(parent_fd, name, descriptor, expected):
    private_acl(descriptor)
    current = snapshot(os.fstat(descriptor))
    named = snapshot(os.stat(name, dir_fd=parent_fd, follow_symlinks=False))
    require(identity(current) == identity(expected) == identity(named)
            and stat.S_ISDIR(current["mode"])
            and current["uid"] == os.geteuid()
            and current["mode"] & 0o7777 == 0o700)


def payload_stat(info, inode, links):
    # Publication intentionally changes nlink/ctime; all other security metadata
    # stays normalized. Source snapshots always use the stricter nlink==1 rule.
    require(stat.S_ISREG(info.st_mode) and info.st_uid == os.geteuid()
            and info.st_mode & 0o7777 == 0o600 and info.st_nlink == links
            and (info.st_dev, info.st_ino) == inode
            and 0 < info.st_size <= MAX_ENCODED)


def readback(parent_fd, name, inode, size, links):
    descriptor = os.open(name, nofollow_flags(), dir_fd=parent_fd)
    try:
        private_acl(descriptor)
        before = os.fstat(descriptor)
        payload_stat(before, inode, links)
        require(before.st_size == size)
        digest = hashlib.sha256()
        remaining = size
        while remaining:
            chunk = os.read(descriptor, min(CHUNK, remaining))
            require(chunk)
            digest.update(chunk)
            remaining -= len(chunk)
        require(os.read(descriptor, 1) == b"")
        after = os.fstat(descriptor)
        private_acl(descriptor)
        payload_stat(after, inode, links)
        # Reads may update atime; no other metadata may change.
        require(after.st_size == size and after.st_gid == before.st_gid
                and after.st_mtime_ns == before.st_mtime_ns
                and after.st_ctime_ns == before.st_ctime_ns)
        named = os.stat(name, dir_fd=parent_fd, follow_symlinks=False)
        payload_stat(named, inode, links)
        require(named.st_size == size and named.st_mtime_ns == before.st_mtime_ns
                and named.st_ctime_ns == before.st_ctime_ns)
        return digest.hexdigest()
    finally:
        os.close(descriptor)


def pack(request, parent, destination, staging, expected):
    validate_report(expected, request)
    name = stage_name(staging, parent, request)
    with anchored_parent(parent) as (parent_fd, _chain):
        absent(parent_fd, destination)
        absent(parent_fd, name)
        require(scan(request, parent_fd) == expected)
        os.mkdir(name, 0o700, dir_fd=parent_fd)
        stage_fd = os.open(name, nofollow_flags(True), dir_fd=parent_fd)
        try:
            private_acl(stage_fd, clear=True)
            stage = snapshot(os.fstat(stage_fd))
            own_directory(parent_fd, name, stage_fd, stage)
            payload_fd = os.open(PAYLOAD, os.O_RDWR | os.O_CREAT | os.O_EXCL
                                 | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600,
                                 dir_fd=stage_fd)
            with os.fdopen(payload_fd, "w+b", buffering=0) as raw:
                private_acl(raw.fileno(), clear=True)
                initial = os.fstat(raw.fileno())
                require(initial.st_uid == os.geteuid()
                        and initial.st_mode & 0o7777 == 0o600
                        and initial.st_nlink == 1 and stat.S_ISREG(initial.st_mode))
                inode = (initial.st_dev, initial.st_ino)
                output = BoundedWriter(raw)
                codec = ZipOutput(output) if request["format"] == "zip" else TarOutput(output)
                # No cleanup path publishes or removes anything on failure.
                try:
                    scan(request, parent_fd, expected["members"], codec)
                    codec.close()
                except Exception:
                    codec.abort()
                    raise
                output.flush()
                os.fsync(raw.fileno())
                size = os.fstat(raw.fileno()).st_size
                require(0 < size <= MAX_ENCODED)
                digest = readback(stage_fd, PAYLOAD, inode, size, 1)
                scan(request, parent_fd, expected["members"])
                require(identity(snapshot(os.fstat(parent_fd))) ==
                        identity(expected["root"]))
                # Reopen the complete ancestor chain before publication.
                with anchored_parent(parent) as (fresh_fd, _fresh_chain):
                    require(identity(snapshot(os.fstat(fresh_fd))) ==
                            identity(expected["root"]))
                own_directory(parent_fd, name, stage_fd, stage)
                require(sorted(os.listdir(stage_fd)) == [PAYLOAD])
                require(readback(stage_fd, PAYLOAD, inode, size, 1) == digest)
                os.link(PAYLOAD, destination, src_dir_fd=stage_fd,
                        dst_dir_fd=parent_fd, follow_symlinks=False)
                os.fsync(parent_fd)
                require(readback(parent_fd, destination, inode, size, 2) == digest)
                own_directory(parent_fd, name, stage_fd, stage)
                require(sorted(os.listdir(stage_fd)) == [PAYLOAD])
                payload_stat(os.stat(PAYLOAD, dir_fd=stage_fd, follow_symlinks=False),
                             inode, 2)
                os.unlink(PAYLOAD, dir_fd=stage_fd)
                require(os.listdir(stage_fd) == [])
                own_directory(parent_fd, name, stage_fd, stage)
                os.rmdir(name, dir_fd=parent_fd)
                os.fsync(parent_fd)
                absent(parent_fd, name)
                require(readback(parent_fd, destination, inode, size, 1) == digest)
        finally:
            os.close(stage_fd)
    return {"version": 1, "archive_bytes": size, "sha256": digest}


def main():
    capabilities()
    require(len(sys.argv) in (3, 4) and sys.argv[1] in ("inspect", "pack"))
    require((sys.argv[1] == "inspect" and len(sys.argv) == 3)
            or (sys.argv[1] == "pack" and len(sys.argv) == 4))
    signal.signal(signal.SIGALRM, expired)
    signal.alarm(SECONDS)
    request, parent, destination = request_from_arg(sys.argv[2])
    if sys.argv[1] == "inspect":
        with anchored_parent(parent) as (parent_fd, _chain):
            absent(parent_fd, destination)
            result = scan(request, parent_fd)
            require(scan(request, parent_fd) == result)
            absent(parent_fd, destination)
    else:
        expected = load_json(sys.stdin.buffer.read(MAX_INPUT + 1), MAX_INPUT)
        result = pack(request, parent, destination, sys.argv[3], expected)
    response = json_bytes(result, MAX_RESPONSE)
    sys.stdout.buffer.write(response)
    sys.stdout.buffer.flush()
    signal.alarm(0)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        # Never expose paths, source contents, exceptions, or a success receipt.
        sys.stderr.buffer.write(b"KeelShell server archive rejected\n")
        sys.exit(65)
