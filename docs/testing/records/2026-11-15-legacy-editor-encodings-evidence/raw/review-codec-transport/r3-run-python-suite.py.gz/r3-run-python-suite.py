"""Run the verbatim frozen suite against preserved old/new helper bytes."""

from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time


ROOT = Path(__file__).resolve().parent
SUITE = ROOT / "r3-python-suite.py"
INVENTORY = json.loads((ROOT / "python-suite-audit-r3.json").read_text())


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def run_case(case):
    helper = ROOT / f"r3-{case}-server_archive.py"
    helper_bytes = helper.read_bytes()
    temporary = ROOT / "tmp-r3" / case
    temporary.mkdir(mode=0o700, parents=True, exist_ok=False)
    environment = os.environ.copy()
    environment["TMPDIR"] = str(temporary)
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    argv = [sys.executable, "-B", str(SUITE), helper_bytes.decode()]
    started = datetime.now(timezone.utc).isoformat()
    clock = time.monotonic()
    child = subprocess.Popen(
        argv,
        cwd=ROOT,
        env=environment,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        start_new_session=True,
    )
    timed_out = False
    try:
        stdout, stderr = child.communicate(timeout=60)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(child.pid, signal.SIGTERM)
        try:
            stdout, stderr = child.communicate(timeout=3)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            stdout, stderr = child.communicate(timeout=3)
    (ROOT / f"python-{case}-r3.stdout").write_bytes(stdout)
    (ROOT / f"python-{case}-r3.stderr").write_bytes(stderr)
    text = stderr.decode()
    rows = re.findall(
        r"^(test_\S+) \(([^)]+)\) \.\.\. (ok|ERROR|FAIL|skipped .*)$",
        text,
        re.MULTILINE,
    )
    expected_errors = {
        "test_ancestor_open_accepts_unrelated_child_creation",
        "test_ancestor_open_accepts_unrelated_child_removal",
    }
    actual_errors = {name for name, _, status in rows if status == "ERROR"}
    names = sorted(name for name, _, _ in rows)
    result = {
        "case": case,
        "command": [sys.executable, "-B", str(SUITE), "<verbatim helper text>"],
        "helper_argument_source": str(helper),
        "helper_argument_sha256": sha256(helper_bytes),
        "suite_sha256": sha256(SUITE.read_bytes()),
        "cwd": str(ROOT),
        "tmpdir": str(temporary),
        "started_utc": started,
        "elapsed_seconds": time.monotonic() - clock,
        "timeout_seconds": 60,
        "timed_out": timed_out,
        "exit_code": child.returncode,
        "reaped": child.returncode is not None,
        "python_executable": sys.executable,
        "python_version": sys.version,
        "platform": sys.platform,
        "bytecode_disabled_for_parent_and_children": True,
        "stdout_sha256": sha256(stdout),
        "stderr_sha256": sha256(stderr),
        "test_count": len(rows),
        "passed_count": sum(status == "ok" for _, _, status in rows),
        "error_count": len(actual_errors),
        "failure_count": sum(status == "FAIL" for _, _, status in rows),
        "skip_count": sum(status.startswith("skipped ") for _, _, status in rows),
        "results": [
            {"name": name, "test_id": identity, "status": status}
            for name, identity, status in rows
        ],
        "inventory_matches_frozen_suite": names == INVENTORY["new_inventory"],
        "summary_lines": [
            line for line in text.splitlines()
            if line.startswith(("Ran ", "OK", "FAILED"))
        ],
        "expected_red_control": case == "before",
        "red_error_set_matches_expected": actual_errors == expected_errors,
        "independent_python_source_execution": True,
        "independent_rust_recompilation": False,
    }
    expected = (
        child.returncode == 1 and actual_errors == expected_errors
        and result["passed_count"] == 28
        if case == "before"
        else child.returncode == 0 and result["passed_count"] == 30
        and result["error_count"] == 0
    )
    result["expected_outcome_matches"] = (
        expected
        and result["failure_count"] == 0
        and result["skip_count"] == 1
        and result["test_count"] == 31
        and result["inventory_matches_frozen_suite"]
        and not timed_out
        and result["reaped"]
    )
    print(json.dumps({
        key: value for key, value in result.items()
        if key not in ("results", "python_version")
    }), flush=True)
    return result


if __name__ == "__main__":
    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(run_case, ("before", "after")))
    output = ROOT / "python-execution-r3.json"
    with output.open("x") as stream:
        json.dump(results, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    if not all(result["expected_outcome_matches"] for result in results):
        raise SystemExit(1)
