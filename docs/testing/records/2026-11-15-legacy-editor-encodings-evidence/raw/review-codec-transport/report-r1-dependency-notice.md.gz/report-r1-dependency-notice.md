**KeelShell codec/session r1：依赖升级期间的签署边界补充**

原 [report-r1.md](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/report-r1.md) 的静态复核及功能执行结论只适用于 **r1 旧依赖冻结**：`zip 9.5.1`、直接依赖 `rand 0.10.3`、`encoding_rs 0.8.44`。其 `APPROVE_SCOPED` 不覆盖随后升级的根 manifest/lock、新依赖编译产物或最终全仓门禁。本补充与原报告成套阅读，保留原报告、原冻结、原副本和原始日志。

本次补充核对时间为 `2026-11-15T16:05:48.997516+00:00`，即北京时间 **2026-11-16 00:05:48**。结构化证据见 [dependency-notice-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/dependency-notice-r1.json)。

| 严重级别 | 本范围开放源码发现 |
| --- | ---: |
| P0 | 0 |
| P1 | 0 |
| P2 | 0 |
| P3 | 0 |

未发现需要立即通知父的新增源码缺陷。父已明确告知并正在处理的依赖升级，以及等待新冻结/新编译副本的状态，按未完成验证边界记录；它们没有被伪装为新的 codec/session 源码缺陷，也没有被当成已完成的依赖门禁。

**离线核对父提供的依赖证据。** [dependency-report-r3.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/dependency-report-r3.json) 的 SHA-256 为 `60991769eedf5176abc676485d60fb183d2bb4823f5a1f666393932bd8d937bf`，记录的 metadata 检查时间为 `2026-11-15T15:58:55Z` 至 `2026-11-15T15:59:07Z`。独立读取确认 112 条声明、37 个唯一 registry 包、37 份保存的响应，计数与报告一致。

已逐一解压并解析 `registry-metadata-r3/*.json.gz`，**37/37 响应正文 SHA-256 匹配** `raw_public_responses`。该字段采用解压后的 HTTP 响应正文哈希；gzip 容器字节的哈希另存于本补充 JSON，未混淆两者。当前复核者没有联网，也没有独立执行或审计父的 HTTP 获取过程；“宿主 HTTP route、官方 GET、无重定向/显式认证 handler”是父的获取记录，不是本次离线读取证明的网络行为。

| 保存的 metadata 包 | 快照中的 `max_stable_version` | 该版本 `yanked` | 旧冻结中的解析版本 |
| --- | --- | --- | --- |
| zip | 9.6.0 | false | 9.5.1 |
| rand | 0.10.4 | false | 直接依赖 0.10.3 |
| encoding_rs | 0.8.44 | false | 0.8.44 |

这是对父保存的 metadata 快照的读回，不是对当前实时 registry 状态的重新查询。r3 的顶层 `errors` 为空，但 **`status = "failed"`**，存在 6 条失败声明：workspace/app/core 的 zip 共 3 条，core/MCP/session 的 rand 共 3 条。zip 需要更新 requirement 的 major/minor，且 app/core 的直接 lock 未达该快照最新版本；rand 的 3 个直接使用者需更新 lock。不能将“metadata 已取回”改写为“依赖策略已通过”。旧的传递依赖 `rand 0.8.8`、`0.9.5` 与这里的直接 `rand 0.10.x` 分开识别，不要求无依据地移除它们。

**冻结和副本的当前状态。** 以下 5 个非根输入仍逐项匹配 r1；它们是 1 个 core manifest 和 4 个 Rust 源码/测试文件，不能误称为 5 个 Rust 源码文件。

| 输入 | SHA-256 |
| --- | --- |
| [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/Cargo.toml](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/Cargo.toml) | `fd51c21807c3cfd465337f430277ae7a07db7606e19707effae770afef8b88bc` |
| [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs) | `f9381cf61633437cf9e722b00062c4a85009c9f66a10791acfc93160d3b0b7c4` |
| [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document/legacy_tests.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document/legacy_tests.rs) | `d856683beb4c06d8cbaa71bfc689cdb091523e4020d5ca073129e1bb2f6b1a8e` |
| [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs) | `ca9120d91ae81ee4ccaa75a17e44038f2d3bca5bbd9b3e01a819cc82787c60a0` |
| [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/editor_encoding_tests.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/editor_encoding_tests.rs) | `2cb8ae13585e7596ec7939f74dcc8b7aa5733a12a77733f83f7c74a7c5ef00e3` |

两份旧稳定副本也仍匹配：core 为 `d47cc0aaea401eebd9af162f97db8426ec1b3f0c5e0ce684b62e267adddc6679`，session 为 `1dbfba00762db7c6466f0f17159bee6328fa09101247139ba7a628ae97c08d8b`。本补充只读取稳定副本字节，没有重跑或改写共享 target 中的原件。

当前根文件已经与 r1 不同，是父告知的依赖升级进行中的观测值：

| 观测文件 | 当前 SHA-256 | 读回内容 |
| --- | --- | --- |
| [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/Cargo.toml:44](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/Cargo.toml:44) | `a42dcfe8613ddd588b1a0da5036ba6ee4c90c73e5b1d304378176ef32c1a9e5e` | zip requirement 已为 `"9.6"`；rand 保持 `"0.10"`；encoding_rs 保持 `"0.8"` |
| [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/Cargo.lock:10786](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/Cargo.lock:10786) | `297f8bd7d3353461d81631ab3733ef804270b28fc06b4d16060563f26037cb77` | zip 已为 `9.6.0`；[rand 直接版本位置](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/Cargo.lock:6655) 为 `0.10.4`；encoding_rs 为 `0.8.44` |

根文件在本次读取前后字节一致，但这不等于父已提交新冻结，也不代表依赖图变化已完整复审。扫描当时只有原 `codec-transport-review-inputs-r1.json`，尚未取得替代冻结及对应新编译稳定副本。原报告 SHA 仍为 `9e49a336527f4088da90cff2beb15178112ae40bedc84cd94db5fddd775c2449`；原冻结 SHA 仍为 `1161f99811f4932d887596b0f34baffa8e6a68ea8b35ee23066720461c831440`。

**实际执行证据保持旧依赖归属。** 原复核已亲自执行下列两个父预构建稳定副本，完整名称和源码/库存对应关系见原报告及 `source-test-audit-r1.json`。本次再次离线读取原始 stdout/stderr，验证与执行 receipt 的哈希匹配、通过名称与预期集合相同、完整 `--list` 输出哈希与冻结相同。

| 原专项 filter / 参数 | 原完整 `--list` | 实际结果 | 测试构成 |
| --- | ---: | --- | --- |
| `text_document:: --test-threads=4` | 262 tests / 0 benchmarks | 63 passed / 0 failed / 0 ignored / 199 filtered | 40 个新增旧编码测试、23 个既有 Unicode 测试 |
| `sftp::editor_encoding_tests:: --test-threads=4` | 241 tests / 0 benchmarks | 36 passed / 0 failed / 0 ignored / 205 filtered | 30 个新增保存测试、6 个复用 fixture 自测 |

两个原专项均退出 0，单次上限 50 秒；原 `--list` 单次上限 30 秒。它们是**父预构建、非独立重新编译的执行**，不能证明新依赖编译或回归通过。本次补充新执行测试进程为 **0**，没有将原 99 项改记为新增运行。原 session 专项仅使用测试自行创建的本机 loopback SSH/SFTP fixture；没有客户机器或真实 OpenSSH/native 运行验收。

**后续差分复审与合并建议。** 未变的 5 个输入可沿用原静态审查；收到新冻结后再次核验这些 SHA，并只对实际变化的根 manifest/lock 及依赖图边进行差分审查。新编译稳定副本需要先逐一核验 SHA、完整 `--list` 和测试名称，再按授权有界执行对应专项，明确仍属于父编译产物；若原静态输入也变化，再仅扩展到实际变化部分。不从“观察到两个新版本号”推导完整依赖图或全仓门禁通过。

当前建议是 **保留旧依赖冻结下的 `APPROVE_SCOPED`，新依赖复审及最终合并门禁 PENDING**。复核者未执行 Cargo/build/clean/fmt/Clippy/全仓检查，未修改源码、Cargo 文件或共享 target，未联网。app 选择器的 Kit Popover 集成完全由父负责，仍不在本次签署范围；完整全仓门禁、app 集成和各平台 native 验收均没有被局部专项通过替代。
