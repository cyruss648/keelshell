**KeelShell 显式旧编码：独立、严格只读代码与功能复核 r1**

结论为 **APPROVE_SCOPED / FULL_GATE_PENDING**。本次签署仅覆盖冻结清单中的 7 个文件相对基线的差分：core 文本 codec、session explicit-format 保存入口及对应测试、manifest 和 lock。开放发现 **P0=0、P1=0、P2=0、P3=0**。允许父继续集成本范围候选；最终整批合并/功能提交仍须由父在相同最终工程输入上取得完整全仓门禁，并完成 app 的独立集成检查。该结论不签署 app、完整产品或 native 验收。

复核者是本任务中新进入的非作者，未参与本差分实现。末次冻结复查时间为 `2026-11-15T15:57:44.142566+00:00`。基线和当前 HEAD 均为 `2cfe0deb732db78f43a9b76d9e2c7e5c214a1f24`；被审候选是该基线上的未提交文件字节，不存在另一个已提交的候选 SHA。

| 严重级别 | 开放数量 | 缺陷位置、触发条件及影响 |
| --- | ---: | --- |
| P0 | 0 | 未发现 |
| P1 | 0 | 未发现 |
| P2 | 0 | 未发现 |
| P3 | 0 | 未发现 |

下文行号是实际审查证据位置，不代表存在缺陷。没有需要提前通知父的新增缺陷；不以缺少范围外验收制造源码发现。

已先读取 `/Users/hdh/.codex/RTK.md`、适用祖先及项目 `AGENTS.md`、完整 `docs/HANDOFF.md`、`docs/testing/SHARED_TARGET.md`、`docs/adr/0140-explicit-legacy-editor-encodings.md`，并应用 `rust-best-practices` 与 `rust-engineer` 的错误处理、测试、文档和 async 指引。用户的本次严格只读授权优先于 skill 中的一般 Cargo 验证步骤。

**冻结输入与来源核验。** 原始清单为 [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/codec-transport-review-inputs-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/codec-transport-review-inputs-r1.json)，SHA-256 为 `1161f99811f4932d887596b0f34baffa8e6a68ea8b35ee23066720461c831440`。开始和结束均逐项核对；7/7 文件匹配，清单自身未变化。两个新增测试文件不在基线 Git 树中，已直接完整读取，未遗漏于仅显示已跟踪文件的 Git diff 之外。

| 冻结文件 | 核验 SHA-256 | 初检/末检 |
| --- | --- | --- |
| [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/Cargo.toml](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/Cargo.toml) | `2dcece565d611723d9298a1c197e19ef5b2c8d84ed5bbd6e3b88e215f1257db0` | MATCH / MATCH |
| [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/Cargo.lock](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/Cargo.lock) | `776c8e5f5fb9b23dc05d2521f79f2f8fa5574d9e1dbb1eba95fb8ccc8797d937` | MATCH / MATCH |
| [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/Cargo.toml](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/Cargo.toml) | `fd51c21807c3cfd465337f430277ae7a07db7606e19707effae770afef8b88bc` | MATCH / MATCH |
| [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs) | `f9381cf61633437cf9e722b00062c4a85009c9f66a10791acfc93160d3b0b7c4` | MATCH / MATCH |
| [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document/legacy_tests.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document/legacy_tests.rs) | `d856683beb4c06d8cbaa71bfc689cdb091523e4020d5ca073129e1bb2f6b1a8e` | MATCH / MATCH |
| [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs) | `ca9120d91ae81ee4ccaa75a17e44038f2d3bca5bbd9b3e01a819cc82787c60a0` | MATCH / MATCH |
| [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/editor_encoding_tests.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/editor_encoding_tests.rs) | `2cb8ae13585e7596ec7939f74dcc8b7aa5733a12a77733f83f7c74a7c5ef00e3` | MATCH / MATCH |

两份父预构建稳定副本均先验 SHA，再执行完整 `--list`，随后才执行专项。原构建位置只做字节/dep-info 读取，未运行或修改共享 target。

| 二进制 | 父原件及稳定副本 | 二者 SHA-256 | 完整库存 |
| --- | --- | --- | ---: |
| `core-text-tests-r1` | [父原件](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/recovery-batch-integration-20261115/target/debug/build/keelshell-core/a54f33ee8a518a64/out/keelshell_core-a54f33ee8a518a64)；[稳定副本](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-binaries/keelshell_core-a54f33ee8a518a64) | `d47cc0aaea401eebd9af162f97db8426ec1b3f0c5e0ce684b62e267adddc6679` | 262 tests / 0 benchmarks |
| `session-encoding-tests-r1` | [父原件](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/recovery-batch-integration-20261115/target/debug/build/keelshell-session/fa7c45e79deaf5f4/out/keelshell_session-fa7c45e79deaf5f4)；[稳定副本](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-binaries/keelshell_session-fa7c45e79deaf5f4) | `1dbfba00762db7c6466f0f17159bee6328fa09101247139ba7a628ae97c08d8b` | 241 tests / 0 benchmarks |

| 完整 `--list` | 实际 stdout SHA-256 | 与冻结摘要 |
| --- | --- | --- |
| [core-text-tests-r1.list.stdout](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/core-text-tests-r1.list.stdout) | `d86f9f0b169e392a8295cd203da145f0beb372bae6388f5c7e651a1bebed9581` | MATCH |
| [session-encoding-tests-r1.list.stdout](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/session-encoding-tests-r1.list.stdout) | `dea317f0f4a39af02ee382280fb3d785a11ee292af06f0c6eedf5d89a5ca46a5` | MATCH |

两次 `--list` 均 exit 0，分别有 30 秒外层上限。core 库存确实包含 `text_document::` 的 63 个名字，分解为新增 `legacy_tests` 40 项和既有 Unicode 23 项；session 库存确实包含本模块 36 个名字，分解为新增保存行为 30 项和复用 fixture 自测 6 项。源码声明、完整库存和实际通过名字三者按集合核对，missing/unexpected 均为 0。

父原始专项日志也已实际读取：core 日志 SHA-256 `2ed44b503fd62397e119d15095534a7d2729ba95a5e39a2857f0e9d5386d5fe2`，session 日志 SHA-256 `5c23f276f94a16e1664193d99d1ec85d6da380b3ba8c2bddda5c1b8315442e81`，均与其原 JSON 回执一致，逐名通过集合也与本次一致。原日志记录了本主树的真实 `Compiling` 路径及冻结中的二进制路径。父 dep-info 包含 `text_document.rs`、`text_document/legacy_tests.rs`、`sftp.rs`、`sftp/editor_encoding_tests.rs` 和共享 fixture 的对应路径；详细记录在 [parent-depinfo-readback-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/parent-depinfo-readback-r1.json)。

这些来源检查和测试库存能排除本次明显的旧测试缺失，但不能替代独立重编译，也不能把 7 文件冻结扩展成整个 workspace 的构建输入证明。**本次所有 Rust 执行均为父预构建稳定副本的非独立重编译执行。**

**实际执行与计数。** 工作目录为 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport`，临时目录固定到该目录下的 `tmp`。每个专项外层 50 秒超时；两个测试进程均已实际 wait/reap。只运行了下列两个专项，没有扩大到完整二进制或其他测试过滤器。

| 实际执行 | passed | failed | ignored | filtered out | 外层实耗 | exit / reaped |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-binaries/keelshell_core-a54f33ee8a518a64 text_document:: --test-threads=4` | 63 | 0 | 0 | 199 | 13.782s / 50s | 0 / true |
| `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-binaries/keelshell_session-fa7c45e79deaf5f4 sftp::editor_encoding_tests:: --test-threads=4` | 36 | 0 | 0 | 205 | 0.284s / 50s | 0 / true |

合计为 **99 个通过的执行名字**，其中新增行为测试 70 项、既有 Unicode 23 项、fixture 复用 6 项。6 个 fixture 名字不是 6 项新增产品覆盖；父执行与本次复核也不叠加为新的独立用例总数。两次专项无超时、无 stderr。完整命令、时间、stdout/stderr SHA、预期/实际名字与 reap 信息在 [execution-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/execution-r1.json)；原始 stdout 文件保留逐项结果。

另执行一次限定范围的 `git --no-optional-locks diff --no-ext-diff --check 2cfe0deb732db78f43a9b76d9e2c7e5c214a1f24 -- <7 scope files>`，exit 0。该 Git 检查仅覆盖已跟踪变更，两个新增测试文件另由源码全文和名字集合检查覆盖。未执行 Cargo、clean、build、Clippy、格式化或全仓 gate。

**代码与行为证据。**

| 核对项、触发条件和预期影响 | 生产证据（绝对路径与行号） | 已核对的测试与断言 |
| --- | --- | --- |
| 严格解码：截断、多字节错误须拒绝；不得产生替换字符或自动换编码 | [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:191](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:191)；[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:443](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:443) | `legacy_multibyte_decoding_rejects_malformed_and_truncated_sequences` 枚举 GBK/GB18030/Big5/Shift_JIS 错误；流式尾部错误用例越过多个输出缓冲区后仍须失败。解码使用 `new_decoder_without_bom_handling` 和 `decode_to_utf8_without_replacement`。 |
| 原字节往返：可以解码但 encoder 无法逐字节重建的 alias/decode-only 输入不得进入可编辑基线 | [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:435](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:435) | [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document/legacy_tests.rs:247](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document/legacy_tests.rs:247) 对非 canonical 字节断言 `NonCanonicalEncoding`，并有 canonical 正例；[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/editor_encoding_tests.rs:498](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/editor_encoding_tests.rs:498) 对 source 和 candidate 分别验证拒绝且没有写入/残留。 |
| best-fit 未报错仍须拒绝：Shift_JIS 的日元、上划线、减号及 GB18030 修订映射不能静默改变 Unicode 草稿 | [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:376](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:376)；[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:479](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:479) | [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document/legacy_tests.rs:278](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document/legacy_tests.rs:278) 和 [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document/legacy_tests.rs:296](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document/legacy_tests.rs:296) 先证明第三方 codec `had_errors == false` 且得到 lossy bytes，再断言产品 `Unrepresentable` 和 `matches_bytes == false`。另有不可表示 emoji、NCR 和长前缀尾部负例。 |
| Unicode BOM、FEFF 和 NUL：旧编码不得重解释 Unicode 签名；权威 BOM-less UTF-8 格式须保留首个 FEFF；NUL 全路径拒绝 | [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:144](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:144)；[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:269](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:269)；[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:447](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:447) | 新用例覆盖 UTF-8/UTF-16/UTF-32 BOM、内部签名字节、GB18030 literal FEFF、save 输出碰撞 BOM、read/save/readback/comparison NUL；[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/editor_encoding_tests.rs:722](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/editor_encoding_tests.rs:722) 直接从指定 BOM-less `TextFormat` 读回多个 FEFF，未重新猜 BOM。 |
| 1 MiB raw、draft、decoded UTF-8、normalized Unicode 和 encoded 预算均须独立检查；不得只截断成功 | [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:369](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:369)；[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:443](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:443)；[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:545](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:545) | [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document/legacy_tests.rs:357](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document/legacy_tests.rs:357) 起覆盖五种 legacy 的恰好边界/超限；decoded expansion 用 raw 小于上限但 UTF-8 超限的反例；GB18030 encoded expansion 用 UTF-8 小于上限但最终 raw 超限的反例；CRLF 分别触发 raw 与 decoded 预算。原 Unicode 23 项同时覆盖 BOM/UTF-16 预算。 |
| 4096 行只限制保存：4097 行的原观察仍应能比较为 clean，可被替换为合法行数 | [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:357](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:357)；[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:365](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:365)；[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:411](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:411) | [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document/legacy_tests.rs:475](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document/legacy_tests.rs:475) 验证 4096 个 LF-delimited 片段可保存、再加尾行拒绝，4097 行观察仍精确匹配；[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/editor_encoding_tests.rs:682](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/editor_encoding_tests.rs:682) 实际通过 SFTP 完成 4097→4096 行替换并核验备份。CR-only 行策略保持既有 LF-delimited 合同。 |
| 换行不扩权：CRLF/LF 保留插入策略，Mixed/CR 保持 verbatim，不强制文件末尾换行，不跨编码继承策略 | [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:310](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:310)；[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:407](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:407) | line profiles、continuing no-break、compatibility、with-line-ending、encoding-change 用例逐字节检查。没有把 Unicode normalization 当作可表示性修复。 |
| 旧 Unicode API 保留，MCP 上限不扩大 | [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:144](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:144)；[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:599](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:599)；[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:616](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:616) | 默认 decode 仍仅 Unicode；原 session API 仍只比较检测出的 encoding，不新增严格 BOM/EOL 合同。新旧入口共用原 backup/write 路径；[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/editor_encoding_tests.rs:744](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/editor_encoding_tests.rs:744) 和 [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/editor_encoding_tests.rs:775](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/editor_encoding_tests.rs:775) 分别验证旧入口拒绝无效 Unicode legacy 字节、保留原 encoding-only 行为。1 MiB 正例另断言 MCP `OutputLimit(65536)`。 |
| 所有输入内容/格式校验先于任何备份和远端写入 | [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:664](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:664)；[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:701](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:701) | source `decode_body`、`matches_bytes`，candidate `decode_body`、`prepare_save` 及最终 bytes equality 全在 helper 调用前。负例检查 `SessionError::Invalid`/`OutputLimit`、WRITE/CLOSE 计数、完整原文件和目录；包括错误编码/行策略、malformed、alias、BOM、NUL、raw/decoded/line/CRLF 预算。错误内容不包含正文 sentinel。 |
| 授权必须在 await 后和每次 mutation 前复核；撤销不得发布目标 | [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:729](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:729)；[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:754](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:754)；[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/mutation.rs:106](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/mutation.rs:106)；[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/mutation.rs:133](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/mutation.rs:133) | expired-authority、metadata hold 后撤销、target CLOSE hold 后撤销分别执行，断言无初次 mutation 或只保留已确认 backup，原目标不变；已知终态撤销没有伪造 unknown quarantine。`TextFormat` 本身不授予写权限。 |
| backup ACK、目标 CLOSE ACK 和 POSIX rename STATUS 各自 await；不存在普通 rename 回退 | [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:705](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:705)；[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:799](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:799)；[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:891](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:891)；[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:919](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:919) | backup CLOSE hold 时只有 backup 临时文件，目标还未 staging；backup CLOSE 拒绝后目标未变；`set_atomic_unsupported(true)` 在新 raw SFTP channel 握手前生效，未广告 POSIX rename 即返回 Unsupported，无 mutation/回退。目标发布代码只接受明确 STATUS/Ok。 |
| staging 后仍重验精确原文件，pending 丢弃保留共享隔离 | [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:794](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:794)；[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:900](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:900)；[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/inspection.rs:129](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/inspection.rs:129)；[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/mutation.rs:70](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/mutation.rs:70) | target CLOSE hold 后通过同 SSH 的 sibling SFTP 写入返回 MutationBusy；外部将目标替换为同长度不同正文后，writer 失败且外部新正文/原 backup 都保留。丢弃 pending CLOSE future 后，可实际读到 quarantine，sibling 写入返回 MutationQuarantined；不是仅检查本地 bool。 |
| ACK 与完整目标读回是不同完成边界 | [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:653](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:653)；[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:724](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:724)；[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/editor_encoding_tests.rs:197](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/editor_encoding_tests.rs:197) | transport 返回 acknowledged backup path；`assert_saved` 由测试调用者另外读取完整 backup 与 target snapshot，核对 exact bytes/permissions/无临时文件。API 自身没有把 target readback 合并到返回值；app 是否执行并正确接纳该读回，留给父 app 集成复核。 |

`inspection.rs`、`mutation.rs`、共享 packet fixture 和 core `lib.rs` 的当前字节都与指定基线相同，作为理解调用边界的只读上下文核对；它们不计入本次差分签署文件。codec 的 4096 字节栈缓冲区只消费第三方 API 报告的 `written`，严格处理 OutputFull/InputEmpty/Malformed/Unmappable；离线读取已安装 `encoding_rs 0.8.44` 的 API 文档，确认逐次输出为完整 Unicode 字符、剩余输入按 read 推进及 last=true 的调用约定。未引入 unsafe、生产 panic 或正文错误输出。

**测试实际证明的范围。** 测试使用真实 localhost TCP/SSH/SFTP 协议与内存文件系统：新 session fixture 在 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/editor_encoding_tests.rs:123` 绑定 `127.0.0.1:0`，随机临时主机密钥和精确 fingerprint，仅该进程内测试账号。没有访问外部网络或客户机器，没有真实 OpenSSH daemon、容器或 OS 远端文件系统。本次不会把 fixture 写成真实 OpenSSH/native 验收。

- `editor_encoding_lossy_best_fit_and_unrepresentable_drafts_produce_no_candidate`（[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/editor_encoding_tests.rs:523](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/editor_encoding_tests.rs:523)）只调用 core `prepare_save`，并验证不存在 candidate/远端 mutation。它没有调用新 session 保存 API，不能证明 session 能从已经被调用者有损替换的字节恢复 Unicode 草稿。byte-only API 本来无法恢复该信息；core 的 draft→bytes 审核链仍由调用者使用。
- `editor_encoding_wrong_source_encoding_is_typed_and_mutation_free` 使用在所选 Unicode 格式下无效的源字节。它不承诺识别所有选错但在多个 legacy codec 中都合法、能往返的字节；显式选择的含义是遵守选择，未增加内容猜测。
- 成功保存和 CLOSE hold/失败/丢弃用例真实执行新入口。正常成功的 backup/target 全量读回已覆盖；该选集没有独立注入“rename STATUS 丢失”和“rename ACK 后目标被篡改/调用者读回失败”的新场景。相关继承代码已静态核对，父的 app/全仓后续证据须单独覆盖，不由这些用例补签。
- 六个 `sftp_fixture` 自测来自既有共享文件的再次编译引入；它们验证 canonical-path/write gate 自身，不是六个 editor 产品行为测试。所有名字在下方完整列出，没有把同源重复包装计成新增功能。

**Manifest/lock。** [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/Cargo.toml:24](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/Cargo.toml:24) 新增 workspace 直接 registry requirement `encoding_rs = "0.8"`，[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/Cargo.toml:17](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/Cargo.toml:17) 以 workspace 继承；满足本次增量的 `x.y` 合同。[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/Cargo.lock:4517](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/Cargo.lock:4517) 仅新增 core→encoding_rs 的依赖边。对基线与当前 lock 的完整 package map 比较：新增/移除 package 均为 0，除 core 的该依赖边外无 package 记录变化；现有解析版本是 `encoding_rs 0.8.44`。不声明依赖最新版本，不联网重做版本查询。原默认 Unicode 方法、1 MiB/4096 常量、MCP 64 KiB 入口均保留。详细结构化核对见 [source-test-audit-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/source-test-audit-r1.json)。

**交付限制及可合并建议。** 范围内未发现阻止集成的源码问题，7 文件输入签署 `APPROVE_SCOPED`。最终全仓门禁仍为 **PENDING**；本次没有执行 `scripts/check.py`、workspace tests/doctests、fmt 或严格 Clippy，也没有把历史 HANDOFF 中其他批次的成功状态继承过来。父须在最终集成冻结上完成这些门禁；若这 7 文件发生变化，应按新冻结做增量复核。

app 的读取选择器、审核身份/迟到回复、保存后的完整读回接纳、冲突合并、三主题/双语、紧凑窗口、IME/辅助技术和 native 三平台均不在签署范围。`crates/keelshell-session/tests/openssh_interop.rs` 本批差分也不在冻结的 7 文件中，未审、未运行。完整目标读回、真实 disposable OpenSSH、跨平台构建/运行、安装发布及产品验收没有在本复核中被证明。SFTP 仍无原子 compare-and-swap，最终复核后发生的外部并发变化不能由本 API 排除。

执行期间只在指定新 review 目录创建本报告、冻结副本、SHA/库存/来源/执行回执、限定 diff 和空临时目录；没有修改或格式化源码/manifest/lock，没有 Cargo/clean/build/commit/push，没有写共享 target、触碰父其他资源或清理任何既有证据。末次 7 个源文件和四个 binary 位置的摘要 **11/11 MATCH**，清单自身未变。证据入口为 [verification-initial.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/verification-initial.json)、[verification-final.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/verification-final.json)、[execution-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/execution-r1.json)、[source-test-audit-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/source-test-audit-r1.json)、[diff-check-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/diff-check-r1.json)。

**完整实际执行名字。** 下列 99 个名字均在对应完整 `--list` 中，并在本次专项 stdout 中实际记录 `ok`。按源码分组列出，排序不代表并行执行顺序。

**core 新增行为 40 项**

- `text_document::legacy_tests::legacy_encoding_names_and_classification_are_explicit` — ok
- `text_document::legacy_tests::gbk_known_chinese_and_euro_bytes_round_trip` — ok
- `text_document::legacy_tests::gb18030_known_chinese_and_four_byte_scalar_round_trip` — ok
- `text_document::legacy_tests::big5_known_chinese_bytes_round_trip` — ok
- `text_document::legacy_tests::shift_jis_known_japanese_and_halfwidth_bytes_round_trip` — ok
- `text_document::legacy_tests::windows1252_known_accents_quotes_and_euro_round_trip` — ok
- `text_document::legacy_tests::legacy_empty_and_ascii_documents_keep_the_explicit_encoding` — ok
- `text_document::legacy_tests::default_decoder_stays_unicode_only_after_legacy_support` — ok
- `text_document::legacy_tests::explicit_legacy_selection_does_not_prefer_valid_utf8` — ok
- `text_document::legacy_tests::legacy_reads_and_known_formats_reject_all_unicode_boms` — ok
- `text_document::legacy_tests::legacy_keeps_internal_signature_bytes_as_selected_codec_content` — ok
- `text_document::legacy_tests::legacy_multibyte_decoding_rejects_malformed_and_truncated_sequences` — ok
- `text_document::legacy_tests::windows1252_defined_c1_control_mappings_are_not_replacement_errors` — ok
- `text_document::legacy_tests::legacy_rejects_aliases_and_decode_only_mappings_as_edit_baselines` — ok
- `text_document::legacy_tests::shift_jis_rejects_yen_overline_and_minus_best_fit_without_encoder_errors` — ok
- `text_document::legacy_tests::gb18030_rejects_revision_best_fit_without_encoder_errors` — ok
- `text_document::legacy_tests::legacy_unrepresentable_drafts_never_become_numeric_character_references` — ok
- `text_document::legacy_tests::legacy_nul_is_rejected_on_read_save_readback_and_comparison` — ok
- `text_document::legacy_tests::legacy_raw_and_draft_limits_accept_exactly_one_mib` — ok
- `text_document::legacy_tests::legacy_decoded_utf8_expansion_has_an_independent_exact_limit` — ok
- `text_document::legacy_tests::gb18030_encoded_expansion_has_an_independent_exact_raw_limit` — ok
- `text_document::legacy_tests::legacy_crlf_expansion_counts_towards_the_final_raw_budget` — ok
- `text_document::legacy_tests::legacy_crlf_expansion_counts_towards_the_decoded_utf8_budget` — ok
- `text_document::legacy_tests::legacy_line_limit_accepts_4096_and_keeps_4097_line_observations_clean` — ok
- `text_document::legacy_tests::legacy_line_profiles_preserve_crlf_mixed_cr_and_final_newline_policy` — ok
- `text_document::legacy_tests::legacy_continuing_no_break_saves_retain_the_existing_insertion_policy` — ok
- `text_document::legacy_tests::legacy_insertion_policy_never_crosses_an_encoding_change` — ok
- `text_document::legacy_tests::legacy_format_compatibility_requires_the_same_encoding_and_line_policy` — ok
- `text_document::legacy_tests::legacy_with_line_ending_changes_only_the_authoritative_insertion_policy` — ok
- `text_document::legacy_tests::legacy_streaming_preserves_multibyte_characters_across_output_buffers` — ok
- `text_document::legacy_tests::legacy_streaming_rejects_malformed_input_after_full_output_buffers` — ok
- `text_document::legacy_tests::legacy_streaming_rejects_best_fit_and_unrepresentable_draft_tails` — ok
- `text_document::legacy_tests::legacy_saves_never_unicode_normalize_a_draft_to_make_it_representable` — ok
- `text_document::legacy_tests::legacy_saves_reject_output_that_would_introduce_a_unicode_signature` — ok
- `text_document::legacy_tests::gb18030_preserves_literal_leading_and_internal_feff_as_content` — ok
- `text_document::legacy_tests::explicit_unicode_selection_matches_existing_bom_and_content_semantics` — ok
- `text_document::legacy_tests::explicit_unicode_selection_rejects_missing_or_wrong_encoding_boms` — ok
- `text_document::legacy_tests::explicit_unicode_selection_keeps_utf32_and_malformed_unicode_rejected` — ok
- `text_document::legacy_tests::explicit_unicode_selection_keeps_bomless_feff_readback_authority` — ok
- `text_document::legacy_tests::legacy_errors_display_and_debug_never_include_document_contents` — ok

**core 既有 Unicode 23 项**

- `text_document::tests::text_document_unchanged_round_trip_keeps_bom_unicode_terminators_and_eof` — ok
- `text_document::tests::text_document_preserves_uniform_policy_without_double_cr_or_forced_eof` — ok
- `text_document::tests::text_document_only_one_signature_is_removed_and_internal_feff_remains` — ok
- `text_document::tests::text_document_final_raw_budget_includes_bom_and_crlf_expansion` — ok
- `text_document::tests::text_document_save_line_bound_does_not_mark_an_unchanged_read_dirty` — ok
- `text_document::tests::text_document_rejects_binary_invalid_and_other_encoding_signatures` — ok
- `text_document::tests::text_document_format_changes_require_a_new_observation` — ok
- `text_document::tests::text_document_continuing_no_break_observation_retains_insertion_policy` — ok
- `text_document::tests::text_document_encoding_names_and_utf16_known_bytes_preserve_byte_order` — ok
- `text_document::tests::text_format_decode_body_uses_observed_bom_and_preserves_leading_feff_content` — ok
- `text_document::tests::text_document_utf16_round_trip_removes_only_one_bom_and_keeps_all_line_profiles` — ok
- `text_document::tests::text_document_utf16_saves_follow_existing_newline_policy_and_eof` — ok
- `text_document::tests::text_document_bomless_input_is_utf8_and_never_guessed_as_utf16` — ok
- `text_document::tests::text_document_utf32_boms_are_rejected_before_utf16_classification` — ok
- `text_document::tests::text_document_utf16_rejects_odd_bytes_and_malformed_surrogates_without_contents` — ok
- `text_document::tests::text_document_all_encodings_reject_nul_on_read_save_and_comparison` — ok
- `text_document::tests::text_document_utf8_never_replaces_malformed_or_partial_sequences` — ok
- `text_document::tests::text_document_utf16_raw_budget_includes_bom_and_newline_expansion` — ok
- `text_document::tests::text_document_utf16_decoded_body_and_save_draft_have_independent_utf8_budget` — ok
- `text_document::tests::text_document_utf16_line_bound_keeps_unchanged_observation_clean` — ok
- `text_document::tests::text_document_format_compatibility_checks_encoding_bom_and_line_policy` — ok
- `text_document::tests::text_document_utf16_continuing_empty_and_plain_saves_retain_original_policy` — ok
- `text_document::tests::text_document_insertion_policy_does_not_cross_encoding_changes` — ok

**session 新增行为 30 项**

- `sftp::editor_encoding_tests::editor_encoding_gbk_preserves_exact_source_backup_and_replacement` — ok
- `sftp::editor_encoding_tests::editor_encoding_gb18030_preserves_four_byte_source_backup_and_replacement` — ok
- `sftp::editor_encoding_tests::editor_encoding_big5_preserves_exact_source_backup_and_replacement` — ok
- `sftp::editor_encoding_tests::editor_encoding_shift_jis_preserves_exact_source_backup_and_replacement` — ok
- `sftp::editor_encoding_tests::editor_encoding_windows1252_preserves_exact_source_backup_and_replacement` — ok
- `sftp::editor_encoding_tests::editor_encoding_wrong_source_encoding_is_typed_and_mutation_free` — ok
- `sftp::editor_encoding_tests::editor_encoding_source_must_roundtrip_under_supplied_line_policy` — ok
- `sftp::editor_encoding_tests::editor_encoding_invalid_source_never_falls_back_or_replaces_bytes` — ok
- `sftp::editor_encoding_tests::editor_encoding_invalid_candidate_is_rejected_before_backup` — ok
- `sftp::editor_encoding_tests::editor_encoding_candidate_must_equal_prepared_line_policy_bytes` — ok
- `sftp::editor_encoding_tests::editor_encoding_legacy_authority_cannot_reinterpret_unicode_boms` — ok
- `sftp::editor_encoding_tests::editor_encoding_noncanonical_legacy_source_and_candidate_are_rejected` — ok
- `sftp::editor_encoding_tests::editor_encoding_lossy_best_fit_and_unrepresentable_drafts_produce_no_candidate` — ok
- `sftp::editor_encoding_tests::editor_encoding_expired_authority_creates_no_backup_or_temporary` — ok
- `sftp::editor_encoding_tests::editor_encoding_authority_revoked_during_source_check_prevents_all_mutations` — ok
- `sftp::editor_encoding_tests::editor_encoding_raw_source_and_candidate_budgets_fail_before_backup` — ok
- `sftp::editor_encoding_tests::editor_encoding_decoded_source_and_candidate_budgets_fail_before_backup` — ok
- `sftp::editor_encoding_tests::editor_encoding_saved_line_budget_rejects_candidate_before_backup` — ok
- `sftp::editor_encoding_tests::editor_encoding_final_crlf_expansion_budget_fails_before_backup` — ok
- `sftp::editor_encoding_tests::editor_encoding_source_over_line_limit_can_be_replaced_at_save_line_limit` — ok
- `sftp::editor_encoding_tests::editor_encoding_one_mib_legacy_save_keeps_mcp_at_64_kib` — ok
- `sftp::editor_encoding_tests::editor_encoding_bomless_leading_feff_uses_exact_authority_without_reguessing` — ok
- `sftp::editor_encoding_tests::editor_encoding_unicode_entrypoint_rejects_legacy_sources_and_candidates` — ok
- `sftp::editor_encoding_tests::editor_encoding_unicode_compatibility_entrypoint_keeps_encoding_only_check` — ok
- `sftp::editor_encoding_tests::editor_encoding_missing_posix_rename_has_no_mutations_or_fallback` — ok
- `sftp::editor_encoding_tests::editor_encoding_backup_close_ack_precedes_target_staging` — ok
- `sftp::editor_encoding_tests::editor_encoding_backup_close_failure_prevents_target_staging` — ok
- `sftp::editor_encoding_tests::editor_encoding_revalidates_source_after_staging_and_excludes_shared_writers` — ok
- `sftp::editor_encoding_tests::editor_encoding_revocation_before_publication_retains_original_and_backup` — ok
- `sftp::editor_encoding_tests::editor_encoding_dropped_target_close_keeps_backup_and_shared_quarantine` — ok

**session 同源 fixture 复用 6 项**

- `sftp::editor_encoding_tests::sftp_fixture::canonical_path_gate_tests::exact_path_hold_survives_clones_and_releases_on_owner_drop` — ok
- `sftp::editor_encoding_tests::sftp_fixture::canonical_path_gate_tests::expired_reply_stays_owned_until_drop_and_cannot_rearm_silently` — ok
- `sftp::editor_encoding_tests::sftp_fixture::canonical_path_gate_tests::release_before_poll_and_old_handler_do_not_consume_new_hold` — ok
- `sftp::editor_encoding_tests::sftp_fixture::transfer_write_gate_tests::a_missing_release_expires_as_failure_instead_of_admitting_a_write` — ok
- `sftp::editor_encoding_tests::sftp_fixture::transfer_write_gate_tests::first_write_unrelated_targets_and_release_before_poll_are_never_held` — ok
- `sftp::editor_encoding_tests::sftp_fixture::transfer_write_gate_tests::guard_unwind_releases_an_entered_write_and_rearming_does_not_retrap_it` — ok

