**KeelShell codec/session：最终依赖 r2 限定差分复核**

结论为 **APPROVE_SCOPED / FULL_GATE_PENDING**。本次批准绑定 r2 的 7 个文件及最终工程冻结 `612` 项、聚合摘要 `bab1cc3f38f1d84e5ea5a9e2e93d8cad77fe9d06e4707e37c8bd84e54c2dadd3`，覆盖 core 文本 codec、session explicit-format 保存及对应测试、manifest/lock 的限定差分。新依赖下实际执行 core **63/63**、session **36/36**，均退出 0、无超时并已回收。开放发现 **P0=0、P1=0、P2=0、P3=0**。

| 严重级别 | 开放数量 | 缺陷位置、触发条件与影响 |
| --- | ---: | --- |
| P0 | 0 | 未发现 |
| P1 | 0 | 未发现 |
| P2 | 0 | 未发现 |
| P3 | 0 | 未发现 |

未发现需要提前通知父的新增缺陷。下文绝对路径和行号均为核对证据，不是缺陷定位。基线与本次初检 HEAD 均为 `2cfe0deb732db78f43a9b76d9e2c7e5c214a1f24`；被审候选仍是该基线上的冻结文件字节，不能虚构成另一个已提交的候选 SHA。

复核者为本任务的独立非作者，未参与实现。r1 已完整读取 RTK、适用 AGENTS、HANDOFF、SHARED_TARGET、ADR 0140，并应用 `rust-best-practices` 与 `rust-engineer`；本轮沿用这些边界，仅重审变化的依赖及新编译副本。原 [report-r1.md](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/report-r1.md) 与 [旧依赖补充说明](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/report-r1-dependency-notice.md) 均保留。r1 的旧二进制结果没有被用于替代本轮新依赖执行。

**冻结身份与逐项核验。** [codec-transport-review-inputs-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/codec-transport-review-inputs-r2.json) 文件 SHA-256 为 `0a67cd456e0777638986cef6dc098c5ea5e0cea46287bb627691ebcc42fdb50b`。7/7 文件均匹配，其中 5 个非根输入与 r1 相同；准确构成为 1 个 core manifest、4 个 Rust 源码/测试文件。

| 冻结输入 | r2 SHA-256 | 相对 r1 |
| --- | --- | --- |
| [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/Cargo.toml](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/Cargo.toml) | `a42dcfe8613ddd588b1a0da5036ba6ee4c90c73e5b1d304378176ef32c1a9e5e` | zip requirement 更新 |
| [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/Cargo.lock](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/Cargo.lock) | `297f8bd7d3353461d81631ab3733ef804270b28fc06b4d16060563f26037cb77` | zip/rand 升级及依赖边 |
| [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/Cargo.toml:17](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/Cargo.toml:17) | `fd51c21807c3cfd465337f430277ae7a07db7606e19707effae770afef8b88bc` | 不变 |
| [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs) | `f9381cf61633437cf9e722b00062c4a85009c9f66a10791acfc93160d3b0b7c4` | 不变 |
| [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document/legacy_tests.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document/legacy_tests.rs) | `d856683beb4c06d8cbaa71bfc689cdb091523e4020d5ca073129e1bb2f6b1a8e` | 不变 |
| [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs) | `ca9120d91ae81ee4ccaa75a17e44038f2d3bca5bbd9b3e01a819cc82787c60a0` | 不变 |
| [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/editor_encoding_tests.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/editor_encoding_tests.rs) | `2cb8ae13585e7596ec7939f74dcc8b7aa5733a12a77733f83f7c74a7c5ef00e3` | 不变 |

[frozen-inputs-r3.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/frozen-inputs-r3.json) 的文件自身 SHA-256 为 `a8392637a51b626c96c16561be3afeb7f557ae480faa94fe4989b476aa110678`。其 `files` 映射确为 612 项，以 `json.dumps(files, sort_keys=True, separators=(',', ':')).encode()` 计算的 SHA-256 为上述 `bab1…add3`；两种摘要没有混用。已逐项读取这 612 个文件核对字节，全部匹配，7 个范围文件也与该映射一致。对范围外条目只核验哈希，不扩大到 app 或全仓代码签署。初检、末检和冻结副本保存在本 review 目录。

末检时间为 `2026-11-15T16:18:31.007185+00:00`，即北京时间 **2026-11-16 00:18:31**。初检与末检均为 7/7 范围文件、612/612 冻结项和两组原件/稳定副本全部匹配，r2 清单及完整冻结文件自身也未变化。证据见 [verification-r2-initial.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/verification-r2-initial.json)、[verification-r2-final.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/verification-r2-final.json)；原 r1 报告 SHA 仍为 `9e49a336527f4088da90cff2beb15178112ae40bedc84cd94db5fddd775c2449`。

**依赖图与 resolver 原件。** 使用只读 `git show` 从指定基线取得原始 manifest/lock，再对最终 TOML 的完整包记录和全部依赖边进行比较，未调用 Cargo resolver。结果见 [dependency-graph-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/dependency-graph-r2.json) 和 [manifest-lock-r2.diff](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/manifest-lock-r2.diff)。

| 项目 | 实际核对结果及位置 |
| --- | --- |
| 根 manifest | 相对基线仅新增 [encoding_rs `"0.8"`](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/Cargo.toml:24) 和 [zip `"9.5"`→`"9.6"`](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/Cargo.toml:44)；前者在 r1 已审。rand 仍为 `"0.10"`，所有直接 registry requirement 的 `x.y` 策略离线重算通过。 |
| 包集合 | 基线及最终均为 **984** 个包记录；仅移除 rand 0.10.3、zip 9.5.1，增加 rand 0.10.4、zip 9.6.0。其余包的 name/version/source 没有变化。 |
| 既有包记录 | 仅 core、MCP、session、num-bigint、pageant、proptest、quinn-proto、russh 共 **8** 条记录变化：core 增加 [encoding_rs 边](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/Cargo.lock:4517)，上述 8 条记录中的 rand 引用均从 0.10.3 更新为 0.10.4；没有其他字段变化。相对 r1，core encoding 边不是新变化。 |
| 新版本原件 | [rand 0.10.4](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/Cargo.lock:6655) 和 [zip 9.6.0](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/Cargo.lock:10786) 的完整解析记录与父保留的 resolver 中间 lock 原件相同，且原始 `[[package]]` 文本块逐字节相同；不是只比较版本字符串。 |
| zip 内部依赖边 | 新 zip 原件将 nix 依赖由 `0.31.3` 指向已存在的 `0.32.0`。这是 zip 包记录内的真实变化；不把它省略成“只有版本/checksum 变了”。两个 nix 包原有版本/记录均保留，无新增或升级其他传递包版本。 |
| 保留与恢复 | resolver 中间 lock 为 **980** 个包记录；最终恢复到 984。逐项确认 **23** 个中间状态缺失或改变的既有包记录恢复为基线原记录，原始文本块也均一致。其他不涉及允许转换的既有记录完全保留。 |
| 依赖图闭合 | 最终 lock 中每条依赖边均唯一解析到一个包；缺失、歧义和意外既有记录变化均为 **0**。旧的传递 rand 0.8.8、0.9.5 仍保留；encoding_rs 0.8.44 的包记录不变。 |

父保留的 [resolver-intermediate-lock-r1.toml](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/resolver-intermediate-lock-r1.toml) SHA-256 为 `b6505875038f1969421f941aba8090dd09a51b7be4dca93a1d6c0c598867c0a8`；[dependency-lock-retention-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/dependency-lock-retention-r1.json) 为 `787e9043fdad966885218c1b0cb3ced1a51d3010f0457dcfae3bb3c2e1415053`。后者的新增、移除、8 条既有变化以及最终 lock SHA 均与独立比较相符。

恢复的 23 个原记录为 accesskit_unix 0.22.1、ashpd 0.13.13、atspi-common 0.13.0、atspi-proxies 0.13.0、naga 30.0.2、naga-types 30.0.2、notify-rust 4.19.0、oo7 0.6.0、tempfile 3.27.0、webpki-root-certs 1.0.12、wgpu-core 30.0.2、wgpu-core-deps-apple 30.0.2、wgpu-core-deps-emscripten 30.0.2、wgpu-core-deps-wasm 30.0.2、wgpu-core-deps-windows-linux-android 30.0.2、wgpu-hal 30.0.2、wgpu-naga-bridge 30.0.2、wgpu-types 30.0.2、zbus 5.19.0、zbus 6.3.0、zbus_macros 6.3.0、zbus_utils 6.1.0、zruntime 0.2.3。该枚举是在解释 lock 保留证据，不是对这些范围外功能作验收。

**官方 metadata 快照与 r4。** [dependency-report-r4.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/dependency-report-r4.json) SHA-256 为 `d71e7668d69270d21a9bf47723e883b81bf21a36503f06e8f15ad1047a2705e6`。其 37 个 `raw_public_responses` 正文摘要与 r3 完全相同，37/37 gzip 解压后的正文哈希匹配。响应采集窗口仍为 `2026-11-15T15:58:55Z` 至 `15:59:07Z`；没有冒充新的联网查询。

本轮以 `python3 -B` 加载已冻结的仓库依赖检查器，注入只读本地 metadata fetch，并安装拒绝网络操作的 audit hook，独立重新执行对当前 manifest/lock 的策略计算：**37 包、112 声明全部 passed，errors=[]，112 条完整结果与父 r4 逐条相同**。未执行 Cargo，未写 pycache，网络事件为 0。该步骤重用了仓库检查器的逻辑；lock 的基线/原件保留另由独立比较脚本核对，并非仅信任父的摘要。

| 版本 | lock checksum，与保存的官方 version 记录相同 | 快照中状态 |
| --- | --- | --- |
| zip 9.6.0 | `80cc68510ea7553c30a69c732de5278e94183f68765af6c642dbccefd6ec777e` | 非 yanked，快照最高稳定版本 |
| rand 0.10.4 | `8f6fa277c67e6ea590466f04c3fe82cb509f0864fe470643e5570de9514a9b11` | 非 yanked，快照最高稳定版本 |
| encoding_rs 0.8.44 | `89253175e704ab869b04f9db224d38630e0211a53841a79181deae0889e169f5` | 非 yanked，快照最高稳定版本 |

详细响应检查见 [dependency-metadata-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/dependency-metadata-r2.json)，本轮计算的完整 112 条结果见 [dependency-policy-r2-recomputed.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/dependency-policy-r2-recomputed.json)。最高稳定版本结论只绑定该保存快照；宿主 HTTP route/严格 GET 的获取来历属于父提供的 provenance，本轮未联网重验。

**父编译来历与新稳定副本。** 已读取 [final-test-build-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/final-test-build-r1.json) 及完整日志，日志 SHA-256 `65505e6eb8c67def282335891f905f36384e4f5391ed44f9b4553de2b404f8c1` 与 receipt 一致。父记录的命令为 `cargo test --workspace --locked --no-run --message-format=json`，结束于 `2026-11-15T16:06:31.654991+00:00`，exit 0、reaped=true，日志有 `build-finished: success=true`。core/session 测试产物的 `fresh=false` 且 executable 精确对应下列新原件；依赖 artifact 记录包含 zip 9.6.0、rand 0.10.4、encoding_rs 0.8.44。

上述信息补充了 retention receipt 当时仍写着 `PENDING Cargo --locked validation` 的后续父构建证据，不能把旧 receipt 本身改称已更新，也不能把 `--no-run` 改称全仓测试成功。复核者没有运行该 Cargo 命令；这是父编译来历的读回。详见 [parent-build-provenance-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/parent-build-provenance-r2.json)。

| 新副本 | 父原件和稳定副本 SHA-256，二者均已核验 | 完整库存 |
| --- | --- | --- |
| [core 稳定副本](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/final-review-binaries/keelshell_core-d048304bbec322b2)；[父原件](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/recovery-batch-integration-20261115/target/debug/build/keelshell-core/d048304bbec322b2/out/keelshell_core-d048304bbec322b2) | `e1c23428bdc487f79bcc816a6de19e328a892c648a1371a60c1b0381b8da0730` | 262 tests / 0 benchmarks |
| [session 稳定副本](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/final-review-binaries/keelshell_session-3d79ad765c25c763)；[父原件](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/recovery-batch-integration-20261115/target/debug/build/keelshell-session/3d79ad765c25c763/out/keelshell_session-3d79ad765c25c763) | `893441946f417dc736a92091b42601f0b18b7ece66c362d75064801d97a2284b` | 241 tests / 0 benchmarks |

先逐项验源文件及二进制 SHA，再实际执行两份稳定副本的完整 `--list`，之后才执行专项。完整库存 stdout SHA 分别为 `d86f9f0b169e392a8295cd203da145f0beb372bae6388f5c7e651a1bebed9581`、`dea317f0f4a39af02ee382280fb3d785a11ee292af06f0c6eedf5d89a5ca46a5`，与父冻结及 r1 全库存相同。63/36 个筛选名称与原源码审计集合完全一致，缺失/意外名称均为 0；不是只比较总数。两份新 `.d` 也实际列出对应生产源文件和新增测试文件，读回见 [additional-readback-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/additional-readback-r2.json)。

**本轮实际执行。** cwd 为本 review 目录，TMPDIR 为其 `tmp-r2`。两次 `--list` 上限各 30 秒；两个专项上限各 50 秒、各 4 个 libtest 工作线程。仅执行冻结授权的新稳定副本，父原件/共享 target 只读。所有 stdout/stderr 和完整名称 JSON 已保存。

| 实际二进制命令 | passed | failed | ignored | filtered | 实耗 | exit / reaped |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/final-review-binaries/keelshell_core-d048304bbec322b2 text_document:: --test-threads=4` | 63 | 0 | 0 | 199 | 14.675s / 50s | 0 / true |
| `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/final-review-binaries/keelshell_session-3d79ad765c25c763 sftp::editor_encoding_tests:: --test-threads=4` | 36 | 0 | 0 | 205 | 0.305s / 50s | 0 / true |

本轮为新依赖下 **99 个通过的执行名字**：40 个 legacy core 测试、23 个原 Unicode 测试、30 个 session 保存测试、6 个复用 fixture 自测。与 r1 重跑不叠加为 198 个独立用例；6 个 fixture 自测也不是新增产品行为覆盖。两个专项无超时、stderr 为空，预期/实际通过名称相同。详细命令、时间、哈希、全部名字和 reap 信息见 [execution-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/execution-r2.json)。

原始记录为 [core list](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/core-text-tests-r2.list.stdout)、[core run](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/core-text-tests-r2.run.stdout)、[session list](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/session-encoding-tests-r2.list.stdout)、[session run](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/session-encoding-tests-r2.run.stdout)，各自 `.stderr` 文件另存。另有一次限定 7 文件的只读 `git diff --check`，exit 0；该检查只涵盖已跟踪变更，未用它替代两个新增测试文件的既有全文审查及本轮 SHA/名称核验。

这些是**复核者独立操作执行、父预构建、非独立重新编译的结果**。源码 SHA、编译日志、dep-info 和完整库存增加了来源证据，仍不能表述为复核者从源码独立构建。

**未变源码的复核结论与断言边界。** 下列静态证据已在 r1 全文审查，本轮先校验输入完全不变，再以新依赖重跑原选集。没有重新编写实现或测试。

| 合同与触发条件 | 不变源码/测试证据及影响边界 |
| --- | --- |
| 严格解码、原字节往返、best-fit 无 encoder error 仍拒绝 | [严格 streaming decode](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:443)、[原字节比对](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:435)、[草稿 Unicode 往返校验](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:376)。[Shift_JIS](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document/legacy_tests.rs:278) 和 [GB18030](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document/legacy_tests.rs:296) 用例先证明第三方 `had_errors=false` 的 lossy 映射，再断言产品拒绝，非空壳负例。 |
| Unicode BOM/FEFF/NUL；raw、decoded、draft、normalized、encoded 独立 1 MiB；4096 行 | [BOM/NUL 路径](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:269)、[保存预算](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document.rs:369)、[精确边界测试](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document/legacy_tests.rs:357)、[4096/4097 行测试](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/text_document/legacy_tests.rs:475)。包含 UTF-8 与最终 raw 不同方向膨胀、CRLF 两种预算、BOM-less 权威 FEFF；4096 是既有 LF-delimited 保存合同，4097 行原观察仍可 clean。 |
| 旧 Unicode API 保留；输入/格式 validation 在 mutation 前 | [原 session Unicode API](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:599)、[新入口 validation](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:664)、[backup helper 前边界](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:701)。负例核对错误类型、实际 WRITE/CLOSE 计数、完整原文件和目录；旧入口仍保留 encoding-only 合同。 |
| 授权、backup/target ACK、no POSIX fallback、quarantine | [授权重验](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:729)、[原文件重验](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:794)、[POSIX publish](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:919)。既有共用 mutation 保护和本选集验证授权撤销、CLOSE hold/拒绝/丢弃、兄弟 channel 隔离、无普通 rename 回退；不靠单个本地 bool 推断远端状态。 |
| ACK 与完整目标读回的边界 | [新 API rustdoc](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:653) 明确 transport 返回 acknowledged backup path；[成功测试 helper](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/editor_encoding_tests.rs:197) 由调用者另读完整 backup/target 并核对字节、权限和临时文件。app 的读回接纳仍由父独立复核。 |

`editor_encoding_lossy_best_fit_and_unrepresentable_drafts_produce_no_candidate` 位于 [editor_encoding_tests.rs:523](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/editor_encoding_tests.rs:523)，仅调用 core `prepare_save`；它不能证明 session 能恢复调用者此前已丢失的 Unicode 草稿。byte-only API 不含该信息。选集也没有新注入 rename STATUS 丢失、rename ACK 后目标篡改或 app 读回失败场景；没有将这些未执行场景改写为已证明。

session 专项仅使用测试自行创建的 `127.0.0.1` TCP/SSH/SFTP 与内存文件系统、临时主机密钥和测试账号，没有客户机器或外部网络。它不等同真实 OpenSSH daemon、实际远端 OS 文件系统或 native 平台验收。此次 99 项没有扩大为 zip 归档全功能、全仓 tests/doctests 或各平台验收；这些依赖升级影响的其他功能仍由父最终全仓门禁覆盖。

**合并条件与剩余限制。** 本轮没有运行 Cargo、build、clean、格式化、Clippy 或完整全仓门禁，没有改写源码、Cargo 文件、共享 target 或 r1 证据，所有新增输出均写入本 review 目录。app 的 Kit Popover、保存后读回接纳及其他 UI/集成功能完全不在签署范围。

本范围可合并建议为：**范围内无阻断发现；父在同一最终冻结 `612 / bab1cc3f38f1d84e5ea5a9e2e93d8cad77fe9d06e4707e37c8bd84e54c2dadd3` 上取得完整全仓门禁成功记录后，本次 `FULL_GATE_PENDING` 条件即满足，无需仅为状态更新再发起一轮代码审查。** 父仍负责 app 集成及应有的 native 验收，不能以本报告替代。若冻结输入继续变化，仅复审实际变化及受影响证据，不能把 r2 扩展签署到后续未审输入。

**本轮完整实际通过名称。**

**core：63 个实际通过名称，按名称排序。**

```text
text_document::legacy_tests::big5_known_chinese_bytes_round_trip
text_document::legacy_tests::default_decoder_stays_unicode_only_after_legacy_support
text_document::legacy_tests::explicit_legacy_selection_does_not_prefer_valid_utf8
text_document::legacy_tests::explicit_unicode_selection_keeps_bomless_feff_readback_authority
text_document::legacy_tests::explicit_unicode_selection_keeps_utf32_and_malformed_unicode_rejected
text_document::legacy_tests::explicit_unicode_selection_matches_existing_bom_and_content_semantics
text_document::legacy_tests::explicit_unicode_selection_rejects_missing_or_wrong_encoding_boms
text_document::legacy_tests::gb18030_encoded_expansion_has_an_independent_exact_raw_limit
text_document::legacy_tests::gb18030_known_chinese_and_four_byte_scalar_round_trip
text_document::legacy_tests::gb18030_preserves_literal_leading_and_internal_feff_as_content
text_document::legacy_tests::gb18030_rejects_revision_best_fit_without_encoder_errors
text_document::legacy_tests::gbk_known_chinese_and_euro_bytes_round_trip
text_document::legacy_tests::legacy_continuing_no_break_saves_retain_the_existing_insertion_policy
text_document::legacy_tests::legacy_crlf_expansion_counts_towards_the_decoded_utf8_budget
text_document::legacy_tests::legacy_crlf_expansion_counts_towards_the_final_raw_budget
text_document::legacy_tests::legacy_decoded_utf8_expansion_has_an_independent_exact_limit
text_document::legacy_tests::legacy_empty_and_ascii_documents_keep_the_explicit_encoding
text_document::legacy_tests::legacy_encoding_names_and_classification_are_explicit
text_document::legacy_tests::legacy_errors_display_and_debug_never_include_document_contents
text_document::legacy_tests::legacy_format_compatibility_requires_the_same_encoding_and_line_policy
text_document::legacy_tests::legacy_insertion_policy_never_crosses_an_encoding_change
text_document::legacy_tests::legacy_keeps_internal_signature_bytes_as_selected_codec_content
text_document::legacy_tests::legacy_line_limit_accepts_4096_and_keeps_4097_line_observations_clean
text_document::legacy_tests::legacy_line_profiles_preserve_crlf_mixed_cr_and_final_newline_policy
text_document::legacy_tests::legacy_multibyte_decoding_rejects_malformed_and_truncated_sequences
text_document::legacy_tests::legacy_nul_is_rejected_on_read_save_readback_and_comparison
text_document::legacy_tests::legacy_raw_and_draft_limits_accept_exactly_one_mib
text_document::legacy_tests::legacy_reads_and_known_formats_reject_all_unicode_boms
text_document::legacy_tests::legacy_rejects_aliases_and_decode_only_mappings_as_edit_baselines
text_document::legacy_tests::legacy_saves_never_unicode_normalize_a_draft_to_make_it_representable
text_document::legacy_tests::legacy_saves_reject_output_that_would_introduce_a_unicode_signature
text_document::legacy_tests::legacy_streaming_preserves_multibyte_characters_across_output_buffers
text_document::legacy_tests::legacy_streaming_rejects_best_fit_and_unrepresentable_draft_tails
text_document::legacy_tests::legacy_streaming_rejects_malformed_input_after_full_output_buffers
text_document::legacy_tests::legacy_unrepresentable_drafts_never_become_numeric_character_references
text_document::legacy_tests::legacy_with_line_ending_changes_only_the_authoritative_insertion_policy
text_document::legacy_tests::shift_jis_known_japanese_and_halfwidth_bytes_round_trip
text_document::legacy_tests::shift_jis_rejects_yen_overline_and_minus_best_fit_without_encoder_errors
text_document::legacy_tests::windows1252_defined_c1_control_mappings_are_not_replacement_errors
text_document::legacy_tests::windows1252_known_accents_quotes_and_euro_round_trip
text_document::tests::text_document_all_encodings_reject_nul_on_read_save_and_comparison
text_document::tests::text_document_bomless_input_is_utf8_and_never_guessed_as_utf16
text_document::tests::text_document_continuing_no_break_observation_retains_insertion_policy
text_document::tests::text_document_encoding_names_and_utf16_known_bytes_preserve_byte_order
text_document::tests::text_document_final_raw_budget_includes_bom_and_crlf_expansion
text_document::tests::text_document_format_changes_require_a_new_observation
text_document::tests::text_document_format_compatibility_checks_encoding_bom_and_line_policy
text_document::tests::text_document_insertion_policy_does_not_cross_encoding_changes
text_document::tests::text_document_only_one_signature_is_removed_and_internal_feff_remains
text_document::tests::text_document_preserves_uniform_policy_without_double_cr_or_forced_eof
text_document::tests::text_document_rejects_binary_invalid_and_other_encoding_signatures
text_document::tests::text_document_save_line_bound_does_not_mark_an_unchanged_read_dirty
text_document::tests::text_document_unchanged_round_trip_keeps_bom_unicode_terminators_and_eof
text_document::tests::text_document_utf16_continuing_empty_and_plain_saves_retain_original_policy
text_document::tests::text_document_utf16_decoded_body_and_save_draft_have_independent_utf8_budget
text_document::tests::text_document_utf16_line_bound_keeps_unchanged_observation_clean
text_document::tests::text_document_utf16_raw_budget_includes_bom_and_newline_expansion
text_document::tests::text_document_utf16_rejects_odd_bytes_and_malformed_surrogates_without_contents
text_document::tests::text_document_utf16_round_trip_removes_only_one_bom_and_keeps_all_line_profiles
text_document::tests::text_document_utf16_saves_follow_existing_newline_policy_and_eof
text_document::tests::text_document_utf32_boms_are_rejected_before_utf16_classification
text_document::tests::text_document_utf8_never_replaces_malformed_or_partial_sequences
text_document::tests::text_format_decode_body_uses_observed_bom_and_preserves_leading_feff_content
```

**session：36 个实际通过名称，按名称排序。**

```text
sftp::editor_encoding_tests::editor_encoding_authority_revoked_during_source_check_prevents_all_mutations
sftp::editor_encoding_tests::editor_encoding_backup_close_ack_precedes_target_staging
sftp::editor_encoding_tests::editor_encoding_backup_close_failure_prevents_target_staging
sftp::editor_encoding_tests::editor_encoding_big5_preserves_exact_source_backup_and_replacement
sftp::editor_encoding_tests::editor_encoding_bomless_leading_feff_uses_exact_authority_without_reguessing
sftp::editor_encoding_tests::editor_encoding_candidate_must_equal_prepared_line_policy_bytes
sftp::editor_encoding_tests::editor_encoding_decoded_source_and_candidate_budgets_fail_before_backup
sftp::editor_encoding_tests::editor_encoding_dropped_target_close_keeps_backup_and_shared_quarantine
sftp::editor_encoding_tests::editor_encoding_expired_authority_creates_no_backup_or_temporary
sftp::editor_encoding_tests::editor_encoding_final_crlf_expansion_budget_fails_before_backup
sftp::editor_encoding_tests::editor_encoding_gb18030_preserves_four_byte_source_backup_and_replacement
sftp::editor_encoding_tests::editor_encoding_gbk_preserves_exact_source_backup_and_replacement
sftp::editor_encoding_tests::editor_encoding_invalid_candidate_is_rejected_before_backup
sftp::editor_encoding_tests::editor_encoding_invalid_source_never_falls_back_or_replaces_bytes
sftp::editor_encoding_tests::editor_encoding_legacy_authority_cannot_reinterpret_unicode_boms
sftp::editor_encoding_tests::editor_encoding_lossy_best_fit_and_unrepresentable_drafts_produce_no_candidate
sftp::editor_encoding_tests::editor_encoding_missing_posix_rename_has_no_mutations_or_fallback
sftp::editor_encoding_tests::editor_encoding_noncanonical_legacy_source_and_candidate_are_rejected
sftp::editor_encoding_tests::editor_encoding_one_mib_legacy_save_keeps_mcp_at_64_kib
sftp::editor_encoding_tests::editor_encoding_raw_source_and_candidate_budgets_fail_before_backup
sftp::editor_encoding_tests::editor_encoding_revalidates_source_after_staging_and_excludes_shared_writers
sftp::editor_encoding_tests::editor_encoding_revocation_before_publication_retains_original_and_backup
sftp::editor_encoding_tests::editor_encoding_saved_line_budget_rejects_candidate_before_backup
sftp::editor_encoding_tests::editor_encoding_shift_jis_preserves_exact_source_backup_and_replacement
sftp::editor_encoding_tests::editor_encoding_source_must_roundtrip_under_supplied_line_policy
sftp::editor_encoding_tests::editor_encoding_source_over_line_limit_can_be_replaced_at_save_line_limit
sftp::editor_encoding_tests::editor_encoding_unicode_compatibility_entrypoint_keeps_encoding_only_check
sftp::editor_encoding_tests::editor_encoding_unicode_entrypoint_rejects_legacy_sources_and_candidates
sftp::editor_encoding_tests::editor_encoding_windows1252_preserves_exact_source_backup_and_replacement
sftp::editor_encoding_tests::editor_encoding_wrong_source_encoding_is_typed_and_mutation_free
sftp::editor_encoding_tests::sftp_fixture::canonical_path_gate_tests::exact_path_hold_survives_clones_and_releases_on_owner_drop
sftp::editor_encoding_tests::sftp_fixture::canonical_path_gate_tests::expired_reply_stays_owned_until_drop_and_cannot_rearm_silently
sftp::editor_encoding_tests::sftp_fixture::canonical_path_gate_tests::release_before_poll_and_old_handler_do_not_consume_new_hold
sftp::editor_encoding_tests::sftp_fixture::transfer_write_gate_tests::a_missing_release_expires_as_failure_instead_of_admitting_a_write
sftp::editor_encoding_tests::sftp_fixture::transfer_write_gate_tests::first_write_unrelated_targets_and_release_before_poll_are_never_held
sftp::editor_encoding_tests::sftp_fixture::transfer_write_gate_tests::guard_unwind_releases_an_entered_write_and_rearming_does_not_retrap_it
```
