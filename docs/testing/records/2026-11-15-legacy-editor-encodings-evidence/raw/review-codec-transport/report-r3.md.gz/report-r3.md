**独立只读窄差分复核 r3：APPROVE_SCOPED_DELTA。开放发现 P0=0、P1=0、P2=0、P3=0。** 本报告只签署工程冻结 r3→r4 的服务器归档 helper 与其嵌入 Python 测试两文件变化，并核对原签署输入的字节连续性。原 `FULL_GATE_PENDING` 工程条件已由父在同一 r4 冻结上取得成功门禁满足；本轮仅只读核验该回执和日志，没有增加执行或扩大代码签署范围。签署时间：2026-11-16T00:46:26+08:00。

**身份、范围与冻结。** 本复核为非作者独立复核，工程基线为 `2cfe0deb732db78f43a9b76d9e2c7e5c214a1f24`，主树为 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`。先前 codec/session 与依赖差分继续由 [原 report-r2](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/report-r2.md) 承载；其原 r1、r2 以及 Carson r1 报告均保持原字节及原签署条件，不回填到新冻结。app、Kit Popover、codec 和 session 保存代码没有重新审查或执行。

已读取 RTK、AGENTS、HANDOFF、SHARED_TARGET、ADR 0140、ADR 0135 及适用 `rust-best-practices`、`rust-engineer` 技能与测试/注释参考；用户的严格只读授权优先于技能中的一般 Cargo 验证步骤。仅将报告、冻结摘录、原件副本和独立运行输出写入本 review 目录；没有修改、格式化源码/Cargo 文件，没有运行 Cargo/build/clean/Clippy，没有 commit/push、共享 target 写入或资源清理，也没有联网或访问客户机器。

| 冻结 | 项数 | 集合 SHA-256 | JSON 文件 SHA-256 |
| --- | ---: | --- | --- |
| [frozen-inputs-r3.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/frozen-inputs-r3.json) | 612 | `bab1cc3f38f1d84e5ea5a9e2e93d8cad77fe9d06e4707e37c8bd84e54c2dadd3` | `a8392637a51b626c96c16561be3afeb7f557ae480faa94fe4989b476aa110678` |
| [frozen-inputs-r4.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/frozen-inputs-r4.json) | 612 | `e8029ecb7eea9a28e76d4c47f8d4d280afa57de4356049f2d83ab39020749ce6` | `d65339f28b35031d884669c3102d86e87aeacc59d99c6393f9d41d0e49106c58` |

集合摘要按 `sha256(json.dumps(files, sort_keys=True, separators=(',', ':')).encode())` 独立重算匹配。按父冻结规则独立枚举工程路径：根 Cargo.toml/Cargo.lock、crates 下递归 Rust/Python/Cargo.toml、scripts 顶层 Python、.cargo 下递归 TOML；实际 612 项，没有缺项或额外项。初次与最终核验均为 612/612 匹配。两文件旧字节已从基线只读 `git show` 恢复并与 r3 SHA 对齐；新字节与 r4、当前文件及保存副本一致。完整差分见 [archive-anchor-r3.diff](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/archive-anchor-r3.diff)。

| 唯一变化文件与当前位置 | r3 SHA-256 | r4 SHA-256 |
| --- | --- | --- |
| [crates/keelshell-core/src/server_archive.py](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/server_archive.py:288) | `c38955fe645d7ab26af8a5538d63911af87dda24db0af125e361eb49976f3df2` | `302bfee709d5d9f6c6ceeba3cbfdd7954f0343a7b98012b8f2546dc6bdd57500` |
| [crates/keelshell-core/tests/server_archive.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/tests/server_archive.rs:582) | `4441aa67e701035bf3a8c3454d75dedc6af22bca613b6a151a02b9e55611cb5b` | `8a052fe74e64f99e23daf9263b9a11b69a73da9b8ba30bf4b6bea7bb0a654ca6` |

其余 **610 项逐项满足 r3 = r4 = 当前字节**。原 codec/session r2 范围 **7/7**、Carson r1 源码/测试范围 **11/11** 均属于该不变集合，与各自原签署 SHA 一致。这里签署的是字节连续性，没有将本轮扩展为 app 功能复核。逐项证据见 [unchanged-inputs-r3.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/unchanged-inputs-r3.json)、[verification-r3-initial.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/verification-r3-initial.json)、[verification-r3-final.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/verification-r3-final.json)。原 r1、r2 与 Carson 报告的 SHA 再次读回一致。

**根因及修复语义。** 已读回并保存父诊断的六轮日志、回执和九份 trace；第六轮为 37 passed / 3 failed。三个 line 284 trace 的 dev/ino/mode/uid/gid/flags 全部相同，只有 nlink 7↔6、size 224↔192、mtime/ctime 变化，与真实共享 TMPDIR 中并发创建/删除旁支一致。旧完整 `current == before` 将无关目录活动当作权限失效，导致归档被拒绝、无成功回执并保留隔离状态。诊断 shim 是定位原件，不能当作生产通过结果。见 [parent-evidence-r3.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/parent-evidence-r3.json) 和 [诊断原始回执副本](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/r3-parent-evidence/archive-diagnostic-r1/result.json)。

唯一生产变化在 [server_archive.py:288](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/server_archive.py:288)，改为既有 `identity(current) == identity(before)` 并说明原因。[identity:244](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/server_archive.py:244) 精确比较 **dev、ino、mode、uid、gid、flags**，没有放宽 inode、文件类型、权限位或归属字段检查；[nofollow_flags:248](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/server_archive.py:248) 的 `O_NOFOLLOW/O_DIRECTORY/O_CLOEXEC/O_NONBLOCK`、逐级 dir_fd、持有全部祖先 fd、最终逐路径 identity 复核及 finally 关闭 fd 保持。新比较与本来就使用 identity 的 [最终祖先复核:293](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/server_archive.py:293) 一致，允许无关旁支引起的大小/链接数/时间变化，不允许替换后继续获得 authority。

所选树的校验没有改动：[opened:254](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/server_archive.py:254) 在打开后、yield 后及名称复核时仍比较完整 snapshot；[Inventory.visit:355](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/server_archive.py:355) 保留成员完整 stat 与 SHA；[scan:398](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/server_archive.py:398) 保留一次扫描前后父目录完整 stat 相等及精确 expected members。[pack:634](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/server_archive.py:634) 在创建 stage 前仍要求完整扫描等于审核 expected，后续流式扫描和发布前复扫继续核对成员，[发布前重开完整祖先链:669](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/server_archive.py:669) 保持。归档自身创建 stage/发布会改变父目录时间和链接数，后期父目录 identity 比较是原有行为；本报告不声称它在自身写入后仍与最初完整 root stat 逐字段相同。

**ACL 边界。** identity 是上述六个 stat 字段，**不是 ACL 摘要；本修复不新增祖先 ACL 快照相等保证**。不以 ctime 被移出比较来宣称能探测所有祖先 ACL 修改。[ADR 0135:53](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/adr/0135-reviewed-server-archive-packing.md:53) 已明确该合同；这份文档作为语义上下文读取，不计入两文件工程 delta 签署。[private_acl:71](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/server_archive.py:71)、[own_directory:578](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/server_archive.py:578)、[readback:597](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/server_archive.py:597) 以及 [stage 内容写入前清 ACL:638](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/server_archive.py:638)、[payload 内容写入前清 ACL:645](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/src/server_archive.py:645) 的清除和重复验证保持。所选对象完整 stat 与新建私有 stage/payload ACL 合同继续分别成立。uid/gid/flags 的比较在本轮静态核对；新 race 用例没有分别实际更改每个字段，也没有据此扩展平台权限模型保证。

**测试是否证明其断言。** [python-suite-audit-r3.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/python-suite-audit-r3.json) 证实既有 25 个 Python 测试方法没有改写，只增加 `mock` import、`anchor_race` 和六个测试；Rust 文件 raw Python suite 以外的字节完全一致。生产 Python AST 仅 `anchored_parent` 变化。[anchor_race:582](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/tests/server_archive.rs:582) 只替换 `os.open` 的调度点，使用真实 stat/fstat、mkdir/rmdir、fchmod、rename 和 symlink；没有伪造通过所需的 stat。正例显式证明完整 stat 确实改变而 identity 相同，反例在 authority yield 前拒绝；symlink 反例允许实际 OSError 或 Rejected，均不得进入 body。

| 六个新增实际执行名称及绝对路径行号 | 断言对应的真实行为 |
| --- | --- |
| [test_ancestor_open_accepts_unrelated_child_creation](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/tests/server_archive.rs:632) | 真实 mkdir 改变目录完整 stat；identity 相同，context 正常退出。 |
| [test_ancestor_open_accepts_unrelated_child_removal](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/tests/server_archive.rs:635) | 真实 rmdir 改变目录完整 stat；identity 相同，context 正常退出。 |
| [test_ancestor_open_rejects_permission_change](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/tests/server_archive.rs:638) | 真实 fchmod 改变 mode；在 yield authority 前拒绝。 |
| [test_ancestor_open_rejects_directory_replacement](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/tests/server_archive.rs:641) | 真实 rename 后新建同名目录，inode 不同；在 yield 前拒绝。 |
| [test_ancestor_open_rejects_symlink_replacement](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/tests/server_archive.rs:644) | 真实 rename 后建立同名 symlink；no-follow 打开拒绝，未 yield。 |
| [test_selected_directory_keeps_full_snapshot_validation](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-core/tests/server_archive.rs:647) | 进入 opened() 后向所选目录创建真实成员；退出时完整 snapshot 检查拒绝。 |

第六项直接证明 `opened()` 的退出完整快照仍生效，不将其单项覆盖扩大为所有 scan 调用路径；既有 `test_source_inventory_add_remove_and_replacement_drift`、`test_source_content_drift_even_at_same_size_and_restored_mtime`、`test_inventory_and_digest_rechecked_while_streaming_and_before_publication` 在同次 suite 中实际通过，补充所选成员/摘要路径证据。没有开放 P0/P1/P2/P3 发现，不附无事实依据的预防性缺陷。

**本复核者实际独立执行。** 从 r4 Rust raw string 原样抽取 suite，SHA-256 为 `75383a6da233d4440cbfca5161762d7a54a6167459f55f7ccbc72f5b596fea73`；以同一 suite 分别执行保存的 r3 helper 与 r4 helper。外层实际命令为 `python3 -B /Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/r3-run-python-suite.py`；子命令为 `/opt/homebrew/opt/python@3.15/bin/python3.15 -B /Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/r3-python-suite.py <verbatim helper text>`。helper 参数是相应保存文件的原样完整文本，具体来源、摘要与参数占位说明见 [python-execution-r3.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/python-execution-r3.json)；可复现驱动见 [r3-run-python-suite.py](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/r3-run-python-suite.py)。

宿主为 Darwin、Python 3.15.2。两例分别使用 review 目录内独立 TMPDIR，外层各 60 秒有界，suite 内 helper 子进程 10 秒有界，父子均禁用 bytecode；两例实际均已 reap、没有超时。这是独立 **Python 源码执行**，没有 Rust 编译或 Rust 测试二进制执行，也不构成 Linux、Windows、Python 3.8 或完整原生验收。

| 本复核者执行 | 实际 run | passed | errors | failures | skipped | exit / reap | 外层耗时 |
| --- | ---: | ---: | ---: | ---: | ---: | --- | --- |
| r3 旧 helper + r4 新 suite，预期红对照 | 31 | 28 | 2 | 0 | 1 | 1 / true | 5.750s |
| r4 新 helper + 同一 suite | 31 | 30 | 0 | 0 | 1 | 0 / true | 5.750s |

红对照的两个 ERROR **仅为** `test_ancestor_open_accepts_unrelated_child_creation` 和 `test_ancestor_open_accepts_unrelated_child_removal`，均在旧 helper `anchored_parent:284` 被拒绝；另外四项新增安全测试旧/新均通过，新 helper 六项全通过。三项真实 Darwin ACL 测试在两例均通过。唯一 skip 是 `test_non_utf8_directory_entry_rejected`，原因是 `host filesystem itself rejects non-UTF8 names`；不计作通过。两次都逐名对齐抽取的 31 项库存。红/绿对照和父相同 suite 均不叠加为独立覆盖数量。

原始输出：[红对照 stderr](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/python-before-r3.stderr)、[修后 stderr](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/python-after-r3.stderr)；对应 stdout 为空并各自保留。stderr SHA-256 分别为 `7f765375c404b4a932769062f48ab0ae60f7dc35194c14c7ded272bf04d84e50`、`ce20faac943913e4d709f64c7599cbaee661dd3fbf70e75365f2421b75e94cc7`。最终核验再次匹配原始输出、suite 与 helper 摘要。

**父原件核验，单列于独立执行。** 已复制并逐份核对 24 份父红/绿、归档回归和诊断原件；来源、摘要及副本相等性见 [parent-evidence-r3.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/parent-evidence-r3.json)。父 `archive-anchor-red-r1` 为 exit1/reaped、31 run / 2 errors / 1 skip；`archive-anchor-green-r1` 为 exit0/reaped、31 run / 1 skip。[父 archive-regression-r1 原始日志副本](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/r3-parent-evidence/archive-regression-r1.log) 为 exit0/reaped：**core Rust server_archive 14/14，session Rust server_archive 40/40**。嵌套 Python 为 31 run / 1 skip，单列且包含于 core 的一个 wrapper 内，不能改写为 core27，也不能把嵌套 Python 加到 Rust 计数。这些父 Rust 执行不是本复核者的独立重编译或独立 Rust 执行。

**门禁条件的最新事实。** 最初本轮范围保持 `FULL_GATE_PENDING`。收口前父交付新的成功回执后，仅执行只读核对：[父 full-gate-r2 回执副本](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/r3-parent-evidence/full-gate-r2.json) 为 `exit 0 / reaped / 696.329s`，启动 `2026-11-15T16:30:20.513458Z`、结束 `2026-11-15T16:41:56.845847Z`；[父完整日志副本](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/r3-parent-evidence/full-gate-r2.log) SHA-256 为 `a981cce0db30e29e13dc363a06c6047cc86a21346d7607edcaa3c72ebf19b89e`，与父回执完全匹配。逐行聚合 Rust 结果得到普通 **3077 passed / 0 failed / 37 ignored**、rustdoc **14 passed / 0 failed**；父报告工程 Python **187 run / 1 skip**，fmt、strict Clippy、policy、三组 controllers 通过。

首次 612 项哈希核验时间为 `2026-11-15T16:29:58.001437Z`，先于 gate 启动；收口时 612 项仍全部匹配 r4，父确认 gate 使用同一冻结。回执、日志副本、Rust 逐结果行及前后冻结绑定见 [parent-full-gate-r3.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/parent-full-gate-r3.json)、[verification-r3-final.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/legacy-editor-batch-20261115/review-codec-transport/verification-r3-final.json)。因此原 `FULL_GATE_PENDING` 工程条件已由父同冻结成功门禁满足；本报告不将父执行表述为 reviewer 重跑全仓门禁。原 `full-gate-r1` 的 exit1/reaped、归档 39/1 失败继续保持历史失败，诊断第六轮 37/3 与成功 r2 分别保留。

**限定合并建议与限制。** 两文件 delta 范围内可以合并；父可组合原 codec/session r2 报告、Carson r1 报告、610 项不变证据、本 r3 delta 批准，以及同一 r4 的成功 full-gate-r2。无需仅为该门禁状态另起一轮审查或重复执行。旧 r2 生产与依赖输入 7/7 未变，其父预构建稳定副本 63+36 项独立执行仍保留“非独立重编译”的原限制；本轮没有重新执行这 99 项。

app 集成、随后进行的 openssh-r2 与正常程序构建、三平台 native 桌面、发行安装及完整产品验收不在本报告签署范围。Python 非 UTF-8 文件名场景保持 skip，其他平台 ACL/旧解释器及恶意同用户全文件系统锁保证未取得；本次身份检查没有添加祖先 ACL 快照保证。若后续工程输入发生变化，仅对实际 delta 和受影响证据复审，不能把本签署扩展到未审输入。

**31 项实际执行的完整逐名结果。** 两列来自独立执行原始 stderr，不以父摘要代替。ERROR 为旧 helper 的预期红对照，修后该两项为 ok。

| 实际 Python 测试名称 | 旧 helper | r4 helper |
| --- | --- | --- |
| `test_ancestor_open_accepts_unrelated_child_creation` | ERROR | ok |
| `test_ancestor_open_accepts_unrelated_child_removal` | ERROR | ok |
| `test_ancestor_open_rejects_directory_replacement` | ok | ok |
| `test_ancestor_open_rejects_permission_change` | ok | ok |
| `test_ancestor_open_rejects_symlink_replacement` | ok | ok |
| `test_darwin_acl_added_during_packing_blocks_receipt_and_keeps_unknown_objects` | ok | ok |
| `test_darwin_acl_set_or_inspection_failure_retains_empty_stage_and_no_archive` | ok | ok |
| `test_darwin_inherited_acl_is_removed_before_source_bytes_and_publication` | ok | ok |
| `test_empty_directory_as_only_source` | ok | ok |
| `test_encoded_limit_is_checked_during_writes_and_retains_only_private_stage` | ok | ok |
| `test_existing_final_and_stage_are_preserved` | ok | ok |
| `test_full_member_name_and_selected_path_budgets` | ok | ok |
| `test_hardlinks_and_special_files_rejected` | ok | ok |
| `test_inspect_has_no_writes_and_import_has_no_execution` | ok | ok |
| `test_inventory_and_digest_rechecked_while_streaming_and_before_publication` | ok | ok |
| `test_malicious_stdin_schema_binding_digests_and_path_attacks` | ok | ok |
| `test_member_aliases_and_nonportable_names` | ok | ok |
| `test_member_depth_count_and_expanded_budgets` | ok | ok |
| `test_missing_capabilities_and_unknown_modes_fail_closed` | ok | ok |
| `test_multiple_sources_and_empty_regular_file` | ok | ok |
| `test_non_utf8_directory_entry_rejected` | skipped 'host filesystem itself rejects non-UTF8 names' | skipped 'host filesystem itself rejects non-UTF8 names' |
| `test_publication_race_preserves_winner_and_no_success_receipt` | ok | ok |
| `test_readback_corruption_and_unknown_stage_objects_block_receipt_and_cleanup` | ok | ok |
| `test_request_path_attacks_aliases_parent_and_suffix` | ok | ok |
| `test_response_budget_rejects_instead_of_truncating_manifest` | ok | ok |
| `test_selected_directory_keeps_full_snapshot_validation` | ok | ok |
| `test_source_content_drift_even_at_same_size_and_restored_mtime` | ok | ok |
| `test_source_inventory_add_remove_and_replacement_drift` | ok | ok |
| `test_stage_path_attacks_fail_before_creation` | ok | ok |
| `test_symlink_member_root_and_ancestor_rejected` | ok | ok |
| `test_zip_and_gnu_tar_pack_binary_unicode_quotes_and_empty_directories` | ok | ok |
