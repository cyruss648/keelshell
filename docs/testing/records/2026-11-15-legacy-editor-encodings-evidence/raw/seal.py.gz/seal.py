"""Export completed batch originals losslessly; omit only regenerable test copies."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SOURCE = Path(__file__).resolve().parent
DEST = ROOT / 'docs/testing/records/2026-11-15-legacy-editor-encodings-evidence'
summary = json.loads((SOURCE / 'final-gate-summary-r1.json').read_text())
assert summary['status'] == 'AUTHOR_GATE_PASS' and summary['source_path_and_hash_drift'] == 0
for report in ['review-codec-transport/report-r2.md', 'review-codec-transport/report-r3.md', 'review-app/report-r1.md']:
    assert (SOURCE / report).is_file(), report
assert not DEST.exists(), 'Use a new destination rather than overwriting evidence'
DEST.mkdir()
manifest = {'schema':1,'original_directory':str(SOURCE.relative_to(ROOT)),'exported_utc':datetime.now(timezone.utc).isoformat(),'count':0,'files':{}}
omitted = {'files':[], 'total_bytes':0}
for path in sorted(SOURCE.rglob('*')):
    if not path.is_file():
        continue
    assert not path.is_symlink(), str(path)
    relative = path.relative_to(SOURCE).as_posix()
    data = path.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    if relative.split('/')[0] in ('review-binaries','final-review-binaries'):
        omitted['files'].append({'path':relative,'bytes':len(data),'sha256':digest,'reason':'Regenerable parent-built test copy; exact source binding, inventory and execution originals retained'})
        omitted['total_bytes'] += len(data)
        continue
    compress = path.suffix != '.gz' and (len(data) >= 2048 or relative.startswith('frozen-inputs-'))
    artifact = 'raw/' + relative + ('.gz' if compress else '')
    payload = gzip.compress(data, mtime=0) if compress else data
    target = DEST / artifact
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(payload)
    restored = gzip.decompress(payload) if compress else payload
    assert restored == data
    manifest['files'][relative] = {'artifact':artifact,'source_bytes':len(data),'source_sha256':digest,'artifact_bytes':len(payload),'artifact_sha256':hashlib.sha256(payload).hexdigest()}
manifest['count'] = len(manifest['files'])
(DEST / 'archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(DEST / 'omitted-artifacts.json').write_text(json.dumps(omitted,indent=2)+'\n')
assert len(omitted['files']) == 6
print(json.dumps({'originals':manifest['count'],'omitted_regenerable_copies':len(omitted['files']),'omitted_bytes':omitted['total_bytes'],'lossless_bytes_verified':sum(v['source_bytes'] for v in manifest['files'].values())}))
