"""Summarize only a completed gate and verify exact final source and new test names."""
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
receipt = json.loads((OUT / 'full-gate-r1.json').read_text())
assert receipt['reaped'] and receipt['exit_code'] == 0 and not receipt['timeout_or_interrupt']
log = (OUT / 'full-gate-r1.log').read_text()
assert hashlib.sha256(log.encode()).hexdigest() == receipt['log_sha256']
freeze = json.loads((OUT / 'frozen-inputs-r3.json').read_text())
paths = [ROOT / 'Cargo.toml', ROOT / 'Cargo.lock']
paths += list((ROOT / 'crates').rglob('*.rs')) + list((ROOT / 'crates').rglob('*.py')) + list((ROOT / 'crates').rglob('Cargo.toml'))
paths += list((ROOT / 'scripts').glob('*.py'))
if (ROOT / '.cargo').exists():
    paths += list((ROOT / '.cargo').rglob('*.toml'))
files = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(set(paths))}
assert files == freeze['files']
actual_sha = hashlib.sha256(json.dumps(files, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
assert actual_sha == freeze['sha256']
review = json.loads((OUT / 'final-review-inputs-r1.json').read_text())
new = [n for label, names in review['expected_new_names'].items() if label != 'openssh' for n in names]
assert len(new) == 84 and len(set(new)) == 84
assert all(re.search(r'^test ' + re.escape(n) + r' \.\.\. ok$', log, re.M) for n in new)
section = 'engineering'
kind = 'ordinary'
totals = {'ordinary': {'passed': 0, 'failed': 0, 'ignored': 0}, 'rustdoc': {'passed': 0, 'failed': 0, 'ignored': 0}}
for line in log.splitlines():
    if line.startswith('Running: cargo test --workspace '):
        section = 'workspace'
    elif line.startswith('Running:') and section == 'workspace':
        section = 'controllers'
    if section != 'workspace':
        continue
    if 'Doc-tests ' in line:
        kind = 'rustdoc'
    m = re.match(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', line)
    if m:
        for key, value in zip(('passed', 'failed', 'ignored'), m.groups()):
            totals[kind][key] += int(value)
assert totals['ordinary']['failed'] == 0 and totals['rustdoc']['failed'] == 0
p = re.search(r'Ran (\d+) tests in ', log)
assert p and 'OK (skipped=1)' in log
interop = json.loads((OUT / 'openssh-r1/result.json').read_text())
assert interop['outcome'] == 'passed' and interop['passed_tests'] == 17
openssh_log = (OUT / 'openssh-r1/tests.log').read_text()
assert all(re.search(r'^test ' + re.escape(n) + r' \.\.\. ok$', openssh_log, re.M) for n in review['expected_new_names']['openssh'])
report = {'status':'AUTHOR_GATE_PASS','freeze_count':len(files),'freeze_sha256':actual_sha,'source_path_and_hash_drift':0,'gate_exit_code':receipt['exit_code'],'gate_reaped':receipt['reaped'],'elapsed_seconds':receipt['elapsed_seconds'],'rust':totals,'python':{'run':int(p[1]),'skipped':1,'passed':int(p[1])-1},'new_default_names_passed':new,'new_default_count':len(new),'reused_fixture_tests_added_to_an_additional_target':6,'openssh_passed':interop['passed_tests'],'openssh_new_opt_in_names':review['expected_new_names']['openssh'],'native_desktop':'NOT_RUN','full_product':'ACTIVE','log_sha256':receipt['log_sha256']}
assert not (OUT / 'final-gate-summary-r1.json').exists()
(OUT / 'final-gate-summary-r1.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('new_default_names_passed','openssh_new_opt_in_names')}))
