"""Sign only reaped successful final commands and exact named test/source bindings."""
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent


def command(label):
    receipt = json.loads((OUT / f"{label}.json").read_text())
    assert receipt["reaped"] and receipt["exit_code"] == 0
    assert not receipt["timeout_or_interrupt"]
    data = (OUT / f"{label}.log").read_bytes()
    assert hashlib.sha256(data).hexdigest() == receipt["log_sha256"]
    return receipt, data.decode()


receipt, log = command("full-gate-r2")
freeze = json.loads((OUT / "frozen-inputs-r4.json").read_text())
paths = [ROOT / "Cargo.toml", ROOT / "Cargo.lock"]
paths += list((ROOT / "crates").rglob("*.rs"))
paths += list((ROOT / "crates").rglob("*.py"))
paths += list((ROOT / "crates").rglob("Cargo.toml"))
paths += list((ROOT / "scripts").glob("*.py"))
if (ROOT / ".cargo").exists():
    paths += list((ROOT / ".cargo").rglob("*.toml"))
files = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
         for p in sorted(set(paths))}
assert files == freeze["files"]
actual_sha = hashlib.sha256(
    json.dumps(files, sort_keys=True, separators=(",", ":")).encode()
).hexdigest()
assert actual_sha == freeze["sha256"]
review = json.loads((OUT / "final-review-inputs-r2.json").read_text())
assert review["freeze_sha256"] == actual_sha
new = [name for label, names in review["expected_new_names"].items()
       if label != "openssh" for name in names]
assert len(new) == 84 and len(set(new)) == 84
assert all(re.search(r"^test " + re.escape(name) + r" \.\.\. ok$", log, re.M)
           for name in new)
section, kind = "engineering", "ordinary"
totals = {kind: {"passed": 0, "failed": 0, "ignored": 0}
          for kind in ("ordinary", "rustdoc")}
controllers = []
for line in log.splitlines():
    if line.startswith("Running: cargo test --workspace "):
        section = "workspace"
    elif line.startswith("Running:") and section == "workspace":
        section = "controllers"
    if section == "controllers" and line.startswith("Running:"):
        controllers.append(line)
    if section != "workspace":
        continue
    if "Doc-tests " in line:
        kind = "rustdoc"
    match = re.match(r"test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;", line)
    if match:
        for key, value in zip(("passed", "failed", "ignored"), match.groups()):
            totals[kind][key] += int(value)
assert totals["ordinary"]["failed"] == 0 and totals["rustdoc"]["failed"] == 0
assert len(controllers) == 3
python = re.search(r"Ran (\d+) tests in ", log)
assert python and "OK (skipped=1)" in log
command("openssh-r2")
interop = json.loads((OUT / "openssh-r2/result.json").read_text())
assert interop["outcome"] == "passed" and interop["passed_tests"] == 17
openssh_log = (OUT / "openssh-r2/tests.log").read_text()
assert all(re.search(r"^test " + re.escape(name) + r" \.\.\. ok$", openssh_log, re.M)
           for name in review["expected_new_names"]["openssh"])
helper_receipt, helper_log = command("archive-anchor-green-r1")
assert "Ran 31 tests in " in helper_log and "OK (skipped=1)" in helper_log
normal, _ = command("normal-build-r1")
report = {
    "status": "AUTHOR_GATE_PASS", "freeze_file": "frozen-inputs-r4.json",
    "freeze_count": len(files), "freeze_sha256": actual_sha,
    "source_path_and_hash_drift": 0, "gate_label": "full-gate-r2",
    "gate_exit_code": receipt["exit_code"], "gate_reaped": receipt["reaped"],
    "elapsed_seconds": receipt["elapsed_seconds"], "rust": totals,
    "python": {"run": int(python[1]), "skipped": 1, "passed": int(python[1]) - 1},
    "helper_python": {"run": 31, "skipped": 1, "passed": 30, "new": 6},
    "new_default_names_passed": new, "new_default_count": len(new),
    "reused_fixture_tests_added_to_an_additional_target": 6,
    "controller_commands": controllers, "openssh_passed": interop["passed_tests"],
    "openssh_new_opt_in_names": review["expected_new_names"]["openssh"],
    "normal_build_exit": normal["exit_code"],
    "native_desktop": "NOT_RUN", "full_product": "ACTIVE",
    "log_sha256": receipt["log_sha256"],
}
path = OUT / "final-gate-summary-r1.json"
assert not path.exists()
path.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({key: value for key, value in report.items()
                  if key not in ("new_default_names_passed", "openssh_new_opt_in_names",
                                 "controller_commands")}))
