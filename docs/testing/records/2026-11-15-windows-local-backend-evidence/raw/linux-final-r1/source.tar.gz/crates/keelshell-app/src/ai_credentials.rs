//! AI keys share the authenticated vault, with an encrypted destination binding.

use std::{
    path::PathBuf,
    sync::atomic::{AtomicBool, Ordering},
};

use keelshell_core::{
    AiApiStyle, AiAuthentication, AiBackend, AiSecretRef, CredentialKind, Error, NamedAiProfile,
    VaultStore,
};
use serde::{Deserialize, Serialize};
use uuid::Uuid;
use zeroize::{Zeroize, Zeroizing};

#[derive(Clone, Copy, PartialEq, Eq)]
pub(crate) enum VaultAction {
    Save,
    Unlock,
}

pub(crate) enum Completion {
    Saved(Uuid),
    Unlocked(Zeroizing<String>),
    RequestUnlocked(crate::ai_request_options::RequestSecret),
    Cancelled,
}

pub(crate) fn uses_api_key_authentication(authentication: &AiAuthentication) -> bool {
    match authentication {
        AiAuthentication::Bearer { .. } => true,
        AiAuthentication::Header { name, .. } => name.eq_ignore_ascii_case("x-api-key"),
        AiAuthentication::None => false,
    }
}

fn authentication_binding(authentication: &AiAuthentication) -> Option<&'static str> {
    match authentication {
        AiAuthentication::Bearer { .. } => Some("bearer"),
        AiAuthentication::Header { name, .. } if name.eq_ignore_ascii_case("x-api-key") => {
            Some("header:x-api-key")
        }
        AiAuthentication::None | AiAuthentication::Header { .. } => None,
    }
}

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct BoundKey {
    version: u32,
    profile_id: Uuid,
    endpoint: String,
    api_style: AiApiStyle,
    authentication: String,
    #[serde(default)]
    backend: Option<AiBackend>,
    key: String,
}

impl Drop for BoundKey {
    fn drop(&mut self) {
        self.key.zeroize();
    }
}

pub(crate) fn reference(profile: &NamedAiProfile) -> Option<Uuid> {
    match &profile.authentication {
        authentication if uses_api_key_authentication(authentication) => match authentication {
            AiAuthentication::Bearer {
                credential: Some(AiSecretRef::SecretStore { id }),
            }
            | AiAuthentication::Header {
                credential: Some(AiSecretRef::SecretStore { id }),
                ..
            } => Some(*id),
            _ => None,
        },
        _ => None,
    }
}

fn encode(profile: &NamedAiProfile, key: Zeroizing<String>) -> Result<Zeroizing<String>, Error> {
    let payload = BoundKey {
        version: 2,
        profile_id: profile.id,
        endpoint: profile.endpoint.clone(),
        api_style: profile.api_style,
        authentication: authentication_binding(&profile.authentication)
            .ok_or(Error::VaultEntryMismatch)?
            .into(),
        backend: Some(profile.backend.clone()),
        key: key.to_string(),
    };
    serde_json::to_string(&payload)
        .map(Zeroizing::new)
        .map_err(|_| Error::VaultCorrupt)
}

fn decode(
    profile: &NamedAiProfile,
    payload: Zeroizing<String>,
) -> Result<Zeroizing<String>, Error> {
    let mut payload: BoundKey = serde_json::from_str(&payload).map_err(|_| Error::VaultCorrupt)?;
    // Existing v1 ciphertext remains usable only by its original HTTP adapter.
    // V2 additionally binds the exact CLI type/path; metadata edits cannot make
    // the vault silently deliver an old API key to another executable. Limits
    // cannot redirect a key and are excluded from this identity comparison.
    let backend_matches = match payload.version {
        1 => payload.backend.is_none() && profile.backend == AiBackend::Api,
        2 => payload
            .backend
            .as_ref()
            .is_some_and(|backend| backend.same_credential_destination(&profile.backend)),
        _ => false,
    };
    if !backend_matches
        || payload.profile_id != profile.id
        || payload.endpoint != profile.endpoint
        || payload.api_style != profile.api_style
        || authentication_binding(&profile.authentication) != Some(payload.authentication.as_str())
    {
        return Err(Error::VaultEntryMismatch);
    }
    if payload.key.is_empty() || payload.key.contains('\0') {
        return Err(Error::VaultInvalidSecret);
    }
    Ok(Zeroizing::new(std::mem::take(&mut payload.key)))
}

/// Run only on a background executor. No profile metadata or network is written.
pub(crate) fn operate(
    path: PathBuf,
    profile: &NamedAiProfile,
    action: VaultAction,
    master: Zeroizing<String>,
    key: Zeroizing<String>,
    cancelled: &AtomicBool,
) -> Result<Completion, Error> {
    match profile.backend {
        AiBackend::Api => profile.validate_current_transport()?,
        AiBackend::LocalAgent { .. } => profile.validate_local_agent_transport()?,
    }
    if !uses_api_key_authentication(&profile.authentication) {
        return Err(Error::VaultEntryMismatch);
    }
    if action == VaultAction::Save && (key.is_empty() || key.contains('\0')) {
        return Err(Error::VaultInvalidSecret);
    }
    if cancelled.load(Ordering::Acquire) {
        return Ok(Completion::Cancelled);
    }
    let store = VaultStore::new(path);
    let mut vault = store.load(&master)?;
    drop(master);
    if cancelled.load(Ordering::Acquire) {
        return Ok(Completion::Cancelled);
    }
    match action {
        VaultAction::Save => {
            // A draft can be cancelled after this write. Its orphaned ciphertext
            // is safe to clean later; an existing reference is never overwritten.
            let id = Uuid::new_v4();
            let payload = encode(profile, key)?;
            vault.set(id, profile.id, CredentialKind::AiApiKey, &payload)?;
            if cancelled.load(Ordering::Acquire) {
                return Ok(Completion::Cancelled);
            }
            store.save(&mut vault)?;
            Ok(Completion::Saved(id))
        }
        VaultAction::Unlock => {
            let id = reference(profile).ok_or(Error::VaultEntryNotFound)?;
            decode(
                profile,
                vault.get(id, profile.id, CredentialKind::AiApiKey)?,
            )
            .map(Completion::Unlocked)
        }
    }
}

mod request_secret;
pub(crate) use request_secret::operate_request;

#[cfg(test)]
mod tests;
