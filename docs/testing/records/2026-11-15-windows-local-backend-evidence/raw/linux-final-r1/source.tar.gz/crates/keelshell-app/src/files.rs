//! SFTP browser and bounded Unicode editor. Mutations are explicit reviewed actions.
use crate::i18n::{Message, t};
use gpui_kit::prelude::FluentBuilder;
use gpui_kit::{
    component::{
        Disableable, Selectable, Sizable,
        button::{Button, ButtonVariants},
        input::{EditorState, Input, InputEvent, InputState, Textarea, TextareaState},
    },
    *,
};
use keelshell_core::{
    DirectoryCompareReport, DirectoryEntryKind, DirectoryEntrySnapshot, DirectoryEntryStatus,
    DirectorySyncDeletePolicy, DirectorySyncDirection, DirectorySyncPlan, TextDocument, TextFormat,
    TextLineEnding, TransferRecoveryClaim, TransferRecoveryDirection, TransferRecoveryRecord,
    TransferRecoveryState, TransferRecoveryStore,
};
use keelshell_session::{
    SessionError, SshSession,
    sftp::{
        DirectoryResumePlan, DirectoryTransferPlan, FileResumePlan, FileTransferPlan,
        RegularFileSnapshot, RemoteEntry, SftpSession, TransferDirection, TransferEvent,
        TransferQuarantineReview, TransferSpec,
    },
};
use std::{
    collections::{HashSet, VecDeque},
    path::PathBuf,
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
        mpsc,
    },
    time::{Duration, SystemTime, UNIX_EPOCH},
};

mod action_view;
mod archive;
mod archive_inspection;
mod batch;
mod browser;
mod editor_language;
mod editor_search;
#[cfg(test)]
mod editor_search_tests;
mod local_browser;
mod local_catalog;
mod local_view;
#[cfg(test)]
mod local_view_tests;
mod merge;
mod navigation_view;
mod parallel;
mod review;
mod selection;
mod server_archive;
mod sync;
mod transfer;
mod view;
mod worker;
use transfer::{TransferPhase, TransferStatus, TransferUpdate};
use worker::operate;

use gpui_kit::assets::IconName;
#[derive(Clone)]
enum IsolationTarget {
    Remote(String),
    Local(PathBuf),
}

#[derive(Clone)]
struct RecoveryDiscardCandidate {
    id: uuid::Uuid,
    record: TransferRecoveryRecord,
}

#[derive(Clone)]
enum Operation {
    InspectFileQuarantine(IsolationTarget),
    InspectQuarantine(TransferSpec),
    AcknowledgeQuarantine(TransferQuarantineReview),
    List(String),
    Read(RemoteEntry),
    ReadMerge {
        path: String,
        base: Vec<u8>,
        format: TextFormat,
        draft: String,
    },
    ApplyPatchToDraft {
        path: String,
        draft: String,
        patch: String,
    },
    Mkdir(String),
    Rename(String, String),
    Delete(RemoteEntry),
    SetPermissions(RemoteEntry, u32),
    Upload(PathBuf, String),
    Download(String, PathBuf),
    PlanDirectory(TransferSpec),
    PlanBatch(batch::BatchRequest),
    TransferBatch(Box<batch::BatchPlan>),
    PlanArchive(archive::ArchiveRequest),
    TransferArchive(Box<archive::ArchivePlan>),
    InspectArchiveTools(archive_inspection::Probe),
    PlanServerArchive(server_archive::Request),
    PackServerArchive(Box<server_archive::Plan>),
    TransferFile(FileTransferPlan),
    TransferDirectory(DirectoryTransferPlan),
    PlanResume(TransferSpec, bool),
    PlanPersistedRecovery {
        id: uuid::Uuid,
        spec: TransferSpec,
        directory: bool,
    },
    DiscardPersistedRecoveryBatch(Vec<RecoveryDiscardCandidate>),
    ResumeFile(FileResumePlan),
    ResumeDirectory(DirectoryResumePlan),
    ResumePersistedFile(uuid::Uuid, FileResumePlan),
    ResumePersistedDirectory(uuid::Uuid, DirectoryResumePlan),
    Compare(PathBuf, String),
    PlanDirectorySync(
        PathBuf,
        String,
        DirectorySyncDirection,
        DirectorySyncDeletePolicy,
    ),
    ApplyDirectorySync(Box<DirectorySyncComparison>, sync::journal::SharedJournal),
    Save {
        path: String,
        reviewed: RegularFileSnapshot,
        format: TextFormat,
        content: Vec<u8>,
    },
}
enum Outcome {
    QuarantineInspected(TransferQuarantineReview),
    Listed(String, Vec<RemoteEntry>),
    Read(RegularFileSnapshot, TextDocument),
    Saved {
        snapshot: RegularFileSnapshot,
        backup: String,
        format: TextFormat,
        body: String,
    },
    MergeLoaded {
        snapshot: RegularFileSnapshot,
        plan: keelshell_core::TextMergePlan,
        base: Vec<u8>,
        draft: String,
    },
    PatchApplied(String, String, String),
    Done(Message),
    PlannedDirectory(DirectoryTransferPlan),
    PlannedBatch(Box<batch::BatchPlan>),
    PlannedArchive(Box<archive::ArchivePlan>),
    PlannedServerArchive(Box<server_archive::Plan>),
    ArchiveTools(
        archive_inspection::Probe,
        keelshell_session::archive_tools::ArchiveToolReport,
    ),
    PlannedFileResume(FileResumePlan),
    PlannedDirectoryResume(DirectoryResumePlan),
    PlannedPersistedFileResume {
        id: uuid::Uuid,
        plan: FileResumePlan,
        recovery_claim: TransferRecoveryClaim,
    },
    PlannedPersistedDirectoryResume {
        id: uuid::Uuid,
        plan: DirectoryResumePlan,
        recovery_claim: TransferRecoveryClaim,
    },
    Compared(DirectoryComparison),
    DirectorySyncPlanned(DirectorySyncComparison),
}

enum WorkerMessage {
    Progress(Message),
    Transfer(TransferUpdate),
    Result {
        result: Box<Result<Outcome, FileFailure>>,
        recovery_warning: Option<Message>,
    },
}

#[derive(Clone, PartialEq, Eq)]
pub(crate) struct CloseDraft {
    text: SharedString,
    format: Option<TextFormat>,
    original: Option<(String, Vec<u8>)>,
    reload_required: bool,
    session: uuid::Uuid,
    review: uuid::Uuid,
    patch: SharedString,
}

pub struct FilesPanel {
    session: Option<SshSession>,
    /// Changes whenever this panel is detached from its authenticated host.
    /// Recovery proposals carry this token so a stale action cannot cross a
    /// reconnect/session boundary.
    session_token: uuid::Uuid,
    suspended: bool,
    host: String,
    connection_id: Option<uuid::Uuid>,
    runtime: Arc<tokio::runtime::Runtime>,
    recovery_store: Arc<TransferRecoveryStore>,
    recovery_records: Vec<TransferRecoveryRecord>,
    recovery_loading: bool,
    recovery_load_generation: u64,
    recovery_mutation_generation: u64,
    recovery_load_error: Option<String>,
    recovery_writes: HashSet<uuid::Uuid>,
    recovery_claim_requests: HashSet<uuid::Uuid>,
    recovery_claim: Option<TransferRecoveryClaim>,
    /// User-visible selection for the persisted recovery list.
    recovery_selection: selection::Selection<uuid::Uuid>,
    /// IDs waiting for explicit, one-at-a-time recovery review. The queue is
    /// session-bound and never authorizes a transfer by itself.
    recovery_review_queue: VecDeque<uuid::Uuid>,
    recovery_review_session: Option<uuid::Uuid>,
    recovery_review_active: Option<uuid::Uuid>,
    recovery_review_revision: u64,
    // The input is a navigation draft; mutations use only this canonical directory.
    directory: Option<String>,
    path: Entity<InputState>,
    name: Entity<InputState>,
    mode: Entity<InputState>,
    local: Entity<InputState>,
    archive_name: Entity<InputState>,
    archive_format: keelshell_core::ArchiveFormat,
    archive_inspection: archive_inspection::State,
    local_browser: local_browser::LocalBrowser,
    remote_sort: browser::BrowserSort,
    remote_selection: selection::Selection<String>,
    remote_show_hidden: bool,
    _browser_subscriptions: Vec<Subscription>,
    browser_review_revision: uuid::Uuid,
    editor: Entity<EditorState>,
    editor_find: Entity<InputState>,
    editor_replace: Entity<InputState>,
    editor_match: Option<usize>,
    confirmation_scroll: ScrollHandle,
    confirmation_expanded: bool,
    review_focus: FocusHandle,
    editor_surface: Option<review::EditorSurface>,
    tools_scroll: ScrollHandle,
    tool_section: Option<action_view::ToolSection>,
    tool_section_focus: [FocusHandle; 2],
    transfer_list_scroll: ScrollHandle,
    queue_details_scroll: ScrollHandle,
    queue_details_visible: bool,
    entries: Vec<RemoteEntry>,
    selected: Option<RemoteEntry>,
    editing: Option<(String, Vec<u8>)>,
    editor_snapshot: Option<RegularFileSnapshot>,
    editor_format: Option<TextFormat>,
    // Once an incompatible remote format was observed, only an explicit
    // successful reopen may establish a new save/merge baseline.
    editor_reload_required: bool,
    merge_review: Option<merge::MergeReview>,
    patch: Entity<TextareaState>,
    patch_visible: bool,
    text_review_scroll: ScrollHandle,
    diff_preview_scroll: ScrollHandle,
    diff_preview: Option<SharedString>,
    status: Message,
    busy: bool,
    pending: Option<(Message, Operation)>,
    pending_review_id: uuid::Uuid,
    operation_stop: Option<Arc<AtomicBool>>,
    operation_id: Option<uuid::Uuid>,
    transfer_pause: Option<tokio::sync::watch::Sender<bool>>,
    transfer: Option<TransferStatus>,
    active_recovery_id: Option<uuid::Uuid>,
    recovery: Option<RecoveryCandidate>,
    isolation_target: Option<IsolationTarget>,
    resume_mode: bool,
    comparison: Option<DirectoryComparison>,
    sync_journal: Option<sync::journal::SharedJournal>,
    mirror_conflicts: Vec<keelshell_core::DirectoryMirrorConflict>,
    transfer_jobs: Vec<parallel::QueuedTransfer>,
    selected_transfer: Option<uuid::Uuid>,
    transfer_queue: Arc<tokio::sync::OnceCell<Arc<keelshell_session::sftp::TransferQueue>>>,
    queue_parallelism: Arc<std::sync::atomic::AtomicUsize>,
    #[cfg(test)]
    reject_next_queued_worker_start: bool,
    // Tests retain setup admission in the actual entity, after queue ownership.
    #[cfg(test)]
    fixture_group: Option<Arc<fixture_group::FixtureGroup>>,
}

struct DirectoryComparison {
    local: PathBuf,
    remote: String,
    report: DirectoryCompareReport,
    sync_plan: Option<DirectorySyncPlan>,
}

#[derive(Clone)]
struct DirectorySyncComparison {
    local: PathBuf,
    remote: String,
    report: DirectoryCompareReport,
    plan: DirectorySyncPlan,
}

/// A failed transfer can offer a new read-only verification step, but never a
/// replay. The token binds the proposal to the live authenticated session that
/// produced the partial output.
struct RecoveryCandidate {
    persisted_id: Option<uuid::Uuid>,
    session_token: uuid::Uuid,
    spec: TransferSpec,
    directory: bool,
}

fn recovery_record_for(
    id: uuid::Uuid,
    connection_id: Option<uuid::Uuid>,
    spec: &TransferSpec,
    directory: bool,
    existing_bytes: u64,
) -> Result<TransferRecoveryRecord, String> {
    let direction = match spec.direction {
        TransferDirection::Upload => TransferRecoveryDirection::Upload,
        TransferDirection::Download => TransferRecoveryDirection::Download,
    };
    let timestamp = current_unix_timestamp();
    TransferRecoveryRecord::new_with_connection_id(
        id,
        connection_id,
        direction,
        spec.local.clone(),
        spec.remote.clone(),
        directory,
        TransferRecoveryState::Unfinished,
        existing_bytes,
        None,
        existing_bytes,
        timestamp,
        timestamp,
    )
    .map_err(|error| error.to_string())
}

fn recovery_connection_matches(
    record: &TransferRecoveryRecord,
    current_connection_id: Option<uuid::Uuid>,
) -> bool {
    record.connection_id.is_none() || record.connection_id == current_connection_id
}

fn persisted_recovery_progress(operation: &Operation) -> Option<(u64, u64)> {
    match operation {
        Operation::ResumePersistedFile(_, plan) => Some((plan.existing_bytes(), plan.bytes())),
        Operation::ResumePersistedDirectory(_, plan) => Some((plan.existing_bytes(), plan.bytes())),
        _ => None,
    }
}

fn update_persisted_recovery_progress(
    record: &mut TransferRecoveryRecord,
    existing_bytes: u64,
    total_bytes: u64,
) -> Result<(), String> {
    if existing_bytes > total_bytes {
        return Err("verified bytes exceed the source total".to_owned());
    }
    record.reviewed_existing_bytes = existing_bytes;
    record.total_bytes = Some(total_bytes);
    record.transferred_bytes = record
        .transferred_bytes
        .max(existing_bytes)
        .min(total_bytes);
    record.validate().map_err(|error| error.to_string())
}

fn persisted_recovery_is_bound(records: &[TransferRecoveryRecord], id: uuid::Uuid) -> Option<bool> {
    records
        .iter()
        .find(|record| record.id == id)
        .map(|record| record.connection_id.is_some())
}

fn recovery_load_is_current(
    expected_session: uuid::Uuid,
    current_session: uuid::Uuid,
    expected_generation: u64,
    current_generation: u64,
    expected_mutation_generation: u64,
    current_mutation_generation: u64,
) -> bool {
    expected_session == current_session
        && expected_generation == current_generation
        && expected_mutation_generation == current_mutation_generation
}

fn remember_persisted_recovery_progress(
    records: &mut [TransferRecoveryRecord],
    id: uuid::Uuid,
    existing_bytes: u64,
    total_bytes: u64,
) -> Result<(), String> {
    let record = records
        .iter_mut()
        .find(|record| record.id == id)
        .ok_or_else(|| "the recovery record disappeared".to_owned())?;
    update_persisted_recovery_progress(record, existing_bytes, total_bytes)?;
    record.updated_at = current_unix_timestamp().max(record.created_at);
    Ok(())
}

fn transfer_spec_from_recovery(record: &TransferRecoveryRecord) -> TransferSpec {
    TransferSpec {
        direction: match record.direction {
            TransferRecoveryDirection::Upload => TransferDirection::Upload,
            TransferRecoveryDirection::Download => TransferDirection::Download,
        },
        local: record.local_path.clone(),
        remote: record.remote_path.clone(),
    }
}

fn recovery_is_available(
    candidate: Option<&RecoveryCandidate>,
    session_token: uuid::Uuid,
    suspended: bool,
    busy: bool,
    pending: bool,
    phase: Option<TransferPhase>,
) -> bool {
    !busy
        && !suspended
        && !pending
        && phase == Some(TransferPhase::Failed)
        && candidate.is_some_and(|candidate| candidate.session_token == session_token)
}

/// Guard the explicit recovery click against state that can change after the
/// card was rendered. A pending approval must remain untouched when the click
/// is rejected; the caller may still be waiting for the user to confirm it.
fn recovery_request_is_allowed(
    candidate: Option<&RecoveryCandidate>,
    session_token: uuid::Uuid,
    session_available: bool,
    suspended: bool,
    busy: bool,
    pending: bool,
    phase: Option<TransferPhase>,
) -> bool {
    session_available
        && recovery_is_available(candidate, session_token, suspended, busy, pending, phase)
}

const TRANSFER_RECOVERY_CHECKPOINT_BYTES: u64 = 64 * 1024;

fn current_unix_timestamp() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_or(0, |duration| duration.as_secs())
}

struct TransferRecoveryWriter {
    store: Arc<TransferRecoveryStore>,
    record: TransferRecoveryRecord,
    claim: Option<TransferRecoveryClaim>,
    last_persisted_bytes: u64,
    last_error: Option<String>,
    finished: bool,
}

impl TransferRecoveryWriter {
    fn new(
        store: Arc<TransferRecoveryStore>,
        record: TransferRecoveryRecord,
        claim: Option<TransferRecoveryClaim>,
    ) -> Self {
        Self {
            last_persisted_bytes: record.transferred_bytes,
            store,
            record,
            claim,
            last_error: None,
            finished: false,
        }
    }

    fn start(&mut self) -> Result<(), FileFailure> {
        let mut record = self.record.clone();
        record.state = TransferRecoveryState::Unfinished;
        record.updated_at = current_unix_timestamp().max(record.created_at);
        if self.claim.is_none() {
            self.claim = Some(
                self.store
                    .upsert_and_claim(record.clone())
                    .map_err(|error| FileFailure::RecoveryUnavailable(error.to_string()))?,
            );
        } else {
            self.persist(record.clone())
                .map_err(|error| FileFailure::RecoveryUnavailable(error.to_string()))?;
        }
        self.record = record;
        self.last_persisted_bytes = self.record.transferred_bytes;
        self.last_error = None;
        Ok(())
    }

    fn persist(&self, record: TransferRecoveryRecord) -> Result<(), keelshell_core::Error> {
        match self.claim.as_ref() {
            Some(claim) => self.store.upsert_with_claim(claim, record),
            None => self.store.upsert(record),
        }
    }

    fn checkpoint(&mut self, transferred_bytes: u64, total_bytes: Option<u64>) {
        if transferred_bytes
            < self
                .last_persisted_bytes
                .saturating_add(TRANSFER_RECOVERY_CHECKPOINT_BYTES)
            && total_bytes.is_none()
        {
            return;
        }
        let mut record = self.record.clone();
        record.transferred_bytes = transferred_bytes;
        record.total_bytes = total_bytes.or(record.total_bytes);
        record.updated_at = current_unix_timestamp().max(record.created_at);
        match self.persist(record.clone()) {
            Ok(()) => {
                self.record = record;
                self.last_persisted_bytes = transferred_bytes;
                self.last_error = None;
            }
            Err(error) => {
                self.last_error = Some(error.to_string());
            }
        }
    }

    fn finish(
        &mut self,
        outcome: &Result<Outcome, FileFailure>,
        transferred_bytes: u64,
        total_bytes: Option<u64>,
    ) {
        if self.finished {
            return;
        }
        self.finished = true;
        let transferred_bytes = transferred_bytes.max(self.record.reviewed_existing_bytes);
        self.checkpoint(transferred_bytes, total_bytes);
        let mut terminal_error = self.last_error.take();
        if outcome.is_ok() {
            let result = self.claim.as_ref().map_or_else(
                || self.store.remove(self.record.id),
                |claim| self.store.remove_with_claim(claim),
            );
            if let Err(error) = result {
                terminal_error = Some(combine_recovery_errors(terminal_error, error.to_string()));
            }
            self.last_error = terminal_error;
            return;
        }
        let mut record = self.record.clone();
        record.transferred_bytes = transferred_bytes;
        record.total_bytes = total_bytes.or(record.total_bytes);
        record.state = match outcome {
            Err(error) if error.is_outcome_unknown() => TransferRecoveryState::OutcomeUnknown,
            Err(error) if error.is_cancelled() => TransferRecoveryState::Cancelled,
            _ => TransferRecoveryState::Failed,
        };
        record.updated_at = current_unix_timestamp().max(record.created_at);
        match self.persist(record.clone()) {
            Ok(()) => {
                self.record = record;
                self.last_persisted_bytes = transferred_bytes;
                self.last_error = terminal_error;
            }
            Err(error) => {
                self.last_error = Some(combine_recovery_errors(terminal_error, error.to_string()));
            }
        }
    }

    fn take_error(&mut self) -> Option<String> {
        self.last_error.take()
    }
}

fn combine_recovery_errors(previous: Option<String>, next: String) -> String {
    previous.map_or(next.clone(), |previous| {
        format!("{previous}; terminal update: {next}")
    })
}

fn append_recovery_warning(message: Message, warning: Option<&Message>) -> Message {
    let Some(warning) = warning else {
        return message;
    };
    let (message_zh, message_en) = message.translations();
    let (warning_zh, warning_en) = warning.translations();
    Message::new(
        format!("{message_zh}\n{warning_zh}"),
        format!("{message_en}\n{warning_en}"),
    )
}

fn recovery_finish_warning(detail: impl Into<String>) -> Message {
    Message::detail(
        "传输结束，但恢复记录未能更新",
        "Transfer ended, but recovery metadata was not updated",
        detail.into(),
    )
}

fn persisted_recovery_host_confirmation(host: &str) -> Message {
    Message::new(
        format!(
            "当前 SSH 会话：{host}。这条重启后传输记录没有保存连接身份。请确认当前 SSH 主机就是原目标主机；确认后才会执行只读检查，尚未写入远端。"
        ),
        format!(
            "Current SSH session: {host}. This post-restart transfer record has no saved connection identity. Confirm that the current SSH host is the original target; only then will the read-only inspection start. Nothing has been written remotely."
        ),
    )
}

impl Drop for FilesPanel {
    fn drop(&mut self) {
        self.local_browser.cancel_read();
        self.cancel_transfers();
        if let Some(stop) = &self.operation_stop {
            stop.store(true, Ordering::Release);
        }
    }
}
fn field(placeholder: &str, value: &str, window: &mut Window, cx: &mut App) -> Entity<InputState> {
    cx.new(|cx| {
        let mut input = InputState::new(window, cx).placeholder(placeholder.to_owned());
        input.set_value(value.to_owned(), window, cx);
        input
    })
}

#[derive(Debug, PartialEq, Eq)]
enum PathError {
    DirectoryRequired,
    InvalidName,
}
impl PathError {
    fn message(&self) -> Message {
        match self {
            Self::DirectoryRequired => Message::new(
                "请先成功打开远程目录，再修改文件",
                "Open a remote directory successfully before changing files",
            ),
            Self::InvalidName => Message::new(
                "请输入不含路径分隔符或控制字符的单个文件名",
                "Enter one file or folder name without separators or control characters",
            ),
        }
    }
}

/// Join only a canonical absolute directory and one literal name, never a draft path.
fn child_path(directory: Option<&str>, name: &str) -> Result<String, PathError> {
    let directory = directory
        .filter(|path| path.starts_with('/') && !path.chars().any(char::is_control))
        .ok_or(PathError::DirectoryRequired)?;
    if name.is_empty()
        || matches!(name, "." | "..")
        || name.contains(['/', '\\'])
        || name.chars().any(char::is_control)
    {
        return Err(PathError::InvalidName);
    }
    Ok(format!("{}/{}", directory.trim_end_matches('/'), name))
}

/// Parse the explicit POSIX mode input used by the reviewed permissions action.
/// Three digits are accepted as shorthand for a leading zero; no symbolic mode
/// expressions or shell syntax are interpreted.
fn parse_permissions_mode(value: &str) -> Result<u32, &'static str> {
    let value = value.trim();
    if !(3..=4).contains(&value.len()) || !value.bytes().all(|byte| (b'0'..=b'7').contains(&byte)) {
        return Err("enter a three- or four-digit octal mode between 0000 and 7777");
    }
    u32::from_str_radix(value, 8).map_err(|_| "enter a valid octal mode")
}

#[derive(Debug)]
enum FileFailure {
    Transport(String),
    RecoveryUnavailable(String),
    IsolationBusy,
    IsolationUnknown,
    Cancelled,
    CancelledBeforeStart,
    CancellationUnconfirmed,
    OutcomeUncertain(String),
    InvalidEditor,
    TextDocument(keelshell_core::TextDocumentError),
    EditorFormatChanged,
    TextEdit(keelshell_core::TextEditError),
    SavedReadback(String),
    Symlink,
    Cleanup,
    WorkerStopped,
    DirectoryTransfer {
        destination: String,
        error: Box<FileFailure>,
    },
    Comparison(String),
    MirrorConflicts(Vec<keelshell_core::DirectoryMirrorConflict>),
}

/// Return a terminal phase only for an operation that actually transferred
/// bytes. Read-only plans must leave an older failed transfer card untouched.
fn terminal_transfer_phase(
    is_transfer: bool,
    result: &Result<Outcome, FileFailure>,
) -> Option<TransferPhase> {
    if !is_transfer {
        return None;
    }
    Some(match result {
        Ok(_) => TransferPhase::Completed,
        Err(
            FileFailure::CancellationUnconfirmed
            | FileFailure::OutcomeUncertain(_)
            | FileFailure::WorkerStopped,
        ) => TransferPhase::Uncertain,
        Err(error) if error.is_cancelled() => TransferPhase::Cancelled,
        Err(_) => TransferPhase::Failed,
    })
}

impl From<SessionError> for FileFailure {
    fn from(error: SessionError) -> Self {
        match error {
            SessionError::MutationBusy => Self::IsolationBusy,
            SessionError::MutationQuarantined => Self::IsolationUnknown,
            SessionError::MutationUncertain => Self::OutcomeUncertain(error.to_string()),
            _ => Self::Transport(error.to_string()),
        }
    }
}
impl std::fmt::Display for FileFailure {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::IsolationBusy=>f.write_str("file target is owned by an active application mutation"),
            Self::IsolationUnknown=>f.write_str("file target is isolated by an unknown mutation; exact risk acknowledgement required"),
            Self::Transport(detail) => f.write_str(detail),
            Self::RecoveryUnavailable(detail) => {
                write!(f, "transfer recovery metadata is unavailable: {detail}")
            }
            Self::Cancelled => {
                f.write_str("File operation cancelled; remote outcome may be unknown")
            }
            Self::OutcomeUncertain(detail) => write!(f, "Transfer outcome unknown: {detail}"),
            Self::CancellationUnconfirmed => {
                f.write_str("Cancellation requested, but no terminal transfer result was received")
            }
            Self::CancelledBeforeStart => {
                f.write_str("File operation cancelled before SFTP initialization")
            }
            Self::InvalidEditor => f.write_str("Editor accepts supported Unicode text files up to 1 MiB"),
            Self::TextDocument(error) => write!(f, "{error}"),
            Self::EditorFormatChanged => {
                f.write_str("Remote encoding, BOM or line-ending format changed; read and review again")
            }
            Self::TextEdit(error) => write!(f,"{error}"),
            Self::SavedReadback(error) => write!(f,"publication acknowledged but content readback failed: {error}"),
            Self::Symlink => f.write_str("Permission changes on symbolic links are disabled"),
            Self::Cleanup => f.write_str("Operation completed but SFTP cleanup failed"),
            Self::WorkerStopped => f.write_str("File worker stopped without a result"),
            Self::DirectoryTransfer { destination, error } => {
                write!(f, "{error}; inspect partial directory {destination}")
            }
            Self::MirrorConflicts(conflicts) => write!(f,"bounded mirror refused {} conflicts", conflicts.len()),
            Self::Comparison(detail) => write!(f, "Directory comparison failed: {detail}"),
        }
    }
}
impl FileFailure {
    fn is_cancelled(&self) -> bool {
        match self {
            Self::Cancelled | Self::CancelledBeforeStart => true,
            Self::DirectoryTransfer { error, .. } => error.is_cancelled(),
            _ => false,
        }
    }

    fn is_outcome_unknown(&self) -> bool {
        match self {
            Self::OutcomeUncertain(_) | Self::CancellationUnconfirmed | Self::WorkerStopped => true,
            Self::DirectoryTransfer { error, .. } => error.is_outcome_unknown(),
            _ => false,
        }
    }

    fn message(&self) -> Message {
        match self {
            Self::IsolationBusy => Message::new(
                "目标正由其它文件操作占用；请等待完成后重新审核。",
                "Another file operation owns this target; review again after it finishes.",
            ),
            Self::IsolationUnknown => Message::new(
                "目标存在未知写入结果，已隔离。普通保存或 MCP 提案确认不会解除隔离；请只读检查并显式审核风险。",
                "This target is isolated by an unknown mutation. Ordinary save or MCP approval cannot release it; inspect read-only and explicitly review its risk.",
            ),
            Self::RecoveryUnavailable(detail) => Message::detail(
                "传输恢复记录无法安全保存，传输尚未开始",
                "Transfer recovery metadata could not be saved safely; the transfer did not start",
                detail,
            ),
            Self::MirrorConflicts(conflicts) => Message::new(
                format!(
                    "镜像计划已拒绝：{} 项冲突；请查看完整只读列表。没有写入或删除。",
                    conflicts.len()
                ),
                format!(
                    "Mirror refused: {} conflicts; inspect the complete read-only list. Nothing was written or deleted.",
                    conflicts.len()
                ),
            ),
            Self::Transport(detail) => Message::new(
                format!("文件操作失败：{detail}。远端结果可能未知，请检查后再重试。"),
                format!(
                    "File operation failed: {detail}. Remote completion may be unknown; inspect before retrying."
                ),
            ),
            Self::Cancelled => Message::new(
                "操作已取消；请先检查远端结果。临时文件或未完成的本地下载可能仍存在。",
                "Operation cancelled; inspect the remote result. A staged file or partial local download may remain.",
            ),
            Self::OutcomeUncertain(detail) => Message::detail(
                "传输结果未知，目标已隔离；重连不会解除隔离。请只读检查，再显式审核未知风险",
                "Transfer outcome unknown; destination isolated across reconnects. Inspect read-only, then explicitly review the unresolved risk",
                detail,
            ),
            Self::CancellationUnconfirmed => Message::new(
                "已请求取消，但尚未收到最终传输回执；结果未知，请检查目标后再操作。",
                "Cancellation requested, but the final transfer result is unknown; inspect the destination before another operation.",
            ),
            Self::CancelledBeforeStart => Message::new(
                "已在打开 SFTP 前取消操作",
                "Operation cancelled before opening SFTP",
            ),
            Self::InvalidEditor => Message::new(
                "编辑器仅支持不超过 1 MiB 的受支持 Unicode 文本文件",
                "The editor accepts supported Unicode text files up to 1 MiB",
            ),
            Self::TextDocument(error) => Message::detail(
                "文本格式准备未通过，保留原文件和草稿",
                "Text format preparation failed; original and draft retained",
                error,
            ),
            Self::EditorFormatChanged => Message::new(
                "远端编码、BOM 或换行格式已变化；当前草稿保留。请保留所需草稿，再显式重新打开文件并审核；未写入。",
                "Remote encoding, BOM or line-ending format changed; draft retained. Preserve the draft you need, then explicitly reopen and review the file; no write occurred.",
            ),
            Self::TextEdit(error) => Message::detail(
                "文本审核未完成，草稿已保留",
                "Text review incomplete; draft retained",
                error,
            ),
            Self::SavedReadback(error) => Message::detail(
                "已收到原子发布确认，但完整读回未通过；保留旧基线和草稿，请读取远端确认，不自动重试",
                "Atomic publication acknowledged, but full readback failed; old baseline and draft retained. Inspect the remote file; no automatic retry",
                error,
            ),
            Self::Symlink => Message::new(
                "为避免跟随链接误改目标，符号链接不支持修改权限",
                "Permission changes on symbolic links are disabled to avoid following a link",
            ),
            Self::Cleanup => Message::new(
                "操作已完成，但 SFTP 清理失败；请检查后再重试",
                "Operation completed, but SFTP cleanup failed; inspect before retrying",
            ),
            Self::DirectoryTransfer { destination, error } => Message::new(
                format!(
                    "目录传输未完成：{error}。请检查目标 {destination}；可能保留部分文件，不会自动清理。"
                ),
                format!(
                    "Directory transfer incomplete: {error}. Inspect {destination}; partial files may remain and are not removed automatically."
                ),
            ),
            Self::Comparison(detail) => Message::new(
                format!("目录比较失败：{detail}"),
                format!("Directory comparison failed: {detail}"),
            ),
            Self::WorkerStopped => Message::new(
                "文件工作线程未返回结果便结束",
                "File worker stopped without a result",
            ),
        }
    }
}

async fn cancellation(stop: &AtomicBool) {
    while !stop.load(Ordering::Acquire) {
        tokio::time::sleep(Duration::from_millis(10)).await;
    }
}

fn transfer_progress_message(
    direction: TransferDirection,
    transferred: u64,
    total: Option<u64>,
) -> Message {
    let verb_zh = match direction {
        TransferDirection::Upload => "上传中",
        TransferDirection::Download => "下载中",
    };
    let verb_en = match direction {
        TransferDirection::Upload => "Uploading",
        TransferDirection::Download => "Downloading",
    };
    let progress_zh = total.map_or_else(
        || format!("{transferred} 字节"),
        |total| format!("{transferred} / {total} 字节"),
    );
    let progress_en = total.map_or_else(
        || format!("{transferred} bytes"),
        |total| format!("{transferred} / {total} bytes"),
    );
    Message::new(
        format!("{verb_zh}：{progress_zh}"),
        format!("{verb_en}: {progress_en}"),
    )
}

fn resume_progress_message(
    transferred: u64,
    total: Option<u64>,
    existing: u64,
    directory: bool,
) -> Message {
    let total = total.map_or_else(|| "—".to_owned(), |total| total.to_string());
    if directory {
        return Message::new(
            format!(
                "目录续传已确认 {transferred} / {total} 字节（含已复核前缀）；审核时原有 {existing} 字节"
            ),
            format!(
                "Folder continuation: {transferred} / {total} confirmed bytes (includes rechecked prefixes); {existing} existing bytes at review"
            ),
        );
    }
    let added = transferred.saturating_sub(existing);
    Message::new(
        format!("续传进度（含已验证部分）：{transferred} / {total} 字节；本次新增 {added} 字节"),
        format!(
            "Continuation progress (includes verified content): {transferred} / {total} bytes; {added} new bytes"
        ),
    )
}

fn send_worker_progress(progress: &mpsc::SyncSender<WorkerMessage>, message: Message) {
    // Progress is advisory and may be coalesced when the GPUI frame is busy;
    // the terminal result always uses the blocking sender below.
    let _ = progress.try_send(WorkerMessage::Progress(message));
}

impl FilesPanel {
    /// Height allocated by the workspace, also used by file-state geometry tests.
    pub(crate) fn workbench_height(viewport_height: Pixels) -> Pixels {
        // Keep the compact workbench bounded so the terminal retains a usable
        // viewport. The file panel owns its own scroll surfaces, so editor,
        // transfer and merge controls remain reachable without reserving their
        // full content height from the shared workspace.
        px(340.).min(viewport_height * 0.40)
            - if viewport_height < px(700.) {
                px(20.)
            } else {
                px(0.)
            }
    }

    #[cfg(test)]
    pub fn new(
        session: SshSession,
        host: String,
        runtime: Arc<tokio::runtime::Runtime>,
        window: &mut Window,
        cx: &mut Context<Self>,
    ) -> Self {
        Self::new_with_recovery_store_and_connection(
            session,
            host,
            None,
            runtime,
            Arc::new(TransferRecoveryStore::disabled()),
            window,
            cx,
        )
    }

    pub fn new_with_recovery_store_and_connection(
        session: SshSession,
        host: String,
        connection_id: Option<uuid::Uuid>,
        runtime: Arc<tokio::runtime::Runtime>,
        recovery_store: Arc<TransferRecoveryStore>,
        window: &mut Window,
        cx: &mut Context<Self>,
    ) -> Self {
        #[cfg(test)]
        let fixture_group = fixture_group::for_app(cx);
        let mut panel = Self {
            session: Some(session),
            session_token: uuid::Uuid::new_v4(),
            suspended: false,
            host,
            connection_id,
            runtime,
            recovery_store,
            recovery_records: Vec::new(),
            recovery_loading: true,
            recovery_load_generation: 0,
            recovery_mutation_generation: 0,
            recovery_load_error: None,
            recovery_writes: HashSet::new(),
            recovery_claim_requests: HashSet::new(),
            recovery_claim: None,
            recovery_selection: selection::Selection::default(),
            recovery_review_queue: VecDeque::new(),
            recovery_review_session: None,
            recovery_review_active: None,
            recovery_review_revision: 0,
            directory: None,
            path: field(t(cx, "远程目录", "Remote directory"), ".", window, cx),
            name: field(
                t(cx, "文件名 / 新建目录", "New name / folder"),
                "",
                window,
                cx,
            ),
            mode: field(
                t(cx, "权限（八进制）", "Permissions (octal)"),
                "",
                window,
                cx,
            ),
            local: field(t(cx, "本地传输路径", "Local transfer path"), "", window, cx),
            archive_name: field(
                t(cx, "远端新归档名称", "New remote archive name"),
                "",
                window,
                cx,
            ),
            archive_format: keelshell_core::ArchiveFormat::Zip,
            archive_inspection: archive_inspection::State::default(),
            local_browser: local_browser::LocalBrowser::new(window, cx),
            remote_sort: browser::BrowserSort::default(),
            remote_selection: selection::Selection::default(),
            remote_show_hidden: false,
            _browser_subscriptions: Vec::new(),
            browser_review_revision: uuid::Uuid::new_v4(),
            editor: cx.new(|cx| {
                EditorState::new(window, cx)
                    .language("text")
                    // KeelShell owns the literal search/replace controls and
                    // keeps review edits explicit, so editor conveniences that
                    // alter input or add a second search surface stay disabled.
                    .searchable(false)
                    .folding(false)
                    .auto_close(false)
                    .smart_indent(false)
            }),
            editor_find: field(t(cx, "查找", "Find"), "", window, cx),
            editor_replace: field(t(cx, "替换为", "Replace with"), "", window, cx),
            editor_match: None,
            confirmation_scroll: ScrollHandle::new(),
            confirmation_expanded: false,
            review_focus: cx.focus_handle(),
            editor_surface: None,
            tools_scroll: ScrollHandle::new(),
            tool_section: None,
            tool_section_focus: [cx.focus_handle(), cx.focus_handle()],
            transfer_list_scroll: ScrollHandle::new(),
            queue_details_scroll: ScrollHandle::new(),
            queue_details_visible: false,
            entries: Vec::new(),
            selected: None,
            editing: None,
            editor_snapshot: None,
            editor_format: None,
            editor_reload_required: false,
            merge_review: None,
            patch: cx.new(|cx| TextareaState::new(window, cx)),
            patch_visible: false,
            text_review_scroll: ScrollHandle::new(),
            diff_preview_scroll: ScrollHandle::new(),
            diff_preview: None,
            status: Message::new("正在打开 SFTP…", "Opening SFTP…"),
            busy: false,
            pending: None,
            pending_review_id: uuid::Uuid::new_v4(),
            operation_stop: None,
            operation_id: None,
            transfer_pause: None,
            transfer: None,
            active_recovery_id: None,
            recovery: None,
            isolation_target: None,
            resume_mode: false,
            comparison: None,
            sync_journal: None,
            mirror_conflicts: Vec::new(),
            transfer_jobs: Vec::new(),
            selected_transfer: None,
            transfer_queue: Arc::new(tokio::sync::OnceCell::new()),
            queue_parallelism: Arc::new(std::sync::atomic::AtomicUsize::new(2)),
            #[cfg(test)]
            reject_next_queued_worker_start: false,
            #[cfg(test)]
            fixture_group,
        };
        panel.install_browser_subscriptions(window, cx);
        panel.run(Operation::List(".".into()), window, cx);
        panel.load_recovery_records(window, cx);
        panel
    }

    fn load_recovery_records(&mut self, window: &mut Window, cx: &mut Context<Self>) {
        let store = self.recovery_store.clone();
        let runtime = self.runtime.clone();
        let executor = cx.background_executor().clone();
        let expected_session = self.session_token;
        let expected_mutation_generation = self.recovery_mutation_generation;
        self.recovery_load_generation = self.recovery_load_generation.wrapping_add(1);
        let expected_generation = self.recovery_load_generation;
        self.recovery_loading = true;
        let task = crate::runtime_bridge::spawn(&runtime, executor, async move {
            tokio::task::spawn_blocking(move || store.load())
                .await
                .map_err(|error| format!("transfer recovery worker stopped: {error}"))?
                .map_err(|error| error.to_string())
        });
        cx.spawn_in(window, async move |this, cx| {
            let result = match task.await {
                Ok(result) => result,
                Err(_) => Err("transfer recovery worker did not return".to_owned()),
            };
            let _ = this.update_in(cx, |view, _, cx| {
                view.apply_recovery_load(
                    expected_session,
                    expected_generation,
                    expected_mutation_generation,
                    result,
                    cx,
                );
            });
        })
        .detach();
    }

    pub(super) fn apply_recovery_load(
        &mut self,
        expected_session: uuid::Uuid,
        expected_generation: u64,
        expected_mutation_generation: u64,
        result: Result<Vec<TransferRecoveryRecord>, String>,
        cx: &mut Context<Self>,
    ) {
        if !recovery_load_is_current(
            expected_session,
            self.session_token,
            expected_generation,
            self.recovery_load_generation,
            expected_mutation_generation,
            self.recovery_mutation_generation,
        ) {
            return;
        }
        self.recovery_loading = false;
        match result {
            Ok(records) => {
                self.recovery_records = records;
                self.recovery_load_error = None;
            }
            Err(error) => {
                self.recovery_records.clear();
                self.recovery_load_error = Some(error);
            }
        }
        let visible_ids: Vec<_> = self
            .recovery_records
            .iter()
            .map(|record| record.id)
            .collect();
        self.recovery_selection.retain_visible(&visible_ids);
        let queue_lost_record = (!self.recovery_review_queue.is_empty()
            || self.recovery_review_session.is_some())
            && !self.recovery_review_queue_is_current();
        let active_lost_record = self
            .active_recovery_id
            .is_some_and(|id| !self.recovery_records.iter().any(|record| record.id == id));
        if queue_lost_record || active_lost_record {
            let pending_recovery = self
                .pending
                .as_ref()
                .and_then(|(_, operation)| operation.persisted_recovery_id());
            self.revoke_recovery_review();
            if pending_recovery.is_some() || active_lost_record {
                self.pending = None;
                self.confirmation_expanded = false;
                self.recovery = None;
            }
            self.status = Message::new(
                "恢复记录已消失或待审核队列已失效；已清空待审核状态，未执行传输。",
                "A recovery record disappeared or the review queue became stale; pending review state was cleared and no transfer ran.",
            );
        }
        cx.notify();
    }

    fn advance_recovery_mutation_generation(&mut self) {
        self.recovery_mutation_generation = self.recovery_mutation_generation.wrapping_add(1);
        // The mutation has already updated the authoritative in-memory
        // snapshot. Any load captured before it is stale and must not leave
        // the panel permanently marked as loading when its callback returns.
        self.recovery_loading = false;
    }

    pub(super) fn apply_persisted_recovery_progress(
        &mut self,
        id: uuid::Uuid,
        existing_bytes: u64,
        total_bytes: u64,
        window: &mut Window,
        cx: &mut Context<Self>,
    ) -> Result<(), String> {
        let result = remember_persisted_recovery_progress(
            &mut self.recovery_records,
            id,
            existing_bytes,
            total_bytes,
        );
        if result.is_ok() {
            self.advance_recovery_mutation_generation();
            // The in-memory record is updated immediately for the review
            // surface, but another record may have completed or been
            // discarded while the old load was in flight. Re-read the
            // authoritative store after every successful mutation so a
            // stale callback cannot leave unrelated records in the panel.
            self.load_recovery_records(window, cx);
        }
        result
    }

    /// Preserve local drafts and completed records while retiring remote capabilities.
    pub fn suspend(&mut self, cx: &mut Context<Self>) {
        if self.suspended {
            return;
        }
        self.suspended = true;
        self.session = None;
        self.session_token = uuid::Uuid::new_v4();
        self.archive_inspection = archive_inspection::State::default();
        self.recovery = None;
        self.revoke_recovery_review();
        self.recovery_claim_requests.clear();
        self.pending = None;
        self.confirmation_expanded = false;
        self.local_browser.retire_navigation();
        self.remote_selection.clear();
        self.selected = None;
        self.cancel_transfers();
        self.cancel_active(cx);
        cx.notify();
    }

    /// Explicitly selected, loaded directory of this live file panel; never a shell cwd.
    pub(crate) fn completion_directory(&self) -> Option<&str> {
        (!self.suspended)
            .then_some(self.directory.as_deref())
            .flatten()
    }

    /// Whether dropping this snapshot would lose an unsaved editor draft.
    pub fn has_unsaved_draft(&self, cx: &App) -> bool {
        let content = self.editor.read(cx).value();
        self.editing
            .as_ref()
            .map_or(!content.is_empty(), |(_, original)| {
                !self.draft_matches_bytes(&content, original)
            })
    }

    fn draft_matches_bytes(&self, draft: &str, raw: &[u8]) -> bool {
        self.editor_format.map_or_else(
            || draft.as_bytes() == raw,
            |format| format.matches_bytes(draft, raw),
        )
    }

    /// Compare the editor's canonical Unicode body with a worker snapshot.
    ///
    /// The worker carries decoded text for merge planning, while the editor
    /// may currently contain LF insertions that are normalized by its saved
    /// format. Encoding the current draft and decoding it again keeps this
    /// check byte-format aware without comparing UTF-16 bytes as UTF-8.
    pub(super) fn draft_matches_text(&self, draft: &str, expected: &str) -> bool {
        self.prepare_editor_bytes(draft)
            .ok()
            .and_then(|bytes| self.editor_format?.decode_body(&bytes).ok())
            .is_some_and(|body| body == expected)
    }

    fn prepare_editor_bytes(&self, draft: &str) -> Result<Vec<u8>, FileFailure> {
        self.editor_format
            .ok_or(FileFailure::InvalidEditor)?
            .prepare_save(draft)
            .map_err(FileFailure::TextDocument)
    }

    /// Immutable in-memory version for explicit archive-discard consent.
    pub fn draft_snapshot(&self, cx: &App) -> SharedString {
        self.editor.read(cx).value()
    }

    /// Exact transient draft/format consent; never serialized or logged.
    pub(crate) fn window_close_draft(&self, cx: &App) -> CloseDraft {
        CloseDraft {
            text: self.editor.read(cx).value(),
            format: self.editor_format,
            original: self.editing.clone(),
            reload_required: self.editor_reload_required,
            session: self.session_token,
            review: self.pending_review_id,
            patch: self.patch.read(cx).value(),
        }
    }

    pub(crate) fn window_close_busy(&self) -> bool {
        self.busy
            || self.operation_id.is_some()
            || self.has_active_transfers()
            || self.isolation_target.is_some()
            || self
                .transfer
                .as_ref()
                .is_some_and(|job| job.phase == TransferPhase::Uncertain)
            || self
                .transfer_jobs
                .iter()
                .any(|job| job.status.phase == TransferPhase::Uncertain)
            || self.sync_journal.as_ref().is_some_and(|journal| {
                journal.lock().map_or(true, |journal| {
                    !journal.finished
                        || journal.cleanup_failed
                        || journal
                            .steps
                            .iter()
                            .any(|step| step.state == sync::journal::StepState::Unknown)
                })
            })
    }

    #[cfg(test)]
    pub(crate) fn set_window_close_format_for_test(&mut self, raw: &[u8]) {
        self.editor_format = TextDocument::decode(raw)
            .ok()
            .map(|document| document.format());
    }

    #[cfg(test)]
    pub(crate) fn seed_draft_for_test(
        &mut self,
        path: &str,
        original: &str,
        draft: &str,
        window: &mut Window,
        cx: &mut Context<Self>,
    ) {
        self.editing = Some((path.to_owned(), original.as_bytes().to_vec()));
        self.editor_format = TextDocument::decode(original.as_bytes())
            .ok()
            .map(|document| document.format());
        self.editor_reload_required = false;
        self.editor.update(cx, |editor, cx| {
            editor.set_highlighter(editor_language::language_for_path(path), cx);
            editor.set_value(draft.to_owned(), window, cx)
        });
    }

    /// Retain live transport/editor state while updating only translated hints.
    pub fn refresh_locale(&mut self, window: &mut Window, cx: &mut Context<Self>) {
        for (input, zh, en) in [
            (&self.path, "远程目录", "Remote directory"),
            (&self.name, "文件名 / 新建目录", "New name / folder"),
            (&self.mode, "权限（八进制）", "Permissions (octal)"),
            (&self.local, "本地传输路径", "Local transfer path"),
            (
                &self.archive_name,
                "远端新归档名称",
                "New remote archive name",
            ),
            (
                &self.local_browser.path,
                "本地绝对目录",
                "Absolute local folder",
            ),
        ] {
            let placeholder = t(cx, zh, en);
            input.update(cx, |input, cx| {
                input.set_placeholder(placeholder, window, cx)
            });
        }
        cx.notify();
    }
    fn run(&mut self, operation: Operation, window: &mut Window, cx: &mut Context<Self>) {
        let persisted_recovery_id = operation.persisted_recovery_id();
        let recovery_context = if matches!(&operation, Operation::PlanPersistedRecovery { .. }) {
            self.recovery_claim
                .take()
                .map(|claim| (self.recovery_store.clone(), claim))
        } else {
            None
        };
        let Some(session) = self.session.clone().filter(|_| !self.suspended) else {
            if persisted_recovery_id.is_some() {
                self.revoke_recovery_review();
            }
            return;
        };
        if self.operation_id.is_some() || (self.busy && !operation.can_run_beside_transfers()) {
            if persisted_recovery_id.is_some() {
                self.revoke_recovery_review();
            }
            self.status = Message::new(
                "请等待或取消当前文件操作",
                "Wait for or cancel the active file operation",
            );
            cx.notify();
            return;
        }
        if let Operation::TransferBatch(plan) = operation {
            self.run_batch(*plan, window, cx);
            return;
        }
        if let Operation::TransferArchive(plan) = &operation
            && !self.archive_plan_is_current(plan, cx)
        {
            self.status = archive::expired_message();
            cx.notify();
            return;
        }
        let server_archive_current = match &operation {
            Operation::PlanServerArchive(request) => {
                self.server_archive_request_is_current(request, cx)
            }
            Operation::PackServerArchive(plan) => self.server_archive_plan_is_current(plan, cx),
            _ => true,
        };
        if !server_archive_current {
            self.status = archive::expired_message();
            cx.notify();
            return;
        }
        let archive_probe = if let Operation::InspectArchiveTools(probe) = &operation {
            if !self.archive_probe_is_current(probe) {
                self.status = Message::new(
                    "检测所审核的 SSH 会话已变化，请重新审核。",
                    "The reviewed inspection session changed. Review a new inspection.",
                );
                cx.notify();
                return;
            }
            Some(probe.clone())
        } else {
            None
        };
        if operation.transfer_status().is_some() {
            self.run_queued_transfer(operation, window, cx);
            return;
        }
        // An archive owns only its newly installed close hold. A verified
        // completion must restore any older unresolved target, not erase it.
        let archive_previous_isolation = matches!(
            &operation,
            Operation::TransferArchive(_) | Operation::PackServerArchive(_)
        )
        .then(|| self.isolation_target.clone());
        if let Some(target) = operation.isolation_target() {
            self.isolation_target = Some(target);
        }
        let recovery_spec = operation.recovery_spec();
        let is_transfer = recovery_spec.is_some();
        if let Some((spec, directory)) = recovery_spec {
            self.recovery = Some(RecoveryCandidate {
                persisted_id: operation.persisted_recovery_id(),
                session_token: self.session_token,
                spec,
                directory,
            });
        } else if let Operation::PlanPersistedRecovery {
            id,
            spec,
            directory,
        } = &operation
        {
            self.active_recovery_id = Some(*id);
            self.recovery = Some(RecoveryCandidate {
                persisted_id: Some(*id),
                session_token: self.session_token,
                spec: spec.clone(),
                directory: *directory,
            });
        } else if !matches!(
            &operation,
            Operation::PlanResume(..)
                | Operation::PlanPersistedRecovery { .. }
                | Operation::InspectArchiveTools(_)
                | Operation::PlanServerArchive(_)
                | Operation::InspectFileQuarantine(_)
                | Operation::InspectQuarantine(_)
                | Operation::AcknowledgeQuarantine(_)
        ) {
            // A browse/edit/mutation action is a new workflow; do not retain
            // a hidden recovery proposal after the user leaves its card.
            self.recovery = None;
        }
        if !matches!(
            &operation,
            Operation::Compare(..)
                | Operation::PlanDirectorySync(..)
                | Operation::InspectArchiveTools(_)
                | Operation::PlanServerArchive(_)
        ) {
            self.comparison = None;
        }
        if let Operation::List(path) = &operation
            && (path.trim().is_empty() || path.chars().any(char::is_control))
        {
            self.status = Message::new(
                "请输入不含控制字符的有效远程目录",
                "Enter a nonempty remote directory without control characters",
            );
            cx.notify();
            return;
        }
        if matches!(
            &operation,
            Operation::Compare(..) | Operation::PlanDirectorySync(..)
        ) {
            self.mirror_conflicts.clear();
        }
        if let Operation::ApplyDirectorySync(_, journal) = &operation {
            self.sync_journal = Some(journal.clone());
        }
        if matches!(&operation, Operation::List(_)) {
            // Admission retires the old selection even when the new directory
            // later fails or is cancelled. Rejected busy/invalid requests above
            // do not change the current browser selection.
            self.remote_selection.clear();
            self.selected = None;
            self.withdraw_browser_review();
        }
        if archive_probe.is_some() {
            self.begin_archive_probe();
        }
        self.busy = true;
        self.pending = None;
        self.confirmation_expanded = false;
        let operation_id = uuid::Uuid::new_v4();
        self.operation_id = Some(operation_id);
        if let Some(status) = operation.transfer_status() {
            self.transfer = Some(status);
        } else if !matches!(
            &operation,
            Operation::PlanResume(..)
                | Operation::PlanPersistedRecovery { .. }
                | Operation::InspectArchiveTools(_)
                | Operation::PlanServerArchive(_)
                | Operation::InspectFileQuarantine(_)
                | Operation::InspectQuarantine(_)
                | Operation::AcknowledgeQuarantine(_)
        ) {
            // Keep a failed transfer card visible while a recovery plan is
            // being checked; browsing or unrelated operations retire it.
            self.transfer = None;
        }
        self.status = match &operation {
            Operation::PlanDirectory(_) => Message::new(
                "正在扫描目录，完成后需确认…",
                "Scanning directory; confirmation is required before transfer…",
            ),
            Operation::PlanArchive(_) => Message::new(
                "正在只读准备归档和完整条目清单，完成后需审核…",
                "Preparing the archive and complete manifest read-only; review is required…",
            ),
            Operation::TransferArchive(_) => Message::new(
                "正在重新校验归档源并发布新目标…",
                "Revalidating archive sources and publishing the new destination…",
            ),
            Operation::InspectArchiveTools(_) => Message::new(
                "正在只读检测当前 SSH 会话的工具 PATH…",
                "Inspecting tool resolution in the current SSH session PATH…",
            ),
            Operation::PlanServerArchive(_) => Message::new(
                "正在服务器只读扫描完整归档源，完成后需再次审核…",
                "Inspecting all archive sources on the server read-only; another review is required…",
            ),
            Operation::PackServerArchive(_) => Message::new(
                "正在服务器重新核验、打包并完整读回新归档…",
                "Revalidating, packing and fully reading back the new server archive…",
            ),
            Operation::TransferDirectory(_) => Message::new(
                "正在复核已审核的目录…",
                "Rechecking the reviewed directory…",
            ),
            Operation::PlanResume(..) => Message::new(
                "正在只读校验源与已有部分内容，完成后需审核确认…",
                "Verifying the source and existing content without writing; review is required…",
            ),
            Operation::PlanPersistedRecovery { .. } => Message::new(
                "正在检查重启后传输记录，完成后需重新审核确认…",
                "Inspecting a post-restart transfer record; review is required again…",
            ),
            Operation::ResumeFile(_) | Operation::ResumeDirectory(_) => Message::new(
                "正在复核已审核的续传内容…",
                "Rechecking the reviewed continuation…",
            ),
            Operation::ResumePersistedFile(..) | Operation::ResumePersistedDirectory(..) => {
                Message::new(
                    "正在复核重启后传输记录对应的续传…",
                    "Rechecking the continuation from the post-restart record…",
                )
            }
            Operation::Compare(_, _) => Message::new(
                "正在读取两侧目录快照（只读）…",
                "Reading both directory snapshots (read-only)…",
            ),
            Operation::PlanDirectorySync(..) => Message::new(
                "正在读取两侧文件内容并生成审核计划（只读）…",
                "Reading both sides and generating a reviewable plan (read-only)…",
            ),
            Operation::ApplyDirectorySync(..) => Message::new(
                "正在复核审核快照并同步目录…",
                "Rechecking reviewed snapshots and synchronizing directories…",
            ),
            _ => Message::new("正在处理…", "Working…"),
        };
        let editor_before = self.editor.read(cx).value().to_string();
        let review_only = matches!(
            &operation,
            Operation::InspectFileQuarantine(_)
                | Operation::InspectQuarantine(_)
                | Operation::PlanResume(..)
                | Operation::PlanPersistedRecovery { .. }
                | Operation::PlanDirectory(_)
                | Operation::PlanBatch(_)
                | Operation::PlanArchive(_)
                | Operation::PlanServerArchive(_)
                | Operation::PlanDirectorySync(..)
        );
        let navigation_before = self.path.read(cx).value().to_string();
        let browser_review_revision = self.browser_review_revision;
        let recovery_review_revision = self.recovery_review_revision;
        let runtime = self.runtime.clone();
        let stop = Arc::new(AtomicBool::new(false));
        self.operation_stop = Some(stop.clone());
        let worker_stop = stop.clone();
        let (pause, pause_receiver) = tokio::sync::watch::channel(false);
        self.transfer_pause = self.transfer.as_ref().map(|_| pause);
        let (sender, receiver) = mpsc::sync_channel(16);
        #[cfg(test)]
        let fixture_group = self.fixture_group.clone();
        if let Err(error) = crate::terminal::spawn_owned_transport_worker(
            cx.entity_id(),
            "keelshell-sftp",
            stop,
            move || {
                #[cfg(test)]
                let _fixture_group = fixture_group;
                let result = runtime.block_on(operate(
                    session,
                    operation,
                    worker_stop,
                    pause_receiver,
                    &sender,
                    recovery_context,
                ));
                let completion = result.as_ref().map(|_| ()).map_err(ToString::to_string);
                let _ = sender.send(WorkerMessage::Result {
                    result: Box::new(result),
                    recovery_warning: None,
                });
                completion
            },
        ) {
            // A failed foreground start cannot release running queue jobs' guard.
            self.busy = self.has_active_transfers();
            self.operation_stop = None;
            self.operation_id = None;
            self.transfer_pause = None;
            if archive_probe.is_some() {
                self.fail_archive_probe();
            }
            if let Some(previous) = archive_previous_isolation {
                self.isolation_target = previous;
            }
            if is_transfer {
                self.recovery = None;
            }
            if is_transfer && let Some(transfer) = &mut self.transfer {
                transfer.phase = TransferPhase::Failed;
            }
            if persisted_recovery_id.is_some() {
                self.revoke_recovery_review();
            }
            self.status =
                Message::detail("无法启动文件工作线程", "Unable to start file worker", error);
            cx.notify();
            return;
        }
        let executor = cx.background_executor().clone();
        cx.spawn_in(window,async move |this,cx| {
            let (result, recovery_warning) = loop {
                match receiver.try_recv() {
                    Ok(WorkerMessage::Result {
                        result,
                        recovery_warning,
                    }) => break (*result, recovery_warning),
                    Ok(WorkerMessage::Progress(message)) => {
                        if this
                            .update_in(cx, |view, _, cx| {
                            if view.operation_id != Some(operation_id) { return; }
                            if !view.suspended && !view.transfer.as_ref().is_some_and(|state| matches!(state.phase,TransferPhase::Pausing|TransferPhase::Paused|TransferPhase::Resuming|TransferPhase::Cancelling)) {
                                view.status = message;
                            }
                            cx.notify();
                            })
                            .is_err()
                        {
                            return;
                        }
                    }
                    Ok(WorkerMessage::Transfer(event)) => {
                        if this.update_in(cx, |view, _, cx| {
                            if view.operation_id != Some(operation_id) { return; }
                            if let Some(transfer) = &mut view.transfer {
                                transfer.update(event);
                                if transfer.phase != TransferPhase::Cancelling {
                                    match event {
                                        TransferUpdate::Paused(..) => view.status = Message::new("传输已暂停；继续将使用原源路径、目标和 SSH 会话。", "Transfer paused; continuing preserves its source, destination and SSH session."),
                                        TransferUpdate::Resumed(..) => view.status = Message::new("正在继续原传输…", "Continuing the original transfer…"),
                                        _ => {}
                                    }
                                }
                            }
                            cx.notify();
                        }).is_err() { return; }
                    }
                    Err(mpsc::TryRecvError::Disconnected) => {
                        break (Err(FileFailure::WorkerStopped), None)
                    }
                    Err(mpsc::TryRecvError::Empty) => {},
                }
                executor.timer(Duration::from_millis(16)).await;
                if this.update_in(cx,|_,_,_|()).is_err() { return; }
            };
            let _ = this.update_in(cx,|view,window,cx| {
                if view.operation_id != Some(operation_id) { return; }
                view.busy = view.has_active_transfers();
                view.operation_stop = None;
                view.operation_id = None;
                view.transfer_pause = None;
                if let Some(probe) = &archive_probe {
                    view.finish_archive_probe(probe, result.is_err());
                }
                if let Some(previous) = archive_previous_isolation
                    && !archive::retains_close_hold(&result)
                {
                    view.isolation_target = previous;
                }
                if let Some(phase) = terminal_transfer_phase(is_transfer, &result)
                    && let Some(transfer) = &mut view.transfer
                {
                    transfer.phase = phase;
                }
                if view.suspended {
                    if persisted_recovery_id.is_some() {
                        view.revoke_recovery_review();
                    }
                    // A late worker may acknowledge a write, but may not replace the
                    // archived editor, its original baseline, or an approved plan.
                    let message = match &result {
                        Ok(_) => Message::new("旧会话任务已完成；保留归档内容。", "Previous session task completed; archived contents retained."),
                        Err(error) => Message::detail("旧会话任务结束", "Previous session task ended", error),
                    };
                    view.status = append_recovery_warning(message, recovery_warning.as_ref());
                    cx.notify();
                    return;
                }
                if let Err(FileFailure::MirrorConflicts(conflicts)) = &result { view.mirror_conflicts = conflicts.clone(); }
                if review_only && result.is_ok()
                    && (view.browser_review_revision != browser_review_revision
                        || (persisted_recovery_id.is_some()
                            && view.recovery_review_revision != recovery_review_revision)) {
                    // A read-only plan may finish after a local or remote draft
                    // changes. Retire its original result owner above, but do
                    // not recreate a proposal that navigation withdrew. Writes
                    // never enter this branch and retain their actual outcome.
                    if persisted_recovery_id.is_some() {
                        view.revoke_recovery_review();
                    }
                    view.status = Message::new("只读审核准备已完成，但路径或选择已变化；未采用旧计划，请重新准备。", "Read-only review preparation completed, but the path or selection changed; the old plan was not adopted. Prepare it again.");
                    cx.notify();
                    return;
                }
                let succeeded = result.is_ok();
                let keeps_recovery_claim = matches!(
                    &result,
                    Ok(
                        Outcome::PlannedPersistedFileResume { .. }
                            | Outcome::PlannedPersistedDirectoryResume { .. }
                    )
                );
                if persisted_recovery_id.is_some() && !keeps_recovery_claim {
                    view.revoke_recovery_review();
                }
                match result {
                    Ok(Outcome::Listed(path,entries)) => {
                        if view.path.read(cx).value().as_ref() == navigation_before.as_str() {
                            view.path.update(cx,|input,cx|input.set_value(path.clone(),window,cx));
                        }
                        view.directory = Some(path);
                        view.status = Message::new(format!("共 {} 项",entries.len()),format!("{} entries",entries.len()));
                        view.entries = entries;
                        view.selected = None;
                        view.remote_selection.clear();
                    }
                    Ok(Outcome::Read(snapshot, document)) => {
                        let path = snapshot.entry.path.clone();
                        let content = snapshot.content.clone();
                        if view.editor.read(cx).value().as_ref() == editor_before.as_str() {
                            view.editor.update(cx, |input, cx| {
                                input.set_highlighter(
                                    editor_language::language_for_path(&path),
                                    cx,
                                );
                                input.set_value(
                                    document.body().to_owned(),
                                    window,
                                    cx,
                                )
                            });
                            let description = text_format_description(document.format());
                            view.status = Message::new(format!("正在编辑 {path} · {} 字节 · {}",content.len(), description.0),format!("Editing {path} · {} bytes · {}",content.len(), description.1));
                            view.editing = Some((path,content));
                            view.editor_format = Some(document.format());
                            view.editor_reload_required = false;
                            view.editor_snapshot = Some(snapshot);
                            view.merge_review = None;
                            view.diff_preview = None;
                        } else {
                            view.status = Message::new("加载期间检测到新编辑，已保留当前内容；请在准备好后重新打开文件。", "Your edits changed while loading; preserved the editor. Open the file again when ready.");
                        }
                    }
                    Ok(Outcome::Saved {
                        snapshot,
                        backup,
                        format,
                        body,
                    }) => {
                        let path = snapshot.entry.path.clone();
                        let content = snapshot.content.clone();
                        if view.editing.as_ref().is_some_and(|(current,_)| current == &path) {
                            let current = view.editor.read(cx).value();
                            let dirty = !view.draft_matches_bytes(&current, &content);
                            let previous_format = view.editor_format.unwrap_or(format);
                            if !dirty && current.as_ref() != body {
                                view.editor.update(cx, |input, cx| input.set_value(body, window, cx));
                            }
                            view.editing = Some((path,content));
                            // Retained newer text still owns its original envelope.
                            // Only a canonical saved body can adopt the observed BOM.
                            view.editor_format = Some(if dirty {
                                previous_format
                            } else {
                                format.retain_insertion_policy(previous_format)
                            });
                            view.editor_snapshot = Some(snapshot);
                            view.merge_review = None;
                            view.diff_preview = None;
                            view.status = if dirty {
                                Message::new(
                                    format!("已保存审核版本；后续编辑尚未保存。原内容备份：{backup}"),
                                    format!("Saved the reviewed version; newer edits remain unsaved. Original backup: {backup}"),
                                )
                            } else {
                                Message::new(
                                    format!("远程文件已原子保存并完整读回。原内容备份：{backup}"),
                                    format!("Remote file atomically saved and fully read back. Original backup: {backup}"),
                                )
                            };
                        }
                    }
                    Ok(Outcome::MergeLoaded {snapshot, plan, base, draft}) => {
                        view.receive_merge(snapshot, plan, base, draft, window, cx);
                    }
                    Ok(Outcome::PatchApplied(path, original, result)) => {
                        if view.editing.as_ref().is_some_and(|(current,_)| current == &path)
                            && view.editor.read(cx).value().as_ref() == original.as_str() {
                            view.editor.update(cx, |input,cx|input.set_value(result,window,cx));
                            view.merge_review = None;
                            view.diff_preview = None;
                            view.status = Message::new("差异已精确应用到草稿；远端未写入，请审核最终全文。", "Patch applied exactly to the draft; remote unchanged. Review the complete result.");
                        } else { view.status = Message::new("解析期间草稿已变化，保留当前草稿；请重新预览差异。", "Draft changed during patch parsing; preserved it. Preview the patch again."); }
                    }
                    Ok(Outcome::Done(message)) => {
                        view.status = append_recovery_warning(message, recovery_warning.as_ref())
                    }
                    Ok(Outcome::QuarantineInspected(review)) => {
                        view.status = Message::new("只读检查完成；请审核解除隔离的未知风险", "Read-only inspection complete; review the risk before releasing isolation");
                        view.replace_pending_review(parallel::quarantine_review_message(&review), Operation::AcknowledgeQuarantine(review));
                    }
                    Ok(Outcome::PlannedBatch(plan)) => {
                        view.status = Message::new("批量只读准备完成，请审核每个目标。", "Read-only batch preparation completed; review every target.");
                        view.confirm(plan.review_message(), Operation::TransferBatch(plan), cx);
                    }
                    Ok(Outcome::PlannedArchive(plan)) => {
                        if view.archive_plan_is_current(&plan, cx) {
                            view.status = Message::new("归档准备完成，请审核完整清单及新目标。", "Archive prepared; review the complete manifest and new destination.");
                            view.confirm(plan.review_message(), Operation::TransferArchive(plan), cx);
                        } else {
                            view.status = archive::expired_message();
                        }
                    }
                    Ok(Outcome::PlannedServerArchive(plan)) => {
                        if view.server_archive_plan_is_current(&plan, cx) {
                            view.status = Message::new("服务器归档只读扫描完成，请审核完整清单、命令与标准输入。", "Read-only server inspection completed; review the complete manifest, command and standard input.");
                            view.confirm(plan.review_message(), Operation::PackServerArchive(plan), cx);
                        } else {
                            view.status = archive::expired_message();
                        }
                    }
                    Ok(Outcome::ArchiveTools(probe, report)) => {
                        view.receive_archive_tools(probe, report, cx);
                    }
                    Ok(Outcome::PlannedDirectory(plan)) => {
                        view.status = Message::new("扫描完成，请审核目录传输", "Scan complete; review the directory transfer");
                        view.replace_pending_review(directory_review_message(&plan), Operation::TransferDirectory(plan));
                    }
                    Ok(Outcome::PlannedFileResume(plan)) => {
                        view.status = Message::new("部分内容校验通过，请审核续传", "Existing content verified; review continuation");
                        view.replace_pending_review(resume_review_message(plan.direction(), plan.local_path(), plan.remote_path(), plan.bytes(), plan.existing_bytes(), None), Operation::ResumeFile(plan));
                    }
                    Ok(Outcome::PlannedDirectoryResume(plan)) => {
                        view.status = Message::new("部分目录校验通过，请审核续传", "Existing tree verified; review continuation");
                        view.replace_pending_review(resume_review_message(plan.direction(), plan.local_path(), plan.remote_path(), plan.bytes(), plan.existing_bytes(), Some((plan.files(),plan.directories()))), Operation::ResumeDirectory(plan));
                    }
                    Ok(Outcome::PlannedPersistedFileResume {
                        id,
                        plan,
                        recovery_claim,
                    }) => {
                        let Some(connection_bound) =
                            persisted_recovery_is_bound(&view.recovery_records, id)
                        else {
                            view.revoke_recovery_review();
                            view.status = Message::new(
                                "恢复记录已消失，已拒绝继续；请重新加载文件面板。",
                                "The recovery record disappeared; continuation was refused. Reload the file panel.",
                            );
                            cx.notify();
                            return;
                        };
                        if let Err(error) = view.apply_persisted_recovery_progress(
                            id,
                            plan.existing_bytes(),
                            plan.bytes(),
                            window,
                            cx,
                        ) {
                            view.revoke_recovery_review();
                            view.status = Message::new(
                                format!("恢复计划进度无法保留：{error}"),
                                format!("The recovery plan progress could not be retained: {error}"),
                            );
                            cx.notify();
                            return;
                        }
                        view.recovery_claim = Some(recovery_claim);
                        view.status = Message::new(
                            "重启后记录校验通过，请重新审核续传",
                            "Post-restart record verified; review the continuation again",
                        );
                        view.active_recovery_id = Some(id);
                        view.replace_pending_review(
                            persisted_resume_review_message(
                                plan.direction(),
                                plan.local_path(),
                                plan.remote_path(),
                                plan.bytes(),
                                plan.existing_bytes(),
                                None,
                                &view.host,
                                connection_bound,
                            ),
                            Operation::ResumePersistedFile(id, plan),
                        );
                    }
                    Ok(Outcome::PlannedPersistedDirectoryResume {
                        id,
                        plan,
                        recovery_claim,
                    }) => {
                        let Some(connection_bound) =
                            persisted_recovery_is_bound(&view.recovery_records, id)
                        else {
                            view.revoke_recovery_review();
                            view.status = Message::new(
                                "恢复记录已消失，已拒绝继续；请重新加载文件面板。",
                                "The recovery record disappeared; continuation was refused. Reload the file panel.",
                            );
                            cx.notify();
                            return;
                        };
                        if let Err(error) = view.apply_persisted_recovery_progress(
                            id,
                            plan.existing_bytes(),
                            plan.bytes(),
                            window,
                            cx,
                        ) {
                            view.revoke_recovery_review();
                            view.status = Message::new(
                                format!("恢复计划进度无法保留：{error}"),
                                format!("The recovery plan progress could not be retained: {error}"),
                            );
                            cx.notify();
                            return;
                        }
                        view.recovery_claim = Some(recovery_claim);
                        view.status = Message::new(
                            "重启后目录记录校验通过，请重新审核续传",
                            "Post-restart directory record verified; review the continuation again",
                        );
                        view.active_recovery_id = Some(id);
                        view.replace_pending_review(
                            persisted_resume_review_message(
                                plan.direction(),
                                plan.local_path(),
                                plan.remote_path(),
                                plan.bytes(),
                                plan.existing_bytes(),
                                Some((plan.files(), plan.directories())),
                                &view.host,
                                connection_bound,
                            ),
                            Operation::ResumePersistedDirectory(id, plan),
                        );
                    }
                    Ok(Outcome::Compared(comparison)) => {
                        let review_count = comparison.report.review_count();
                        view.comparison = Some(DirectoryComparison {
                            local: comparison.local,
                            remote: comparison.remote,
                            report: comparison.report,
                            sync_plan: None,
                        });
                        view.status = if review_count == 0 {
                            Message::new("两侧目录已按可用元数据匹配", "The directories match on available metadata")
                        } else {
                            Message::new(
                                format!("目录比较完成：{review_count} 项需要审核"),
                                format!("Directory comparison complete: {review_count} entries need review"),
                            )
                        };
                    }
                    Ok(Outcome::DirectorySyncPlanned(comparison)) => {
                        let operation_count = comparison.plan.operation_count();
                        view.comparison = Some(DirectoryComparison {
                            local: comparison.local,
                            remote: comparison.remote,
                            report: comparison.report,
                            sync_plan: Some(comparison.plan),
                        });
                        view.status = Message::new(
                            format!("内容校验完成：已生成 {operation_count} 项审核计划；当前仅预览，不会写入"),
                            format!("Content verification complete: {operation_count} reviewed operations; preview only, nothing was written"),
                        );
                    }
                    Err(FileFailure::EditorFormatChanged) => {
                        view.editor_reload_required = true;
                        view.merge_review = None;
                        view.status = FileFailure::EditorFormatChanged.message();
                    }
                    Err(error) => {
                        let message = if review_only {
                            Message::detail(
                                "审核未完成，尚未开始传输",
                                "Review incomplete; transfer not started",
                                error,
                            )
                        } else {
                            error.message()
                        };
                        view.status = append_recovery_warning(message, recovery_warning.as_ref());
                    }
                }
                if is_transfer && succeeded {
                    // A completed transfer has no recovery action. Failed or
                    // cancelled transfers retain the proposal for an explicit
                    // user-triggered verification step.
                    view.recovery = None;
                }
                cx.notify();
            });
        }).detach();
        cx.notify();
    }
    fn remote_child(&mut self, name: &str) -> Option<String> {
        match child_path(self.directory.as_deref(), name) {
            Ok(path) => Some(path),
            Err(error) => {
                self.status = error.message();
                None
            }
        }
    }
    fn new_remote_path(&mut self, cx: &Context<Self>) -> Option<String> {
        let name = self.name.read(cx).value().trim().to_owned();
        self.remote_child(&name)
    }
    fn request_read(&mut self, entry: RemoteEntry, window: &mut Window, cx: &mut Context<Self>) {
        let dirty = self.editing.as_ref().is_some_and(|(_, original)| {
            !self.draft_matches_bytes(&self.editor.read(cx).value(), original)
        });
        if dirty {
            self.confirm(
                Message::new(
                    format!("放弃未保存的编辑并打开 {}？", entry.path),
                    format!("Discard unsaved edits and open {}?", entry.path),
                ),
                Operation::Read(entry),
                cx,
            );
        } else {
            self.run(Operation::Read(entry), window, cx);
        }
    }
    fn confirm(&mut self, message: Message, operation: Operation, cx: &mut Context<Self>) {
        if self.suspended {
            return;
        }
        if self.operation_id.is_some() || (self.busy && !operation.can_run_beside_transfers()) {
            self.status = Message::new(
                "请等待或取消当前文件操作",
                "Wait for or cancel the active file operation",
            );
        } else {
            self.replace_pending_review(message, operation);
        }
        cx.notify();
    }
    fn replace_pending_review(&mut self, message: Message, operation: Operation) {
        // Each proposal needs fresh approval, even when two non-batch actions
        // have identical text or replace one another before the next frame.
        let keep_recovery_claim = operation
            .persisted_recovery_id()
            .zip(self.active_recovery_id)
            .is_some_and(|(operation_id, active_id)| operation_id == active_id);
        if !keep_recovery_claim {
            self.revoke_recovery_review();
        }
        self.pending_review_id = uuid::Uuid::new_v4();
        self.confirmation_scroll.set_offset(point(px(0.), px(0.)));
        self.confirmation_expanded = false;
        self.editor_surface = None;
        self.pending = Some((message, operation));
    }
    fn execute_pending(&mut self, window: &mut Window, cx: &mut Context<Self>) {
        if self.suspended {
            return;
        }
        if self.operation_id.is_some()
            || (self.busy
                && self
                    .pending
                    .as_ref()
                    .is_none_or(|(_, operation)| !operation.can_run_beside_transfers()))
        {
            return;
        }
        if let Some((_, Operation::Save { content, .. })) = &self.pending
            && !self.draft_matches_bytes(&self.editor.read(cx).value(), content)
        {
            self.pending = None;
            self.confirmation_expanded = false;
            self.status = Message::new(
                "审核后内容已修改，请重新审核再保存。",
                "Editor changed after review. Review the new contents before saving.",
            );
            cx.notify();
            return;
        }
        if let Some((_, operation)) = self.pending.take() {
            self.confirmation_expanded = false;
            if let Operation::DiscardPersistedRecoveryBatch(candidates) = operation {
                self.start_batch_discard(candidates, window, cx);
            } else {
                self.run(operation, window, cx);
            }
        }
    }

    fn request_sync_review(&mut self, cx: &mut Context<Self>) {
        if self.busy || self.suspended || self.pending.is_some() {
            return;
        }
        let Some(comparison) = &self.comparison else {
            return;
        };
        let Some(plan) = &comparison.sync_plan else {
            return;
        };
        let review = DirectorySyncComparison {
            local: comparison.local.clone(),
            remote: comparison.remote.clone(),
            report: comparison.report.clone(),
            plan: plan.clone(),
        };
        match sync::review_message(&review) {
            Ok(message) => {
                let journal = Arc::new(std::sync::Mutex::new(sync::journal::Journal::new(
                    &review.plan,
                )));
                self.confirm(
                    message,
                    Operation::ApplyDirectorySync(Box::new(review), journal),
                    cx,
                )
            }
            Err(error) => {
                self.status = error.message();
                cx.notify();
            }
        }
    }

    /// Build a bounded, read-only unified diff for the current remote-file draft.
    /// The preview never sends data or mutates the remote file; saving still requires
    /// the existing explicit review confirmation.
    fn toggle_diff_preview(&mut self, cx: &mut Context<Self>) {
        if self.diff_preview.is_some() {
            self.diff_preview = None;
            self.status = Message::new("已隐藏差异预览", "Diff preview hidden");
            cx.notify();
            return;
        }
        let Some((path, original)) = self.editing.as_ref() else {
            self.status = Message::new("请先打开远程文件", "Open a remote file first");
            cx.notify();
            return;
        };
        let draft = self.editor.read(cx).value();
        let draft = match self.prepare_editor_bytes(&draft) {
            Ok(bytes) => bytes,
            Err(error) => {
                self.status = error.message();
                cx.notify();
                return;
            }
        };
        self.diff_preview_scroll.set_offset(point(px(0.), px(0.)));
        let Some(format) = self.editor_format else {
            self.status = FileFailure::InvalidEditor.message();
            cx.notify();
            return;
        };
        let original = match format.decode_body(original) {
            Ok(body) => body,
            Err(error) => {
                self.status = FileFailure::TextDocument(error).message();
                cx.notify();
                return;
            }
        };
        let draft = match format.decode_body(&draft) {
            Ok(body) => body,
            Err(error) => {
                self.status = FileFailure::TextDocument(error).message();
                cx.notify();
                return;
            }
        };
        match keelshell_core::diff_text(&original, &draft) {
            Ok(diff) => {
                match diff.render(&format!("{path} (remote)"), &format!("{path} (draft)")) {
                    Ok(rendered) if rendered.is_empty() && original == draft => {
                        self.diff_preview = Some("（当前草稿与读取的基线字节相同）\n(The draft is byte-identical to the captured baseline.)".into());
                        self.status = Message::new(
                            "当前草稿与读取的基线字节相同",
                            "The draft is byte-identical to the captured baseline",
                        );
                    }
                    Ok(rendered) if rendered.is_empty() => {
                        self.diff_preview = Some("（逻辑行相同，字节仍不同；此预览将 CRLF/LF 视为相同。请在保存审核中核对最终全文。）\n(Logical lines match, but bytes still differ; this preview treats CRLF/LF equally. Review the complete final text before saving.)".into());
                        self.status = Message::new(
                            "逻辑行相同，字节仍不同；请核对最终全文",
                            "Logical lines match, but bytes still differ; review the complete final text",
                        );
                    }
                    Ok(rendered) if rendered.len() <= 128 * 1024 => {
                        self.diff_preview = Some(format!("逻辑行预览（CRLF/LF 视为相同）；不是可直接应用的精确字节补丁。\nLogical-line preview (CRLF/LF treated equally); not an exact byte patch.\n{rendered}").into());
                        self.status = Message::new(
                            "差异已生成，请核对后再保存",
                            "Diff generated; review it before saving",
                        );
                    }
                    Ok(_) => {
                        self.status = Message::new(
                            "差异预览超过 128 KiB，请缩小编辑范围后再查看",
                            "Diff preview exceeds 128 KiB; narrow the edit before viewing",
                        );
                    }
                    Err(error) => {
                        self.status = Message::new(
                            format!("无法生成差异：{error}"),
                            format!("Unable to generate diff: {error}"),
                        );
                    }
                }
            }
            Err(error) => {
                self.status = Message::new(
                    format!("无法生成差异：{error}"),
                    format!("Unable to generate diff: {error}"),
                );
            }
        }
        cx.notify();
    }

    /// Start a fresh, read-only continuation plan after explicit user action.
    /// This never reuses a stale resume plan and cannot cross a session token.
    pub(super) fn can_offer_recovery(&self) -> bool {
        let candidate = self.recovery.as_ref();
        let record_loaded = candidate
            .and_then(|candidate| candidate.persisted_id)
            .is_none_or(|id| self.recovery_records.iter().any(|record| record.id == id));
        record_loaded
            && !self.recovery_loading
            && recovery_is_available(
                candidate,
                self.session_token,
                self.suspended,
                self.busy,
                self.pending.is_some(),
                self.transfer.as_ref().map(|transfer| transfer.phase),
            )
    }

    pub(super) fn request_recovery(&mut self, window: &mut Window, cx: &mut Context<Self>) {
        let Some(candidate) = self.recovery.as_ref() else {
            return;
        };
        let session_valid = !self.suspended
            && self.session.is_some()
            && candidate.session_token == self.session_token;
        let phase = self.transfer.as_ref().map(|transfer| transfer.phase);
        let allowed = recovery_request_is_allowed(
            Some(candidate),
            self.session_token,
            self.session.is_some(),
            self.suspended,
            self.busy,
            self.pending.is_some(),
            phase,
        );
        if !allowed {
            if !session_valid || phase != Some(TransferPhase::Failed) {
                self.recovery = None;
            }
            self.status = Message::new(
                if self.busy {
                    "当前文件操作仍在进行，请等待完成后再恢复"
                } else if self.pending.is_some() {
                    "当前操作仍待审核，请先处理审核栏"
                } else {
                    "恢复建议已失效，请在当前 SSH 会话中重新选择源和目标"
                },
                if self.busy {
                    "A file operation is still running; wait before recovery"
                } else if self.pending.is_some() {
                    "An operation is awaiting review; handle the review bar first"
                } else {
                    "The recovery proposal is stale; choose the source and destination again in the current SSH session"
                },
            );
            cx.notify();
            return;
        }
        if let Some(id) = candidate.persisted_id {
            if !self.recovery_records.iter().any(|record| record.id == id) {
                self.status = Message::new(
                    "恢复记录仍在加载，请稍后重试。",
                    "The recovery record is still loading; try again shortly.",
                );
                cx.notify();
                return;
            }
            self.request_persisted_recovery(id, window, cx);
            return;
        }
        let spec = candidate.spec.clone();
        let directory = candidate.directory;
        self.status = Message::new(
            "正在准备新的续传校验；确认后才会写入目标",
            "Preparing a new continuation check; nothing will be written until you confirm",
        );
        self.run(Operation::PlanResume(spec, directory), window, cx);
    }
}

fn directory_review_message(plan: &DirectoryTransferPlan) -> Message {
    let (source, target) = match plan.direction() {
        TransferDirection::Upload => (
            plan.local_path().display().to_string(),
            plan.remote_path().to_owned(),
        ),
        TransferDirection::Download => (
            plan.remote_path().to_owned(),
            plan.local_path().display().to_string(),
        ),
    };
    Message::new(
        format!(
            "源：{source}\n目标：{target}\n{} 个文件 · {} 个目录 · {} 字节。仅新建目标，不跟随符号链接。\n上限：32 层 / 10000 项 / 16 GiB / 15 分钟。取消或失败会保留部分目录；确认传输？",
            plan.files(),
            plan.directories(),
            plan.bytes()
        ),
        format!(
            "Source: {source}\nDestination: {target}\n{} files · {} directories · {} bytes. New destination only; symlinks are refused.\nLimits: 32 levels / 10000 entries / 16 GiB / 15 minutes. Failure or cancellation leaves a partial tree. Transfer?",
            plan.files(),
            plan.directories(),
            plan.bytes()
        ),
    )
}

fn resume_review_message(
    direction: TransferDirection,
    local: &std::path::Path,
    remote: &str,
    total: u64,
    existing: u64,
    tree: Option<(usize, usize)>,
) -> Message {
    let (source, target) = match direction {
        TransferDirection::Upload => (local.display().to_string(), remote.to_owned()),
        TransferDirection::Download => (remote.to_owned(), local.display().to_string()),
    };
    let counts_en = tree.map_or_else(String::new, |(files, dirs)| {
        format!("{files} files / {dirs} directories · ")
    });
    let counts_zh = tree.map_or_else(String::new, |(files, dirs)| {
        format!("{files} 个文件 / {dirs} 个目录 · ")
    });
    Message::new(
        format!(
            "续传源：{source}\n续传目标：{target}\n{counts_zh}已校验部分 {existing} / {total} 字节；待补充 {} 字节。\n仅在已有内容与源一致时追加；执行前会重新校验，不覆盖不同内容。取消或失败可保留部分目标。确认续传？",
            total.saturating_sub(existing)
        ),
        format!(
            "Resume source: {source}\nResume destination: {target}\n{counts_en}Verified existing content: {existing} / {total} bytes; {} bytes remain.\nAppend only when existing content matches the source; rechecked before writing. Different content is never overwritten. Cancellation or failure may leave partial output. Continue?",
            total.saturating_sub(existing)
        ),
    )
}

#[allow(clippy::too_many_arguments)]
fn persisted_resume_review_message(
    direction: TransferDirection,
    local: &std::path::Path,
    remote: &str,
    total: u64,
    existing: u64,
    tree: Option<(usize, usize)>,
    host: &str,
    connection_bound: bool,
) -> Message {
    let base = resume_review_message(direction, local, remote, total, existing, tree);
    let (base_zh, base_en) = base.translations();
    let (host_zh, host_en) = if connection_bound {
        (
            format!(
                "当前 SSH 会话：{host}。记录已绑定当前保存连接；请确认该会话仍对应原目标主机后再确认续传。"
            ),
            format!(
                "Current SSH session: {host}. The record is bound to the current saved connection; confirm that this session still reaches the original target host before continuing."
            ),
        )
    } else {
        (
            format!(
                "当前 SSH 会话：{host}。这条记录没有保存连接身份；请明确确认当前 SSH 主机就是原目标主机。确认前不会写入。"
            ),
            format!(
                "Current SSH session: {host}. This record has no saved connection identity; explicitly confirm that the current SSH host is the original target. Nothing is written before confirmation."
            ),
        )
    };
    Message::new(
        format!("{host_zh}\n\n{base_zh}"),
        format!("{host_en}\n\n{base_en}"),
    )
}

impl Operation {
    fn isolation_target(&self) -> Option<IsolationTarget> {
        match self {
            Self::Mkdir(path) | Self::Save { path, .. } => {
                Some(IsolationTarget::Remote(path.clone()))
            }
            Self::Rename(from, _) => Some(IsolationTarget::Remote(from.clone())),
            Self::Delete(entry) | Self::SetPermissions(entry, _) => {
                Some(IsolationTarget::Remote(entry.path.clone()))
            }
            Self::TransferArchive(plan) => Some(plan.isolation_target()),
            Self::PackServerArchive(plan) => Some(plan.isolation_target()),
            Self::ApplyDirectorySync(review, _) => Some(
                if review.plan.direction() == DirectorySyncDirection::LeftToRight {
                    IsolationTarget::Remote(review.remote.clone())
                } else {
                    IsolationTarget::Local(review.local.clone())
                },
            ),
            _ => None,
        }
    }
    fn can_run_beside_transfers(&self) -> bool {
        self.recovery_spec().is_some()
            || matches!(
                self,
                Self::InspectFileQuarantine(_)
                    | Self::InspectQuarantine(_)
                    | Self::AcknowledgeQuarantine(_)
                    | Self::List(_)
                    | Self::Read(_)
                    | Self::ReadMerge { .. }
                    | Self::ApplyPatchToDraft { .. }
                    | Self::PlanDirectory(_)
                    | Self::PlanBatch(_)
                    | Self::PlanArchive(_)
                    | Self::PlanServerArchive(_)
                    | Self::InspectArchiveTools(_)
                    | Self::TransferBatch(_)
                    | Self::PlanResume(..)
                    | Self::PlanPersistedRecovery { .. }
                    | Self::DiscardPersistedRecoveryBatch(_)
                    | Self::Compare(..)
                    | Self::PlanDirectorySync(..)
            )
    }

    fn persisted_recovery_id(&self) -> Option<uuid::Uuid> {
        match self {
            Self::PlanPersistedRecovery { id, .. }
            | Self::ResumePersistedFile(id, _)
            | Self::ResumePersistedDirectory(id, _) => Some(*id),
            _ => None,
        }
    }

    /// Derive a fresh continuation request only from an operation that already
    /// performed transfer I/O. Review-only plans intentionally return `None`.
    fn recovery_spec(&self) -> Option<(TransferSpec, bool)> {
        match self {
            Self::TransferFile(plan) => Some((
                TransferSpec {
                    local: plan.local_path().to_owned(),
                    remote: plan.remote_path().to_owned(),
                    direction: plan.direction(),
                },
                false,
            )),
            Self::Upload(local, remote) => Some((TransferSpec::upload(local, remote), false)),
            Self::Download(remote, local) => Some((TransferSpec::download(remote, local), false)),
            Self::TransferDirectory(plan) => Some((
                TransferSpec {
                    local: plan.local_path().to_owned(),
                    remote: plan.remote_path().to_owned(),
                    direction: plan.direction(),
                },
                true,
            )),
            Self::ResumeFile(plan) => Some((
                TransferSpec {
                    local: plan.local_path().to_owned(),
                    remote: plan.remote_path().to_owned(),
                    direction: plan.direction(),
                },
                false,
            )),
            Self::ResumeDirectory(plan) => Some((
                TransferSpec {
                    local: plan.local_path().to_owned(),
                    remote: plan.remote_path().to_owned(),
                    direction: plan.direction(),
                },
                true,
            )),
            Self::ResumePersistedFile(_, plan) => Some((
                TransferSpec {
                    local: plan.local_path().to_owned(),
                    remote: plan.remote_path().to_owned(),
                    direction: plan.direction(),
                },
                false,
            )),
            Self::ResumePersistedDirectory(_, plan) => Some((
                TransferSpec {
                    local: plan.local_path().to_owned(),
                    remote: plan.remote_path().to_owned(),
                    direction: plan.direction(),
                },
                true,
            )),
            Self::InspectFileQuarantine(_)
            | Self::InspectQuarantine(_)
            | Self::AcknowledgeQuarantine(_)
            | Self::List(_)
            | Self::Read(_)
            | Self::ReadMerge { .. }
            | Self::ApplyPatchToDraft { .. }
            | Self::Mkdir(_)
            | Self::Rename(_, _)
            | Self::Delete(_)
            | Self::SetPermissions(_, _)
            | Self::PlanDirectory(_)
            | Self::PlanBatch(_)
            | Self::TransferBatch(_)
            | Self::PlanArchive(_)
            | Self::TransferArchive(_)
            | Self::InspectArchiveTools(_)
            | Self::PlanServerArchive(_)
            | Self::PackServerArchive(_)
            | Self::PlanResume(..)
            | Self::PlanPersistedRecovery { .. }
            | Self::DiscardPersistedRecoveryBatch(_)
            | Self::Compare(..)
            | Self::ApplyDirectorySync(..)
            | Self::PlanDirectorySync(..)
            | Self::Save { .. } => None,
        }
    }

    fn transfer_status(&self) -> Option<TransferStatus> {
        let (spec, directory, continuation) = match self {
            Self::TransferFile(plan) => (
                TransferSpec {
                    local: plan.local_path().to_owned(),
                    remote: plan.remote_path().to_owned(),
                    direction: plan.direction(),
                },
                false,
                false,
            ),
            Self::Upload(local, remote) => (TransferSpec::upload(local, remote), false, false),
            Self::Download(remote, local) => (TransferSpec::download(remote, local), false, false),
            Self::TransferDirectory(plan) => (
                TransferSpec {
                    local: plan.local_path().to_owned(),
                    remote: plan.remote_path().to_owned(),
                    direction: plan.direction(),
                },
                true,
                false,
            ),
            Self::ResumeFile(plan) => (
                TransferSpec {
                    local: plan.local_path().to_owned(),
                    remote: plan.remote_path().to_owned(),
                    direction: plan.direction(),
                },
                false,
                true,
            ),
            Self::ResumeDirectory(plan) => (
                TransferSpec {
                    local: plan.local_path().to_owned(),
                    remote: plan.remote_path().to_owned(),
                    direction: plan.direction(),
                },
                true,
                true,
            ),
            Self::ResumePersistedFile(_, plan) => (
                TransferSpec {
                    local: plan.local_path().to_owned(),
                    remote: plan.remote_path().to_owned(),
                    direction: plan.direction(),
                },
                false,
                true,
            ),
            Self::ResumePersistedDirectory(_, plan) => (
                TransferSpec {
                    local: plan.local_path().to_owned(),
                    remote: plan.remote_path().to_owned(),
                    direction: plan.direction(),
                },
                true,
                true,
            ),
            _ => return None,
        };
        let mut status = TransferStatus::new(spec, directory, continuation);
        status.reviewed_existing = match self {
            Self::ResumeFile(plan) | Self::ResumePersistedFile(_, plan) => plan.existing_bytes(),
            Self::ResumeDirectory(plan) | Self::ResumePersistedDirectory(_, plan) => {
                plan.existing_bytes()
            }
            _ => 0,
        };
        Some(status)
    }
}

fn text_format_description(format: TextFormat) -> (String, String) {
    let (zh, en) = match format.line_ending() {
        TextLineEnding::None => ("无换行；新增使用 LF", "no line breaks; new breaks use LF"),
        TextLineEnding::Lf => ("LF", "LF"),
        TextLineEnding::CrLf => ("CRLF", "CRLF"),
        TextLineEnding::Cr => ("孤立 CR（原样保持）", "standalone CR (verbatim)"),
        TextLineEnding::Mixed => ("混合换行（原样保持）", "mixed line endings (verbatim)"),
    };
    (
        format!(
            "{}；BOM：{}；换行：{zh}",
            format.encoding().name(),
            if format.has_bom() { "有" } else { "无" }
        ),
        format!(
            "{}; BOM: {}; line endings: {en}",
            format.encoding().name(),
            if format.has_bom() { "yes" } else { "no" }
        ),
    )
}

fn size_label(size: Option<u64>) -> String {
    let Some(size) = size else {
        return "—".into();
    };
    if size < 1024 {
        return format!("{size} B");
    }
    if size < 1024 * 1024 {
        return format!("{:.1} KiB", size as f64 / 1024.);
    }
    if size < 1024 * 1024 * 1024 {
        return format!("{:.1} MiB", size as f64 / (1024. * 1024.));
    }
    format!("{:.1} GiB", size as f64 / (1024. * 1024. * 1024.))
}
fn permissions_label(entry: &RemoteEntry) -> String {
    let Some(mode) = entry.permissions else {
        return "—".into();
    };
    let mut chars = vec![if entry.is_symlink {
        'l'
    } else if entry.is_directory {
        'd'
    } else {
        '-'
    }];
    for (index, bit) in [
        0o400, 0o200, 0o100, 0o040, 0o020, 0o010, 0o004, 0o002, 0o001,
    ]
    .into_iter()
    .enumerate()
    {
        chars.push(if mode & bit != 0 {
            ['r', 'w', 'x'][index % 3]
        } else {
            '-'
        });
    }
    for (index, flag, marked, unmarked) in [
        (3, 0o4000, 's', 'S'),
        (6, 0o2000, 's', 'S'),
        (9, 0o1000, 't', 'T'),
    ] {
        if mode & flag != 0 {
            chars[index] = if chars[index] == 'x' {
                marked
            } else {
                unmarked
            };
        }
    }
    chars.into_iter().collect()
}
fn modified_label(timestamp: Option<u32>) -> String {
    timestamp
        .and_then(|value| chrono::DateTime::from_timestamp(i64::from(value), 0))
        .map(|value| value.format("%Y/%m/%d %H:%M").to_string())
        .unwrap_or_else(|| "—".into())
}
fn type_label(entry: &RemoteEntry, cx: &App) -> &'static str {
    if entry.is_symlink {
        t(cx, "符号链接", "Link")
    } else if entry.is_directory {
        t(cx, "文件夹", "Folder")
    } else {
        t(cx, "文件", "File")
    }
}
fn table_cell(text: impl Into<SharedString>, width: f32) -> impl IntoElement {
    div()
        .w(px(width))
        .flex_shrink_0()
        .px_2()
        .overflow_hidden()
        .child(text.into())
}

fn confirmation_bar(
    cx: &App,
    message: String,
    scroll: &ScrollHandle,
    expand: Button,
    confirm: Button,
    cancel: Button,
) -> impl IntoElement {
    let visual = crate::design::palette(cx);
    div()
        .id("file-confirmation-bar")
        .w_full()
        .min_w_0()
        .px_2()
        .py_0()
        .flex_shrink_0()
        .flex()
        .items_center()
        .gap_2()
        .bg(rgb(visual.danger_surface))
        .border_t_1()
        .border_color(rgb(visual.danger_border))
        .child(review::confirmation_text(cx, &message, scroll, false))
        // Expansion is presentation only. The pending reviewed operation is
        // unchanged, and its original fixed actions remain reachable here.
        .child(
            div()
                .flex()
                .flex_shrink_0()
                .items_center()
                .gap_2()
                .child(expand)
                .child(confirm)
                .child(cancel),
        )
        .test_support()
}

#[cfg(test)]
mod tests {
    #![allow(clippy::expect_used, clippy::unwrap_used)]

    use super::{
        FileFailure, Operation, Outcome, RecoveryCandidate, TransferDirection, TransferPhase,
        TransferRecoveryWriter, child_path, modified_label, parse_permissions_mode,
        permissions_label, persisted_recovery_is_bound, persisted_resume_review_message,
        recovery_connection_matches, recovery_is_available, recovery_load_is_current,
        recovery_record_for, recovery_request_is_allowed, size_label, terminal_transfer_phase,
        transfer_progress_message, update_persisted_recovery_progress,
    };
    use keelshell_core::{
        TransferRecoveryDirection, TransferRecoveryRecord, TransferRecoveryState,
        TransferRecoveryStore,
    };
    use keelshell_session::sftp::RemoteEntry;
    use std::sync::Arc;
    use tempfile::TempDir;

    #[test]
    fn mutation_requires_a_loaded_absolute_directory() {
        for directory in [
            None,
            Some(""),
            Some("."),
            Some("draft/relative"),
            Some("/bad\npath"),
        ] {
            assert!(child_path(directory, "notes.txt").is_err());
        }
        assert_eq!(
            child_path(Some("/home/operator"), "notes.txt"),
            Ok("/home/operator/notes.txt".to_owned())
        );
    }

    #[test]
    fn remote_child_keeps_root_and_unicode_names_literal() {
        assert_eq!(
            child_path(Some("/"), "说明.txt"),
            Ok("/说明.txt".to_owned())
        );
        assert_eq!(
            child_path(Some("/var/log/"), "app log.txt"),
            Ok("/var/log/app log.txt".to_owned())
        );
        assert_eq!(
            child_path(Some("/tmp"), "$(command); file"),
            Ok("/tmp/$(command); file".to_owned())
        );
    }

    #[test]
    fn remote_child_rejects_traversal_and_display_control_characters() {
        for name in [
            "",
            ".",
            "..",
            "../victim",
            "one/two",
            "one\\two",
            "bad\0name",
            "bad\nname",
            "\u{1b}[2J",
        ] {
            assert!(
                child_path(Some("/home/operator"), name).is_err(),
                "{name:?}"
            );
        }
    }

    #[test]
    fn stale_recovery_load_cannot_replace_a_newer_session_or_generation() {
        let session = uuid::Uuid::new_v4();
        assert!(recovery_load_is_current(session, session, 7, 7, 3, 3));
        assert!(!recovery_load_is_current(session, session, 6, 7, 3, 3));
        assert!(!recovery_load_is_current(session, session, 7, 7, 2, 3));
        assert!(!recovery_load_is_current(
            session,
            uuid::Uuid::new_v4(),
            7,
            7,
            3,
            3,
        ));
    }

    #[test]
    fn permission_input_is_strict_octal_without_symbolic_or_shell_syntax() {
        assert_eq!(parse_permissions_mode("0640"), Ok(0o640));
        assert_eq!(parse_permissions_mode("640"), Ok(0o640));
        for value in ["", "64", "06400", "0780", "u+rw", "$(id)", " 0640x"] {
            assert!(parse_permissions_mode(value).is_err(), "{value:?}");
        }
    }

    #[test]
    fn recovery_candidate_is_derived_only_from_started_transfer_operations() {
        let spec =
            keelshell_session::sftp::TransferSpec::upload("/tmp/source.txt", "/srv/source.txt");
        let candidate = Operation::Upload(spec.local.clone(), spec.remote.clone()).recovery_spec();
        assert!(candidate.is_some());
        let Some((recovery, directory)) = candidate else {
            return;
        };
        assert_eq!(recovery, spec);
        assert!(!directory);

        assert!(Operation::PlanResume(spec, false).recovery_spec().is_none());
        let recovery_store = Arc::new(TransferRecoveryStore::disabled());
        let recovery_record = recovery_record_for(uuid::Uuid::new_v4(), None, &recovery, false, 0)
            .expect("valid recovery record");
        let recovery_claim = recovery_store
            .upsert_and_claim(recovery_record.clone())
            .expect("claim recovery record");
        drop(recovery_store);
        let persisted = Operation::PlanPersistedRecovery {
            id: recovery_record.id,
            spec: recovery.clone(),
            directory: false,
        };
        drop(recovery_claim);
        assert!(persisted.recovery_spec().is_none());
        assert!(persisted.transfer_status().is_none());
        assert!(persisted.can_run_beside_transfers());
        assert!(Operation::List("/srv".into()).recovery_spec().is_none());
    }

    #[test]
    fn persisted_recovery_record_captures_direction_paths_progress_and_connection_binding() {
        let connection_id = uuid::Uuid::new_v4();
        let spec =
            keelshell_session::sftp::TransferSpec::upload("/tmp/source.txt", "/srv/source.txt");
        let record =
            recovery_record_for(uuid::Uuid::new_v4(), Some(connection_id), &spec, false, 128)
                .expect("valid recovery record");
        assert_eq!(record.connection_id, Some(connection_id));
        assert_eq!(record.direction, TransferRecoveryDirection::Upload);
        assert_eq!(
            record.local_path,
            std::path::PathBuf::from("/tmp/source.txt")
        );
        assert_eq!(record.remote_path, "/srv/source.txt");
        assert_eq!(record.transferred_bytes, 128);
        assert_eq!(record.reviewed_existing_bytes, 128);
        assert_eq!(record.state, TransferRecoveryState::Unfinished);
    }

    #[test]
    fn persisted_recovery_connection_binding_is_optional_but_mismatch_fails_closed() {
        let bound = TransferRecoveryRecord::new_with_connection_id(
            uuid::Uuid::new_v4(),
            Some(uuid::Uuid::from_u128(7)),
            TransferRecoveryDirection::Download,
            "/tmp/source.txt",
            "/srv/source.txt",
            false,
            TransferRecoveryState::Failed,
            0,
            None,
            0,
            10,
            10,
        )
        .expect("valid bound record");
        assert!(recovery_connection_matches(
            &bound,
            Some(uuid::Uuid::from_u128(7))
        ));
        assert!(!recovery_connection_matches(
            &bound,
            Some(uuid::Uuid::from_u128(8))
        ));
        assert!(!recovery_connection_matches(&bound, None));

        let unbound = TransferRecoveryRecord::new(
            uuid::Uuid::new_v4(),
            TransferRecoveryDirection::Download,
            "/tmp/source.txt",
            "/srv/source.txt",
            false,
            TransferRecoveryState::Failed,
            0,
            None,
            0,
            10,
            10,
        )
        .expect("valid legacy record");
        assert!(recovery_connection_matches(&unbound, None));
        assert!(recovery_connection_matches(
            &unbound,
            Some(uuid::Uuid::from_u128(9))
        ));
    }

    #[test]
    fn persisted_recovery_review_uses_the_record_binding_and_fresh_plan_progress() {
        let id = uuid::Uuid::new_v4();
        let mut record = TransferRecoveryRecord::new(
            id,
            TransferRecoveryDirection::Upload,
            "/tmp/source.txt",
            "/srv/source.txt",
            false,
            TransferRecoveryState::Failed,
            20,
            Some(100),
            8,
            10,
            10,
        )
        .expect("valid unbound recovery record");
        assert_eq!(
            persisted_recovery_is_bound(&[record.clone()], id),
            Some(false)
        );

        update_persisted_recovery_progress(&mut record, 40, 80)
            .expect("fresh read-only plan progress");
        assert_eq!(record.reviewed_existing_bytes, 40);
        assert_eq!(record.total_bytes, Some(80));
        assert_eq!(
            record.transferred_bytes, 40,
            "reviewed existing bytes cannot be lost when the old checkpoint is stale"
        );
        let connection_bound =
            persisted_recovery_is_bound(std::slice::from_ref(&record), id).expect("record binding");

        let message = persisted_resume_review_message(
            TransferDirection::Upload,
            &record.local_path,
            &record.remote_path,
            record.total_bytes.expect("total bytes"),
            record.reviewed_existing_bytes,
            None,
            "fixture SSH",
            connection_bound,
        );
        let (zh, en) = message.translations();
        assert!(zh.contains("没有保存连接身份"));
        assert!(en.contains("no saved connection identity"));
    }

    #[test]
    fn persisted_recovery_progress_rejects_an_impossible_plan() {
        let mut record = TransferRecoveryRecord::new(
            uuid::Uuid::new_v4(),
            TransferRecoveryDirection::Download,
            "/tmp/target.txt",
            "/srv/source.txt",
            false,
            TransferRecoveryState::OutcomeUnknown,
            4,
            Some(8),
            4,
            10,
            10,
        )
        .expect("valid recovery record");
        assert!(update_persisted_recovery_progress(&mut record, 9, 8).is_err());
        assert_eq!(record.reviewed_existing_bytes, 4);
        assert_eq!(record.total_bytes, Some(8));
        assert_eq!(record.transferred_bytes, 4);
    }

    #[test]
    fn recovery_writer_marks_resume_active_and_classifies_terminal_results() {
        let directory = TempDir::new().expect("temporary directory");
        let store = Arc::new(TransferRecoveryStore::new(
            directory.path().join("transfer-recovery.json"),
        ));
        let id = uuid::Uuid::new_v4();
        let record = TransferRecoveryRecord::new(
            id,
            TransferRecoveryDirection::Upload,
            "/tmp/source.txt",
            "/srv/source.txt",
            false,
            TransferRecoveryState::Failed,
            4,
            Some(8),
            4,
            10,
            10,
        )
        .expect("valid terminal record");
        let mut writer = TransferRecoveryWriter::new(store.clone(), record.clone(), None);
        writer.start().expect("resume start is durably recorded");
        assert_eq!(
            store.load().expect("load active record")[0].state,
            TransferRecoveryState::Unfinished
        );

        let unknown: Result<Outcome, FileFailure> =
            Err(FileFailure::OutcomeUncertain("late reply".into()));
        writer.finish(&unknown, 6, Some(8));
        let retained = store.load().expect("load unknown result");
        assert_eq!(retained[0].state, TransferRecoveryState::OutcomeUnknown);
        assert_eq!(retained[0].transferred_bytes, 6);
        let success: Result<Outcome, FileFailure> =
            Ok(Outcome::Done(crate::i18n::Message::empty()));
        writer.finish(&success, 8, Some(8));
        let retained_after_duplicate_finish = store.load().expect("load after duplicate finish");
        assert_eq!(
            retained_after_duplicate_finish[0].state,
            TransferRecoveryState::OutcomeUnknown
        );
        assert_eq!(
            retained_after_duplicate_finish[0].transferred_bytes, 6,
            "a late duplicate terminal event cannot rewrite the retained outcome"
        );
        drop(writer);

        let mut completed = TransferRecoveryWriter::new(
            store.clone(),
            TransferRecoveryRecord::new(
                id,
                TransferRecoveryDirection::Upload,
                "/tmp/source.txt",
                "/srv/source.txt",
                false,
                TransferRecoveryState::OutcomeUnknown,
                6,
                Some(8),
                4,
                10,
                10,
            )
            .expect("valid retained record"),
            None,
        );
        completed.start().expect("second recovery start");
        completed.finish(&success, 8, Some(8));
        assert!(
            store
                .load()
                .expect("load after successful cleanup")
                .is_empty()
        );
    }

    #[test]
    fn new_recovery_writer_claims_the_record_before_transfer_start() {
        let directory = TempDir::new().expect("temporary directory");
        let path = directory.path().join("transfer-recovery.json");
        let store = Arc::new(TransferRecoveryStore::new(&path));
        let observer = TransferRecoveryStore::new(&path);
        let record = TransferRecoveryRecord::new(
            uuid::Uuid::new_v4(),
            TransferRecoveryDirection::Upload,
            "/tmp/source.txt",
            "/srv/source.txt",
            false,
            TransferRecoveryState::Failed,
            0,
            Some(8),
            0,
            10,
            10,
        )
        .expect("valid new transfer record");
        let mut writer = TransferRecoveryWriter::new(store, record.clone(), None);

        writer.start().expect("new transfer recovery start");
        assert_eq!(
            observer.load().expect("load first durable checkpoint")[0].state,
            TransferRecoveryState::Unfinished
        );
        assert!(
            matches!(observer.claim(record.id), Err(keelshell_core::Error::Busy)),
            "another process cannot inspect a record while the first worker owns it"
        );

        let failure: Result<Outcome, FileFailure> =
            Err(FileFailure::Transport("queue unavailable".into()));
        writer.finish(&failure, 0, None);
        drop(writer);
        let claim = observer
            .claim(record.id)
            .expect("claim after the worker releases ownership");
        drop(claim);
    }

    #[test]
    fn claimed_recovery_writer_preserves_reviewed_bytes_when_startup_fails() {
        let directory = TempDir::new().expect("temporary directory");
        let store = Arc::new(TransferRecoveryStore::new(
            directory.path().join("transfer-recovery.json"),
        ));
        let id = uuid::Uuid::new_v4();
        let record = TransferRecoveryRecord::new(
            id,
            TransferRecoveryDirection::Upload,
            "/tmp/source.txt",
            "/srv/source.txt",
            false,
            TransferRecoveryState::OutcomeUnknown,
            4,
            Some(8),
            4,
            10,
            10,
        )
        .expect("valid recovery record");
        store
            .upsert(record.clone())
            .expect("persist recovery record");
        let claim = store.claim(id).expect("claim recovery record");
        let mut writer = TransferRecoveryWriter::new(store.clone(), record, Some(claim));
        writer.start().expect("start claimed recovery");

        let failure: Result<Outcome, FileFailure> =
            Err(FileFailure::Transport("queue unavailable".into()));
        writer.finish(&failure, 0, None);
        let retained = store.load().expect("load failed claimed recovery");
        assert_eq!(retained[0].state, TransferRecoveryState::Failed);
        assert_eq!(
            retained[0].transferred_bytes, 4,
            "a queue startup failure cannot erase the reviewed existing prefix"
        );
    }

    #[test]
    fn recovery_candidate_requires_failed_transfer_and_current_session() {
        let token = uuid::Uuid::new_v4();
        let candidate = RecoveryCandidate {
            persisted_id: None,
            session_token: token,
            spec: keelshell_session::sftp::TransferSpec::download(
                "/srv/source.txt",
                "/tmp/source.txt",
            ),
            directory: false,
        };
        assert!(recovery_is_available(
            Some(&candidate),
            token,
            false,
            false,
            false,
            Some(TransferPhase::Failed),
        ));
        for (suspended, busy, pending, phase) in [
            (true, false, false, Some(TransferPhase::Failed)),
            (false, true, false, Some(TransferPhase::Failed)),
            (false, false, true, Some(TransferPhase::Failed)),
            (false, false, false, Some(TransferPhase::Cancelled)),
            (false, false, false, Some(TransferPhase::Completed)),
        ] {
            assert!(!recovery_is_available(
                Some(&candidate),
                token,
                suspended,
                busy,
                pending,
                phase,
            ));
        }
        assert!(!recovery_is_available(
            Some(&candidate),
            uuid::Uuid::new_v4(),
            false,
            false,
            false,
            Some(TransferPhase::Failed),
        ));
    }

    #[test]
    fn read_only_resume_plan_never_rewrites_failed_transfer_phase() {
        let success: Result<Outcome, FileFailure> =
            Ok(Outcome::Done(crate::i18n::Message::empty()));
        let failed: Result<Outcome, FileFailure> = Err(FileFailure::WorkerStopped);
        let cancelled: Result<Outcome, FileFailure> = Err(FileFailure::Cancelled);
        for result in [&success, &failed, &cancelled] {
            assert_eq!(terminal_transfer_phase(false, result), None);
        }
        assert_eq!(
            terminal_transfer_phase(true, &success),
            Some(TransferPhase::Completed)
        );
        assert_eq!(
            terminal_transfer_phase(true, &failed),
            Some(TransferPhase::Uncertain)
        );
        let rejected = Err(FileFailure::Transport("server rejected the request".into()));
        assert_eq!(terminal_transfer_phase(false, &rejected), None);
        assert_eq!(
            terminal_transfer_phase(true, &rejected),
            Some(TransferPhase::Failed)
        );
        assert_eq!(
            terminal_transfer_phase(true, &cancelled),
            Some(TransferPhase::Cancelled)
        );
    }

    #[gpui_kit::test]
    fn persisted_resume_review_requires_current_host_confirmation(
        cx: &mut gpui_kit::TestAppContext,
    ) {
        let message = persisted_resume_review_message(
            TransferDirection::Upload,
            std::path::Path::new("/tmp/source.txt"),
            "/srv/source.txt",
            100,
            40,
            None,
            "ops@example:22",
            false,
        );
        cx.update(|cx| {
            assert!(
                message
                    .render(cx)
                    .contains("请明确确认当前 SSH 主机就是原目标主机")
            );
            crate::i18n::set_language(keelshell_core::Language::En, cx);
            assert!(
                message.render(cx).contains(
                    "explicitly confirm that the current SSH host is the original target"
                )
            );
        });
    }

    #[test]
    fn recovery_click_guard_rejects_changed_state_without_requiring_a_new_candidate() {
        let token = uuid::Uuid::new_v4();
        let candidate = RecoveryCandidate {
            persisted_id: None,
            session_token: token,
            spec: keelshell_session::sftp::TransferSpec::download(
                "/srv/source.txt",
                "/tmp/source.txt",
            ),
            directory: false,
        };
        assert!(recovery_request_is_allowed(
            Some(&candidate),
            token,
            true,
            false,
            false,
            false,
            Some(TransferPhase::Failed),
        ));
        for (session_available, suspended, busy, pending, phase) in [
            (false, false, false, false, Some(TransferPhase::Failed)),
            (true, true, false, false, Some(TransferPhase::Failed)),
            (true, false, true, false, Some(TransferPhase::Failed)),
            (true, false, false, true, Some(TransferPhase::Failed)),
            (true, false, false, false, Some(TransferPhase::Completed)),
        ] {
            assert!(!recovery_request_is_allowed(
                Some(&candidate),
                token,
                session_available,
                suspended,
                busy,
                pending,
                phase,
            ));
        }
    }

    fn entry(mode: Option<u32>, directory: bool, symlink: bool) -> RemoteEntry {
        RemoteEntry {
            name: "sample".into(),
            path: "/sample".into(),
            size: None,
            is_directory: directory,
            is_symlink: symlink,
            permissions: mode,
            modified: None,
        }
    }

    #[test]
    fn permission_columns_preserve_special_bits_and_entry_types() {
        assert_eq!(
            permissions_label(&entry(Some(0o100644), false, false)),
            "-rw-r--r--"
        );
        assert_eq!(
            permissions_label(&entry(Some(0o41777), true, false)),
            "drwxrwxrwt"
        );
        assert_eq!(
            permissions_label(&entry(Some(0o104640), false, false)),
            "-rwSr-----"
        );
        assert_eq!(
            permissions_label(&entry(Some(0o120777), false, true)),
            "lrwxrwxrwx"
        );
        assert_eq!(permissions_label(&entry(None, false, false)), "—");
    }

    #[test]
    fn metadata_columns_distinguish_missing_zero_and_utc_time() {
        assert_eq!(size_label(None), "—");
        assert_eq!(size_label(Some(0)), "0 B");
        assert_eq!(size_label(Some(1536)), "1.5 KiB");
        assert_eq!(modified_label(None), "—");
        assert_eq!(modified_label(Some(0)), "1970/01/01 00:00");
        assert_eq!(modified_label(Some(946_684_800)), "2000/01/01 00:00");
        assert_eq!(modified_label(Some(1_709_164_800)), "2024/02/29 00:00");
    }

    #[gpui_kit::test]
    fn transfer_progress_messages_localize_known_and_unknown_totals(
        cx: &mut gpui_kit::TestAppContext,
    ) {
        cx.update(|cx| {
            let upload = transfer_progress_message(TransferDirection::Upload, 1024, Some(4096));
            assert_eq!(upload.render(cx), "上传中：1024 / 4096 字节");
            crate::i18n::set_language(keelshell_core::Language::En, cx);
            assert_eq!(upload.render(cx), "Uploading: 1024 / 4096 bytes");
            let download = transfer_progress_message(TransferDirection::Download, 512, None);
            assert_eq!(download.render(cx), "Downloading: 512 bytes");
            crate::i18n::set_language(keelshell_core::Language::ZhCn, cx);
            assert_eq!(download.render(cx), "下载中：512 字节");
        });
    }

    #[gpui_kit::test]
    fn existing_file_error_retranslates_without_rewriting_remote_detail(
        cx: &mut gpui_kit::TestAppContext,
    ) {
        let error = FileFailure::Transport("/srv/服务.conf: permission denied".into()).message();
        cx.update(|cx| {
            assert!(error.render(cx).starts_with("文件操作失败："));
            crate::i18n::set_language(keelshell_core::Language::En, cx);
            assert!(error.render(cx).starts_with("File operation failed:"));
            assert!(
                error
                    .render(cx)
                    .contains("/srv/服务.conf: permission denied")
            );
            crate::i18n::set_language(keelshell_core::Language::ZhCn, cx);
            assert!(
                error
                    .render(cx)
                    .contains("/srv/服务.conf: permission denied")
            );
        });
    }
}

#[cfg(test)]
pub(crate) mod fixture_group;
#[cfg(test)]
#[path = "files/layout_tests.rs"]
mod layout_tests;
#[cfg(test)]
pub(crate) mod test_server;
#[cfg(test)]
mod transfer_tests;

#[cfg(test)]
#[expect(
    dead_code,
    reason = "The protocol fixture exposes controls used by several independent suites"
)]
#[path = "../../keelshell-session/tests/fixtures/sftp.rs"]
pub(crate) mod sftp_test_filesystem;
