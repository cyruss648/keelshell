#![cfg_attr(
    all(target_os = "windows", not(debug_assertions)),
    windows_subsystem = "windows"
)]

mod ai_credentials;
mod ai_request_options;
mod ai_settings;
mod app_windows;
mod assistant;
mod batch_commands;
mod command_history;
mod command_palette;
mod command_suggestions;
mod command_text;
mod configuration_recovery;
mod design;
mod directory_compare;
mod emulator;
mod files;
mod i18n;
mod jump_host_picker;
mod mcp_bridge;
mod monitor;
mod profile_sync;
mod proxy_editor;
mod runtime_bridge;
mod snippet_editor;
mod snippet_parameters;
mod ssh_bridge;
mod target_parameters;
mod terminal;
mod tunnels;
mod updater;
mod vault_settings;
mod workflow_commands;
mod workspace;

#[cfg(test)]
mod ui_tests;

use keelshell_core::{AppState, StateStore};
use std::sync::Arc;

fn main() {
    if keelshell_ai::run_local_agent_directory_launcher() {
        return;
    }
    if updater::run_update_helper() {
        return;
    }
    let path = match std::env::var_os("KEELSHELL_DATA_DIR") {
        Some(path) => std::path::PathBuf::from(path).join("state.json"),
        None => match StateStore::default_path() {
            Ok(path) => path,
            Err(error) => {
                eprintln!("Cannot resolve application data: {error}");
                std::process::exit(1);
            }
        },
    };
    let runtime = match tokio::runtime::Builder::new_multi_thread()
        .enable_all()
        .worker_threads(4)
        .build()
    {
        Ok(runtime) => Arc::new(runtime),
        Err(error) => {
            eprintln!("Cannot start networking runtime: {error}");
            std::process::exit(1);
        }
    };
    let store = Arc::new(StateStore::new(path));
    // Initial disk loading precedes the UI event loop. Subsequent writes use workers.
    let (state, load_error) = match store.load() {
        Ok(state) => (state, None),
        Err(error) => (
            AppState::default(),
            Some(format!(
                "Configuration could not be loaded: {error}. Existing file preserved."
            )),
        ),
    };
    gpui_kit::application()
        .with_assets(application_assets())
        .run(move |cx| {
            cx.set_app_identity(
                app_windows::APPLICATION_IDENTIFIER,
                app_windows::APPLICATION_NAME,
            );
            gpui_kit::init(cx);
            design::apply_settings(&state.settings, None, cx);
            i18n::set_language(state.settings.language, cx);
            workspace::bind_keys(cx);
            terminal::install_shutdown(cx);
            if let Err(error) = app_windows::open(store, state, load_error, runtime, true, cx) {
                eprintln!("Unable to open KeelShell: {error}");
                cx.quit();
            }
            cx.activate(true);
        });
}

// The component-default bundle omits application icons such as split, AI and
// package. Native apps need the full embedded catalog; no network icon fetches.
fn application_assets() -> impl gpui_kit::AssetSource + rust_embed::RustEmbed {
    gpui_kit::assets::AllAssets
}

#[cfg(test)]
mod assets_tests {
    use gpui_kit::{AssetSource, assets::IconName};

    #[test]
    fn application_source_resolves_every_declared_icon_offline() {
        let source = super::application_assets();
        for icon in IconName::ALL {
            let path = icon.path();
            let bytes = source
                .load(&path)
                .unwrap_or_else(|error| panic!("{path}: {error}"))
                .unwrap_or_else(|| panic!("missing embedded icon: {path}"));
            assert!(!bytes.is_empty(), "empty embedded icon: {path}");
            assert!(
                matches!(bytes, std::borrow::Cow::Borrowed(_)),
                "icon must be compiled static bytes, never a registry filesystem read: {path}"
            );
        }
    }
}
