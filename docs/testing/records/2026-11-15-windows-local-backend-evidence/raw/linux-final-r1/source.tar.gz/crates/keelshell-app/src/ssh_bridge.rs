//! Bridge an SSH shell to the native terminal without blocking GPUI.

use std::sync::Arc;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::mpsc::{self, Receiver, SyncSender, TryRecvError, TrySendError};
use std::time::Duration;

use gpui_kit::{App, AppContext, Entity};
use keelshell_session::{
    ConnectionEnd, ConnectionState, SessionEvent, ShellEnd, SshSession, SshShell,
};
use tokio::runtime::Runtime;
use tokio::sync::watch;

use crate::terminal::{TerminalCommand, TerminalView, TransportState, spawn_transport_worker};

#[path = "ssh_bridge_zmodem.rs"]
mod zmodem;
use zmodem::Protocol;

/// Open one SSH terminal entity. The connection is shared with independent SFTP
/// and terminal consumers; closing this view closes only its shell channel.
pub fn open(
    session: SshSession,
    runtime: Arc<Runtime>,
    title: String,
    target: String,
    font_size: f32,
    history: usize,
    cx: &mut App,
) -> Entity<TerminalView> {
    let (output, incoming) = mpsc::sync_channel(128);
    let (outgoing, commands) = mpsc::sync_channel(128);
    let cancelled = Arc::new(AtomicBool::new(false));
    let worker_stop = cancelled.clone();
    let failure_output = output.clone();
    let protocol = Protocol::new(session.clone(), target.clone());
    let safety = protocol.safety.clone();
    let (lifecycle, state) = watch::channel(TransportState::Starting);
    let started = spawn_transport_worker("keelshell-ssh-shell", cancelled.clone(), move || {
        runtime.block_on(run_with_protocol(
            session,
            commands,
            output,
            worker_stop,
            lifecycle,
            protocol,
        ))
    });
    if let Err(error) = started {
        // TerminalView supplies the translated error label; preserve this
        // operating-system diagnostic without translating a host or title.
        let _ = failure_output.try_send(SessionEvent::Error(error.to_string()));
        cancelled.store(true, Ordering::Release);
    }
    cx.new(|cx| {
        let mut view = TerminalView::from_transport(
            title, font_size, history, incoming, outgoing, cancelled, cx,
        );
        view.attach_transport_target(target);
        view.attach_zmodem_safety(safety);
        view.attach_lifecycle(state);
        view
    })
}

#[cfg(test)]
async fn run(
    session: SshSession,
    commands: Receiver<TerminalCommand>,
    output: SyncSender<SessionEvent>,
    cancelled: Arc<AtomicBool>,
    lifecycle: watch::Sender<TransportState>,
) -> Result<(), String> {
    let protocol = Protocol::new(session.clone(), "controlled SSH fixture".into());
    run_with_protocol(session, commands, output, cancelled, lifecycle, protocol).await
}

async fn run_with_protocol(
    session: SshSession,
    commands: Receiver<TerminalCommand>,
    output: SyncSender<SessionEvent>,
    cancelled: Arc<AtomicBool>,
    lifecycle: watch::Sender<TransportState>,
    mut protocol: Protocol,
) -> Result<(), String> {
    let startup = tokio::select! {
        _ = cancellation(&cancelled) => { lifecycle.send_replace(TransportState::Ended(ShellEnd::Cancelled)); return Ok(()); },
        result = session.start_shell(30, 100) => result,
    };
    let mut shell = match startup {
        Ok(shell) => shell,
        Err(error) => {
            lifecycle.send_replace(TransportState::Ended(connection_end(&session)));
            let message = error.to_string();
            let _ = output.try_send(SessionEvent::Error(message.clone()));
            return Err(message);
        }
    };
    lifecycle.send_replace(TransportState::Ready);
    let mut result = pump(
        &mut shell,
        &session,
        &mut protocol,
        &commands,
        &output,
        &cancelled,
        &lifecycle,
    )
    .await;
    let protocol_result = protocol.fail();
    let reason = shell.completion().unwrap_or_else(|| {
        if cancelled.load(Ordering::Acquire) {
            ShellEnd::Cancelled
        } else {
            connection_end(&session)
        }
    });
    lifecycle.send_replace(TransportState::Ended(reason));
    // Channel cleanup and retained terminal output share a bounded deadline,
    // independent of cancellation. Failure recovery can append ordinary bytes
    // after pump has stopped; retain ownership until delivery or explicit error.
    let until = tokio::time::Instant::now() + Duration::from_secs(2);
    let cleanup = tokio::time::timeout_at(until, shell.close())
        .await
        .map_err(|_| "SSH_SHELL_CLEANUP_TIMEOUT".to_owned())
        .and_then(|result| result.map_err(|error| error.to_string()));
    let output_cleanup = flush_cleanup_output(&mut protocol, &output, until).await;
    protocol.transport_closed();
    for outcome in [protocol_result, cleanup, output_cleanup] {
        if let Err(error) = outcome {
            result = Err(match result {
                Ok(()) => error,
                Err(primary) => format!("{primary}; {error}"),
            });
        }
    }
    result
}

async fn flush_cleanup_output(
    protocol: &mut Protocol,
    output: &SyncSender<SessionEvent>,
    until: tokio::time::Instant,
) -> Result<(), String> {
    while let Some(event) = protocol.output.pop_front() {
        match output.try_send(event) {
            Ok(()) => {}
            Err(TrySendError::Full(event)) => {
                protocol.output.push_front(event);
                if tokio::time::Instant::now() >= until {
                    return Err("SSH_SHELL_OUTPUT_CLEANUP_TIMEOUT".into());
                }
                tokio::time::sleep_until(
                    until.min(tokio::time::Instant::now() + Duration::from_millis(4)),
                )
                .await;
            }
            Err(TrySendError::Disconnected(_)) => {
                return Err("SSH_SHELL_OUTPUT_CLEANUP_DISCONNECTED".into());
            }
        }
    }
    Ok(())
}

async fn pump(
    shell: &mut SshShell,
    session: &SshSession,
    protocol: &mut Protocol,
    commands: &Receiver<TerminalCommand>,
    output: &SyncSender<SessionEvent>,
    cancelled: &AtomicBool,
    lifecycle: &watch::Sender<TransportState>,
) -> Result<(), String> {
    let mut completion_seen = false;
    loop {
        if cancelled.load(Ordering::Acquire) {
            return Ok(());
        }

        if !completion_seen && let Some(reason) = shell.completion() {
            lifecycle.send_replace(TransportState::Ended(reason));
            completion_seen = true;
        }
        if drain_output(shell, session, protocol, output).await? {
            return Ok(());
        }

        // A lifecycle outcome can precede its ordered terminal event. Drain
        // queued OO/tail first and never let a due timer retire that lease
        // while its unsuccessful or unknown end is already observable.
        if !completion_seen && let Some(reason) = shell.completion() {
            lifecycle.send_replace(TransportState::Ended(reason));
            completion_seen = true;
        }
        if completion_seen {
            tokio::time::sleep(Duration::from_millis(4)).await;
            continue;
        }
        protocol.tick()?;

        while let Some(bytes) = protocol.pop_write() {
            match write_and_drain(
                shell,
                session,
                protocol,
                ShellWrite::Protocol(&bytes),
                output,
                cancelled,
                lifecycle,
            )
            .await?
            {
                WriteOutcome::Written => protocol.write_completed()?,
                WriteOutcome::ShellEnded => {
                    completion_seen = true;
                    break;
                }
                WriteOutcome::Stopped => return Ok(()),
            }
        }
        if completion_seen {
            continue;
        }

        // Merge consecutive resize requests, but preserve their position before
        // the next write. No write is dequeued until this worker can own it.
        let mut resize = None;
        let mut write = None;
        for _ in 0..128 {
            match commands.try_recv() {
                Ok(TerminalCommand::Resize(rows, cols)) => resize = Some((rows, cols)),
                Ok(TerminalCommand::Write(bytes)) => {
                    if protocol.input_blocked() {
                        protocol.reject_input()?;
                    } else {
                        write = Some(bytes);
                        break;
                    }
                }
                Ok(TerminalCommand::Zmodem(control)) => {
                    tokio::select! {
                        biased;
                        _ = cancellation(cancelled) => return Ok(()),
                        result = protocol.control(session, *control) => result?,
                    }
                    break;
                }
                Ok(TerminalCommand::ResumeInput(id)) => protocol.resume_input(id),
                Err(TryRecvError::Empty) => break,
                Err(TryRecvError::Disconnected) => return Ok(()),
            }
        }
        if let Some((rows, cols)) = resize {
            let mut completion = shell.subscribe_completion();
            tokio::select! {
                biased;
                _ = cancellation(cancelled) => return Ok(()),
                reason = shell_end(&mut completion) => {
                    lifecycle.send_replace(TransportState::Ended(reason));
                    completion_seen = true;
                    continue;
                },
                result = shell.resize(rows, cols) => result.map_err(|error| error.to_string())?,
            }
        }
        if let Some(bytes) = write {
            match write_and_drain(
                shell,
                session,
                protocol,
                ShellWrite::Ordinary(&bytes),
                output,
                cancelled,
                lifecycle,
            )
            .await?
            {
                WriteOutcome::Written => {}
                WriteOutcome::ShellEnded => completion_seen = true,
                WriteOutcome::Stopped => return Ok(()),
            }
        }
        tokio::time::sleep(Duration::from_millis(4)).await;
    }
}

async fn drain_output(
    shell: &mut SshShell,
    session: &SshSession,
    protocol: &mut Protocol,
    output: &SyncSender<SessionEvent>,
) -> Result<bool, String> {
    // One retained event plus two bounded queues provide output backpressure.
    for _ in 0..64 {
        let event = if let Some(event) = protocol.output.pop_front() {
            event
        } else if protocol.wants_input() {
            let Some(event) = shell.try_recv() else {
                break;
            };
            protocol.feed(session, event).await?;
            continue;
        } else {
            break;
        };
        let completed = matches!(event, SessionEvent::Exited { .. });
        let failed = match &event {
            SessionEvent::Error(message) if shell.completion().is_none() => Some(message.clone()),
            _ => None,
        };
        let completed =
            completed || matches!(event, SessionEvent::Error(_)) && shell.completion().is_some();
        match output.try_send(event) {
            Ok(()) => {
                if let Some(error) = failed {
                    return Err(error);
                }
                if completed {
                    return Ok(true);
                }
            }
            Err(TrySendError::Full(event)) => {
                protocol.output.push_front(event);
                break;
            }
            Err(TrySendError::Disconnected(_)) => return Ok(true),
        }
    }
    Ok(false)
}

/// Preserve one write future while draining output. A failed or interrupted
/// write can have sent a prefix; it is never restarted or replayed.
#[derive(Clone, Copy)]
enum ShellWrite<'a> {
    Ordinary(&'a [u8]),
    Protocol(&'a [u8]),
}

enum WriteOutcome {
    Written,
    // Completion is independent of the bounded output queue. Keep draining
    // that queue, but never acknowledge this interrupted write as completed.
    ShellEnded,
    Stopped,
}

async fn write_and_drain(
    shell: &mut SshShell,
    session: &SshSession,
    protocol: &mut Protocol,
    write: ShellWrite<'_>,
    output: &SyncSender<SessionEvent>,
    cancelled: &AtomicBool,
    lifecycle: &watch::Sender<TransportState>,
) -> Result<WriteOutcome, String> {
    let (ShellWrite::Ordinary(bytes) | ShellWrite::Protocol(bytes)) = write;
    let writer = shell.writer();
    let writing = async {
        match write {
            ShellWrite::Ordinary(_) => writer.write(bytes).await,
            ShellWrite::Protocol(_) => writer.write_confirmed(bytes).await,
        }
    };
    let mut completion = shell.subscribe_completion();
    tokio::pin!(writing);
    loop {
        tokio::select! {
            biased;
            _ = cancellation(cancelled) => return Ok(WriteOutcome::Stopped),
            reason = shell_end(&mut completion) => {
                lifecycle.send_replace(TransportState::Ended(reason));
                return Ok(WriteOutcome::ShellEnded);
            },
            result = &mut writing => {
                if let Some(reason) = shell.completion() {
                    lifecycle.send_replace(TransportState::Ended(reason));
                    return Ok(WriteOutcome::ShellEnded);
                }
                return result.map(|()| WriteOutcome::Written).map_err(|error| error.to_string());
            },
            _ = tokio::time::sleep(Duration::from_millis(4)) => {
                if drain_output(shell, session, protocol, output).await? {
                    return Ok(WriteOutcome::Stopped);
                }
                if matches!(write, ShellWrite::Ordinary(_)) && protocol.input_blocked() {
                    // A remote peer can begin Zmodem while SSH flow control
                    // suspends an already admitted ordinary write. Stop polling
                    // that future at the ownership boundary: its unknown prefix
                    // cannot be replayed or mixed with protocol negotiation.
                    protocol.interrupt_ordinary_write();
                    return Err("SSH_ZMODEM_INPUT_HANDOFF_INTERRUPTED".into());
                }
            }
        }
    }
}

async fn cancellation(cancelled: &AtomicBool) {
    while !cancelled.load(Ordering::Acquire) {
        tokio::time::sleep(Duration::from_millis(10)).await;
    }
}

async fn shell_end(completion: &mut watch::Receiver<Option<ShellEnd>>) -> ShellEnd {
    loop {
        if let Some(reason) = completion.borrow_and_update().clone() {
            return reason;
        }
        if completion.changed().await.is_err() {
            return ShellEnd::ConnectionClosed(ConnectionEnd::Unknown);
        }
    }
}

fn connection_end(session: &SshSession) -> ShellEnd {
    ShellEnd::ConnectionClosed(match session.connection_state() {
        ConnectionState::Closed(reason) => reason,
        ConnectionState::Closing => ConnectionEnd::LocalClosed,
        ConnectionState::Connected => ConnectionEnd::Unknown,
    })
}

#[cfg(test)]
#[path = "ssh_bridge_tests.rs"]
mod tests;
