//! Workspace composition: connection library, terminal tabs and reviewed commands.
use gpui_kit::prelude::FluentBuilder;
use keelshell_session::{
    KeyboardInteractiveChallenge, RetryPolicy, SessionError, SshAuth, SshOptions, SshSession,
};
use std::{
    collections::HashMap,
    sync::Arc,
    time::{Duration, SystemTime, UNIX_EPOCH},
};
use tokio::sync::{mpsc, oneshot};
use zeroize::Zeroizing;

use crate::i18n::{self, Message, t};
use gpui_kit::{
    component::{
        Disableable, Sizable,
        button::{Button, ButtonVariants},
        input::{Input, InputEvent, InputState, Textarea, TextareaState},
    },
    *,
};
use keelshell_core::{AppState, AuthMethod, Connection, Language, StateStore};
mod agent;
mod appearance;
mod command_palette;
mod command_workflows;
mod commands;
mod configuration_recovery;
mod credentials;
mod knowledge_library;
mod library;
mod library_bulk;
mod library_view;
mod mcp;
mod modal_scope;
mod modals;
mod navigation;
use navigation::NavigationPanel;
mod openssh_review;
mod pane_sessions;
mod pane_view;
mod profile_sync;
mod protocol_selection;
mod reconnect;
mod reconnect_editor;
mod remote_completion;
mod routing;
mod startup_restore;
mod workflow_audit;
mod workflow_commands;
use library::{DestinationPrompt, DestinationTarget, FolderForm, LibraryFilter};
use reconnect_editor::ReconnectEditor;
#[cfg(test)]
pub(crate) mod tests;
#[cfg(test)]
#[path = "tunnels/workspace_tests.rs"]
mod tunnel_rule_tests;
mod updates;
mod vault;
mod view;
mod window_configuration;
pub(crate) mod window_lifecycle;

use crate::ai_settings::{AiSettingsEvent, AiSettingsPanel, EphemeralCredentials};
use crate::assistant::{
    AssistantEvent, AssistantPanel, KnowledgeCaptureKind, KnowledgeCaptureSnapshot,
};
use crate::command_history::CommandHistory;
use crate::jump_host_picker::JumpHostPicker;
use crate::proxy_editor::ProxyEditor;
use crate::snippet_editor::{SnippetEditor, SnippetEditorEvent};
use crate::terminal::TerminalView;
use crate::updater::{UpdatePanel, UpdatePanelEvent};
use crate::vault_settings::{VaultSettings, VaultSettingsEvent};
use openssh_review::OpenSshImportReview;

actions!(
    keelshell,
    [
        OpenConnections,
        OpenCommandPalette,
        CloseTab,
        ToggleAssistant,
        PreviousSession,
        NextSession,
        CompleteRemoteCommand,
        NewWorkspaceWindow,
        CloseWorkspaceWindow
    ]
);

struct LoginPrompt {
    id: uuid::Uuid,
    connection: Connection,
    secret: Entity<InputState>,
    proxy_secret: Entity<InputState>,
    master: Entity<InputState>,
    confirmation: Entity<InputState>,
    mode: vault::LoginMode,
    busy: bool,
    cancelled: Arc<std::sync::atomic::AtomicBool>,
    message: Option<Message>,
    pin: Option<String>,
    route_identity: keelshell_core::RouteIdentity,
}

struct KeyboardInteractiveField {
    prompt: String,
    answer: Entity<InputState>,
}

struct KeyboardInteractivePrompt {
    // Route/hop and zero input fields can recur across distinct challenges.
    identity: uuid::Uuid,
    route_id: uuid::Uuid,
    index: usize,
    name: String,
    instructions: String,
    fields: Vec<KeyboardInteractiveField>,
    response: Option<oneshot::Sender<Option<Vec<Zeroizing<String>>>>>,
}

impl KeyboardInteractivePrompt {
    fn clear_inputs(&self, window: &mut Window, cx: &mut App) {
        for field in &self.fields {
            field.answer.update(cx, |input, cx| {
                input.set_value("", window, cx);
            });
        }
    }

    fn focus(&self, window: &mut Window, cx: &mut App) {
        if let Some(field) = self.fields.first() {
            field.answer.read(cx).focus_handle(cx).focus(window, cx);
        }
    }
}

#[derive(Clone, Copy, PartialEq)]
struct SessionTabReveal {
    active_id: EntityId,
    viewport_width: Pixels,
    navigation_width: Pixels,
    tabs_len: usize,
    language: keelshell_core::Language,
    update_action: &'static str,
    show_navigation: bool,
    show_assistant: bool,
}

struct HostApproval {
    attempt: uuid::Uuid,
    index: usize,
    scope: keelshell_core::HostKeyScope,
    connection: Connection,
    fingerprint: String,
    previous: Option<String>,
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum ToolPanel {
    Files,
    Commands,
    Tunnels,
}

#[derive(Default)]
struct RemotePanels {
    files: Option<Entity<crate::files::FilesPanel>>,
    monitor: Option<Entity<crate::monitor::MonitorPanel>>,
    tunnels: Option<Entity<crate::tunnels::TunnelsPanel>>,
}

struct ConnectionForm {
    id: Option<uuid::Uuid>,
    password: bool,
    name: Entity<InputState>,
    host: Entity<InputState>,
    port: Entity<InputState>,
    username: Entity<InputState>,
    folder_id: Option<uuid::Uuid>,
    tags: Entity<InputState>,
    key: Entity<InputState>,
    jump_picker: Entity<JumpHostPicker>,
    proxy_editor: Entity<ProxyEditor>,
    reconnect_editor: Entity<ReconnectEditor>,
}

/// Draft for the no-session SSH entry point.
///
/// It intentionally contains only endpoint and authentication-mode inputs. A
/// submitted draft becomes an in-memory [`Connection`] and is never handed to
/// `StateStore`; the user must explicitly choose “Save as connection” to open
/// the persistent editor.
struct QuickConnectForm {
    host: Entity<InputState>,
    port: Entity<InputState>,
    username: Entity<InputState>,
    key: Entity<InputState>,
}

impl ConnectionForm {
    fn signature(&self, cx: &App) -> Vec<String> {
        let mut signature = vec![
            self.password.to_string(),
            self.name.read(cx).value().to_string(),
            self.host.read(cx).value().to_string(),
            self.port.read(cx).value().to_string(),
            self.username.read(cx).value().to_string(),
            self.folder_id.map(|id| id.to_string()).unwrap_or_default(),
            self.tags.read(cx).value().to_string(),
            self.key.read(cx).value().to_string(),
            self.jump_picker
                .read(cx)
                .selected()
                .map(|id| id.to_string())
                .unwrap_or_default(),
        ];
        signature.extend(self.proxy_editor.read(cx).signature(cx));
        signature.extend(self.reconnect_editor.read(cx).signature(cx));
        signature
    }
}

enum AfterSave {
    None,
    Theme,
    Updates {
        revision: u64,
    },
    UpdateHistory,
    Ai {
        panel: WeakEntity<AiSettingsPanel>,
        credentials: EphemeralCredentials,
        revision: u64,
    },
    Connection {
        id: uuid::Uuid,
        signature: Vec<String>,
    },
    Trust {
        attempt: uuid::Uuid,
        index: usize,
    },
    ConnectionsImported {
        added: usize,
        skipped: usize,
        folders_added: usize,
        warnings: usize,
    },
    ConnectionFavorite {
        favorite: bool,
    },
    ConnectionDeleted {
        name: String,
    },
    FolderSaved {
        id: uuid::Uuid,
        token: uuid::Uuid,
    },
    FolderRemoved {
        id: uuid::Uuid,
        token: uuid::Uuid,
    },
    ConnectionMoved {
        token: uuid::Uuid,
    },
    ConnectionRestored {
        name: String,
    },
    RecentSaved,
    LibraryBatch {
        token: uuid::Uuid,
        action: keelshell_core::ConnectionLibraryAction,
        ids: Vec<uuid::Uuid>,
    },
    BatchAudit {
        records: Vec<keelshell_core::BatchAuditRecord>,
    },
    WorkflowAudit {
        records: Vec<keelshell_core::WorkflowAuditRecord>,
    },
    Knowledge {
        panel: WeakEntity<AssistantPanel>,
        review_id: uuid::Uuid,
    },
    KnowledgeLibrary {
        panel: WeakEntity<crate::assistant::knowledge_library::KnowledgeLibrary>,
        review_id: uuid::Uuid,
    },
    TunnelRule {
        panel: WeakEntity<crate::tunnels::TunnelsPanel>,
        operation: uuid::Uuid,
    },
    TunnelRuntime {
        panel: WeakEntity<crate::tunnels::TunnelsPanel>,
        operation: uuid::Uuid,
        snapshot_id: uuid::Uuid,
        removing: bool,
    },
    SnippetSaved {
        panel: EntityId,
    },
    SnippetDeleted {
        id: uuid::Uuid,
    },
    CredentialLinked {
        prompt: uuid::Uuid,
        connection: Box<Connection>,
    },
}

/// Binding retained by an AI snippet draft until its ordinary local save.
///
/// It contains only process-local identity needed for a second Workspace
/// admission check. It is never serialized into the saved [`Snippet`].
#[derive(Clone, Debug, PartialEq, Eq)]
struct AiSnippetReviewBinding {
    command: String,
    target: String,
    session_id: String,
    terminal: EntityId,
    review_id: uuid::Uuid,
}

struct NewRemoteTab {
    session: SshSession,
    title: String,
    host: String,
    connection_id: Option<uuid::Uuid>,
    split: Option<(EntityId, keelshell_core::SplitAxis)>,
    restored: Option<startup_restore::RestoredTarget>,
}

pub struct Workspace {
    app_windows: Entity<crate::app_windows::AppWindows>,
    window_summary: Arc<std::sync::Mutex<crate::app_windows::WindowSummary>>,
    configuration_gate: Arc<std::sync::Mutex<crate::app_windows::ConfigurationGate>>,
    window_id: uuid::Uuid,
    native_window: AnyWindowHandle,
    configuration_epoch: u64,
    configuration_invalidated: bool,
    close_review: Option<window_lifecycle::CloseReview>,
    closing: Option<Message>,
    cleanup_unknown: Option<window_lifecycle::CleanupUnknown>,
    closing_intent: Option<window_lifecycle::CloseIntent>,
    worker_owners: std::collections::HashSet<EntityId>,
    owned_window_sessions: Vec<SshSession>,
    /// Authenticated route sessions that must outlive their dependent child.
    ///
    /// A target reached through a jump host owns a different SSH connection
    /// from that host. Keeping only sessions referenced by terminal tabs would
    /// therefore close the jump host while the target still uses its channel.
    session_dependencies: Vec<(SshSession, SshSession)>,
    retired_window_panels: Vec<RemotePanels>,
    store: Arc<StateStore>,
    state: AppState,
    tabs: Vec<Entity<TerminalView>>,
    active: usize,
    session_panes: pane_sessions::SessionPanes<EntityId>,
    protocol_selection: protocol_selection::ProtocolSelection,
    pane_bounds:
        std::rc::Rc<std::cell::RefCell<HashMap<keelshell_core::PaneNodeId, Bounds<Pixels>>>>,
    pane_canvas_size: std::rc::Rc<std::cell::Cell<Size<Pixels>>>,
    pane_divider_focus: std::cell::RefCell<HashMap<keelshell_core::PaneNodeId, FocusHandle>>,
    pane_generation: u64,
    pane_tab_ids: HashMap<EntityId, uuid::Uuid>,
    restored_tabs: HashMap<EntityId, keelshell_core::LayoutTab>,
    layout_window_id: uuid::Uuid,
    pane_zoomed: bool,
    search: Entity<InputState>,
    command: Entity<TextareaState>,
    form: Option<ConnectionForm>,
    quick_connect: QuickConnectForm,
    quick_password: bool,
    command_palette_query: Entity<InputState>,
    command_palette_selected: usize,
    openssh_review: Option<OpenSshImportReview>,
    status: Message,
    show_connections: bool,
    show_quick_connect: bool,
    show_window_switcher: bool,
    show_command_palette: bool,
    show_appearance: bool,
    library_filter: LibraryFilter,
    folder_form: Option<FolderForm>,
    destination_prompt: Option<DestinationPrompt>,
    library_selection: std::collections::BTreeSet<uuid::Uuid>,
    library_batch_prompt: Option<library_bulk::LibraryBatchPrompt>,
    library_trash_undo: Vec<uuid::Uuid>,
    pending_recents: Vec<(Connection, keelshell_core::ConnectionRoute, u64)>,
    pending_batch_audits: Vec<keelshell_core::BatchAuditRecord>,
    pending_workflow_audits: Vec<keelshell_core::WorkflowAuditRecord>,
    overlay_focus: FocusHandle,
    modal_focus: FocusHandle,
    surface_focus: FocusHandle,
    navigation_focus: FocusHandle,
    modal_button_focus: std::cell::RefCell<HashMap<ElementId, WeakFocusHandle>>,
    modal_scope: modal_scope::ModalScope,
    saving: bool,
    state_reloading: bool,
    show_assistant: bool,
    show_navigation: bool,
    navigation_panel: NavigationPanel,
    navigation_tree: navigation::tree::NavigationTree,
    session_tab_scroll: ScrollHandle,
    session_tab_reveal: Option<SessionTabReveal>,
    assistant: Entity<AssistantPanel>,
    agent: Option<agent::AgentState>,
    ai_credentials: EphemeralCredentials,
    ai_settings: Option<Entity<AiSettingsPanel>>,
    ai_settings_subscription: Option<Subscription>,
    profile_sync: Option<Entity<crate::profile_sync::ProfileSyncPanel>>,
    profile_sync_subscription: Option<Subscription>,
    configuration_recovery: Option<Entity<crate::configuration_recovery::ConfigRecoveryPanel>>,
    configuration_recovery_subscription: Option<Subscription>,
    vault_settings: Option<Entity<VaultSettings>>,
    vault_settings_subscription: Option<Subscription>,
    update_panel: Option<Entity<UpdatePanel>>,
    update_service: Entity<UpdatePanel>,
    pending_update_check: Option<u64>,
    update_history_retry_after: Option<std::time::Instant>,
    command_target: Option<EntityId>,
    command_revision: u64,
    command_record_history: bool,
    remote_completion: remote_completion::CompletionState,
    suggestion_selected: usize,
    suggestion_scroll: ScrollHandle,
    suggestion_request: Option<commands::SuggestionRequest>,
    suggestion_cache: Vec<commands::CommandCandidate>,
    suggestion_job_running: bool,
    command_sources_revision: u64,
    snippet_sources: Arc<Vec<keelshell_core::Snippet>>,
    suggestion_dismissed: Option<(u64, String)>,
    snippet_search: Entity<InputState>,
    snippet_editor: Option<Entity<SnippetEditor>>,
    snippet_subscription: Option<Subscription>,
    snippet_editing: bool,
    ai_snippet_review: Option<AiSnippetReviewBinding>,
    snippet_delete: Option<keelshell_core::Snippet>,
    snippet_parameters: Option<Entity<crate::snippet_parameters::SnippetParameters>>,
    parameter_subscription: Option<Subscription>,
    parameter_ticket: Option<command_workflows::ParameterTicket>,
    batch_panel: Option<Entity<crate::batch_commands::BatchPanel>>,
    batch_subscription: Option<Subscription>,
    show_batch: bool,
    workflow_panel: Option<Entity<crate::workflow_commands::WorkflowPanel>>,
    workflow_subscription: Option<Subscription>,
    show_workflow: bool,
    runtime: Arc<tokio::runtime::Runtime>,
    remote_sessions: HashMap<EntityId, SshSession>,
    knowledge_source_ids: HashMap<EntityId, uuid::Uuid>,
    knowledge_source_revisions: HashMap<EntityId, u64>,
    command_histories: HashMap<EntityId, CommandHistory>,
    login: Option<LoginPrompt>,
    keyboard_interactive: Option<KeyboardInteractivePrompt>,
    host_approval: Option<HostApproval>,
    connecting: bool,
    route_jobs: usize,
    connect_route: Option<routing::ConnectRoute>,
    remote_hosts: HashMap<EntityId, String>,
    remote_connection_ids: HashMap<EntityId, uuid::Uuid>,
    panels: HashMap<EntityId, RemotePanels>,
    reconnect_bindings: HashMap<EntityId, reconnect::TabBinding>,
    archived_panels: HashMap<EntityId, RemotePanels>,
    show_archived: std::collections::HashSet<EntityId>,
    discard_archive: Option<EntityId>,
    _reconnect_poll: Task<()>,
    mcp: mcp::McpState,
    visible_panel: Option<ToolPanel>,
    terminal_observers: HashMap<EntityId, Subscription>,
    terminal_focus: HashMap<EntityId, Subscription>,
    tunnel_subscriptions: HashMap<EntityId, Subscription>,
    tunnel_runtime_subscriptions: HashMap<EntityId, Subscription>,
    // Keep runtime owners reachable after tab/archive removal until cleanup.
    tunnel_owners: HashMap<EntityId, Entity<crate::tunnels::TunnelsPanel>>,
    tunnel_rule_store_blocked: bool,
    _subscriptions: Vec<Subscription>,
}

fn input(placeholder: &str, value: &str, window: &mut Window, cx: &mut App) -> Entity<InputState> {
    cx.new(|cx| {
        let mut state = InputState::new(window, cx).placeholder(placeholder.to_owned());
        state.set_value(value.to_owned(), window, cx);
        state
    })
}

fn current_unix_timestamp() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_or(0, |duration| duration.as_secs())
}

impl Workspace {
    pub fn new(
        store: Arc<StateStore>,
        state: AppState,
        load_error: Option<String>,
        runtime: Arc<tokio::runtime::Runtime>,
        window: &mut Window,
        cx: &mut Context<Self>,
    ) -> Self {
        Self::new_window(store, state, load_error, runtime, true, window, cx)
    }

    pub(crate) fn new_window(
        store: Arc<StateStore>,
        state: AppState,
        load_error: Option<String>,
        runtime: Arc<tokio::runtime::Runtime>,
        restore: bool,
        window: &mut Window,
        cx: &mut Context<Self>,
    ) -> Self {
        let app_windows =
            crate::app_windows::AppWindows::for_store(&store, &state, runtime.clone(), cx);
        let window_id = uuid::Uuid::new_v4();
        let window_summary = Arc::new(std::sync::Mutex::new(crate::app_windows::WindowSummary {
            id: window_id,
            sequence: 0,
            session_count: 0,
            context: t(cx, "快速连接", "Quick connect").to_owned(),
        }));
        let configuration_epoch = app_windows
            .read(cx)
            .gate
            .lock()
            .map_or(0, |gate| gate.epoch());
        let workspace_owner = cx.weak_entity();
        app_windows.update(cx, |shared, _| {
            shared.register(crate::app_windows::Registration {
                id: window_id,
                window: window.window_handle(),
                workspace: workspace_owner,
                summary: window_summary.clone(),
            })
        });
        let weak = cx.weak_entity();
        window.on_window_should_close(cx, move |window, cx| {
            let _ = weak.update(cx, |view, cx| {
                view.request_window_close(window_lifecycle::CloseIntent::Window, window, cx)
            });
            false
        });
        let configuration_subscription =
            cx.subscribe_in(&app_windows, window, |view, _, _, window, cx| {
                view.observe_shared_configuration(window, cx);
            });
        crate::design::apply_settings(&state.settings, Some(window), cx);
        let appearance_subscription = cx.observe_window_appearance(window, |view, window, cx| {
            view.on_appearance_changed(window.appearance(), window, cx);
        });
        let navigation_keystrokes = Self::intercept_navigation_keys(window, cx);
        let terminal_keystrokes = Self::observe_terminal_selection(window, cx);
        let search = input(
            t(cx, "搜索连接名称、主机、用户…", "Search connections…"),
            "",
            window,
            cx,
        );
        let command_palette_query = input(
            t(cx, "搜索工作区动作…", "Search workspace actions…"),
            "",
            window,
            cx,
        );
        let command = cx.new(|cx| {
            TextareaState::new(window, cx).rows(2).placeholder(t(
                cx,
                "输入命令，确认目标后执行",
                "Enter a command and review its target",
            ))
        });
        let quick_connect = QuickConnectForm {
            host: input(
                t(cx, "主机或 IP 地址", "Host or IP address"),
                "",
                window,
                cx,
            ),
            port: input(t(cx, "端口", "Port"), "22", window, cx),
            username: input(t(cx, "SSH 用户名", "SSH username"), "", window, cx),
            key: input(
                t(
                    cx,
                    "私钥路径（可选，留空使用 SSH Agent）",
                    "Private key path (optional; empty uses SSH agent)",
                ),
                "",
                window,
                cx,
            ),
        };
        let completion_directory = input(
            t(
                cx,
                "绝对目录，或读取 SFTP 起点",
                "Absolute directory, or read SFTP base",
            ),
            "",
            window,
            cx,
        );
        let completion_directory_subscription = cx.subscribe_in(
            &completion_directory,
            window,
            |view, _, event: &InputEvent, _, cx| {
                if matches!(event, InputEvent::Change) {
                    view.completion_directory_changed(cx);
                }
            },
        );
        let completion_cursor_subscription =
            cx.observe_in(&command, window, |view, _, window, cx| {
                view.observe_completion_cursor(window, cx)
            });
        let snippet_search = input(
            t(
                cx,
                "搜索片段名称、命令、标签…",
                "Search snippets, commands, tags…",
            ),
            "",
            window,
            cx,
        );
        let snippet_subscription =
            cx.subscribe(&snippet_search, |_, _, _: &InputEvent, cx| cx.notify());
        let subscription = cx.subscribe(&search, |_, _, _: &InputEvent, cx| cx.notify());
        let command_palette_subscription =
            cx.subscribe(&command_palette_query, |view, _, event: &InputEvent, cx| {
                if matches!(event, InputEvent::Change) {
                    view.command_palette_selected = 0;
                }
                cx.notify();
            });
        let command_subscription = cx.subscribe_in(
            &command,
            window,
            |view, input, event: &InputEvent, _, cx| {
                if matches!(event, InputEvent::Change) {
                    view.cancel_remote_completion(cx);
                    view.command_revision = view.command_revision.wrapping_add(1);
                    view.suggestion_selected = 0;
                    // Undo can restore a deleted draft. Keep its target and
                    // history choice until an explicit new draft clears editing history.
                    if !input.read(cx).value().is_empty() && view.command_target.is_none() {
                        view.command_target = view.tabs.get(view.active).map(Entity::entity_id);
                    }
                    cx.notify();
                } else {
                    cx.notify();
                }
            },
        );
        let ai_credentials = EphemeralCredentials::new();
        let assistant = cx.new(|cx| {
            AssistantPanel::new(
                &state.settings.ai_profiles,
                &ai_credentials,
                runtime.clone(),
                window,
                cx,
            )
        });
        assistant
            .read(cx)
            .knowledge_library
            .clone()
            .update(cx, |panel, cx| panel.set_snapshot(&state, cx));
        let assistant_subscription = cx.subscribe_in(
            &assistant,
            window,
            |view, panel, event, window, cx| match event {
                AssistantEvent::Capture {
                    selection_only,
                    previous_run,
                } => {
                    if !panel.read(cx).agent_capture_current(*previous_run) {
                        return;
                    }
                    if let Some(terminal) = view.tabs.get(view.active) {
                        let terminal_id = terminal.entity_id();
                        let source = terminal.read(cx);
                        let text = if *selection_only {
                            source.selected_text()
                        } else {
                            source.visible_text()
                        };
                        let host = view
                            .remote_hosts
                            .get(&terminal_id)
                            .cloned()
                            .unwrap_or_default();
                        let session_id = format!("{:?}", terminal_id);
                        let source_id = *view
                            .knowledge_source_ids
                            .entry(terminal_id)
                            .or_insert_with(uuid::Uuid::new_v4);
                        let revision = view
                            .knowledge_source_revisions
                            .entry(terminal_id)
                            .or_insert(0);
                        *revision = revision.saturating_add(1);
                        panel.update(cx, |panel, cx| {
                            panel.set_context_snapshot(
                                KnowledgeCaptureSnapshot {
                                    text,
                                    host,
                                    session_id,
                                    source_id,
                                    revision: *revision,
                                    captured_at: current_unix_timestamp(),
                                    kind: if *selection_only {
                                        KnowledgeCaptureKind::Selection
                                    } else {
                                        KnowledgeCaptureKind::VisibleScreen
                                    },
                                },
                                cx,
                            )
                        });
                    }
                }
                AssistantEvent::AgentStart { run_id, session_id } => {
                    view.start_agent(*run_id, session_id, cx)
                }
                AssistantEvent::AgentProposed {
                    run_id,
                    action_id,
                    action,
                } => view.register_agent_proposal(*run_id, *action_id, action, cx),
                AssistantEvent::AgentPrepareFile {
                    run_id,
                    action_id,
                    action,
                } => view.prepare_agent_file(*run_id, *action_id, action, cx),
                AssistantEvent::AgentExecute {
                    run_id,
                    action_id,
                    action,
                } => view.execute_agent_action(*run_id, *action_id, action, cx),
                AssistantEvent::AgentActionRejected { run_id, action_id } => {
                    view.reject_agent_action(*run_id, *action_id)
                }
                AssistantEvent::SaveKnowledge { review_id } => {
                    let Some(entry) = panel.read(cx).knowledge_save_candidate(*review_id) else {
                        panel.update(cx, |panel, cx| panel.reject_knowledge_save(cx));
                        view.status = Message::new(
                            "本地知识审核已过期或未通过保存闸门。",
                            "The local knowledge review is stale or did not pass the save gate.",
                        );
                        cx.notify();
                        return;
                    };
                    let mut candidate = view.state.clone();
                    if let Err(error) = candidate.record_knowledge_entry(entry) {
                        panel.update(cx, |panel, cx| panel.reject_knowledge_save(cx));
                        view.status = Message::detail(
                            "本地知识未保存",
                            "Local knowledge was not saved",
                            error,
                        );
                        cx.notify();
                        return;
                    }
                    view.persist(
                        candidate,
                        AfterSave::Knowledge {
                            panel: panel.downgrade(),
                            review_id: *review_id,
                        },
                        window,
                        cx,
                    );
                }
                AssistantEvent::ReloadKnowledge { review_id } => {
                    view.reload_knowledge_state(panel.downgrade(), *review_id, window, cx);
                }
                AssistantEvent::ManageKnowledge { review_id } => {
                    view.apply_knowledge_change(*review_id, window, cx);
                }
                AssistantEvent::ReloadKnowledgeLibrary { token } => {
                    view.reload_knowledge_library(*token, window, cx);
                }
                AssistantEvent::AgentStop { run_id } => view.stop_agent(*run_id),
                AssistantEvent::OpenSettings => view.open_ai_settings(window, cx),
                AssistantEvent::SelectProfile(id) => {
                    if let Some(profile) = view
                        .state
                        .settings
                        .ai_profiles
                        .profiles
                        .iter()
                        .find(|profile| profile.id == *id)
                    {
                        view.status =
                            Message::detail("当前 AI 配置", "Current AI profile", &profile.name);
                        cx.notify();
                    }
                }
                AssistantEvent::SaveSnippet {
                    command,
                    target,
                    session_id,
                    review_id,
                } => view.handle_ai_snippet_save(
                    panel,
                    commands::AiSnippetSaveRequest {
                        command: command.clone(),
                        target: target.clone(),
                        session_id: session_id.clone(),
                        review_id: *review_id,
                    },
                    window,
                    cx,
                ),
                AssistantEvent::Suggestion {
                    command,
                    session_id,
                } => {
                    if let Some(terminal) = view
                        .tabs
                        .get(view.active)
                        .filter(|tab| format!("{:?}", tab.entity_id()) == *session_id)
                    {
                        let target = terminal.entity_id();
                        view.set_reviewed_command(command.clone(), Some(target), window, cx);
                        view.status = Message::new(
                            "已填入 AI 建议，请核对目标与命令后执行。",
                            "AI suggestion inserted. Review the target and command before running.",
                        );
                    } else {
                        view.status = Message::new(
                            "此建议属于另一会话，请先选择对应终端。",
                            "Suggestion belongs to another session. Select its terminal first.",
                        );
                    }
                    cx.notify();
                }
            },
        );
        let executor = cx.background_executor().clone();
        let reconnect_poll = cx.spawn_in(window, async move |this, cx| {
            loop {
                executor.timer(Duration::from_millis(200)).await;
                if this
                    .update_in(cx, |view, window, cx| {
                        view.poll_reconnect(window, cx);
                        view.retire_tunnel_owners(cx);
                        view.maintain_mcp(cx);
                        view.maintain_agent(cx);
                        view.close_orphaned_window_sessions(cx);
                        view.flush_update_check(window, cx);
                    })
                    .is_err()
                {
                    break;
                }
            }
        });
        let mcp = mcp::McpState::new(input(
            t(
                cx,
                "授权的 canonical 远程目录",
                "Granted canonical remote directory",
            ),
            "",
            window,
            cx,
        ));
        let snippet_sources = Arc::new(state.snippets.clone());
        let update_service = app_windows.read(cx).updater.clone();
        if load_error.is_some() {
            update_service.update(cx, |panel, cx| panel.suspend_background(cx));
        }
        let update_subscription =
            cx.subscribe_in(&update_service, window, |view, _, event, window, cx| {
                match event {
                    UpdatePanelEvent::Close => {
                        if view.app_windows.read(cx).update_owner == Some(view.window_id) {
                            view.app_windows
                                .update(cx, |shared, _| shared.update_owner = None);
                            view.update_panel = None;
                            view.focus_current_surface(window, cx);
                        }
                    }
                    UpdatePanelEvent::ReviewInstall => {
                        if view.app_windows.read(cx).update_owner == Some(view.window_id) {
                            view.request_window_close(
                                window_lifecycle::CloseIntent::Install,
                                window,
                                cx,
                            );
                        }
                    }
                    UpdatePanelEvent::Restart => {
                        let shared = view.app_windows.read(cx);
                        if shared.update_owner == Some(view.window_id)
                            && shared.quitting
                            && shared.quit_install
                            && shared
                                .windows
                                .iter()
                                .all(|entry| shared.cleaned.contains(&entry.id))
                        {
                            crate::terminal::shutdown_and_quit(cx);
                        }
                    }
                    UpdatePanelEvent::Preferences {
                        preferences,
                        revision,
                    } => {
                        if view.app_windows.read(cx).update_owner == Some(view.window_id) {
                            view.save_update_preferences(*preferences, *revision, window, cx);
                        }
                    }
                    UpdatePanelEvent::Checked(seconds) => {
                        if view
                            .app_windows
                            .read(cx)
                            .windows
                            .first()
                            .is_none_or(|entry| entry.id != view.window_id)
                        {
                            return;
                        }
                        view.pending_update_check = Some(
                            view.pending_update_check
                                .map_or(*seconds, |pending| pending.max(*seconds)),
                        );
                        view.flush_update_check(window, cx);
                    }
                }
                cx.notify();
            });
        let update_observer = cx.observe(&update_service, |_, _, cx| cx.notify());
        let layout_window_id = if restore {
            state
                .workspace_layout
                .as_ref()
                .map_or_else(uuid::Uuid::new_v4, |layout| layout.active_window)
        } else {
            uuid::Uuid::new_v4()
        };
        let mut workspace = Self {
            configuration_gate: app_windows.read(cx).gate.clone(),
            app_windows,
            window_summary,
            window_id,
            native_window: window.window_handle(),
            configuration_epoch,
            configuration_invalidated: false,
            close_review: None,
            closing: None,
            cleanup_unknown: None,
            closing_intent: None,
            worker_owners: Default::default(),
            owned_window_sessions: Vec::new(),
            session_dependencies: Vec::new(),
            retired_window_panels: Vec::new(),
            store,
            state,
            tabs: Vec::new(),
            active: 0,
            session_panes: pane_sessions::SessionPanes::new(),
            protocol_selection: Default::default(),
            pane_bounds: Default::default(),
            pane_canvas_size: Default::default(),
            pane_divider_focus: Default::default(),
            pane_generation: 0,
            pane_tab_ids: HashMap::new(),
            restored_tabs: HashMap::new(),
            layout_window_id,
            pane_zoomed: false,
            search,
            command,
            form: None,
            quick_connect,
            quick_password: false,
            command_palette_query,
            command_palette_selected: 0,
            openssh_review: None,
            status: load_error
                .map(|error| Message::detail("配置加载失败", "Configuration failed", error))
                .unwrap_or_else(|| {
                    Message::new("就绪，请选择 SSH 连接", "Ready. Select an SSH connection")
                }),
            show_connections: false,
            show_quick_connect: false,
            show_window_switcher: false,
            show_command_palette: false,
            show_appearance: false,
            library_filter: LibraryFilter::All,
            folder_form: None,
            destination_prompt: None,
            library_selection: Default::default(),
            library_batch_prompt: None,
            library_trash_undo: Vec::new(),
            pending_recents: Vec::new(),
            pending_batch_audits: Vec::new(),
            pending_workflow_audits: Vec::new(),
            overlay_focus: cx.focus_handle(),
            modal_focus: cx.focus_handle(),
            surface_focus: cx.focus_handle(),
            navigation_focus: cx.focus_handle(),
            modal_button_focus: std::cell::RefCell::new(HashMap::new()),
            modal_scope: modal_scope::ModalScope::default(),
            saving: false,
            state_reloading: false,
            show_assistant: false,
            show_navigation: true,
            navigation_panel: NavigationPanel::default(),
            navigation_tree: navigation::tree::NavigationTree::new(cx),
            session_tab_scroll: ScrollHandle::new(),
            session_tab_reveal: None,
            assistant,
            agent: None,
            ai_credentials,
            ai_settings: None,
            ai_settings_subscription: None,
            profile_sync: None,
            profile_sync_subscription: None,
            configuration_recovery: None,
            configuration_recovery_subscription: None,
            vault_settings: None,
            vault_settings_subscription: None,
            update_panel: None,
            update_service,
            pending_update_check: None,
            update_history_retry_after: None,
            command_target: None,
            command_revision: 0,
            command_record_history: true,
            remote_completion: remote_completion::CompletionState::new(completion_directory),
            suggestion_selected: 0,
            suggestion_scroll: ScrollHandle::new(),
            suggestion_request: None,
            suggestion_cache: Vec::new(),
            suggestion_job_running: false,
            command_sources_revision: 0,
            snippet_sources,
            suggestion_dismissed: None,
            snippet_search,
            snippet_editor: None,
            snippet_subscription: None,
            snippet_editing: false,
            ai_snippet_review: None,
            snippet_delete: None,
            snippet_parameters: None,
            parameter_subscription: None,
            parameter_ticket: None,
            batch_panel: None,
            batch_subscription: None,
            show_batch: false,
            workflow_panel: None,
            workflow_subscription: None,
            show_workflow: false,
            runtime,
            remote_sessions: HashMap::new(),
            knowledge_source_ids: HashMap::new(),
            knowledge_source_revisions: HashMap::new(),
            command_histories: HashMap::new(),
            login: None,
            keyboard_interactive: None,
            host_approval: None,
            connecting: false,
            route_jobs: 0,
            connect_route: None,
            remote_hosts: HashMap::new(),
            remote_connection_ids: HashMap::new(),
            panels: HashMap::new(),
            reconnect_bindings: HashMap::new(),
            archived_panels: HashMap::new(),
            show_archived: Default::default(),
            discard_archive: None,
            _reconnect_poll: reconnect_poll,
            mcp,
            visible_panel: None,
            terminal_observers: HashMap::new(),
            terminal_focus: HashMap::new(),
            tunnel_subscriptions: HashMap::new(),
            tunnel_runtime_subscriptions: HashMap::new(),
            tunnel_owners: HashMap::new(),
            tunnel_rule_store_blocked: false,
            _subscriptions: vec![
                configuration_subscription,
                update_subscription,
                update_observer,
                appearance_subscription,
                navigation_keystrokes,
                terminal_keystrokes,
                subscription,
                command_palette_subscription,
                assistant_subscription,
                command_subscription,
                snippet_subscription,
                completion_directory_subscription,
                completion_cursor_subscription,
            ],
        };
        if restore {
            workspace.restore_startup_layout(cx);
        }
        workspace.refresh_protocol_selection(cx);
        workspace
    }
    fn open_connections(
        &mut self,
        _: &OpenConnections,
        window: &mut Window,
        cx: &mut Context<Self>,
    ) {
        if self.show_quick_connect {
            self.show_quick_connect = false;
        }
        if self
            .active_modal()
            .is_some_and(|kind| kind != modal_scope::ModalKind::Manager)
        {
            self.focus_current_surface(window, cx);
            return;
        }
        self.show_connections = true;
        self.search.read(cx).focus_handle(cx).focus(window, cx);
        cx.notify();
    }
    fn close_tab(&mut self, _: &CloseTab, window: &mut Window, cx: &mut Context<Self>) {
        // Every close action resolves against the same scope used for rendering.
        if self.close_active_modal(window, cx) {
            return;
        }
        if self.connecting {
            self.cancel_connect_route(window, cx);
            return;
        }
        if let Some(tab) = self.tabs.get(self.active) {
            self.close_session_tab(tab.entity_id(), window, cx);
        } else {
            self.focus_current_surface(window, cx);
        }
    }

    fn close_session_tab(&mut self, id: EntityId, window: &mut Window, cx: &mut Context<Self>) {
        if self.active_modal().is_some() || self.connecting {
            return;
        }
        // A painted close control retains its original entity. Do not select
        // that target first: closing an inactive tab must retain the user's
        // active pane, its command review and every other leaf's selection.
        let Some(index) = self.tabs.iter().position(|tab| tab.entity_id() == id) else {
            return;
        };
        if self.tabs[index].read(cx).zmodem_close_busy() {
            self.status = Message::new(
                "请先在该终端完成或取消 Zmodem，并核对未知结果。",
                "Finish or cancel Zmodem in that terminal and inspect unknown outcomes first.",
            );
            cx.notify();
            return;
        }
        let closed_active = self.tabs.get(self.active).map(Entity::entity_id) == Some(id);
        let closed_restored = self.restored_tabs.contains_key(&id);
        if self
            .connect_route
            .as_ref()
            .and_then(|route| route.restored)
            .is_some_and(|target| target.entity == id)
        {
            self.cancel_connect_route(window, cx);
        }
        if !self.sync_session_panes() {
            cx.notify();
            return;
        }
        let next = match self.session_panes.remove(id) {
            Ok(next) => next,
            Err(error) => {
                self.status =
                    Message::detail("无法关闭会话面板", "Cannot close session pane", error);
                cx.notify();
                return;
            }
        };
        self.cancel_remote_completion(cx);
        self.remember_window_workers(cx);
        let terminal = self.tabs.remove(index);
        self.pane_tab_ids.remove(&terminal.entity_id());
        self.restored_tabs.remove(&terminal.entity_id());
        self.pane_generation = self.pane_generation.wrapping_add(1);
        let retired_session_id = format!("{:?}", terminal.entity_id());
        self.assistant.update(cx, |panel, cx| {
            panel.invalidate_session(&retired_session_id, cx)
        });
        self.forget_reconnect(terminal.entity_id(), window, cx);
        self.remote_sessions.remove(&terminal.entity_id());
        self.tunnel_subscriptions.remove(&terminal.entity_id());
        self.tunnel_runtime_subscriptions
            .remove(&terminal.entity_id());
        self.knowledge_source_ids.remove(&terminal.entity_id());
        self.knowledge_source_revisions
            .remove(&terminal.entity_id());
        self.command_histories.remove(&terminal.entity_id());
        self.remote_hosts.remove(&terminal.entity_id());
        self.remote_connection_ids.remove(&terminal.entity_id());
        if let Some(panels) = self.panels.remove(&terminal.entity_id()) {
            self.retired_window_panels.push(panels);
        }
        self.retire_tunnel_owners(cx);
        // Retiring a tab can leave an independent file,
        // monitor, tunnel or agent worker using the captured
        // SSH connection. Keep that connection until the
        // worker has published its terminal outcome.
        self.close_orphaned_window_sessions(cx);
        // Retiring the authoritative mapping must revoke the
        // backend token in this foreground turn, before a
        // paused write can resume.
        self.maintain_agent(cx);
        self.terminal_observers.remove(&terminal.entity_id());
        self.terminal_focus.remove(&terminal.entity_id());
        // Retirement revokes background MCP leases in this same UI turn.
        // Closing a shell channel does not close its shared SFTP connection.
        self.maintain_mcp(cx);
        self.maintain_command_workflows(cx);
        self.active = next
            .and_then(|id| self.tabs.iter().position(|tab| tab.entity_id() == id))
            .unwrap_or(self.tabs.len());
        self.refresh_protocol_selection(cx);
        if closed_active || !closed_restored {
            self.focus_current_surface(window, cx);
        }
        cx.notify();
    }

    /// Close route sessions that no remaining tab in this window can use.
    ///
    /// Route authentication may retain intermediate hop handles so a window
    /// close can clean up a late completion. A normal tab close still has to
    /// release those handles when the last tab using the route disappears.
    /// Sessions shared by another tab remain owned by that tab's window.
    fn retain_route_dependencies(&self, active: &[SshSession]) -> Vec<SshSession> {
        let mut required = active.to_vec();
        let mut changed = true;
        while changed {
            changed = false;
            for (child, parent) in &self.session_dependencies {
                if required
                    .iter()
                    .any(|session| session.same_connection(child))
                    && !required
                        .iter()
                        .any(|session| session.same_connection(parent))
                {
                    required.push(parent.clone());
                    changed = true;
                }
            }
        }
        required
    }

    fn remember_session_dependency(&mut self, child: &SshSession, parent: &SshSession) {
        if !self
            .session_dependencies
            .iter()
            .any(|(known_child, known_parent)| {
                known_child.same_connection(child) && known_parent.same_connection(parent)
            })
        {
            self.session_dependencies
                .push((child.clone(), parent.clone()));
        }
    }

    fn close_orphaned_window_sessions(&mut self, cx: &App) {
        let active: Vec<_> = self.remote_sessions.values().cloned().collect();
        let required = self.retain_route_dependencies(&active);
        let background_busy = self.window_agent_busy(cx)
            || self.retired_window_panels.iter().any(|panels| {
                panels
                    .files
                    .as_ref()
                    .is_some_and(|panel| panel.read(cx).window_close_busy())
                    || panels
                        .monitor
                        .as_ref()
                        .is_some_and(|panel| panel.read(cx).window_close_busy(cx))
                    || panels
                        .tunnels
                        .as_ref()
                        .is_some_and(|panel| panel.read(cx).window_close_busy())
            });
        if background_busy {
            return;
        }
        let mut orphaned = Vec::new();
        self.owned_window_sessions.retain(|session| {
            if required
                .iter()
                .any(|remaining| remaining.same_connection(session))
            {
                true
            } else {
                orphaned.push(session.clone());
                false
            }
        });
        for session in orphaned {
            let runtime = self.runtime.clone();
            runtime.spawn(async move {
                let _ = tokio::time::timeout(Duration::from_secs(3), session.close()).await;
            });
        }
        self.session_dependencies.retain(|(child, parent)| {
            self.owned_window_sessions
                .iter()
                .any(|session| session.same_connection(child))
                && self
                    .owned_window_sessions
                    .iter()
                    .any(|session| session.same_connection(parent))
        });
    }

    fn split_remote(
        &mut self,
        axis: keelshell_core::SplitAxis,
        window: &mut Window,
        cx: &mut Context<Self>,
    ) {
        if self.active_modal().is_some() || self.connecting || !self.sync_session_panes() {
            self.focus_current_surface(window, cx);
            return;
        }
        let Some(tab) = self.tabs.get(self.active) else {
            return;
        };
        let id = tab.entity_id();
        let Some(session) = self.remote_sessions.get(&id).cloned() else {
            return;
        };
        if !tab.read(cx).is_open() {
            return;
        }
        if !self.session_panes.can_split(id) || self.tabs.len() >= keelshell_core::MAX_LAYOUT_TABS {
            self.status = Message::new("已达到分屏上限。", "The pane limit has been reached.");
            cx.notify();
            return;
        }
        let binding = self.reconnect_bindings.get(&id).cloned();
        let title = tab.read(cx).title.clone();
        let host = self.remote_hosts.get(&id).cloned().unwrap_or_default();
        let connection_id = self.remote_connection_ids.get(&id).copied();
        let Some(peer) = self.add_remote_tab(
            NewRemoteTab {
                session,
                title,
                host,
                connection_id,
                split: Some((id, axis)),
                restored: None,
            },
            window,
            cx,
        ) else {
            return;
        };
        if let Some(binding) = binding {
            self.reconnect_bindings.insert(peer, binding.for_split());
        }
        // The command bar and keyboard focus share the primary pane target.
        if let Some(primary) = self.tabs.get(self.active) {
            primary.read(cx).focus_handle(cx).focus(window, cx);
        }
        cx.notify();
    }
    fn watch_terminal(
        &mut self,
        terminal: &Entity<TerminalView>,
        window: &mut Window,
        cx: &mut Context<Self>,
    ) {
        self.worker_owners.insert(terminal.entity_id());
        let id = terminal.entity_id();
        let workspace = cx.weak_entity();
        terminal.update(cx, |terminal, _| {
            terminal.bind_input_selection(move |cx| {
                let _ = workspace.update(cx, |view, cx| view.select_terminal_input(id, cx));
            });
        });
        self.terminal_observers.insert(
            id,
            cx.observe_in(terminal, window, |view, _, window, cx| {
                view.maintain_remote_completion(window, cx);
                view.maintain_command_workflows(cx);
                {
                    view.poll_reconnect(window, cx);
                    view.maintain_mcp(cx);
                    view.maintain_agent(cx);
                };
                cx.notify();
            }),
        );
        let focus = terminal.read(cx).focus_handle(cx);
        self.terminal_focus.insert(
            id,
            cx.on_focus_in(&focus, window, move |view, _, cx| {
                view.select_terminal_input(id, cx);
            }),
        );
    }
    #[cfg(test)]
    fn displayed_terminals(&self) -> Vec<Entity<TerminalView>> {
        self.session_panes
            .displayed_sessions()
            .into_iter()
            .filter_map(|id| self.tabs.iter().find(|tab| tab.entity_id() == id).cloned())
            .collect()
    }
    fn add_remote_tab(
        &mut self,
        request: NewRemoteTab,
        window: &mut Window,
        cx: &mut Context<Self>,
    ) -> Option<EntityId> {
        let NewRemoteTab {
            session,
            title,
            host,
            connection_id,
            split: pane_split,
            restored,
        } = request;
        if restored.is_some_and(|target| {
            !self.restored_target_current(target)
                || connection_id != Some(target.connection)
                || pane_split.is_some()
        }) {
            return None;
        }
        if !self.sync_session_panes()
            || restored.is_none()
                && (self.tabs.len() >= keelshell_core::MAX_LAYOUT_TABS
                    || pane_split.is_none() && !self.session_panes.can_add())
        {
            self.status = Message::new(
                "当前面板的会话数量已达上限。",
                "This pane has reached its session limit.",
            );
            cx.notify();
            return None;
        }
        let terminal = crate::ssh_bridge::open(
            session.clone(),
            self.runtime.clone(),
            title,
            host.clone(),
            self.state.settings.font_size,
            self.state.settings.scrollback_lines,
            cx,
        );
        let id = terminal.entity_id();
        let mut panes = self.session_panes.clone();
        let placement = if let Some(target) = restored {
            panes.replace(target.entity, id)
        } else if let Some((primary, axis)) = pane_split {
            panes.split(primary, id, axis).map(|_| ())
        } else {
            let ids: Vec<_> = self
                .tabs
                .iter()
                .map(Entity::entity_id)
                .chain([id])
                .collect();
            panes.reconcile(&ids, Some(id))
        };
        if let Err(error) = placement {
            self.status = Message::detail("无法添加会话面板", "Cannot add session pane", error);
            cx.notify();
            return None;
        }
        let replacement = restored.and_then(|target| {
            self.tabs
                .iter()
                .position(|tab| tab.entity_id() == target.entity)
                .map(|index| (target, index))
        });
        if restored.is_some() && replacement.is_none() {
            return None;
        }
        self.session_panes = panes;
        if let Some((target, _)) = replacement {
            self.pane_tab_ids.remove(&target.entity);
            self.restored_tabs.remove(&target.entity);
            self.pane_tab_ids.insert(id, target.layout_tab);
        } else {
            self.pane_tab_ids.insert(id, uuid::Uuid::new_v4());
        }
        self.pane_generation = self.pane_generation.wrapping_add(1);
        self.remote_hosts.insert(id, host.clone());
        if let Some(connection_id) = connection_id {
            self.remote_connection_ids.insert(id, connection_id);
        }
        self.watch_terminal(&terminal, window, cx);
        self.remote_sessions.insert(id, session.clone());
        self.command_histories.insert(id, CommandHistory::default());
        let runtime = self.runtime.clone();
        let monitor =
            cx.new(|cx| crate::monitor::MonitorPanel::new(session, host, runtime, window, cx));
        let protocol_workspace = cx.weak_entity();
        monitor.update(cx, |panel, panel_cx| {
            panel.bind_protocol_authority(protocol_workspace, id, panel_cx)
        });
        self.panels.insert(
            id,
            RemotePanels {
                monitor: Some(monitor),
                ..Default::default()
            },
        );
        if let Some((_, index)) = replacement {
            // Only the inert owner is retired. Runtime authorities and command
            // reviews belonging to other entities retain their exact targets.
            self.tabs[index] = terminal;
        } else {
            self.tabs.push(terminal);
        }
        self.active = self
            .session_panes
            .active_session()
            .and_then(|active| self.tabs.iter().position(|tab| tab.entity_id() == active))
            .unwrap_or(self.tabs.len());
        self.refresh_protocol_selection(cx);
        self.show_connections = false;
        // Splitting retains the primary target and its chosen tool surface.
        // Only a newly connected session starts in the default Files view.
        if pane_split.is_none() && restored.is_none() {
            self.visible_panel = None;
            self.toggle_panel(ToolPanel::Files, window, cx);
        }
        if restored.is_none() || self.tabs.get(self.active).map(Entity::entity_id) == Some(id) {
            self.focus_current_surface(window, cx);
        }
        self.remember_window_workers(cx);
        Some(id)
    }
    fn on_appearance_changed(
        &mut self,
        appearance: WindowAppearance,
        window: &mut Window,
        cx: &mut Context<Self>,
    ) {
        if self.state.settings.theme == keelshell_core::Theme::System {
            crate::design::sync_system(appearance, window, cx);
        }
    }

    pub(crate) fn current_window_summary(&self, cx: &App) -> (usize, String) {
        let context = self
            .tabs
            .get(self.active)
            .and_then(|tab| self.remote_hosts.get(&tab.entity_id()))
            .cloned()
            .unwrap_or_else(|| t(cx, "快速连接", "Quick connect").to_owned());
        (self.tabs.len(), context)
    }

    fn refresh_window_summary(&self, cx: &App) {
        let (session_count, context) = self.current_window_summary(cx);
        if let Ok(mut summary) = self.window_summary.lock() {
            summary.session_count = session_count;
            summary.context = context;
        }
    }

    pub(super) fn toggle_window_switcher(&mut self, window: &mut Window, cx: &mut Context<Self>) {
        if self.active_modal().is_some() {
            return;
        }
        self.show_window_switcher = !self.show_window_switcher;
        if !self.show_window_switcher {
            self.focus_current_surface(window, cx);
        }
        cx.notify();
    }

    pub(super) fn close_window_switcher(&mut self, window: &mut Window, cx: &mut Context<Self>) {
        if self.show_window_switcher {
            self.show_window_switcher = false;
            self.focus_current_surface(window, cx);
            cx.notify();
        }
    }

    pub(super) fn activate_workspace_window(
        &mut self,
        id: uuid::Uuid,
        window: &mut Window,
        cx: &mut Context<Self>,
    ) {
        self.show_window_switcher = false;
        if id == self.window_id {
            window.activate_window();
            self.surface_focus.focus(window, cx);
            cx.notify();
            return;
        }
        let target = self.app_windows.read(cx).window_handle(id);
        let source = cx.weak_entity();
        if let Some(target) = target {
            cx.defer(move |cx| {
                if target
                    .update(cx, |_, window, _| window.activate_window())
                    .is_err()
                {
                    let _ = source.update(cx, |view, cx| {
                        view.status = Message::new(
                            "目标工作区窗口已关闭或不可用。",
                            "The selected workspace window is closed or unavailable.",
                        );
                        cx.notify();
                    });
                }
            });
        } else {
            self.status = Message::new(
                "目标工作区窗口已关闭或不可用。",
                "The selected workspace window is closed or unavailable.",
            );
        }
        cx.notify();
    }

    fn select_theme(
        &mut self,
        theme: keelshell_core::Theme,
        window: &mut Window,
        cx: &mut Context<Self>,
    ) {
        if self.state.settings.theme == theme {
            return;
        }
        let mut candidate = self.state.clone();
        candidate.settings.theme = theme;
        self.persist(candidate, AfterSave::Theme, window, cx);
    }

    fn switch_language(&mut self, window: &mut Window, cx: &mut Context<Self>) {
        if self.saving
            || self.state_reloading
            || self.configuration_recovery.is_some()
            || (self.vault_settings.is_some() || self.profile_sync.is_some())
        {
            return;
        }
        let language = match i18n::language(cx) {
            Language::ZhCn => Language::En,
            Language::En => Language::ZhCn,
        };
        let mut candidate = self.state.clone();
        candidate.settings.language = language;
        self.persist(candidate, AfterSave::None, window, cx);
    }
    fn apply_language(&mut self, language: Language, window: &mut Window, cx: &mut Context<Self>) {
        i18n::set_language(language, cx);
        self.refresh_library_batch_locale(window, cx);
        if let Some(panel) = &self.snippet_parameters {
            panel.update(cx, |panel, cx| panel.refresh_locale(window, cx));
        }
        if let Some(panel) = &self.batch_panel {
            panel.update(cx, |panel, cx| panel.refresh_locale(cx));
        }
        if let Some(panel) = &self.workflow_panel {
            panel.update(cx, |panel, cx| panel.refresh_locale(cx));
        }
        self.remote_completion.directory.update(cx, |input, cx| {
            input.set_placeholder(
                t(
                    cx,
                    "绝对目录，或读取 SFTP 起点",
                    "Absolute directory, or read SFTP base",
                ),
                window,
                cx,
            )
        });
        self.search.update(cx, |input, cx| {
            input.set_placeholder(
                t(
                    cx,
                    "搜索连接名称、主机、用户…",
                    "Search connections, hosts, users…",
                ),
                window,
                cx,
            )
        });
        self.command.update(cx, |input, cx| {
            input.set_placeholder(
                t(
                    cx,
                    "输入命令，确认目标后执行",
                    "Enter a command and review its target",
                ),
                window,
                cx,
            )
        });
        for (field, zh, en) in [
            (
                &self.quick_connect.host,
                "主机或 IP 地址",
                "Host or IP address",
            ),
            (&self.quick_connect.port, "端口", "Port"),
            (&self.quick_connect.username, "SSH 用户名", "SSH username"),
            (
                &self.quick_connect.key,
                "私钥路径（可选，留空使用 SSH Agent）",
                "Private key path (optional; empty uses SSH agent)",
            ),
        ] {
            field.update(cx, |input, cx| {
                input.set_placeholder(t(cx, zh, en), window, cx)
            });
        }
        if let Some(form) = &self.form {
            for (field, zh, en) in [
                (&form.name, "连接名称", "Connection name"),
                (&form.host, "主机或 IP 地址", "Host or IP address"),
                (&form.port, "端口", "Port"),
                (&form.username, "SSH 用户名", "SSH username"),
                (&form.tags, "标签，用逗号分隔", "Tags, separated by commas"),
                (
                    &form.key,
                    "私钥路径（留空使用 SSH Agent）",
                    "Private key path (empty: SSH agent)",
                ),
            ] {
                field.update(cx, |input, cx| {
                    input.set_placeholder(t(cx, zh, en), window, cx)
                });
            }
        }
        if let Some(login) = &self.login {
            login.proxy_secret.update(cx, |input, cx| {
                input.set_placeholder(
                    t(
                        cx,
                        "代理密码（仅本次使用）",
                        "Proxy password (this connection only)",
                    ),
                    window,
                    cx,
                )
            });
            login.secret.update(cx, |input, cx| {
                input.set_placeholder(
                    t(
                        cx,
                        "密码或私钥口令（本次使用，不保存）",
                        "Password or key passphrase (not saved)",
                    ),
                    window,
                    cx,
                )
            });
            login.master.update(cx, |input, cx| {
                input.set_placeholder(t(cx, "凭据库主密码", "Vault master password"), window, cx)
            });
            login.confirmation.update(cx, |input, cx| {
                input.set_placeholder(
                    t(cx, "再次输入主密码", "Confirm master password"),
                    window,
                    cx,
                )
            });
        }
        if let Some(form) = &self.form {
            form.proxy_editor
                .update(cx, |editor, cx| editor.refresh_locale(window, cx));
            form.reconnect_editor
                .update(cx, |editor, cx| editor.refresh_locale(cx));
            form.jump_picker
                .update(cx, |picker, cx| picker.refresh_locale(window, cx));
        }
        self.mcp.root.update(cx, |input, cx| {
            input.set_placeholder(
                t(
                    cx,
                    "授权的 canonical 远程目录",
                    "Granted canonical remote directory",
                ),
                window,
                cx,
            )
        });
        self.snippet_search.update(cx, |input, cx| {
            input.set_placeholder(
                t(
                    cx,
                    "搜索片段名称、命令、标签…",
                    "Search snippets, commands, tags…",
                ),
                window,
                cx,
            )
        });
        if let Some(panel) = &self.snippet_editor {
            panel.update(cx, |panel, cx| panel.refresh_locale(window, cx));
        }
        for terminal in &self.tabs {
            terminal.update(cx, |terminal, cx| terminal.refresh_locale(window, cx));
        }
        self.assistant
            .update(cx, |panel, cx| panel.refresh_locale(window, cx));
        if let Some(panel) = &self.ai_settings {
            panel.update(cx, |panel, cx| panel.refresh_locale(window, cx));
        }
        for panels in self.panels.values().chain(self.archived_panels.values()) {
            if let Some(panel) = &panels.files {
                panel.update(cx, |panel, cx| panel.refresh_locale(window, cx));
            }
            if let Some(panel) = &panels.monitor {
                panel.update(cx, |panel, cx| panel.refresh_locale(window, cx));
            }
            if let Some(panel) = &panels.tunnels {
                panel.update(cx, |panel, cx| panel.refresh_locale(window, cx));
            }
        }
    }
    fn open_ai_settings(&mut self, window: &mut Window, cx: &mut Context<Self>) {
        if self.state_reloading
            || self.library_batch_prompt.is_some()
            || self.configuration_recovery.is_some()
            || self.mcp.show
            || self.show_batch
            || self.show_workflow
            || self.ai_settings.is_some()
            || (self.vault_settings.is_some() || self.profile_sync.is_some())
            || self.snippet_modal_open()
            || self.connect_route.is_some()
        {
            return;
        }
        let panel = cx.new(|cx| {
            AiSettingsPanel::new(
                &self.state.settings.ai_profiles,
                &self.ai_credentials,
                self.runtime.clone(),
                self.store.path().with_file_name("vault.json"),
                window,
                cx,
            )
        });
        self.ai_settings_subscription = Some(cx.subscribe_in(
            &panel,
            window,
            |view, panel, event, window, cx| match event {
                AiSettingsEvent::Close => {
                    if !view.saving {
                        view.ai_settings = None;
                        view.ai_settings_subscription = None;
                        view.focus_current_surface(window, cx);
                        cx.notify();
                    }
                }
                AiSettingsEvent::Apply {
                    catalog,
                    credentials,
                    revision,
                } => {
                    if view.saving || view.state_reloading {
                        panel.update(cx, |panel, cx| {
                            panel.report_failure(
                                Message::new(
                                    if view.state_reloading {
                                        "正在重新加载配置，请完成后再应用 AI 设置"
                                    } else {
                                        "请等待当前保存完成"
                                    },
                                    if view.state_reloading {
                                        "Configuration reload is in progress; apply AI settings after it finishes"
                                    } else {
                                        "Wait for the current save to finish"
                                    },
                                ),
                                cx,
                            )
                        });
                        return;
                    }
                    let mut candidate = view.state.clone();
                    candidate.settings.ai_profiles = catalog.clone();
                    panel.update(cx, |panel, cx| panel.set_saving(true, cx));
                    view.persist(
                        candidate,
                        AfterSave::Ai {
                            panel: panel.downgrade(),
                            credentials: credentials.clone(),
                            revision: *revision,
                        },
                        window,
                        cx,
                    );
                }
            },
        ));
        self.ai_settings = Some(panel);
        cx.notify();
    }
    fn open_updates(&mut self, window: &mut Window, cx: &mut Context<Self>) {
        if !self.configuration_current(cx)
            || self.close_review.is_some()
            || self
                .app_windows
                .read(cx)
                .update_owner
                .is_some_and(|owner| owner != self.window_id)
        {
            return;
        }
        if self.state_reloading
            || self.configuration_recovery.is_some()
            || self.mcp.show
            || self.show_batch
            || self.show_workflow
            || self.ai_settings.is_some()
            || (self.vault_settings.is_some() || self.profile_sync.is_some())
            || self.update_panel.is_some()
            || self.snippet_modal_open()
            || self.connect_route.is_some()
        {
            return;
        }
        let panel = self.update_service.clone();
        self.app_windows
            .update(cx, |shared, _| shared.update_owner = Some(self.window_id));
        panel.update(cx, |panel, cx| panel.show(window, cx));
        self.update_panel = Some(panel);
        cx.notify();
    }
    fn toggle_assistant(&mut self, _: &ToggleAssistant, _: &mut Window, cx: &mut Context<Self>) {
        if self.active_modal().is_some() {
            return;
        }
        self.show_assistant = !self.show_assistant;
        cx.notify();
    }
    fn open_form(&mut self, window: &mut Window, cx: &mut Context<Self>) {
        if self.library_batch_prompt.is_some() {
            self.focus_current_surface(window, cx);
            return;
        }
        if self.saving {
            self.status = Message::new(
                "请等待当前保存完成，再编辑其他连接。",
                "Wait for the current save before opening another connection.",
            );
            cx.notify();
            return;
        }
        self.form = Some(ConnectionForm {
            id: None,
            proxy_editor: cx.new(|cx| ProxyEditor::new(None, window, cx)),
            reconnect_editor: cx.new(|cx| {
                ReconnectEditor::new(keelshell_core::ReconnectPolicy::Manual, window, cx)
            }),
            jump_picker: cx.new(|cx| JumpHostPicker::new(&self.state, None, None, window, cx)),
            password: true,
            name: input(t(cx, "连接名称", "e.g. Staging API"), "", window, cx),
            host: input(
                t(cx, "主机或 IP 地址", "Host or IP address"),
                "",
                window,
                cx,
            ),
            port: input(t(cx, "端口", "Port"), "22", window, cx),
            username: input(t(cx, "SSH 用户名", "SSH username"), "", window, cx),
            folder_id: match self.library_filter {
                LibraryFilter::Folder(id) => id,
                _ => None,
            },
            tags: input(
                t(cx, "标签，用逗号分隔", "Tags, separated by commas"),
                "",
                window,
                cx,
            ),
            key: input(
                t(
                    cx,
                    "私钥路径（留空使用 SSH Agent）",
                    "Private key path (empty: SSH agent)",
                ),
                "",
                window,
                cx,
            ),
        });
        if let Some(form) = &self.form {
            form.name.read(cx).focus_handle(cx).focus(window, cx);
        }
        cx.notify();
    }

    fn quick_connection(&self, cx: &App) -> Result<Connection, Message> {
        let host = self.quick_connect.host.read(cx).value().trim().to_owned();
        let username = self
            .quick_connect
            .username
            .read(cx)
            .value()
            .trim()
            .to_owned();
        let port = self.quick_connect.port.read(cx).value().trim().to_owned();
        let port = port.parse::<u16>().map_err(|_| {
            Message::new(
                "端口须为 1 至 65535 的整数",
                "Port must be a number from 1 to 65535",
            )
        })?;
        let key = self.quick_connect.key.read(cx).value().trim().to_owned();
        let mut connection = Connection::new(format!("{username}@{host}"), host, username);
        connection.port = port;
        connection.auth = if self.quick_password {
            AuthMethod::Password
        } else if key.is_empty() {
            AuthMethod::Agent
        } else {
            AuthMethod::PrivateKey { path: key.into() }
        };
        connection.validate().map_err(|error| {
            Message::detail(
                "快速连接参数无效",
                "Quick connection parameters are invalid",
                error,
            )
        })?;
        Ok(connection)
    }

    /// Submit the one-time draft through the regular SSH route and
    /// authentication flow. This never writes the draft to the connection
    /// library; successful one-time sessions are therefore absent from the
    /// persistent recent-profile list as well.
    pub(super) fn connect_quick(&mut self, window: &mut Window, cx: &mut Context<Self>) {
        let connection = match self.quick_connection(cx) {
            Ok(connection) => connection,
            Err(message) => {
                self.status = message;
                cx.notify();
                return;
            }
        };
        self.show_quick_connect = false;
        self.request_ephemeral_connect(connection, window, cx);
    }

    /// Copy the one-time endpoint draft into the normal connection editor.
    /// Persistence still requires the editor's explicit Save action.
    pub(super) fn save_quick_as_profile(&mut self, window: &mut Window, cx: &mut Context<Self>) {
        if self.saving {
            return;
        }
        let host = self.quick_connect.host.read(cx).value().to_string();
        let port = self.quick_connect.port.read(cx).value().to_string();
        let username = self.quick_connect.username.read(cx).value().to_string();
        let key = self.quick_connect.key.read(cx).value().to_string();
        let name = format!("{}@{}", username.trim(), host.trim());
        let password = self.quick_password;
        self.show_quick_connect = false;
        self.open_form(window, cx);
        if let Some(form) = self.form.as_ref() {
            form.name
                .update(cx, |input, cx| input.set_value(name, window, cx));
            form.host
                .update(cx, |input, cx| input.set_value(host, window, cx));
            form.port
                .update(cx, |input, cx| input.set_value(port, window, cx));
            form.username
                .update(cx, |input, cx| input.set_value(username, window, cx));
            form.key
                .update(cx, |input, cx| input.set_value(key, window, cx));
        }
        if let Some(form) = self.form.as_mut() {
            form.password = password;
        }
        cx.notify();
    }

    fn save_connection(&mut self, window: &mut Window, cx: &mut Context<Self>) {
        if self.saving {
            return;
        }
        let form_id = self.form.as_ref().and_then(|form| form.id);
        let original = form_id.and_then(|id| {
            self.state
                .connections
                .iter()
                .find(|item| item.id == id)
                .cloned()
        });
        if form_id.is_some() && original.is_none() {
            self.status = Message::new(
                "连接已移除，编辑未保存；请重新选择当前连接。",
                "The connection was removed; edits were not saved. Select the current profile.",
            );
            cx.notify();
            return;
        }
        let Some(form) = self.form.as_ref() else {
            return;
        };
        let mut connection = Connection::new(
            form.name.read(cx).value().to_string(),
            form.host.read(cx).value().to_string(),
            form.username.read(cx).value().to_string(),
        );
        connection.jump_host = form.jump_picker.read(cx).selected();
        match form.reconnect_editor.read(cx).draft(cx) {
            Ok(policy) => connection.reconnect = policy,
            Err(error) => {
                self.status = error;
                cx.notify();
                return;
            }
        }
        match form.proxy_editor.read(cx).draft(cx) {
            Ok(proxy) => connection.proxy = proxy,
            Err(error) => {
                self.status = error;
                cx.notify();
                return;
            }
        }
        connection.tags = form
            .tags
            .read(cx)
            .value()
            .split(',')
            .map(str::trim)
            .filter(|tag| !tag.is_empty())
            .map(str::to_owned)
            .collect();
        let folder_id = form.folder_id;
        if let Some(id) = form_id {
            connection.id = id;
            if let Some(original) = original.as_ref() {
                connection.group = original.group.clone();
                connection.favorite = original.favorite;
            }
        }
        let port = form.port.read(cx).value();
        match port.parse::<u16>() {
            Ok(port) => connection.port = port,
            Err(_) => {
                self.status = Message::new(
                    "端口须为 1 至 65535 的整数",
                    "Port must be a number from 1 to 65535",
                );
                cx.notify();
                return;
            }
        }
        let key = form.key.read(cx).value();
        if form.password {
            connection.auth = AuthMethod::Password;
        } else if !key.trim().is_empty() {
            connection.auth = AuthMethod::PrivateKey {
                path: key.trim().into(),
            };
        }
        if connection.proxy.is_some() && !connection.host.is_ascii() {
            self.status = Message::new(
                "使用代理时，目标主机须为 ASCII 域名或 IP；国际域名请使用 punycode 格式。",
                "A proxied target requires an ASCII hostname or IP; use punycode for internationalized domains.",
            );
            cx.notify();
            return;
        }
        if let Err(error) = connection.validate() {
            self.status = Message::detail("操作失败", "Operation failed", error);
            cx.notify();
            return;
        }
        if let Some(original) = original.as_ref()
            && vault::same_destination(original, &connection)
        {
            connection.credential_ref = original.credential_ref;
        }
        let after = AfterSave::Connection {
            id: connection.id,
            signature: form.signature(cx),
        };
        let mut candidate = self.state.clone();
        let connection_id = connection.id;
        if form_id.is_some() {
            if let Err(error) = candidate.update_connection(connection) {
                self.status = Message::detail(
                    "连接或跳板路线无效，未保存",
                    "Connection or jump route invalid; not saved",
                    error,
                );
                cx.notify();
                return;
            }
        } else {
            candidate.connections.push(connection);
        }
        if let Err(error) = candidate.move_connection(connection_id, folder_id) {
            self.status = Message::detail("文件夹无效，未保存", "Folder invalid; not saved", error);
            cx.notify();
            return;
        }
        self.persist(candidate, after, window, cx);
    }
    fn export_connections(&mut self, cx: &mut Context<Self>) {
        match self.state.export_connections() {
            Ok(document) => {
                cx.write_to_clipboard(ClipboardItem::new_string(document));
                self.status = Message::new(
                    "连接 JSON 已复制到剪贴板（不包含密码或私钥内容）",
                    "Connection JSON copied to the clipboard (passwords and key contents are excluded)",
                );
            }
            Err(error) => {
                self.status = Message::detail("导出失败", "Export failed", error);
            }
        }
        cx.notify();
    }
    fn import_connections(&mut self, window: &mut Window, cx: &mut Context<Self>) {
        if self.saving {
            self.status = Message::new(
                "请等待当前保存完成，再导入连接。",
                "Wait for the current save to finish before importing connections.",
            );
            cx.notify();
            return;
        }
        let Some(document) = cx.read_from_clipboard().and_then(|item| item.text()) else {
            self.status = Message::new(
                "剪贴板中没有可读取的连接 JSON。",
                "The clipboard does not contain readable connection JSON.",
            );
            cx.notify();
            return;
        };
        let mut candidate = self.state.clone();
        match candidate.import_connections(&document) {
            Ok(report) if candidate == self.state => {
                self.status = Message::new(
                    format!("没有新增连接或文件夹，跳过 {} 条重复记录。", report.skipped),
                    format!(
                        "No connections or folders added; skipped {} duplicate records.",
                        report.skipped
                    ),
                );
                cx.notify();
            }
            Ok(report) => {
                let folders_added = candidate
                    .folders
                    .len()
                    .saturating_sub(self.state.folders.len());
                self.persist(
                    candidate,
                    AfterSave::ConnectionsImported {
                        added: report.added,
                        skipped: report.skipped,
                        folders_added,
                        warnings: 0,
                    },
                    window,
                    cx,
                )
            }
            Err(error) => {
                self.status = Message::detail(
                    "导入失败，未修改连接库",
                    "Import failed; the library was not changed",
                    error,
                );
                cx.notify();
            }
        }
    }
    fn toggle_favorite(&mut self, id: uuid::Uuid, window: &mut Window, cx: &mut Context<Self>) {
        if self.saving {
            return;
        }
        let mut candidate = self.state.clone();
        match candidate.toggle_connection_favorite(id) {
            Ok(favorite) => self.persist(
                candidate,
                AfterSave::ConnectionFavorite { favorite },
                window,
                cx,
            ),
            Err(error) => {
                self.status = Message::detail("收藏状态更新失败", "Favorite update failed", error);
                cx.notify();
            }
        }
    }
    fn delete_connection(&mut self, id: uuid::Uuid, window: &mut Window, cx: &mut Context<Self>) {
        if self.saving {
            return;
        }
        let mut candidate = self.state.clone();
        let removed = match candidate.soft_delete_connection(id, library::now_seconds()) {
            Ok(connection) => connection,
            Err(error) => {
                self.status = Message::detail("移入回收站失败", "Move to trash failed", error);
                cx.notify();
                return;
            }
        };
        self.persist(
            candidate,
            AfterSave::ConnectionDeleted { name: removed.name },
            window,
            cx,
        );
    }
    fn reload_knowledge_state(
        &mut self,
        panel: WeakEntity<AssistantPanel>,
        review_id: uuid::Uuid,
        window: &mut Window,
        cx: &mut Context<Self>,
    ) {
        if self.saving
            || self.state_reloading
            || self.ai_settings.is_some()
            || self.vault_settings.is_some()
            || self.profile_sync.is_some()
            || self.update_panel.is_some()
            || self.configuration_recovery.is_some()
        {
            self.status = Message::new(
                "正在保存、重新加载或编辑 AI 配置，请完成后再重新加载。",
                "A save, reload, or AI configuration edit is in progress. Finish it before reloading.",
            );
            cx.notify();
            return;
        }
        let Some(panel_entity) = panel.upgrade() else {
            return;
        };
        let accepted = panel_entity.update(cx, |panel, cx| {
            panel.mark_knowledge_reload_pending(review_id, cx)
        });
        if !accepted {
            self.status = Message::new(
                "本地知识重新加载请求已过期，请重新生成预览。",
                "The local knowledge reload request is stale; build a fresh preview.",
            );
            cx.notify();
            return;
        }
        self.state_reloading = true;
        self.set_tunnel_rule_configuration_busy(true, cx);
        self.status = Message::new("正在重新加载本机配置…", "Reloading local configuration…");
        let store = self.store.clone();
        let gate = self.configuration_gate.clone();
        let owner = self.window_id;
        let reload = match crate::app_windows::ConfigurationGate::begin_reload_lease(&gate, owner) {
            Ok(reload) => reload,
            Err(_) => {
                self.state_reloading = false;
                return;
            }
        };
        let task = cx.background_executor().spawn(async move {
            let result = store.load();
            reload.finish(result.as_ref().ok());
            result
        });
        cx.spawn_in(window, async move |this, cx| {
            let result = task.await;
            let _ = this.update_in(cx, |view, window, cx| {
                view.state_reloading = false;
                view.set_tunnel_rule_configuration_busy(false, cx);
                match result {
                    Ok(state) => {
                        let accepted = panel
                            .upgrade()
                            .map(|panel| {
                                panel.update(cx, |panel, cx| {
                                    panel.mark_knowledge_reload_succeeded(review_id, cx)
                                })
                            })
                            .unwrap_or(false);
                        if accepted {
                            view.accept_reloaded_knowledge_state(state, window, cx);
                            view.status = Message::new(
                                "配置已重新加载；旧知识审核已清除，请重新生成预览。",
                                "Configuration reloaded; the old knowledge review was cleared. Build a fresh preview.",
                            );
                        } else {
                            view.status = Message::new(
                                "配置已读取，但当前知识审核已经过期。",
                                "Configuration was read, but the current knowledge review is stale.",
                            );
                        }
                    }
                    Err(error) => {
                        view.mark_tunnel_rule_store_uncertain(cx);
                        view.configuration_invalidated = true;
                        let accepted = panel
                            .upgrade()
                            .map(|panel| {
                                panel.update(cx, |panel, cx| {
                                    panel.mark_knowledge_reload_failed(review_id, &error, cx)
                                })
                            })
                            .unwrap_or(false);
                        if accepted {
                            view.status = Message::detail(
                                "配置重新加载失败，知识保存仍被阻止",
                                "Configuration reload failed; knowledge saving remains blocked",
                                error,
                            );
                        }
                    }
                }
                cx.notify();
            });
        })
        .detach();
    }

    fn persist(
        &mut self,
        mut candidate: AppState,
        after: AfterSave,
        window: &mut Window,
        cx: &mut Context<Self>,
    ) {
        if let Some(seconds) = self.pending_update_check {
            candidate.settings.updates.last_successful_check = Some(
                candidate
                    .settings
                    .updates
                    .last_successful_check
                    .map_or(seconds, |last| last.max(seconds)),
            );
        }
        // Apply is an event boundary too. Recheck the immutable catalog and its
        // complete credential snapshot before any background store write; a
        // delayed or directly emitted event must not bypass the panel's guard.
        if let AfterSave::Ai {
            panel, credentials, ..
        } = &after
            && crate::ai_request_options::validate_catalog_metadata(
                &candidate.settings.ai_profiles,
                credentials,
            )
            .is_err()
        {
            let message = Message::new(
                "配置文字包含已知秘密或秘密集合超限，未写入配置。",
                "Configuration text contains a known secret or the secret set exceeds its limit. Configuration was not written.",
            );
            if let Some(panel) = panel.upgrade() {
                panel.update(cx, |panel, cx| panel.report_failure(message.clone(), cx));
            }
            self.status = message;
            cx.notify();
            return;
        }
        if self.configuration_recovery.is_some()
            || (self.vault_settings.is_some() || self.profile_sync.is_some())
            || (self.snippet_modal_open()
                && !matches!(
                    &after,
                    AfterSave::SnippetSaved { .. }
                        | AfterSave::SnippetDeleted { .. }
                        | AfterSave::None
                ))
        {
            self.status = Message::new(
                "请先关闭配置管理面板，再修改配置。",
                "Close the configuration management panel before changing configuration.",
            );
            cx.notify();
            return;
        }
        if self.saving || self.state_reloading {
            self.status = Message::new(
                "正在保存或重新加载，请完成后重试本次修改。",
                "A save or reload is in progress. Wait for it to finish, then retry this change.",
            );
            cx.notify();
            return;
        }
        let update_history = matches!(&after, AfterSave::UpdateHistory);
        let Some(write_lease) = self.acquire_configuration_write(cx) else {
            return;
        };
        if let AfterSave::KnowledgeLibrary { panel, review_id } = &after
            && !panel
                .upgrade()
                .is_some_and(|panel| panel.update(cx, |panel, cx| panel.begin_save(*review_id, cx)))
        {
            write_lease.cancel_before_dispatch();
            return;
        }
        self.saving = true;
        self.set_tunnel_rule_configuration_busy(true, cx);
        if let AfterSave::Knowledge { panel, review_id } = &after
            && let Some(panel) = panel.upgrade()
        {
            panel.update(cx, |panel, cx| {
                panel.mark_knowledge_save_pending(*review_id, cx)
            });
        }
        if !update_history {
            self.status = Message::new("正在保存…", "Saving…");
        }
        let store = self.store.clone();
        let state = candidate.clone();
        let task = cx.background_executor().spawn(async move {
            let result = store.save(&state);
            write_lease.finish(&result);
            result
        });
        cx.spawn_in(window, async move |this, cx| {
            let result = task.await;
            let _ = this.update_in(cx, |view, window, cx| {
                view.saving = false;
                view.set_tunnel_rule_configuration_busy(false, cx);
                let saved_successfully = result.is_ok();
                match result {
                    Ok(saved) => {
                        view.state = saved;
                        view.shared_commit_completed(cx);
                        view.apply_language(view.state.settings.language, window, cx);
                        view.refresh_knowledge_library(cx);
                        let tunnel_rule_saved = if let AfterSave::TunnelRule {
                            panel, operation, ..
                        } = &after
                        {
                            panel.upgrade().map(|panel| {
                                panel.update(cx, |panel, cx| {
                                    panel.mark_rule_mutation_succeeded(*operation, cx)
                                })
                            })
                        } else {
                            None
                        };
                        let tunnel_runtime_saved = if let AfterSave::TunnelRuntime {
                            panel,
                            operation,
                            snapshot_id,
                            removing,
                        } = &after
                        {
                            panel.upgrade().map(|panel| {
                                panel.update(cx, |panel, cx| {
                                    panel.mark_runtime_event_succeeded(
                                        *operation,
                                        *snapshot_id,
                                        *removing,
                                        cx,
                                    )
                                })
                            })
                        } else {
                            None
                        };
                        view.refresh_tunnel_panels(cx);
                        view.update_service.update(cx, |panel, cx| panel.set_preferences(view.state.settings.updates, cx));
                        if view.pending_update_check.is_some_and(|pending| view.state.settings.updates.last_successful_check.is_some_and(|saved| saved >= pending)) {
                            view.pending_update_check = None;
                            view.update_history_retry_after = None;
                        }
                        view.maintain_library_selection();
                        if let AfterSave::Trust { attempt, index } = &after {
                            view.accept_reconnect_trust(*attempt, *index);
                        }
                        view.invalidate_reconnect_profiles(window, cx);
                        view.revoke_stale_protocol_diagnostics(cx);
                        view.maintain_mcp(cx);
                        view.maintain_agent(cx);
                        let route_changed=view.invalidate_changed_route(window,cx);
                        // Appearance and update preferences/history do not change suggestion sources.
                        if !matches!(&after, AfterSave::Theme | AfterSave::Updates { .. } | AfterSave::UpdateHistory) {
                            view.snippet_sources = Arc::new(view.state.snippets.clone());
                            view.command_sources_revision = view.command_sources_revision.wrapping_add(1);
                        }
                        if !matches!(&after, AfterSave::UpdateHistory | AfterSave::Knowledge { .. }) {
                            view.status = Message::new("已保存到本机", "Saved locally");
                        }
                        match after {
                            AfterSave::None | AfterSave::UpdateHistory => {}
                            AfterSave::Updates { revision } => {
                                view.update_service.update(cx, |panel, cx| panel.preferences_saved(revision, view.state.settings.updates, cx));
                                view.status = Message::new("更新设置已保存", "Update settings saved");
                            }
                            AfterSave::Theme => {
                                crate::design::apply_settings(&view.state.settings, Some(window), cx);
                                view.status = Message::new("外观偏好已保存", "Appearance preference saved");
                            }
                            AfterSave::SnippetSaved { panel } => {
                                if view.snippet_editor.as_ref().is_some_and(|editor| editor.entity_id() == panel) {
                                    view.snippet_editor = None; view.snippet_subscription = None;
                                }
                                view.ai_snippet_review = None;
                                view.status = Message::new("命令片段已保存", "Command snippet saved");
                                view.focus_current_surface(window, cx);
                            }
                            AfterSave::SnippetDeleted { id } => {
                                if view.snippet_delete.as_ref().is_some_and(|snippet| snippet.id == id) { view.snippet_delete = None; }
                                view.status = Message::new("命令片段已删除", "Command snippet deleted");
                                view.focus_current_surface(window, cx);
                            }
                            AfterSave::Ai {
                                panel,
                                credentials,
                                revision,
                            } => {
                                view.ai_credentials = credentials;
                                view.assistant.update(cx, |assistant, cx| {
                                    assistant.set_profiles(
                                        &view.state.settings.ai_profiles,
                                        &view.ai_credentials,
                                        cx,
                                    )
                                });
                                if let Some(panel) = panel.upgrade() {
                                    panel.update(cx, |panel, cx| panel.mark_saved(revision, cx));
                                }
                            }
                            AfterSave::Connection { id, signature } => {
                                if view
                                    .form
                                    .as_ref()
                                    .is_some_and(|form| form.signature(cx) == signature)
                                {
                                    view.form = None;
                                    view.focus_current_surface(window, cx);
                                } else if let Some(form) = view.form.as_mut() {
                                    form.id = Some(id);
                                    view.status = Message::new(
                                        "已保存，后续输入的修改仍待保存。",
                                        "Saved. Your newer form edits are still pending.",
                                    );
                                }
                            }
                            AfterSave::Trust { attempt, index } => {
                                view.finish_host_trust(attempt, index, window, cx);
                            }
                            AfterSave::ConnectionsImported { added, skipped, folders_added, warnings } => {
                                view.status = Message::new(
                                    format!("已导入 {added} 条连接和 {folders_added} 个文件夹，跳过 {skipped} 条重复记录；有 {warnings} 项配置需要审阅。"),
                                    format!("Imported {added} connections and {folders_added} folders; skipped {skipped} duplicates; {warnings} config items need review."),
                                );
                            }
                            AfterSave::ConnectionFavorite { favorite } => {
                                view.status = Message::new(
                                    if favorite { "已加入收藏" } else { "已取消收藏" },
                                    if favorite { "Added to favorites" } else { "Removed from favorites" },
                                );
                            }
                            AfterSave::ConnectionDeleted { name } => {
                                view.status = Message::new(
                                    format!("已移入回收站：{name}，可随时恢复。"),
                                    format!("Moved to trash: {name}. You can restore it."),
                                );
                            }
                            AfterSave::FolderSaved { id, token } => {
                                if view.folder_form.as_ref().is_some_and(|form| form.token == token) {
                                    view.close_folder_form(window, cx);
                                }
                                view.library_filter = LibraryFilter::Folder(Some(id));
                                view.status = Message::new("文件夹已保存", "Folder saved");
                            }
                            AfterSave::FolderRemoved { id, token } => {
                                if view.folder_form.as_ref().is_some_and(|form| form.token == token) {
                                    view.close_folder_form(window, cx);
                                }
                                if view.library_filter == LibraryFilter::Folder(Some(id)) {
                                    view.library_filter = LibraryFilter::All;
                                }
                                view.status = Message::new("空文件夹已删除", "Empty folder removed");
                            }
                            AfterSave::ConnectionMoved { token } => {
                                if view.destination_prompt.as_ref().is_some_and(|prompt| prompt.token == token) {
                                    view.close_destination(window, cx);
                                }
                                view.status = Message::new("连接已移动", "Connection moved");
                            }
                            AfterSave::ConnectionRestored { name } => {
                                view.status = Message::new(format!("已恢复连接：{name}"), format!("Connection restored: {name}"));
                            }
                            AfterSave::RecentSaved => {
                                view.status = Message::new("已连接，最近使用记录已保存", "Connected; recent usage saved");
                            }
                            AfterSave::LibraryBatch { token, action, ids } => {
                                view.finish_library_batch(token, action, ids, window, cx);
                            }
                            AfterSave::WorkflowAudit { records } => {
                                view.pending_workflow_audits.retain(|pending| !records.iter().any(|saved| saved.id == pending.id));
                                view.status = Message::new("任务记录已保存（不含命令、输出、地址或参数）", "Task history saved (without commands, output, addresses or parameters)");
                                view.refresh_workflow_audit_history(cx);
                            }
                            AfterSave::Knowledge { panel, review_id } => {
                                let accepted_by_panel = panel
                                    .upgrade()
                                    .map(|panel| {
                                        panel.update(cx, |panel, cx| {
                                            panel.mark_knowledge_saved(review_id, cx)
                                        })
                                    })
                                    .unwrap_or(false);
                                view.status = if accepted_by_panel {
                                    Message::new(
                                        "本地知识已保存到 StateStore",
                                        "Local knowledge saved to StateStore",
                                    )
                                } else {
                                    Message::new(
                                        "本地知识写入已完成，但当前审核预览已过期；请重新加载配置后查看。",
                                        "Local knowledge write completed, but the current review is stale; reload the configuration before reviewing it again.",
                                    )
                                };
                            }
                            AfterSave::KnowledgeLibrary { panel, review_id } => {
                                if let Some(panel) = panel.upgrade() {
                                    panel.update(cx, |panel, cx| panel.finish_save(review_id, cx));
                                }
                                view.status = Message::new(
                                    "本地知识修改已保存",
                                    "Local knowledge changes saved",
                                );
                            }
                            AfterSave::TunnelRule { .. } => {
                                view.status = if tunnel_rule_saved == Some(true) {
                                    Message::new(
                                        "命名隧道规则已保存到 StateStore",
                                        "Named tunnel rule saved to StateStore",
                                    )
                                } else {
                                    Message::new(
                                        "命名隧道规则已保存，但当前编辑面板已过期。",
                                        "Named tunnel rule was saved, but the current editor is stale.",
                                    )
                                };
                            }
                            AfterSave::TunnelRuntime { removing, .. } => {
                                if tunnel_runtime_saved != Some(true) {
                                    view.status = Message::new(
                                        "运行状态已保存，但当前隧道面板已过期。",
                                        "Runtime state was saved, but the current tunnel panel is stale.",
                                    );
                                } else if removing {
                                    view.status = Message::new(
                                        "命名隧道清理已确认，恢复候选已移除。",
                                        "Named tunnel cleanup was confirmed; the recovery candidate was removed.",
                                    );
                                }
                            }
                            AfterSave::BatchAudit { .. } => {
                                view.status = Message::new(
                                    "批量审计摘要已保存（不含命令正文、输出或主机地址）",
                                    "Batch audit summary saved (without command text, output or host addresses)",
                                );
                            }
                            AfterSave::CredentialLinked { prompt, connection } => {
                                view.finish_credential_save(prompt, *connection, window, cx);
                            }
                        }
                        if route_changed { view.status=Message::new("配置已保存；连接路线已变化，当前连接尝试已取消。", "Profile saved; the route changed, so the current connection attempt was cancelled."); }
                    }
                    Err(error) => {
                        if let AfterSave::BatchAudit { records } = &after {
                            view.pending_batch_audits.extend(records.iter().cloned());
                        }
                        if matches!(&after, AfterSave::SnippetSaved { .. }) && let Some(panel) = &view.snippet_editor {
                            panel.update(cx, |panel, cx| panel.set_error(Message::detail("保存失败，草稿已保留；配置冲突时请重启后重试", "Save failed; draft preserved. Restart after a configuration conflict", &error), cx));
                        }
                        let organization_failure = Message::detail(
                            "保存失败，草稿已保留；如配置已被修改，请重启后重试",
                            "Save failed; draft retained. If configuration changed, restart before retrying",
                            &error,
                        );
                        if matches!(&after, AfterSave::LibraryBatch { .. })
                            && let Some(prompt) = &mut view.library_batch_prompt {
                            prompt.message = Some(organization_failure.clone());
                        }
                        if matches!(&after, AfterSave::FolderSaved { .. } | AfterSave::FolderRemoved { .. })
                            && let Some(form) = &mut view.folder_form {
                            form.message = Some(organization_failure.clone());
                        }
                        if matches!(&after, AfterSave::ConnectionMoved { .. })
                            && let Some(prompt) = &mut view.destination_prompt {
                            prompt.message = Some(organization_failure);
                        }
                        let credential_failure = if let AfterSave::CredentialLinked { prompt, .. } = &after {
                            let message = if matches!(error, keelshell_core::Error::Conflict) {
                                Message::new(
                                    "连接配置保存失败：配置已被其他操作修改，未发起连接，密码输入已清空。加密条目可能已保存。请先保存其他工作，再重启应用以重新加载配置后重试。",
                                    "Profile save failed because the configuration changed. No connection started; password inputs were cleared. An encrypted entry may remain. Save your other work, then restart the app to reload the configuration before retrying.",
                                )
                            } else {
                                Message::new(
                                    "连接配置保存失败，未发起连接，密码输入已清空。加密条目可能已保存，请检查配置文件及其访问权限。",
                                    "Profile save failed; no connection started and password inputs were cleared. An encrypted entry may remain. Check the configuration file and its permissions.",
                                )
                            };
                            if let Some(login) = view.login.as_mut().filter(|login| login.id == *prompt) {
                                login.busy = false;
                                login.message = Some(message.clone());
                            }
                            Some(message)
                        } else {
                            None
                        };
                        if matches!(&after, AfterSave::Updates { .. }) {
                            view.update_service.update(cx, |panel, cx| panel.preferences_failed(cx));
                        }
                        if view.pending_update_check.is_some() {
                            view.update_history_retry_after = Some(std::time::Instant::now() + Duration::from_secs(30));
                        }
                        if let AfterSave::Ai { panel, .. } = &after
                            && let Some(panel) = panel.upgrade()
                        {
                            panel.update(cx, |panel, cx| {
                                panel.report_failure(
                                    Message::detail(
                                        "保存失败，草稿已保留",
                                        "Save failed; draft preserved",
                                        &error,
                                    ),
                                    cx,
                                )
                            });
                        }
                        if let AfterSave::Knowledge { panel, review_id } = &after
                            && let Some(panel) = panel.upgrade()
                        {
                            panel.update(cx, |panel, cx| {
                                if matches!(&error, keelshell_core::Error::Conflict) {
                                    panel.mark_knowledge_save_conflict(*review_id, cx);
                                } else {
                                    panel.mark_knowledge_save_failed(
                                        *review_id,
                                        matches!(&error, keelshell_core::Error::Durability(_)),
                                        cx,
                                    );
                                }
                            });
                        }
                        if let AfterSave::KnowledgeLibrary { panel, review_id } = &after
                            && let Some(panel) = panel.upgrade()
                        {
                            panel.update(cx, |panel, cx| panel.save_failed(*review_id, &error, cx));
                        }
                        if matches!(
                            &after,
                            AfterSave::TunnelRule { .. } | AfterSave::TunnelRuntime { .. }
                        )
                            || matches!(&error, keelshell_core::Error::Conflict | keelshell_core::Error::Durability(_))
                        {
                            view.mark_tunnel_rule_store_uncertain(cx);
                        }
                        if matches!(
                            &error,
                            keelshell_core::Error::Conflict | keelshell_core::Error::Durability(_)
                        ) {
                            // Run the shared invalidation side effects so
                            // command sources, reviews and transports cannot
                            // use an uncertain configuration. A credential
                            // failure retains its modal and a knowledge
                            // failure retains its non-retryable conflict
                            // review; both are updated below after shared
                            // authority has been invalidated.
                            if !view.configuration_invalidated {
                                match &after {
                                    AfterSave::CredentialLinked { .. } => {
                                        view.observe_shared_configuration_preserving_login(
                                            window, cx,
                                        );
                                    }
                                    AfterSave::Knowledge { .. } => {
                                        view.observe_shared_configuration_preserving_knowledge_review(
                                            window, cx,
                                        );
                                    }
                                    _ => view.observe_shared_configuration(window, cx),
                                }
                            }
                        }
                        if let AfterSave::TunnelRule { panel, operation } = &after
                            && let Some(panel) = panel.upgrade()
                        {
                            let message = if matches!(&error, keelshell_core::Error::Conflict) {
                                Message::new(
                                    "规则保存失败：配置已被其他操作修改，规则草稿已保留；请重新打开应用或重新加载配置，再编辑最新规则。",
                                    "Rule save failed because configuration changed elsewhere; the draft is retained. Reopen the app or reload configuration, then edit the latest rule.",
                                )
                            } else {
                                Message::detail("规则保存失败或结果未知，草稿已保留；请重新打开应用或重新加载配置后再编辑", "Rule save failed or its outcome is unknown; draft retained. Reopen the app or reload configuration before editing again", &error)
                            };
                            panel.update(cx, |panel, cx| {
                                panel.mark_rule_mutation_failed(*operation, message, true, cx)
                            });
                        }
                        if let AfterSave::TunnelRuntime {
                            panel,
                            operation,
                            ..
                        } = &after
                            && let Some(panel) = panel.upgrade()
                        {
                            panel.update(cx, |panel, cx| {
                                panel.mark_runtime_event_failed(
                                    *operation,
                                    Message::detail(
                                        "命名隧道运行状态保存失败或结果未知；候选已保留，请重新加载配置后再操作。",
                                        "Named tunnel runtime state could not be confirmed; the candidate was retained. Reload configuration before acting again.",
                                        &error,
                                    ),
                                    true,
                                    cx,
                                )
                            });
                        }
                        // observe_shared_configuration marks the shared
                        // tunnel controls busy while it revokes stale
                        // authority. The failed save has already completed,
                        // so restore the normal idle presentation before
                        // reporting the durable error.
                        view.set_tunnel_rule_configuration_busy(false, cx);
                        view.status = credential_failure.unwrap_or_else(|| Message::detail(
                            "保存失败，输入内容已保留",
                            "Save failed; input preserved",
                            error,
                        ))
                    }
                };
                view.observe_shared_configuration_if_needed(window, cx);
                view.resume_connect_route(window, cx);
                if saved_successfully {
                    view.flush_recent_connections(window, cx);
                    view.flush_batch_audits(window, cx);
                    view.flush_workflow_audits(window, cx);
                } else if !update_history {
                    view.pending_recents.clear();
                }
                if !update_history { view.refresh_workflow_audit_history(cx); }
                cx.notify();
            });
        })
        .detach();
        cx.notify();
    }

    fn import_openssh_connections(&mut self, window: &mut Window, cx: &mut Context<Self>) {
        if self.saving || self.openssh_review.is_some() {
            self.status = Message::new(
                "请等待当前保存完成，再导入 SSH 配置。",
                "Wait for the current save to finish before importing SSH configuration.",
            );
            cx.notify();
            return;
        }
        let Some(document) = cx.read_from_clipboard().and_then(|item| item.text()) else {
            self.status = Message::new(
                "剪贴板中没有可读取的 SSH 配置。",
                "The clipboard does not contain readable SSH configuration.",
            );
            cx.notify();
            return;
        };
        let mut candidate = self.state.clone();
        match candidate.import_openssh_config_report(&document) {
            Ok(report) if report.imported.added == 0 && report.warnings.is_empty() => {
                self.status = Message::new(
                    format!(
                        "没有新增连接，跳过 {} 条重复记录；有 {} 项需审阅。",
                        report.imported.skipped,
                        report.warnings.len()
                    ),
                    format!(
                        "No connections added; skipped {} duplicates; {} items need review.",
                        report.imported.skipped,
                        report.warnings.len()
                    ),
                );
                cx.notify();
            }
            Ok(report) => {
                self.openssh_review = Some(OpenSshImportReview::new(candidate, report));
                self.status = Message::new(
                    "请审阅 SSH 配置导入内容，确认后才会保存。",
                    "Review the SSH import; nothing is saved until you confirm.",
                );
                self.focus_current_surface(window, cx);
                cx.notify();
            }
            Err(error) => {
                self.status = Message::detail(
                    "SSH 配置导入失败，未修改连接库",
                    "SSH configuration import failed; the library was not changed",
                    error,
                );
                cx.notify();
            }
        }
    }
    fn run_command(&mut self, window: &mut Window, cx: &mut Context<Self>) {
        if self.command_surface_blocked() {
            return;
        }
        let text = self.command.read(cx).value().to_string();
        if text.trim().is_empty() {
            return;
        }
        if let Some(terminal) = self.tabs.get(self.active) {
            if self
                .command_target
                .is_some_and(|target| target != terminal.entity_id())
            {
                self.status = Message::new(
                    "命令属于另一会话，请切换到对应标签再执行。",
                    "Command belongs to another tab. Select that tab before running.",
                );
                cx.notify();
                return;
            }
            let queued = terminal.update(cx, |view, cx| {
                let result = view.try_write(format!("{text}\r").into_bytes());
                // Workspace already owns selection here; avoid calling back
                // into its leased entity through the terminal input hook.
                view.focus_handle(cx).focus(window, cx);
                cx.notify();
                result
            });
            if let Err(error) = queued {
                self.status = error;
                cx.notify();
                return;
            }
            if self.command_record_history {
                self.command_histories
                    .entry(terminal.entity_id())
                    .or_default()
                    .record(&text);
            }
            self.command_sources_revision = self.command_sources_revision.wrapping_add(1);
            self.set_reviewed_command(String::new(), None, window, cx);
            self.status = Message::new(
                "命令已加入当前远程会话发送队列",
                "Command queued in the active terminal",
            );
        } else {
            self.status = Message::new(
                "请先连接 SSH 主机再执行命令",
                "Open a terminal before running a command",
            );
        }
        cx.notify();
    }
    fn clear_command_history(&mut self, cx: &mut Context<Self>) {
        let Some(terminal) = self.tabs.get(self.active) else {
            return;
        };
        let changed = self
            .command_histories
            .get_mut(&terminal.entity_id())
            .is_some_and(CommandHistory::clear);
        self.command_sources_revision = self.command_sources_revision.wrapping_add(1);
        self.status = if changed {
            Message::new(
                "当前 SSH 会话的命令历史已清空",
                "Command history cleared for this SSH session",
            )
        } else {
            Message::new(
                "当前 SSH 会话没有命令历史",
                "This SSH session has no command history",
            )
        };
        cx.notify();
    }
    fn refresh_tunnel_panels(&mut self, cx: &mut Context<Self>) {
        self.update_tunnel_panels(false, cx);
    }

    fn reload_tunnel_panels(&mut self, cx: &mut Context<Self>) {
        self.tunnel_rule_store_blocked = false;
        self.update_tunnel_panels(true, cx);
    }

    fn update_tunnel_panels(&mut self, authoritative: bool, cx: &mut Context<Self>) {
        let state = self.state.clone();
        let mut panels = Vec::new();
        for (id, remote_panels) in self.panels.iter().chain(self.archived_panels.iter()) {
            if let Some(panel) = &remote_panels.tunnels {
                panels.push((panel.clone(), self.remote_connection_ids.get(id).copied()));
            }
        }
        for (panel, connection_id) in panels {
            panel.update(cx, |panel, cx| {
                if authoritative {
                    panel.reload_rule_state(state.clone(), connection_id, cx);
                } else {
                    panel.refresh_rule_state(Some(state.clone()), connection_id, cx);
                }
                if self.tunnel_rule_store_blocked {
                    panel.mark_rule_store_uncertain(cx);
                }
            });
        }
    }

    fn mark_tunnel_rule_store_uncertain(&mut self, cx: &mut Context<Self>) {
        self.tunnel_rule_store_blocked = true;
        for panels in self.panels.values().chain(self.archived_panels.values()) {
            if let Some(panel) = &panels.tunnels {
                panel.update(cx, |panel, cx| panel.mark_rule_store_uncertain(cx));
            }
        }
    }

    fn retire_tunnel_owners(&mut self, cx: &mut Context<Self>) {
        let retained: std::collections::HashSet<_> = self
            .panels
            .values()
            .chain(self.archived_panels.values())
            .filter_map(|panels| panels.tunnels.as_ref())
            .map(Entity::entity_id)
            .collect();
        self.tunnel_owners.retain(|id, panel| {
            retained.contains(id) || panel.update(cx, |panel, cx| panel.retire_workers(cx))
        });
        self.retired_window_panels.retain(|panels| {
            panels
                .files
                .as_ref()
                .is_some_and(|panel| panel.read(cx).window_close_busy())
                || panels
                    .monitor
                    .as_ref()
                    .is_some_and(|panel| panel.read(cx).window_close_busy(cx))
                || panels
                    .tunnels
                    .as_ref()
                    .is_some_and(|panel| panel.read(cx).window_close_busy())
        });
    }

    fn set_tunnel_rule_configuration_busy(&mut self, busy: bool, cx: &mut Context<Self>) {
        for panels in self.panels.values().chain(self.archived_panels.values()) {
            if let Some(panel) = &panels.tunnels {
                panel.update(cx, |panel, cx| panel.set_rule_configuration_busy(busy, cx));
            }
        }
    }

    fn handle_tunnel_rule_event(
        &mut self,
        panel: &Entity<crate::tunnels::TunnelsPanel>,
        event: &crate::tunnels::TunnelRuleEvent,
        window: &mut Window,
        cx: &mut Context<Self>,
    ) {
        // A subscription is not authority: require the original live panel,
        // saved-connection binding and exact pending review at this boundary.
        let bound = self.panels.iter().any(|(terminal, panels)| {
            panels.tunnels.as_ref() == Some(panel)
                && self.remote_connection_ids.get(terminal) == Some(&event.rule.connection_id)
        });
        if !bound || self.tunnel_rule_store_blocked || !panel.read(cx).accepts_rule_mutation(event)
        {
            panel.update(cx, |panel, cx| {
                panel.mark_rule_mutation_failed(
                    event.operation,
                    Message::new(
                        "隧道面板或审核已过期，未保存规则。",
                        "Tunnel panel or review expired; rule was not saved.",
                    ),
                    false,
                    cx,
                )
            });
            return;
        }
        let busy = self.saving
            || self.state_reloading
            || self.configuration_recovery.is_some()
            || self.vault_settings.is_some()
            || self.profile_sync.is_some()
            || self.snippet_modal_open();
        let active = event.deleting
            && self
                .panels
                .values()
                .chain(self.archived_panels.values())
                .filter_map(|panels| panels.tunnels.as_ref())
                .chain(self.tunnel_owners.values())
                .any(|panel| panel.read(cx).has_active_rule(event.rule.id));
        if busy || active {
            panel.update(cx, |panel, cx| {
                panel.mark_rule_mutation_failed(event.operation,
                    if active { Message::new("此规则在其他标签或当前标签仍有活动隧道，请先停止。", "This rule still has active tunnels in this or another tab. Stop them first.") }
                    else { Message::new("配置正在保存、重新加载或管理中，请完成后重试。", "Configuration is being saved, reloaded or managed. Finish that operation before retrying.") }, false, cx)
            });
            return;
        }
        let candidate = match event.candidate(&self.state) {
            Ok(candidate) => candidate,
            Err(error) => {
                panel.update(cx, |panel, cx| {
                    panel.mark_rule_mutation_failed(
                        event.operation,
                        Message::detail(
                            "规则审核已过期或内容无效，未保存",
                            "Rule review expired or is invalid; not saved",
                            error,
                        ),
                        false,
                        cx,
                    )
                });
                return;
            }
        };
        self.persist(
            candidate,
            AfterSave::TunnelRule {
                panel: panel.downgrade(),
                operation: event.operation,
            },
            window,
            cx,
        );
    }

    fn handle_tunnel_runtime_event(
        &mut self,
        panel: &Entity<crate::tunnels::TunnelsPanel>,
        event: &crate::tunnels::TunnelRuntimeEvent,
        window: &mut Window,
        cx: &mut Context<Self>,
    ) {
        let bound = self
            .panels
            .values()
            .chain(self.archived_panels.values())
            .filter_map(|panels| panels.tunnels.as_ref())
            .any(|candidate| candidate == panel)
            || self
                .tunnel_owners
                .values()
                .any(|candidate| candidate == panel);
        if !bound {
            panel.update(cx, |panel, cx| {
                panel.mark_runtime_event_failed(
                    event.operation(),
                    Message::new(
                        "隧道面板已过期，未保存运行状态。",
                        "The tunnel panel is stale; runtime state was not saved.",
                    ),
                    false,
                    cx,
                )
            });
            return;
        }
        let busy = self.saving
            || self.state_reloading
            || self.configuration_recovery.is_some()
            || self.vault_settings.is_some()
            || self.profile_sync.is_some()
            || self.snippet_modal_open();
        if busy {
            panel.update(cx, |panel, cx| {
                panel.mark_runtime_event_deferred(event.operation(), cx);
            });
            return;
        }
        if self.tunnel_rule_store_blocked || !panel.read(cx).accepts_runtime_event(event) {
            panel.update(cx, |panel, cx| {
                panel.mark_runtime_event_failed(
                    event.operation(),
                    Message::new(
                        "配置保存结果未知或面板审核已过期，运行候选已保留；请重新加载配置。",
                        "The configuration result is unknown or the panel review is stale. The runtime candidate was retained; reload configuration.",
                    ),
                    true,
                    cx,
                )
            });
            return;
        }
        let candidate = match event.candidate(&self.state) {
            Ok(candidate) => candidate,
            Err(error) => {
                self.mark_tunnel_rule_store_uncertain(cx);
                panel.update(cx, |panel, cx| {
                    panel.mark_runtime_event_failed(
                        event.operation(),
                        Message::detail(
                            "命名隧道运行状态审核已过期，候选已保留",
                            "Named tunnel runtime state review expired; candidate retained",
                            error,
                        ),
                        true,
                        cx,
                    )
                });
                return;
            }
        };
        self.persist(
            candidate,
            AfterSave::TunnelRuntime {
                panel: panel.downgrade(),
                operation: event.operation(),
                snapshot_id: event.snapshot_id(),
                removing: event.removing(),
            },
            window,
            cx,
        );
    }

    fn toggle_panel(&mut self, kind: ToolPanel, window: &mut Window, cx: &mut Context<Self>) {
        if self.remote_completion.visible() {
            self.cancel_remote_completion(cx);
            if self.visible_panel == Some(kind) {
                cx.notify();
                return;
            }
        }
        if kind == ToolPanel::Commands {
            self.visible_panel = if self.visible_panel == Some(kind) {
                None
            } else {
                Some(kind)
            };
            cx.notify();
            return;
        }
        let Some(terminal) = self.tabs.get(self.active) else {
            return;
        };
        let id = terminal.entity_id();
        if self.show_archived.contains(&id) || terminal.read(cx).end_reason().is_some() {
            self.visible_panel = if self.visible_panel == Some(kind) {
                None
            } else {
                Some(kind)
            };
            cx.notify();
            return;
        }
        let Some(session) = self.remote_sessions.get(&id).cloned() else {
            self.status = Message::new(
                "请先建立 SSH 连接",
                "Remote tools are available in a connected SSH tab",
            );
            cx.notify();
            return;
        };
        let host = self.remote_hosts.get(&id).cloned().unwrap_or_default();
        let runtime = self.runtime.clone();
        let rule_state = self.state.clone();
        let rule_connection_id = self.remote_connection_ids.get(&id).copied();
        match kind {
            ToolPanel::Files
                if self
                    .panels
                    .get(&id)
                    .and_then(|panels| panels.files.as_ref())
                    .is_none() =>
            {
                self.panels.entry(id).or_default().files = Some(cx.new(|cx| {
                    crate::files::FilesPanel::new_with_recovery_store_and_connection(
                        session,
                        host,
                        rule_connection_id,
                        runtime,
                        Arc::new(keelshell_core::TransferRecoveryStore::from_state_path(
                            self.store.path(),
                        )),
                        window,
                        cx,
                    )
                }));
            }
            ToolPanel::Tunnels
                if self
                    .panels
                    .get(&id)
                    .and_then(|panels| panels.tunnels.as_ref())
                    .is_none() =>
            {
                let panel = cx.new(|cx| {
                    crate::tunnels::TunnelsPanel::new_with_state(
                        session,
                        host,
                        runtime,
                        Some(rule_state),
                        rule_connection_id,
                        window,
                        cx,
                    )
                });
                let subscription = cx.subscribe_in(
                    &panel,
                    window,
                    |view, panel, event: &crate::tunnels::TunnelRuleEvent, window, cx| {
                        view.handle_tunnel_rule_event(panel, event, window, cx)
                    },
                );
                let runtime_subscription = cx.subscribe_in(
                    &panel,
                    window,
                    |view, panel, event: &crate::tunnels::TunnelRuntimeEvent, window, cx| {
                        view.handle_tunnel_runtime_event(panel, event, window, cx)
                    },
                );
                panel.update(cx, |panel, cx| {
                    panel.set_rule_configuration_busy(self.saving || self.state_reloading, cx);
                    if self.tunnel_rule_store_blocked {
                        panel.mark_rule_store_uncertain(cx);
                    }
                });
                self.tunnel_owners.insert(panel.entity_id(), panel.clone());
                self.tunnel_subscriptions.insert(id, subscription);
                self.tunnel_runtime_subscriptions
                    .insert(id, runtime_subscription);
                self.panels.entry(id).or_default().tunnels = Some(panel);
            }
            ToolPanel::Tunnels => {
                if let Some(panel) = self
                    .panels
                    .get(&id)
                    .and_then(|panels| panels.tunnels.clone())
                {
                    panel.update(cx, |panel, cx| {
                        panel.refresh_rule_state(Some(rule_state), rule_connection_id, cx)
                    });
                }
            }
            _ => {}
        }
        self.visible_panel = if self.visible_panel == Some(kind) {
            None
        } else {
            Some(kind)
        };
        cx.notify();
    }
    #[cfg(test)]
    fn edit_connection(
        &mut self,
        connection: Connection,
        window: &mut Window,
        cx: &mut Context<Self>,
    ) {
        self.edit_connection_by_id(connection.id, window, cx);
    }

    fn edit_connection_by_id(
        &mut self,
        id: uuid::Uuid,
        window: &mut Window,
        cx: &mut Context<Self>,
    ) {
        if self.library_batch_prompt.is_some() {
            self.focus_current_surface(window, cx);
            return;
        }
        if self.saving {
            return;
        }
        let Some(connection) = self
            .state
            .connections
            .iter()
            .find(|profile| profile.id == id)
            .cloned()
        else {
            self.status = Message::new(
                "连接已移除，请重新选择。",
                "Connection removed. Select another saved connection.",
            );
            cx.notify();
            return;
        };
        self.cancel_reconnect_for_profile(id, window, cx);
        if self.editing_active_route(id) {
            self.cancel_connect_route(window, cx);
        }
        let key = match &connection.auth {
            AuthMethod::PrivateKey { path } => path.to_string_lossy().into_owned(),
            _ => String::new(),
        };
        self.form = Some(ConnectionForm {
            id: Some(connection.id),
            proxy_editor: cx.new(|cx| ProxyEditor::new(connection.proxy.as_ref(), window, cx)),
            reconnect_editor: cx.new(|cx| ReconnectEditor::new(connection.reconnect, window, cx)),
            jump_picker: cx.new(|cx| {
                JumpHostPicker::new(
                    &self.state,
                    Some(connection.id),
                    connection.jump_host,
                    window,
                    cx,
                )
            }),
            password: matches!(connection.auth, AuthMethod::Password),
            name: input(t(cx, "名称", "Name"), &connection.name, window, cx),
            host: input(t(cx, "主机", "Host"), &connection.host, window, cx),
            port: input(
                t(cx, "端口", "Port"),
                &connection.port.to_string(),
                window,
                cx,
            ),
            username: input(
                t(cx, "用户名", "Username"),
                &connection.username,
                window,
                cx,
            ),
            folder_id: self.state.folder_id_of(connection.id),
            tags: input(
                t(cx, "标签，用逗号分隔", "Tags, separated by commas"),
                &connection.tags.join(", "),
                window,
                cx,
            ),
            key: input(t(cx, "私钥路径", "Private key path"), &key, window, cx),
        });
        if let Some(form) = &self.form {
            form.name.read(cx).focus_handle(cx).focus(window, cx);
        }
        cx.notify();
    }
}

pub fn bind_keys(cx: &mut App) {
    let (open, close, assistant) = if cfg!(target_os = "macos") {
        ("cmd-t", "cmd-w", "cmd-j")
    } else {
        ("ctrl-shift-t", "ctrl-shift-w", "ctrl-shift-j")
    };
    let (previous_session, next_session) = if cfg!(target_os = "macos") {
        ("cmd-alt-left", "cmd-alt-right")
    } else {
        ("ctrl-alt-left", "ctrl-alt-right")
    };
    cx.bind_keys([
        KeyBinding::new("ctrl-space", CompleteRemoteCommand, Some("Input")),
        KeyBinding::new(
            if cfg!(target_os = "macos") {
                "cmd-k"
            } else {
                "ctrl-k"
            },
            OpenCommandPalette,
            None,
        ),
        KeyBinding::new(open, OpenConnections, None),
        KeyBinding::new(close, CloseTab, None),
        KeyBinding::new(assistant, ToggleAssistant, None),
        KeyBinding::new(previous_session, PreviousSession, None),
        KeyBinding::new(next_session, NextSession, None),
        KeyBinding::new(
            if cfg!(target_os = "macos") {
                "cmd-shift-n"
            } else {
                "ctrl-shift-n"
            },
            NewWorkspaceWindow,
            None,
        ),
        KeyBinding::new(
            if cfg!(target_os = "macos") {
                "cmd-shift-w"
            } else {
                "ctrl-alt-w"
            },
            CloseWorkspaceWindow,
            None,
        ),
    ]);
}
