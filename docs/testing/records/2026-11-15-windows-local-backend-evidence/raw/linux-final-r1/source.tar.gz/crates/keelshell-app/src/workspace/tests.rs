//! Render the real SSH-only workspace and exercise language/save transitions.

use std::{
    path::PathBuf,
    sync::{
        Arc,
        atomic::AtomicBool,
        mpsc::{self, Receiver, SyncSender},
    },
    time::Duration,
};

use gpui_kit::component::input::InputState;
use gpui_kit::{
    AnyWindowHandle, AppContext, Bounds, ClipboardItem, Entity, Focusable, InputEvent, ScrollDelta,
    TestAppContext, WindowBounds, WindowOptions, point, px, size,
    test::{TestAppContextExt, TestWindowExt},
};
use keelshell_core::{
    AiApiStyle, AiAuthentication, AiPreset, AiProfileCatalog, AppState, Connection,
    KnowledgeOutcome, Language, StateStore, Theme,
};
use keelshell_session::SessionEvent;

use super::{KeyboardInteractiveField, KeyboardInteractivePrompt, Workspace};
use crate::i18n;
use crate::terminal::{TerminalCommand, TerminalView};

mod ai_command_review_target;
mod ai_metadata;
mod ai_snippet_save;
mod command_palette;
mod configuration_recovery;
mod connection_indicators;
pub(crate) mod independent_disk_monitor;
mod knowledge_library;
pub(crate) mod mirror_sync_combination;
mod navigation;
mod pane_layout;
mod profile_sync;
pub(crate) mod protocol_diagnostics;
mod reviewed_agent;
mod session_tabs;
mod startup_restore;
pub(super) mod windows;
mod workbench_layout;

trait Checked<T> {
    fn checked(self, operation: &str) -> T;
}

impl<T, E: std::fmt::Debug> Checked<T> for Result<T, E> {
    #[track_caller]
    fn checked(self, operation: &str) -> T {
        match self {
            Ok(value) => value,
            Err(error) => panic!("{operation}: {error:?}"),
        }
    }
}

struct TemporaryState(PathBuf);

impl Drop for TemporaryState {
    fn drop(&mut self) {
        let _ = std::fs::remove_dir_all(&self.0);
    }
}

struct Fixture {
    window: AnyWindowHandle,
    workspace: Entity<Workspace>,
    store: Arc<StateStore>,
    _state_directory: TemporaryState,
}

fn mount(cx: &mut TestAppContext, profiles: Vec<Connection>) -> Fixture {
    mount_sized(cx, profiles, 1280., 840.)
}

fn mount_sized(
    cx: &mut TestAppContext,
    profiles: Vec<Connection>,
    width: f32,
    height: f32,
) -> Fixture {
    mount_state_sized(
        cx,
        AppState {
            connections: profiles,
            ..AppState::default()
        },
        width,
        height,
    )
}

fn mount_state_sized(cx: &mut TestAppContext, state: AppState, width: f32, height: f32) -> Fixture {
    let directory = std::env::temp_dir().join(format!("keelshell-ui-{}", uuid::Uuid::new_v4()));
    std::fs::create_dir(&directory).checked("create isolated state directory");
    let guard = TemporaryState(directory.clone());
    let store = Arc::new(StateStore::new(directory.join("state.json")));
    store.save(&state).checked("persist fixture state");
    let state = store.load().checked("load persisted fixture state");
    let runtime = Arc::new(
        tokio::runtime::Builder::new_multi_thread()
            .worker_threads(1)
            .enable_all()
            .build()
            .checked("create fixture runtime"),
    );
    cx.update(|cx| {
        gpui_kit::init(cx);
        crate::workspace::bind_keys(cx);
        i18n::set_language(state.settings.language, cx);
    });
    let workspace_store = store.clone();
    let (window, workspace) = cx.update(|cx| {
        gpui_kit::open_window(
            WindowOptions {
                window_bounds: Some(WindowBounds::Windowed(Bounds::new(
                    point(px(0.), px(0.)),
                    size(px(width), px(height)),
                ))),
                ..Default::default()
            },
            cx,
            |window, cx| {
                cx.new(|cx| Workspace::new(workspace_store, state, None, runtime, window, cx))
            },
        )
        .checked("mount production workspace")
    });
    cx.update_window(window, |_, window, _| window.activate_window())
        .checked("activate test window for native focus events");
    Fixture {
        window,
        workspace,
        store,
        _state_directory: guard,
    }
}

/// Adopt a deliberately persisted fixture snapshot into the shared configuration
/// authority before exercising a production action.
///
/// Test setup sometimes writes through a separate `StateStore` call after the
/// real workspace has been mounted. Updating only `Workspace::state` would
/// leave its revision and epoch behind the process-wide gate, so every guarded
/// action would be rejected as stale. This helper models the completed reload
/// boundary used by the production event handlers while keeping live panes and
/// drafts owned by the test workspace.
fn adopt_fixture_state(fixture: &Fixture, state: AppState, cx: &mut TestAppContext) {
    cx.update_window(fixture.window, |_, _, cx| {
        fixture.workspace.update(cx, |view, cx| {
            view.state = state.clone();
            let gate = view.app_windows.read(cx).gate.clone();
            let reload =
                crate::app_windows::ConfigurationGate::begin_reload_lease(&gate, view.window_id)
                    .checked("begin fixture configuration adoption");
            reload.finish(Some(&state));
            view.configuration_epoch = gate
                .lock()
                .checked("lock fixture configuration gate")
                .epoch();
            view.configuration_invalidated = false;
            cx.notify();
        });
    })
    .checked("adopt persisted fixture configuration");
}

fn save_and_adopt_fixture_state(
    fixture: &Fixture,
    state: AppState,
    operation: &str,
    cx: &mut TestAppContext,
) -> AppState {
    let saved = fixture.store.save(&state).checked(operation);
    adopt_fixture_state(fixture, saved.clone(), cx);
    saved
}

/// Mount an already sampled monitor beside production workspace/terminal controls.
/// This asserts GPUI layout and local interactions, not desktop native acceptance.
pub(crate) fn verify_disk_monitor_minimum_workspace(
    monitor: Entity<crate::monitor::MonitorPanel>,
    cx: &mut TestAppContext,
) {
    let fixture = mount_sized(cx, Vec::new(), 900., 580.);
    let panes = attach_remote_panes(&fixture, cx);
    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |workspace, cx| {
            workspace.show_connections = false;
            workspace.panels.insert(
                panes[0].terminal.entity_id(),
                super::RemotePanels {
                    monitor: Some(monitor),
                    ..Default::default()
                },
            );
            cx.notify();
        });
        window.render_frame(cx);
        window.click("navigation-monitor", cx);
        for language in [Language::ZhCn, Language::En] {
            for theme in [
                keelshell_core::Theme::System,
                keelshell_core::Theme::Light,
                keelshell_core::Theme::Dark,
            ] {
                i18n::set_language(language, cx);
                crate::design::apply(theme, Some(window), cx);
                window.render_frame(cx);
                let terminal = window
                    .find(("terminal-pane", panes[0].terminal.entity_id()))
                    .bounds();
                assert!(terminal.size.width >= px(200.) && terminal.size.height >= px(80.));
                for id in [
                    "new-session",
                    "split-session",
                    "toggle-assistant",
                    "theme-settings",
                    "language",
                    "refresh-monitor",
                    "pause-monitor",
                ] {
                    let button = window.find(id);
                    let bounds = button.bounds();
                    assert!(button.visible(), "{language:?}/{theme:?}/{id}");
                    assert!(
                        bounds.right() <= window.bounds().right()
                            && bounds.bottom() <= window.bounds().bottom()
                    );
                }
                for _ in 0..40 {
                    let choices = window.find("monitor-disk-devices").bounds();
                    let viewport = window.find("monitor-scroll").bounds();
                    if choices.origin.y >= viewport.origin.y
                        && choices.bottom() <= viewport.bottom()
                    {
                        break;
                    }
                    let direction = if choices.origin.y < viewport.origin.y {
                        1.
                    } else {
                        -1.
                    };
                    // The column padding is outside the nested chooser. Dispatch
                    // an actual wheel there rather than scrolling the inner list.
                    window.dispatch_event(
                        gpui_kit::ScrollEvent {
                            position: point(viewport.origin.x + px(2.), viewport.center().y),
                            delta: gpui_kit::ScrollDelta::Lines(point(0., direction)),
                            ..Default::default()
                        }
                        .to_platform_input(),
                        cx,
                    );
                    window.render_frame(cx);
                }
                for _ in 0..30 {
                    let row = window.find(("monitor-disk-device", 11_usize));
                    let choices = window.find("monitor-disk-devices").bounds();
                    if row.visible()
                        && row.bounds().origin.y >= choices.origin.y
                        && row.bounds().bottom() <= choices.bottom()
                    {
                        break;
                    }
                    window.scroll(
                        "monitor-disk-devices",
                        gpui_kit::ScrollDelta::Lines(point(0., -1.)),
                        cx,
                    );
                    window.render_frame(cx);
                }
                let row_bounds = window.find(("monitor-disk-device", 11_usize)).bounds();
                let choices_bounds = window.find("monitor-disk-devices").bounds();
                assert!(
                    row_bounds.origin.y >= choices_bounds.origin.y
                        && row_bounds.bottom() <= choices_bounds.bottom(),
                    "{language:?}/{theme:?}: last disk row is clipped: row={row_bounds:?}, chooser={choices_bounds:?}, outer={:?}",
                    window.find("monitor-scroll").bounds()
                );
                assert_eq!(
                    window.find(("monitor-disk-device", 11_usize)).label(),
                    Some("fixture11 · 8:11")
                );
                window.click(("monitor-disk-device", 11_usize), cx);
                window.render_frame(cx);
                let metrics = window.find("monitor-disk-metrics").bounds();
                let column = window.find("monitor-column").bounds();
                assert!(metrics.origin.x >= column.origin.x && metrics.right() <= column.right());
                assert!(
                    window.find("monitor-operation-status").bounds().bottom()
                        <= window.bounds().bottom()
                );
            }
        }
    })
    .checked("six minimum workspace disk layouts and actual nested device scroll/click");
    assert!(panes.iter().all(|pane| writes(pane).is_empty()));
}

#[gpui_kit::test]
async fn update_panel_close_has_a_localized_name_and_closes_the_real_panel(
    cx: &mut TestAppContext,
) {
    let fixture = mount(cx, Vec::new());
    for (language, label) in [
        (Language::ZhCn, "关闭关于与更新"),
        (Language::En, "Close about and updates"),
    ] {
        cx.update_window(fixture.window, |_, window, cx| {
            i18n::set_language(language, cx);
            window.render_frame(cx);
            window.click("about-updates", cx);
            window.render_frame(cx);
            assert!(fixture.workspace.read(cx).update_panel.is_some());
            assert_eq!(window.find("close-update-panel").label(), Some(label));
            window.click("close-update-panel", cx);
        })
        .checked("close the actual update panel without checking or installing an update");
        cx.wait_for(fixture.window, Duration::from_secs(5), |_, cx| {
            fixture.workspace.read(cx).update_panel.is_none()
        })
        .await;
        cx.update_window(fixture.window, |_, window, cx| {
            window.render_frame(cx);
            assert!(window.try_find("close-update-panel").is_none());
        })
        .checked("closed panel no longer exposes its control");
    }
    cx.update(|cx| i18n::set_language(Language::ZhCn, cx));
}

#[gpui_kit::test]
fn first_launch_is_chinese_without_a_local_or_remote_terminal(cx: &mut TestAppContext) {
    let fixture = mount(cx, Vec::new());
    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        let workspace = fixture.workspace.read(cx);
        assert_eq!(workspace.state.settings.language, Language::ZhCn);
        assert_eq!(i18n::language(cx), Language::ZhCn);
        assert!(workspace.tabs.is_empty());
        assert!(workspace.remote_sessions.is_empty());
        assert!(workspace.panels.is_empty());
        assert_eq!(window.find("new-connection").label(), Some("新建连接"));
        assert_eq!(
            window.find("language").label(),
            Some("切换语言：中文或英文")
        );
        assert_eq!(window.find("new-session").label(), Some("新建 SSH 会话"));
        assert_eq!(window.find("quick-host").label(), Some("主机或 IP 地址"));
        assert_eq!(window.find("quick-port").label(), Some("端口"));
        assert_eq!(window.find("quick-username").label(), Some("SSH 用户名"));
        assert_eq!(window.find("quick-key").label(), Some("私钥路径（可选）"));
        assert!(window.try_find(("session-tab", 0_usize)).is_none());
        assert!(window.try_find("run-command").is_none());
        i18n::set_language(Language::En, cx);
        window.render_frame(cx);
        assert_eq!(window.find("new-session").label(), Some("New SSH session"));
        assert_eq!(
            window.find("quick-host").label(),
            Some("Host or IP address")
        );
        assert_eq!(window.find("quick-port").label(), Some("Port"));
        assert_eq!(window.find("quick-username").label(), Some("SSH username"));
        assert_eq!(
            window.find("quick-key").label(),
            Some("Private key path (optional)")
        );
        i18n::set_language(Language::ZhCn, cx);
    })
    .checked("draw empty Chinese workspace");
}

#[gpui_kit::test]
fn empty_split_and_new_session_never_create_a_fallback_shell(cx: &mut TestAppContext) {
    let fixture = mount(cx, Vec::new());
    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        window.click("split-session", cx);
        // Also exercise the command defensively, bypassing disabled UI state.
        fixture.workspace.update(cx, |workspace, cx| {
            workspace.split_remote(keelshell_core::SplitAxis::Horizontal, window, cx);
            workspace.split_remote(keelshell_core::SplitAxis::Horizontal, window, cx);
        });
        window.render_frame(cx);
        window.click("new-session", cx);
        let workspace = fixture.workspace.read(cx);
        assert!(workspace.show_connections);
        assert!(workspace.tabs.is_empty());
        assert!(workspace.remote_sessions.is_empty());
        assert!(workspace.remote_hosts.is_empty());
        assert!(workspace.panels.is_empty());
        assert_eq!(
            workspace
                .session_panes
                .layout()
                .leaf_ids()
                .checked("empty layout"),
            vec![workspace.session_panes.active_pane()]
        );
        assert_eq!(workspace.session_panes.active_session(), None);
    })
    .checked("empty split and connection-manager actions");
    cx.run_until_parked();
    fixture
        .workspace
        .read_with(cx, |workspace, _| assert!(workspace.tabs.is_empty()));
}

#[gpui_kit::test]
fn quick_connect_uses_the_ephemeral_route_and_does_not_save_a_profile(cx: &mut TestAppContext) {
    let fixture = mount(cx, Vec::new());
    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |workspace, cx| {
            workspace.quick_connect.host.update(cx, |input, cx| {
                input.set_value("quick.example.test", window, cx)
            });
            workspace
                .quick_connect
                .port
                .update(cx, |input, cx| input.set_value("2208", window, cx));
            workspace
                .quick_connect
                .username
                .update(cx, |input, cx| input.set_value("operator", window, cx));
            workspace.quick_password = true;
        });
        window.render_frame(cx);
        window.click("quick-connect", cx);
        window.render_frame(cx);
        assert!(
            window.try_find("save-credential-mode").is_none(),
            "one-time authentication must not expose vault save"
        );
        assert!(window.try_find("keyboard-interactive-mode").is_some());
        window.click("keyboard-interactive-mode", cx);
        assert!(
            fixture
                .workspace
                .read(cx)
                .connect_route
                .as_ref()
                .is_some_and(|route| route.keyboard_interactive)
        );
    })
    .checked("start one-time SSH connection from the empty workspace");
    fixture.workspace.read_with(cx, |workspace, _| {
        assert!(workspace.connect_route.is_some());
        let login = workspace
            .login
            .as_ref()
            .checked_option("password mode reuses SSH login UI");
        assert!(workspace.login_is_current(&login.connection));
        assert!(matches!(login.mode, super::vault::LoginMode::Once));
        assert!(workspace.state.connections.is_empty());
        assert!(!workspace.saving);
    });
    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |workspace, cx| {
            let login = workspace
                .login
                .as_ref()
                .checked_option("quick login remains open");
            login.secret.update(cx, |input, cx| {
                input.set_value("one-time-secret", window, cx)
            });
            workspace.submit_login(window, cx);
            assert!(workspace.connect_route.is_some());
            assert!(workspace.connecting);
        });
    })
    .checked("submit one-time password without rejecting the ephemeral route");
    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |workspace, cx| {
            workspace.cancel_connect_route(window, cx);
        });
    })
    .checked("cancel one-time SSH connection");
    assert!(
        fixture
            .store
            .load()
            .checked("reload quick state")
            .connections
            .is_empty()
    );
}

#[gpui_kit::test]
fn quick_connect_remains_visible_with_saved_profiles(cx: &mut TestAppContext) {
    let profile = Connection::new("Saved SSH", "saved.example.test", "operator");
    let fixture = mount(cx, vec![profile]);
    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        assert!(window.try_find("quick-connect-surface").is_some());
        assert_eq!(window.find("new-connection").label(), Some("新建连接"));
    })
    .checked("keep one-time entry point beside the saved library");
}

#[gpui_kit::test]
fn quick_connect_save_action_only_opens_the_persistent_editor(cx: &mut TestAppContext) {
    let fixture = mount(cx, Vec::new());
    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |workspace, cx| {
            workspace.quick_connect.host.update(cx, |input, cx| {
                input.set_value("save.example.test", window, cx)
            });
            workspace
                .quick_connect
                .username
                .update(cx, |input, cx| input.set_value("operator", window, cx));
        });
        window.render_frame(cx);
        window.click("save-quick-profile", cx);
    })
    .checked("open the persistent connection editor explicitly");
    fixture.workspace.read_with(cx, |workspace, cx| {
        let form = match workspace.form.as_ref() {
            Some(form) => form,
            None => panic!("save action opens editor"),
        };
        assert_eq!(form.host.read(cx).value(), "save.example.test");
        assert_eq!(form.username.read(cx).value(), "operator");
        assert!(workspace.state.connections.is_empty());
    });
    assert!(
        fixture
            .store
            .load()
            .checked("reload unsaved quick state")
            .connections
            .is_empty()
    );
}

#[gpui_kit::test]
async fn language_switch_preserves_profiles_and_unsaved_drafts_after_persistence(
    cx: &mut TestAppContext,
) {
    let mut profile = Connection::new("生产 SSH", "example.invalid", "operator");
    profile.group = "研发/应用".into();
    let profiles = vec![profile];
    let fixture = mount(cx, profiles.clone());
    let signature = cx
        .update_window(fixture.window, |_, window, cx| {
            window.render_frame(cx);
            window.click("new-connection", cx);
            let name = fixture
                .workspace
                .read(cx)
                .form
                .as_ref()
                .map(|form| form.name.entity_id());
            let Some(name) = name else {
                panic!("New connection must open a draft");
            };
            window.click(("input", name), cx);
            window.input("未保存的连接", cx);
            fixture.workspace.update(cx, |workspace, cx| {
                workspace.command.update(cx, |input, cx| {
                    input.set_value("printf '%s' '$UNSENT'", window, cx)
                });
                workspace
                    .search
                    .update(cx, |input, cx| input.set_value("生产", window, cx));
                workspace.switch_language(window, cx);
                assert!(workspace.saving);
                // A draft edit arriving after save starts must survive its completion.
                let Some(form) = &workspace.form else {
                    panic!("language change removed draft");
                };
                form.name.update(cx, |input, cx| {
                    input.set_value("保存期间继续编辑", window, cx)
                });
                form.host
                    .update(cx, |input, cx| input.set_value("draft.invalid", window, cx));
                form.signature(cx)
            })
        })
        .checked("edit draft and switch language through the production callback");
    cx.wait_for(fixture.window, Duration::from_secs(3), |_, cx| {
        !fixture.workspace.read(cx).saving
    })
    .await;
    fixture.workspace.read_with(cx, |workspace, cx| {
        assert_eq!(workspace.state.settings.language, Language::En);
        assert_eq!(i18n::language(cx), Language::En);
        assert_eq!(workspace.state.connections, profiles);
        assert_eq!(
            workspace.form.as_ref().map(|form| form.signature(cx)),
            Some(signature.clone())
        );
        assert_eq!(workspace.command.read(cx).value(), "printf '%s' '$UNSENT'");
        assert_eq!(workspace.search.read(cx).value(), "生产");
        assert!(workspace.tabs.is_empty());
    });
    let persisted = fixture
        .store
        .load()
        .checked("verify language persisted on disk");
    assert_eq!(persisted.settings.language, Language::En);
    assert_eq!(persisted.connections, profiles);
    cx.update_window(fixture.window, |_, window, cx| {
        fixture
            .workspace
            .update(cx, |workspace, cx| workspace.switch_language(window, cx));
    })
    .checked("switch the same live workspace back to Chinese");
    cx.wait_for(fixture.window, Duration::from_secs(3), |_, cx| {
        !fixture.workspace.read(cx).saving
    })
    .await;
    fixture.workspace.read_with(cx, |workspace, cx| {
        assert_eq!(workspace.state.settings.language, Language::ZhCn);
        assert_eq!(workspace.state.connections, profiles);
        assert_eq!(
            workspace.form.as_ref().map(|form| form.signature(cx)),
            Some(signature)
        );
        assert_eq!(workspace.command.read(cx).value(), "printf '%s' '$UNSENT'");
    });
    assert_eq!(
        fixture
            .store
            .load()
            .checked("verify Chinese persisted")
            .settings
            .language,
        Language::ZhCn
    );
}

#[gpui_kit::test]
fn pane_tabs_preserve_other_leaf_selection_across_switching_and_closure(cx: &mut TestAppContext) {
    let fixture = mount(cx, Vec::new());
    let panes: Vec<_> = (0..2)
        .flat_map(|_| attach_remote_panes(&fixture, cx))
        .collect();
    let primary = panes[0].terminal.entity_id();
    let unrelated = panes[1].terminal.entity_id();
    let peer = panes[2].terminal.entity_id();
    cx.update_window(fixture.window, |_, window, cx| {
        let (original, adjacent) = fixture.workspace.update(cx, |workspace, cx| {
            workspace.tabs = panes[..3]
                .iter()
                .map(|pane| pane.terminal.clone())
                .collect();
            workspace.active = 0;
            assert!(workspace.sync_session_panes());
            let original = workspace.session_panes.active_pane();
            let adjacent = workspace
                .session_panes
                .split(primary, peer, keelshell_core::SplitAxis::Horizontal)
                .checked("split registered peer into a second leaf");
            cx.notify();
            (original, adjacent)
        });
        window.render_frame(cx);
        window.simulate_next_frame(cx);
        window.render_frame(cx);
        assert_eq!(
            fixture.workspace.read(cx).session_panes.tabs_in(original),
            &[primary, unrelated]
        );
        window.click(("pane-tab", unrelated), cx);
        let workspace = fixture.workspace.read(cx);
        assert_eq!(workspace.tabs[workspace.active].entity_id(), unrelated);
        assert_eq!(
            workspace.session_panes.selected_in(original),
            Some(unrelated)
        );
        assert_eq!(workspace.session_panes.selected_in(adjacent), Some(peer));
        assert_eq!(
            workspace.session_panes.displayed_sessions(),
            vec![unrelated, peer]
        );
        assert!(
            panes[1]
                .terminal
                .read(cx)
                .focus_handle(cx)
                .is_focused(window)
        );
        assert!(window.find(("terminal-pane", peer)).visible());

        window.click(("close-tab", 1_usize), cx);
        let workspace = fixture.workspace.read(cx);
        assert_eq!(workspace.session_panes.tabs_in(original), &[primary]);
        assert_eq!(workspace.session_panes.tabs_in(adjacent), &[peer]);
        assert_eq!(
            workspace.session_panes.displayed_sessions(),
            vec![primary, peer]
        );
        assert_eq!(workspace.session_panes.active_session(), Some(primary));
        assert!(
            panes[0]
                .terminal
                .read(cx)
                .focus_handle(cx)
                .is_focused(window)
        );

        window.click(("session-tab", 1_usize), cx);
        assert!(
            panes[2]
                .terminal
                .read(cx)
                .focus_handle(cx)
                .is_focused(window)
        );
        assert_eq!(
            fixture
                .workspace
                .read(cx)
                .session_panes
                .displayed_sessions(),
            vec![primary, peer]
        );
        window.click(("close-tab", 1_usize), cx);
        let workspace = fixture.workspace.read(cx);
        assert_eq!(
            workspace
                .tabs
                .iter()
                .map(Entity::entity_id)
                .collect::<Vec<_>>(),
            vec![primary]
        );
        assert_eq!(workspace.session_panes.layout().root, original);
        assert_eq!(workspace.session_panes.displayed_sessions(), vec![primary]);
        assert_eq!(workspace.session_panes.active_session(), Some(primary));
        assert!(
            panes[0]
                .terminal
                .read(cx)
                .focus_handle(cx)
                .is_focused(window)
        );
        assert!(workspace.session_panes.tabs_in(adjacent).is_empty());
    })
    .checked("switch local pane tabs and close sessions without replacing the other leaf");
    assert!(panes.iter().all(|pane| writes(pane).is_empty()));
}

struct RemotePane {
    terminal: Entity<TerminalView>,
    commands: Receiver<TerminalCommand>,
    // Keep the fixture transport connected while layout and focus are exercised.
    _output: SyncSender<SessionEvent>,
}

fn attach_remote_panes(fixture: &Fixture, cx: &mut TestAppContext) -> Vec<RemotePane> {
    cx.update_window(fixture.window, |_, window, cx| {
        let panes: Vec<_> = ["left-pane-output", "right-pane-output"]
            .into_iter()
            .map(|text| {
                let (output, incoming) = mpsc::sync_channel(64);
                let (outgoing, commands) = mpsc::sync_channel(64);
                let terminal = cx.new(|cx| {
                    let mut terminal = TerminalView::from_transport(
                        text.into(),
                        14.,
                        1000,
                        incoming,
                        outgoing,
                        Arc::new(AtomicBool::new(false)),
                        cx,
                    );
                    terminal.emulator.feed(text.as_bytes());
                    terminal
                });
                RemotePane {
                    terminal,
                    commands,
                    _output: output,
                }
            })
            .collect();
        fixture.workspace.update(cx, |workspace, cx| {
            workspace.tabs = panes.iter().map(|pane| pane.terminal.clone()).collect();
            workspace.active = 0;
            for (index, pane) in panes.iter().enumerate() {
                workspace.remote_hosts.insert(
                    pane.terminal.entity_id(),
                    format!("fixture-{index}@example.invalid:22"),
                );
                // Exercise production observers and focus callbacks, rather than
                // updating Workspace.active from inside the test click handler.
                workspace.watch_terminal(&pane.terminal, window, cx);
            }
            cx.notify();
        });
        let focus = panes[0].terminal.read(cx).focus_handle(cx);
        focus.focus(window, cx);
        window.render_frame(cx);
        panes
    })
    .checked("attach deterministic remote transports and production focus listeners")
}

fn writes(pane: &RemotePane) -> Vec<u8> {
    pane.commands
        .try_iter()
        .filter_map(|command| match command {
            TerminalCommand::Write(bytes) => Some(bytes),
            TerminalCommand::Resize(_, _)
            | TerminalCommand::Zmodem(_)
            | TerminalCommand::ResumeInput(_) => None,
        })
        .flatten()
        .collect()
}

#[gpui_kit::test]
fn split_peer_pointer_focus_routes_capture_and_commands_without_reordering_panes(
    cx: &mut TestAppContext,
) {
    let fixture = mount(cx, Vec::new());
    let panes = attach_remote_panes(&fixture, cx);
    let left = panes[0].terminal.entity_id();
    let right = panes[1].terminal.entity_id();
    let original_bounds = cx
        .update_window(fixture.window, |_, window, cx| {
            fixture.workspace.update(cx, |workspace, cx| {
                assert!(workspace.sync_session_panes());
                workspace
                    .session_panes
                    .split(left, right, keelshell_core::SplitAxis::Horizontal)
                    .checked("split the actual registered terminal peer");
                workspace.show_assistant = true;
                cx.notify();
            });
            window.render_frame(cx);
            window.simulate_next_frame(cx);
            window.render_frame(cx);
            let bounds = [
                window.find(("terminal-pane", left)).bounds(),
                window.find(("terminal-pane", right)).bounds(),
            ];
            assert!(bounds[0].origin.x < bounds[1].origin.x);
            // A real pointer event reaches TerminalView's mouse/focus handler.
            window.click(("terminal-pane", right), cx);
            assert!(
                panes[1]
                    .terminal
                    .read(cx)
                    .focus_handle(cx)
                    .is_focused(window),
                "right terminal did not receive pointer focus; bounds={bounds:?}"
            );
            bounds
        })
        .checked("click the actual right-hand terminal pane");
    cx.run_until_parked();
    assert!(panes.iter().all(|pane| writes(pane).is_empty()));
    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        let workspace = fixture.workspace.read(cx);
        assert_eq!(workspace.tabs[workspace.active].entity_id(), right);
        assert_eq!(
            workspace
                .tabs
                .iter()
                .map(Entity::entity_id)
                .collect::<Vec<_>>(),
            vec![left, right]
        );
        for id in [left, right] {
            let pane = workspace
                .session_panes
                .pane_for(id)
                .ok_or("registered pane owner")
                .checked("look up stable pane ownership");
            assert_eq!(workspace.session_panes.tabs_in(pane), &[id]);
            assert_eq!(workspace.session_panes.selected_in(pane), Some(id));
        }
        assert_eq!(
            workspace
                .displayed_terminals()
                .iter()
                .map(Entity::entity_id)
                .collect::<Vec<_>>(),
            vec![left, right]
        );
        assert_eq!(
            window.find(("terminal-pane", left)).bounds(),
            original_bounds[0]
        );
        assert_eq!(
            window.find(("terminal-pane", right)).bounds(),
            original_bounds[1]
        );
        window.click("context-screen", cx);
    })
    .checked("verify stable left/right geometry and explicitly capture focused context");
    cx.run_until_parked();
    fixture.workspace.read_with(cx, |workspace, cx| {
        let (context, host, session_id) = workspace.assistant.read(cx).captured_context_for_test();
        assert!(context.contains("right-pane-output"));
        assert!(!context.contains("left-pane-output"));
        assert_eq!(host, "fixture-1@example.invalid:22");
        assert_eq!(session_id, format!("{right:?}"));
    });
    cx.update_window(fixture.window, |_, window, cx| {
        let input = fixture.workspace.read(cx).command.entity_id();
        window.click(("input", input), cx);
        window.input("printf focused-right", cx);
    })
    .checked("type a command after focusing the right pane");
    cx.run_until_parked();
    fixture.workspace.read_with(cx, |workspace, _| {
        assert_eq!(workspace.command_target, Some(right));
    });
    assert!(panes.iter().all(|pane| writes(pane).is_empty()));
    cx.update_window(fixture.window, |_, window, cx| {
        window.click("run-command", cx);
    })
    .checked("queue the reviewed command using its production button");
    cx.run_until_parked();
    assert!(writes(&panes[0]).is_empty());
    assert_eq!(writes(&panes[1]), b"printf focused-right\r");
    fixture.workspace.read_with(cx, |workspace, _| {
        assert_eq!(workspace.tabs[workspace.active].entity_id(), right);
        assert_eq!(
            workspace
                .displayed_terminals()
                .iter()
                .map(Entity::entity_id)
                .collect::<Vec<_>>(),
            vec![left, right]
        );
        assert_eq!(workspace.command_target, None);
        let Some(history) = workspace.command_histories.get(&right) else {
            panic!("the active SSH tab owns command history");
        };
        assert_eq!(
            history.newest_first().collect::<Vec<_>>(),
            ["printf focused-right"]
        );
    });
    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |workspace, cx| {
            workspace.visible_panel = Some(super::ToolPanel::Commands);
            cx.notify();
        });
        window.render_frame(cx);
        assert!(window.try_find("clear-command-history").is_some());
        window.click(("use-history", 0_usize), cx);
    })
    .checked("show and reinsert the active SSH session history");
    cx.run_until_parked();
    fixture.workspace.read_with(cx, |workspace, cx| {
        assert_eq!(workspace.command.read(cx).value(), "printf focused-right");
        assert_eq!(workspace.command_target, Some(right));
    });
    assert!(panes.iter().all(|pane| writes(pane).is_empty()));
}

#[gpui_kit::test]
async fn workspace_capture_review_and_save_round_trips_confirmed_knowledge(
    cx: &mut TestAppContext,
) {
    let fixture = mount(cx, Vec::new());
    let panes = attach_remote_panes(&fixture, cx);
    let active_id = panes[0].terminal.entity_id();
    let expected_session_id = format!("{active_id:?}");

    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |workspace, cx| {
            workspace.show_assistant = true;
            cx.notify();
        });
        window.render_frame(cx);
        window.click("context-screen", cx);
    })
    .checked("capture visible terminal context through the Workspace subscription");
    cx.run_until_parked();
    fixture.workspace.read_with(cx, |workspace, cx| {
        let (context, host, session_id) = workspace.assistant.read(cx).captured_context_for_test();
        assert!(context.contains("left-pane-output"));
        assert_eq!(host, "fixture-0@example.invalid:22");
        assert_eq!(session_id, expected_session_id);
    });

    cx.update_window(fixture.window, |_, window, cx| {
        window.click("knowledge-preview-action", cx);
        window.render_frame(cx);
        assert!(window.find("knowledge-save-disabled").visible());
        window.click("knowledge-confirm-completed", cx);
        window.render_frame(cx);
        // Outcome confirmation expands the source-bound preview. Reveal its
        // save action without bypassing the scroll container or visibility.
        window.scroll(
            "assistant-scroll",
            ScrollDelta::Lines(point(0., -1000.)),
            cx,
        );
        window.render_frame(cx);
        assert!(window.find("knowledge-save").visible());
    })
    .checked("review the captured knowledge before saving");
    fixture.workspace.read_with(cx, |workspace, cx| {
        assert!(workspace.assistant.read(cx).knowledge_save_ready_for_test());
    });

    cx.update_window(fixture.window, |_, window, cx| {
        window.scroll(
            "assistant-scroll",
            ScrollDelta::Lines(point(0., -1000.)),
            cx,
        );
        window.render_frame(cx);
        window.click("knowledge-save", cx);
        window.render_frame(cx);
    })
    .checked("emit the reviewed knowledge save event");
    cx.run_until_parked();

    cx.wait_for(fixture.window, Duration::from_secs(3), |_, cx| {
        !fixture.workspace.read(cx).saving
    })
    .await;

    let saved = fixture.store.load().checked("reload saved knowledge state");
    assert_eq!(saved.knowledge_entries.len(), 1);
    let entry = &saved.knowledge_entries[0];
    let expected_source_id = fixture.workspace.read_with(cx, |workspace, _| {
        workspace
            .knowledge_source_ids
            .get(&active_id)
            .copied()
            .unwrap_or_else(|| panic!("captured source identity"))
    });
    assert_eq!(entry.session_id(), expected_session_id);
    assert_eq!(entry.entry().source().id(), expected_source_id);
    assert_eq!(entry.entry().outcome(), KnowledgeOutcome::Completed);
    assert!(entry.entry().summary().contains("left-pane-output"));

    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        assert!(window.find("knowledge-save-saved").visible());
    })
    .checked("show the saved state after the background write completes");
}

#[gpui_kit::test]
async fn workspace_knowledge_conflict_invalidates_review_without_replay(cx: &mut TestAppContext) {
    let fixture = mount(cx, Vec::new());
    let panes = attach_remote_panes(&fixture, cx);

    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |workspace, cx| {
            workspace.show_assistant = true;
            cx.notify();
        });
        window.render_frame(cx);
        window.click("context-screen", cx);
    })
    .checked("capture terminal context for the conflict review");
    cx.run_until_parked();

    cx.update_window(fixture.window, |_, window, cx| {
        window.click("knowledge-preview-action", cx);
        window.render_frame(cx);
        window.click("knowledge-confirm-completed", cx);
        window.render_frame(cx);
        window.scroll(
            "assistant-scroll",
            ScrollDelta::Lines(point(0., -1000.)),
            cx,
        );
        window.render_frame(cx);
        assert!(window.find("knowledge-save").visible());
    })
    .checked("prepare a confirmed knowledge save before the competing write");

    let mut competing = fixture
        .store
        .load()
        .checked("load competing state snapshot");
    competing.settings.language = Language::En;
    fixture
        .store
        .save(&competing)
        .checked("persist competing state change");

    cx.update_window(fixture.window, |_, window, cx| {
        window.scroll(
            "assistant-scroll",
            ScrollDelta::Lines(point(0., -1000.)),
            cx,
        );
        window.render_frame(cx);
        window.click("knowledge-save", cx);
        window.render_frame(cx);
    })
    .checked("submit the stale knowledge save candidate");
    cx.wait_for(fixture.window, Duration::from_secs(3), |_, cx| {
        !fixture.workspace.read(cx).saving
    })
    .await;

    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        assert!(window.find("knowledge-save-conflict").visible());
        assert!(window.try_find("knowledge-save").is_none());
    })
    .checked("show a non-retryable conflict state after the stale write");
    fixture.workspace.read_with(cx, |workspace, cx| {
        assert!(!workspace.assistant.read(cx).knowledge_save_ready_for_test());
    });

    cx.update_window(fixture.window, |_, window, cx| {
        window.click("knowledge-reload", cx);
        window.render_frame(cx);
    })
    .checked("explicitly reload the latest StateStore after the conflict");
    cx.wait_for(fixture.window, Duration::from_secs(3), |_, cx| {
        !fixture.workspace.read(cx).state_reloading
    })
    .await;
    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        assert!(window.find("knowledge-preview-action").visible());
        assert!(window.try_find("knowledge-preview").is_none());
        assert!(window.try_find("knowledge-save-conflict").is_none());
    })
    .checked("require a fresh review after the explicit reload");
    fixture.workspace.read_with(cx, |workspace, _| {
        assert_eq!(workspace.state.settings.language, Language::En);
    });

    let persisted = fixture
        .store
        .load()
        .checked("reload competing state after conflict");
    assert_eq!(persisted.settings.language, Language::En);
    assert!(persisted.knowledge_entries.is_empty());
    assert!(panes.iter().all(|pane| writes(pane).is_empty()));
}

#[gpui_kit::test]
async fn workspace_knowledge_reload_rebinds_authoritative_ui_configuration(
    cx: &mut TestAppContext,
) {
    let fixture = mount(cx, Vec::new());
    let panes = attach_remote_panes(&fixture, cx);

    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |workspace, cx| {
            workspace.show_assistant = true;
            cx.notify();
        });
        window.render_frame(cx);
        window.click("context-screen", cx);
    })
    .checked("capture terminal context before the authoritative reload");
    cx.run_until_parked();

    cx.update_window(fixture.window, |_, window, cx| {
        window.click("knowledge-preview-action", cx);
        window.render_frame(cx);
        window.click("knowledge-confirm-completed", cx);
        window.render_frame(cx);
    })
    .checked("prepare a review that can enter the reload boundary");

    let external_profile = {
        let mut profile = keelshell_core::NamedAiProfile::draft(AiPreset::Custom);
        profile.name = "Externally selected assistant".into();
        profile.api_style = AiApiStyle::ChatCompletions;
        profile.endpoint = "https://external.example/v1/chat".into();
        profile.model = "external-model".into();
        profile.authentication = AiAuthentication::None;
        profile
    };
    let external_profile_id = external_profile.id;
    let mut competing = fixture.store.load().checked("load reload competitor state");
    competing.settings.language = Language::En;
    competing.settings.theme = Theme::Dark;
    competing.settings.ai_profiles = AiProfileCatalog {
        active_id: Some(external_profile_id),
        profiles: vec![external_profile],
    };
    fixture
        .store
        .save(&competing)
        .checked("persist external assistant and appearance state");

    cx.update_window(fixture.window, |_, window, cx| {
        window.scroll(
            "assistant-scroll",
            ScrollDelta::Lines(point(0., -1000.)),
            cx,
        );
        window.render_frame(cx);
        window.click("knowledge-save", cx);
        window.render_frame(cx);
    })
    .checked("create the stale save that requires reload");
    cx.wait_for(fixture.window, Duration::from_secs(3), |_, cx| {
        !fixture.workspace.read(cx).saving
    })
    .await;

    cx.update_window(fixture.window, |_, window, cx| {
        window.scroll(
            "assistant-scroll",
            ScrollDelta::Lines(point(0., -1000.)),
            cx,
        );
        window.render_frame(cx);
        assert!(window.find("knowledge-reload").visible());
        window.click("knowledge-reload", cx);
        window.render_frame(cx);
    })
    .checked("start the explicit reload");
    cx.wait_for(fixture.window, Duration::from_secs(3), |_, cx| {
        !fixture.workspace.read(cx).state_reloading
    })
    .await;

    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        assert_eq!(i18n::language(cx), Language::En);
        assert_eq!(
            cx.global::<gpui_kit::component::Theme>().mode,
            gpui_kit::component::ThemeMode::Dark
        );
    })
    .checked("apply authoritative locale and theme after reload");
    fixture.workspace.read_with(cx, |workspace, cx| {
        assert_eq!(workspace.state.settings.theme, Theme::Dark);
        assert_eq!(
            workspace.assistant.read(cx).active_profile_id_for_test(),
            Some(external_profile_id)
        );
        assert!(workspace.ai_credentials.get(&external_profile_id).is_none());
    });
    assert!(panes.iter().all(|pane| writes(pane).is_empty()));
}

#[gpui_kit::test]
fn workspace_blocks_ai_settings_apply_while_state_reloads(cx: &mut TestAppContext) {
    let fixture = mount(cx, Vec::new());

    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |workspace, cx| {
            workspace.show_assistant = true;
            workspace.open_ai_settings(window, cx);
            cx.notify();
        });
        window.render_frame(cx);
        fixture.workspace.update(cx, |workspace, cx| {
            workspace.state_reloading = true;
            cx.notify();
        });
        window.render_frame(cx);
        assert!(window.find("ai-settings-apply").visible());
        window.click("ai-settings-apply", cx);
        window.render_frame(cx);
    })
    .checked("reject settings apply while reload is active");

    fixture.workspace.read_with(cx, |workspace, cx| {
        assert!(workspace.state_reloading);
        assert!(!workspace.saving);
        let panel = workspace
            .ai_settings
            .as_ref()
            .unwrap_or_else(|| panic!("settings panel remains open"));
        assert!(!panel.read(cx).is_saving_for_test());
    });
}

#[gpui_kit::test]
fn workspace_blocks_update_and_secure_state_panels_while_state_reloads(cx: &mut TestAppContext) {
    let fixture = mount(cx, Vec::new());

    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |workspace, cx| {
            workspace.open_updates(window, cx);
            workspace.state_reloading = true;
            cx.notify();
        });
        window.render_frame(cx);
        assert!(window.try_find("vault-settings-panel").is_none());
        window.click("updates-weekly", cx);
        window.render_frame(cx);
        window.click("save-update-preferences", cx);
        window.render_frame(cx);
    })
    .checked("keep update controls closed while reload is active");

    fixture.workspace.read_with(cx, |workspace, cx| {
        assert!(workspace.state_reloading);
        assert!(workspace.profile_sync.is_none());
        assert!(workspace.vault_settings.is_none());
        assert!(
            !workspace
                .update_service
                .read(cx)
                .preferences_saving_for_test()
        );
    });

    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |workspace, cx| {
            workspace.open_profile_sync(window, cx);
            workspace.open_vault_settings(window, cx);
            workspace.open_configuration_recovery(window, cx);
        });
    })
    .checked("reject secure configuration panels during reload");
    fixture.workspace.read_with(cx, |workspace, _| {
        assert!(workspace.profile_sync.is_none());
        assert!(workspace.vault_settings.is_none());
        assert!(workspace.configuration_recovery.is_none());
    });
}

#[gpui_kit::test]
async fn workspace_reload_failure_keeps_knowledge_save_blocked(cx: &mut TestAppContext) {
    let fixture = mount(cx, Vec::new());
    let _panes = attach_remote_panes(&fixture, cx);

    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |workspace, cx| {
            workspace.show_assistant = true;
            cx.notify();
        });
        window.render_frame(cx);
        window.click("context-screen", cx);
    })
    .checked("capture context before corrupting the reload source");
    cx.run_until_parked();
    cx.update_window(fixture.window, |_, window, cx| {
        window.click("knowledge-preview-action", cx);
        window.render_frame(cx);
        window.click("knowledge-confirm-completed", cx);
        window.render_frame(cx);
    })
    .checked("create a review before corrupting the reload source");
    let review_id = fixture.workspace.read_with(cx, |workspace, cx| {
        workspace
            .assistant
            .read(cx)
            .knowledge_review_id_for_test()
            .unwrap_or_else(|| panic!("knowledge review should exist"))
    });
    fixture.workspace.update(cx, |workspace, cx| {
        workspace.assistant.update(cx, |assistant, cx| {
            assistant.mark_knowledge_save_pending(review_id, cx);
            assistant.mark_knowledge_save_failed(review_id, true, cx);
        });
    });
    std::fs::write(fixture.store.path(), b"{corrupt").checked("corrupt reload fixture");

    cx.update_window(fixture.window, |_, window, cx| {
        window.scroll(
            "assistant-scroll",
            ScrollDelta::Lines(point(0., -1000.)),
            cx,
        );
        window.render_frame(cx);
        assert!(window.find("knowledge-reload").visible());
        window.click("knowledge-reload", cx);
        window.render_frame(cx);
    })
    .checked("start reload against corrupt state");
    cx.wait_for(fixture.window, Duration::from_secs(3), |_, cx| {
        !fixture.workspace.read(cx).state_reloading
    })
    .await;
    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        assert!(window.find("knowledge-reload").visible());
        assert!(window.try_find("knowledge-save").is_none());
        fixture.workspace.read_with(cx, |workspace, cx| {
            assert!(
                workspace
                    .assistant
                    .read(cx)
                    .knowledge_reload_failed_for_test()
            );
            assert!(!workspace.assistant.read(cx).knowledge_save_ready_for_test());
        });
    })
    .checked("keep the failed reload fail closed");
}

#[gpui_kit::test]
fn workspace_selection_capture_uses_the_focused_terminal_source(cx: &mut TestAppContext) {
    let fixture = mount(cx, Vec::new());
    let panes = attach_remote_panes(&fixture, cx);
    let active_id = panes[0].terminal.entity_id();

    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |workspace, cx| {
            workspace.show_assistant = true;
            cx.notify();
        });
        window.render_frame(cx);
    })
    .checked("show the assistant beside the terminal before selecting text");
    panes[0].terminal.update(cx, |terminal, _| {
        terminal.emulator.start_selection(0, 0);
        terminal
            .emulator
            .update_selection(0, "left-pane-output".len().saturating_sub(1));
        assert_eq!(terminal.selected_text(), "left-pane-output");
    });

    cx.update_window(fixture.window, |_, window, cx| {
        window.click("context-selection", cx);
    })
    .checked("capture selected terminal context through the Workspace subscription");
    cx.run_until_parked();

    fixture.workspace.read_with(cx, |workspace, cx| {
        let assistant = workspace.assistant.read(cx);
        let (context, host, session_id) = assistant.captured_context_for_test();
        assert!(context.contains("left-pane-output"));
        assert_eq!(host, "fixture-0@example.invalid:22");
        assert_eq!(session_id, format!("{active_id:?}"));
    });
}

#[gpui_kit::test]
fn existing_command_draft_cannot_drift_to_another_tab_and_new_draft_allows_rebinding(
    cx: &mut TestAppContext,
) {
    let fixture = mount(cx, Vec::new());
    let panes = attach_remote_panes(&fixture, cx);
    let first = panes[0].terminal.entity_id();
    let second = panes[1].terminal.entity_id();
    cx.update_window(fixture.window, |_, window, cx| {
        let input = fixture.workspace.read(cx).command.entity_id();
        window.click(("input", input), cx);
        window.input("printf reviewed-first", cx);
    })
    .checked("type an original command draft on the first tab");
    cx.run_until_parked();
    fixture.workspace.read_with(cx, |workspace, _| {
        assert_eq!(workspace.command_target, Some(first))
    });
    cx.update_window(fixture.window, |_, window, cx| {
        window.click(("session-tab", 1_usize), cx);
    })
    .checked("switch tabs through its production pointer callback");
    cx.run_until_parked();
    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        let workspace = fixture.workspace.read(cx);
        assert_eq!(workspace.tabs[workspace.active].entity_id(), second);
        assert_eq!(workspace.command_target, Some(first));
        assert_eq!(workspace.command.read(cx).value(), "printf reviewed-first");
        window.click("run-command", cx);
        // The method must enforce the same binding even if a future keyboard
        // shortcut bypasses the disabled button.
        fixture
            .workspace
            .update(cx, |workspace, cx| workspace.run_command(window, cx));
    })
    .checked("refuse the old command on the newly selected tab");
    assert!(writes(&panes[0]).is_empty());
    assert!(writes(&panes[1]).is_empty());
    cx.update_window(fixture.window, |_, window, cx| {
        let input = fixture.workspace.read(cx).command.entity_id();
        window.click(("input", input), cx);
        window.press(
            if cfg!(target_os = "macos") {
                "cmd-a"
            } else {
                "ctrl-a"
            },
            cx,
        );
        window.press("backspace", cx);
    })
    .checked("explicitly clear the old draft");
    cx.run_until_parked();
    fixture.workspace.read_with(cx, |workspace, cx| {
        assert!(workspace.command.read(cx).value().is_empty());
        assert_eq!(workspace.command_target, Some(first));
    });
    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        window.click("new-command-draft", cx);
        window.input("printf reviewed-second", cx);
    })
    .checked("begin a fresh draft on the current tab");
    cx.run_until_parked();
    fixture.workspace.read_with(cx, |workspace, _| {
        assert_eq!(workspace.command_target, Some(second))
    });
    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        window.click("run-command", cx);
    })
    .checked("send only the new explicitly rebound draft");
    cx.run_until_parked();
    assert!(writes(&panes[0]).is_empty());
    assert_eq!(writes(&panes[1]), b"printf reviewed-second\r");
}

#[gpui_kit::test]
async fn connection_library_clipboard_import_favorite_export_and_delete_persist(
    cx: &mut TestAppContext,
) {
    let fixture = mount(cx, Vec::new());
    let mut source = AppState::default();
    source.connections.push(Connection::new(
        "Imported host",
        "import.example.test",
        "operator",
    ));
    let document = source
        .export_connections()
        .checked("create validated connection export");

    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        cx.write_to_clipboard(ClipboardItem::new_string(document.clone()));
        window.click("import-connections", cx);
    })
    .checked("import connection JSON through the production manager");
    cx.wait_for(fixture.window, Duration::from_secs(3), |_, cx| {
        !fixture.workspace.read(cx).saving
    })
    .await;
    fixture.workspace.read_with(cx, |workspace, _| {
        assert_eq!(workspace.state.connections.len(), 1);
        assert_eq!(workspace.state.connections[0].name, "Imported host");
    });

    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        window.click(("favorite", 0_usize), cx);
    })
    .checked("toggle the imported connection favorite marker");
    cx.wait_for(fixture.window, Duration::from_secs(3), |_, cx| {
        !fixture.workspace.read(cx).saving
    })
    .await;
    fixture.workspace.read_with(cx, |workspace, _| {
        assert!(workspace.state.connections[0].favorite);
    });

    let exported = cx
        .update_window(fixture.window, |_, window, cx| {
            window.render_frame(cx);
            window.click("export-connections", cx);
            cx.read_from_clipboard().and_then(|item| item.text())
        })
        .checked("read exported JSON from the system clipboard");
    let Some(exported) = exported else {
        panic!("export action did not place text on the clipboard");
    };
    assert!(exported.contains("import.example.test"));
    assert!(!exported.contains("known_hosts"));

    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        window.click(("delete", 0_usize), cx);
    })
    .checked("delete the imported connection through the production manager");
    cx.wait_for(fixture.window, Duration::from_secs(3), |_, cx| {
        !fixture.workspace.read(cx).saving
    })
    .await;
    fixture.workspace.read_with(cx, |workspace, _| {
        assert!(workspace.state.connections.is_empty());
    });
    assert!(
        fixture
            .store
            .load()
            .checked("reload deleted connection state")
            .connections
            .is_empty()
    );
}

#[gpui_kit::test]
async fn connection_library_imports_reviewable_openssh_config_from_clipboard(
    cx: &mut TestAppContext,
) {
    let fixture = mount(cx, Vec::new());
    let document = "Host app\n HostName app.example.test\n User deploy\n Port 2222\nHost web-*\n HostName ignored.example.test\n User deploy\n";
    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        cx.write_to_clipboard(ClipboardItem::new_string(document.into()));
        window.click("import-openssh", cx);
    })
    .checked("import OpenSSH text through the production manager");
    fixture.workspace.read_with(cx, |workspace, cx| {
        assert!(workspace.state.connections.is_empty());
        assert!(workspace.openssh_review.is_some());
        assert!(workspace.status.render(cx).contains("审阅"));
    });
    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        window.click("confirm-openssh-import", cx);
    })
    .checked("confirm the reviewed OpenSSH import");
    cx.wait_for(fixture.window, Duration::from_secs(3), |_, cx| {
        !fixture.workspace.read(cx).saving
    })
    .await;
    fixture.workspace.read_with(cx, |workspace, _| {
        assert_eq!(workspace.state.connections.len(), 1);
        let connection = &workspace.state.connections[0];
        assert_eq!(connection.name, "app");
        assert_eq!(connection.host, "app.example.test");
        assert_eq!(connection.port, 2222);
        assert!(workspace.openssh_review.is_none());
    });
}

#[gpui_kit::test]
async fn cancelling_reviewable_openssh_import_keeps_library_unchanged(cx: &mut TestAppContext) {
    let fixture = mount(cx, Vec::new());
    let document = "Host app\n HostName app.example.test\n User deploy\n";
    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        cx.write_to_clipboard(ClipboardItem::new_string(document.into()));
        window.click("import-openssh", cx);
    })
    .checked("open the OpenSSH import review");
    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        window.click("cancel-openssh-import", cx);
    })
    .checked("cancel the OpenSSH import review");
    fixture.workspace.read_with(cx, |workspace, _| {
        assert!(workspace.state.connections.is_empty());
        assert!(workspace.openssh_review.is_none());
    });
}

fn password_profile() -> Connection {
    let mut profile = Connection::new("测试凭据", "127.0.0.1", "fixture-user");
    profile.auth = keelshell_core::AuthMethod::Password;
    profile
}

fn begin_vault_save(fixture: &Fixture, cx: &mut TestAppContext) {
    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |workspace, cx| {
            let profile = workspace.state.connections[0].clone();
            workspace.prepare_login(profile, None, window, cx);
        });
        window.render_frame(cx);
        window.click("save-credential-mode", cx);
        fixture.workspace.update(cx, |workspace, cx| {
            let login = workspace.login.as_ref().checked_option("open login");
            for (input, value) in [
                (&login.secret, "ssh-fixture-secret-中文"),
                (&login.master, "vault-fixture-master"),
                (&login.confirmation, "vault-fixture-master"),
            ] {
                input.update(cx, |input, cx| input.set_value(value, window, cx));
            }
        });
        window.render_frame(cx);
        window.click("submit-login", cx);
    })
    .checked("submit explicit credential save through production buttons");
}

trait CheckedOption<T> {
    fn checked_option(self, message: &str) -> T;
}
impl<T> CheckedOption<T> for Option<T> {
    fn checked_option(self, message: &str) -> T {
        self.unwrap_or_else(|| panic!("{message}"))
    }
}

async fn wait_for_vault(fixture: &Fixture, cx: &mut TestAppContext) {
    cx.wait_for(fixture.window, Duration::from_secs(20), |_, cx| {
        !fixture.workspace.read(cx).saving
    })
    .await;
}

#[gpui_kit::test]
async fn vault_login_saves_locks_unlinks_and_never_connects_on_save(cx: &mut TestAppContext) {
    let fixture = mount(cx, vec![password_profile()]);
    begin_vault_save(&fixture, cx);
    wait_for_vault(&fixture, cx).await;
    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        let workspace = fixture.workspace.read(cx);
        let login = workspace
            .login
            .as_ref()
            .checked_option("save keeps authentication modal open");
        assert!(matches!(login.mode, super::vault::LoginMode::Unlock));
        assert!(login.connection.credential_ref.is_some());
        assert!(!login.busy);
        assert!(!workspace.connecting);
        assert!(workspace.tabs.is_empty());
        for input in [&login.secret, &login.master, &login.confirmation] {
            assert!(input.read(cx).value().is_empty());
        }
        assert!(login.master.read(cx).focus_handle(cx).is_focused(window));
        assert_eq!(window.find("submit-login").label(), Some("解锁并连接"));
        fixture
            .workspace
            .update(cx, |workspace, cx| workspace.switch_language(window, cx));
    })
    .checked("saving leaves vault locked and updates prompt");
    wait_for_vault(&fixture, cx).await;
    let stored = fixture
        .store
        .load()
        .checked("read saved credential reference");
    assert!(stored.connections[0].credential_ref.is_some());
    let vault_path = fixture.store.path().with_file_name("vault.json");
    assert!(vault_path.is_file());
    for path in [fixture.store.path(), vault_path.as_path()] {
        let bytes = std::fs::read_to_string(path).checked("inspect isolated persisted document");
        assert!(!bytes.contains("ssh-fixture-secret"));
        assert!(!bytes.contains("vault-fixture-master"));
    }
    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        assert_eq!(
            window.find("submit-login").label(),
            Some("Unlock and connect")
        );
        window.click("forget-credential", cx);
    })
    .checked("unlink saved credential in English");
    wait_for_vault(&fixture, cx).await;
    fixture.workspace.read_with(cx, |workspace, _| {
        assert!(workspace.state.connections[0].credential_ref.is_none());
        assert!(matches!(
            workspace
                .login
                .as_ref()
                .checked_option("modal remains open")
                .mode,
            super::vault::LoginMode::Once
        ));
        assert!(!workspace.connecting);
    });
    assert!(
        fixture
            .store
            .load()
            .checked("read unlinked profile")
            .connections[0]
            .credential_ref
            .is_none()
    );
    assert!(
        vault_path.exists(),
        "unlinking explicitly retains encrypted entries"
    );
}

#[gpui_kit::test]
async fn vault_wrong_master_and_cancelled_unlock_never_start_ssh(cx: &mut TestAppContext) {
    let fixture = mount(cx, vec![password_profile()]);
    begin_vault_save(&fixture, cx);
    wait_for_vault(&fixture, cx).await;
    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |workspace, cx| {
            let login = workspace.login.as_ref().checked_option("saved login");
            login
                .master
                .update(cx, |input, cx| input.set_value("wrong-master", window, cx));
            workspace.submit_login(window, cx);
        });
    })
    .checked("submit incorrect master password");
    wait_for_vault(&fixture, cx).await;
    cx.update_window(fixture.window, |_, window, cx| {
        let workspace = fixture.workspace.read(cx);
        let login = workspace
            .login
            .as_ref()
            .checked_option("failed unlock remains retryable");
        assert!(!workspace.connecting);
        assert!(!login.busy);
        assert!(
            login
                .message
                .as_ref()
                .checked_option("unlock error")
                .render(cx)
                .contains("无法解锁")
        );
        assert!(login.master.read(cx).value().is_empty());
        fixture.workspace.update(cx, |workspace, cx| {
            let login = workspace.login.as_ref().checked_option("retry login");
            let master = login.master.clone();
            master.update(cx, |input, cx| {
                input.set_value("vault-fixture-master", window, cx)
            });
            workspace.submit_login(window, cx);
            workspace.cancel_login(window, cx);
            assert!(master.read(cx).value().is_empty());
            assert!(workspace.login.is_none());
        });
    })
    .checked("cancel unlock before foreground delivery");
    wait_for_vault(&fixture, cx).await;
    fixture.workspace.read_with(cx, |workspace, _| {
        assert!(workspace.login.is_none());
        assert!(!workspace.connecting);
        assert!(workspace.tabs.is_empty());
        assert!(workspace.state.connections[0].credential_ref.is_some());
    });
}

#[gpui_kit::test]
async fn vault_state_conflict_keeps_orphan_encrypted_entry_without_link_or_connection(
    cx: &mut TestAppContext,
) {
    let fixture = mount(cx, vec![password_profile()]);
    let other = StateStore::new(fixture.store.path());
    let mut external = other.load().checked("external snapshot");
    external.settings.font_size = 19.;
    other
        .save(&external)
        .checked("create state conflict before vault save");
    begin_vault_save(&fixture, cx);
    wait_for_vault(&fixture, cx).await;
    fixture.workspace.read_with(cx, |workspace, cx| {
        let login = workspace
            .login
            .as_ref()
            .checked_option("failed save preserves modal");
        assert!(!login.busy);
        let message = login
            .message
            .as_ref()
            .checked_option("save error")
            .render(cx);
        assert!(message.contains("连接配置保存失败"));
        assert!(message.contains("保存其他工作，再重启应用"));
        assert!(message.contains("密码输入已清空"));
        assert!(!message.contains("重新打开配置"));
        assert_eq!(workspace.status.render(cx), message);
        for input in [&login.secret, &login.master, &login.confirmation] {
            assert!(input.read(cx).value().is_empty());
        }
        assert!(workspace.state.connections[0].credential_ref.is_none());
        assert!(!workspace.connecting);
    });
    cx.update(|cx| i18n::set_language(Language::En, cx));
    fixture.workspace.read_with(cx, |workspace, cx| {
        let message = workspace.status.render(cx);
        assert!(message.contains("Save your other work, then restart the app"));
        assert!(message.contains("password inputs were cleared"));
        assert!(!message.contains("input preserved"));
        assert!(!message.contains("Reopen the profile"));
    });
    assert!(fixture.store.path().with_file_name("vault.json").exists());
    let saved = other
        .load()
        .checked("state failure preserves external edit");
    assert_eq!(saved.settings.font_size, 19.);
    assert!(saved.connections[0].credential_ref.is_none());
}

#[gpui_kit::test]
async fn editing_connection_name_preserves_vault_reference_but_target_change_removes_it(
    cx: &mut TestAppContext,
) {
    let mut profile = password_profile();
    profile.credential_ref = Some(uuid::Uuid::new_v4());
    let reference = profile.credential_ref;
    let fixture = mount(cx, vec![profile.clone()]);
    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |workspace, cx| {
            workspace.edit_connection(profile, window, cx);
            let form = workspace.form.as_ref().checked_option("profile editor");
            form.name
                .update(cx, |input, cx| input.set_value("已重命名", window, cx));
            workspace.save_connection(window, cx);
        });
    })
    .checked("rename profile");
    wait_for_vault(&fixture, cx).await;
    assert_eq!(
        fixture.store.load().checked("renamed profile").connections[0].credential_ref,
        reference
    );
    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |workspace, cx| {
            let profile = workspace.state.connections[0].clone();
            workspace.edit_connection(profile, window, cx);
            let form = workspace.form.as_ref().checked_option("profile editor");
            form.host
                .update(cx, |input, cx| input.set_value("other.invalid", window, cx));
            workspace.save_connection(window, cx);
        });
    })
    .checked("edit profile destination");
    wait_for_vault(&fixture, cx).await;
    assert!(
        fixture
            .store
            .load()
            .checked("changed destination")
            .connections[0]
            .credential_ref
            .is_none()
    );
}

#[gpui_kit::test]
fn vault_authentication_focus_and_cancellation_keep_secrets_out_of_remote_terminal(
    cx: &mut TestAppContext,
) {
    let fixture = mount(cx, vec![password_profile()]);
    let panes = attach_remote_panes(&fixture, cx);
    let _ = writes(&panes[0]);
    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |workspace, cx| {
            workspace.prepare_login(workspace.state.connections[0].clone(), None, window, cx);
        });
        window.render_frame(cx);
        let (secret, master) = {
            let workspace = fixture.workspace.read(cx);
            let login = workspace
                .login
                .as_ref()
                .checked_option("authentication prompt");
            assert!(login.secret.read(cx).focus_handle(cx).is_focused(window));
            (login.secret.clone(), login.master.clone())
        };
        window.click("ssh-password", cx);
        window.input("ssh-typed-secret", cx);
        window.click("save-credential-mode", cx);
        window.render_frame(cx);
        assert!(secret.read(cx).value().is_empty());
        window.click(("input", master.entity_id()), cx);
        window.input("typed-master-secret", cx);
        window.click("cancel-login", cx);
        assert!(master.read(cx).value().is_empty());
        assert!(fixture.workspace.read(cx).login.is_none());
    })
    .checked("type masked credentials and cancel via real UI handlers");
    cx.run_until_parked();
    assert!(writes(&panes[0]).is_empty());
    assert!(writes(&panes[1]).is_empty());
    assert!(!fixture.store.path().with_file_name("vault.json").exists());
}

struct VaultSshFixture {
    authenticated: Arc<AtomicBool>,
}

impl russh::server::Handler for VaultSshFixture {
    type Error = russh::Error;

    async fn auth_password(
        &mut self,
        user: &str,
        password: &str,
    ) -> Result<russh::server::Auth, Self::Error> {
        let valid = user == "fixture-user" && password == "ssh-fixture-secret-中文";
        self.authenticated
            .store(valid, std::sync::atomic::Ordering::Release);
        Ok(if valid {
            russh::server::Auth::Accept
        } else {
            russh::server::Auth::reject()
        })
    }
}

#[gpui_kit::test]
async fn vault_successful_unlock_authenticates_over_real_loopback_ssh(cx: &mut TestAppContext) {
    use russh::keys::{HashAlg, PrivateKey, ssh_key::private::Ed25519Keypair};
    let fixture = mount(cx, vec![password_profile()]);
    let runtime = fixture
        .workspace
        .read_with(cx, |workspace, _| workspace.runtime.clone());
    let listener = runtime
        .block_on(tokio::net::TcpListener::bind("127.0.0.1:0"))
        .checked("bind loopback authentication fixture");
    let port = listener.local_addr().checked("fixture port").port();
    // Deterministic public test-only seed; never used by a real SSH endpoint.
    let key = PrivateKey::from(Ed25519Keypair::from_seed(&[0x71; 32]));
    let fingerprint = key.public_key().fingerprint(HashAlg::Sha256).to_string();
    let config = Arc::new(russh::server::Config {
        keys: vec![key],
        auth_rejection_time: Duration::from_millis(1),
        auth_rejection_time_initial: Some(Duration::from_millis(1)),
        ..Default::default()
    });
    let authenticated = Arc::new(AtomicBool::new(false));
    let seen = authenticated.clone();
    let server = runtime.spawn(async move {
        if let Ok(Ok((socket, _))) =
            tokio::time::timeout(Duration::from_secs(20), listener.accept()).await
            && let Ok(session) = russh::server::run_stream(
                config,
                socket,
                VaultSshFixture {
                    authenticated: seen,
                },
            )
            .await
        {
            let _ = tokio::time::timeout(Duration::from_secs(20), session).await;
        }
    });
    cx.update_window(fixture.window, |_, _, cx| {
        fixture.workspace.update(cx, |workspace, _| {
            workspace.state.connections[0].port = port;
        });
    })
    .checked("assign isolated loopback destination");
    begin_vault_save(&fixture, cx);
    wait_for_vault(&fixture, cx).await;
    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |workspace, cx| {
            let login = workspace
                .login
                .as_mut()
                .checked_option("saved credential prompt");
            // The fixture's generated host identity is explicitly trusted for
            // this authentication test; separate transport tests verify TOFU.
            login.pin = Some(fingerprint);
            login.master.update(cx, |input, cx| {
                input.set_value("vault-fixture-master", window, cx)
            });
        });
        window.render_frame(cx);
        window.click("submit-login", cx);
    })
    .checked("unlock stored credential through production button");
    cx.wait_for(fixture.window, Duration::from_secs(20), |_, cx| {
        !fixture.workspace.read(cx).tabs.is_empty()
    })
    .await;
    assert!(
        authenticated.load(std::sync::atomic::Ordering::Acquire),
        "SSH server must receive the decrypted fixture password, never the master password"
    );
    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |workspace, cx| {
            assert!(workspace.login.is_none());
            assert!(!workspace.connecting);
            assert_eq!(workspace.remote_sessions.len(), 1);
            workspace.close_tab(&super::CloseTab, window, cx);
        });
    })
    .checked("close authenticated fixture session");
    server.abort();
}

#[gpui_kit::test]
fn keyboard_interactive_prompt_is_ephemeral_and_cancelable(cx: &mut TestAppContext) {
    let mut profile = Connection::new("MFA target", "mfa.example.test", "operator");
    profile.auth = keelshell_core::AuthMethod::Password;
    let fixture = mount(cx, vec![profile.clone()]);
    let mut receiver = cx
        .update_window(fixture.window, |_, window, cx| {
            fixture.workspace.update(cx, |workspace, cx| {
                workspace.request_connect(profile.clone(), window, cx);
                let route = workspace
                    .connect_route
                    .as_mut()
                    .checked_option("keyboard-interactive route");
                route.keyboard_interactive = true;
                let route_id = route.id;
                let (sender, receiver) = tokio::sync::oneshot::channel();
                let answer = cx.new(|cx| {
                    InputState::new(window, cx)
                        .masked(true)
                        .placeholder("Enter this response")
                });
                answer.update(cx, |input, cx| input.set_value("123456", window, cx));
                workspace.keyboard_interactive = Some(KeyboardInteractivePrompt {
                    identity: uuid::Uuid::new_v4(),
                    route_id,
                    index: 0,
                    name: "Duo MFA".into(),
                    instructions: "Approve the sign-in, then enter the code.".into(),
                    fields: vec![KeyboardInteractiveField {
                        prompt: "One-time code".into(),
                        answer,
                    }],
                    response: Some(sender),
                });
                receiver
            })
        })
        .checked("prepare keyboard-interactive MFA prompt");
    cx.update_window(fixture.window, |_, window, cx| {
        for language in [Language::ZhCn, Language::En] {
            i18n::set_language(language, cx);
            window.render_frame(cx);
            assert!(window.try_find("keyboard-interactive-content").is_some());
            assert!(window.try_find("submit-keyboard-interactive").is_some());
            assert_eq!(
                window.find("submit-keyboard-interactive").label(),
                Some(if language == Language::En {
                    "Submit and continue"
                } else {
                    "提交并继续"
                })
            );
        }
        window.click("submit-keyboard-interactive", cx);
        fixture.workspace.read_with(cx, |workspace, _| {
            assert!(workspace.keyboard_interactive.is_none());
        });
    })
    .checked("submit keyboard-interactive MFA prompt");
    assert!(matches!(
        receiver.try_recv(),
        Ok(Some(answers)) if answers.len() == 1 && answers[0].as_str() == "123456"
    ));

    let mut receiver = cx
        .update_window(fixture.window, |_, window, cx| {
            fixture.workspace.update(cx, |workspace, cx| {
                let route_id = workspace
                    .connect_route
                    .as_ref()
                    .map(|route| route.id)
                    .checked_option("route after submitted challenge");
                let (sender, receiver) = tokio::sync::oneshot::channel();
                let answer = cx.new(|cx| InputState::new(window, cx).masked(true));
                workspace.keyboard_interactive = Some(KeyboardInteractivePrompt {
                    identity: uuid::Uuid::new_v4(),
                    route_id,
                    index: 0,
                    name: "Duo MFA".into(),
                    instructions: String::new(),
                    fields: vec![KeyboardInteractiveField {
                        prompt: "One-time code".into(),
                        answer,
                    }],
                    response: Some(sender),
                });
                receiver
            })
        })
        .checked("prepare second keyboard-interactive prompt");
    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        window.click("cancel-keyboard-interactive", cx);
        fixture.workspace.read_with(cx, |workspace, _| {
            assert!(workspace.keyboard_interactive.is_none());
            assert!(workspace.connect_route.is_none());
        });
    })
    .checked("cancel keyboard-interactive MFA prompt");
    assert!(matches!(receiver.try_recv(), Ok(None)));
}

pub(crate) mod batch_peer;
mod command_workflows;
mod commands;
mod credentials;
mod dependency_workflow;
mod library;
mod routes;
mod themes;
mod updates;
mod workflow_audit;

mod remote_completion;

mod mcp;

mod independent_target_parameters;
