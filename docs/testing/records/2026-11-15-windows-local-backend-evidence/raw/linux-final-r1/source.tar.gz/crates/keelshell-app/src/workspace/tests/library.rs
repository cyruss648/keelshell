use super::*;
use crate::workspace::library::{DestinationTarget, LibraryFilter};
use gpui_kit::{App, Bounds, MouseButton, Pixels, Point, Window};

fn contained(inner: Bounds<Pixels>, outer: Bounds<Pixels>) -> bool {
    inner.origin.x >= outer.origin.x
        && inner.origin.y >= outer.origin.y
        && inner.right() <= outer.right()
        && inner.bottom() <= outer.bottom()
}

fn click_painted_library_position(position: Point<Pixels>, window: &mut Window, cx: &mut App) {
    // Keep the old frame's listeners attached while the live profile changes.
    for event in [
        gpui_kit::MouseDownEvent {
            button: MouseButton::Left,
            position,
            click_count: 1,
            ..Default::default()
        }
        .to_platform_input(),
        gpui_kit::MouseUpEvent {
            button: MouseButton::Left,
            position,
            click_count: 1,
            ..Default::default()
        }
        .to_platform_input(),
    ] {
        window.dispatch_event(event, cx);
    }
}

fn persist_fixture_state_without_repaint(
    fixture: &Fixture,
    state: AppState,
    operation: &str,
    cx: &mut TestAppContext,
) -> AppState {
    let saved = fixture.store.save(&state).checked(operation);
    let adopted = saved.clone();
    cx.update_window(fixture.window, |_, _, cx| {
        fixture.workspace.update(cx, |workspace, cx| {
            workspace.state = adopted.clone();
            let gate = workspace.app_windows.read(cx).gate.clone();
            let reload = crate::app_windows::ConfigurationGate::begin_reload_lease(
                &gate,
                workspace.window_id,
            )
            .checked("begin no-repaint fixture adoption");
            reload.finish(Some(&adopted));
            workspace.configuration_epoch =
                gate.lock().checked("lock no-repaint fixture gate").epoch();
            workspace.configuration_invalidated = false;
        });
    })
    .checked("adopt fixture state without repaint");
    saved
}

#[gpui_kit::test]
fn wide_connection_manager_retains_columns_and_visible_actions(cx: &mut TestAppContext) {
    let fixture = mount_sized(
        cx,
        vec![Connection::new("审核主机", "192.0.2.10", "operator")],
        1440.,
        900.,
    );
    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |workspace, cx| {
            workspace.show_connections = true;
            cx.notify();
        });
        for language in [Language::ZhCn, Language::En] {
            i18n::set_language(language, cx);
            window.render_frame(cx);
            let dialog = window.find("connection-manager-dialog").bounds();
            let manager = window.within("connection-manager-dialog");
            // The wide layout keeps the table rather than rendering a card.
            assert!(manager.try_find(("connection-endpoint", 0_usize)).is_none());
            let row = manager.find(("connection-row", 0_usize)).bounds();
            assert!(contained(row, dialog));
            for id in ["connect", "edit", "move", "duplicate", "delete", "favorite"] {
                let action = manager.find((id, 0_usize));
                assert!(action.visible());
                assert!(
                    contained(action.bounds(), row),
                    "wide {id} escaped: {:?}",
                    action.bounds()
                );
                assert!(
                    action
                        .label()
                        .checked_option("complete accessible target")
                        .contains("审核主机 · operator@192.0.2.10:22")
                );
            }
        }
        i18n::set_language(Language::ZhCn, cx);
    })
    .checked("wide manager columns with complete accessible target identities");
}

#[gpui_kit::test]
fn compact_library_keeps_identity_and_actions_visible_with_assistant_open(cx: &mut TestAppContext) {
    for width in [480., 760., 1100.] {
        let fixture = mount_sized(
            cx,
            vec![Connection::new("审核主机", "192.0.2.10", "operator")],
            width,
            900.,
        );
        cx.update_window(fixture.window, |_, window, cx| {
            fixture.workspace.update(cx, |workspace, cx| {
                workspace.show_assistant = true;
                cx.notify();
            });
            for language in [Language::ZhCn, Language::En] {
                i18n::set_language(language, cx);
                window.render_frame(cx);
                let row = window.find(("connection-row", 0_usize)).bounds();
                assert!(
                    contained(row, window.bounds()),
                    "row escaped {width}: {row:?}"
                );
                for (id, label) in [
                    ("connection-name", "审核主机"),
                    ("connection-endpoint", "operator@192.0.2.10:22"),
                ] {
                    let identity = window.find((id, 0_usize));
                    assert_eq!(identity.label(), Some(label));
                    assert!(identity.visible());
                    assert!(contained(identity.bounds(), row));
                }
                for id in ["connect", "edit", "move", "duplicate", "delete", "favorite"] {
                    let action = window.find((id, 0_usize));
                    assert!(action.visible(), "{id} hidden at {width}");
                    assert!(
                        contained(action.bounds(), row),
                        "{id} escaped {width}: {:?}",
                        action.bounds()
                    );
                }
            }
            window.click(("edit", 0_usize), cx);
            assert_eq!(
                fixture
                    .workspace
                    .read(cx)
                    .form
                    .as_ref()
                    .checked_option("real profile editor")
                    .id,
                Some(fixture.workspace.read(cx).state.connections[0].id)
            );
            window.click("cancel-connection", cx);
            fixture.workspace.update(cx, |workspace, cx| {
                workspace.show_connections = true;
                cx.notify();
            });
            for language in [Language::ZhCn, Language::En] {
                i18n::set_language(language, cx);
                window.render_frame(cx);
                let dialog = window.find("connection-manager-dialog").bounds();
                assert!(contained(dialog, window.bounds()));
                let manager = window.within("connection-manager-dialog");
                let row = manager.find(("connection-row", 0_usize)).bounds();
                assert!(contained(row, dialog));
                for id in [
                    "connect",
                    "edit",
                    "move",
                    "duplicate",
                    "delete",
                    "favorite",
                    "connection-name",
                    "connection-endpoint",
                ] {
                    let control = manager.find((id, 0_usize));
                    assert!(control.visible(), "manager {id} hidden at {width}");
                    assert!(contained(control.bounds(), row));
                }
            }
            window
                .within("connection-manager-dialog")
                .click(("edit", 0_usize), cx);
            assert!(fixture.workspace.read(cx).form.is_some());
            window.click("cancel-connection", cx);
            i18n::set_language(Language::ZhCn, cx);
        })
        .checked("compact production library with assistant and real edit action");
    }
}

#[gpui_kit::test]
fn compact_library_keeps_full_surface_inside_narrow_theme_language_height_matrix(
    cx: &mut TestAppContext,
) {
    for height in [580., 900.] {
        let fixture = mount_sized(
            cx,
            (0..12)
                .map(|index| {
                    Connection::new(
                        format!("审核主机 {index}"),
                        format!("192.0.2.{}", index + 10),
                        "operator",
                    )
                })
                .collect(),
            480.,
            height,
        );
        let mut clicked_scrolled_action = false;
        cx.update_window(fixture.window, |_, window, cx| {
            fixture.workspace.update(cx, |workspace, cx| {
                workspace.show_connections = true;
                cx.notify();
            });
            for definition in crate::design::registry() {
                for appearance in [Theme::Light, Theme::Dark] {
                    for language in [Language::ZhCn, Language::En] {
                        i18n::set_language(language, cx);
                        fixture.workspace.update(cx, |workspace, cx| {
                            workspace.state.settings.theme_family =
                                keelshell_core::ThemeId::new(definition.id)
                                    .checked("valid theme family");
                            workspace.state.settings.theme = appearance;
                            let settings = workspace.state.settings.clone();
                            crate::design::apply_settings(&settings, Some(window), cx);
                            cx.notify();
                        });
                        window.render_frame(cx);

                        let scene = format!(
                            "480x{height}/{}/{appearance:?}/{language:?}",
                            definition.id
                        );
                        let dialog = window.find("connection-manager-dialog");
                        assert!(
                            dialog.visible() && contained(dialog.bounds(), window.bounds()),
                            "{scene}: manager escaped window: {:?}",
                            dialog.bounds()
                        );
                        let dialog_bounds = dialog.bounds();
                        let mut manager = window.within("connection-manager-dialog");
                        for id in [
                            "close-manager",
                            "library-filter-summary",
                            "library-actions-toolbar",
                            "connection-folders",
                            "connection-table-scroll",
                            "connection-rows",
                        ] {
                            let element = manager.find(id);
                            assert!(element.visible(), "{scene}: {id} is hidden");
                            assert!(
                                contained(element.bounds(), dialog_bounds),
                                "{scene}: {id} escaped manager: {:?}",
                                element.bounds()
                            );
                        }

                        assert_eq!(
                            manager.find("connection-rows").role(),
                            Some(gpui_kit::Role::List),
                            "{scene}: connection list role"
                        );
                        let row = manager.find(("connection-row", 0_usize));
                        let rows = manager.find("connection-rows").bounds();
                        assert!(
                            row.visible() && contained(row.bounds(), rows),
                            "{scene}: first profile row is outside the scroll viewport: {:?} in {rows:?}",
                            row.bounds()
                        );
                        for id in [
                            "library-select",
                            "favorite",
                            "connection-name",
                            "connection-endpoint",
                            "connection-actions",
                            "connect",
                            "edit",
                            "move",
                            "duplicate",
                            "delete",
                        ] {
                            let element = manager.find((id, 0_usize));
                            assert!(element.visible(), "{scene}: {id} is hidden");
                            assert!(
                                contained(element.bounds(), row.bounds()),
                                "{scene}: {id} escaped row: {:?} in {:?}",
                                element.bounds(),
                                row.bounds()
                            );
                        }

                        manager.scroll(
                            "connection-rows",
                            ScrollDelta::Pixels(point(px(0.), px(-100_000.))),
                            cx,
                        );
                        let last_index = 11_usize;
                        let last_row = manager.find(("connection-row", last_index));
                        let rows = manager.find("connection-rows").bounds();
                        assert!(
                            last_row.visible() && contained(last_row.bounds(), rows),
                            "{scene}: last profile row is not reachable after scrolling: {:?} in {rows:?}",
                            last_row.bounds()
                        );
                        for id in [
                            "library-select",
                            "favorite",
                            "connection-name",
                            "connection-endpoint",
                            "connection-actions",
                            "connect",
                            "edit",
                            "move",
                            "duplicate",
                            "delete",
                        ] {
                            let element = manager.find((id, last_index));
                            assert!(element.visible(), "{scene}: last {id} is hidden");
                            assert!(
                                contained(element.bounds(), last_row.bounds()),
                                "{scene}: last {id} escaped row: {:?} in {:?}",
                                element.bounds(),
                                last_row.bounds()
                            );
                        }
                        let opened_editor = if !clicked_scrolled_action {
                            manager.click(("edit", last_index), cx);
                            assert!(
                                fixture.workspace.read(cx).form.is_some(),
                                "{scene}: last-row edit action did not open the real editor"
                            );
                            clicked_scrolled_action = true;
                            true
                        } else {
                            false
                        };
                        drop(manager);
                        if opened_editor {
                            window.click("cancel-connection", cx);
                            window.render_frame(cx);
                        }
                        let mut manager = window.within("connection-manager-dialog");
                        manager.scroll(
                            "connection-rows",
                            ScrollDelta::Pixels(point(px(0.), px(100_000.))),
                            cx,
                        );
                        window.render_frame(cx);
                    }
                }
            }
            i18n::set_language(Language::ZhCn, cx);
            fixture.workspace.update(cx, |workspace, cx| {
                workspace.state.settings.theme_family =
                    keelshell_core::ThemeId::default();
                workspace.state.settings.theme = Theme::Light;
                let settings = workspace.state.settings.clone();
                crate::design::apply_settings(&settings, Some(window), cx);
                cx.notify();
            });
        })
        .checked("keep the complete narrow connection library surface inside the window");
    }
}

#[gpui_kit::test]
async fn painted_library_edit_uses_current_profile_after_same_id_replacement(
    cx: &mut TestAppContext,
) {
    let original = Connection::new("旧配置", "old.invalid", "old-user");
    let id = original.id;
    let fixture = mount(cx, vec![original.clone()]);
    let position = cx
        .update_window(fixture.window, |_, window, cx| {
            fixture.workspace.update(cx, |workspace, cx| {
                workspace.show_connections = true;
                cx.notify();
            });
            window.render_frame(cx);
            window.find(("edit", 0_usize)).bounds().center()
        })
        .checked("paint the original library edit action");

    let mut replacement = original.clone();
    replacement.name = "当前配置".into();
    replacement.host = "current.invalid".into();
    replacement.port = 2222;
    replacement.username = "current-user".into();
    let mut replacement_state = fixture.store.load().checked("load original library state");
    replacement_state.connections[0] = replacement.clone();
    persist_fixture_state_without_repaint(
        &fixture,
        replacement_state,
        "persist same-id profile replacement",
        cx,
    );

    cx.update_window(fixture.window, |_, window, cx| {
        click_painted_library_position(position, window, cx);
        fixture.workspace.read_with(cx, |workspace, cx| {
            let form = workspace
                .form
                .as_ref()
                .checked_option("current profile editor");
            assert_eq!(form.id, Some(id));
            assert_eq!(form.host.read(cx).value(), "current.invalid");
            assert_eq!(form.port.read(cx).value(), "2222");
            assert_eq!(form.username.read(cx).value(), "current-user");
        });
        window.render_frame(cx);
        window.click("save-connection", cx);
    })
    .checked("route painted edit through the current profile");
    saved(&fixture, cx).await;

    let state = fixture
        .store
        .load()
        .checked("load current profile after edit");
    let persisted = state
        .connections
        .iter()
        .find(|connection| connection.id == id)
        .checked_option("persisted replacement profile");
    assert_eq!(persisted.host, "current.invalid");
    assert_eq!(persisted.port, 2222);
    assert_eq!(persisted.username, "current-user");
}

#[gpui_kit::test]
async fn painted_library_edit_cannot_resurrect_removed_profile(cx: &mut TestAppContext) {
    let original = Connection::new("待移除配置", "removed.invalid", "operator");
    let id = original.id;
    let fixture = mount(cx, vec![original]);
    let position = cx
        .update_window(fixture.window, |_, window, cx| {
            fixture.workspace.update(cx, |workspace, cx| {
                workspace.show_connections = true;
                cx.notify();
            });
            window.render_frame(cx);
            window.find(("edit", 0_usize)).bounds().center()
        })
        .checked("paint the removable library edit action");

    let mut removed_state = fixture.store.load().checked("load removable library state");
    removed_state.connections.clear();
    persist_fixture_state_without_repaint(&fixture, removed_state, "persist profile removal", cx);

    cx.update_window(fixture.window, |_, window, cx| {
        click_painted_library_position(position, window, cx);
        fixture.workspace.read_with(cx, |workspace, cx| {
            assert!(workspace.form.is_none());
            assert_eq!(workspace.status.render(cx), "连接已移除，请重新选择。");
        });
        fixture.workspace.update(cx, |workspace, cx| {
            workspace.save_connection(window, cx);
        });
    })
    .checked("reject the stale removed-profile edit before saving");
    saved(&fixture, cx).await;

    assert!(
        fixture
            .store
            .load()
            .checked("load library after rejected stale edit")
            .connections
            .is_empty()
    );
    let active = fixture.workspace.read_with(cx, |workspace, _| {
        workspace
            .state
            .connections
            .iter()
            .filter(|connection| connection.id == id)
            .count()
    });
    assert_eq!(active, 0);
}

#[gpui_kit::test]
fn compact_library_exposes_bilingual_toolbar_and_batch_semantics(cx: &mut TestAppContext) {
    let fixture = mount_sized(
        cx,
        vec![Connection::new("审核主机", "192.0.2.10", "operator")],
        480.,
        580.,
    );
    cx.update_window(fixture.window, |_, _, cx| {
        fixture.workspace.update(cx, |workspace, cx| {
            workspace.show_connections = true;
            cx.notify();
        });
    })
    .checked("bilingual compact toolbar and batch semantics");
    for language in [Language::ZhCn, Language::En] {
        let actions = match language {
            Language::ZhCn => [
                ("new-connection", "新建连接"),
                ("import-connections", "导入 JSON"),
                ("import-openssh", "从剪贴板导入 SSH 配置"),
                ("profile-sync-open", "加密同步"),
                ("export-connections", "导出 JSON"),
            ],
            Language::En => [
                ("new-connection", "New connection"),
                ("import-connections", "Import JSON"),
                ("import-openssh", "Import SSH config from clipboard"),
                ("profile-sync-open", "Encrypted sync"),
                ("export-connections", "Export JSON"),
            ],
        };
        let batch_bounds = cx
            .update_window(fixture.window, |_, window, cx| {
                i18n::set_language(language, cx);
                window.render_frame(cx);
                let manager = window.within("connection-manager-dialog");
                let toolbar = manager.find("library-actions-toolbar");
                let batch = manager.find("library-bulk-toolbar");
                assert_eq!(
                    toolbar.role(),
                    Some(gpui_kit::Role::Group),
                    "{language:?}: connection toolbar role"
                );
                assert_eq!(
                    batch.role(),
                    Some(gpui_kit::Role::Group),
                    "{language:?}: batch toolbar role"
                );
                assert_eq!(
                    toolbar.label(),
                    Some(match language {
                        Language::ZhCn => "连接库操作",
                        Language::En => "Connection library actions",
                    }),
                    "{language:?}: connection toolbar label"
                );
                assert_eq!(
                    batch.label(),
                    Some(match language {
                        Language::ZhCn => "连接批量操作",
                        Language::En => "Connection bulk actions",
                    }),
                    "{language:?}: batch toolbar label"
                );
                for &(id, label) in &actions {
                    let button = manager.find(id);
                    assert!(
                        button.visible() && contained(button.bounds(), toolbar.bounds()),
                        "{language:?}: {id} escaped compact toolbar: {:?} in {:?}",
                        button.bounds(),
                        toolbar.bounds()
                    );
                    assert_eq!(
                        button.label(),
                        Some(label),
                        "{language:?}: {id} accessibility label"
                    );
                }
                assert!(
                    contained(
                        manager.find("library-clear-selection").bounds(),
                        batch.bounds()
                    ),
                    "{language:?}: clear selection escaped batch toolbar"
                );
                batch.bounds()
            })
            .checked("render bilingual compact connection toolbars");
        cx.update_window(fixture.window, |_, window, cx| {
            window.click(("library-select", 0_usize), cx);
        })
        .checked("select one compact connection for batch actions");
        cx.update_window(fixture.window, |_, window, cx| {
            window.render_frame(cx);
            let manager = window.within("connection-manager-dialog");
            let bulk_move = manager.find("library-bulk-move");
            assert!(
                bulk_move.visible() && contained(bulk_move.bounds(), batch_bounds),
                "{language:?}: compact batch move action is not reachable"
            );
            assert_eq!(
                bulk_move.label(),
                Some(match language {
                    Language::ZhCn => "移动所选连接",
                    Language::En => "Move selected profiles",
                })
            );
        })
        .checked("inspect compact batch action semantics");
        cx.update_window(fixture.window, |_, window, cx| {
            window.click("library-clear-selection", cx);
        })
        .checked("clear compact connection selection");
    }
    cx.update(|cx| i18n::set_language(Language::ZhCn, cx));
}

#[gpui_kit::test]
fn connection_actions_distinguish_same_names_by_complete_endpoint_in_both_languages(
    cx: &mut TestAppContext,
) {
    let mut first = Connection::new("同名连接", "192.0.2.10", "operator");
    first.favorite = true;
    let mut second = Connection::new("同名连接", "2001:db8::10", "deploy");
    second.port = 2222;
    let deleted_id = second.id;
    let fixture = mount(cx, vec![first, second]);
    cx.update_window(fixture.window, |_, window, cx| {
        for language in [Language::ZhCn, Language::En] {
            i18n::set_language(language, cx);
            window.render_frame(cx);
            for (index, endpoint, favorite) in [
                (0_usize, "operator@192.0.2.10:22", true),
                (1_usize, "deploy@[2001:db8::10]:2222", false),
            ] {
                let target = format!("同名连接 · {endpoint}");
                assert_eq!(
                    window.find(("connection-row", index)).label(),
                    Some(target.as_str())
                );
                assert_eq!(
                    window.find(("connection-row", index)).role(),
                    Some(gpui_kit::Role::ListItem)
                );
                let actions = if language == Language::En {
                    [
                        ("connect", "Connect"),
                        ("edit", "Edit"),
                        ("move", "Move"),
                        ("duplicate", "Copy"),
                        ("delete", "Trash"),
                        (
                            "favorite",
                            if favorite {
                                "Remove from favorites"
                            } else {
                                "Add to favorites"
                            },
                        ),
                    ]
                } else {
                    [
                        ("connect", "连接"),
                        ("edit", "编辑"),
                        ("move", "移动"),
                        ("duplicate", "复制"),
                        ("delete", "移入回收站"),
                        (
                            "favorite",
                            if favorite {
                                "取消收藏"
                            } else {
                                "添加收藏"
                            },
                        ),
                    ]
                };
                for (id, action) in actions {
                    let expected = format!("{action}: 同名连接 · {endpoint}");
                    assert_eq!(window.find((id, index)).label(), Some(expected.as_str()));
                }
            }
        }
        fixture.workspace.update(cx, |workspace, cx| {
            workspace
                .state
                .soft_delete_connection(deleted_id, 1)
                .checked("trash synthetic profile");
            workspace.library_filter = LibraryFilter::Trash;
            cx.notify();
        });
        for (language, action) in [(Language::ZhCn, "恢复"), (Language::En, "Restore")] {
            i18n::set_language(language, cx);
            window.render_frame(cx);
            let expected = format!("{action}: 同名连接 · deploy@[2001:db8::10]:2222");
            assert_eq!(
                window.find(("restore", 0_usize)).label(),
                Some(expected.as_str())
            );
            assert!(window.try_find(("connect", 0_usize)).is_none());
        }
        i18n::set_language(Language::ZhCn, cx);
    })
    .checked("assert production control names for active and recoverable SSH profiles");
}

#[gpui_kit::test]
fn selected_library_row_exposes_state_and_keeps_primary_action_reachable(cx: &mut TestAppContext) {
    for width in [1440., 720.] {
        let profile = Connection::new("已选主机", "selected.invalid", "operator");
        let id = profile.id;
        let fixture = mount_sized(cx, vec![profile], width, 720.);
        cx.update_window(fixture.window, |_, window, cx| {
            fixture.workspace.update(cx, |workspace, cx| {
                workspace.show_connections = true;
                workspace.library_selection.insert(id);
                cx.notify();
            });
            for (language, selected_label, unselected_label) in [
                (
                    Language::ZhCn,
                    "取消选择: 已选主机 · operator@selected.invalid:22",
                    "选择连接: 已选主机 · operator@selected.invalid:22",
                ),
                (
                    Language::En,
                    "Deselect: 已选主机 · operator@selected.invalid:22",
                    "Select profile: 已选主机 · operator@selected.invalid:22",
                ),
            ] {
                i18n::set_language(language, cx);
                window.render_frame(cx);

                {
                    let manager = window.within("connection-manager-dialog");
                    assert_eq!(
                        manager.find("connection-rows").role(),
                        Some(gpui_kit::Role::List),
                        "connection list role at width {width} and {language:?}"
                    );
                    let row = manager.find(("connection-row", 0_usize));
                    assert_eq!(
                        row.role(),
                        Some(gpui_kit::Role::ListItem),
                        "connection item role at width {width} and {language:?}"
                    );
                    assert_eq!(row.selected(), Some(true), "selected row at width {width}");
                    assert_eq!(
                        manager.find(("library-select", 0_usize)).label(),
                        Some(selected_label),
                        "selected action label at width {width} and {language:?}"
                    );
                    let connect = manager.find(("connect", 0_usize));
                    assert!(connect.visible());
                    assert!(
                        contained(connect.bounds(), row.bounds()),
                        "connect escaped selected row at width {width}: {:?}",
                        connect.bounds()
                    );
                }

                window.click(("library-select", 0_usize), cx);
                window.render_frame(cx);
                let manager = window.within("connection-manager-dialog");
                assert_eq!(
                    manager.find(("connection-row", 0_usize)).selected(),
                    Some(false),
                    "deselected row at width {width} and {language:?}"
                );
                assert_eq!(
                    manager.find(("library-select", 0_usize)).label(),
                    Some(unselected_label),
                    "unselected action label at width {width} and {language:?}"
                );

                window.click(("library-select", 0_usize), cx);
            }
            i18n::set_language(Language::ZhCn, cx);
        })
        .checked("preserve selected-row semantics across wide and compact layouts");
    }
}

#[gpui_kit::test]
fn library_summary_exposes_filter_query_and_selection_in_both_languages(cx: &mut TestAppContext) {
    let mut favorite = Connection::new("收藏主机", "favorite.invalid", "operator");
    favorite.favorite = true;
    let other = Connection::new("普通主机", "other.invalid", "operator");
    let fixture = mount(cx, vec![favorite, other]);
    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |workspace, cx| {
            workspace.show_connections = true;
            cx.notify();
        });
        for language in [Language::ZhCn, Language::En] {
            i18n::set_language(language, cx);
            fixture.workspace.update(cx, |workspace, cx| {
                workspace.set_library_filter(LibraryFilter::All, cx);
                workspace.library_selection.clear();
                workspace.search.update(cx, |input, cx| {
                    input.set_value("", window, cx);
                });
            });
            window.render_frame(cx);
            assert_eq!(
                window.find("library-scope-title").label(),
                Some(if language == Language::ZhCn {
                    "全部连接"
                } else {
                    "All connections"
                })
            );
            assert_eq!(
                window.find("library-filter-count").label(),
                Some(if language == Language::ZhCn {
                    "2 / 2 个连接"
                } else {
                    "2 / 2 profiles"
                })
            );

            window.click("favorite-connections", cx);
            window.render_frame(cx);
            assert_eq!(
                window.find("library-scope-title").label(),
                Some(if language == Language::ZhCn {
                    "收藏"
                } else {
                    "Favorites"
                })
            );
            assert_eq!(
                window.find("library-filter-count").label(),
                Some(if language == Language::ZhCn {
                    "1 / 1 个连接"
                } else {
                    "1 / 1 profiles"
                })
            );
            assert_eq!(
                fixture.workspace.read(cx).library_filter,
                LibraryFilter::Favorites
            );

            window.click(("library-select", 0_usize), cx);
            window.render_frame(cx);
            assert_eq!(
                window.find("library-selection-count").label(),
                Some(if language == Language::ZhCn {
                    "1 个连接已选择"
                } else {
                    "1 profiles selected"
                })
            );

            fixture.workspace.update(cx, |workspace, cx| {
                workspace.search.update(cx, |input, cx| {
                    input.set_value("does-not-exist", window, cx);
                });
            });
            window.render_frame(cx);
            assert!(window.find("library-query-summary").visible());
            assert!(window.find("library-clear-filter").visible());
            assert!(window.find("library-empty-state").visible());
            assert_eq!(
                window.find("library-empty-title").label(),
                Some(if language == Language::ZhCn {
                    "没有匹配的连接"
                } else {
                    "No matching profiles"
                })
            );
            window.click("library-empty-clear-filter", cx);
            window.render_frame(cx);
            assert!(
                fixture
                    .workspace
                    .read(cx)
                    .search
                    .read(cx)
                    .value()
                    .is_empty()
            );
            assert!(window.try_find("library-empty-state").is_none());
        }
        i18n::set_language(Language::ZhCn, cx);
    })
    .checked("render library scope, query and explicit selection semantics");
}

#[gpui_kit::test]
fn library_empty_state_is_theme_neutral_bilingual_and_actionable(cx: &mut TestAppContext) {
    let fixture = mount_sized(cx, Vec::new(), 720., 600.);
    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |workspace, cx| {
            workspace.show_connections = true;
            cx.notify();
        });
        for theme in crate::design::registry() {
            fixture.workspace.update(cx, |workspace, cx| {
                workspace.state.settings.theme_family =
                    keelshell_core::ThemeId::new(theme.id).checked("valid theme family");
                workspace.state.settings.theme = Theme::Light;
                let settings = workspace.state.settings.clone();
                crate::design::apply_settings(&settings, Some(window), cx);
                cx.notify();
            });
            for language in [Language::ZhCn, Language::En] {
                i18n::set_language(language, cx);
                window.render_frame(cx);
                let manager = window.find("connection-manager-dialog").bounds();
                let empty = window.find("library-empty-state");
                assert!(empty.visible());
                assert!(contained(empty.bounds(), manager));
                assert!(window.find("library-empty-card").visible());
                assert!(window.find("library-scope-icon").visible());
                assert!(window.find("library-empty-new-connection").visible());
                assert_eq!(
                    window.find("library-empty-title").label(),
                    Some(if language == Language::ZhCn {
                        "还没有连接配置"
                    } else {
                        "No saved profiles"
                    })
                );
            }
        }
        window.click("library-empty-new-connection", cx);
        assert!(fixture.workspace.read(cx).form.is_some());
        window.click("cancel-connection", cx);
        i18n::set_language(Language::ZhCn, cx);
    })
    .checked("render actionable empty state across registered themes and languages");
}

async fn saved(fixture: &Fixture, cx: &mut TestAppContext) {
    cx.wait_for(fixture.window, Duration::from_secs(5), |_, cx| {
        !fixture.workspace.read(cx).saving
    })
    .await;
}

fn create_folder(fixture: &Fixture, name: &str, cx: &mut TestAppContext) {
    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        window.click("new-folder", cx);
        let input = fixture
            .workspace
            .read(cx)
            .folder_form
            .as_ref()
            .checked_option("folder editor")
            .name
            .entity_id();
        window.click(("input", input), cx);
        window.input(name, cx);
        window.click("save-folder", cx);
    })
    .checked("create folder using real controls");
}

#[gpui_kit::test]
async fn folders_move_trash_restore_and_rename_persist_through_real_controls(
    cx: &mut TestAppContext,
) {
    let profile = Connection::new("生产主机", "node.invalid", "operator");
    let id = profile.id;
    let fixture = mount(cx, vec![profile]);
    create_folder(&fixture, "研发", cx);
    saved(&fixture, cx).await;
    let root = fixture
        .workspace
        .read_with(cx, |view, _| view.state.folders[0].id);
    create_folder(&fixture, "应用", cx);
    saved(&fixture, cx).await;
    let child = fixture.workspace.read_with(cx, |view, _| {
        view.state
            .folders
            .iter()
            .find(|folder| folder.parent_id == Some(root))
            .checked_option("child folder")
            .id
    });
    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        window.click("all-connections", cx);
        window.render_frame(cx);
        window.click(("move", 0_usize), cx);
        window.render_frame(cx);
        window.click(("destination-folder", 1_usize), cx);
        window.click("save-destination", cx);
    })
    .checked("move profile to nested destination");
    saved(&fixture, cx).await;
    let state = fixture.store.load().checked("load saved membership");
    assert_eq!(state.folder_id_of(id), Some(child));
    assert_eq!(state.connections[0].group, "研发/应用");
    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        window.click(("delete", 0_usize), cx);
    })
    .checked("move profile to trash");
    saved(&fixture, cx).await;
    let state = fixture.store.load().checked("load persistent trash");
    assert!(state.connections.is_empty());
    assert_eq!(state.deleted_connections[0].connection.id, id);
    assert_eq!(state.folder_id_of(id), Some(child));
    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        window.click("trashed-connections", cx);
        window.render_frame(cx);
        assert!(window.try_find(("connect", 0_usize)).is_none());
        window.click(("restore", 0_usize), cx);
    })
    .checked("restore without a connect action in trash");
    saved(&fixture, cx).await;
    let state = fixture.store.load().checked("load restored profile");
    assert_eq!(state.connections[0].id, id);
    assert!(state.deleted_connections.is_empty());
    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        window.click(("manage-folder", 0_usize), cx);
        window.render_frame(cx);
        fixture.workspace.update(cx, |view, cx| {
            view.folder_form
                .as_ref()
                .checked_option("folder editor")
                .name
                .update(cx, |input, cx| input.set_value("运维", window, cx));
        });
        window.click("save-folder", cx);
    })
    .checked("rename ancestor folder");
    saved(&fixture, cx).await;
    let state = fixture.store.load().checked("load renamed tree");
    assert_eq!(state.folder_path(child).as_deref(), Some("运维/应用"));
    assert_eq!(state.connections[0].group, "运维/应用");
}

#[gpui_kit::test]
async fn folder_cycle_and_nonempty_delete_keep_draft_and_existing_tree(cx: &mut TestAppContext) {
    let fixture = mount(cx, Vec::new());
    create_folder(&fixture, "父目录", cx);
    saved(&fixture, cx).await;
    create_folder(&fixture, "子目录", cx);
    saved(&fixture, cx).await;
    let before = fixture.store.load().checked("load original tree");
    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        window.click(("manage-folder", 0_usize), cx);
        window.render_frame(cx);
        window.click("remove-empty-folder", cx);
        window.render_frame(cx);
        let view = fixture.workspace.read(cx);
        assert!(!view.saving);
        assert!(
            view.folder_form
                .as_ref()
                .checked_option("retained folder editor")
                .message
                .is_some()
        );
        window.click(("folder-parent", 1_usize), cx);
        window.click("save-folder", cx);
        window.render_frame(cx);
        let view = fixture.workspace.read(cx);
        assert!(!view.saving);
        assert!(
            view.folder_form
                .as_ref()
                .checked_option("cycle rejected")
                .message
                .is_some()
        );
    })
    .checked("refuse nonempty delete and ancestor cycle");
    assert_eq!(
        fixture
            .store
            .load()
            .checked("compare tree after failed mutations"),
        before
    );
}

#[gpui_kit::test]
async fn recent_success_queues_behind_save_without_losing_metadata_and_filters(
    cx: &mut TestAppContext,
) {
    let profile = Connection::new("最近主机", "recent.invalid", "operator");
    let id = profile.id;
    let fixture = mount(cx, vec![profile]);
    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |view, cx| {
            view.toggle_favorite(id, window, cx);
            assert!(view.saving);
            view.remember_successful_connection(view.state.connections[0].clone(), window, cx);
            assert_eq!(view.pending_recents.len(), 1);
            assert!(view.state.recent_connections.is_empty());
        });
    })
    .checked("queue successful usage behind favorite write");
    saved(&fixture, cx).await;
    let state = fixture.store.load().checked("load both serialized updates");
    assert!(state.connections[0].favorite);
    assert_eq!(state.recent_connections.len(), 1);
    assert_eq!(state.recent_connections[0].connection_id, id);
    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        window.click("recent-connections", cx);
        window.render_frame(cx);
        assert!(window.try_find(("connect", 0_usize)).is_some());
        window.click(("delete", 0_usize), cx);
    })
    .checked("trash recently connected profile");
    saved(&fixture, cx).await;
    assert!(
        fixture
            .store
            .load()
            .checked("recent removed on trash")
            .recent_connections
            .is_empty()
    );
}

#[gpui_kit::test]
async fn tags_and_folder_selection_save_with_profile_and_language_keeps_drafts(
    cx: &mut TestAppContext,
) {
    let profile = Connection::new("标签主机", "tags.invalid", "operator");
    let id = profile.id;
    let fixture = mount(cx, vec![profile]);
    create_folder(&fixture, "服务", cx);
    saved(&fixture, cx).await;
    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        window.click("all-connections", cx);
        window.render_frame(cx);
        window.click(("edit", 0_usize), cx);
        fixture.workspace.update(cx, |view, cx| {
            let form = view.form.as_ref().checked_option("profile editor");
            form.tags
                .update(cx, |input, cx| input.set_value("生产, API", window, cx));
            view.open_destination(DestinationTarget::Draft, window, cx);
        });
        window.render_frame(cx);
        window.click(("destination-folder", 0_usize), cx);
        window.click("save-destination", cx);
        fixture
            .workspace
            .update(cx, |view, cx| view.switch_language(window, cx));
    })
    .checked("select draft folder and change locale");
    saved(&fixture, cx).await;
    cx.update_window(fixture.window, |_, window, cx| {
        let form = fixture
            .workspace
            .read(cx)
            .form
            .as_ref()
            .checked_option("draft survived language switch");
        assert_eq!(form.tags.read(cx).value(), "生产, API");
        assert!(form.folder_id.is_some());
        window.render_frame(cx);
        window.click("save-connection", cx);
    })
    .checked("save bilingual profile editor");
    saved(&fixture, cx).await;
    let state = fixture.store.load().checked("load folder and tags");
    assert_eq!(state.connections[0].tags, ["生产", "API"]);
    assert_eq!(state.folder_id_of(id), Some(state.folders[0].id));
}

#[gpui_kit::test]
fn destination_picker_focus_never_sends_keys_to_ssh(cx: &mut TestAppContext) {
    let profile = Connection::new("选择目标", "focus.invalid", "operator");
    let id = profile.id;
    let fixture = mount(cx, vec![profile]);
    let panes = attach_remote_panes(&fixture, cx);
    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |view, cx| {
            view.open_destination(DestinationTarget::Connection(id), window, cx)
        });
        window.render_frame(cx);
        window.input("must-not-reach-ssh", cx);
        window.press("enter", cx);
        window.render_frame(cx);
    })
    .checked("type while destination picker owns focus");
    cx.run_until_parked();
    for pane in &panes {
        assert!(writes(pane).is_empty());
    }
    fixture.workspace.read_with(cx, |view, _| {
        assert!(view.destination_prompt.is_some());
        assert_eq!(view.library_filter, LibraryFilter::All);
    });
}

#[gpui_kit::test]
async fn empty_folder_import_is_persisted_even_without_new_connections(cx: &mut TestAppContext) {
    let fixture = mount(cx, Vec::new());
    let mut incoming = AppState::default();
    let root = incoming
        .create_folder("导入的空目录", None)
        .checked("create imported root");
    incoming
        .create_folder("空子目录", Some(root))
        .checked("create imported child");
    let document = incoming
        .export_connections()
        .checked("export empty directory tree");
    cx.update_window(fixture.window, |_, window, cx| {
        cx.write_to_clipboard(ClipboardItem::new_string(document));
        window.render_frame(cx);
        window.click("import-connections", cx);
    })
    .checked("import empty folders with production button");
    saved(&fixture, cx).await;
    let state = fixture.store.load().checked("load imported empty folders");
    assert!(state.connections.is_empty());
    assert_eq!(state.folders.len(), 2);
    assert!(
        state
            .folders
            .iter()
            .any(|folder| state.folder_path(folder.id).as_deref() == Some("导入的空目录/空子目录"))
    );
}

#[gpui_kit::test]
async fn delayed_recent_write_rechecks_destination_after_profile_edit(cx: &mut TestAppContext) {
    let profile = Connection::new("旧目标", "old.invalid", "operator");
    let fixture = mount(cx, vec![profile.clone()]);
    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |view, cx| {
            let mut changed = view.state.clone();
            changed.connections[0].host = "new.invalid".into();
            view.persist(changed, crate::workspace::AfterSave::None, window, cx);
            view.remember_successful_connection(profile.clone(), window, cx);
            assert_eq!(view.pending_recents.len(), 1);
        });
    })
    .checked("success of old destination arrives during changed-target save");
    saved(&fixture, cx).await;
    let state = fixture.store.load().checked("load changed destination");
    assert_eq!(state.connections[0].host, "new.invalid");
    assert!(state.recent_connections.is_empty());
    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |view, cx| {
            view.remember_successful_connection(profile, window, cx)
        });
    })
    .checked("reject stale success before queue admission");
    fixture.workspace.read_with(cx, |view, _| {
        assert!(!view.saving);
        assert!(view.pending_recents.is_empty());
    });
}

#[gpui_kit::test]
async fn saving_profile_with_manager_open_restores_manager_focus(cx: &mut TestAppContext) {
    let profile = Connection::new("管理器", "manager.invalid", "operator");
    let fixture = mount(cx, vec![profile.clone()]);
    let panes = attach_remote_panes(&fixture, cx);
    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |view, cx| {
            view.show_connections = true;
            view.edit_connection(profile, window, cx);
        });
        window.render_frame(cx);
        window.click("save-connection", cx);
    })
    .checked("save profile while manager occludes the SSH terminal");
    saved(&fixture, cx).await;
    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        assert!(
            fixture
                .workspace
                .read(cx)
                .search
                .read(cx)
                .focus_handle(cx)
                .is_focused(window)
        );
        window.input("manager-search", cx);
    })
    .checked("subsequent keys belong to manager search");
    cx.run_until_parked();
    assert!(writes(&panes[0]).is_empty());
    assert!(writes(&panes[1]).is_empty());
}

#[gpui_kit::test]
async fn profile_metadata_keeps_recent_but_destination_change_clears_it(cx: &mut TestAppContext) {
    let profile = Connection::new("已连接", "old.invalid", "operator");
    let fixture = mount(cx, vec![profile.clone()]);
    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |view, cx| {
            view.remember_successful_connection(profile.clone(), window, cx);
        });
    })
    .checked("record prior successful destination");
    saved(&fixture, cx).await;
    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |view, cx| {
            view.edit_connection(profile, window, cx);
            view.form
                .as_ref()
                .checked_option("profile editor")
                .name
                .update(cx, |input, cx| input.set_value("新名称", window, cx));
        });
        window.render_frame(cx);
        window.click("save-connection", cx);
    })
    .checked("rename profile without changing destination");
    saved(&fixture, cx).await;
    assert_eq!(
        fixture
            .store
            .load()
            .checked("renamed profile")
            .recent_connections
            .len(),
        1
    );
    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |view, cx| {
            view.edit_connection(view.state.connections[0].clone(), window, cx);
            view.form
                .as_ref()
                .checked_option("profile editor")
                .host
                .update(cx, |input, cx| input.set_value("new.invalid", window, cx));
        });
        window.render_frame(cx);
        window.click("save-connection", cx);
    })
    .checked("change profile destination");
    saved(&fixture, cx).await;
    assert!(
        fixture
            .store
            .load()
            .checked("changed profile")
            .recent_connections
            .is_empty()
    );
}

#[gpui_kit::test]
fn closing_profile_and_manager_restore_visible_keyboard_target(cx: &mut TestAppContext) {
    let profile = Connection::new("管理器焦点", "focus.invalid", "operator");
    let fixture = mount(cx, vec![profile.clone()]);
    let panes = attach_remote_panes(&fixture, cx);
    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |view, cx| {
            view.show_connections = true;
            view.edit_connection(profile, window, cx);
            view.close_tab(&crate::workspace::CloseTab, window, cx);
        });
        window.render_frame(cx);
        assert!(
            fixture
                .workspace
                .read(cx)
                .search
                .read(cx)
                .focus_handle(cx)
                .is_focused(window)
        );
        window.input("search", cx);
        window.click("close-manager", cx);
        assert!(
            panes[0]
                .terminal
                .read(cx)
                .focus_handle(cx)
                .is_focused(window)
        );
        window.input("ssh", cx);
    })
    .checked("close layers and restore the newly exposed input");
    cx.run_until_parked();
    assert_eq!(writes(&panes[0]), b"ssh");
    assert!(writes(&panes[1]).is_empty());
}

struct DelayedShell {
    gate: Arc<tokio::sync::Notify>,
    authenticating: Arc<AtomicBool>,
    received: Arc<std::sync::atomic::AtomicUsize>,
    channels: std::collections::HashMap<russh::ChannelId, russh::Channel<russh::server::Msg>>,
    jobs: tokio::task::JoinSet<()>,
}
impl russh::server::Handler for DelayedShell {
    type Error = russh::Error;
    async fn auth_password(
        &mut self,
        user: &str,
        password: &str,
    ) -> Result<russh::server::Auth, Self::Error> {
        self.authenticating
            .store(true, std::sync::atomic::Ordering::Release);
        self.gate.notified().await;
        Ok(
            if user == "fixture-user" && password == "delayed-test-password" {
                russh::server::Auth::Accept
            } else {
                russh::server::Auth::reject()
            },
        )
    }
    async fn channel_open_session(
        &mut self,
        channel: russh::Channel<russh::server::Msg>,
        reply: russh::server::ChannelOpenHandle,
        _: &mut russh::server::Session,
    ) -> Result<(), Self::Error> {
        self.channels.insert(channel.id(), channel);
        reply.accept().await;
        Ok(())
    }
    async fn pty_request(
        &mut self,
        id: russh::ChannelId,
        _: &str,
        _: u32,
        _: u32,
        _: u32,
        _: u32,
        _: &[(russh::Pty, u32)],
        session: &mut russh::server::Session,
    ) -> Result<(), Self::Error> {
        session.channel_success(id)?;
        Ok(())
    }
    async fn shell_request(
        &mut self,
        id: russh::ChannelId,
        session: &mut russh::server::Session,
    ) -> Result<(), Self::Error> {
        session.channel_success(id)?;
        let Some(mut channel) = self.channels.remove(&id) else {
            return Err(russh::Error::Disconnect);
        };
        let received = self.received.clone();
        self.jobs.spawn(async move {
            if channel.data(&b"READY"[..]).await.is_err() {
                return;
            }
            while let Some(message) = channel.wait().await {
                match message {
                    russh::ChannelMsg::Data { data } => {
                        received.fetch_add(data.len(), std::sync::atomic::Ordering::AcqRel);
                        let _ = channel.data(&data[..]).await;
                    }
                    russh::ChannelMsg::Close | russh::ChannelMsg::Eof => break,
                    _ => {}
                }
            }
        });
        Ok(())
    }
}

#[gpui_kit::test]
async fn asynchronous_ssh_success_preserves_folder_editor_focus(cx: &mut TestAppContext) {
    use russh::keys::{HashAlg, PrivateKey, ssh_key::private::Ed25519Keypair};
    let fixture = mount(cx, vec![password_profile()]);
    let runtime = fixture
        .workspace
        .read_with(cx, |view, _| view.runtime.clone());
    let listener = runtime
        .block_on(tokio::net::TcpListener::bind("127.0.0.1:0"))
        .checked("bind delayed SSH fixture");
    let port = listener.local_addr().checked("fixture address").port();
    let key = PrivateKey::from(Ed25519Keypair::from_seed(&[0x75; 32]));
    let pin = key.public_key().fingerprint(HashAlg::Sha256).to_string();
    let config = Arc::new(russh::server::Config {
        keys: vec![key],
        ..Default::default()
    });
    let gate = Arc::new(tokio::sync::Notify::new());
    let authenticating = Arc::new(AtomicBool::new(false));
    let received = Arc::new(std::sync::atomic::AtomicUsize::new(0));
    let handler = DelayedShell {
        gate: gate.clone(),
        authenticating: authenticating.clone(),
        received: received.clone(),
        channels: Default::default(),
        jobs: tokio::task::JoinSet::new(),
    };
    let server = runtime.spawn(async move {
        if let Ok(Ok((socket, _))) =
            tokio::time::timeout(Duration::from_secs(20), listener.accept()).await
            && let Ok(session) = russh::server::run_stream(config, socket, handler).await
        {
            let _ = tokio::time::timeout(Duration::from_secs(20), session).await;
        }
    });
    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |view, cx| {
            view.state.connections[0].port = port;
            view.connect(
                view.state.connections[0].clone(),
                zeroize::Zeroizing::new("delayed-test-password".into()),
                Some(pin),
                window,
                cx,
            );
        });
    })
    .checked("start SSH while authentication is deliberately delayed");
    cx.wait_for(fixture.window, Duration::from_secs(10), |_, _| {
        authenticating.load(std::sync::atomic::Ordering::Acquire)
    })
    .await;
    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        window.click("new-folder", cx);
        window.render_frame(cx);
        window.input("before-", cx);
    })
    .checked("open and type in folder editor during connection");
    gate.notify_one();
    cx.wait_for(fixture.window, Duration::from_secs(20), |_, cx| {
        !fixture.workspace.read(cx).connecting
    })
    .await;
    fixture.workspace.read_with(cx, |view, _| {
        assert!(
            !view.tabs.is_empty(),
            "SSH fixture did not connect: {:?}",
            view.status
        );
    });
    cx.wait_for(fixture.window, Duration::from_secs(10), |_, cx| {
        fixture
            .workspace
            .read(cx)
            .tabs
            .first()
            .is_some_and(|tab| tab.read(cx).visible_text().contains("READY"))
    })
    .await;
    cx.update_window(fixture.window, |_, window, cx| {
        window.render_frame(cx);
        let form = fixture
            .workspace
            .read(cx)
            .folder_form
            .as_ref()
            .checked_option("editor remains visible");
        assert!(form.name.read(cx).focus_handle(cx).is_focused(window));
        window.input("after", cx);
        assert_eq!(
            fixture
                .workspace
                .read(cx)
                .folder_form
                .as_ref()
                .checked_option("retained editor")
                .name
                .read(cx)
                .value(),
            "before-after"
        );
    })
    .checked("SSH completion must not steal editor keys");
    cx.run_until_parked();
    assert_eq!(received.load(std::sync::atomic::Ordering::Acquire), 0);
    saved(&fixture, cx).await;
    cx.update_window(fixture.window, |_, window, cx| {
        window.click("cancel-folder", cx);
        window.input("ok", cx);
    })
    .checked("closing editor intentionally restores terminal focus");
    cx.wait_for(fixture.window, Duration::from_secs(5), |_, _| {
        received.load(std::sync::atomic::Ordering::Acquire) == 2
    })
    .await;
    cx.update_window(fixture.window, |_, window, cx| {
        fixture.workspace.update(cx, |view, cx| {
            view.close_tab(&crate::workspace::CloseTab, window, cx)
        });
    })
    .checked("close test session");
    server.abort();
}

mod bulk;
