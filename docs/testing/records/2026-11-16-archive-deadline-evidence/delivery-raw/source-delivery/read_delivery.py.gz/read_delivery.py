"""Read exact local, tracking, remote and frozen source identities."""
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[2]
SOURCE = "bc9ebd6cf4f213b9330c04380f866ead9133fb0a"
PARALLEL = "feature/archive-deadline-clock-20261116"
ORIGINAL = "feature/editor-unicode-codec-20261114"


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True, timeout=30).strip()


def remote(branch):
    value = git("ls-remote", "--heads", "origin", f"refs/heads/{branch}")
    sha, ref = value.split()
    assert ref == "refs/heads/" + branch
    return sha


value = {
    "source_commit": SOURCE,
    "current_branch": git("branch", "--show-current"),
    "current_head": git("rev-parse", "HEAD"),
    "parallel_branch": PARALLEL,
    "parallel_local": git("rev-parse", "refs/heads/" + PARALLEL),
    "parallel_tracking": git("rev-parse", "refs/remotes/origin/" + PARALLEL),
    "parallel_remote": remote(PARALLEL),
    "original_tracking": git("rev-parse", "refs/remotes/origin/" + ORIGINAL),
    "original_remote": remote(ORIGINAL),
    "working_tree_clean": not git("status", "--porcelain"),
}
assert value["current_branch"] == ORIGINAL
assert all(
    value[key] == SOURCE
    for key in ["current_head", "parallel_local", "parallel_tracking", "parallel_remote"]
)
assert value["original_tracking"] == value["original_remote"] == "5c23396c3cfcc6dd021fb870a7007373c25475d1"
assert value["working_tree_clean"]
verifier = ROOT / "docs/testing/records/2026-11-16-archive-deadline-evidence/verify_binding.py"
result = subprocess.check_output(
    [
        "python3", str(verifier), "--source-commit", SOURCE,
        "--evidence-commit", SOURCE, "--check-current",
    ],
    cwd=ROOT, text=True, timeout=30,
)
value["git_blob_binding"] = json.loads(result)
value["original_branch_push_deferred_for_exact_windows_diagnostics"] = True
print(json.dumps(value, indent=2))
