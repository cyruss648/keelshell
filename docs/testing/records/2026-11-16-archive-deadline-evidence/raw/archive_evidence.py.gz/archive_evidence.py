"""Persist this owned batch's originals without replacing an earlier archive."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
DEST = ROOT / "docs/testing/records/2026-11-16-archive-deadline-evidence"
assert (BASE / "final-gate-summary-r3.json").is_file()
assert (BASE / "reviewer/report.md").is_file()
assert not DEST.exists()
DEST.mkdir()


def sha(data):
    return hashlib.sha256(data).hexdigest()


rows = []
for source in sorted(BASE.rglob("*")):
    if not source.is_file() or "__pycache__" in source.parts:
        continue
    assert not source.is_symlink()
    relative = source.relative_to(BASE)
    data = source.read_bytes()
    compressed = gzip.compress(data, mtime=0)
    target = DEST / "raw" / (relative.as_posix() + ".gz")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(compressed)
    assert gzip.decompress(target.read_bytes()) == data
    rows.append({
        "path": relative.as_posix(),
        "archive": target.relative_to(DEST).as_posix(),
        "bytes": len(data), "sha256": sha(data),
        "gzip_bytes": len(compressed), "gzip_sha256": sha(compressed),
    })
manifest = {
    "schema": 1,
    "source_baseline": "5c23396c3cfcc6dd021fb870a7007373c25475d1",
    "inputs_freeze": "raw/inputs-freeze-r1.json.gz",
    "count": len(rows),
    "original_bytes": sum(row["bytes"] for row in rows),
    "gzip_bytes": sum(row["gzip_bytes"] for row in rows),
    "files": rows,
}
(DEST / "archive-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
(DEST / "previews.json").write_text("[]\n")
shutil.copyfile(
    ROOT / "docs/testing/records/2026-11-16-archive-diagnostics-and-native-focus-evidence/verify_binding.py",
    DEST / "verify_binding.py",
)
print(json.dumps({key: manifest[key] for key in ["count", "original_bytes", "gzip_bytes"]}))
