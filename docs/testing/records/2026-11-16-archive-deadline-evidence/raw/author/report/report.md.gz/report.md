# macOS archive fixed-deadline fixture candidate r1

结论：可静态确认原用例依赖真实调度速度；本候选消除该条件，并补充有界阶段诊断。
**尚未编译、格式化、Clippy 或运行 Rust，不能称修复验证通过。**
旧 CI 的实际失败阶段和生产根因仍为 **UNKNOWN**。

## 输入与授权边界

- 用户指定源码提交：`9d0f886acda4e48058004a28f85ef1fa3c510d4c`。
  与最新 HANDOFF 的源码交付记录一致；作者没有调用 Git 独立重新绑定该提交。
  导入依据是 `baseline.json` 中实际读取的三个父文件 SHA-256。
- Quality `43801985537`，attempt `1`，macOS job `133084142077`。
- 原日志：`work/command-focus-ci-20261116/macos-job-133084142077-r1.plain.log`。
  第 4716–4729 行记录本用例失败、裸 `Error: Elapsed(())`、
  `39 passed; 1 failed; 0 ignored` 和该 integration target 的 `7.57s`。
  这不是该用例自身的独立运行时长。
- 已读取 AGENTS、RTK、HANDOFF 当前交付与当前批次、SHARED_TARGET，以及测试、
  support fixture、生产 deadline/SSH 调用链和本地锁定版本 Tokio 的相关实现。
- 写入全部位于本作者目录。未修改父正式源码、文档、Git 或 target；
  未运行 Cargo、rustc、rustfmt、clean、UI、既有测试二进制，
  未新建 chat/worktree，未 commit/push。唯一 target 仍归父所有。

## 静态可证与不可证

原测试 `tests/server_archive.rs:657–686`：

1. 会话 timeout 为 1 秒。
2. 等待 dispatch gate 进入后，再真实等待 650 毫秒。
3. 释放 gate，随后必须在同一生产截止前完成 ACK、manifest 输入、
   `spawn_blocking` 中的真实 Python helper、完整回执及 SFTP 准备，才能进入 read gate。
4. 因而上述真实工作至多只有约 350 毫秒，还需扣除先前准入与调度耗时。

生产 `src/sftp/server_archive.rs:225–334` 在执行入口创建一次 authority，
把同一个 `until` 传入 SSH 执行及最终读回，`archive_deadline` 在 340 行起；
`src/ssh.rs:826` 起接收该截止。这个结构与原测试的合同一致。
当前材料没有证实生产在某阶段错误重置截止。

裸 `Elapsed(())` 可以来自两个 `entered` 的 5 秒等待、execution 的外层
2 秒等待，或 `alive` 的外层 5 秒等待。日志没有阶段标签，不能由其终态时间
认定卡在 read gate，更不能把这个失败认定为 confirmed production bug。

## 候选行为

只改三个文件，共 **106 行新增、13 行删除**：

- `crates/keelshell-session/Cargo.toml`：dev-dependency 继承 workspace 的 Tokio，
  只启用 `test-util`。没有引入版本要求、升级版本、编辑 lock 或改变生产依赖声明。
  当前 workspace 要求为 `1.54`，lock 解析为 `1.54.1`。
- `crates/keelshell-session/tests/support/server_archive_fixture.rs`：
  在现有 Gate 增加独立的 entry Notify；release Notify、armed 行为和 8 秒
  hold 上限不变。新增 `wait_frozen`，用 `std::time::Instant` 作有界墙钟 watchdog，
  同时轮询操作并向 Tokio 让出执行权，使 runtime 保持 runnable，避免真实 I/O
  等待时 idle auto-advance 偷走受控截止。没有新增 task、线程或后台 keeper。
- `crates/keelshell-session/tests/server_archive.rs`：只改最后一个用例。
  先按真实时钟完成 fixture、连接及审核，再暂停 current-thread runtime 的 Tokio
  时钟。实际抵达 dispatch gate 时断言执行耗时为零，显式推进 650ms 后释放；
  实际抵达 read gate 时断言仍为 650ms、只派发一次且执行尚未完成；再推进 351ms，
  越过原来的 1s 截止。额外 1ms 是越过 timer tick 边界，生产预算仍为 1s。
  结果必须是 `MutationUncertain`。恢复时钟后完成原有隔离、SSH 存活与关闭检查。

原有断言全部保留其检查对象：`MutationUncertain`、`<1400ms`、destination
与 staging 两条 quarantine、精确 `alive` 输出/exit status，均未删除或降为日志。
**耗时断言明确从 std 时钟改为生产 deadline 使用的 Tokio 时钟**；
它现在检查受控执行时间，不再把 helper/系统调度速度当作 1.4 秒性能要求。
两个 barrier 仍各有 5 秒墙钟上限，结果等待仍有 2 秒墙钟上限，
原有 2 秒 Tokio timeout 也保留；没有单纯增大任一等待预算。

若读回阶段错误获得新的 1 秒预算，read gate 在 650ms 进入后，
其错误的新截止会是 1650ms。时钟固定在 1001ms，错误执行不会按要求返回，
`wait_frozen` 会在原有 2 秒墙钟预算内明确失败。因此仍能拒绝分阶段重置截止；
此为静态分析，尚未做实际 mutation/red 验证。

没有加入自动重试、跳过、未知写重放、结果改签或生产代码修改；
helper 仍按精确审核命令通过真实 SSH 执行，未改成伪造输出。

## 诊断与定位

setup 与收尾错误增加 `phase=start/connect/plan/quarantine/alive/sftp-close/ssh-close`。
受控阶段 watchdog 报告：

- `phase=dispatch barrier`：尚未观察 dispatch 进入，定位到入场/通道/派发之前；
- `phase=readback barrier`：未观察 read 进入；若 dispatch_entries=1，
  只证明到达 dispatch，不证明 Python、输出或 SFTP 中哪一项失败；
- `phase=execution deadline`：已显式越过原截止，但未在 2 秒墙钟内观察结果。

上述失败均附 inspect/pack/opens/eof/input_bytes/dispatch_entries/read_entries。
这些是本次 fixture 计数，不包含内容、路径或凭据，也不等同于业务写入确认。
不吞掉 watchdog 错误、不自动重启执行。生产错误类型与未知隔离语义不变。

## 实际检查与限制

已执行并保存到 `static-checks.json` / `patch-dry-run.txt`：

- 对三个父正式文件重新计算 SHA-256，与开始时快照全部相等。
- 从父原文件与直接编辑的 candidate 调用 `diff -u`，形成可导入补丁；
  每项 diff 预期 exit 1。
- 对 `report/originals` 三文件镜像执行一次 `patch --dry-run --batch -p1`，
  exit 0；未实际应用到父工程。
- Python `tomllib` 解析候选 manifest；静态核对其 dev feature。
- 核对其他用例之前的测试源码逐字不变，以及原有关键断言/关闭调用存在。

实际 Rust 运行数为 **0**。未独立验证宏展开、借用检查、fmt、Clippy、
Tokio 调度实测、测试库存、负载回归、全门禁或真实 macOS/Linux CI。
本地读取 Tokio `1.54.1` 的 `time/clock.rs`、`task/yield_now.rs`、
current-thread scheduler 与 time driver，仅用于核对 pause、auto-advance
和 runnable/yield 行为；不把静态阅读当成运行验收。

## 父代理导入与验证建议

1. 比较 `baseline.json` 与当前父三个文件摘要；有漂移时先审差分。
2. 导入 `macos-deadline-r1.patch`，由父在其现有 target 归属下做格式、编译、
   Clippy、精确用例及完整 `server_archive` target 验证，核对具体用例名。
3. 独立复核暂停时钟的 idle 防护、两个 entry 通知的先后顺序与错误时清理；
   有条件时做读回重新分配截止的受控红例，证明本用例会拒绝。
4. 精确新提交的真实 CI 另行验证。旧 job 继续保留 failure/阶段 UNKNOWN，
   该补丁不代签 Windows 归档诊断或任何原生/生产验收。

建议：**作为静态已检查、未编译的候选交父验证，不能直接计入已过门禁批次。**
文件摘要和补丁 SHA-256 见 `static-checks.json`，原文件快照在 `originals/`。
