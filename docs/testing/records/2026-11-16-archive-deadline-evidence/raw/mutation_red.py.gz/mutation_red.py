"""Exercise a deliberately reset readback deadline, then restore exact source."""
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
relative = Path("crates/keelshell-session/src/sftp/server_archive.rs")
source = ROOT / relative
original = source.read_bytes()
snapshot = BASE / "deadline-reset-production-original.rs"
assert not snapshot.exists()
snapshot.write_bytes(original)
text = original.decode()
start = text.index("    pub async fn execute_server_archive(")
end = text.index("\nfn same_connection", start)
body = text[start:end]
before = "        let result = authority\n            .wait(async {"
assert body.count(before) == 1
body = body.replace(before, "        let result = async {", 1)
before = "                .await?;\n                accepted(&output)?;"
assert body.count(before) == 1
body = body.replace(
    before,
    "                .await?;\n"
    "                // Deliberate test mutation: wrongly renew readback authority.\n"
    "                let authority = Authority {\n"
    "                    sftp: self,\n"
    "                    cancelled,\n"
    "                    until: archive_deadline(self.timeout)?,\n"
    "                };\n"
    "                accepted(&output)?;",
    1,
)
before = "            })\n            .await;\n        // No await follows"
assert body.count(before) == 1
body = body.replace(before, "            }\n            .await;\n        // No await follows", 1)
mutated = (text[:start] + body + text[end:]).encode()
patch = "".join(
    difflib.unified_diff(
        original.decode().splitlines(keepends=True),
        mutated.decode().splitlines(keepends=True),
        fromfile="a/" + str(relative),
        tofile="b/" + str(relative),
    )
)
(BASE / "deadline-reset-mutation.patch").write_text(patch)
receipt = {
    "source": str(relative),
    "original_sha256": hashlib.sha256(original).hexdigest(),
    "mutated_sha256": hashlib.sha256(mutated).hexdigest(),
    "purpose": "Model a separate readback budget by removing the outer original "
               "deadline and renewing authority after real SSH execution.",
}
try:
    source.write_bytes(mutated)
    result = subprocess.run(
        [
            sys.executable, str(BASE / "run_command.py"),
            "deadline-reset-red-r1", "240", "cargo", "test", "--locked",
            "-p", "keelshell-session", "--test", "server_archive",
            "server_archive_dispatch_and_readback_share_one_fixed_execution_deadline",
            "--", "--exact", "--test-threads=1",
        ],
        cwd=ROOT,
        check=False,
    )
    receipt["runner_exit"] = result.returncode
finally:
    current = source.read_bytes()
    receipt["mutation_unchanged_before_restore"] = current == mutated
    if current != mutated:
        raise RuntimeError("Source changed concurrently; refusing to overwrite it.")
    source.write_bytes(original)
    receipt["restored_sha256"] = hashlib.sha256(source.read_bytes()).hexdigest()
    receipt["restored_exactly"] = source.read_bytes() == original
    (BASE / "deadline-reset-mutation-receipt.json").write_text(
        json.dumps(receipt, indent=2) + "\n"
    )
print(json.dumps(receipt))
log = (BASE / "deadline-reset-red-r1.log").read_text()
assert receipt["runner_exit"] != 0, "Mutation was not rejected"
assert "Finished `test` profile" in log, "Mutation did not compile"
assert "phase=execution deadline exceeded wall budget" in log, log
assert "1 failed; 0 ignored" in log, log
assert receipt["restored_exactly"]
