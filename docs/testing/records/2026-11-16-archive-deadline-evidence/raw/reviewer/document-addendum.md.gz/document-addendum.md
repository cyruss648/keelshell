**文档一致性旁路复核：交接压缩及已持久原生事实同步**

结论：**APPROVE，P0=0 / P1=0 / P2=0 / P3=0**，没有需要阻断本候选的文档问题。
此为用户追加的只读文档核对，不重复源码 review，不构成新的原生验收。
源码主报告 `report.md` 的合并条件保持：完整门禁终态尚未核验，实际合并暂缓。

文档快照截止：**2026-11-16 13:13:06 Asia/Shanghai**。
`document-check.json` 保留较早的两文档检查；
`document-check-r2.json` 绑定本次五文件快照、链接、已完成依赖查询及 CI 保存快照。
没有修改下列文档，没有重新运行测试、Cargo、UI 或额外 agent。

| 文档绝对路径 | 行数 / 字节数 | SHA-256 |
| --- | --- | --- |
| `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/HANDOFF.md` | 129 / 8445 | `f9d854a28fc29762517482233e31585a395312d1abf41300d7ea9c95bdd80839` |
| `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/HANDOFF_HISTORY_2026-11-16.md` | 2039 / 146588 | `231769816b66b2d25c8f403ba7b7d3e451ebfbd4f939101a0494a9aa77c201d1` |
| `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/testing/records/2026-11-16-archive-deadline.md` | 84 / 4887 | `01ac43d7f7df662f24e3934cb7accc4fd365597219848c1e9b41dd1db2b5519e` |
| `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/product/FILE_BROWSER_KEYBOARD.md` | 65 / 4568 | `750d436dd84330261d0e11ddaafee34fea434029328f6233481b6dd72344d306` |
| `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/product/CAPABILITIES.md` | 990 / 115928 | `8b5e311ea5b6b2336683071fa52ff9c4fa533c7fad83217539457774964066f4` |

1. **历史全文及相对链接位置保持。**
   实际读取固定
   `5c23396c3cfcc6dd021fb870a7007373c25475d1:docs/HANDOFF.md`，
   与 `docs/HANDOFF_HISTORY_2026-11-16.md` 逐字节相等；不是只比较行数或摘录。
   两者都位于 `docs/`，历史 Markdown 的相对链接没有因移动到其他目录而改基准。
   当前
   [HANDOFF.md:3](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/HANDOFF.md:3)
   及 124–129 行明确提供历史、产品、测试与路线入口，要求按精确回执追溯，
   并保留旧失败事实。当前 HANDOFF 和新记录共 19 个本地链接全部可解析；
   本次产品文档新增/调整区域的五个链接及三个“原生焦点补验”锚点也均可定位。
   没有声称逐一重验历史全文内所有旧活动路径的当前可用性。

2. **持续要求、资源归属和后续顺序没有被改签。**
   [HANDOFF.md:9](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/HANDOFF.md:9)
   保留正常推送、三方 SHA、不强推、不覆盖 main 独立文档；
   14–27 行保留 remote-only、四层分工、阻塞 I/O、三主题/语义 token、
   AI 双重显式审核、host key fail closed、凭据边界、x.y/lock/无工具链 pin、
   非作者及完整门禁、Release 授权与不覆盖安装/不上传遥测。
   104–120 行保留输入及库存核对、失败原件、源码/证据身份、活动 CI 协调、
   自有资源清理、唯一 target 和归属切换规则，且不让新测试签成新正常包/桌面验收。

   特别核对了压缩清单没有逐项重述的供应商账户/外部 MCP 和完整多窗口矩阵：
   原
   [持续边界:2037](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/HANDOFF_HISTORY_2026-11-16.md:2037)
   完整保存；HANDOFF 100 行链接的能力台账仍在
   [CAPABILITIES.md:828](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/product/CAPABILITIES.md:828)、
   [951–961 行](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/product/CAPABILITIES.md:951)
   明确保留相关未验收范围。
   当前入口没有宣称这些边界已通过，因此不把这项简写判成约束遗失或 P3。
   历史 HOLD 仅能由更新且适用的精确证据限定补充，不能理解为全部关闭。

3. **本候选、冻结、红绿及 pending 事实准确。**
   [HANDOFF.md:31](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/HANDOFF.md:31)
   和
   [测试记录:5](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/testing/records/2026-11-16-archive-deadline.md:5)
   限定为 manifest dev feature 与两测试文件；实际生产恢复字节、四组父红绿计数、
   718 项集合摘要与主报告核对结果一致。
   测试记录 23–41 行区分可静态确认的旧 650ms 条件与 UNKNOWN 根因、
   `<1400ms` 的测量对象变化、真实墙钟预算、dev feature 和原生产预算。
   52–60 行对 mutation 的外层移除/读回续期描述与实际补丁一致。
   两文档的 full-gate/reviewer pending 是检查时点事实；截至本次文档快照，
   `full-gate-r1.json` 仍未出现。本旁路不将父后续局部进度写成最终通过。
   父在门禁和审查结束后更新这些状态属于新事实，不要求覆盖此快照报告。

4. **旧 CI 的失败和新 CI 的身份分离。**
   [HANDOFF.md:49](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/HANDOFF.md:49)
   的源码 `76b8253...`、run `43806549649 / attempt 1` 及三个 job
   `133098539119 / 133098539273 / 133098539513`
   与父已经完成 GET 后保存的
   `work/archive-diagnostics-ci-20261116/diagnostic-run-followup-r3.log`
   和 `diagnostic-jobs-r2.log` 一致；两个文件摘要都与回执相等。
   这些保存快照为 in_progress，不作为本复核时刻的实时远端查询。
   旧 `43801985537` 的裸 Elapsed、Windows 缺审和未知根因仍保留，
   新候选没有被写成旧生产问题的确认修复。
   CI 的 docs-only push 不覆盖活动源码 run 规则，也与
   [.github/workflows/ci.yml:3](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/.github/workflows/ci.yml:3)
   的 `paths-ignore: docs/**` 及同 ref cancel-in-progress 配置相符。

5. **依赖实时检查没有被误报为全部成功。**
   已读取父完成的 `dependencies-live-r1.json/.log` 和
   `dependencies-live-report-r1.json`，日志摘要/字节数与回执相等。
   报告记录查询于 2026-11-16 13:02:51–13:03:27 Asia/Shanghai 完成，
   113 条声明/使用、37 个 registry 包；按 package 分组确为 23 包全部要求通过、
   14 包无版本元数据且存在查询错误，其他分组状态为 0；整体 exit 1、已 reap。
   HANDOFF 44–45 行及测试记录 75–78 行保留了这 14 包 UNKNOWN 和整体失败，
   并将 x.y 政策另列。reviewer 没有重新联网查询或签署所有依赖最新。

6. **产品文档只同步先前限定原生证据。**
   [FILE_BROWSER_KEYBOARD.md:3](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/product/FILE_BROWSER_KEYBOARD.md:3)
   与 43–49 行的中英说明均保留原批次记录，并把较晚的两侧各一文件、
   从命令框到双列表根的正反向路径单独补充；原多条目反向仍不完整，
   其他主题/平台、IME/VoiceOver 及完整焦点矩阵仍开放。
   [CAPABILITIES.md:3](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/product/CAPABILITIES.md:3)
   同时明确 Frost 浅色中文、自有 SSH/SFTP、raw PNG 焦点、167 份完整 AX、
   67 步/149 字节草稿、AX setValue 和 raw PTY/尺寸等限制；原下方 HOLD 作为历史
   保留，没有改写旧结果。

   这些描述与已持久
   [焦点补验记录:44](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/testing/records/2026-11-16-archive-diagnostics-and-native-focus.md:44)
   至 69 行一致：反向 remote26/local32、正向 remote35/local29，
   初始 38 项的 100 步反向仅到 remote，不等同完整双列表；不签 AX focused-child、
   IME、raw PTY 零出站或其他主题/尺寸/平台/VoiceOver。
   本旁路只核对新文字与已持久记录，不重新查看全部 PNG/AX、重放 UI 或签新的
   正常程序构建。两份产品文档的新增事实不能代签当前归档候选的任何 GUI 验收。

没有要求修改文档；四项内容更新与原历史归档在上述固定快照范围内一致。
本旁路没有独立刷新远端 CI、供应商元数据或 agent 存活状态，也没有重审历史能力的
全部实现/验收。所有当前源码、门禁、原生与发行状态继续按主报告和各自精确回执区分。
