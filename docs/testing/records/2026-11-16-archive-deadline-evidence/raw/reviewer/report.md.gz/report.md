**macOS 归档固定截止时间候选：新非作者独立只读复核**

源码结论：**APPROVE，P0=0 / P1=0 / P2=0 / P3=0，必须修复项为 0。**
当前 merge recommendation：**HOLD 实际合并，等待父任务唯一完整门禁的终态**。
同一冻结输入的完整门禁实际成功、库存及完整路径/字节核对无漂移后，建议合并本候选；
本次源码审查没有要求修改的代码。这个条件来自工程合同，不能把专项绿例或本报告
代签成仍未结束的 fmt/Clippy/全仓测试/依赖政策等最终门禁。

本报告由未参与候选编写、导入、生产变异或父验证执行的新非作者完成。
源码证据截止为 **2026-11-16 13:05:43 Asia/Shanghai**，对应
`verification.json` 的 `2026-11-16T05:05:43.438349+00:00`。
后续文档旁路检查单独记录，不重写这个截止时点的门禁限制。

**输入、身份及只读边界**

- 正式 checkout：
  `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`。
- 固定基线及开始/截止读回 HEAD：
  `5c23396c3cfcc6dd021fb870a7007373c25475d1`。
- 候选仅三个文件，`106 insertions / 13 deletions`。以下 SHA-256 在开始和截止
  均相等，且全部与作者封存 candidate 的对应字节相等。

| 绝对路径 | SHA-256 |
| --- | --- |
| `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/Cargo.toml` | `941ad490fb950bc43fa2b454555dc29b0eba6373e78df1eec776b75ce10ebfcf` |
| `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/server_archive.rs` | `94bcfe07bcaa67ae952c71613a2baf126b35ce266aab0827bbd092b1710f3c61` |
| `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/support/server_archive_fixture.rs` | `6c7886e82183debf9c0b5528f9f44a1c7c3a6c37179dd2745be0add51fe1633b` |

候选 Git diff SHA-256 为
`01067f3a91080ca72e3ae35903960e58bf22d5c3b1cb091dd24e5c6b8367b09f`，
两次相等。生产归档逻辑按
`git show 5c23396c3cfcc6dd021fb870a7007373c25475d1:crates/keelshell-session/src/sftp/server_archive.rs`
阅读；父临时变异不计入候选。截止时实际生产文件与这个对象逐字节相等，
SHA-256 均为
`d31d4eecccb5566097dd1f49e86a803b38fb43763f0cc6334449e8cfc1c2d8ba`。

独立重新计算父冻结的 **718** 个工程输入：路径集合无 missing/extra，
逐文件摘要无 mismatch，集合摘要确为
`593459030133909451156982dbb949e53d872cccf6cfa30a18593b2411e66e21`。
这是输入绑定检查，不能表示已经执行完整门禁。

已读取 RTK、checkout 与上层 AGENTS、原 HANDOFF 当前交付/当前批次，以及
`docs/testing/SHARED_TARGET.md`；应用
`/Users/hdh/.agents/skills/rust-best-practices/SKILL.md` 的相关编码、错误处理、
测试、注释及所有权指导。共享 target 没有切换给 reviewer，reviewer 没有进入构建流程。

本复核仅在
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/archive-deadline-integration-20261116/reviewer/`
写报告/核对结果；没有修改源码、工程文档、Git 或 target，没有运行 Cargo、clean、
rustfmt、rustc、测试二进制、UI，没有新建子 agent、chat 或 worktree。
读取 Git 使用 `GIT_OPTIONAL_LOCKS=0`，没有执行 Git 写命令。

**发现计数及判定**

| 级别 | 本次源码发现数 | 必须修复项 |
| --- | ---: | ---: |
| P0 | 0 | 0 |
| P1 | 0 | 0 |
| P2 | 0 | 0 |
| P3 | 0 | 0 |

未发现能够成立的新增缺陷，以下列出重点风险的触发条件、源码位置和判定依据，
避免把“零发现”当成未检查。

1. **暂停时机和 auto-advance 防护。**
   [server_archive.rs:656](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/server_archive.rs:656)
   显式采用 current-thread runtime；658–667 行先完成真实 fixture、连接和计划审核，
   674 行才 pause。触发风险是等待真实 I/O 时 runtime 进入 idle，从而自动推进到
   生产 timer，造成假超时。fixture
   [296–327 行](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/support/server_archive_fixture.rs:296)
   对固定 future 先 poll，再 select `yield_now`；等待期间持续向调度器让出执行权。
   688、698 行分别要求受控耗时恰为 0 与 650ms，不允许 barrier 间被动消耗时钟。
   若防护失效，用例会失败，不会把额外时间视为成功。

2. **yield 循环仍可驱动真实 I/O。**
   `wait_frozen` 没有在 async 线程里 sleep、阻塞等待或创建 keeper task。
   `biased` 使完成操作优先返回；操作 Pending 时，新的 yield future 返回 Pending，
   整个调用链返回调度器。不能把这泛化为“每次 yield 都保证公平调度”。
   本次按锁定 Tokio 1.54.1 的实际实现核对：
   `/Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837/tokio-1.54.1/src/task/yield_now.rs:38`
   把 waker 交给 defer；
   `/Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837/tokio-1.54.1/src/runtime/scheduler/current_thread/mod.rs:445`
   的 `park_yield` 用零等待轮询 driver，457–473 行把 deferred waker 计入 pending work，
   并在 driver 之后唤醒；
   `/Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837/tokio-1.54.1/src/runtime/time/mod.rs:213`
   将零等待 limit 施加到 driver，不会跳过 socket readiness。
   fixture
   [548 行](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/support/server_archive_fixture.rs:548)
   仍在 blocking worker 中执行真实 helper，835–861 行仍是实际 SFTP 文件读取。
   未来调度实现变化需重新验证；当前父绿例和有效红例均实际抵达 read gate。

3. **Notify 顺序及丢失唤醒。**
   fixture
   [59–99 行](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/support/server_archive_fixture.rs:59)
   使用独立 entry/released Notify。`hold` 先以 AcqRel 增加 entered，再
   `entry.notify_one()`；`wait_for_entry` 创建通知 future 后用 Acquire 检查持久
   predicate，predicate 已真时直接返回，否则 await。通知发生在首次 poll 之前时，
   当前用法的唯一等待者仍可消费保存的 permit；通知之后 predicate 也不会回退。
   `release` 先清 armed 再 notify，保留 release-before-await permit。
   两个 gate 各自只有本用例的一个观察者、一个 holder，且均为新 fixture 的首次 arm，
   没有另一个 consumer 抢 permit，未发现丢唤醒路径。该判定不声称 helper 是通用
   多观察者广播或可重置世代屏障；`arm` 不重置累计 entered。

4. **失败退出、future drop 和清理。**
   `wait_frozen` 把 operation pin 在调用栈中，不另起后台任务；墙钟预算错误通过 `?`
   传播，不吞掉或重试。最后 `.await???` 分别传播 fixture、Tokio timeout、
   JoinError，保留供 `matches!` 检查的 SessionError。
   错误/断言发生在 resume 之前时，显式 close 确实不会执行；不能谎称失败路径也完成
   了正常收尾。现有
   [Fixture::drop:145](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/support/server_archive_fixture.rs:145)
   同步设置 stop、释放全部七个 gate、abort listener；连接/子任务随后随 fixture
   所在测试 runtime teardown 回收。丢弃 JoinHandle 本身不等于 abort，判断依据包含
   这个独立 runtime 的销毁。helper 的
   [597–618 行](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/support/server_archive_fixture.rs:597)
   仍使用真实 Instant 的 7 秒上限、stop 检查与 kill 后 1 秒 reap 观察；
   blocking closure 持有临时根目录，避免 helper 尚在运行时提前删除目录。
   未发现候选新增的逃逸任务、永久 gate 等待或跨测试冻结时钟。
   父红例的进程回执支持该次错误运行已终止；本复核没有独立注入两个准备 barrier 的
   全部失败路径，也没有逐个核验失败时所有文件描述符/临时目录，不能扩签完整清理矩阵。

5. **受控时钟与真实墙钟预算。**
   [server_archive.rs:689](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/server_archive.rs:689)
   和 702 行显式推进 650+351=1001ms，跨越原 1 秒截止；
   fixture 的三个 watchdog 仍分别为 5/5/2 秒 `std::time::Instant`。
   最后一层 2 秒 Tokio timeout 仍保留，但冻结期间主要由真实 2 秒 watchdog 防止卡死。
   `advance` 不保证返回时所有 timer 已处理，后续 `wait_frozen` 持续驱动 runtime，
   因此没有把 advance 返回直接当作任务已完成。
   原 `<1400ms` 从墙钟改为 Tokio 执行时钟，已明确改变测量对象：
   本候选检查单次截止合同，不再断言 helper/runner 的 1.4 秒性能。
   新增 barrier 精确耗时和真实 watchdog 补足这个区别，不是仅放宽原等待上限。
   这些是协作式等待预算，不是整个测试含 setup/teardown 的 12 秒硬杀进程上限。

6. **隔离、未决状态及独立 SSH 存活断言。**
   [server_archive.rs:703](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/server_archive.rs:703)
   仍要求 `MutationUncertain`；714–727 行先 resume、释放 read gate，再执行
   两路径 quarantine、`alive`、SFTP close、SSH close。
   同文件
   [assert_quarantine:38](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/server_archive.rs:38)
   对 destination 和 staging 分别要求匹配条目；fixture
   [alive:904](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/support/server_archive_fixture.rs:904)
   仍断言精确 `alive` 字节及 exit status 0。
   最后一个用例之前的完整测试源码与 HEAD 逐字节相同，包含
   [335–411 行](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/server_archive.rs:335)
   的 dropped future/取消后双隔离及再次执行 `MutationQuarantined`，
   [571–625 行](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/server_archive.rs:571)
   的 readback 占用及取消不清 pending。
   固定生产对象的
   [server_archive.rs:321](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/server_archive.rs:321)
   只在完整成功时清 pending；
   [mutation.rs:70](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/mutation.rs:70)
   的 Drop/result 规则也未改动。没有把 UNKNOWN 写入重放、清理或签成无写入。

7. **test-util 的生产边界。**
   [Cargo.toml:29](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/Cargo.toml:29)
   只在 dev-dependencies 增加继承 workspace 的 Tokio `test-util`；
   生产 dependencies 表与 HEAD 相等，workspace 仍要求 `1.54`、
   lock 仍为 `1.54.1`，Cargo.lock 与 HEAD 逐字节相等。
   [workspace Cargo.toml:3](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/Cargo.toml:3)
   为 resolver 3；本地官方 Cargo 手册
   `/Users/hdh/.rustup/toolchains/stable-aarch64-apple-darwin/share/doc/rust/html/cargo/reference/resolver.html:511`
   说明：普通构建不由 dev edge 开启该 feature，测试及 `--all-targets` 等包含 dev
   targets 的构建会统一对应 feature。因此测试中的生产库会使用同一受控 Tokio 时钟，
   这正是本测试需要的行为；不能把测试构建称作不受 test-util 影响。
   本候选没有在生产调用 pause，也没有要求正常发行构建开启 test-util。
   这里是 manifest/解析器规则的静态结论，没有运行 cargo tree 或重建发行程序来核验
   最终 artifact 的实际 feature 集及字节。

**真正执行的测试、父原件及 mutation 有效性**

reviewer 实际执行 Rust 测试 **0**，其他行为测试 **0**。
Python 仅进行摘要、文本/TOML、路径集合和完成日志库存核对，不作为行为测试计数。
没有借用父二进制执行独立专项，也没有独立重新编译。

亲自读取并核对以下四组已经完成的父日志及 JSON：日志字节数和 SHA-256 均与回执一致；
回执均为 `direct_reaped=true / active_processes=0 / pipes_drained=true`，
无 timeout、interrupted 或 errors。

| 父原件 | passed / failed / ignored | 实际退出码 | 日志测试时长 |
| --- | --- | ---: | --- |
| `deadline-candidate-r1` | 1 / 0 / 0，另 39 filtered | 0 | 0.13s |
| `archive-target-r1` | 40 / 0 / 0，无 filtered | 0 | 5.60s |
| `deadline-reset-red-r1` | 0 / 1 / 0，另 39 filtered | 101 | 2.13s |
| `deadline-restored-green-r1` | 1 / 0 / 0，另 39 filtered | 0 | 0.14s |

表内是父执行数，不能计为 reviewer 独立运行。三次绿色运行共 42 次通过的执行，
覆盖 40 个不同测试名；另一次预期 mutation 失败单列，不称“43 项全部通过”。
源码含 23 个直接测试及 17 个宏生成测试；40 个名字与原基线和完整 target 日志
逐名相等，未通过合并计数掩盖库存缺失。

原件绝对目录为
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/archive-deadline-integration-20261116/`。
具体结果可定位到
[archive-target-r1.log:46](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/archive-deadline-integration-20261116/archive-target-r1.log:46)、
[deadline-reset-red-r1.log:11](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/archive-deadline-integration-20261116/deadline-reset-red-r1.log:11)、
[deadline-restored-green-r1.log:8](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/archive-deadline-integration-20261116/deadline-restored-green-r1.log:8)。

亲自检查
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/archive-deadline-integration-20261116/deadline-reset-mutation.patch`：
它同时移除覆盖整个执行体的原 `authority.wait`，并在真实 SSH 执行完成后重建
读回 authority。若仅修改内部预算却仍被原外层截止拦住，不足以证明测试有判别力；
本次没有这种屏蔽。错误实现可抵达 dispatch/read 两个 barrier，并在受控 1001ms
时仍等待错误的约 1650ms 截止，实际由 2 秒真实 watchdog 拒绝：

```text
phase=execution deadline exceeded wall budget 2s;
inspect=1 pack=1 opens=5 eof=2 input_bytes=1540 dispatch_entries=1 read_entries=1
```

红例日志显示实际编译当前 checkout 的 session，测试失败而非编译失败；
恢复绿例也显示重新编译和精确测试成功。saved original、固定 HEAD 对象及实际恢复
文件三者字节一致。reviewer 没有执行、重做或恢复任何 mutation。

**旧 CI、未来门禁及验收限制**

旧 CI `43801985537 / attempt 1`、macOS job `133084142077` 的已保存 excerpt
只证明该 target `39/1/0` 及裸 `Error: Elapsed(())`，7.57s 是整个 target 时长，
不是该用例自己的时长。这个旧失败的具体 await/阶段、生产根因均保持 **UNKNOWN**。
可以静态证明旧测试真实消耗 650ms 后只剩约 350ms 给 helper/传输，但不能据此认定
runner 调度就是旧 CI 根因，也不能称生产归档错误已修复。

此次直接读到的是作者保存的
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/archive-deadline-integration-20261116/author/report/failure-excerpt.txt`；
它标注旧日志 4716–4729 行。旧 `work/command-focus-ci-20261116/` 原目录已不在，
没有从该已删除路径重取完整旧日志或独立查询远端 CI。

证据截止时 `full-gate-r1.json` 尚不存在，本报告没有读取未结束日志来签署成功。
父随后报告的局部门禁进展，也不改变本报告在该截止时点的 PENDING。
最终完整门禁、严格 Clippy、全仓 Rust/Python、依赖政策、三组 controller 等由父
实际完成并另行记录；同一 718 项输入成功且无漂移后可满足这里的合并条件。
未来实际失败需要另行调查，不能覆盖本报告或早前失败原件。

未独立验证高负载稳定性、所有失败清理矩阵、普通发行构建、精确新提交的真实
macOS/Linux/Windows CI、OpenSSH/native、GUI、IME/辅助技术、发行安装或业务验收。
Windows 八项旧归档失败和完整产品范围不由本测试候选或 mutation 证据关闭。

输入快照及机器核对结果分别见同目录 `input-snapshot.json`、`verification.json`。
报告和相关核对文件的最终摘要由同目录 `SHA256SUMS` 及交付回复提供。
