"""Bind a completed gate to the full source set and actual compiled inventories."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
receipt = json.loads((BASE / "full-gate-r1.json").read_text())
data = (BASE / "full-gate-r1.log").read_bytes()
assert receipt["observed_exit"] == receipt["controller_exit"] == 0
assert not receipt["timed_out"] and not receipt["interrupted"]
assert receipt["terminal"] == {
    "direct_reaped": True,
    "active_processes": 0,
    "pipes_drained": True,
    "errors": [],
}
assert receipt["log_bytes"] == len(data)
assert receipt["log_sha256"] == hashlib.sha256(data).hexdigest()
text = data.decode()
freeze = json.loads((BASE / "inputs-freeze-r1.json").read_text())
names = subprocess.check_output(
    ["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"],
    cwd=ROOT,
).split(b"\0")
current_paths = {
    name.decode() for name in names
    if name and not name.startswith(b"docs/") and (ROOT / name.decode()).is_file()
}
assert current_paths == {row["path"] for row in freeze["inputs"]}
mismatches = [
    row["path"] for row in freeze["inputs"]
    if hashlib.sha256((ROOT / row["path"]).read_bytes()).hexdigest() != row["sha256"]
]
assert not mismatches
aggregate = "".join(
    f"{row['path']}\0{row['sha256']}\n" for row in freeze["inputs"]
).encode()
assert hashlib.sha256(aggregate).hexdigest() == freeze["aggregate_sha256"]

workspace = text.split(
    "Running: cargo test --workspace --locked -- --test-threads=4\n", 1
)[1].split("Running: cargo test -p keelshell-ai", 1)[0]
ordinary, rustdoc = workspace.split("   Doc-tests ", 1)
pattern = r"^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;"


def totals(part):
    rows = [tuple(map(int, row)) for row in re.findall(pattern, part, re.M)]
    assert rows
    return dict(zip(
        ("passed", "failed", "ignored"),
        (sum(row[index] for row in rows) for index in range(3)),
    ))


def target_output(binary_fragment):
    match = re.search(
        r"^     Running ([^\n]*\(" + re.escape(binary_fragment) + r"[^\n]*)\)\n",
        ordinary, re.M,
    )
    assert match, binary_fragment
    return ordinary[match.end():].split("     Running ", 1)[0]


app_output = target_output(
    "work/recovery-batch-integration-20261115/target/debug/build/keelshell-app/"
)
inventory = set(re.findall(r"^(.+): test$", (BASE / "app-inventory-r1.log").read_text(), re.M))
executed = re.findall(r"^test (.+) \.\.\. (?:ok|ignored[^\n]*)$", app_output, re.M)
assert len(executed) == len(set(executed)) == len(inventory)
assert set(executed) == inventory
# Session has several targets; choose the actual server_archive header.
match = re.search(
    r"^     Running tests/server_archive\.rs "
    r"\(work/recovery-batch-integration-20261115/target/debug/build/"
    r"keelshell-session/[^\n]+\)\n", ordinary, re.M
)
assert match
archive_output = ordinary[match.end():].split("     Running ", 1)[0]
archive_names = set(re.findall(r"^test (.+) \.\.\. ok$", archive_output, re.M))
prior_archive_names = set(re.findall(
    r"^test (.+) \.\.\. ok$", (BASE / "archive-target-r1.log").read_text(), re.M
))
assert len(archive_names) == 40 and archive_names == prior_archive_names
assert "server_archive_dispatch_and_readback_share_one_fixed_execution_deadline" in archive_names
python = re.search(r"^Ran (\d+) tests in [^\n]+\n\nOK \(skipped=(\d+)\)", text, re.M)
assert python
controllers = re.findall(r"^Running: (cargo test -p keelshell-ai[^\n]+)$", text, re.M)
assert len(controllers) == 3

artifacts = {}
for name, expected in {
    "keelshell-app": "af2a88364650b90b5dfab4ca8a4655a8430febc4971f575c7a7fd0fde19eb9a3",
    "keelshell-mcp": "0e5efdcbe2069fb4ea3c809a99419c557d11ba0ba18e7ba8e5fc6ea0e9bde816",
}.items():
    binary = ROOT / "work/recovery-batch-integration-20261115/target/debug" / name
    digest = hashlib.sha256(binary.read_bytes()).hexdigest()
    assert digest == expected
    artifacts[name] = {
        "bytes": binary.stat().st_size, "sha256": digest,
        "reused_previous_normal_build": True,
    }
summary = {
    "gate": receipt,
    "engineering_inputs": freeze["count"],
    "engineering_sha256": freeze["aggregate_sha256"],
    "complete_engineering_path_set_matches": True,
    "input_mismatches": mismatches,
    "rust": {"ordinary": totals(ordinary), "rustdoc": totals(rustdoc)},
    "app_inventory_count": len(inventory),
    "app_executed_names_match": True,
    "app": totals(app_output),
    "server_archive": {
        **totals(archive_output), "exact_40_names_match": True,
        "fixed_deadline_name_passed": True,
    },
    "python": {
        "run": int(python[1]), "passed": int(python[1]) - int(python[2]),
        "skipped": int(python[2]), "failed": 0,
    },
    "normal_artifacts": artifacts,
    "format_strict_clippy_xy_policy_and_three_controllers_passed": True,
    "controllers": controllers,
}
with (BASE / "final-gate-summary-r2.json").open("x") as output:
    json.dump(summary, output, indent=2)
    output.write("\n")
print(json.dumps(summary, indent=2))
