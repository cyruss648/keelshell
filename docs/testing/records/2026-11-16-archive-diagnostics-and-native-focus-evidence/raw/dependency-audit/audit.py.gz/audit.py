#!/usr/bin/env python3
"""Read-only dependency audit; subprocesses are bounded HTTPS GETs and Git reads."""
import concurrent.futures as cf
import csv, datetime as dt, hashlib, io, json, os, pathlib, re, shutil, subprocess, time, tomllib
ROOT=pathlib.Path.cwd()
OUT=ROOT/'work/windows-archive-fix-20261116/dependency-audit'
START=time.monotonic()
NOW=lambda: dt.datetime.now(dt.timezone.utc).isoformat()
started=NOW()
# The preceding instruction/manifest reads began before this process. Reserve
# at least a minute of the user's 180 seconds for those reads and reporting.
DEADLINE=START+65
NET_END=START+55
OUT.mkdir(parents=True,exist_ok=True)
(OUT/'official').mkdir(exist_ok=True)
def dump(name,obj):
 (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def digest(b): return hashlib.sha256(b).hexdigest()
def git(*args):
 try:
  p=subprocess.run(['git','--no-optional-locks',*args],capture_output=True,text=True,timeout=3)
  return p.stdout.strip() if p.returncode==0 else 'UNKNOWN'
 except subprocess.TimeoutExpired: return 'UNKNOWN'
head=git('rev-parse','HEAD')
manifest_paths=[ROOT/'Cargo.toml']+sorted((ROOT/'crates').glob('*/Cargo.toml'))
input_paths=manifest_paths+[ROOT/'Cargo.lock']
initial={str(p.relative_to(ROOT)):digest(p.read_bytes()) for p in input_paths}
root=tomllib.loads((ROOT/'Cargo.toml').read_text())
lock=tomllib.loads((ROOT/'Cargo.lock').read_text())
packages=lock['package']
registry_packages=[p for p in packages if p.get('source','').startswith('registry+')]
wsdeps=root.get('workspace',{}).get('dependencies',{})
entries=[]
errors=[]
def lineno(path,section,key):
 current=''
 for n,line in enumerate(path.read_text().splitlines(),1):
  if line.strip().startswith('['): current=line.strip()
  if current==section and re.match(r'^\s*'+re.escape(key)+r'\s*=',line): return n
 return None
def blocks(d):
 for kind in ['dependencies','dev-dependencies','build-dependencies']:
  if kind in d: yield kind,d[kind]
 for target,td in d.get('target',{}).items():
  for kind in ['dependencies','dev-dependencies','build-dependencies']:
   if kind in td: yield 'target.'+target+'.'+kind,td[kind]
def add(path,section,key,value,owner=None):
 inherited=isinstance(value,dict) and value.get('workspace') is True
 actual=wsdeps.get(key) if inherited else value
 if isinstance(actual,str): actual={'version':actual}
 if not isinstance(actual,dict):
  errors.append({'file':str(path.relative_to(ROOT)),'alias':key,'error':'UNRESOLVED_DEFINITION'}); return
 if 'path' in actual or 'git' in actual: return
 version=actual.get('version')
 name=actual.get('package',key)
 entries.append({'crate':name,'alias':key,'manifest':str(path.relative_to(ROOT)),
  'section':section,'line':lineno(path,'['+section+']',key),'requirement':version,
  'xy_policy':'PASS' if isinstance(version,str) and re.fullmatch(r'\d+\.\d+',version) else 'FAIL',
  'inherited':inherited,'workspace_package':owner,'registry':actual.get('registry','crates.io')})
for key,value in wsdeps.items(): add(ROOT/'Cargo.toml','workspace.dependencies',key,value)
for path in manifest_paths[1:]:
 d=tomllib.loads(path.read_text())
 for section,values in blocks(d):
  for key,value in values.items(): add(path,section,key,value,d['package']['name'])
byname={}
for e in entries: byname.setdefault(e['crate'],[]).append(e)
def key(version):
 m=re.fullmatch(r'(\d+)\.(\d+)\.(\d+)(?:\+[0-9A-Za-z.-]+)?',version)
 return tuple(map(int,m.groups())) if m else None
def compatible(version,req):
 k=key(version)
 if k is None or not re.fullmatch(r'\d+\.\d+',req or ''): return False
 major,minor=map(int,req.split('.'))
 lower=(major,minor,0)
 upper=(major+1,0,0) if major else ((0,minor+1,0) if minor else (0,1,0))
 return lower<=k<upper
# Resolve direct versions from each workspace package's actual lock edges.
for e in entries:
 versions=[]; issues=[]
 if e['workspace_package']:
  owners=[p for p in packages if p['name']==e['workspace_package'] and not p.get('source')]
  for owner in owners:
   for edge in owner.get('dependencies',[]):
    bits=edge.split()
    if bits[0]!=e['crate']: continue
    candidates=[p for p in registry_packages if p['name']==e['crate'] and (len(bits)<2 or p['version']==bits[1])]
    if len(candidates)==1: versions.append(candidates[0]['version'])
    elif len(candidates)!=1: issues.append('LOCK_EDGE_AMBIGUOUS_OR_MISSING')
  if not versions: issues.append('NO_DIRECT_LOCK_EDGE')
 e['direct_locked_versions']=sorted(set(versions),key=lambda v:key(v) or (-1,-1,-1))
 e['lock_resolution_issues']=sorted(set(issues))
# Read only the toolchain fields needed for this audit. No environment dump.
settings_path=pathlib.Path.home()/'.rustup/settings.toml'
settings=tomllib.loads(settings_path.read_text()) if settings_path.exists() else {}
tool=settings.get('default_toolchain')
toolbase=settings_path.parent/'toolchains'/str(tool)
local_manifest=toolbase/'lib/rustlib/multirust-channel-manifest.toml'
local={ 'default_toolchain':tool,'evidence_method':'installed manifest and binary static inspection; no rustc/cargo execution',
 'rustc_cli_version':'UNKNOWN','cargo_cli_version':'UNKNOWN','runtime_version_verified':False,
 'settings_path':str(settings_path),'manifest_path':str(local_manifest),
 'path_commands':{name:shutil.which(name) for name in ['rustc','cargo']},
 'workspace_toolchain_pins':[], 'matching_directory_override':None,
 'rustup_toolchain_override_present':bool(os.environ.get('RUSTUP_TOOLCHAIN'))}
for base in [ROOT,*ROOT.parents]:
 for name in ['rust-toolchain','rust-toolchain.toml']:
  if (base/name).is_file(): local['workspace_toolchain_pins'].append(str(base/name))
for directory,name in settings.get('overrides',{}).items():
 try:
  if ROOT.is_relative_to(pathlib.Path(directory)):
   local['matching_directory_override']={'directory':directory,'toolchain':name}
 except ValueError: pass
if local_manifest.exists():
 b=local_manifest.read_bytes(); m=tomllib.loads(b.decode())
 local.update({'manifest_date':m.get('date'),'manifest_sha256':digest(b),
  'rust_distribution_version':m.get('pkg',{}).get('rust',{}).get('version'),
  'rustc_distribution_version':m.get('pkg',{}).get('rustc',{}).get('version'),
  'cargo_distribution_package_version':m.get('pkg',{}).get('cargo',{}).get('version')})
 local['rustc_cli_version']=local['rustc_distribution_version'] or 'UNKNOWN'
# The Cargo distribution manifest uses an internal 0.x package version. Do not
# relabel it as the CLI version. Seek a unique version/build string in the file.
cb=toolbase/'bin/cargo'
if cb.is_file():
 b=cb.read_bytes()
 patterns=[rb'(?:cargo )?(1\.\d{1,3}\.\d+ \([0-9a-f]{7,40} 20\d\d-\d\d-\d\d\))',
           rb'(?:cargo )?(1\.\d{1,3}\.\d+)\x00(?:[^\x00]{0,60}\x00)?([0-9a-f]{7,40})\x00(20\d\d-\d\d-\d\d)']
 found=sorted(set(m.group(1).decode('ascii') for m in re.finditer(patterns[0],b)))
 local['cargo_static_full_version_strings']=found
 if len(found)==1: local['cargo_cli_version']=found[0]
 local['cargo_binary_sha256']=digest(b)
dump('local-toolchain.json',local)
# Bound each transfer with both curl's clock and a parent timeout; curl reads
# neither user configuration nor proxy/authorization environment variables.
CURL=shutil.which('curl')
def fetch(label,url):
 remaining=NET_END-time.monotonic()
 if remaining<1: return {'status':'UNKNOWN','reason':'TOTAL_NETWORK_DEADLINE','url':url}
 maxsec=min(7.0,remaining)
 dest=OUT/'official'/label
 begin=time.monotonic()
 args=[CURL,'--disable','--noproxy','*','--proto','=https','--proto-redir','=https',
  '--location','--max-redirs','2','--connect-timeout','3','--max-time',str(maxsec),
  '--retry','0','--silent','--show-error','--max-filesize','8388608',
  '--user-agent','KeelShell-readonly-dependency-audit/20261116','--output',str(dest),
  '--write-out','%{http_code}',url]
 try:
  p=subprocess.run(args,capture_output=True,text=True,timeout=maxsec+0.7,
   env={'PATH':'/usr/bin:/bin:/usr/sbin:/sbin'})
  meta={'url':url,'observed_at_utc':NOW(),'duration_seconds':round(time.monotonic()-begin,3),
   'curl_exit_code':p.returncode,'http_status':p.stdout.strip()[-3:]}
  # Retain only numeric error classification; stderr may contain proxy details.
  if p.returncode!=0 or meta['http_status']!='200':
   meta.update(status='UNKNOWN',reason=('TIMEOUT' if p.returncode==28 else 'HTTP_OR_TRANSFER_FAILURE'))
   return meta
  raw=dest.read_bytes()
  meta.update(status='VERIFIED',evidence_file=str(dest.relative_to(OUT)),sha256=digest(raw),bytes=len(raw))
  return meta
 except subprocess.TimeoutExpired:
  return {'url':url,'status':'UNKNOWN','reason':'PARENT_TIMEOUT_REAPED','duration_seconds':round(time.monotonic()-begin,3)}
def crate_job(name):
 attempts=[]
 api=fetch(name+'.json','https://crates.io/api/v1/crates/'+name)
 attempts.append(api)
 versions=[]; data=None
 if api['status']=='VERIFIED':
  try:
   data=json.loads((OUT/api['evidence_file']).read_text())
   versions=[{'version':v['num'],'yanked':v.get('yanked',False),'rust_version':v.get('rust_version'),
    'published_at':v.get('created_at')} for v in data['versions']]
  except (ValueError,KeyError,TypeError): api.update(status='UNKNOWN',reason='INVALID_API_RESPONSE')
 if not versions:
  n=name.lower()
  shard=('1/'+n if len(n)==1 else '2/'+n if len(n)==2 else '3/'+n[0]+'/'+n if len(n)==3 else n[:2]+'/'+n[2:4]+'/'+n)
  sparse=fetch(name+'.index.jsonl','https://index.crates.io/'+shard)
  attempts.append(sparse)
  if sparse['status']=='VERIFIED':
   try:
    versions=[{'version':v['vers'],'yanked':v.get('yanked',False),'rust_version':v.get('rust_version')}
     for line in (OUT/sparse['evidence_file']).read_text().splitlines() if line for v in [json.loads(line)]]
   except (ValueError,KeyError,TypeError): sparse.update(status='UNKNOWN',reason='INVALID_SPARSE_RESPONSE')
 stable=[v for v in versions if not v['yanked'] and key(v['version']) is not None]
 stable.sort(key=lambda v:key(v['version']))
 result={'status':'VERIFIED' if stable else 'UNKNOWN','attempts':attempts,
  'actual_latest_stable':stable[-1]['version'] if stable else 'UNKNOWN',
  'latest_definition':'highest SemVer stable, non-yanked, from live official crates.io API or sparse index',
  'api_newest_version':data.get('crate',{}).get('newest_version') if data else None,
  'api_max_version':data.get('crate',{}).get('max_version') if data else None,
  'api_max_stable_version':data.get('crate',{}).get('max_stable_version') if data else None,
  'latest_rust_version':stable[-1].get('rust_version') if stable else None,
  'requirements':{}}
 for req in sorted({e['requirement'] or '' for e in byname[name]}):
  allowed=[v for v in stable if compatible(v['version'],req)]
  result['requirements'][req]={'latest_compatible_stable':allowed[-1]['version'] if allowed else 'UNKNOWN',
    'actual_latest_satisfies_requirement':compatible(result['actual_latest_stable'],req) if stable else None}
 return name,result
results={}
with cf.ThreadPoolExecutor(max_workers=12) as pool:
 futures=[pool.submit(crate_job,name) for name in sorted(byname)]
 rust_future=pool.submit(fetch,'channel-rust-stable.toml','https://static.rust-lang.org/dist/channel-rust-stable.toml')
 checksum_future=pool.submit(fetch,'channel-rust-stable.toml.sha256','https://static.rust-lang.org/dist/channel-rust-stable.toml.sha256')
 for fut in cf.as_completed(futures):
  name,result=fut.result(); results[name]=result
 rust_remote=rust_future.result(); checksum=checksum_future.result()
if rust_remote['status']=='VERIFIED':
 try:
  raw=(OUT/rust_remote['evidence_file']).read_bytes(); manifest=tomllib.loads(raw.decode())
  rust_remote.update({'manifest_date':manifest.get('date'),
   'rustc_version':manifest.get('pkg',{}).get('rustc',{}).get('version'),
   'rust_version':manifest.get('pkg',{}).get('rust',{}).get('version'),
   'cargo_distribution_package_version':manifest.get('pkg',{}).get('cargo',{}).get('version')})
  if checksum['status']=='VERIFIED':
   expected=(OUT/checksum['evidence_file']).read_text().split()[0]
   rust_remote['checksum_matches']=digest(raw)==expected
 except (ValueError,KeyError,TypeError,IndexError): rust_remote.update(status='UNKNOWN',reason='INVALID_STABLE_MANIFEST')
rows=[]
for name in sorted(byname):
 refs=byname[name]; remote=results[name]
 direct=sorted(set(v for e in refs for v in e['direct_locked_versions']),key=lambda v:key(v) or (-1,-1,-1))
 transitive=sorted(set(p['version'] for p in registry_packages if p['name']==name and p['version'] not in direct),key=lambda v:key(v) or (-1,-1,-1))
 latest=remote['actual_latest_stable']
 conclusions=[]
 if remote['status']=='UNKNOWN': conclusions.append('UNKNOWN_LATEST')
 elif not direct: conclusions.append('UNKNOWN_DIRECT_LOCK')
 else:
  for version in direct:
   conclusions.append('AT_LATEST' if version==latest else 'LOCK_BEHIND_LATEST' if key(version) and key(version)<key(latest) else 'LOCK_AHEAD_OF_REGISTRY')
 row={'crate':name,'manifest_requirements':sorted(set(e['requirement'] or '' for e in refs)),
  'manifest_xy_policy':'PASS' if all(e['xy_policy']=='PASS' for e in refs) else 'FAIL',
  'direct_locked_versions':direct,'other_transitive_locked_versions':transitive,
  'actual_latest_stable':latest,'status':sorted(set(conclusions)),
  'official':remote,'occurrences':refs}
 rows.append(row)
final={str(p.relative_to(ROOT)):digest(p.read_bytes()) for p in input_paths}
summary={'started_at_utc':started,'completed_at_utc':NOW(),'script_elapsed_seconds':round(time.monotonic()-START,3),
 'investigation_budget_seconds':180,'network_window_seconds':55,'per_transfer_max_seconds':7,
 'workspace':str(ROOT),'head_at_start':head,'head_at_end':git('rev-parse','HEAD'),
 'manifest_count':len(manifest_paths),'unique_direct_registry_crates':len(rows),
 'manifest_registry_occurrences_including_workspace_definitions':len(entries),
 'explicit_requirement_count':sum(not e['inherited'] for e in entries),
 'xy_failures':sum(e['xy_policy']=='FAIL' for e in entries),
 'verified_latest_count':sum(r['actual_latest_stable']!='UNKNOWN' for r in rows),
 'unknown_latest_count':sum(r['actual_latest_stable']=='UNKNOWN' for r in rows),
 'direct_lock_resolution_issues':sum(bool(e['lock_resolution_issues']) for e in entries),
 'manifest_lock_hashes_before':initial,'manifest_lock_hashes_after':final,
 'manifest_lock_unchanged':initial==final,'parse_errors':errors,
 'local_toolchain':local,'official_rust_stable':rust_remote,'official_rust_stable_checksum':checksum,
 'constraints':{'cargo_executed':False,'rustc_executed':False,'clean_executed':False,
  'source_or_lock_written':False,'committed':False,'pushed':False,'created_chat_or_worktree':False},
 'dependencies':rows}
dump('audit.json',summary)
with (OUT/'dependencies.csv').open('w',newline='') as f:
 fields=['crate','manifest_requirements','manifest_xy_policy','direct_locked_versions','other_transitive_locked_versions','actual_latest_stable','latest_compatible_stable','actual_latest_satisfies_requirement','status','source_urls']
 writer=csv.DictWriter(f,fieldnames=fields); writer.writeheader()
 for r in rows:
  writer.writerow({'crate':r['crate'],'manifest_requirements':';'.join(r['manifest_requirements']),
   'manifest_xy_policy':r['manifest_xy_policy'],'direct_locked_versions':';'.join(r['direct_locked_versions']),
   'other_transitive_locked_versions':';'.join(r['other_transitive_locked_versions']),
   'actual_latest_stable':r['actual_latest_stable'],
   'latest_compatible_stable':';'.join(q+'='+v['latest_compatible_stable'] for q,v in r['official']['requirements'].items()),
   'actual_latest_satisfies_requirement':';'.join(q+'='+str(v['actual_latest_satisfies_requirement']) for q,v in r['official']['requirements'].items()),
   'status':';'.join(r['status']),'source_urls':';'.join(a['url'] for a in r['official']['attempts'])})
lines=['# KeelShell 依赖只读核对 — 2026-11-16','',
 f"基线 HEAD `{head}`；完成于 {summary['completed_at_utc']}。脚本耗时 {summary['script_elapsed_seconds']} 秒；每条 HTTPS GET 最多 7 秒、无重试，网络批次 55 秒截止。脚本计时不覆盖首次阅读；总计 180 秒时限以单独 timing_compliance 回执为准。",'',
 f"读取 {len(manifest_paths)} 个 manifest、Cargo.lock；{len(rows)} 个直接 registry 包、{len(entries)} 处依赖声明/继承引用、{summary['explicit_requirement_count']} 处显式版本要求。x.y 违规 {summary['xy_failures']}；直接 lock 解析问题 {summary['direct_lock_resolution_issues']}；manifest/lock 前后摘要一致：{initial==final}。",'',
 f"官方 actual latest 已核实 {summary['verified_latest_count']}，UNKNOWN {summary['unknown_latest_count']}。latest 定义为官方实时元数据中的最高稳定且未撤回版本；预发布及其他仅传递锁版本单列，不能当作直接依赖升级依据。",'',
 f"默认工具链 `{tool}`。安装清单 rustc `{local.get('rustc_distribution_version','UNKNOWN')}`；Cargo 内部发行包版本 `{local.get('cargo_distribution_package_version','UNKNOWN')}`，CLI 静态证据 `{local['cargo_cli_version']}`。未执行 rustc/cargo，因此没有运行时 --version 回执。PATH 命令位置与目录覆盖情况见 local-toolchain.json。",'',
 f"官方 Rust stable：{rust_remote.get('rustc_version','UNKNOWN')}；manifest 日期 {rust_remote.get('manifest_date','UNKNOWN')}；查询状态 {rust_remote['status']}。",'',
 '| 直接包 | manifest x.y | 直接 lock | official actual latest stable | 判定 |','| --- | --- | --- | --- | --- |']
for r in rows:
 lines.append('| '+r['crate']+' | '+', '.join(r['manifest_requirements'])+' | '+(', '.join(r['direct_locked_versions']) or 'UNKNOWN')+' | '+r['actual_latest_stable']+' | '+', '.join(r['status'])+' |')
lines+=['','没有更改正式源码或锁文件，没有调用 Cargo、rustc、clean，没有提交、推送、新建用户 chat/worktree；仅在本临时证据目录写入。没有实施任何依赖升级。','',
 '机器可读完整证据：audit.json；逐包表：dependencies.csv；本机工具链：local-toolchain.json；官方响应与 SHA-256：official/。','',
 '限制：本核对不运行构建或 dependency policy gate，不判定新版本的工程兼容性，不替代 Windows 归档修复/CI/原生验收。网络失败明确 UNKNOWN，不复用历史最新版本结论。']
(OUT/'report.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({k:summary[k] for k in ['completed_at_utc','script_elapsed_seconds','manifest_count','unique_direct_registry_crates','manifest_registry_occurrences_including_workspace_definitions','explicit_requirement_count','xy_failures','verified_latest_count','unknown_latest_count','direct_lock_resolution_issues','manifest_lock_unchanged']},ensure_ascii=False))
print(json.dumps({'official_rust_stable_status':rust_remote['status'],'official_rustc':rust_remote.get('rustc_version','UNKNOWN'),'local_cargo_static_cli':local['cargo_cli_version'],'files':['report.md','dependencies.csv','audit.json','local-toolchain.json']},ensure_ascii=False))
