# KeelShell 依赖只读核对 — 2026-11-16

基线 HEAD `f4299487c132180e484008326c5b52682b3a753f`；完成于 2026-11-16T04:25:41.666915+00:00。脚本耗时 18.461 秒；每条 HTTPS GET 最多 7 秒、无重试，网络批次 55 秒截止。时限未达标：从最早已记录阅读时点到查询结束至少 180.235 秒，且首次阅读更早；不能宣称满足总计 180 秒限制。查询后停止追加网络调查。

读取 7 个 manifest、Cargo.lock；37 个直接 registry 包、112 处依赖声明/继承引用、38 处显式版本要求。x.y 违规 0；直接 lock 解析问题 0；manifest/lock 前后摘要一致：True。

官方 actual latest 已核实 16，UNKNOWN 21。latest 定义为官方实时元数据中的最高稳定且未撤回版本；预发布及其他仅传递锁版本单列，不能当作直接依赖升级依据。

默认工具链 `stable-aarch64-apple-darwin`。安装清单 rustc `1.100.0 (0ef1bc386 2026-11-09)`；Cargo 内部发行包版本 `0.101.0 (3acc79c0c 2026-11-05)`，CLI 静态证据 `UNKNOWN`。未执行 rustc/cargo，因此没有运行时 --version 回执。PATH 命令位置与目录覆盖情况见 local-toolchain.json。Cargo CLI 版本保持 UNKNOWN，不将内部发行包 0.101.0 误当作 cargo --version。

官方 Rust stable：UNKNOWN；manifest 日期 UNKNOWN；查询状态 UNKNOWN。

| 直接包 | manifest x.y | 直接 lock | official actual latest stable | 判定 |
| --- | --- | --- | --- | --- |
| alacritty_terminal | 0.26 | 0.26.0 | 0.26.0 | AT_LATEST |
| argon2 | 0.6 | 0.6.0 | 0.6.0 | AT_LATEST |
| base64 | 0.23 | 0.23.1 | 0.23.1 | AT_LATEST |
| calcifer-macos-acl | 0.1 | 0.1.0 | 0.1.0 | AT_LATEST |
| chacha20poly1305 | 0.11 | 0.11.0 | 0.11.0 | AT_LATEST |
| chrono | 0.4 | 0.4.45 | 0.4.45 | AT_LATEST |
| directories | 6.0 | 6.0.0 | 6.0.0 | AT_LATEST |
| encoding_rs | 0.8 | 0.8.44 | 0.8.44 | AT_LATEST |
| flate2 | 1.1 | 1.1.11 | 1.1.11 | AT_LATEST |
| gpui-kit | 0.9 | 0.9.1 | 0.9.1 | AT_LATEST |
| hmac | 0.13 | 0.13.0 | 0.13.0 | AT_LATEST |
| image | 0.25 | 0.25.10 | 0.25.10 | AT_LATEST |
| nix | 0.32 | 0.32.0 | 0.32.0 | AT_LATEST |
| process-wrap | 10.0 | 10.0.1 | 10.0.1 | AT_LATEST |
| rand | 0.10 | 0.10.4 | 0.10.4 | AT_LATEST |
| reqwest | 0.13 | 0.13.5 | UNKNOWN | UNKNOWN_LATEST |
| rmcp | 3.10 | 3.10.0 | UNKNOWN | UNKNOWN_LATEST |
| russh | 0.65 | 0.65.1 | UNKNOWN | UNKNOWN_LATEST |
| russh-sftp | 3.0 | 3.0.1 | 3.0.1 | AT_LATEST |
| rust-embed | 8.14 | 8.14.0 | UNKNOWN | UNKNOWN_LATEST |
| rustix | 1.1 | 1.1.6 | UNKNOWN | UNKNOWN_LATEST |
| serde | 1.0 | 1.0.229 | UNKNOWN | UNKNOWN_LATEST |
| serde_json | 1.0 | 1.0.154 | UNKNOWN | UNKNOWN_LATEST |
| sha2 | 0.11 | 0.11.1 | UNKNOWN | UNKNOWN_LATEST |
| tar | 0.4 | 0.4.46 | UNKNOWN | UNKNOWN_LATEST |
| tempfile | 3.27 | 3.27.0 | UNKNOWN | UNKNOWN_LATEST |
| thiserror | 2.0 | 2.0.21 | UNKNOWN | UNKNOWN_LATEST |
| tokio | 1.54 | 1.54.1 | UNKNOWN | UNKNOWN_LATEST |
| tokio-util | 0.7 | 0.7.20 | UNKNOWN | UNKNOWN_LATEST |
| toml | 1.2 | 1.2.1+spec-1.1.0 | UNKNOWN | UNKNOWN_LATEST |
| url | 2.5 | 2.5.8 | UNKNOWN | UNKNOWN_LATEST |
| uuid | 1.29 | 1.29.2 | UNKNOWN | UNKNOWN_LATEST |
| win32job | 2.1 | 2.1.0 | UNKNOWN | UNKNOWN_LATEST |
| windows-sys | 0.61 | 0.61.2 | UNKNOWN | UNKNOWN_LATEST |
| winresource | 0.1 | 0.1.34 | UNKNOWN | UNKNOWN_LATEST |
| zeroize | 1.9 | 1.9.1 | UNKNOWN | UNKNOWN_LATEST |
| zip | 9.6 | 9.6.0 | UNKNOWN | UNKNOWN_LATEST |

没有更改正式源码或锁文件，没有调用 Cargo、rustc、clean，没有提交、推送、新建用户 chat/worktree；仅在本临时证据目录写入。没有实施任何依赖升级。

机器可读完整证据：audit.json；逐包表：dependencies.csv；本机工具链：local-toolchain.json；官方响应与 SHA-256：official/。

限制：本核对不运行构建或 dependency policy gate，不判定新版本的工程兼容性，不替代 Windows 归档修复/CI/原生验收。网络失败明确 UNKNOWN，不复用历史最新版本结论。
