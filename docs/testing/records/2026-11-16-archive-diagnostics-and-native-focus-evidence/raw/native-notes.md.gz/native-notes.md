# Native focus follow-up, 2026-11-16

The new CUA observation used an isolated macOS arm64 application with an owned
localhost OpenSSH/SFTP fixture. The host fingerprint was compared with the
independently generated server key before accepting it. UI actions used CUA only.

The staged normal GUI/MCP binaries were reused from the prior source
`9d0f886acda4e48058004a28f85ef1fa3c510d4c`, with hashes respectively
`af2a88364650b90b5dfab4ca8a4655a8430febc4971f575c7a7fd0fde19eb9a3`
and `0e5efdcbe2069fb4ea3c809a99419c557d11ba0ba18e7ba8e5fc6ea0e9bde816`.
The current candidate changes only the cfg(test) archive test module. It does
not rebuild or change normal application code. The packaging manifest observes
the staging checkout's HEAD/dirty state; it is not a fresh-build receipt for these
normal binaries. Packaging and native static inspection both exited 0.

Initial setup through the connection-library container did not activate a
connection. The quick-connect fields and explicit authentication/host-key dialogs
were then used successfully. Local directories were loaded with the refresh
button; no Enter-to-load result is claimed.

CUA `typeText` initially omitted the Chinese characters in the synthetic command.
The complete 149-byte draft was subsequently installed using the real input's AX
`setValue`. This is not an IME or Unicode keyboard-entry test. The unchanged
original initial capture is `focus-native-r1/cua/draft.ax.txt`.

The first reverse walk had 38 entries on each side. At step 89 the visible remote
row checkbox had focus, and at step 100 the remote list root had its accent frame.
This walk stopped there; it is not a completed two-list scenario. The many row
controls require many Tab stops; no claim of optimal keyboard efficiency is made.

Both file lists were then explicitly browsed to `alpha-folder`, each containing
only `child.txt`. Starting from a real click in the composer for each direction:

- Reverse Shift+Tab: remote list root at 26, local list root at 32.
- Forward Tab: local list root at 29, remote list root at 35.

The four unmodified `small-{reverse,forward}-{26,32,29,35}.png` captures, using the
applicable direction/step pairs above, visibly show the accent frame around the
corresponding list. CUA's AX focus summary reports the window root throughout;
it cannot certify the exact focused child. Focus claims here use the original
screenshots, while draft claims use exact full AX value bytes.

All 100 initial and 67 complete-scenario navigation snapshots have exactly the
same 149 draft bytes. `navigation-byte-verification.json` re-extracts the whole
value and compares equality; it does not rely on the earlier endsWith check.
The synthetic execution marker was absent at final observation. All 36 seeded
files, the welcome file and the nested child retained exact bytes. Marker absence
does not establish zero outbound PTY writes.

The fixture controller received stop and exited 0/reaped. All three owned roots
stopped; both listening ports closed; the private directory is absent. The
post-cleanup birth-identity inventory normalizes JSON tuples and includes a live
JSON-roundtrip positive control: 76 recorded identities, zero live matches.

Scope: Frost light, Chinese UI, one macOS window at its observed size, one-entry
lists, unchanged normal binaries. Other themes, platforms, window sizes, IME,
VoiceOver, raw PTY auditing and the complete product remain unverified here.
