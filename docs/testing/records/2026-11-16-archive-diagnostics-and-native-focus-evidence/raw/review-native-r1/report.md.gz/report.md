APPROVE

P0: 0；P1: 0；P2: 0；P3: 0。实际执行产品测试数：0；原生 UI 重放次数：0。

2026-11-16，新非作者对既存原生证据的只读复核。本报告仅批准下述限定观察及 `native-notes.md` 对它们的表述；不签署 Windows 归档修复、完整工程门禁、CI、发行或完整产品验收。已读根 AGENTS.md、其引用的 RTK.md 及 docs/HANDOFF.md 最新交接段。唯一写入为本报告；没有运行 Cargo/rustc、测试程序、原生应用、夹具或清理程序，没有修改源码/target，也没有提交或推送。

复核时 HEAD 为 `f4299487c132180e484008326c5b52682b3a753f`。只读 Git 查询显示，相对 `9d0f886acda4e48058004a28f85ef1fa3c510d4c` 的 crates 差分仅为 `crates/keelshell-app/src/files/archive_tests.rs`，该文件当时为未提交修改；本次不进行该测试补丁的源码评审。

亲自使用 view_image 查看了七张未编辑的原始 PNG：指定的四张列表焦点图、两张 small 起始图，以及最初 draft.png。两张 small 起始图均显示 composer 的焦点轮廓和末尾插入光标，列表各仅一条 child.txt，与记录的真实点击起点一致。截图支持以下可见 accent 框观察：

| 方向与步骤 | 原始 PNG（位于 focus-native-r1/cua/） | 亲眼观察 |
| --- | --- | --- |
| Shift+Tab 26 | small-reverse-26.png | 远程文件列表外框为 accent |
| Shift+Tab 32 | small-reverse-32.png | 本地文件列表外框为 accent |
| Tab 29 | small-forward-29.png | 本地文件列表外框为 accent |
| Tab 35 | small-forward-35.png | 远程文件列表外框为 accent |

对应表述位于 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-archive-fix-20261116/native-notes.md:31`。每方向均为一次从 composer 起点到达两列表的有限路径；不扩展为闭环回到 composer 或任意列表规模验收。初次每侧 38 项的 100 步保留为未完成双列表的历史观察；其 progress 文件记录步骤 2–100，步骤 1 单独保存在 reverse-first.ax.txt，二者无缺号。本次完整的单条目场景为反向 32 步加正向 35 步，共 67 步。

本次自行以只读 Python 提取全部 167 份原始 AX 中唯一 composer 的完整 Value，保留四个前导空格，不使用 strip 或 endsWith。文件集合精确覆盖初次 100 步与完整场景 67 步；167/167 全值均等于 navigation-result.json 中的 149 个 UTF-8 字节，167/167 原始 AX 摘要及草稿摘要均与 navigation-byte-verification.json 的逐项记录相同，零差异。统一草稿 SHA-256 为 `477afc35ee18681f4c8368995956cfb0239a11e6bc8531afeb43051cdd4461d9`。这属于静态证据核对，不计作执行产品测试。

两张 small 起始 AX 与 draft-ax-set.ax.txt 同样为完整 149 字节；最初 draft.ax.txt 为 131 字节，确实缺少“中文焦点检查”，draft.png 也显示空引号。故仅认可 AX setValue 后的草稿保持，不签署 CUA typeText 的中文输入或 IME。167 份 AX 的 focus summary 全部为 `The focused UI element is 0 标准窗口 KeelShell, Secondary Actions: Raise`；不能据此签署 AX focused child 或 VoiceOver 焦点。列表焦点结论仅来自上表原始截图。参见 `native-notes.md:21`、`:37`、`:43` 及各 AX 第 53 行。

已核对 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-archive-fix-20261116/focus-native-r1/fixture-readback.json:2`：36 个 seed 的 exact_hashes_unchanged、child/welcome 字节保持及 execution_marker_absent 均为 true；session-live 与 session-final 的 36 项 seed SHA-256 完全相同，且可从保留的 native_fixture.py 内容定义重算一致。最终文件保持与 marker absent 是既存现场读回结果；夹具已回收，本次没有重新读取已删除的现场文件。marker absent 不能推出 raw PTY 零出站，原笔记 `native-notes.md:46` 已保留此限制。

已核对 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-archive-fix-20261116/focus-native-r1/cleanup-readback.json:2`：owned_identities=76、live_birth_matches=[]、json_roundtrip_live_identity_positive_control=true、roots_stopped=3、target/jump ports_closed 均 true、private_root_absent=true、fixture_controller_exit=0、controller_reaped=true。session-final 的 76 项身份均包含可规范化的三项 Darwin birth 数组，process_cleanup 为三个 true，两端口分别为 51695/51696 且均记录 closed，scratch_absent=true，没有 ended_early/deadline_reached 标记。批准的是这组既存清理回执及其交叉一致性；没有重新枚举现场进程、连接端口或重做正控，不把回执布尔值表述成本复核员独立重放的结果。

暂存包仅作字节与来源边界交叉核对。实际重算 manifest 列出的全部五个包内文件摘要，均匹配。normal GUI/MCP 的 Mach-O 头均为 arm64，其 SHA-256 分别为：

- GUI：`af2a88364650b90b5dfab4ca8a4655a8430febc4971f575c7a7fd0fde19eb9a3`
- MCP：`0e5efdcbe2069fb4ea3c809a99419c557d11ba0ba18e7ba8e5fc6ea0e9bde816`

GUI 摘要还与 session-live/session-final 的实际启动程序摘要一致。两者与用户指定的原 9d0f886 字节及 native-notes.md:7 一致。既存 package-r1.json 和 package-inspect-r1.json 均记录 observed/controller exit 0、direct_reaped=true、零活动进程；本次未重跑打包或检查。package-manifest.json 的 build.commit 实际为 null、workflow_run 为 null，含 rustc 版本文本；这些暂存元数据不能当作当前 HEAD/dirty 候选的新编译或完整门禁回执。

观察限制：仅 Frost light、中文界面、macOS arm64、截图所示单窗口及尺寸、各一条文件的本地/远程列表、沿用的正常二进制。其他主题、窗口/尺寸、Windows/Linux、IME、VoiceOver、精确 AX focused child、raw PTY 审计和完整产品均未验。前述 38 项历史路径未完成双列表；本报告不予补签。连接建立、主机指纹及 controller stop 的过程仅按既存笔记/回执理解，没有新增独立现场观察。父门禁和 CI 不计入本复核员执行测试数。

固定证据摘要（均在本次只读核对时计算，路径相对 work/windows-archive-fix-20261116）：

| 文件 | SHA-256 |
| --- | --- |
| native-notes.md | e91f7449cf4c7bdaac41cff90622fc5d6bb1cfe643f24d66515ecdbe9affa44e |
| focus-native-r1/navigation-byte-verification.json | 6ac63f71f87cf7d2f2ceb83e91d41a706d2992157885fcf3ee3c8941ede04019 |
| focus-native-r1/fixture-readback.json | 9f872edfa5694bd765e79c92acbf8fd7bee6b220f543193e357143283de434f8 |
| focus-native-r1/cleanup-readback.json | 0e197c20d8cfedf0735bd1c5e82c251ab2d68c28d28c053167e906055ac4b2bc |
| focus-native-r1/session-final.json | 23d60d30bd2fb9870732b171485b78548f519dccdcbf17320083c1e8ab924155 |
| focus-native-r1/cua/small-reverse-26.png | 603176c58fe3a6770af020eada4090ed7602548da8c226d0300d7deaa10aa542 |
| focus-native-r1/cua/small-reverse-32.png | 2f2acdb75c15726d314e30a66e8fe4b81d8aaaf6205ec688ddc7c722d31c6576 |
| focus-native-r1/cua/small-forward-29.png | 3f4110a6de0aa1aede5c60d523e0e6b42ad3b7b6ef5f14a21f7d6aecdc8f7427 |
| focus-native-r1/cua/small-forward-35.png | 603176c58fe3a6770af020eada4090ed7602548da8c226d0300d7deaa10aa542 |
