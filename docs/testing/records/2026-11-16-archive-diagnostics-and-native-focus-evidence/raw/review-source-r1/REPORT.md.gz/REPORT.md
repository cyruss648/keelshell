# Windows 归档测试诊断候选 r1：非作者严格只读复核

复核日期：2026-11-16。建议 **APPROVE，仅适用于此测试诊断候选**。
开放发现：**P0=0、P1=0、P2=0、P3=0**。
这不是 Windows 根因修复批准；原八项 Windows 失败继续保持 **UNKNOWN**。

## 范围与身份核对

- 仓库：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`。
- 实际 HEAD 与指定基线均为 `f4299487c132180e484008326c5b52682b3a753f`。
- 唯一候选源码：
  `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/archive_tests.rs`。
- 已读根目录 `AGENTS.md`、其引用的 `/Users/hdh/.codex/RTK.md`、
  `docs/HANDOFF.md` 最新段和 `docs/testing/SHARED_TARGET.md`。
- 本 reviewer 没有编写或修改候选源码。使用 Rust Best Practices / Rust Engineer
  的源码审查与测试检查指导；用户的严格只读指令优先于技能中的构建建议。
- 执行前后 Git 状态相同，只有上述候选文件修改。没有运行 Cargo、rustc、
  clean、fmt、Clippy、全仓构建、commit 或 push；没有主动写入 target。
  所有新增复核文件均位于本目录。

冻结与现源逐项核对通过，执行前后均无输入集合或字节漂移：

| 对象 | SHA-256 |
| --- | --- |
| 718 inputs aggregate | `e967a7619be613cca5c3fc103f4a6d3c8ad2ad746caacc32386cf169820dd1ff` |
| `source-inputs-r1.json` 文件 | `6b2035d5c4faa819889867efa76400dca56a666004b9647738b3b9549b241f9a` |
| `candidate-r1.patch` | `7552d8918dad1805082a4f9cb9b51e6d55783120bb9c017ae36e8175cde8a3aa` |
| 候选源码文件 | `8b7655066bac425e2bb73c7344eeeee76f3b67f78df1e66771ad9c2d1b6b1ed3` |
| 父 `app-inventory-r1.log` | `012bb4d9616b30ea402a7091914802b676ec515003f3515d611c3fcb70eae10a` |
| 实际执行的预构建二进制，pre/post 相同 | `4c255f76c9dcca152d8869264d0df1f89c7f8481a550a1c21781cd63e2277488` |

实际 `git diff --no-ext-diff <baseline> -- <candidate>` 与冻结补丁逐字节一致。
718 项同时核对清单内摘要及 Git 可见非 docs 工程路径集合，没有增项或漏项。
原有测试正文逐字节保持：原 `reviewed` 之前的代码保留，
首个 `archive_zip_upload...` 测试起直到文件结尾与基线完全相同。
原有 10 项当前平台测试及其配置边界未改写。

## 源码与功能检查

以下行号均指上面的唯一候选源码绝对路径。

1. **审核、确认及无覆盖断言保留。**
   第 274–279 行仍要求 `TransferArchive`、中英文完整清单文字及非空成员，
   仍仅返回原计划的 clone。第 335–340 行保留确认前目标 absent 和独立确认动作；
   第 404–420 行保留提取前不创建目标与确认后的字节/空目录核验；
   第 458–473 行保留取消、旧审核重放拒绝及零原子写入；
   第 525–534 行保留并发既有目标字节和禁止新增文件断言。
   此外测试正文的整体字节比较覆盖这些局部检查。

2. **UNKNOWN 语义完整保留。**
   第 8–18 行仍断言不确定结果为 `OutcomeUncertain`、保持关闭 hold、
   终态为 `TransferPhase::Uncertain`。
   第 590–635 行仍验证已发 WRITE 取消后的未知状态、目标隔离、
   关闭 hold 及 quarantine，后续已验证上传成功不能解除旧未知写入。
   这些测试在本次预构建执行中均通过。

3. **新增失败诊断没有原样输出路径、peer text、状态正文、操作 payload 或凭据。**
   第 93–103 行 `pending_kind` 仅返回四个固定标签，不格式化 payload。
   第 118–197 行只返回固定的 stage/kind/reason 和受限数字。
   第 281–310 行的其余数据为布尔值、计数、固定控件 ID、
   控件可见/禁用状态和几何边界；未格式化 Message、plan、session、
   本地/远程选择项或隔离路径。
   `other-redacted` 保留无法分类的情况，没有把任意细节插入返回值。

4. **numeric suffix 有边界，不被解释为根因证据。**
   第 106–115 行只接受字符串末尾 `(os error <digits>)` 的最后一个候选：
   非空、最多 10 字节、全 ASCII 数字且成功解析为 `u32`。
   只在 I/O 或 worker-start 分支提取；SFTP/SSH 等 peer 文本不提取该数字。
   第 195–196 行明确这只是 display string 的解析值，
   不是保留的 typed `io::Error` 或某个失败 native syscall 的证据。

5. **`track_caller` 对目标失败分支实际有效，未错误地依赖闭包传播。**
   第 271–272 行标记的是被直接调用的 `reviewed`。
   缺少审核的分支在 `read_with` 闭包内仅形成 `Err`；
   最终第 315–318 行的 `panic!` 位于该函数体内。
   直接调用点为第 335、401、458、485、525、546、559、590、612、662 行。
   因此该缺审 panic 的 caller 归属是具体测试调用处。
   这项结论来自源码检查；本次未人为触发缺审 panic 来采集运行时 panic hook。
   第 276–278 行仍在闭包内的原有成功分支断言，不属于上述 caller 传播承诺。

6. **没有吞失败、无故 skip 或诊断重试。**
   缺审核时仍必然失败；`Err` 没有转换为成功、空计划或提前返回。
   新代码没有 `ignore`、`should_panic`、`catch_unwind`、重试循环、
   平台绕过或延长等待；原测试的 cfg 和 bounded waits 保留。
   控件采集没有点击、确认或重新准备归档。
   本 reviewer 只运行一次清单命令和一次指定专项，没有失败重试。

7. **两新增测试对本候选的窄诊断合同足够。**
   第 201–241 行包含 4 组 detail 精确结果比较及 1 个未知状态比较；
   第 245–267 行另含 4 组精确结果比较，共 **9 个期望输出场景**。
   覆盖 I/O 数字后缀、SFTP peer 字样与同型后缀不透传、
   `u32` 溢出、后缀后追加换行/peer text、未知状态、固定 alias 分类、
   timeout、审核失效和 worker-start 数字后缀。
   精确字符串比较同时约束固定分类及私有 fixture 文本不进入输出。
   没有穷举全部固定分类，空数字/符号/非 ASCII/恰好 `u32::MAX` 等也没有单列动态
   用例；对应拒绝/范围由上述非空、长度、ASCII 和 `u32` 解析条件静态核对。
   未发现需要为此候选阻塞合入的测试缺口，不把它解释为完整 Windows 错误覆盖。

## 实际执行

先核对父库存日志与其成功回执摘要；该日志第 1 行记录当前 checkout 的 app 编译路径，
第 8 行 `Running` 给出实际可执行文件。父库存共 **1341 tests**，
含两个新增具体名字。随后直接对该可执行文件执行 `archive_tests:: --list`，
实际列出 **12 个**名字，与父库存的本模块名字逐项一致，含两个新增测试。
执行前已确认现源满足指定 718 项冻结。

实际可执行文件：

```text
/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/recovery-batch-integration-20261115/target/debug/build/keelshell-app/bb7e65d3f7e183e9/out/keelshell_app-bb7e65d3f7e183e9
```

使用 `subprocess.run(..., timeout=60, check=False)`，cwd 为指定仓库，
stdout/stderr 写本复核目录，显式记录退出并回收直接子进程。实际两条命令为：

```text
<上述二进制> files::transfer_tests::archive_tests:: --list
<上述二进制> files::transfer_tests::archive_tests:: --test-threads=4
```

| 命令 | exit | timeout | 用时 | 实际结果 |
| --- | --- | --- | --- | --- |
| live inventory | 0 | false | 0.021723s | 12 个具体名逐项相同 |
| archive tests | 0 | false | 2.482594s | 12 passed / 0 failed / 0 ignored；1329 filtered out |

实际测试为原有 10 项加新增 2 项；清单命令不计为测试。
测试日志 SHA-256：`8136b1690e0efac0b58f07e2c903a43fa15b98a0ab511db796014c6271de9510`。
执行环境为本机 macOS arm64。
二进制摘要、inode、mtime、size 及所有输入的 pre/post 比较一致。

可核验原件：

- [执行前快照](pre.json) / [执行后快照](post.json)
- [摘要与命令比较](hash-comparison.json)
- [原测试保留检查](preserved-tests.json)
- [实际清单](live-inventory.log) / [退出与摘要](live-inventory.json)
- [12 项实际日志](archive-tests.log) / [退出与摘要](archive-tests.json)
- [本次读取、核对和执行脚本](verify_and_run.py)

## 限制与建议

**APPROVE 仅表示这一个文件的测试诊断候选可接受。**
这是新非作者源码复核及父预构建测试程序的独立执行，**没有独立重新编译**。
库存、当前冻结及执行前后摘要支持本次预构建执行的范围；
它们不等同于 reviewer 重新构建的二进制来源证明。
没有 Windows 执行、真实桌面/辅助技术验收或原八项 Windows 失败复现。
这些失败的底层原因仍 UNKNOWN；不能因本机 12 项通过宣称修复。
完整门禁由父任务负责，本次没有执行、等待、采集或代签完整门禁结果。
父任务可能同时写自己的 target；本次只证明 reviewer 未发起 target 写操作、
所用二进制前后摘要不变，不声称整个 target 目录静止。
未为文档另启复核循环。
