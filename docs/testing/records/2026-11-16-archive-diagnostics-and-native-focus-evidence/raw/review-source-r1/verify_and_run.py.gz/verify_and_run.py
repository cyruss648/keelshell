"""Read-only candidate checks and bounded execution of the parent's test binary."""
import hashlib
import json
import os
import platform
from pathlib import Path
import re
import subprocess
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
EVIDENCE = OUT.parent
BASE = "f4299487c132180e484008326c5b52682b3a753f"
SOURCE = "crates/keelshell-app/src/files/archive_tests.rs"
AGGREGATE = "e967a7619be613cca5c3fc103f4a6d3c8ad2ad746caacc32386cf169820dd1ff"
PATCH = "7552d8918dad1805082a4f9cb9b51e6d55783120bb9c017ae36e8175cde8a3aa"
PREFIX = "files::transfer_tests::archive_tests::"
NEW = {
    PREFIX + "archive_review_status_diagnostics_redact_peer_and_path_text",
    PREFIX + "archive_review_status_diagnostics_distinguish_rejected_and_stale_preparation",
}
ENV = dict(os.environ, GIT_OPTIONAL_LOCKS="0")


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def git(*args):
    return subprocess.check_output(
        ["git", *args], cwd=ROOT, env=ENV, timeout=30
    )


def save(name, value):
    with (OUT / name).open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


inventory_path = EVIDENCE / "app-inventory-r1.log"
inventory = inventory_path.read_text()
receipt = json.loads((EVIDENCE / "app-inventory-r1.json").read_text())
assert receipt["observed_exit"] == 0 and not receipt["timed_out"]
assert sha(inventory_path) == receipt["log_sha256"]
running = re.search(r"Running unittests .*? \(([^\n]+)\)", inventory)
assert running
binary = (ROOT / running.group(1)).resolve(strict=True)
assert binary.is_relative_to(Path(receipt["cargo_target"]).resolve())
all_names = re.findall(r"^(.+): test$", inventory, re.MULTILINE)
names = sorted(name for name in all_names if name.startswith(PREFIX))
assert len(names) == 12 and NEW <= set(names)
freeze_path = EVIDENCE / "source-inputs-r1.json"
freeze = json.loads(freeze_path.read_text())
assert freeze["count"] == len(freeze["inputs"]) == 718


def snapshot():
    actual = [
        {"path": row["path"], "sha256": sha(ROOT / row["path"])}
        for row in freeze["inputs"]
    ]
    paths = git("ls-files", "--cached", "--others", "--exclude-standard", "-z")
    current_set = {
        name.decode()
        for name in paths.split(b"\0")
        if name and not name.startswith(b"docs/") and (ROOT / name.decode()).is_file()
    }
    original_set = {row["path"] for row in freeze["inputs"]}
    assert current_set == original_set
    assert actual == freeze["inputs"]
    aggregate = hashlib.sha256(
        "".join(f"{row['path']}\0{row['sha256']}\n" for row in actual).encode()
    ).hexdigest()
    assert aggregate == freeze["aggregate_sha256"] == AGGREGATE
    patch = EVIDENCE / "candidate-r1.patch"
    assert sha(patch) == PATCH
    assert git("diff", "--no-ext-diff", BASE, "--", SOURCE) == patch.read_bytes()
    assert git("rev-parse", "HEAD").decode().strip() == BASE
    stat = binary.stat()
    return {
        "head": BASE,
        "input_count": len(actual),
        "aggregate_sha256": aggregate,
        "source_sha256": sha(ROOT / SOURCE),
        "patch_sha256": sha(patch),
        "manifest_sha256": sha(freeze_path),
        "inventory_sha256": sha(inventory_path),
        "inventory_test_count": len(all_names),
        "selected_names": names,
        "binary_path": str(binary),
        "binary_sha256": sha(binary),
        "binary_size": stat.st_size,
        "binary_mtime_ns": stat.st_mtime_ns,
        "binary_inode": stat.st_ino,
        "git_status": git("status", "--short").decode(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "inputs": actual,
    }


source = (ROOT / SOURCE).read_bytes()
base_source = git("show", f"{BASE}:{SOURCE}")
marker = b"\n#[gpui_kit::test]\nasync fn archive_zip_upload_requires_confirmation_and_preserves_exact_binary_members("
assert source[source.index(marker):] == base_source[base_source.index(marker):]
assert source.startswith(base_source[:base_source.index(b"fn reviewed(")])
pre = snapshot()
save("pre.json", pre)
save("preserved-tests.json", {
    "all_original_test_bodies_byte_identical": True,
    "prefix_before_original_reviewed_byte_identical": True,
    "two_new_test_names_in_parent_inventory": sorted(NEW),
})
results = []
try:
    for label, args in [
        ("live-inventory", [str(binary), PREFIX, "--list"]),
        ("archive-tests", [str(binary), PREFIX, "--test-threads=4"]),
    ]:
        log = OUT / f"{label}.log"
        started = time.monotonic()
        command = {"command": args, "timeout_seconds": 60, "timed_out": False}
        with log.open("xb") as stream:
            try:
                process = subprocess.run(
                    args, cwd=ROOT, env=ENV, stdout=stream,
                    stderr=subprocess.STDOUT, timeout=60, check=False,
                )
                command.update(exit_code=process.returncode, direct_reaped=True)
            except subprocess.TimeoutExpired:
                command.update(exit_code=None, timed_out=True, direct_reaped=True)
        command.update(
            seconds=time.monotonic() - started, log_sha256=sha(log),
            log_bytes=log.stat().st_size,
        )
        save(f"{label}.json", command)
        results.append(command)
        assert command["exit_code"] == 0 and not command["timed_out"]
        if label == "live-inventory":
            live = re.findall(r"^(.+): test$", log.read_text(), re.MULTILINE)
            assert sorted(live) == names
        else:
            text = log.read_text()
            passed = re.findall(r"^test (.+) \.\.\. ok$", text, re.MULTILINE)
            assert sorted(passed) == names
            assert "12 passed; 0 failed; 0 ignored;" in text
finally:
    post = snapshot()
    save("post.json", post)
    save("hash-comparison.json", {
        "snapshots_equal": pre == post,
        "source_and_all_718_inputs_unchanged": pre["inputs"] == post["inputs"],
        "binary_sha256_pre": pre["binary_sha256"],
        "binary_sha256_post": post["binary_sha256"],
        "binary_stat_unchanged": all(pre[k] == post[k] for k in (
            "binary_size", "binary_inode", "binary_mtime_ns"
        )),
        "commands": results,
        "independent_recompile": False,
        "target_written_by_reviewer": False,
    })
print(json.dumps({
    "input_count": pre["input_count"],
    "aggregate_sha256": pre["aggregate_sha256"],
    "binary_sha256": pre["binary_sha256"],
    "snapshots_equal": pre == post,
    "commands": results,
}, indent=2))
