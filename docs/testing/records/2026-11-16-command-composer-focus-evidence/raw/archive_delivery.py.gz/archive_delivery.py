"""Archive owned batch originals and retain reproducible artifact identities."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path.cwd()
SOURCE = ROOT / "work/composer-focus-integration-20261116"
DESTINATION = ROOT / "docs/testing/records/2026-11-16-command-composer-focus-evidence"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def omitted_reason(relative):
    if "__pycache__" in relative.parts or relative.suffix == ".pyc":
        return "reproducible Python cache"
    if relative.as_posix().startswith("package-r1/KeelShell.app/"):
        return "reproducible staged native application; complete manifest retained"
    if relative.as_posix() == "native_ax":
        return "compiled native observer; sources and build receipts retained"
    return None


def main():
    assert not DESTINATION.exists()
    assert (SOURCE / "final-gate-summary.json").is_file()
    assert (SOURCE / "review-native-r1/verification.json").is_file()
    assert list((SOURCE / "review-native-r1").glob("*.md")), "Keep the completed native review"
    assert not any(path.is_symlink() for path in SOURCE.rglob("*"))
    originals = sorted(path for path in SOURCE.rglob("*") if path.is_file())
    manifest = {}
    omitted = []
    for path in originals:
        relative = path.relative_to(SOURCE)
        data = path.read_bytes()
        reason = omitted_reason(relative)
        if reason:
            omitted.append({
                "path": relative.as_posix(), "bytes": len(data),
                "sha256": sha(data), "reason": reason,
            })
            continue
        artifact = "raw/" + relative.as_posix() + ".gz"
        output = DESTINATION / artifact
        output.parent.mkdir(parents=True, exist_ok=True)
        compressed = gzip.compress(data, mtime=0)
        with output.open("xb") as stream:
            stream.write(compressed)
        assert gzip.decompress(compressed) == data
        manifest[relative.as_posix()] = {
            "artifact": artifact, "source_bytes": len(data),
            "source_sha256": sha(data), "artifact_sha256": sha(compressed),
        }
    previews = []
    for source, name in [
        ("native-frost-r1/frost-r3-draft.png", "native-command-draft.png"),
        ("native-frost-r1/frost-r3-reverse-first.png", "native-first-reverse-tab.png"),
    ]:
        destination = DESTINATION / "previews" / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(SOURCE / source, destination)
        assert sha(destination.read_bytes()) == manifest[source]["source_sha256"]
        previews.append({
            "path": destination.relative_to(DESTINATION).as_posix(),
            "source_artifact": manifest[source]["artifact"],
            "sha256": manifest[source]["source_sha256"],
        })
    for name, value in {
        "archive-manifest.json": {
            "recorded_utc": datetime.now(timezone.utc).isoformat(),
            "count": len(manifest), "files": manifest,
        },
        "omitted-artifacts.json": omitted, "previews.json": previews,
    }.items():
        with (DESTINATION / name).open("x") as stream:
            json.dump(value, stream, indent=2, ensure_ascii=False)
            stream.write("\n")
    verifier = (ROOT / "docs/testing/records/2026-11-16-file-browser-keyboard-evidence/verify_binding.py").read_text()
    verifier = verifier.replace("raw/engineering-inputs-r2.json.gz", "raw/engineering-inputs-r1.json.gz")
    old_metadata = '''    metadata = {
        prefix + "/archive-manifest.json", prefix + "/omitted-artifacts.json",
        prefix + "/previews.json",
        *(prefix + "/" + item["path"] for item in previews),
    }'''
    new_metadata = '''    metadata = {
        path.relative_to(ROOT).as_posix() for path in EVIDENCE.iterdir()
        if path.is_file() and path.resolve() != args.output.resolve()
    } | {prefix + "/" + item["path"] for item in previews}'''
    assert old_metadata in verifier
    verifier = verifier.replace(old_metadata, new_metadata)
    with (DESTINATION / "verify_binding.py").open("x") as stream:
        stream.write(verifier)
    source_bytes = sum(row["source_bytes"] for row in manifest.values())
    readme = f"""# 命令输入框双向焦点与精确 CI 证据

本目录保存 {len(manifest)} 份无损原件，原字节 `{source_bytes:,}`；
结论从[本批记录](../2026-11-16-command-composer-focus.md)读取。
`archive-manifest.json` 逐项绑定源字节与 gzip 字节。`omitted-artifacts.json`
登记 {len(omitted)} 份可重建暂存程序、编译 observer 与缓存，未重复提交二进制。

- `raw/engineering-inputs-r1.json.gz`：718 项完整工程集合，SHA-256
  `c3fa4e8b1a8a0f11f8177334fd0c9927e2f1f45d4875cb61212987fadfc6f056`。
- `raw/composer-red-r1.*.gz` / `raw/composer-green-r1.*.gz`：
  实际编译红例 4 pass / 4 fail，修后 8/0/0；失败不覆盖。
- `raw/full-gate-r1.*.gz`、`raw/final-gate-summary.json.gz`：
  最终统一门禁实际 0/reaped/699.865s；Rust 3218/0/48 ignored、
  rustdoc 14/0、Python 290 run/1 skip，app 1339 名逐名相等，完整输入零漂移。
- `raw/review-source-r1/` 与 `raw/source-review-gate-binding.json.gz`：
  新非作者源码批准及相同输入最终门禁绑定；没有独立重新编译。
- `raw/review-native-r1/`：另一新非作者对实际原件的限定复核。
  `raw/native-notes.md.gz` 保留五轮不完整脚本、前台变化和异常链；
  原生双向到达两列表的反向 Tab 仍 HOLD，marker 不是 raw PTY 写入审计。
- `raw/native-cleanup-final-r2.json.gz`：实际 stop/reap/exit0、三个根进程、
  两端口、私有目录及 84 项 birth 身份回收；含 JSON 身份归一化正控。
  旧 r1 内层 tuple 比较不可用，保留并明确替代。
- `raw/normal-artifacts.json.gz`、`raw/package-r1/package-manifest.json.gz`：
  新 arm64 GUI/MCP 与完整包摘要。没有安装、签名或发行。

两个[实际命令草稿](previews/native-command-draft.png)和
[首个反向 Tab](previews/native-first-reverse-tab.png)预览均保持原字节。
这两个片段不能代签完整路径；`previews.json` 绑定对应原始 PNG。

## 上一源码的精确 CI

`raw/ci-followup/` 逐字节保存此前活动 CI 工作目录；`raw/ci-followup-copy.json.gz`
记录完整 84 文件复制核对。run 43797131194 / attempt1 精确绑定源码
80647edca4baa1a07532f328849f24d43819e864，macOS/Ubuntu success，Windows app
1310/8/2 ignored，八项归档审核准备共同失败。原始 ANSI 与去 ANSI 日志、
取件失败、成功 r08、行号摘录和分析均保留。该结果不移签为本批新源码 CI。
详细结论见[CI 跟进](../2026-11-16-platform-ci-followup.md)。

`verify_binding.py` 对 index 或指定证据提交核对原件、预览、根 metadata 与
718 项当前工程 blob；可另传 `--source-commit` 比较源码和证据两棵 Git 树。
提交、推送与清理以单列实际回执为准。后续源码修改后应读取保存的绑定回执与
精确历史提交，不应放宽本冻结的当前字节检查。
"""
    with (DESTINATION / "README.md").open("x") as stream:
        stream.write(readme)
    print(json.dumps({
        "originals": len(manifest), "original_bytes": source_bytes,
        "omitted": len(omitted), "source_files": len(originals), "previews": len(previews),
    }))


if __name__ == "__main__":
    main()
