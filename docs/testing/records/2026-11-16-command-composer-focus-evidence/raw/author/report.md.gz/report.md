# 命令框 Tab 焦点路由交付

基线/当前 HEAD：`4fd193227bb9e5e5e4b49ad6f1503f10741f7383`。只在本隔离树写入，未提交或 push。实现及回归待父编译、集中集成与新非作者评审；真实 macOS 反向 Tab **HOLD 保持开放**。

## 写集

- `crates/keelshell-app/src/workspace/view.rs`：增加 30 行。
- `crates/keelshell-app/src/workspace/tests/navigation.rs`：注册独立测试模块，增加 1 行。
- `crates/keelshell-app/src/workspace/tests/navigation/command_composer_focus.rs`：新增 8 个 GPUI 用例及局部 fixture。
- 本目录的补丁、摘要和报告。没有改 docs、依赖、主题或其他生产文件。

命令栏只 capture Kit 的 `IndentInline` / `OutdentInline`。实时检查 command 真实焦点、无 active modal、无 marked text 后，调用 `Window::focus_next` / `focus_prev` 并停止传播；否则显式传播，保留原处理。没有全局 binding、文本替换或执行入口。三主题继续使用原 registry/token，无样式变化。

## 回归与证据

先写初始 7 项回归并保存 `tests-before-implementation.patch`，再改生产代码；随后补 Run 按钮焦点正控。最终 `tests-only.patch` 含 8 项。**没有执行红/绿，预期失败不算实际红例。**

实际窗口按键覆盖：空命令双向离开；带 Tab、空格、中文、多行及折叠/全选范围的字节保持；真实 `ElementInputHandler` marked text；已挂载 modal 的双向 containment；其他 Input、Textarea 和与远程草稿配置一致的 Editor 缩进/反缩进。预绘制 modal 与 Run 按钮正控使用 `FocusHandle::dispatch_action`，这是同步生产动作派发，避免 `Window::dispatch_action` 的 defer 造成断言先执行。未调用新私有处理函数。

复用 `navigation_fixture` 的隔离 channel transports，全部用例末尾断言所有 `writes` 为空。未启动 SSH、GUI、容器或自动执行。终端只覆盖两种 indent 动作的 scope，未测原生 Tab 编码；Editor 正控是相同配置的真实 Kit 编辑组件，未建立远程文件会话；marked text 是协议注入，未验真实 IME。

已实际通过：直接 rustfmt 两个无子模块文件、`git diff --check`、完整补丁反向 `git apply --check`，均 exit 0，详见 `static-checks.json`。仅静态/格式检查，不代表类型检查、Clippy、测试或 native acceptance。没有运行 Cargo 或访问 target。

已读 RTK、AGENTS、HANDOFF、HALLMARK_NATIVE、SHARED_TARGET、父调查笔记，以及 `rust-best-practices` 的 chapter 01/05/08。按实际锁定 gpui-base/component 0.9.1 源码核对动作、派发时序和缩进；没有改依赖源码。

## 父后续命令（未执行）

先等待当前 fullgate 实际退出、释放唯一 target；在父同一 checkout 导入后保留原 target owner。若另切源码目录，先按 `docs/testing/SHARED_TARGET.md` 保存旧证据并使项目包产物失效。

需要实际红例时，仅将 `tests-only.patch` 应用到受控基线，然后运行下面库存和专项；生产补丁导入后重跑相同专项。不要将源码推断记为红例结果。

```sh
cargo fmt --all --check
cargo test --locked -p keelshell-app -- --list
cargo test --locked -p keelshell-app workspace::tests::navigation::command_composer_focus:: -- --test-threads=1 --nocapture
cargo test --locked -p keelshell-app workspace::tests::navigation:: -- --test-threads=1
cargo test --locked -p keelshell-app workspace::modal_scope::tests:: -- --test-threads=1
cargo test --locked -p keelshell-app files::editor_keyboard_tests:: -- --test-threads=1
python3 scripts/check.py
```

核对库存中的 8 个新增具体名字，记录实际 pass/fail/ignored 后再交新非作者评审。新包真实 macOS Frost 反向 Tab 到两文件列表及命令字节/零执行证据仍需父补验；其他主题、平台、真实 IME/辅助技术保持未验。

完整交付：`composer-focus.patch`；分拆：`production.patch`、`tests-only.patch`；逐文件及补丁 SHA-256：`sha256.json`。

完整补丁 SHA-256：`c56256eef6b36705f78ecf4dfc2843c63027ad0ea7402004810df78063d8bb57`。
