"""Bounded, individually receipted actions on the owned native file fixture."""
import argparse
import json
from pathlib import Path
import time

from native_flow import approve, press, wait
from observe import OUTPUT, SESSION, action, observe


def event(name, operation, *parameters, expected=None):
    result = action(operation, *parameters)
    with (OUTPUT / (name + "-action.json")).open("x") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    if expected:
        wait(expected)
    observe(name, expected)
    return result


def connect():
    action("activate")
    port = SESSION["ports"]["target"]
    user = SESSION["state_fixture"]["connections"][0]["username"]
    direct = f"连接: 原生验证 · 直连 · {user}@127.0.0.1:{port}"
    press("01-direct-auth", "AXButton", direct, "密码或私钥")
    press("02-direct-key", "AXButton", "连接", "收到的指纹:")
    approve("03-direct", "target")
    press("04-direct-live", "AXButton", "连接", "SSH 会话: 原生验证 · 直连")
    wait("远程文件列表")
    observe("05-files", "远程文件列表")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("operation", choices=["connect", "event"])
    parser.add_argument("--name")
    parser.add_argument("--action", nargs="+")
    parser.add_argument("--expected")
    args = parser.parse_args()
    if args.operation == "connect":
        connect()
    else:
        if not args.name or not args.action:
            raise ValueError("Name and action required")
        event(args.name, *args.action, expected=args.expected)
