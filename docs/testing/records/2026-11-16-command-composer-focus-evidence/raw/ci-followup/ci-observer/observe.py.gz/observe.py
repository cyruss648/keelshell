"""Read one pinned GitHub Actions attempt; write evidence only beside this file."""

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time


REPO = "cyruss648/keelshell"
RUN = 43797131194
ATTEMPT = 1
HEAD = "80647edca4baa1a07532f328849f24d43819e864"
JOBS = {
    133068379484: "macos",
    133068379697: "windows",
    133068379884: "ubuntu",
}
BASE = Path(__file__).resolve().parent
STARTED = time.monotonic()
DEADLINE = STARTED + 480
ANSI = re.compile(
    rb"\x1b(?:\[[0-?]*[ -/]*[@-~]|\][^\x07\x1b]*(?:\x07|\x1b\\)|[@-_])"
)
COMMANDS = []


def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def write_json(path, value):
    with path.open("x", encoding="utf-8") as output:
        json.dump(value, output, indent=2, ensure_ascii=False)
        output.write("\n")


def request(label, endpoint, workspace):
    """Use a single absolute 45s budget, reserving 5s for owned CLI reaping."""
    stdout_path = BASE / f"{label}.stdout"
    stderr_path = BASE / f"{label}.stderr"
    receipt_path = BASE / f"{label}.json"
    for path in (stdout_path, stderr_path, receipt_path):
        if path.exists():
            raise RuntimeError("Refusing to overwrite an evidence file")
    command = ["gh", "api", "--method", "GET", endpoint]
    begin = time.monotonic()
    stop = min(begin + 45, DEADLINE)
    execution_budget = max(0, min(40, stop - begin - 5))
    record = {
        "command": command,
        "started_at": utc(),
        "cwd": str(workspace),
        "network_deadline_seconds": 45,
        "execution_budget_seconds": execution_budget,
        "exit_code": None,
        "reaped": False,
        "timed_out": False,
        "kill_sent": False,
        "cleanup_errno": None,
        "launch_errno": None,
    }
    environment = dict(os.environ)
    environment.update(
        GH_PROMPT_DISABLED="1",
        GH_PAGER="cat",
        PAGER="cat",
        NO_COLOR="1",
        CLICOLOR="0",
    )
    environment.pop("GH_DEBUG", None)
    proc = None
    with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
        if execution_budget <= 0:
            record["not_started_reason"] = "observation_deadline"
        else:
            try:
                proc = subprocess.Popen(
                    command,
                    cwd=workspace,
                    env=environment,
                    stdin=subprocess.DEVNULL,
                    stdout=stdout,
                    stderr=stderr,
                    start_new_session=True,
                )
            except OSError as error:
                record["launch_errno"] = error.errno
            if proc is not None:
                try:
                    record["exit_code"] = proc.wait(timeout=execution_budget)
                    record["reaped"] = True
                except subprocess.TimeoutExpired:
                    record["timed_out"] = True
                    # One destructive signal while this unreaped child owns its PGID.
                    try:
                        os.killpg(proc.pid, signal.SIGKILL)
                        record["kill_sent"] = True
                    except OSError as error:
                        record["cleanup_errno"] = error.errno
                    try:
                        record["exit_code"] = proc.wait(
                            timeout=max(0, stop - time.monotonic())
                        )
                        record["reaped"] = True
                    except subprocess.TimeoutExpired:
                        record["cleanup_unconfirmed"] = True
    record.update(
        finished_at=utc(),
        elapsed_seconds=time.monotonic() - begin,
        stdout_file=stdout_path.name,
        stderr_file=stderr_path.name,
        stdout_bytes=stdout_path.stat().st_size,
        stderr_bytes=stderr_path.stat().st_size,
        stdout_sha256=hashlib.sha256(stdout_path.read_bytes()).hexdigest(),
        stderr_sha256=hashlib.sha256(stderr_path.read_bytes()).hexdigest(),
    )
    write_json(receipt_path, record)
    COMMANDS.append(receipt_path.name)
    if record["exit_code"] != 0 or not record["reaped"]:
        return None
    return stdout_path


def read_response(label, endpoint, workspace):
    path = request(label, endpoint, workspace)
    if path is None:
        return None
    try:
        return json.loads(path.read_bytes())
    except (ValueError, UnicodeError):
        return None


def pinned_run(value):
    return (
        value.get("id") == RUN
        and value.get("run_attempt") == ATTEMPT
        and value.get("head_sha") == HEAD
        and value.get("name") == "Quality"
        and value.get("repository", {}).get("full_name") == REPO
    )


def collect_log(job, workspace, logs, sequence):
    identifier = job["id"]
    if identifier in logs or job.get("status") != "completed":
        return
    # A completed successful job needs no log download for this scoped follow-up.
    if job.get("conclusion") == "success":
        return
    if time.monotonic() >= DEADLINE - 5:
        return
    label = f"job-{identifier}-logs-r{sequence:02d}"
    path = request(
        label, f"repos/{REPO}/actions/jobs/{identifier}/logs", workspace
    )
    if path is None:
        return
    plain = ANSI.sub(b"", path.read_bytes())
    plain_path = BASE / f"{label}.plain.log"
    plain_path.write_bytes(plain)
    lines = plain.decode("utf-8", errors="replace").splitlines()
    pattern = re.compile(
        r"##\[error\]|Traceback|FAILED|^.*(?:FAIL|ERROR): |"
        r"\berrno\b|\bwinerror\b|identity.{0,50}(?:fail|bind)|"
        r"Process completed with exit code",
        re.IGNORECASE,
    )
    indexes = set()
    for index, line in enumerate(lines):
        if pattern.search(line):
            indexes.update(range(max(0, index - 4), min(len(lines), index + 9)))
    excerpt = [
        {"line": index + 1, "text": lines[index]} for index in sorted(indexes)
    ]
    excerpt_path = BASE / f"{label}.excerpts.json"
    write_json(excerpt_path, excerpt)
    logs[identifier] = {
        "raw_stdout": path.name,
        "plain_log": plain_path.name,
        "plain_sha256": hashlib.sha256(plain).hexdigest(),
        "excerpts": excerpt_path.name,
        "lines": len(lines),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", required=True, type=Path)
    args = parser.parse_args()
    workspace = args.workspace.resolve()
    expected = workspace / "work/platform-ci-followup-20261116/ci-observer"
    if BASE != expected or not (workspace / "AGENTS.md").is_file():
        raise SystemExit("Workspace and evidence directory do not match")

    begin_utc = utc()
    previous = workspace / "work/platform-ci-followup-20261116/source-jobs-r4.log"
    write_json(
        BASE / "baseline.json",
        {
            "repo": REPO,
            "run_id": RUN,
            "attempt": ATTEMPT,
            "head_sha": HEAD,
            "expected_job_ids": list(JOBS),
            "previous_jobs_file": str(previous.relative_to(workspace)),
            "previous_jobs_sha256": hashlib.sha256(previous.read_bytes()).hexdigest(),
            "started_at": begin_utc,
            "maximum_observation_seconds": 480,
            "minimum_poll_round_interval_seconds": 60,
            "source_cargo_git_ui_mutation": False,
            "method": "GET",
        },
    )
    latest_run = None
    latest_jobs = []
    logs = {}
    reason = "deadline"
    rounds = 0
    errors = []
    next_round = STARTED
    try:
        while time.monotonic() < DEADLINE - 5:
            remaining = next_round - time.monotonic()
            if remaining > 0:
                time.sleep(min(remaining, 25, max(0, DEADLINE - time.monotonic())))
                continue
            round_start = time.monotonic()
            rounds += 1
            next_round = round_start + 60
            run_value = read_response(
                f"r{rounds:02d}-run",
                f"repos/{REPO}/actions/runs/{RUN}/attempts/{ATTEMPT}",
                workspace,
            )
            if run_value is None:
                errors.append({"round": rounds, "stage": "run_get_failed"})
                continue
            if not pinned_run(run_value):
                errors.append({"round": rounds, "stage": "run_identity_mismatch"})
                reason = "identity_mismatch"
                break
            latest_run = run_value
            if time.monotonic() >= DEADLINE - 5:
                break
            jobs_value = read_response(
                f"r{rounds:02d}-jobs",
                f"repos/{REPO}/actions/runs/{RUN}/attempts/{ATTEMPT}/jobs?per_page=100",
                workspace,
            )
            if jobs_value is None:
                errors.append({"round": rounds, "stage": "jobs_get_failed"})
                continue
            candidate = jobs_value.get("jobs", [])
            if (
                len(candidate) != 3
                or {value.get("id") for value in candidate} != set(JOBS)
                or any(
                    value.get("run_id") != RUN
                    or value.get("run_attempt") != ATTEMPT
                    or value.get("head_sha") != HEAD
                    or value.get("workflow_name") != "Quality"
                    for value in candidate
                )
            ):
                errors.append({"round": rounds, "stage": "job_identity_mismatch"})
                reason = "identity_mismatch"
                break
            latest_jobs = candidate
            snapshot = {
                "round": rounds,
                "observed_at": utc(),
                "run_status": latest_run["status"],
                "run_conclusion": latest_run["conclusion"],
                "jobs": [
                    {
                        "id": value["id"],
                        "platform": JOBS[value["id"]],
                        "status": value["status"],
                        "conclusion": value["conclusion"],
                        "active_steps": [
                            step["name"]
                            for step in value.get("steps", [])
                            if step["status"] == "in_progress"
                        ],
                    }
                    for value in candidate
                ],
            }
            write_json(BASE / f"r{rounds:02d}-snapshot.json", snapshot)
            print(json.dumps(snapshot, ensure_ascii=False), flush=True)
            for job in latest_jobs:
                collect_log(job, workspace, logs, rounds)
            if all(value.get("status") == "completed" for value in latest_jobs):
                reason = "all_jobs_completed"
                break
    except Exception as error:
        # No exception strings: they can contain opaque remote values.
        errors.append({"stage": "observer_exception", "type": type(error).__name__})
        reason = "observer_error"

    summary = {
        "repo": REPO,
        "workflow": "Quality",
        "run_id": RUN,
        "attempt": ATTEMPT,
        "required_head_sha": HEAD,
        "observed_head_sha": latest_run.get("head_sha") if latest_run else None,
        "identity_verified": latest_run is not None,
        "run_status": latest_run.get("status") if latest_run else None,
        "run_conclusion": latest_run.get("conclusion") if latest_run else None,
        "observation_started_at": begin_utc,
        "observation_finished_at": utc(),
        "elapsed_seconds": time.monotonic() - STARTED,
        "stop_reason": reason,
        "poll_rounds": rounds,
        "jobs": [
            {
                "id": value["id"],
                "platform": JOBS[value["id"]],
                "name": value["name"],
                "status": value["status"],
                "conclusion": value["conclusion"],
                "started_at": value.get("started_at"),
                "completed_at": value.get("completed_at"),
                "failed_steps": [
                    step
                    for step in value.get("steps", [])
                    if step.get("conclusion") in ("failure", "timed_out")
                ],
                "logs": logs.get(value["id"]),
            }
            for value in latest_jobs
        ],
        "command_receipts": COMMANDS,
        "errors": errors,
        "source_cargo_git_ui_mutation": False,
        "rerun_or_cancel_requested": False,
        "native_product_acceptance": "not_claimed",
    }
    write_json(BASE / "summary.json", summary)
    rows = [
        "# 精确 CI 只读跟进",
        "",
        f"- 仓库：`{REPO}`；Quality run `{RUN}` / attempt `{ATTEMPT}`。",
        f"- 必须及实际核对的源码：`{HEAD}`。",
        f"- 观察时间：{begin_utc} 至 {summary['observation_finished_at']}。",
        f"- 结束原因：`{reason}`；轮次：{rounds}。",
        f"- 最新 run：`{summary['run_status']}` / `{summary['run_conclusion']}`。",
        "",
        "| 平台 | Job | 状态 | Conclusion |",
        "| --- | --- | --- | --- |",
    ]
    rows.extend(
        f"| {value['platform']} | {value['id']} | {value['status']} | "
        f"{value['conclusion']} |"
        for value in summary["jobs"]
    )
    rows.extend(
        [
            "",
            "每个 GET 的原始 stdout、独立 stderr、退出码、回收和时间回执均在本目录。",
            "失败日志另存去 ANSI 副本与带行号的摘录，原始字节不直接渲染。",
            "尚未结束的 job 保持 in_progress；编译或 CI 不能代签原生产品验收。",
            "未执行源码、Cargo、Git mutation、UI、重跑或取消；未创建 chat/worktree。",
            "详细失败定位由读取去 ANSI 日志后的 analysis 文件补充；不反推旧 run 根因。",
            "",
        ]
    )
    with (BASE / "report.md").open("x", encoding="utf-8") as output:
        output.write("\n".join(rows))
    print(
        json.dumps(
            {
                "finished": True,
                "stop_reason": reason,
                "run_status": summary["run_status"],
                "run_conclusion": summary["run_conclusion"],
                "summary_file": "summary.json",
                "elapsed_seconds": summary["elapsed_seconds"],
            }
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
