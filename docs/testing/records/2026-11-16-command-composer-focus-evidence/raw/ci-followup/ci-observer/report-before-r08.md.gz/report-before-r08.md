# 精确 CI 只读跟进

- 仓库：`cyruss648/keelshell`；Quality run `43797131194` / attempt `1`。
- 必须及实际核对的源码：`80647edca4baa1a07532f328849f24d43819e864`。
- 观察时间：2026-11-16T03:39:39.724275+00:00 至 2026-11-16T03:45:44.648355+00:00。
- 结束原因：`all_jobs_completed`；轮次：7。
- 最新 run：`completed` / `failure`。

| 平台 | Job | 状态 | Conclusion |
| --- | --- | --- | --- |
| macos | 133068379484 | completed | success |
| windows | 133068379697 | completed | failure |
| ubuntu | 133068379884 | completed | success |

每个 GET 的原始 stdout、独立 stderr、退出码、回收和时间回执均在本目录。
失败日志另存去 ANSI 副本与带行号的摘录，原始字节不直接渲染。
尚未结束的 job 保持 in_progress；编译或 CI 不能代签原生产品验收。
未执行源码、Cargo、Git mutation、UI、重跑或取消；未创建 chat/worktree。
详细失败定位由读取去 ANSI 日志后的 analysis 文件补充；不反推旧 run 根因。
