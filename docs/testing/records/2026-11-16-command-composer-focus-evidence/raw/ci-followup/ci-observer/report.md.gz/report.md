# 精确 CI 只读跟进结论

仓库 `cyruss648/keelshell` 的 Quality run `43797131194` / attempt `1` 已终态，
conclusion 为 **failure**。每轮实际核对的 `head_sha` 均为
`80647edca4baa1a07532f328849f24d43819e864`，三个 job ID 逐项匹配。
终态源为 `r07-run.stdout`、`r07-jobs.stdout`，观察于 2026-11-16 03:45:41 UTC。

| 平台 | Job | 状态 | Conclusion | 完成时间 UTC |
| --- | --- | --- | --- | --- |
| macOS 26 | 133068379484 | completed | success | 03:44:42 |
| Windows 2025 | 133068379697 | completed | failure | 03:43:57 |
| Ubuntu 24.04 | 133068379884 | completed | success | 03:43:50 |

Windows 实际失败步骤为第 5 步 `Rust quality gate`，具体在
`cargo test --workspace --locked -- --test-threads=4` 的 app 测试执行阶段。
不是编译失败：严格 Clippy 已完成，测试二进制也已完成构建。
app 结果为 **1310 passed / 8 failed / 2 ignored**，用时 804.58 秒
（去 ANSI 日志第 3808 行）；Cargo 返回 101，workflow 步骤返回 1
（第 3812–3813 行）。这不是整个 workspace 的完整通过计数。

八项失败均属于 `files::transfer_tests::archive_tests`，共同停在
`crates/keelshell-app/src/files/archive_tests.rs:102:14`，消息为
`archive preparation must produce a full immutable review`：

- `archive_cancel_and_selection_change_never_publish_an_old_approval`（panic 日志第 3759 行）
- `archive_changed_local_content_is_rejected_before_any_publication`（panic 日志第 3764 行）
- `archive_corrupt_download_and_existing_local_target_preserve_destination`（panic 日志第 3769 行）
- `archive_draft_change_and_retired_session_reject_review`（panic 日志第 3774 行）
- `archive_large_manifest_keeps_last_member_and_fixed_review_actions`（panic 日志第 3779 行）
- `archive_pending_write_cancel_retains_close_hold_across_another_verified_upload`（panic 日志第 3784 行）
- `archive_tar_gz_download_extract_reviews_empty_folders_and_publishes_new_tree`（panic 日志第 3789 行）
- `archive_zip_upload_requires_confirmation_and_preserves_exact_binary_members`（panic 日志第 3794 行）

该日志没有输出这八项失败对应的底层错误或数字 errno/winerror，不能从共同
panic 推断 Windows 文件系统、归档工具或旧进程身份问题的具体根因。
建议父后续检查 Windows 归档准备流程与夹具错误可见性；保持真实原生身份断言，
不以 skip 或放宽断言消除失败。本观察者未读改源码、执行 Cargo 或实施修复。

本次工程 Python 为 **290 run / 256 passed / 34 skipped / 0 failure / 0 error**，
第 462–464 行。原生 Windows 准备诊断明确 `identity_bound=true`、
`observer_phase=identity_bound`、`observer_error=null`（第 465 行）。
第 466 行的 `winerror=1816` 属于成功 barrier 控制中的迟到 CreateProcess 拒绝
（`creation_rejected=true`），并非这八项失败的错误码；不能拿它解释归档失败。
本次成功也不能反推旧失败的历史根因。

日志来源是一次新增只读 GET：

```text
gh api --method GET --allow-escape-sequences repos/cyruss648/keelshell/actions/jobs/133068379697/logs
```

- 原始 stdout：`job-133068379697-logs-r08.stdout`；507318 字节；SHA-256 `f874aa2f132bca56fa1e3ed7b0205c5b25ceb5fad6d6b3f8988b445703fbb948`。
- 去 ANSI 副本：`job-133068379697-logs-r08.plain.log`；493837 字节，3837 行；SHA-256 `0a6cf7c960ef7420fb7445014398176261654537539c528c9421df2a56d03259`；剩余 ESC 字节为 0。
- 命令回执：`job-133068379697-logs-r08.json`；exit 0 / reaped / 未超时 / 3.553777s。
- 失败摘录：`job-133068379697-logs-r08.failure-excerpts.txt`；结构化分析：`windows-failure-analysis.json`。
- r06/r07 因缺少 allow flag 被 gh 拒绝输出 ANSI 的原始失败回执全部保留。
- 原终态文档原字节保存在 `summary-before-r08.json`、`report-before-r08.md`；修订 `summary.json` 已追加 r08 来源和结论。

共 7 轮状态轮询，每轮间隔至少 60 秒；终态时停止。
包含日志取件共 17 条网络命令均已回收、无超时；最长
3.644003s，低于 45 秒。
状态观察 364.925s；从观察开始至一次新编号日志 GET 完成
448.109s，低于 8 分钟。
父要求终态后不再 poll 已遵守。未重跑/取消 CI、未执行 Git mutation/UI、未创建
chat/worktree；所有新文件与修改仅在本 `ci-observer` 目录。没有后台观察进程。
CI 成功 job 不能代签原生产品、发行或完整功能验收。
