# 本批限定原生观察

本批正常程序来自同一父 checkout 的 `normal-build-r1`；macOS arm64 暂存包和
包检查实际通过。`normal-artifacts.json`、`package-r1/package-manifest.json`
保存完整摘要，GUI SHA-256 为
`af2a88364650b90b5dfab4ca8a4655a8430febc4971f575c7a7fd0fde19eb9a3`。
没有安装、覆盖既有应用、签名或发行。

使用独立状态目录与本机自有 sshd 夹具。实际 UI 先读取目标指纹，与独立
ssh-keygen 指纹相等后接受，再连接 SSH/SFTP；`native-connect-r1` 实际退出 0。
Frost 浅色中文默认窗口的截图和 AX 位于 `native-frost-r1/`。

## 实际结果与失败

这五个焦点脚本回合都没有完整成功，原始日志、回执与截图全部保留。
不能将后来的片段改写成某个完整脚本通过。

- r1：输入本地目录后 Enter，八秒内没有加载本地列表。失败时本地路径完整，
  界面显示“目录草稿已修改；按刷新浏览。”；没有足够证据判定 Enter 的投递
  与事件处理具体原因。r2 显式点击“刷新本地目录草稿”后实际加载了列表。
  此为接续准备，不代签 r1 或 Enter 成功。
- r2：输入命令期间前台切换到 PID 1525（实际读回 ChatGPT），草稿只出现部分
  文字。旧 helper 的 text 只在整个文本开始时检查前台，因此不能从该回执
  声称每个字符只投递到了夹具。没有发送其他应用中的消息。随后 helper
  增加每个字符投递前的前台检查，旧源另存 `native_ax-r1.swift`。
- r3：新 helper 下完整草稿实际出现在命令框。第一记真实 macOS Shift+Tab
  的 NSEvent characters 是 U+0019，已从命令框移到会话选择控件。随后七个
  已记录步骤均逐次检查命令 UTF-8 字节保持及执行标记 absent。第八步期间
  前台再次变化，脚本失败；没有到达两文件列表。
- r4：文本投递后的快照前台断言失败，没有签署完整草稿或导航成功；异常截图
  又因没有唯一可见窗口失败，完整异常链保留。不能声称逐字符守卫在此轮触发。
- r5：点击前没有唯一可见窗口，未取得导航成功；异常截图也失败。至此停止原生投递，
  没有不断重新激活或放宽守卫来制造通过。

`frost-r3-progress.json` 保存七步完整 AX 和键事件，`frost-r3-draft`、
`frost-r3-reverse-first` 与各 failed 原件独立保留。r3 的单次离开命令框只证明
限定片段，**双向到达两文件列表的原生反向 Tab HOLD 仍开放**。
没有 raw PTY 写入审计，不能把标记 absent 当作零出站字节。
零 Write 的明确断言来自八项隔离 GPUI 回归，不能移签为原生网络审计。
Graphite/Lavender、真实 IME、VoiceOver、其他尺寸及 Windows/Linux 桌面未重放。

## 资源回收

父向原夹具 PTY 发送 stop 并实际取得退出 0；三个自有根进程清理 true，
两端口关闭，私有目录 absent。最终 `native-cleanup-final-r2.json` 使用内层
birth tuple 归一化，并以当前活进程 JSON roundtrip 作为正控；84 项累计 birth
身份零活匹配。先前 `native-cleanup-final.json` 未还原内层 tuple，结论不可用，
原件保留，由 r2 明确替代。没有新建用户 chat、容器或 worktree。
