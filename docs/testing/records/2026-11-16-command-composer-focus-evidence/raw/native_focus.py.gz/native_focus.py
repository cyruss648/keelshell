"""Observe native composer navigation on this run's owned localhost fixture."""
import argparse
import hashlib
import json
from pathlib import Path
import shlex
import time

from observe import OUTPUT, SESSION, action, observe

parser = argparse.ArgumentParser()
parser.add_argument("--prefix", required=True)
parser.add_argument("--setup-local", action="store_true")
args = parser.parse_args()
assert "/" not in args.prefix
SHIFT = 1 << 17
COMMAND = 1 << 20
COMPOSER = "输入命令，确认目标后执行"
root = Path(SESSION["fixture_root"])
assert root.is_relative_to(Path(SESSION["scratch"]))
marker = root / ".composer-tab-executed"
draft = "    printf '中文焦点检查' > " + shlex.quote(str(marker))
assert not marker.exists()
events = []
progress = {}
deadline = time.monotonic() + 180


def save(name, value):
    with (OUTPUT / (args.prefix + "-" + name + ".json")).open("x") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def one(tree, role, title):
    found = [n for n in tree["nodes"] if n.get("AXRole") == role and n.get("AXTitle") == title]
    assert len(found) == 1, (role, title, len(found))
    return found[0]


def click(role, title):
    tree = action("tree")
    node = one(tree, role, title)
    windows = [w for w in tree["cgWindows"] if w.get("kCGWindowLayer") == 0]
    assert len(windows) == 1
    bounds = windows[0]["kCGWindowBounds"]
    x = node["AXPosition"][0] - bounds["X"] + node["AXSize"][0] / 2
    y = node["AXPosition"][1] - bounds["Y"] + node["AXSize"][1] / 2
    result = action("click", str(x), str(y))
    time.sleep(0.15)
    return result


def snapshot():
    assert time.monotonic() < deadline, "native scenario deadline"
    tree = action("tree")
    assert tree["foregroundPID"] == SESSION["pid"]
    return tree


def assert_draft(tree):
    current = one(tree, "AXTextArea", COMPOSER)["AXValue"]
    assert current.encode() == draft.encode(), (current, draft)
    assert not marker.exists(), "a navigation action executed the draft"


try:
    events.append(action("activate"))
    if args.setup_local:
        events.append(click("AXTextField", "本地绝对目录"))
        events.append(action("key", "0", str(COMMAND)))
        events.append(action("text", str(root)))
        events.append(action("key", "36", "0"))
        until = time.monotonic() + 8
        while True:
            tree = snapshot()
            path = one(tree, "AXTextField", "本地绝对目录")
            listing = one(tree, "AXList", "本地文件列表")
            rows = [n for n in tree["nodes"] if n["path"].startswith(listing["path"] + ".")]
            if path["AXValue"] == str(root) and len(rows) > 3:
                break
            assert time.monotonic() < until, "local directory did not load"
            time.sleep(0.1)
        observe(args.prefix + "-local-loaded", "本地文件列表")

    events.append(click("AXTextArea", COMPOSER))
    events.append(action("key", "0", str(COMMAND)))
    events.append(action("text", draft))
    time.sleep(0.2)
    assert_draft(snapshot())
    observe(args.prefix + "-draft", COMPOSER)

    directions = []
    for direction, flags in [("reverse", SHIFT), ("forward", 0)]:
        events.append(click("AXTextArea", COMPOSER))
        tree = snapshot()
        assert one(tree, "AXTextArea", COMPOSER).get("AXFocused")
        visited = set()
        steps = []
        progress[direction] = steps
        for index in range(128):
            operation = action("key", "48", str(flags))
            time.sleep(0.08)
            tree = snapshot()
            assert_draft(tree)
            focused = [
                {k: n[k] for k in ["path", "AXRole", "AXTitle", "AXValue"] if k in n}
                for n in tree["nodes"] if n.get("AXFocused")
            ]
            if index == 0:
                assert not one(tree, "AXTextArea", COMPOSER).get("AXFocused"), direction
                observe(args.prefix + "-" + direction + "-first")
            for title in ["本地文件列表", "远程文件列表"]:
                listing = one(tree, "AXList", title)
                owns = listing.get("AXFocused") or any(
                    n.get("AXFocused") and n["path"].startswith(listing["path"] + ".")
                    for n in tree["nodes"]
                )
                if owns and title not in visited:
                    visited.add(title)
                    observe(args.prefix + "-" + direction + "-" + title)
            steps.append({"index": index + 1, "action": operation, "focused": focused, "ax": tree})
            if len(visited) == 2:
                break
        save(direction + "-steps", steps)
        assert len(visited) == 2, (direction, visited)
        directions.append({"direction": direction, "steps": len(steps), "visited": sorted(visited)})
    original_seeds = SESSION["seed_sha256"]
    actual = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in original_seeds}
    assert actual == original_seeds
    save("result", {
        "passed": True, "directions": directions,
        "draft_utf8_hex": draft.encode().hex(), "draft_sha256": hashlib.sha256(draft.encode()).hexdigest(),
        "execution_marker_absent": not marker.exists(), "seed_bytes_unchanged": True,
        "scope": "native keyboard/AX and marker non-execution only; not a raw PTY write audit",
    })
except BaseException:
    observe(args.prefix + "-failed")
    raise
finally:
    save("events", events)
    save("progress", progress)
