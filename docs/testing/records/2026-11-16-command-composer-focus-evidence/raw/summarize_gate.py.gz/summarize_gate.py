"""Bind the completed unified gate to the full source set and named inventory."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
receipt = json.loads((BASE / "full-gate-r1.json").read_text())
assert receipt["observed_exit"] == receipt["controller_exit"] == 0
assert receipt["terminal"]["direct_reaped"] and receipt["terminal"]["active_processes"] == 0
assert not receipt["timed_out"]
data = (BASE / "full-gate-r1.log").read_bytes()
assert len(data) == receipt["log_bytes"]
assert hashlib.sha256(data).hexdigest() == receipt["log_sha256"]
text = data.decode()
workspace = text.split("Running: cargo test --workspace --locked -- --test-threads=4\n", 1)[1]
workspace = workspace.split("Running: cargo test -p keelshell-ai", 1)[0]
totals = {kind: dict(passed=0, failed=0, ignored=0) for kind in ["ordinary", "rustdoc"]}
kind = "ordinary"
for line in workspace.splitlines():
    if line.strip().startswith("Doc-tests "):
        kind = "rustdoc"
    elif line.strip().startswith("Running "):
        kind = "ordinary"
    match = re.search(r"^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;", line)
    if match:
        for key, value in zip(["passed", "failed", "ignored"], match.groups()):
            totals[kind][key] += int(value)
assert totals["ordinary"] == dict(passed=3218, failed=0, ignored=48), totals
assert totals["rustdoc"] == dict(passed=14, failed=0, ignored=0), totals
inventory = set(re.findall(r"^(.+): test$", (BASE / "app-inventory-r1.log").read_text(), re.M))
assert len(inventory) == 1339
expected = set((BASE / "author/expected-tests.txt").read_text().splitlines())
assert len(expected) == 8 and expected.issubset(inventory)
passed = set(re.findall(r"^test (.+?) \.\.\. ok$", workspace, re.M))
assert expected.issubset(passed), sorted(expected - passed)
app_section = workspace.split("unittests src/main.rs", 1)[1].split("test result:", 1)[0]
app_executed = set(re.findall(r"^test (.+?) \.\.\. (?:ok|ignored)", app_section, re.M))
assert app_executed == inventory, (sorted(inventory - app_executed), sorted(app_executed - inventory))
assert "Ran 290 tests" in text and "OK (skipped=1)" in text
freeze = json.loads((BASE / "engineering-inputs-r1.json").read_text())
names = subprocess.check_output(
    ["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"], cwd=ROOT
).split(b"\0")
current = {
    name.decode() for name in names
    if name and not name.startswith(b"docs/") and (ROOT / name.decode()).is_file()
}
assert current == {row["path"] for row in freeze["inputs"]}
assert len(current) == freeze["count"] == 718
mismatches = [
    row["path"] for row in freeze["inputs"]
    if hashlib.sha256((ROOT / row["path"]).read_bytes()).hexdigest() != row["sha256"]
]
assert not mismatches, mismatches
artifacts = json.loads((BASE / "normal-artifacts.json").read_text())
for name, expected_artifact in artifacts.items():
    path = ROOT / "work/recovery-batch-integration-20261115/target/debug" / name
    actual = path.read_bytes()
    assert len(actual) == expected_artifact["bytes"]
    assert hashlib.sha256(actual).hexdigest() == expected_artifact["sha256"]
summary = {
    "gate": receipt, "engineering_inputs": freeze["count"],
    "engineering_sha256": freeze["aggregate_sha256"],
    "complete_engineering_path_set_matches": True, "input_mismatches": mismatches,
    "rust": totals, "app_inventory_count": len(inventory), "app_executed_names_match": True,
    "python": dict(run=290, passed=289, skipped=1, failed=0),
    "new_default_rust_tests": sorted(expected),
    "normal_artifacts_unchanged_after_gate": True,
    "format_strict_clippy_xy_policy_and_three_controllers_passed": True,
    "native_reverse_tab_to_both_file_lists": "HOLD",
}
with (BASE / "final-gate-summary.json").open("x") as stream:
    json.dump(summary, stream, indent=2)
    stream.write("\n")
print(json.dumps({k: v for k, v in summary.items() if k not in ["new_default_rust_tests", "gate"]}))
