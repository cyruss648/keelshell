"""Losslessly preserve this batch's text, receipts and screenshots before cleanup."""
import gzip
import hashlib
import json
from pathlib import Path

source = Path(__file__).resolve().parent
target = Path("docs/testing/records/2026-11-16-editor-keyboard-native-evidence")
manifest = {"count": 0, "files": {}}
omitted = []
for path in sorted(source.rglob("*")):
    if not path.is_file():
        continue
    name = path.relative_to(source).as_posix()
    if (
        name.split("/")[0] in ["package-baseline", "package-r1"]
        or "__pycache__" in path.parts
        or name == "native_ax"
        or name.startswith("review-runner/tmp/")
    ):
        omitted.append({"path": name, "reason": "derived package, compiled helper or temporary fixture/cache",
                        "bytes": path.stat().st_size,
                        "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
        continue
    data = path.read_bytes()
    artifact = "raw/" + name + ".gz"
    destination = target / artifact
    destination.parent.mkdir(parents=True, exist_ok=True)
    compressed = gzip.compress(data, mtime=0)
    assert gzip.decompress(compressed) == data
    with destination.open("xb") as stream:
        stream.write(compressed)
    manifest["files"][name] = {
        "artifact": artifact, "source_bytes": len(data),
        "source_sha256": hashlib.sha256(data).hexdigest(),
        "artifact_sha256": hashlib.sha256(compressed).hexdigest(),
    }
manifest["count"] = len(manifest["files"])
for name, value in [("archive-manifest.json", manifest), ("omitted-artifacts.json", omitted)]:
    with (target / name).open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
print(json.dumps({"archived": manifest["count"], "omitted_derived_files": len(omitted),
                  "source_bytes": sum(row["source_bytes"] for row in manifest["files"].values())}))
