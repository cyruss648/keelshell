# 远程编辑器键盘作者交接 — 2026-11-16

结论：实现与静态检查已完成；现已冻结并停止修改，交父统一编译、专项执行、非作者复核和最终门禁。未运行 Cargo、Clippy 或 Rust 测试；不将已写测试计为通过或原生验收。

- 作者 worktree：`/Users/hdh/.codex/worktrees/editor-keyboard-20261116/keelshell`
- 基线 HEAD：`92c8ddaab84d19a1044a5803d73a0495d0b89354`，未提交、未 push、未创建用户 chat。
- 未使用、清理或新建任何 Cargo target；父原生文件/编码工作与 merge.rs 未改。
- 只写下列 6 个授权源码文件，以及本份指定父目录交接报告。正式 ADR/产品/测试记录由父整合。

## 具体变更与冻结 SHA-256

- `crates/keelshell-app/src/files.rs`：模块声明、每个 App 仅一次的局部 keymap 注册，以及不进入 Tab 顺序的编辑器区域 FocusHandle。
  SHA-256：`a4eae756dfc2fcd4e6a7b04ac5c9b6ab6afd01745292b4260a27a6f8e8a33dc7`
- `crates/keelshell-app/src/files/view.rs`：内联草稿卡片的局部键盘作用域、查找入口、准确平台双语保存 tooltip；保存按钮 disabled 状态补齐 busy/pending。
  SHA-256：`f7c86addc7b47a631687e53a512630e82821c8745b7785b64ecb98bbdb357b81`
- `crates/keelshell-app/src/files/review.rs`：仅展开草稿表面挂载同一键盘作用域，增加查找入口和双语保存 tooltip。补丁/合并不挂载。
  SHA-256：`7212cb654e3df88f57160cdf4197d8b868f33b8446187308805d47523ba8c3f4`
- `crates/keelshell-app/src/files/editor_search.rs`：现有搜索/替换框补稳定测试 ID 和随语言变化的无障碍名称；不改变搜索/替换语义。
  SHA-256：`44540b5c6a49859953e0b5d68359db8b954e4cede4d9588b55d2bfb693b50c1a`
- `crates/keelshell-app/src/files/editor_keyboard.rs`：新增 ReviewEditorSave / FindEditorText actions、平台快捷键、局部焦点与当前会话/连接/路径/表面校验，复用既有审核和搜索。
  SHA-256：`5cc5cc86f95457bf03dfda0a24b15ea31088d9cc5467cb27aa745a3aac4e7d5e`
- `crates/keelshell-app/src/files/editor_keyboard_tests.rs`：新增 9 项真实 GPUI 按键分发测试与受控 SSH/SFTP/终端夹具；没有直接调用快捷键处理 helper 代替按键分发。
  SHA-256：`cf773438d9204061bc701f562c792b604a672e2ce83ddf9a024c1f587fe02423`

## 设计与明确边界

- macOS 仅 Cmd+S / Cmd+F；Windows/Linux 仅 Ctrl+S / Ctrl+F，和现有平台选择方式一致。
- 通过 GPUI actions / key context `KeelShellFileEditor` 与 `KeelShellFileEditor > Input` 绑定。后者在 Input 深度处理 Kit 原有搜索键；没有全局 keystroke interceptor、原始键监听或任何快捷键确认操作。
- 作用域仅为内联文本草稿卡片、展开 Draft 及其搜索/替换和工具按钮子树。事件处理还检查区域包含当前焦点，直接派发无焦点 action 不能启动操作。补丁、合并、审核正文、文件目录/其他输入与终端不挂载此 context。
- 保存快捷键调用原 request_save 构造原有完整保存提案，只有成功产生 Operation::Save 才调用 expand_confirmation 并聚焦审核正文。不会调用 execute_pending 或 run；再次按键不能确认、替换或重建已有 pending，也不会直接写入。
- 查找快捷键仅调用既有 focus_editor(Draft)，展开同一编辑器，再聚焦已有 editor_find；保留原查询、替换值和草稿，不激活 Kit 第二搜索表面。新增可见“查找 / Find”按钮采用同一打开路径。
- busy、operation_id 存在、suspended、无 session、无 editing、队列详情、已展开审核或非 Draft 表面都拒绝两种快捷键。此批保守停用忙碌/暂停状态的查找快捷键。
- 每个绘制作用域捕获 session token、connection_id、编辑路径及表面；事件按实时状态复核，因此重绘前的连接/文档/表面变化也会拒绝旧监听器。
- 复用现有 Palette、语义 token、Kit 按钮与实时 LocalizedTooltipExt；没有新增主题颜色、token 或依赖。

## 新测试名（9 项，全部尚未编译/运行）

- `files::editor_keyboard_tests::editor_keyboard_save_opens_complete_review_and_repeats_never_confirm`
- `files::editor_keyboard_tests::editor_keyboard_find_reveals_and_focuses_the_single_literal_search`
- `files::editor_keyboard_tests::editor_keyboard_save_from_find_replace_and_toolbar_reviews_only_the_draft`
- `files::editor_keyboard_tests::editor_keyboard_does_not_steal_terminal_or_other_input_shortcuts`
- `files::editor_keyboard_tests::editor_keyboard_rejects_busy_hidden_missing_session_and_pending_frames`
- `files::editor_keyboard_tests::editor_keyboard_old_paint_cannot_follow_a_changed_connection_or_document`
- `files::editor_keyboard_tests::editor_keyboard_suspension_and_unmounted_editor_preserve_drafts`
- `files::editor_keyboard_tests::editor_keyboard_patch_surface_does_not_review_an_unapplied_patch`
- `files::editor_keyboard_tests::editor_keyboard_find_and_save_keep_bilingual_controls_across_three_themes`

测试通过真实 Window::press / KeyDownEvent 分发到当前 GPUI 树；包含重绘前 auto-repeat、完整审核焦点及 Enter 不确认、BOM/CRLF 提案字节、取消零写入、搜索可见/聚焦/实际输入、搜索/替换及按钮子区域、终端 Ctrl+S/Ctrl+F 输出字节、其他输入、busy/active-operation/pending/queue/no-session 旧帧、会话/连接/路径变化、活编辑器卸载、暂停、未应用补丁及三主题双语控件。SFTP 使用现有受控 loopback 协议 peer 与 fixture group；未启动真实客户连接。

## 实际完成的静态检查

- 定向 `rustfmt --edition 2024 --config skip_children=true`：6 个授权文件，exit 0。
- 同 6 文件 `rustfmt --check --edition 2024 --config skip_children=true`：exit 0。
- `git diff --check`：exit 0。
- Git 差分与 untracked 清单核对：恰好上述 6 个源码路径；HEAD 仍为原基线；9 个完整新测试名已从源码提取。

## 剩余风险与父接手事项

- Rust 类型检查、Clippy、GPUI 测试执行与现有布局/审核/搜索回归均 PENDING，作者没有编译或测试通过回执。父应核对新二进制包含上述完整测试名，再执行专项和最终门禁。
- 全局只注册带局部 context 的 keymap，实际快捷键处理属于编辑器子树；需要父用真实 macOS 验证平台键路由、重复按键、最小窗口和双语 tooltip。Windows/Linux 原生输入、IME、VoiceOver/辅助技术均未验收。
- 同窗口完整 Workspace 连接切换及系统事件注入未由作者运行；当前回归通过改变真实 FilesPanel 的会话/连接/路径身份及卸载其实际视图测试拒绝边界。
- 父已告知真实 macOS 组合键测试应使用 CGEvent.post(.cghidEventTap)；作者未引入原生事件注入 helper。
- 父的 UTF-16 末尾 LF/CR 修复与新增编码测试不在作者写集；集成时保留父的 merge.rs/editor_format_tests.rs 修改。
