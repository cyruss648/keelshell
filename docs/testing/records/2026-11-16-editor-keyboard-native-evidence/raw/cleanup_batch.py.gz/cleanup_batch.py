"""Remove only this sealed batch after exact source and originals enter Git."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
EVIDENCE = ROOT / "docs/testing/records/2026-11-16-editor-keyboard-native-evidence"


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--commit", required=True)
    args = parser.parse_args()
    assert len(args.commit) == 40
    assert BASE == ROOT / "work/editor-native-20261116" and not BASE.is_symlink()
    assert not (EVIDENCE / "cleanup-final.json").exists()
    head = subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=ROOT, timeout=15,
    ).decode().strip()
    assert head == args.commit
    binding = json.loads((EVIDENCE / "commit-input-binding.json").read_text())
    assert binding["source_commit"] == head and not binding["mismatches"]
    subprocess.run(
        [sys.executable, "-B", str(EVIDENCE / "verify_binding.py"),
         "--commit", head,
         "--output", str(EVIDENCE / "pre-cleanup-commit-binding.json")],
        cwd=ROOT, timeout=60, check=True,
    )
    gate = json.loads((BASE / "full-gate-r2.json").read_text())
    assert gate["exit_code"] == 0 and gate["reaped"] and not gate["timed_out"]
    resolution = json.loads((BASE / "review-resolution-r1.json").read_text())
    assert resolution["final_full_gate"] == "PASSED"
    assert resolution["scoped_open_findings"] == 0
    assert len(resolution["closed_agents"]) == 4
    archive = json.loads((EVIDENCE / "archive-manifest.json").read_text())
    omitted = json.loads((EVIDENCE / "omitted-artifacts.json").read_text())
    expected = {
        name: (row["source_sha256"], row["source_bytes"])
        for name, row in archive["files"].items()
    }
    assert len(expected) == archive["count"]
    for row in omitted:
        assert row["path"] not in expected
        expected[row["path"]] = row["sha256"], row["bytes"]
    entries = list(BASE.rglob("*"))
    assert all(not path.is_symlink() for path in entries)
    actual = {path.relative_to(BASE).as_posix(): path
              for path in entries if path.is_file()}
    assert set(actual) == set(expected), "Batch changed after evidence sealing"
    for name, path in actual.items():
        checksum, size = expected[name]
        assert path.stat().st_size == size and digest(path) == checksum, name
    binaries = json.loads((BASE / "normal-artifacts.json").read_text())["normal_binaries"]
    for row in binaries:
        path = ROOT / row["path"]
        assert not path.is_relative_to(BASE)
        assert path.stat().st_size == row["bytes"] and digest(path) == row["sha256"]
    target = ROOT / "work/recovery-batch-integration-20261115/target"
    assert target.is_dir() and not target.is_relative_to(BASE)
    native = json.loads((BASE / "native-cleanup.json").read_text())
    assert native["all_owned_sessions_stopped"] and native["total_identities"] == 181
    for row in native["sessions"]:
        assert not row["live_birth_matches"] and row["scratch_absent_now"]
    author = json.loads((BASE / "author-cleanup.json").read_text())
    assert author["path_absent"] and author["git_worktree_record_absent"]
    author_path = Path(author["worktree"])
    registered = subprocess.check_output(
        ["git", "worktree", "list", "--porcelain"], cwd=ROOT, timeout=15,
    ).decode()
    assert not author_path.exists()
    assert "worktree " + str(author_path) + "\n" not in registered
    # Reject batch processes before removal; the current command and its parents
    # necessarily name the batch and are excluded by ancestry, never by substring.
    processes = {}
    for line in subprocess.check_output(
        ["ps", "-axo", "pid=,ppid=,command="], timeout=15,
    ).decode().splitlines():
        fields = line.strip().split(None, 2)
        if len(fields) == 3:
            processes[int(fields[0])] = (int(fields[1]), fields[2])
    ancestors = set()
    pid = os.getpid()
    while pid and pid not in ancestors:
        ancestors.add(pid)
        pid = processes.get(pid, (0, ""))[0]
    active = [
        pid for pid, (_parent, command) in processes.items()
        if pid not in ancestors
        and (str(BASE) in command or "work/editor-native-20261116/" in command)
    ]
    assert not active, active
    file_count = len(actual)
    byte_count = sum(row[1] for row in expected.values())
    shutil.rmtree(BASE)
    assert not BASE.exists()
    for row in binaries:
        path = ROOT / row["path"]
        assert path.stat().st_size == row["bytes"] and digest(path) == row["sha256"]
    assert target.is_dir()
    record = {
        "schema": 1, "recorded_utc": datetime.now(timezone.utc).isoformat(),
        "source_commit": head, "removed_directory": str(BASE),
        "directory_absent": True, "files_removed": file_count,
        "logical_bytes_removed": byte_count,
        "raw_originals_committed": archive["count"],
        "omitted_rebuildable_files": len(omitted),
        "all_batch_files_matched_sealed_hashes_before_removal": True,
        "normal_binaries": binaries, "normal_binaries_preserved": True,
        "only_valid_target_preserved": True,
        "native_cleanup": "raw/native-cleanup.json.gz",
        "native_sessions_stopped_and_181_births_checked": True,
        "author_managed_worktree_path_and_git_record_absent": True,
        "source_authors_and_reviewers_closed": 4,
        "no_user_chat_created": True, "no_container_created_this_batch": True,
        "no_other_task_resource_touched": True,
        "original_failure_and_hold_evidence_preserved_in_git": True,
    }
    with (EVIDENCE / "cleanup-final.json").open("x") as stream:
        json.dump(record, stream, indent=2)
        stream.write("\n")
    print(json.dumps({key: value for key, value in record.items()
                      if key != "normal_binaries"}))


if __name__ == "__main__":
    main()
