"""Confirm the existing English GBK review once and inspect every target byte."""
from editor_flow import *

root = Path(SESSION["fixture_root"])
filename = "legacy-gbk.txt"
original = (root / filename).read_bytes()
assert hashlib.sha256(original).hexdigest() == SESSION["seed_sha256"][filename]
wait_label("GBK; BOM: no; line endings: CRLF")
wait_label("final LF: yes; final CR: no")
observe("03-gbk-resumed-confirm-ready", "final LF: yes; final CR: no")
act("press", "AXButton", "Confirm")
expected = "中文更新\r\nnew value\r\n".encode("gbk")
wait(lambda tree: (root / filename).read_bytes() == expected, "complete GBK save")
backups = list(root.glob("." + filename + ".keelshell-backup-*"))
assert len(backups) == 1 and backups[0].read_bytes() == original
observe("03-gbk-resumed-saved")
gbk = {
    "file": filename, "original_bytes": len(original), "final_bytes": len(expected),
    "original_sha256": hashlib.sha256(original).hexdigest(),
    "final_sha256": hashlib.sha256(expected).hexdigest(),
    "cancel_kept_all_original_bytes": True, "repeated_shortcut_did_not_confirm": True,
    "complete_saved_bytes_equal": True, "one_complete_original_backup_equal": True,
    "review_final_lf_yes_final_cr_no_observed": True,
    "continuation": "r7 preserved input/find/repeat/cancel/Chinese and English review; confirmed existing English review once",
}
with (OUTPUT / "03-gbk-resumed-readback.json").open("x") as stream:
    json.dump(gbk, stream, indent=2)
    stream.write("\n")
utf16 = json.loads((OUTPUT / "02-utf16-resumed-readback.json").read_text())
with (OUTPUT / "native-editor-summary.json").open("x") as stream:
    json.dump({"pid": SESSION["pid"], "binary_sha256": SESSION["binary_sha256"],
               "native_cases": [utf16, gbk], "failed_scripts_preserved": True,
               "scope": "macOS arm64, Frost light; Chinese flows and English GBK review; not IME or full accessibility"},
              stream, indent=2)
    stream.write("\n")
print(json.dumps({"native_editor_cases": 2, "continued_existing_session": True}), flush=True)
