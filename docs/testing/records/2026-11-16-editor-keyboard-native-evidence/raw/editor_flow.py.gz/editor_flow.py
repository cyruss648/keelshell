"""Exact native key, review, cancellation and byte/backup observations."""
import hashlib
import json
import os
from pathlib import Path
import time

from observe import action as native_action, observe, OUTPUT, SESSION

sequence = max((int(path.stem.split("-")[1]) for path in OUTPUT.glob("event-*.json")), default=0)


def act(*arguments):
    global sequence
    result = native_action(*arguments)
    sequence += 1
    with (OUTPUT / f"event-{sequence:03}.json").open("x") as stream:
        json.dump({"arguments": arguments, "result": result}, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    time.sleep(0.4)
    return result


def wait(predicate, description):
    deadline = time.monotonic() + 8
    while time.monotonic() < deadline:
        tree = native_action("tree")
        if predicate(tree):
            return tree
        time.sleep(0.1)
    raise RuntimeError("Native state not observed: " + description)


def label_present(tree, text):
    return any(text in str(node.get("AXTitle", node.get("AXValue", ""))) for node in tree["nodes"])


def wait_label(text):
    return wait(lambda tree: label_present(tree, text), text)


def editor_value(tree):
    matches = [node.get("AXValue", "") for node in tree["nodes"]
               if node.get("AXRole") == "AXTextArea"
               and node.get("AXTitle", "").startswith("编辑草稿 · ")]
    return matches[0] if len(matches) == 1 else None


def wait_editor(value):
    return wait(lambda tree: editor_value(tree) == value, repr(value))


def click_node(node):
    tree = native_action("tree")
    window = [item for item in tree["cgWindows"] if item["kCGWindowLayer"] == 0]
    assert len(window) == 1
    bounds = window[0]["kCGWindowBounds"]
    position = node["AXPosition"]
    size = node["AXSize"]
    act("click", str(position[0] + size[0] / 2 - bounds["X"]),
        str(position[1] + size[1] / 2 - bounds["Y"]))


def click_label(role, label):
    nodes = [node for node in native_action("tree")["nodes"]
             if node.get("AXRole") == role and node.get("AXTitle") == label]
    assert len(nodes) == 1
    click_node(nodes[0])


def open_file(filename):
    tree = wait_label("选择远程项 " + filename)
    row = next(node for node in tree["nodes"] if node.get("AXTitle") == "选择远程项 " + filename)
    edits = [node for node in tree["nodes"] if node.get("AXTitle") == "编辑"
             and abs(node["AXPosition"][1] - row["AXPosition"][1]) < 10]
    assert len(edits) == 1
    click_node(edits[0])
    wait_label("编辑草稿")
    act("press", "AXButton", "编辑草稿")
    wait_label("返回文件")
    focus_visible_editor()


def focus_visible_editor():
    tree = native_action("tree")
    editor = next(node for node in tree["nodes"]
                  if node.get("AXRole") == "AXTextArea"
                  and node.get("AXTitle", "").startswith("编辑草稿 · "))
    click_node(editor)


def enter_draft(first_line, second_line):
    act("key", "0", "1048576")  # Cmd+A
    act("key", "51")  # Backspace; observe the cleared draft before typing.
    wait_editor("")
    act("text", first_line)
    wait_editor(first_line)
    act("key", "36")
    wait_editor(first_line + "\n")
    act("text", second_line)
    wait_editor(first_line + "\n" + second_line)
    act("key", "36")
    return wait_editor(first_line + "\n" + second_line + "\n")


def review_save():
    act("key", "1", "1048576")  # Cmd+S only requests a review.
    wait_label("审核最终全文并保存")
    wait_label("收起审核")


def assert_unchanged(root, filename, original):
    assert (root / filename).read_bytes() == original
    assert not list(root.glob("." + filename + ".keelshell-backup-*"))


def save_case(root, filename, first, second, expected, prefix, already_typed=False):
    original = (root / filename).read_bytes()
    if already_typed:
        wait_editor(first + "\n" + second + "\n")
    else:
        open_file(filename)
        enter_draft(first, second)
    observe(prefix + "-input", first)
    # Finding must bring the sole application-owned search field into focus.
    act("key", "3", "1048576")  # Cmd+F
    wait(lambda tree: any(node.get("AXRole") == "AXTextField"
                         and node.get("AXTitle") == "查找草稿文本" and node.get("AXFocused")
                         for node in tree["nodes"]), "focused Find field")
    observe(prefix + "-find-focused", "查找下一个")
    tree = native_action("tree")
    editor = next(node for node in tree["nodes"]
                  if node.get("AXRole") == "AXTextArea"
                  and node.get("AXTitle", "").startswith("编辑草稿 · "))
    click_node(editor)
    review_save()
    observe(prefix + "-review", "末尾 LF：有；末尾 CR：无")
    act("key", "1", "1048576")  # Repeating the key cannot approve.
    wait_label("收起审核")
    assert_unchanged(root, filename, original)
    observe(prefix + "-repeated-save-still-review", "确认")
    act("press", "AXButton", "取消")
    assert_unchanged(root, filename, original)
    observe(prefix + "-cancelled")
    act("press", "AXButton", "编辑草稿")
    wait_editor(first + "\n" + second + "\n")
    focus_visible_editor()
    review_save()
    observe(prefix + "-final-review", "末尾 LF：有；末尾 CR：无")
    if filename == "legacy-gbk.txt":
        act("press", "AXButton", "切换语言：中文或英文")
        wait_label("final LF: yes; final CR: no")
        observe(prefix + "-english-review", "final LF: yes; final CR: no")
    act("press", "AXButton", "Confirm" if filename == "legacy-gbk.txt" else "确认")
    wait(lambda tree: (root / filename).read_bytes() == expected
         and not label_present(tree, "审核最终全文并保存"), "complete saved readback")
    backups = list(root.glob("." + filename + ".keelshell-backup-*"))
    assert len(backups) == 1 and backups[0].read_bytes() == original
    observe(prefix + "-saved")
    receipt = {
        "file": filename, "original_bytes": len(original), "final_bytes": len(expected),
        "original_sha256": hashlib.sha256(original).hexdigest(),
        "final_sha256": hashlib.sha256(expected).hexdigest(),
        "cancel_kept_all_original_bytes": True, "repeated_shortcut_did_not_confirm": True,
        "complete_saved_bytes_equal": True, "one_complete_original_backup_equal": True,
        "review_final_lf_yes_final_cr_no_observed": True,
    }
    with (OUTPUT / (prefix + "-readback.json")).open("x") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    return receipt


if __name__ == "__main__":
    act("activate")
    resume = os.environ.get("KEELSHELL_NATIVE_RESUME") == "typed-utf16"
    if not resume:
        username = SESSION["state_fixture"]["connections"][0]["username"]
        port = SESSION["ports"]["target"]
        wait_label(f"连接: 原生验证 · 直连 · {username}@127.0.0.1:{port}")
        act("press", "AXButton", f"连接: 原生验证 · 直连 · {username}@127.0.0.1:{port}")
        wait_label("密码或私钥")
        act("press", "AXButton", "连接")
        pin = "收到的指纹: " + SESSION["host_fingerprints"]["target"]
        wait_label(pin)
        observe("01-exact-independent-pin", pin)
        act("press", "AXButton", "信任此指纹并重新连接")
        wait_label("密码或私钥")
        act("press", "AXButton", "连接")
        wait_label("SSH 会话: 原生验证 · 直连")
    root = Path(SESSION["fixture_root"])
    results = [
        save_case(root, "unicode-le.txt", "第一行", "updated second",
                  b"\xff\xfe" + "第一行\r\nupdated second\r\n".encode("utf-16le"),
                  "02-utf16-resumed" if resume else "02-utf16", already_typed=resume),
    ]
    click_label("AXCheckBox", "下一次读取编码: Unicode 自动")
    wait_label("下一次读取使用 GBK")
    click_label("AXCheckBox", "下一次读取使用 GBK")
    wait_label("下一次读取编码: GBK")
    results.append(
        save_case(root, "legacy-gbk.txt", "中文更新", "new value",
                  "中文更新\r\nnew value\r\n".encode("gbk"), "03-gbk"),
    )
    with (OUTPUT / "native-editor-summary.json").open("x") as stream:
        json.dump({"pid": SESSION["pid"], "binary_sha256": SESSION["binary_sha256"],
                   "native_cases": results, "events": sequence,
                   "scope": "macOS arm64; Chinese flows and English GBK review; configured theme in session; not IME or complete accessibility"},
                  stream, indent=2)
        stream.write("\n")
    print(json.dumps({"native_editor_cases": len(results), "events": sequence}), flush=True)
