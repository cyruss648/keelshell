"""Continue the preserved, explicitly reviewed Frost session; never replay a write."""
from editor_flow import *

root = Path(SESSION["fixture_root"])
filename = "unicode-le.txt"
original = (root / filename).read_bytes()
assert hashlib.sha256(original).hexdigest() == SESSION["seed_sha256"][filename]
wait_label("审核最终全文并保存")
wait_label("末尾 LF：有；末尾 CR：无")
observe("02-utf16-resumed-confirm-ready", "末尾 LF：有；末尾 CR：无")
act("press", "AXButton", "确认")
expected = b"\xff\xfe" + "第一行\r\nupdated second\r\n".encode("utf-16le")
wait(lambda tree: (root / filename).read_bytes() == expected
     and not label_present(tree, "审核最终全文并保存"), "complete UTF-16 save")
backups = list(root.glob("." + filename + ".keelshell-backup-*"))
assert len(backups) == 1 and backups[0].read_bytes() == original
observe("02-utf16-resumed-saved")
utf16 = {
    "file": filename, "original_bytes": len(original), "final_bytes": len(expected),
    "original_sha256": hashlib.sha256(original).hexdigest(),
    "final_sha256": hashlib.sha256(expected).hexdigest(),
    "cancel_kept_all_original_bytes": True,
    "repeated_shortcut_did_not_confirm": True,
    "complete_saved_bytes_equal": True, "one_complete_original_backup_equal": True,
    "review_final_lf_yes_final_cr_no_observed": True,
    "continuation": "r4 preserved input/find/repeat/cancel observations; final Cmd+S retried explicitly, then confirmed once",
}
with (OUTPUT / "02-utf16-resumed-readback.json").open("x") as stream:
    json.dump(utf16, stream, indent=2)
    stream.write("\n")
act("press", "AXCheckBox", "下一次读取编码: Unicode 自动")
wait_label("下一次读取使用 GBK")
act("press", "AXButton", "下一次读取使用 GBK")
wait_label("下一次读取编码: GBK")
gbk = save_case(root, "legacy-gbk.txt", "中文更新", "new value",
                "中文更新\r\nnew value\r\n".encode("gbk"), "03-gbk")
with (OUTPUT / "native-editor-summary.json").open("x") as stream:
    json.dump({"pid": SESSION["pid"], "binary_sha256": SESSION["binary_sha256"],
               "native_cases": [utf16, gbk],
               "scope": "macOS arm64, Frost light; Chinese flows and English GBK review; not IME or full accessibility",
               "failed_scripts_preserved": True}, stream, indent=2)
    stream.write("\n")
print(json.dumps({"native_editor_cases": 2, "continued_existing_session": True}), flush=True)
