"""Finish the still-unmodified GBK file using actual native pointer entry."""
from editor_flow import *

if not label_present(native_action("tree"), "下一次读取使用 GBK"):
    wait_label("下一次读取编码: Unicode 自动")
    click_label("AXCheckBox", "下一次读取编码: Unicode 自动")
wait_label("下一次读取使用 GBK")
click_label("AXCheckBox", "下一次读取使用 GBK")
wait_label("下一次读取编码: GBK")
root = Path(SESSION["fixture_root"])
gbk = save_case(root, "legacy-gbk.txt", "中文更新", "new value",
                "中文更新\r\nnew value\r\n".encode("gbk"), "03-gbk")
utf16 = json.loads((OUTPUT / "02-utf16-resumed-readback.json").read_text())
with (OUTPUT / "native-editor-summary.json").open("x") as stream:
    json.dump({"pid": SESSION["pid"], "binary_sha256": SESSION["binary_sha256"],
               "native_cases": [utf16, gbk], "failed_scripts_preserved": True,
               "scope": "macOS arm64, Frost light; Chinese flows and English GBK review; not IME or full accessibility"},
              stream, indent=2)
    stream.write("\n")
print(json.dumps({"native_editor_cases": 2, "continued_existing_session": True}), flush=True)
