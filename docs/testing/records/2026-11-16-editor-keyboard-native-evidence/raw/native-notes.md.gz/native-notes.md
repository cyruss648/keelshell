# 原生证据边界

正常程序为 `normal-artifacts.json` 中的 macOS arm64 暂存包，不安装、不覆盖已有应用。
原生会话使用独立数据和自有 localhost OpenSSH，主机 pin 来自独立 ssh-keygen。

`baseline` 是旧程序的探索，确认 UTF-16 字节保存与备份正确，但审核末尾 LF
显示错误；不作为新快捷键验收。`candidate-frost-r1` 因启动就绪与清空草稿未
被观察而停止，没有完成保存。其余失败和截图保持。

`candidate-frost-r2` 使用最终正常程序，按多个明确接续动作完成 UTF-16 LE 与
GBK 两个原生流程。r3 在 observation helper 只检查标题、遗漏同时存在的 AXValue
时失败；旧 helper 另存。r4 已完成真实输入、Cmd+F 聚焦、Cmd+S 展开、重复不确认、
取消后的原字节核对，第二次注入未观察到新审核；随后单次显式 Cmd+S 打开审核。
r5 对已有 UTF-16 审核只确认一次，完整目标/原始备份核对通过，随后停在编码浮层
的 AXPress 未打开。r6 实际指针打开浮层，但选项实际角色是 AXCheckBox，而不是
原脚本要求的 AXButton。r7 接续选项，完成 GBK 的输入、查找、审核、重复、取消、
再次完整审核与英文审核截图；立即切回中文未生效，未确认保存。
r8 对仍存在的英文审核只确认一次，完整 GBK 目标与原始备份核对通过。
最终两份 readback 与 native-editor-summary 引用这些实际接续事实；
不能把 r1–r7 改签为完整脚本成功。

首个合成组合键或紧接 AX 动作的注入有未被观察的情况。仅原生观测与后来
显式操作无法证明所有未到达事件的原因；保留 HOLD，不认定已修复全部键盘或
辅助技术问题，也不将所有早期失败一概宣称为已证实的工具错误。

`candidate-graphite-r1` 在合成 Cmd+A/Backspace 后未观察到空草稿，未到达本片
新的 S/F 快捷键，保持 HOLD。三份种子文件原字节均保持，备份数为零；
只计深色 Graphite 窗口观察。Lavender 本批没有新的原生执行。
三主题双语的实际 GPUI 回归另有 9 项专项及独立预构建复核，不代签三主题桌面。

`native-cleanup.json` 已独立重读四个会话的结束回执和当前 Darwin birth identity；
181 条跟踪身份无活匹配，12 个受管根进程均有 stop/wait，八次端口关闭观察、
四个私有目录已回收。没有创建容器或用户 chat。
