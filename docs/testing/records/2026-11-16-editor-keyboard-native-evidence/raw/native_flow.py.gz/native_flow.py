"""Exercise exact native controls against independently generated fixture pins."""
import json
from pathlib import Path
import time

from observe import OUTPUT, SESSION, action, observe


def labels(tree):
    return [str(node.get("AXTitle", node.get("AXValue", ""))) for node in tree["nodes"]]


def wait(text, *, exact=False):
    deadline = time.monotonic() + 8
    while time.monotonic() < deadline:
        tree = action("tree")
        if any(label == text if exact else text in label for label in labels(tree)):
            return tree
        time.sleep(0.1)
    raise RuntimeError("Native label not observed: " + text)


def press(name, role, label, expected):
    wait(label, exact=True)
    receipt = action("press", role, label)
    with (OUTPUT / (name + "-action.json")).open("x") as stream:
        json.dump(receipt, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    tree = wait(expected)
    observe(name, expected)
    return tree


def approve(name, role):
    expected = "收到的指纹: " + SESSION["host_fingerprints"][role]
    tree = wait(expected, exact=True)
    assert expected in labels(tree), "the independent fixture pin must match exactly"
    observe(name + "-identity", expected)
    press(name + "-approved", "AXButton", "信任此指纹并重新连接", "密码或私钥")


if __name__ == "__main__":
    action("activate")
    ports = SESSION["ports"]
    username = SESSION["state_fixture"]["connections"][0]["username"]
    direct = f"连接: 原生验证 · 直连 · {username}@127.0.0.1:{ports['target']}"
    press("01-direct-auth", "AXButton", direct, "密码或私钥")
    press("02-direct-key", "AXButton", "连接", "收到的指纹:")
    approve("03-direct", "target")
    press("04-direct-live", "AXButton", "连接", "SSH 会话: 原生验证 · 直连")
    relayed = f"连接: 原生验证 · 经跳板\n{username}@127.0.0.1:{ports['target']}\n已保存"
    press("05-relay-auth", "AXRow", relayed, "连接步骤 1/2")
    press("06-jump-key", "AXButton", "连接", "收到的指纹:")
    approve("07-jump", "jump")
    press("08-target-auth", "AXButton", "连接", "连接步骤 2/2")
    # Deliberately span multiple real 200ms maintenance ticks at the prompt.
    started = time.monotonic()
    time.sleep(0.85)
    tree = wait("连接步骤 2/2")
    with (OUTPUT / "09-prompt-maintenance-wait.json").open("x") as stream:
        json.dump({"seconds": time.monotonic() - started,
                   "prompt_still_present": True,
                   "purpose": "span multiple real production cleanup ticks"}, stream, indent=2)
        stream.write("\n")
    press("10-routed-target-key", "AXButton", "连接", "收到的指纹:")
    approve("11-routed-target", "target")
    press("12-both-live", "AXButton", "连接", "SSH 会话: 原生验证 · 经跳板")
    press("13-monitor", "AXCheckBox", "主机信息", "路径比较")
    press("14-path-panel", "AXButton", "路径比较", "刷新可比路线")
    press("15-path-candidates", "AXButton", "刷新可比路线", "B:")
