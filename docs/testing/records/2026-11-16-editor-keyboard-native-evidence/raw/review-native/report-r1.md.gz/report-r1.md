**APPROVE（scoped）— 新非作者严格只读原生证据复核，仅批准 candidate-frost-r2 中明确观察到的 Frost 浅色 UTF-16 LE、GBK 操作片段及两份最终读回。完整 native finish、完整脚本成功和全面桌面验收仍未批准。本 reviewer 工作完成，可释放。**

本报告日期为 2026-11-16。工作目录为 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`；本报告与配套 [report-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-native-20261116/review-native/report-r1.json) 是本轮唯一写入，均位于用户指定批次的 `work/editor-native-20261116/review-native/`。已读 AGENTS、引用的 RTK、HANDOFF、本批正式测试记录和 native-notes，再阅读 fixture、flow、接续脚本、两份 readback、summary、原始 AX、图片、event、日志及四份 session-final。没有执行这些原生脚本。

| 本轮限定范围发现 | P0 | P1 | P2 | P3 |
|---|---:|---:|---:|---:|
| 新提出 | 0 | 0 | 0 | 0 |
| 范围内最终开放 | 0 | 0 | 0 | 0 |

未发现阻止上述已观察片段成立的新证据断点，因此没有新增 notice。这个零发现结论不关闭原生键盘投递 HOLD、完整辅助技术、其他主题或其他平台的开放项。

**冻结与既有复核绑定。** 当前 HEAD 为 `92c8ddaab84d19a1044a5803d73a0495d0b89354`。按 freeze.py 的同一规则重新枚举 Git-visible、非 docs 的完整工程路径集合并逐项计算 SHA-256，实际 **715 项**，与 final-inputs-r2.json 的路径和摘要完全一致；集合摘要为：

`a17d4a12b9187755a59af96f99afa5f0998498b0de1a980de0bb9c13f2916c3c`

与 review-source 已批准的 candidate-inputs-r2 比较，唯一变化为 `scripts/test_monitor_recovery_lab.py`，其余 **714 项不变**。review-source JSON 中的 **8 个 Rust 文件**逐项与当前字节一致；Python 的 9 行窄差分由 review-runner/report-r1.md 单独批准。本轮没有重新审签其测试执行结果，也没有重新编译。签署前再次核对完整冻结及保护原件，结果列入配套 JSON。

**实际核验数。** 下表分别计数证据和当前只读核对；不将读取证据计成重新执行原生用例。

| 核验对象 | 本轮实际数量及结果 |
|---|---|
| 工程输入 | 715 项完整集合匹配；8 个既有批准 Rust 文件单独匹配 |
| 正常暂存包 | normal-artifacts 的 6 个 package_files 全部大小/SHA 匹配 |
| AX 原件 | 41 份全部解析，其中 candidate-frost-r2 的 21 份逐项核对；21 份 PID、foregroundPID 均为 71491 |
| view_image 实看原始 PNG | **24 张**：candidate-frost-r2 全部 21 张，加 baseline/13、candidate-frost-r1 清空失败、Graphite HOLD 各 1 张 |
| Frost event 回执 | **45 份**，连续编号 001–045，全部绑定 PID 71491 |
| 原始 flow 进程回执与日志 | **9 组**；Frost r1–r7 与 Graphite r1 合计 8 个 exit 1，Frost r8 为 exit 0；全部 reaped、无 timeout |
| 两份最终读回 | **2 份**；独立重建的 4 组原始/最终字节数与 SHA 全部匹配，summary 原样嵌入这两份内容 |
| 当前清理身份核对 | **181 条** Darwin kernel birth identity：0 同身份匹配、0 不明身份；4 个私有目录及其规范路径均 lstat absent |
| 只读一致性探针 | **48 项：46 项匹配，2 项保存状态 AX 文本搜索未命中**；未命中保持为辅助技术限制，未改写为通过 |
| 本轮重新运行 Rust / Python 测试、原生用例、独立编译 | **均为 0** |

配套 JSON 保留每项探针、715 项摘要、276 份保护原件摘要、41 份 AX 的相关原始字段、45 个事件、9 组执行回执，以及全部当前 birth 读回。两项 AX 未命中不影响已经分别存在的完整正文、截图、现场字节相等断言及最终 readback，详见下文限制。

**身份、真实输入和快捷键。** candidate-frost-r2 的 session-live/session-final 与 summary 都绑定实际暂存 app 的相同摘要，PID 71491；配置为 Frost/light、独立 KEELSHELL_DATA_DIR、初始 known_hosts 为空，目标为自有 localhost `127.0.0.1:61463`。fixture 在 [native_fixture.py:120](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-native-20261116/native_fixture.py:120) 对生成的目标公钥执行独立 `ssh-keygen -lf … -E sha256`。原始 [pin AX:253](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-native-20261116/candidate-frost-r2/01-exact-independent-pin-ax.json:253) 和实看 PNG 显示完全相同的 `SHA256:YMPWN/+SfI2lTh53kv12SfIpJ6esc0bQsY53dzs2SbA`；event-004 才执行信任，之后 event-005 连接。这里只批准该直连 pin，未把两个文件算作两次独立主机验证，也未代签跳板流程。

native_ax.swift 的 text/key 分支使用前台 PID 守卫后的 macOS CGEvent；text 逐字符 Unicode 输入，Enter 是独立 keyCode 36，确认按钮为真实 AXPress。这里的“真实原生输入”指实际 macOS 应用收到合成事件并形成可见/AX 状态，不等于人工物理键盘或 IME 验收。复核期间没有运行 helper 或发出任何键盘事件。

| 片段 | 原始事件与状态对应 |
|---|---|
| UTF-16 输入 | event-010 输入 `第一行`，011 Enter，012 输入 `updated second`，013 Enter。`02-utf16-resumed-input` 的 AXValue 精确为 `第一行\nupdated second\n`，PNG 可见两行正文及空第三行。旧 `02-utf16-input` 的失败标记 `expected_label_missing=第一行` 原样保留；同时其原始 AXValue 已含该正文，符合本轮观测 helper 曾遗漏 AXValue 的限定解释。 |
| UTF-16 查找和审核 | event-015 Cmd+F；[find-focused AX:1338](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-native-20261116/candidate-frost-r2/02-utf16-resumed-find-focused-ax.json:1338) 的唯一“查找草稿文本”AXTextField 聚焦为 true，PNG 有焦点环。回到草稿后 event-017 Cmd+S 展开完整审核；018 重复 Cmd+S 后仍有同一完整审核和确认/取消按钮。 |
| UTF-16 取消与接续 | event-019 取消。flow 在重复键之后和取消之后均执行 [editor_flow.py:140](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-native-20261116/editor_flow.py:140) 的完整原字节及零备份断言；r4 日志实际到达 cancelled 后才在下一次审核等待失败。`00-flow-r4-final-review-missing` 仍是草稿；`00-manual-second-save`、`02-utf16-resumed-confirm-ready` 才再次显示完整审核。 |
| UTF-16 单次确认 | [event-022](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-native-20261116/candidate-frost-r2/event-022.json) 唯一一次“确认”；[finish_frost.py:11](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-native-20261116/finish_frost.py:11) 随后等待目标完整字节等于 expected、审核关闭，并断言唯一备份完整等于原始内容，之后才写 UTF-16 readback。r5 的失败发生在这之后的编码浮层等待，UTF-16 已完成部分可以单独成立。 |
| GBK 输入 | 指针事件 024/025 接续编码浮层；输入 AX 和审核共同证明使用 GBK。031 输入 `中文更新`，032 Enter，033 输入 `new value`，034 Enter；`03-gbk-input` 的精确 AXValue 为 `中文更新\nnew value\n`，PNG 可见两行及空第三行。 |
| GBK 查找、审核、取消 | 035 Cmd+F 后唯一查找框聚焦；037 Cmd+S 展开完整审核，038 重复后仍待审；039 取消。相同 flow 原字节/零备份断言位于这些实际到达的日志标记前。042 再次 Cmd+S 展开完整审核；043 切英文后 `03-gbk-english-review` 同时保留完整两行正文、21→21 bytes、GBK/no BOM/CRLF 和正确尾换行信息。 |
| GBK 单次确认 | r7 的 044 切回中文未被观察，仍保持英文待审。r8 在重新观察现存英文完整审核并核对原始 seed SHA 后，才以 [event-045](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-native-20261116/candidate-frost-r2/event-045.json) 唯一一次 `Confirm`；[complete_gbk_review.py:13](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-native-20261116/complete_gbk_review.py:13) 等待完整目标相等，断言唯一完整原始备份，再写 readback/summary。r8 实际 exit 0 / reaped / 1.2020929159916705s。 |

没有发现第二次“确认”或 `Confirm` 的 event；重复 S 只有请求/保持审核的观察。UTF-16 的手工补发 Cmd+S 没有单列 event 回执，不能声称 45 份 event 覆盖了会话内每一次操作；其后的完整待审状态有原始 AX/PNG，且单次确认及后续读回独立存在。本报告批准首次有回执的 Cmd+S 审核行为和后续实际待审/确认片段，不替补那个未观察到的 r4 第二次审核。

**图片直接观察。** baseline/13-utf16-expanded-review.png 的同一 38→44 字节 UTF-16 LE/BOM/CRLF 审核显示“末尾 LF：无；末尾 CR：无”；candidate-frost-r2/02-utf16-resumed-review.png 显示“末尾 LF：有；末尾 CR：无”。两图完整正文均为“第一行 / updated second”，审核下方确认、取消动作可见；候选的内容和正确尾字符元数据在同屏内，不以屏外 AX 代替可见性。

`03-gbk-review`、`03-gbk-final-review` 为中文完整审核；`03-gbk-english-review`、`03-gbk-resumed-confirm-ready` 为英文完整审核，均清楚显示“中文更新 / new value”、GBK、无 BOM、CRLF；英文为 `final LF: yes; final CR: no`。重复保存截图仍待审；取消截图返回文件/草稿视图，两个 saved 截图则显示保存与完整读回状态及原内容备份提示。保存后的 AXTextArea 分别精确含 `第一行\r\nupdated second\r\n` 和 `中文更新\r\nnew value\r\n`。

Frost r1 清空失败图和 Graphite HOLD 图均仍显示原 seed 的“第一行 / second line”选择状态，没有空草稿；r4-final-review-missing 图也确实没有审核。上述失败图片均按失败阅读，未当作候选通过图。

**完整字节与唯一备份。** [fixture seed:87](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-native-20261116/native_fixture.py:87) 的原始 Unicode 文件是 `FF FE` 加 UTF-16LE 的 `第一行\r\nsecond line\r\n`，原始 GBK 文件为 GBK 的 `中文内容\r\nold value\r\n`。本轮用标准编码独立重新构造原始/目标完整字节，结果如下：

| 对象 | 字节数 | 独立计算并与 readback 匹配的 SHA-256 |
|---|---:|---|
| UTF-16 LE 原始及唯一原始备份 | 38 | `f1eb5270d271357f886471b6baec07365c96308a0a58708d1a7d03788360929b` |
| UTF-16 LE 最终目标 | 44 | `d00d6cecdd4be69db66ef0cd4022f46bebcb39c512503c3637e4a11f71b6f90a` |
| GBK 原始及唯一原始备份 | 21 | `37e255ea3c700aefc573033c3f1c247b77d9fbcdfb55de3772068913a7cb424f` |
| GBK 最终目标 | 21 | `fb1032d55ab1c8a8faaffd21f01ade30000b91353d46df8e7eb8430665efa56a` |

UTF-16 最终字节保留 BOM 和 CRLF；GBK 最终为无 BOM、CRLF。两个 continuation 脚本在确认前都用当前原文件完整 SHA 对照 session seed，确认后读取整个目标，与 expected 完整字节作相等比较；备份 glob 必须恰为 1，且 `backup.read_bytes() == original`，不是抽样、长度相等或摘要自报即可通过。两个 readback 的 SHA 计算自已被完整相等断言约束的 expected/original；备份未另列独立 SHA 字段，其 SHA 由完整相等关系导出。r5/r8 实际到达的 saved 日志与 readback 写入顺序支持上述断言已经经过。

这是对保留的现场执行链、原生状态及两份读回的非作者证据复核。现场私有目录、目标和备份均已回收；本轮没有再次读取已经不存在的目标或备份，也不声称取得第二份独立现场字节采集。完整字节的十六进制独立推导保存在配套 JSON。

**正常二进制来源与 metadata 的实际范围。** 本轮只读取暂存包及 baseline 暂存 MCP，不读取或操作共享 target。实际 app 为 **198,960,496 bytes**，SHA-256：

`ec0a4c3d538a9997c528495207d966bc58ebeb4633baebe61b3bb97b64dcbf1e`

该值与 normal-artifacts、package-manifest、candidate session 及 summary 一致。MCP 实际为 **14,548,464 bytes**，SHA-256 `0e5efdcbe2069fb4ea3c809a99419c557d11ba0ba18e7ba8e5fc6ea0e9bde816`，与 baseline 暂存 MCP 相同。其余 Info.plist、PkgInfo、icns、manifest 也逐项核对。

直接解析两个暂存 Mach-O 头均为 arm64 / MH_EXECUTE；LC_BUILD_VERSION 为 macOS，minos **11.0**、SDK **27.2**；Info.plist 的 LSMinimumSystemVersion 实际为 **15.0**、版本 **0.1.0**。两个 minimum 字段按实际分别记录，不外推旧 macOS 兼容性。父 normal build 回执为 exit 0 / reaped / 6.151247500005411s，日志明确本 checkout 的 keelshell-app 编译；inspect 回执为 exit 0 / reaped / 0.18802891700761393s。

normal-artifacts 中指向 target 的 normal_binaries 两行在本报告只作为父来源记录，未另行读取 target 核对。package manifest 没有嵌入本批 715 项源码集合摘要；本报告只能确认冻结、既有批准源码、父构建记录和实际暂存产物之间的上述对应，**没有独立重新编译或可复现构建证明**。不批准签名、安装、发行或所有系统版本兼容性。

**停止证据与当前只读核对。**

| 会话 | 跟踪 birth 身份 | 当前匹配 | 受管根进程（app / target / jump） | 结束端口关闭回执 | 当前私有目录 |
|---|---:|---:|---|---|---|
| baseline | 50 | 0 | 34455 / 34445 / 34452 | 53750 / 53751 均 true | absent |
| candidate-frost-r1 | 19 | 0 | 68574 / 68564 / 68571 | 60762 / 60763 均 true | absent |
| candidate-frost-r2 | 85 | 0 | 71491 / 71481 / 71488 | 61463 / 61464 均 true | absent |
| candidate-graphite-r1 | 27 | 0 | 86514 / 86503 / 86510 | 62468 / 62469 均 true | absent |

native-cleanup 与四份 session-final 的数量一致，总计 **181 身份、12 根进程 stop/reap、8 次结束端口关闭观察、4 私有目录**。四份 process_cleanup 各有 3 个 true；fixture 调用的 stop_owned 通过 Popen.poll 回收直属进程并检查跟踪后代后返回。回执未逐根记录退出码，本报告没有补造。当前使用只读 `proc_pidinfo(PROC_PIDTBSDINFO)` 对全部 181 个 PID 比较内核 birth 秒/微秒，均无匹配且本次均已 absent；私有目录另对原始路径和规范路径作 lstat，均 absent。未连接端口或重放清理；8 个端口的结论限定为保留的结束时观察。

已实际阅读四会话各 app/target/jump 日志：app、jump 均为空；各 target 保留 BSM audit 权限提示及 SIGTERM 收尾记录。空日志不作为功能成功证据，现存警告不擦除。

**失败保持与批准限制。** Frost r1 是未就绪控件选择失败，r2 是未观察到清空，r3 是观测 helper 未查 AXValue，r4 在第二次审核未到达，r5 在 UTF-16 读回完成后编码浮层未打开，r6 在选项角色 AXButton/AXCheckBox 不匹配处失败，r7 在英文审核后切回中文未生效处失败；**r1–r7 的 exit 1 全部保持**。旧 helper 原件保持。只有 r8 的“确认已有英文 GBK 审核并读取结果”脚本实际 exit 0，不由它反推整条 editor_flow.py 成功。

部分首个组合键或紧接 AX 动作的注入未被观察，根因没有全部证明，键盘投递仍 HOLD；不将这些失败一概归咎工具。Graphite 本轮未观察到清空，未到达新的 S/F，保持 HOLD；native-hold 的三个 seed 保持/零备份只按原件签署，深色窗口可见性不能变成保存通过。Lavender 本批 NOT_RUN；先前 GPUI 专项和预构建测试不代签这两个主题的桌面。

两个保存结果的状态提示在 PNG 可见，但 AX 没有对应提示文本。本轮两次额外 AX 搜索未命中已原样保留在 JSON；不会以图片文字冒充 AX 语义完备，也不会用这些未命中否定另有完整正文、字节断言与 readback 的有限结论。IME、完整 VoiceOver/辅助技术、完整键盘矩阵、Windows/Linux、完整 native finish、签名安装和完整产品目标均开放。

本次不签署 full-gate-r2；该门禁由父独立完成并绑定最终输入。本报告仅允许父将上述 Frost 已观察片段与两份精确读回标记 **scoped APPROVE**，不能据此宣布整条脚本成功或全面桌面通过。276 份已建立保护快照的原件在签署核对时摘要保持，活动 full-gate-r2 文件不纳入静态原件比较。没有源码/格式修改，没有 Cargo、target 读取或修改、commit/push、清理、应用启动、全局键盘，也没有新建 chat/worktree。
