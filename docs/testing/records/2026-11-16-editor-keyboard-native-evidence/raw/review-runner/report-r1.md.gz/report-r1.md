**APPROVE — 新非作者严格只读窄审，仅批准目标 Python 测试相对当前 HEAD 的 9 行差分。**

审查基线及结束 HEAD：`92c8ddaab84d19a1044a5803d73a0495d0b89354`。已读当前 AGENTS、上级 AGENTS 引用的 RTK、HANDOFF 与 STRATEGY，并读取此前非作者 `review-source/report-r1.md` 及其 JSON。审查对象为 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_monitor_recovery_lab.py:371` 至 `:385` 的 `+8/-1`；生产 runner 仅为核对调用顺序和安全断言而只读追踪，不扩大到此前已批准的 Rust 源码。

| 本轮发现 | P0 | P1 | P2 | P3 |
|---|---:|---:|---:|---:|
| 新提出 | 0 | 0 | 0 | 0 |
| 最终开放 | 0 | 0 | 0 | 0 |

没有需要 notice 的阻塞发现。建议批准这份窄差分，并允许父在新冻结上启动最终完整门禁；本报告没有签署完整工程门禁或原生验收。

`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_monitor_recovery_lab.py:371`、`:374`：测试先用真实 digest 构造零库存程序参数，再通过真实 `git rev-parse HEAD` 取得当前完整 SHA，cwd 为 `lab.ROOT`，超时 5 秒，仅替换该次调用的 `--source-sha`。该读取在现有 executable-discovery patch 之前执行；生产 runner 仍自行再次读取 HEAD。若两次读取之间 HEAD 漂移，真实 source guard 仍拒绝。此修改消除了 fixture 的历史 `539c172` 锚定，保留 source guard 的实际执行。

`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_monitor_recovery_lab.py:380` 至 `:385`：原五项断言在 AST 比较中全部原样保留，即 runner exit 1、精确 `PrebuiltInventoryMismatch`、resources 空、cleanup confirmed、所有 cleanup 进程 reaped。新增 `assertTrue(result["cleanup"]["processes"])`，使 `all([])` 不能单独通过生命周期断言。当前共六项断言，没有降低错误类型、资源或清理标准。现有 patch 只让 Podman executable discovery 返回 `unused`，没有 mock Popen、source/digest/inventory 或 cleanup。

生产顺序核对：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/monitor_recovery_lab.py:476`–`:489` 仍依次校验二进制 digest、真实 source HEAD、完整库存，再进入资源 setup；`:127`、`:562`、`:583` 的 stop/reap、processes_confirmed 和最终 cleanup guard 保持。生产 runner 与当前 HEAD、r2 冻结摘要一致，SHA-256 `c4f2326fdc0ed76f1f6a1a1a8a62f05a2bae7a8b4ff62978b106754818acdb79`。本轮独立 suite 还实际通过 digest 不符不启动子进程、库存零/重复/额外/子串拒绝、UNKNOWN 不能由 absent 洗白、owner/full-ID/name、清理屏障和晚到创建等既有回归。

**独立执行结果与命令终态。** 本 reviewer 只运行该 Python 文件一次，`sys.path` 显式加入当前仓库 scripts，再用 `unittest.defaultTestLoader.loadTestsFromModule` 加载该模块的全部测试；实际库存及执行数均为 **23**，不是估计的 35。原始逐名输出在 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-native-20261116/review-runner/independent-suite-r1.log`，完整实际 argv（含内联 Python）和父进程 wait 回执在 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-native-20261116/review-runner/independent-suite-r1.json`，测试名及 audit trace 在 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-native-20261116/review-runner/independent-suite-summary-r1.json`。

| 命令或证据来源 | 实际数 | exit | reaped | 超时 | 耗时 |
|---|---|---:|---|---|---:|
| 独立 `/opt/homebrew/opt/python@3.15/bin/python3.15 -B -c <JSON 中的完整内联 wrapper>`，PID 83890 | 23 passed / 0 failures / 0 errors / 0 skipped | 0 | True | False | 1.644572s |
| 已有父专项 `python3 -B -m unittest discover -s scripts -p test_monitor_recovery_lab.py`，PID 77203 | 23 passed / 0 failed / 0 skipped | 0 | True | False | 1.557706s |
| 旧 `full-gate-r1`：`python3 -B scripts/check.py`，PID 74176，只读取原件 | 工程 Python 284 run / 1 failure / 1 skipped；随后阶段未执行 | 1 | True | False | 11.220978s |

独立运行设置 `PYTHONDONTWRITEBYTECODE=1` 与自有 review-runner/tmp。为在 unittest 删除临时 fixture 之前保留证据，观察 wrapper 先调用原 `write_new`，成功后原样复制焦点用例 result/log/events 字节；Python audit hook 仅记录该用例真实 Popen 的 argv/cwd，不记录环境值。全部生产 guards 均按原函数执行。这是对允许 unittest 的旁路取证，不是另一个替代 runner。

**零库存子进程与零资源的实际证据。** `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-native-20261116/review-runner/zero-inventory-result-r1.json` 记录当前 source SHA 为 `92c8ddaab84d19a1044a5803d73a0495d0b89354`，原始二进制 expected/before/after digest 一致，输入读回 `input_bytes_unchanged=true`。

| 实际命令 | PID | exit | reaped | cleanup observed_stopped |
|---|---:|---:|---|---|
| `001-source-head`：`git rev-parse HEAD` | 83892 | 0 | true | true |
| `002-inventory`：自有临时 `zero-tests --list` | 83895 | 0 | true | true |

inventory 原始 stdout 精确为 `0 tests, 0 benchmarks\n`，保存在 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-native-20261116/review-runner/zero-inventory-002-inventory.log`；因此实际到达并执行了零库存程序，不能以 source-head 子进程替代 inventory 的存在证据。第一次库存检查立即精确失败为 `PrebuiltInventoryMismatch`，第二次 ignored 库存检查未进入；runner 最终为 `FAILED / returncode 1 / observations_admissible=false`，这是该负例的期望结果。

两个 runner 受管子进程的 pid 与 cleanup 两行完全匹配，均有 Darwin birth identity，实际 wait/reap，`observed_stopped=true`；`ancestry_unverified=[]`、`processes_confirmed=true`、`client_barrier_confirmed=true`、`cleanup.confirmed=true`。资源登记 **0**，`resources=[]`、`cleanup.resources=[]`，没有进入 setup 或创建 private_directory。焦点 Popen audit 只有 Git、只读 ps 和零库存程序；没有 Podman 或 `unused` 的执行。由实际调用路径、原始日志和回执共同确认资源创建 **0**，不是对未运行流程的空集合推断。

**r2 冻结与严格只读回验。** 使用与原 freeze 相同的 Git-visible 非 docs 文件路径集合重新计算全部摘要。r2 为 715 项 / `0d8b07451de663fb98b17b5551208c8c9e0cc885f8a6490035827cb62e50bf8b`；本轮开始及结束均为 715 项 / `a17d4a12b9187755a59af96f99afa5f0998498b0de1a980de0bb9c13f2916c3c`。唯一变化是 `scripts/test_monitor_recovery_lab.py`，其余 **714 项不变**，零新增、零缺失。原测试文件在 HEAD/r2 的 SHA-256 为 `9cb9471369c1911fe6883fb5a4574814f237a9dfa2e388884cc03746e65c9fa3`，当前为 `2be3772402b8af367a511c12360dbe4f3534f7df8450e8fe15de23f8862419a1`。此前报告所列 **8 个 Rust 文件**分别与 r2 及此前 reviewer 摘要一致；逐项记录在 `input-audit-start-r1.json`，715 项完整记录在 `freeze-start-r1.json` 和 `freeze-end-r1.json`。

测试前后 HEAD、715 项工程字节和 Git status 均不变；旧 full-gate-r1 JSON/log、父专项 JSON/log、candidate-inputs-r2、final-inputs-r1、此前报告和 notice 共九份保护原件全部摘要不变，见 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-native-20261116/review-runner/input-readback-r1.json`。自有 tmp 测试结束为空。本 reviewer 仅在此 review-runner 内写报告、JSON 和原样日志；没有源码/格式修改，没有运行 Cargo、完整全仓门禁、提交或推送，也没有创建 chat/worktree、清理其他证据或接触共享 target。

**批准边界与交接。** APPROVE 仅覆盖上述 9 行测试差分以及本次实际 23 项 Python 回归。原 r2 非作者的 11 项 Rust 执行结果属于原报告，本轮没有重复执行或新增签署该范围。旧完整门禁 r1 的 `exit 1 / reaped / 11.220978s` 及 SourceShaMismatch 原因保持原状；其 Python 失败之后的 Rust、Clippy 等阶段没有获得本批完整门禁结果。父仍需冻结包含本 Python 修复的最终输入，再运行并绑定一次新的完整成功门禁；本轮 `a17d4a12b9187755a59af96f99afa5f0998498b0de1a980de0bb9c13f2916c3c` 为该时点的独立读回，不改写旧冻结或旧 gate。真实原生、三平台、IME/辅助技术等沿用各自未签署边界。审查工作完成，回报并释放本 reviewer。
