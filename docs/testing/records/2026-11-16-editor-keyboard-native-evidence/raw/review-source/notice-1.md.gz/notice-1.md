# P2 — old-paint 回归首次按键可能先重绘，从而没有执行旧监听器

审查方：本批新非作者，严格只读。此项为测试证据阻塞；未据此认定生产身份守卫失效。keyboard-r3 的 8 pass / 1 fail 保持失败。

位置：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/editor_keyboard_tests.rs:464`、`:480`、`:482`，`key_down` 在 `:216` 通过真实 `Window::dispatch_event` 分发。

触发：新窗口仍处于默认输入 modality 时，先渲染并捕获 editor binding，再直接改变 session_token/connection_id/path，然后送入第一个 KeyDown。测试没有预先将窗口置于键盘 modality，也没有证明分发实际使用的是旧帧。

依据：当前 Cargo.lock 的 gpui-pre 0.3.12 本地原始实现 `/Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837/gpui-pre-0.3.12/src/window.rs:5873-5882` 在 modality 改为 Keyboard 时调用 refresh；同文件 `:6293-6296` 的 dispatch_key_event 见 dirty 会先 draw。于是此次绘制会捕获改变后的身份，生产 `editor_binding_is_current` 可能合法通过。此解释来自独立源码追踪，尚未独立执行失败候选。

影响：当前 old-paint 断言不能区分生产守卫缺陷与框架为首个键盘事件强制重绘；不能把这条测试写成旧监听器拒绝的有效证据，也不能放宽 pending.is_none 使其变绿。

建议修法：在身份改变前用无副作用的真实键盘输入建立 Keyboard modality，随后完整重绘、聚焦并捕获当前帧，再改变身份并分发相同 Save/Find（仍走真实分发）。检查 boundary 诊断与 GPUI 绘制行为；如另有脏帧来源，明确去除夹具中的来源并证明旧监听器路径，而不改动生产身份合同。保留已有失败日志，使用新编号与新冻结验证。
