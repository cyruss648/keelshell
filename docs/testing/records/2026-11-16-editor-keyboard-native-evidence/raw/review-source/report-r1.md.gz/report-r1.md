**APPROVE — 本批新非作者独立严格只读源码复核；最终完整门禁及原生验收待定。**

基线/当前 HEAD：`92c8ddaab84d19a1044a5803d73a0495d0b89354`。批准对象为 `candidate-inputs-r2.json` 的 715 项工程输入，集合 SHA-256：`0d8b07451de663fb98b17b5551208c8c9e0cc885f8a6490035827cb62e50bf8b`。我在测试前后独立重算完整路径集合与逐项摘要，均零缺失、零新增、零漂移。r1→r2 仅 `editor_keyboard_tests.rs` 变化；不把旧 r1 或失败运行改签成功。

已读 AGENTS、RTK、HANDOFF、STRATEGY、SHARED_TARGET；审查基线差分全部 8 个 Rust 文件（显式全文读取新增 `editor_keyboard.rs` 与 `editor_keyboard_tests.rs`）、双语 README、ADR0144、产品与本批测试文档。范围内源码及文档读前读后摘要一致，详见同目录 JSON。

| 本次独立提出 | P0 | P1 | P2 | P3 |
|---|---:|---:|---:|---:|
| 数量 | 0 | 0 | 1 | 0 |
| 最终开放 | 0 | 0 | 0 | 0 |

**notice-1：P2 已关闭。** 原因是夹具首个键盘事件改变 modality 后，GPUI 先重绘，原测试未实际使用旧监听器；不是已证实的生产身份守卫漏洞。当前锁定 `gpui-pre 0.3.12` 的 `window.rs:5873`、`:6293` 支持该解释。修复见 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/editor_keyboard_tests.rs:469`：真实 Left KeyDown 后 render_frame，再修改身份且不 notify，然后真实分发 S/F。session token、connection id、document path 三边界均通过；pending、草稿保留与无远端写入断言未放宽。原 notice、keyboard-r3 的 8/1 和 boundary-0 诊断失败保留。独立源码核对与修后预构建执行足以关闭该项。

源码核查结论：

- `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/editor_keyboard.rs:47`、`:74`、`:89`、`:105`：context 仅装到草稿区域；同时检查焦点路径、可用状态及绘制时捕获的 session/connection/path/surface。busy、operation、pending、队列遮挡、无 session、suspend 及旧身份均保守拒绝。Save 只调用原有 request_save 并展开审核，没有确认或远端执行分支。
- `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files.rs:1069`、`files/review.rs:427`、`files/view.rs:516`（后两者同一绝对父目录）：Kit editor 原有 searchable(false) 保持；限定 Input 深度的绑定与停止传播使查找进入唯一自有搜索区。Patch/Merge 未挂草稿 scope。终端、路径及其他输入测试保持自身行为，终端实际输出通道收到 `13 06`。
- `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/merge.rs:363`、`:374`：末尾 LF/CR 来自准确出站字节按保存格式回解的字符。两项 UTF-16 测试各含 9 组数据，检查大小端、LF/CR/CRLF、空正文、无换行及伪装尾字节字符；同时核对两种语言、准确待保存字节、取消后原文件和零原子写入。18 组数据仍计 **2 项测试**。

**独立执行证据。** 从父 `keyboard-r4.log` 的唯一 Running 路径解析并直接执行以下二进制，没有运行 Cargo、重新编译或修改 target：

`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/recovery-batch-integration-20261115/target/debug/build/keelshell-app/bb7e65d3f7e183e9/out/keelshell_app-bb7e65d3f7e183e9`

大小 `270342304` 字节；SHA-256（执行前、每组执行后、最终均一致）：`981f7aa65376a8199ce8e41e86843187d4316dd12f6f76048cb152b372804af2`。

| 实际参数 | exit | passed / failed / ignored | 其他 |
|---|---:|---|---|
| `--list` | 0 | 不适用 | 1,289 个 test 条目，11 个目标完整存在 |
| `editor_keyboard --test-threads=2` | 0 | 9 / 0 / 0 | 1,280 filtered out |
| `review_uses_final_characters --test-threads=2` | 0 | 2 / 0 / 0 | 1,287 filtered out |

三个进程均实际 reap、未超时。键盘测试通过 Window::press / KeyDownEvent → dispatch_event；审核和 Unicode 保存入口通过真实鼠标事件分发，不是直接调用待测键盘 helper。重复/held 保存键及 Enter 不确认，搜索/替换/工具栏焦点、终端/其他输入、busy/pending、旧帧、卸载/suspend、patch 和三主题×双语均有上述实际用例。草稿内容用 set_value 布置；SSH/SFTP 为受控 loopback fixture，终端 transport 使用测试通道，均不代表原生桌面或实际 PTY 验收。

`report-r1.json` 保留全部 715 项摘要、文档/源码摘要、完整二进制库存、11 个精确测试名、命令/pid/exit/耗时/原始输出和二进制前后摘要。首次清单包装脚本因我误写 Unicode 模块前缀 exit 1；二进制 --list 自身 exit 0。按源码嵌套声明纠正后确认 11 名齐全，原记录保留，没有修改测试或重复计数。

**批准条件与限制。** 本报告批准上述冻结的源码及已执行专项；这是父预构建产物的独立直接执行，**没有独立重新编译**。最终格式、Clippy、全套测试和依赖政策由父在相同最终输入上完成并绑定成功回执后，才满足本地功能提交条件。macOS UTF-16/GBK 的真实键盘、原始备份与完整字节读回仍待单独验收；Windows/Linux 原生、IME 与完整辅助技术未签通过。父后续源码修复需要对应新冻结及窄差分复核。审查工作完成，释放本 reviewer；未创建 worktree/chat，写入限于指定 review-source 内的 notice 与报告。
