"""Bounded batch commands with immutable output and actual wait receipts."""
import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument("name")
parser.add_argument("--timeout", type=float, default=1200)
parser.add_argument("command", nargs=argparse.REMAINDER)
args = parser.parse_args()
base = Path(__file__).resolve().parent
if not args.name or "/" in args.name:
    raise ValueError("A simple receipt name is required")
command = args.command
if command[0] == "--":
    command = command[1:]
started = time.monotonic()
with (base / (args.name + ".log")).open("xb") as log:
    process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT,
                               start_new_session=True)
    timed_out = False
    try:
        code = process.wait(timeout=args.timeout)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            code = process.wait(timeout=8)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            code = process.wait(timeout=8)
receipt = {
    "command": command, "cwd": str(Path.cwd()), "pid": process.pid,
    "exit_code": code, "reaped": process.poll() is not None,
    "timed_out": timed_out, "elapsed_seconds": time.monotonic() - started,
}
with (base / (args.name + ".json")).open("x") as output:
    json.dump(receipt, output, indent=2)
    output.write("\n")
print(json.dumps(receipt), flush=True)
raise SystemExit(124 if timed_out else code)
