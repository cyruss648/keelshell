"""Count successful final gate sections and verify every new named regression."""
import json
from pathlib import Path
import re

base = Path(__file__).resolve().parent
receipt = json.loads((base / "full-gate-r2.json").read_text())
assert receipt["exit_code"] == 0 and receipt["reaped"] and not receipt["timed_out"]
text = (base / "full-gate-r2.log").read_text()
workspace = text.split("Running: cargo test --workspace --locked -- --test-threads=4\n", 1)[1]
workspace = workspace.split("Running: cargo test -p keelshell-ai", 1)[0]
totals = {"ordinary": {"passed": 0, "failed": 0, "ignored": 0},
          "rustdoc": {"passed": 0, "failed": 0, "ignored": 0}}
kind = "ordinary"
for line in workspace.splitlines():
    if line.strip().startswith("Doc-tests "):
        kind = "rustdoc"
    elif line.strip().startswith("Running "):
        kind = "ordinary"
    match = re.search(r"^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;", line)
    if match:
        for key, value in zip(["passed", "failed", "ignored"], match.groups()):
            totals[kind][key] += int(value)
assert totals["ordinary"]["passed"] == 3168, totals
assert totals["rustdoc"]["passed"] == 14, totals
assert not totals["ordinary"]["failed"] and not totals["rustdoc"]["failed"]
expected = []
for path, prefix in [
    ("crates/keelshell-app/src/files/editor_keyboard_tests.rs", "files::editor_keyboard_tests::"),
    ("crates/keelshell-app/src/files/editor_format_tests.rs",
     "files::transfer_tests::conflict_merge_tests::editor_format_tests::"),
]:
    source = Path(path).read_text()
    for name in re.findall(r"async fn (editor_keyboard_\w+|editor_format_utf16_(?:le|be)_review_uses_final_characters_not_encoded_bytes)\(", source):
        expected.append(prefix + name)
assert len(expected) == len(set(expected)) == 11
passed = set(re.findall(r"^test (.+?) \.\.\. ok$", workspace, re.M))
assert set(expected).issubset(passed), set(expected) - passed
python_section = text.split("Running: cargo fmt --all --check", 1)[0]
assert "Ran 284 tests" in python_section and "OK (skipped=1)" in python_section
freeze = json.loads((base / "final-inputs-r2.json").read_text())
summary = {
    "gate": receipt, "engineering_inputs": freeze["count"],
    "engineering_sha256": freeze["aggregate_sha256"],
    "rust": totals, "python": {"run": 284, "passed": 283, "skipped": 1, "failed": 0},
    "new_default_rust_tests": sorted(expected),
    "format_strict_clippy_xy_policy_and_three_controllers_passed": True,
}
with (base / "final-gate-summary.json").open("x") as stream:
    json.dump(summary, stream, indent=2)
    stream.write("\n")
print(json.dumps({"rust": totals, "python": summary["python"], "new_named_tests": len(expected),
                  "gate_seconds": receipt["elapsed_seconds"]}))
