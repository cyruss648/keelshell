文件表格纯选择 / 键盘游标模型作者交付（2026-11-16）

已完成指定纯模型切片，父可按以下文件 SHA256 逐字节导入。仅修改允许的源码文件；自有 work 目录保存临时 wrapper、二进制、报告和回执。

- 作者工作目录：`/Users/hdh/.codex/worktrees/file-browser-selection-20261116/keelshell`。
- 父集成目录：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`。
- 来源 HEAD：`e709d02d86ccfbb1a01677f7cda618b64050765b`，无提交或推送。
- 交付源码：`/Users/hdh/.codex/worktrees/file-browser-selection-20261116/keelshell/crates/keelshell-app/src/files/selection.rs`。
- 源码 SHA256：`74187bb0e3417ab9766f82ca824dc8a883fc112b46e677c069a337719daffe4c`。
- 原始源码 SHA256：`98c4e585332b56135f92ab9e2bd68dc1cfb221fa938030129d99994079a5a97c`。
- 原始补丁：`/Users/hdh/.codex/worktrees/file-browser-selection-20261116/keelshell/work/selection-keyboard-20261116/selection.patch`（相对仓库路径，不含临时绝对路径）。
- 逐命令 JSON 回执：`/Users/hdh/.codex/worktrees/file-browser-selection-20261116/keelshell/work/selection-keyboard-20261116/r1/receipt.json`。

新增 `pub(super) CursorMove { Previous, Next, First, Last }`、`cursor() -> Option<&T>`、`move_cursor(&mut self, CursorMove, &[T], bool) -> bool` 与 `select_all(&mut self, &[T]) -> bool`。cursor 和 anchor 都保存原始泛型路径值。导航每次在完整 visible 列表重新定位，不使用 BTreeSet 迭代顺序或旧行号。

成功 click 更新 cursor；非 range 更新 anchor，原 toggle / range 合集行为保持。clear 清除三项状态。retain_visible 只留下可见选择，并分别撤掉不可见的 anchor / cursor。失败的 stale click、超限 click、超限移动和超限全选保持 paths / anchor / cursor 全部原值。

移动无 cursor（含已不可见 cursor）时，Previous / Last 落末行，Next / First 落首行。有 cursor 时按显示顺序移动并在边界夹紧。返回 true 表示落点动作被接受，包括边界夹紧；不表示行号一定发生变化。非 extend 单选落点并重设 anchor。extend 复用已有 click range 语义，保留原 anchor；anchor 缺失或不可见时退化为落点单选，不隐式创建 anchor。空列表移动返回 false，不清历史状态。

select_all 在 visible 长度不超过 32 时完整替换选择，anchor 设为第一项，cursor 优先保留当前可见值，否则取第一项。33 项整次拒绝；空列表成功清空三项状态。

实测工具链为 rustc 1.100.0 / aarch64-apple-darwin、rustfmt 1.11.0-stable。独立 wrapper 通过绝对 #[path] 引用此源码；该绝对路径只存在于自有 work 目录，未写入仓库源码。

编译清单与实际通过名称逐项一致：31 passed / 0 failed / 0 ignored / 0 measured / 0 filtered。含保持原文的旧测试 3 项及本平台新增 28 项。验证期间源码 SHA256 零漂移；所有 9 条验证命令 exit 0 / reaped。未发生失败或重试。

覆盖当前显示顺序、双向移动、首尾边界、单行、Shift 扩展/收缩/方向反转、重排后路径身份、过滤后 anchor/cursor 分别清除、stale cursor、空集、32/33 全选和范围预算及三项状态不变。String 和 PathBuf 覆盖组合/分解 Unicode、emoji、替代字符；本机 Unix 测试用不同非法 UTF-8 字节和合法替代字符路径验证不发生 lossy 合并。Windows 未配对 surrogate 测试已按 cfg(windows) 编写，本机未编译或运行该分支；不把它计入本机 31 项。

Cargo、共享 target、Clippy、完整工程门禁、GPUI 接线、原生键盘投递和 Windows/Linux 平台执行均未运行；这些由父按集成范围验证。本作者未修改其他源码或 docs，未新建 chat/worktree，未提交或推送。

实际命令工作目录均为 `/Users/hdh/.codex/worktrees/file-browser-selection-20261116/keelshell/work/selection-keyboard-20261116/r1`；以下 argv 与 receipt.json 原文一致。

`rustc-version`: `exit 0`, reaped=true, 0.107533s.

```text
rustc --version --verbose
```

`rustfmt-version`: `exit 0`, reaped=true, 0.034603s.

```text
rustfmt --version
```

`format`: `exit 0`, reaped=true, 0.039504s.

```text
rustfmt --edition 2024 /Users/hdh/.codex/worktrees/file-browser-selection-20261116/keelshell/crates/keelshell-app/src/files/selection.rs
```

`format-check`: `exit 0`, reaped=true, 0.029445s.

```text
rustfmt --edition 2024 --check /Users/hdh/.codex/worktrees/file-browser-selection-20261116/keelshell/crates/keelshell-app/src/files/selection.rs
```

`compile`: `exit 0`, reaped=true, 0.386064s.

```text
rustc --edition 2024 --test /Users/hdh/.codex/worktrees/file-browser-selection-20261116/keelshell/work/selection-keyboard-20261116/r1/selection_wrapper.rs --crate-name selection_keyboard_tests -D warnings -o /Users/hdh/.codex/worktrees/file-browser-selection-20261116/keelshell/work/selection-keyboard-20261116/r1/selection-tests
```

`inventory`: `exit 0`, reaped=true, 0.37671s.

```text
/Users/hdh/.codex/worktrees/file-browser-selection-20261116/keelshell/work/selection-keyboard-20261116/r1/selection-tests --list
```

`tests`: `exit 0`, reaped=true, 0.01027s.

```text
/Users/hdh/.codex/worktrees/file-browser-selection-20261116/keelshell/work/selection-keyboard-20261116/r1/selection-tests --test-threads=1
```

`diff-check`: `exit 0`, reaped=true, 0.021255s.

```text
git -C /Users/hdh/.codex/worktrees/file-browser-selection-20261116/keelshell diff --check -- /Users/hdh/.codex/worktrees/file-browser-selection-20261116/keelshell/crates/keelshell-app/src/files/selection.rs
```

`changed-paths`: `exit 0`, reaped=true, 0.019923s.

```text
git -C /Users/hdh/.codex/worktrees/file-browser-selection-20261116/keelshell diff --name-only
```

原始测试清单：`/Users/hdh/.codex/worktrees/file-browser-selection-20261116/keelshell/work/selection-keyboard-20261116/r1/inventory.stdout.log`。

原始测试运行日志：`/Users/hdh/.codex/worktrees/file-browser-selection-20261116/keelshell/work/selection-keyboard-20261116/r1/tests.stdout.log`。

当前 Git 范围读回：

```text
 M crates/keelshell-app/src/files/selection.rs
```
