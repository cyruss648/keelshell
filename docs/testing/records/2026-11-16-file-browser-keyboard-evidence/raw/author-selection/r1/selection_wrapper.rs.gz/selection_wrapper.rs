#[path = "/Users/hdh/.codex/worktrees/file-browser-selection-20261116/keelshell/crates/keelshell-app/src/files/selection.rs"]
mod selection;
