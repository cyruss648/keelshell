#!/usr/bin/env python3
"""Validate only selection.rs using an isolated rustc test wrapper."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time


WORK = Path(__file__).resolve().parent
ROOT = WORK.parent.parent
SOURCE = ROOT / "crates/keelshell-app/src/files/selection.rs"
RUN = WORK / (sys.argv[1] if len(sys.argv) > 1 else "r1")
RUN.mkdir(exist_ok=False)
WRAPPER = RUN / "selection_wrapper.rs"
BINARY = RUN / "selection-tests"
WRAPPER.write_text(f"#[path = {json.dumps(str(SOURCE))}]\nmod selection;\n")
RECEIPT = {
    "started_at_utc": datetime.now(timezone.utc).isoformat(),
    "source": str(SOURCE),
    "source_sha256_before_format": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    "cwd": str(RUN),
    "commands": [],
    "limits": {
        "cargo": "NOT_RUN",
        "shared_target": "NOT_ACCESSED",
        "gpui_and_native": "NOT_RUN",
        "full_gate_and_clippy": "PARENT_OWNED_NOT_RUN",
        "commit_and_push": "NOT_RUN",
    },
}


def persist():
    (RUN / "receipt.json").write_text(json.dumps(RECEIPT, indent=2) + "\n")


def run(label, argv, timeout=45):
    stdout_path = RUN / f"{label}.stdout.log"
    stderr_path = RUN / f"{label}.stderr.log"
    command = {
        "label": label,
        "argv": [str(arg) for arg in argv],
        "cwd": str(RUN),
        "timeout_seconds": timeout,
        "stdout": str(stdout_path),
        "stderr": str(stderr_path),
    }
    RECEIPT["commands"].append(command)
    persist()
    started = time.monotonic()
    environment = dict(os.environ)
    environment["GIT_OPTIONAL_LOCKS"] = "0"
    with stdout_path.open("wb") as stdout, stderr_path.open("wb") as stderr:
        child = subprocess.Popen(
            command["argv"], cwd=RUN, env=environment, stdout=stdout, stderr=stderr
        )
        command["pid"] = child.pid
        command["timed_out"] = False
        try:
            command["exit_code"] = child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            command["timed_out"] = True
            child.kill()
            command["exit_code"] = child.wait(timeout=10)
        command["reaped"] = child.poll() is not None
    command["elapsed_seconds"] = round(time.monotonic() - started, 6)
    persist()
    print(f"{label}: exit={command['exit_code']} reaped={command['reaped']}", flush=True)
    if command["exit_code"] != 0:
        print(stdout_path.read_text(errors="replace"), end="")
        print(stderr_path.read_text(errors="replace"), end="")
        raise SystemExit(command["exit_code"])
    return stdout_path.read_text()


run("rustc-version", ["rustc", "--version", "--verbose"])
run("rustfmt-version", ["rustfmt", "--version"])
run("format", ["rustfmt", "--edition", "2024", SOURCE])
run("format-check", ["rustfmt", "--edition", "2024", "--check", SOURCE])
RECEIPT["source_sha256_at_compile"] = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
run(
    "compile",
    [
        "rustc",
        "--edition",
        "2024",
        "--test",
        WRAPPER,
        "--crate-name",
        "selection_keyboard_tests",
        "-D",
        "warnings",
        "-o",
        BINARY,
    ],
)
listed = run("inventory", [BINARY, "--list"])
executed = run("tests", [BINARY, "--test-threads=1"])
run("diff-check", ["git", "-C", ROOT, "diff", "--check", "--", SOURCE])
changed = run(
    "changed-paths",
    ["git", "-C", ROOT, "diff", "--name-only"],
)
inventory = re.findall(r"^(.+): test$", listed, flags=re.MULTILINE)
passed = re.findall(r"^test (.+) \.\.\. ok$", executed, flags=re.MULTILINE)
summary = re.search(
    r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; "
    r"(\d+) measured; (\d+) filtered out",
    executed,
)
assert summary is not None, "Missing actual libtest summary"
RECEIPT["test_counts"] = dict(
    zip(
        ["passed", "failed", "ignored", "measured", "filtered_out"],
        map(int, summary.groups()),
    )
)
RECEIPT["inventory_count"] = len(inventory)
RECEIPT["inventory"] = inventory
RECEIPT["passed_names"] = passed
assert sorted(inventory) == sorted(passed), "Compiled inventory differs from executed names"
assert RECEIPT["test_counts"]["passed"] == len(inventory)
assert changed.splitlines() == [
    "crates/keelshell-app/src/files/selection.rs"
], f"Unexpected source changes: {changed}"

baseline = (WORK / "selection-baseline.rs").read_text()
current = SOURCE.read_text()
original_names = [
    "ranges_follow_current_order_and_toggle_preserves_other_paths",
    "hidden_and_stale_rows_do_not_restore_selection",
    "over_budget_ranges_preserve_the_original_selection",
]
for name in original_names:
    pattern = rf"    #\[test\]\n    fn {re.escape(name)}\(\) \{{.*?\n    \}}"
    old = re.search(pattern, baseline, flags=re.DOTALL)
    new = re.search(pattern, current, flags=re.DOTALL)
    assert old is not None and new is not None and old.group() == new.group(), name
    assert f"selection::tests::{name}" in inventory, f"Missing original test {name}"
RECEIPT["original_three_tests_byte_identical"] = original_names
RECEIPT["source_sha256_after_validation"] = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
assert (
    RECEIPT["source_sha256_at_compile"] == RECEIPT["source_sha256_after_validation"]
), "Source drifted after compile"
RECEIPT["binary_sha256"] = hashlib.sha256(BINARY.read_bytes()).hexdigest()
RECEIPT["wrapper_sha256"] = hashlib.sha256(WRAPPER.read_bytes()).hexdigest()
RECEIPT["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
RECEIPT["result"] = "PASS"
persist()
print(
    json.dumps(
        {
            "result": RECEIPT["result"],
            "source_sha256": RECEIPT["source_sha256_after_validation"],
            "inventory_count": RECEIPT["inventory_count"],
            "test_counts": RECEIPT["test_counts"],
            "receipt": str(RUN / "receipt.json"),
        },
        indent=2,
    )
)
print(executed)
