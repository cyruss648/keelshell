# 文件列表键盘：实际 macOS 观察边界

最终工程冻结为 engineering-inputs-r2.json，717 项。package-r2 来自该冻结的正常
GUI/MCP 构建，通过 Mach-O/暂存包检查，完整包字节及正常程序在最终门禁后重新核对。
最终完整门禁 full-gate-r2 实际 exit 0 / reaped / 724.430s；详细计数见
final-gate-summary.json。正常程序不是 headless 测试程序。

旧 package-r1 和 native-frost-r1 仅作为历史原件。connect 脚本把 Files Tab 当作
CheckBox，实际 exit 1；后续另编号观察到列表、一次 Down 和状态文本。
不能把这些旧图像代签 Tab 修订。三个根进程的停止回执为 true，端口和私有目录
已回收，43 个内核 birth 身份当前均无活匹配。

## package-r2 / native-frost-r2

仅 Frost Light、中文、实际 macOS arm64、默认窗口和两个隔离 localhost sshd。
用户 SSH、安装、发行、供应商模型或客户数据均未使用。正常 connect-r2 实际
exit 0，独立核对目标主机 pin，再连接 SFTP 起点。截图与 AX 都是实际运行窗口。

| 原件 | 实际结果与限制 |
| --- | --- |
| native-frost-remote-r1 | Home 首次未观察到选区变化，exit 1；原事件仅记录虚拟键。不能断言根因，也不能把后来成功回填到此回合。 |
| 11b-home-diagnostic | 新 helper 在发送前记录 NSEvent 的字符，Home 为 U+F729；实际观察到 alpha-folder 首行。helper 仍通过系统 CGEvent 投递，没有向应用注入测试接口。 |
| native-frost-remote-r2 / r2-10…23 | 实际 Home、Shift+Down、Space、Escape、超限全选/范围、Page Down、End 和 Up；选区断言、末行完全位于列表内框的 AX 几何通过；F2 聚焦已填名称，实际输入 z-renamed.txt。 |
| r2-24-rename-review-action | Enter 实际展开完整重命名审核；脚本在保存附带的选区摘要时错误要求审核中仍存在列表，exit 1。列表此时按设计卸载。完整脚本没有通过，待审核原件由下一回合另行观察。 |
| native-frost-remote-finish-r1 / r3-24…38 | 从已存在审核明确接续：原文件全部 28 字节保持，重复 Enter 不执行，取消不写；重新 F2/输入/Enter，再单独确认，原名称消失、新名称完整 28 字节及 SHA-256 与原种子相同。 |
| r3-41-up | 脚本误以为已重命名后列表自动重载，实际仍为旧名称，exit 1。生产状态明确提示刷新，此处不修改生产语义。 |
| native-frost-delete-r1 / r4-38b…47 | 新回合先完整读回改名结果，实际 F5 加载新名称，再 End/Up、Delete；重复 Delete 和 Enter 不确认。单独确认后两个名称均 absent，exit 0 / reaped / 5.639s。 |
| native-frost-local-r1 / r4-50…59 | 实际本地路径输入、Enter 读取、Home/Enter 打开 alpha-folder、Backspace 返回、End 选中文文件、Enter 填传输路径，再展开设置核对原生路径。种子字节保持，没有启动传输。exit 0 / reaped / 10.953s。 |
| native-frost-tabs-r1 | 正向 Tab 共 97 次到达两列表；反向序列达到原定期限，整体 exit 1。早期 helper 未在异常 finally 中保存反向逐事件原件，不能凭空补算其次数。 |
| native-frost-small-tabs-r1 | 首个本地 Home 未观察到变化，exit 1。保留失败，不推断根因。 |
| native-frost-small-tabs-r2 | 实际打开本地及远程单文件子目录；脚本对远程路径误用 /var，而服务返回 /private/var，精确断言失败。AX 同时有两处 child.txt 和正确 canonical 当前位置；不称整个脚本通过。 |
| native-frost-tabs-r2 / r7-* | 从上述单文件目录另开回合。正向 Tab 19 次到达两列表；反向实际 180 次、未观察到列表，整体 exit 1。最终 AX 焦点位于命令文本区。事件字符为 Shift+Tab 的 U+0019；该证据不证明完整工作区反向遍历通过，也不能仅由此断言根因。 |
| native-frost-reverse-tabs-r1 | 另从传输输入尝试反向入口，点击坐标被自有窗口边界 guard 拒绝，exit 1，未发该点击。原生反向入口继续 HOLD。 |

普通 GPUI Tab/Shift+Tab 新红绿回归与独立复核均通过，但不能代签上述原生 HOLD。
三主题共用语义 token；本批实际原生仅 Frost，Graphite/Lavender 为 NOT_RUN。
Windows/Linux 桌面、IME、VoiceOver、完整尺寸/主题/焦点矩阵与产品总目标继续开放。

## 停止和清理

用户中断后原 PTY 句柄 91151 不再存在，不从这一点推断外层退出码。
native-frost-r2/session-final.json 实际存在：三个根进程停止回执 true、两端口
关闭、私有目录 absent。父再次读取内核进程身份，104 条 birth 身份零活匹配。
两原生回合共 147 条身份、六个根进程、四次端口均核实；没有容器或用户 chat。
最终回执 native-cleanup-final.json 与 interruption-resource-readback-r1.json
分别保留实际清理和外层未知边界。

旧完整门禁 r1 为修正非作者 Tab P2 主动停止，实际 -15 / reaped / 106.653s。
其唯一 birth 匹配临时根仅剩空目录，确认旧进程组无活进程、lsof 无打开文件后回收，
回执见 interrupted-gate-temp-cleanup.json。最终门禁 r2 的成功不覆盖旧中断。
