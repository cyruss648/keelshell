"""Disposable localhost SSH services and an isolated, exact native application."""
import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import pwd
import select
import shlex
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import time
import uuid

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "scripts"))
import openssh_interop as interop
from ssh_path_lab import server_config

parser = argparse.ArgumentParser()
parser.add_argument("--run", default="native")
parser.add_argument("--package", default="package-r1")
parser.add_argument("--theme", default="light", choices=["light", "dark"])
parser.add_argument("--family", default="frost", choices=["frost", "graphite", "lavender"])
args = parser.parse_args()
if any("/" in value or value in ["", ".", ".."] for value in [args.run, args.package]):
    raise ValueError("Use simple batch-local directory names")
OUTPUT = Path(__file__).resolve().parent / args.run
OUTPUT.mkdir(exist_ok=True)
if (OUTPUT / "session-live.json").exists() or (OUTPUT / "session-final.json").exists():
    raise RuntimeError("Use a new native run directory")
identities = {}
processes = []
scratch = Path(tempfile.mkdtemp(prefix="keelshell-native-file-keys-"))
scratch.chmod(0o700)
receipt = {"schema": 1, "scratch": str(scratch), "started": time.time(),
           "boundaries": ["isolated macOS arm64 observation only",
                          "local owned sshd fixtures; no user hosts",
                          "no install, signing or publication"]}


def save(name, data):
    (OUTPUT / name).write_text(json.dumps(data, indent=2) + "\n")


def capture():
    table = interop.process_table(time.monotonic() + 5)
    for process in processes:
        interop.remember_owned(process, identities, table)


def start(command, name, env=None):
    log = (scratch / (name + ".log")).open("wb")
    process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT,
                               env=env, start_new_session=True)
    log.close()
    processes.append(process)
    capture()
    return process


def run(command):
    return subprocess.check_output(command, text=True, stderr=subprocess.STDOUT, timeout=10).strip()


try:
    cg = ctypes.CDLL("/System/Library/Frameworks/CoreGraphics.framework/CoreGraphics")
    ax = ctypes.CDLL("/System/Library/Frameworks/ApplicationServices.framework/ApplicationServices")
    cg.CGPreflightScreenCaptureAccess.restype = ctypes.c_bool
    ax.AXIsProcessTrusted.restype = ctypes.c_bool
    receipt["permissions"] = {
        "screen_capture_allowed": cg.CGPreflightScreenCaptureAccess(),
        "ax_process_trusted": ax.AXIsProcessTrusted(),
    }
    save("permissions.json", receipt["permissions"])
    if not all(receipt["permissions"].values()):
        raise RuntimeError("Native observation permissions unavailable")
    username = pwd.getpwuid(os.getuid()).pw_name
    shell_root = scratch / "sandbox"
    shell_root.mkdir(mode=0o700)
    (shell_root / "welcome.txt").write_text("Owned disposable KeelShell native fixture.\n")
    seeds = {f"row-{index:02}.txt": f"owned row {index}\n".encode() for index in range(34)}
    seeds["z-last.txt"] = "owned original\n完整字节\n".encode()
    seeds["中文.txt"] = "本地来源与远端打开\n".encode()
    folder = shell_root / "alpha-folder"
    folder.mkdir()
    (folder / "child.txt").write_bytes(b"owned child\n")
    for filename, content in seeds.items():
        (shell_root / filename).write_bytes(content)
    receipt["fixture_root"] = str(shell_root)
    receipt["seed_sha256"] = {name: hashlib.sha256(data).hexdigest() for name, data in seeds.items()}
    wrapper = scratch / "owned_shell.py"
    wrapper.write_text("#!" + sys.executable + "\n" + f"""
import os
root = {str(shell_root)!r}
os.chdir(root)
environment = {{"HOME": root, "ZDOTDIR": root,
               "PATH": "/usr/bin:/bin:/usr/sbin:/sbin",
               "LANG": "en_US.UTF-8", "TERM": os.environ.get("TERM", "xterm-256color")}}
command = os.environ.get("SSH_ORIGINAL_COMMAND")
sftp = {"/usr/libexec/sftp-server -d " + shlex.quote(str(shell_root))!r}
if command == sftp:
    os.execve("/usr/libexec/sftp-server", ["sftp-server", "-d", root], environment)
os.execve("/bin/zsh", ["zsh", "-f", "-c", command] if command else ["zsh", "-f"], environment)
""")
    wrapper.chmod(0o700)
    client = scratch / "client"
    run(["ssh-keygen", "-q", "-t", "ed25519", "-N", "", "-f", str(client)])
    ports = {role: interop.reserve_port() for role in ["target", "jump"]}
    pins = {}
    for role in ["target", "jump"]:
        directory = scratch / role
        directory.mkdir(mode=0o700)
        host = directory / "host"
        run(["ssh-keygen", "-q", "-t", "ed25519", "-N", "", "-f", str(host)])
        pins[role] = run(["ssh-keygen", "-lf", str(host) + ".pub", "-E", "sha256"]).split()[1]
        shutil.copyfile(str(client) + ".pub", directory / "authorized_keys")
        (directory / "authorized_keys").chmod(0o600)
        config = server_config(directory, username, ports[role],
                               ports["target"] if role == "jump" else None)
        config += "SetEnv ZDOTDIR=" + str(shell_root) + "\n"
        if role == "target":
            config = config.replace("PermitTTY no\n", "PermitTTY yes\n")
            config += "ForceCommand " + shlex.quote(str(wrapper)) + "\n"
            config += "Subsystem sftp /usr/libexec/sftp-server -d " + shlex.quote(str(shell_root)) + "\n"
        (directory / "sshd_config").write_text(config)
        run(["/usr/sbin/sshd", "-t", "-f", str(directory / "sshd_config")])
        daemon = start(["/usr/sbin/sshd", "-D", "-e", "-f", str(directory / "sshd_config")], role)
        end = time.monotonic() + 5
        while time.monotonic() < end:
            if daemon.poll() is not None:
                raise RuntimeError(role + " sshd exited")
            try:
                with socket.create_connection(("127.0.0.1", ports[role]), timeout=0.2):
                    break
            except OSError:
                time.sleep(0.05)
        else:
            raise RuntimeError(role + " sshd startup deadline")
    ids = {name: str(uuid.uuid4()) for name in ["direct", "jump", "relayed"]}

    def profile(role, name):
        return {"id": ids[role], "name": name, "group": "", "host": "127.0.0.1",
                "port": ports["jump" if role == "jump" else "target"], "username": username,
                "auth": {"type": "private_key", "path": str(client)},
                "tags": ["owned-native-fixture"], "favorite": False}

    profiles = [profile("direct", "原生验证 · 直连"),
                profile("relayed", "原生验证 · 经跳板"),
                profile("jump", "原生验证 · 跳板")]
    profiles[1]["jump_host"] = ids["jump"]
    state = {"schema_version": 1, "connections": profiles, "folders": [], "snippets": [],
             "settings": {"font_size": 14.0, "scrollback_lines": 10000, "language": "zh-CN",
                          "theme": args.theme, "theme_family": args.family,
                          "updates": {"frequency": "disabled", "auto_download": False}},
             "known_hosts": {}}
    data = scratch / "app-state"
    data.mkdir(mode=0o700)
    (data / "state.json").write_text(json.dumps(state))
    (data / "state.json").chmod(0o600)
    binary = Path(__file__).resolve().parent / args.package / "KeelShell.app/Contents/MacOS/keelshell-app"
    environment = dict(os.environ, KEELSHELL_DATA_DIR=str(data), RUST_BACKTRACE="1")
    application = start([str(binary)], "app", environment)
    receipt.update({"pid": application.pid, "binary": str(binary), "ports": ports,
                    "host_fingerprints": pins, "profile_ids": ids, "state_directory": str(data),
                    "binary_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(),
                    "state_fixture": state})
    save("session-live.json", receipt)
    print(json.dumps({"ready": True, "pid": application.pid, "ports": ports,
                      "host_fingerprints": pins}), flush=True)
    deadline = time.monotonic() + 1800
    while time.monotonic() < deadline:
        capture()
        if any(process.poll() is not None for process in processes):
            receipt["ended_early"] = [process.pid for process in processes if process.poll() is not None]
            break
        readable, _, _ = select.select([sys.stdin], [], [], 0.2)
        if readable:
            line = sys.stdin.readline()
            if not line or line.strip() == "stop":
                break
    else:
        receipt["deadline_reached"] = True
finally:
    capture()
    stops = []
    for process in reversed(processes):
        stops.append(interop.stop_owned(process, time.monotonic() + 12, identities))
    receipt["process_cleanup"] = stops
    receipt["identities"] = {str(pid): value for pid, value in identities.items()}
    for role in ["app", "target", "jump"]:
        source = scratch / (role + ".log")
        if source.exists():
            shutil.copyfile(source, OUTPUT / (role + ".log"))
    receipt["ports_closed"] = {}
    for role, port in receipt.get("ports", {}).items():
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.3):
                receipt["ports_closed"][role] = False
        except OSError:
            receipt["ports_closed"][role] = True
    shutil.rmtree(scratch)
    receipt["scratch_absent"] = not scratch.exists()
    receipt["ended"] = time.time()
    save("session-final.json", receipt)
    print(json.dumps({"stopped": True, "ports_closed": receipt["ports_closed"],
                      "scratch_absent": receipt["scratch_absent"]}), flush=True)
