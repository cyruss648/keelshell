"""Real native keyboard/AX scenarios with explicit owned-file readback."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import time

from observe import OUTPUT, SESSION, action, observe as capture

COMMAND = 1 << 20
SHIFT = 1 << 17
ROOT = Path(SESSION["fixture_root"])
assert ROOT.is_relative_to(Path(SESSION["scratch"])) and ROOT.name == "sandbox"
PREFIX = os.environ.get("KEELSHELL_NATIVE_PREFIX", "")
assert "/" not in PREFIX


def observe(name):
    capture(PREFIX + name)


def save(name, value):
    with (OUTPUT / (PREFIX + name + ".json")).open("x") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def one(tree, role, title):
    nodes = [n for n in tree["nodes"] if n.get("AXRole") == role and n.get("AXTitle") == title]
    if len(nodes) != 1:
        raise RuntimeError(f"Expected one {role} {title}, found {len(nodes)}")
    return nodes[0]


def descendants(tree, title):
    node = one(tree, "AXList", title)
    return [n for n in tree["nodes"] if n["path"].startswith(node["path"] + ".")]


def selected(tree, title="远程文件列表"):
    if not any(n.get("AXRole") == "AXList" and n.get("AXTitle") == title for n in tree["nodes"]):
        return None
    return [n["AXTitle"] for n in descendants(tree, title) if n.get("AXSelected")]


def focused(tree, title):
    return one(tree, "AXList", title).get("AXFocused") or any(
        n.get("AXFocused") for n in descendants(tree, title)
    )


def wait_state(name, predicate):
    deadline = time.monotonic() + 8
    while time.monotonic() < deadline:
        tree = action("tree")
        if predicate(tree):
            save(name + "-assertion", {"passed": True, "selected": selected(tree)})
            observe(name)
            return tree
        time.sleep(0.1)
    observe(name + "-failed")
    save(name + "-assertion", {"passed": False, "selected": selected(tree)})
    raise RuntimeError("Native assertion failed: " + name)


def step(name, *operation, predicate=None):
    save(name + "-action", action(*map(str, operation)))
    if predicate:
        return wait_state(name, predicate)
    time.sleep(0.12)
    observe(name)
    return action("tree")


def key(name, code, flags=0, predicate=None):
    return step(name, "key", code, flags, predicate=predicate)


def has_label(tree, text):
    return any(
        text in str(n.get(key, ""))
        for n in tree["nodes"]
        for key in ["AXTitle", "AXValue", "AXDescription"]
    )


def input_value(tree, title, value):
    return any(
        n.get("AXRole") == "AXTextField" and n.get("AXTitle") == title
        and n.get("AXValue") == value
        for n in tree["nodes"]
    )


def click_field(name, title):
    tree = action("tree")
    node = one(tree, "AXTextField", title)
    windows = [w for w in tree["cgWindows"] if w.get("kCGWindowLayer") == 0]
    assert len(windows) == 1
    bounds = windows[0]["kCGWindowBounds"]
    x = node["AXPosition"][0] - bounds["X"] + node["AXSize"][0] / 2
    y = node["AXPosition"][1] - bounds["Y"] + node["AXSize"][1] / 2
    return step(name, "click", x, y)


def bytes_snapshot(name):
    records = {}
    for filename in ["z-last.txt", "z-renamed.txt"]:
        path = ROOT / filename
        data = path.read_bytes() if path.exists() else None
        records[filename] = None if data is None else {
            "length": len(data), "sha256": hashlib.sha256(data).hexdigest(), "hex": data.hex()
        }
    save(name, records)
    return records


def remote():
    original = (ROOT / "z-last.txt").read_bytes()
    step("10-remote-focus", "press", "AXList", "远程文件列表")
    key("11-home", 115, predicate=lambda t: selected(t) == ["alpha-folder"])
    key("12-shift-down", 125, SHIFT, predicate=lambda t: selected(t) == ["alpha-folder", "row-00.txt"])
    key("13-space", 49, predicate=lambda t: selected(t) == ["alpha-folder"])
    key("14-escape", 53, predicate=lambda t: selected(t) == [])
    key("15-home", 115, predicate=lambda t: selected(t) == ["alpha-folder"])
    key("16-all-rejected", 0, COMMAND,
        predicate=lambda t: selected(t) == ["alpha-folder"] and has_label(t, "已保留原选区"))
    key("17-range-rejected", 119, SHIFT, predicate=lambda t: selected(t) == ["alpha-folder"])
    key("18-page-down", 121, predicate=lambda t: selected(t) != ["alpha-folder"])
    tree = key("19-end", 119, predicate=lambda t: selected(t) == ["中文.txt"])
    row = next(n for n in descendants(tree, "远程文件列表") if n.get("AXSelected"))
    listing = one(tree, "AXList", "远程文件列表")
    assert row["AXPosition"][1] >= listing["AXPosition"][1] + 1
    assert row["AXPosition"][1] + row["AXSize"][1] <= listing["AXPosition"][1] + listing["AXSize"][1] - 1
    save("19-end-visible", {"row": row, "list": listing, "fully_visible_inside_frame": True})
    key("20-rename-select", 126, predicate=lambda t: selected(t) == ["z-last.txt"])
    key("21-f2", 120,
        predicate=lambda t: input_value(t, "文件名 / 新建目录", "z-last.txt"))
    key("22-name-all", 0, COMMAND)
    step("23-new-name", "text", "z-renamed.txt")
    key("24-rename-review", 36, predicate=lambda t: has_label(t, "重命名为") and has_label(t, "z-renamed.txt"))
    remote_confirm(original)


def finish():
    original = (ROOT / "z-last.txt").read_bytes()
    wait_state("24-resumed-review", lambda t: has_label(t, "重命名为") and has_label(t, "z-renamed.txt"))
    remote_confirm(original)


def remote_confirm(original):
    before = bytes_snapshot("25-before-confirm")
    assert before["z-last.txt"]["hex"] == original.hex() and before["z-renamed.txt"] is None
    key("26-review-enter", 36, predicate=lambda t: has_label(t, "重命名为"))
    assert bytes_snapshot("27-repeat-readback") == before
    step("28-cancel", "press", "AXButton", "取消", predicate=lambda t: not has_label(t, "重命名为"))
    assert bytes_snapshot("29-cancel-readback") == before
    step("30-remote-refocus", "press", "AXList", "远程文件列表")
    key("31-end", 119, predicate=lambda t: selected(t) == ["中文.txt"])
    key("32-up", 126, predicate=lambda t: selected(t) == ["z-last.txt"])
    key("33-f2-again", 120,
        predicate=lambda t: input_value(t, "文件名 / 新建目录", "z-last.txt"))
    key("34-name-all", 0, COMMAND)
    step("35-rename-name", "text", "z-renamed.txt")
    key("36-review-again", 36, predicate=lambda t: has_label(t, "重命名为") and has_label(t, "z-renamed.txt"))
    step("37-confirm-rename", "press", "AXButton", "确认",
         predicate=lambda t: (ROOT / "z-renamed.txt").exists() and not (ROOT / "z-last.txt").exists())
    renamed = bytes_snapshot("38-renamed-readback")
    assert renamed["z-renamed.txt"]["hex"] == original.hex() and renamed["z-last.txt"] is None
    delete()


def delete():
    renamed = bytes_snapshot("38b-rename-before-delete")
    assert renamed["z-last.txt"] is None
    assert renamed["z-renamed.txt"]["sha256"] == SESSION["seed_sha256"]["z-last.txt"]
    # Mutation acknowledgements preserve the painted listing. Refresh it
    # explicitly before using a newly renamed row; never reinterpret an old row.
    step("39a-remote-list-focus", "press", "AXList", "远程文件列表")
    key("39b-refresh", 96, predicate=lambda t: any(
        n.get("AXTitle") == "z-renamed.txt" for n in descendants(t, "远程文件列表")))
    step("39-refocus", "press", "AXList", "远程文件列表")
    key("40-end", 119, predicate=lambda t: selected(t) == ["中文.txt"])
    key("41-up", 126, predicate=lambda t: selected(t) == ["z-renamed.txt"])
    key("42-delete-review", 117, predicate=lambda t: has_label(t, "永久删除") and has_label(t, "z-renamed.txt"))
    key("43-delete-repeat", 117, predicate=lambda t: has_label(t, "永久删除"))
    key("44-delete-enter", 36, predicate=lambda t: has_label(t, "永久删除"))
    assert bytes_snapshot("45-delete-pending-readback") == renamed
    step("46-delete-confirm", "press", "AXButton", "确认",
         predicate=lambda t: not (ROOT / "z-renamed.txt").exists() and not has_label(t, "永久删除"))
    assert bytes_snapshot("47-deleted-readback") == {"z-last.txt": None, "z-renamed.txt": None}


def local():
    click_field("50-local-path-focus", "本地绝对目录")
    key("51-local-path-all", 0, COMMAND)
    step("52-local-path-text", "text", str(ROOT))
    key("53-local-load", 36, predicate=lambda t: any(n.get("AXTitle") == "alpha-folder" for n in descendants(t, "本地文件列表")))
    step("54-local-list-focus", "press", "AXList", "本地文件列表")
    key("55-local-home", 115, predicate=lambda t: selected(t, "本地文件列表") == ["alpha-folder"])
    key("56-local-open-folder", 36, predicate=lambda t: has_label(t, "child.txt"))
    key("57-local-parent", 51, predicate=lambda t: any(n.get("AXTitle") == "alpha-folder" for n in descendants(t, "本地文件列表")))
    key("58-local-end", 119, predicate=lambda t: selected(t, "本地文件列表") == ["中文.txt"])
    key("59-local-use", 36)
    step("59-transfer-disclosure", "press", "AXCheckBox", "传输设置",
         predicate=lambda t: any(n.get("AXValue") == str(ROOT / "中文.txt") for n in t["nodes"]))
    assert (ROOT / "中文.txt").read_bytes() == "本地来源与远端打开\n".encode()
    save("59-local-use-no-transfer", {"file_unchanged": True, "local_path": str(ROOT / "中文.txt")})


def tabs():
    for name, flags in [("forward", 0), ("reverse", SHIFT)]:
        click_field("60-" + name + "-origin", "本地绝对目录")
        visited = set()
        events = []
        deadline = time.monotonic() + 45
        try:
            for _ in range(180):
                assert time.monotonic() < deadline, "bounded native Tab deadline"
                events.append(action("key", "48", str(flags)))
                time.sleep(0.025)
                tree = action("tree")
                for title in ["本地文件列表", "远程文件列表"]:
                    if focused(tree, title):
                        visited.add(title)
                        if not (OUTPUT / (PREFIX + "61-" + name + "-" + title + "-ax.json")).exists():
                            observe("61-" + name + "-" + title)
                if len(visited) == 2:
                    break
        finally:
            save("62-" + name + "-tab-actions", {"events": events, "visited": sorted(visited)})
        assert len(visited) == 2, (name, visited)


def small_tabs():
    step("63-local-list-focus", "press", "AXList", "本地文件列表")
    key("64-local-home", 115, predicate=lambda t: selected(t, "本地文件列表") == ["alpha-folder"])
    key("65-local-small-folder", 36, predicate=lambda t: any(
        n.get("AXTitle") == "child.txt" for n in descendants(t, "本地文件列表")))
    step("66-remote-list-focus", "press", "AXList", "远程文件列表")
    key("67-remote-home", 115, predicate=lambda t: selected(t) == ["alpha-folder"])
    key("68-remote-small-folder", 36, predicate=lambda t: has_label(
        t, "当前位置： " + str((ROOT / "alpha-folder").resolve())))
    tabs()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("scenario", choices=["remote", "finish", "delete", "local", "tabs", "small_tabs"])
    args = parser.parse_args()
    globals()[args.scenario]()
