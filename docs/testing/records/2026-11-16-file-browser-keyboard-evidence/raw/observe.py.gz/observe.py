"""Bounded native observations; every action identifies this fixture's PID."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import time

BASE = Path(__file__).resolve().parent
OUTPUT = BASE / os.environ.get("KEELSHELL_NATIVE_RUN", "native")
SESSION = json.loads((OUTPUT / "session-live.json").read_text())
PID = str(SESSION["pid"])


def action(*args):
    result = subprocess.run([str(BASE / "native_ax"), PID, *args],
                            capture_output=True, text=True, timeout=10)
    value = json.loads(result.stdout)
    if result.returncode:
        raise RuntimeError(value)
    return value


def observe(name, label=None, screenshot=True):
    deadline = time.monotonic() + 8
    while True:
        value = action("tree")
        labels = [str(node[key]) for node in value["nodes"] for key in ["AXTitle", "AXValue", "AXDescription"] if key in node]
        if not label or any(label in text for text in labels):
            break
        if time.monotonic() >= deadline:
            value["expected_label_missing"] = label
            break
        time.sleep(0.15)
    destination = OUTPUT / (name + "-ax.json")
    with destination.open("x") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    if screenshot:
        windows = [window for window in value["cgWindows"] if window.get("kCGWindowLayer") == 0]
        if len(windows) != 1:
            raise RuntimeError("Expected one isolated visible window")
        image = OUTPUT / (name + ".png")
        if image.exists():
            raise RuntimeError("Observation already exists")
        subprocess.run(["/usr/sbin/screencapture", "-x", "-l", str(windows[0]["kCGWindowNumber"]),
                        str(image)], check=True, timeout=10)
    print(json.dumps({"observation": name, "pid": int(PID), "count": len(value["nodes"]),
                      "expected_label_present": "expected_label_missing" not in value,
                      "titles": [node.get("AXTitle") for node in value["nodes"]
                                 if node.get("AXTitle")][:25]},
                     ensure_ascii=False))
    if "expected_label_missing" in value:
        raise RuntimeError("Expected native label was not observed: " + label)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("name")
    parser.add_argument("--label")
    parser.add_argument("--press", nargs=2)
    parser.add_argument("--key", nargs="+")
    parser.add_argument("--resize", nargs=2)
    parser.add_argument("--scroll", nargs=3)
    parser.add_argument("--no-screen", action="store_true")
    args = parser.parse_args()
    operations = [(operation, getattr(args, operation)) for operation in ["press", "key", "resize", "scroll"]
                  if getattr(args, operation)]
    if operations:
        if len(operations) != 1:
            raise RuntimeError("One action at a time")
        operation, parameters = operations[0]
        receipt = action(operation, *parameters)
        with (OUTPUT / (args.name + "-action.json")).open("x") as stream:
            json.dump(receipt, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
    observe(args.name, args.label, not args.no_screen)
