**文件列表键盘 macOS 原生证据复核 r1 — 非作者，有界收口**

完成时间：2026-11-16T09:46:04+08:00。建议 **APPROVE，仅批准本报告实际核实的证据与有限观察陈述；原生反向 Tab 入口继续 HOLD**。没有发现需要更正本批证据结论的新问题；这不构成完整键盘流程、完整产品或发布验收。

| 严重级别 | 本次证据复核新增开放问题数 |
| --- | ---: |
| P0 | 0 |
| P1 | 0 |
| P2 | 0 |
| P3 | 0 |

上述计数针对证据完整性、相互一致性与陈述边界。下述已知失败、HOLD 和未验证范围不会因零新增问题而关闭。

已读仓库 AGENTS.md、RTK.md、docs/HANDOFF.md 当前顶部及 docs/testing/SHARED_TARGET.md。写入授权仅限本目录的 REPORT-r1.md 与 receipt.json；本次没有执行 Cargo、编译、测试程序、原生重放、桌面操作、网络连接、Git mutation 或父资源清理，没有读取或输出私有目录中的凭据内容。

**源码、包与原生会话的绑定**

起始 HEAD 为 `e709d02d86ccfbb1a01677f7cda618b64050765b`；收口时只读 `git rev-parse HEAD` 为 `6d80c259b9a80facbf0f2fdeea986e18978c714f`。父说明源码候选与正式 docs 已提交为 6d80c25，717 项工程输入与唯一 target 归属未变。本报告不核实该提交的远端 push 结果，也不把旧会话改写成从新提交重建或重放。

本轮实际独立核对过 [engineering-inputs-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/engineering-inputs-r2.json:3) 的完整 717 项路径集合和逐文件 SHA-256，零缺项、零多项、零字节 mismatch，重算集合摘要一致：`d849a4fc427ef1b2abb114fabb88f5fa6c67a167b1e35d0021e7026e737e7166`。该核对在父推进提交之前完成，之后按用户明确说明沿用相同冻结输入，未重新启动审查。

[package-r2/package-manifest.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/package-r2/package-manifest.json:2) 列出的 5 个包文件与当前包的完整文件集合、逐文件摘要均一致。GUI 为 `5ae23593849a5027e71f1a9461dd0fe3129d7adc54b1f22b110694d67464ca9b`；MCP 为 `0e5efdcbe2069fb4ea3c809a99419c557d11ba0ba18e7ba8e5fc6ea0e9bde816`。正常 GUI/MCP 文件也实际只读重算摘要及长度，分别为 199098288 / 14548464 字节，与包及 [normal-artifacts.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/normal-artifacts.json:1) 相符。[normal-build-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/normal-build-r2.json:1) 记录正常构建 exit 0 / reaped；[inspect-package-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/inspect-package-r2.json:1) 与原日志记录 arm64 Mach-O/暂存包检查通过。以上是既有构建证据复核，未独立编译；manifest 的 build.commit 为 null，不能据此代签精确提交发行。

[native-frost-r2/session-live.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-r2/session-live.json:1) 与 [native-frost-r2/session-final.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-r2/session-final.json:1) 的 PID、binary、binary_sha256、scratch、fixture_root、seed 和 ports 相同；GUI PID=77955，SHA 与 package-r2 完全相同。会话为 Frost Light、zh-CN、隔离状态目录及 localhost sshd。旧 r1 GUI SHA 不同，旧图与 connect 失败没有混入 r2 的通过结论。

**真实 AX/PNG 与亲自视检**

本轮程序检查 r2 的 74 份 AX/74 张 PNG、r1 的 8 份 AX/8 张 PNG：AX PID 分别匹配会话、AX trusted 为 true，PNG 头及 3104×2090 尺寸有效，每张 PNG 有对应 AX。该库存检查不等于逐张人工视检。捕获来源为 [observe.py](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/observe.py:24) 的实际 AX tree 与按目标窗口 ID 调用 screencapture；[native_ax-r2.swift](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native_ax-r2.swift:175) 使用有前台 PID guard 的系统 CGEvent 投递，并记录投递前 NSEvent 字符。没有调用应用内部测试动作接口；这些记录也不等于接收侧逐键回执或人工硬件键盘验收。

以下 6 张 PNG 已由本复核者逐张通过 view_image 亲自查看，并与对应 AX/动作/读回记录核对：

| PNG 原件 | 实际所见与限制 |
| --- | --- |
| [r2-12-shift-down.png](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-r2/r2-12-shift-down.png:1) | 列表：alpha-folder 与 row-00.txt 同时选中。 |
| [r3-24-resumed-review.png](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-r2/r3-24-resumed-review.png:1) | 重命名审核：独立确认/取消，长路径右端超出当前正文视口。 |
| [r3-37-confirm-rename.png](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-r2/r3-37-confirm-rename.png:1) | 重命名结果：已重命名，请刷新列表；列表仍显示旧名称。 |
| [r4-42-delete-review.png](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-r2/r4-42-delete-review.png:1) | 删除审核：完整目标与独立确认/取消。 |
| [r4-46-delete-confirm.png](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-r2/r4-46-delete-confirm.png:1) | 删除结果：已删除，请刷新列表；已绘制列表尚未刷新。 |
| [r7-reverse-final.png](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-r2/r7-reverse-final.png:1) | 反向遍历失败末态：命令文本区有焦点，两列表为单文件目录。 |

重命名审核的 AX 提供完整旧路径、新路径和问句，且有可横纵滚动正文组；对应 PNG 的长路径右端超出视口。本报告不声称其完整文本已同屏显示或已原生验证横向滚动。改名/删除结果 PNG 和 AX 均明确提示刷新，不能把仍绘制的旧列表解释为操作未完成，也不能凭截图代替文件字节读回。

**键盘行为与完整字节**

r2-11…23 的动作、断言和 AX 支持 Home、Shift+Down、Space、Escape、超限全选/范围保留原选区、Page Down、End、Up 与 F2 预填后输入新名。末行几何 [r2-19-end-visible.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-r2/r2-19-end-visible.json:1) 的行 y=976、height=28，列表 y=808、height=197，末行底部 1004 位于列表底部 1005 的内框；本轮重核几何，未扩大到全部滚动/尺寸矩阵。

原始测试内容为 `owned original\n完整字节\n` 的 UTF-8，长度 28 字节，完整 hex 为 `6f776e6564206f726967696e616c0ae5ae8ce695b4e5ad97e88a820a`，独立计算 SHA-256 为 `6d9dd19303c3ae02f7f23326ab9d70bb4b2c5f84d299c03f0a370a191a2449a1`，与会话 seed 一致。

| 观察 | 决定性原件与读回结果 |
| --- | --- |
| 重命名展开、重复 Enter | [r3-25-before-confirm.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-r2/r3-25-before-confirm.json:1) 与 [r3-27-repeat-readback.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-r2/r3-27-repeat-readback.json:1)：z-last.txt 的完整 28 字节、hex、SHA 相同，新名称 absent；审核仍在。 |
| 重命名取消 | [r3-28-cancel-action.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-r2/r3-28-cancel-action.json:1) 明确为 AXButton 取消；[r3-29-cancel-readback.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-r2/r3-29-cancel-readback.json:1) 与确认前完整快照相同。 |
| 再次审核后单独确认改名 | [r3-37-confirm-rename-action.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-r2/r3-37-confirm-rename-action.json:1) 明确为 AXButton 确认；[r3-38-renamed-readback.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-r2/r3-38-renamed-readback.json:1)：旧名 absent，新名完整 28 字节、hex、SHA 与 seed 相同。 |
| 删除前与重复键 | [r4-38b-rename-before-delete.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-r2/r4-38b-rename-before-delete.json:1) 重新读回改名结果；F5 明确刷新后选择新名。[r4-43-delete-repeat-action.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-r2/r4-43-delete-repeat-action.json:1) 与 [r4-44-delete-enter-action.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-r2/r4-44-delete-enter-action.json:1) 后，[r4-45-delete-pending-readback.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-r2/r4-45-delete-pending-readback.json:1) 仍与删除前相同。 |
| 单独确认删除 | [r4-46-delete-confirm-action.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-r2/r4-46-delete-confirm-action.json:1) 为 AXButton 确认；[r4-47-deleted-readback.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-r2/r4-47-deleted-readback.json:1) 中新旧两名称均 absent。 |
| 本地浏览及只填传输路径 | r4-50…59 的 AX/动作支持输入路径、Enter、Home/Enter 进子目录、Backspace 返回、End/Enter 选择中文文件；[r4-59-transfer-disclosure-ax.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-r2/r4-59-transfer-disclosure-ax.json:1) 与 [r4-59-local-use-no-transfer.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-r2/r4-59-local-use-no-transfer.json:1) 支持路径填入及种子内容保持，未启动传输。 |

“不写”在本报告中限定为这些时点的文件存在性与完整字节不变，没有系统调用级写审计。**删除取消未取得本批原生读回，保持 NOT_RUN，不能由重命名取消或工程测试代签。**

**Tab 与逐轮失败保持**

[r4-62-forward-tab-actions.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-r2/r4-62-forward-tab-actions.json:1) 有 97 个 key 动作，[r7-62-forward-tab-actions.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-r2/r7-62-forward-tab-actions.json:1) 有 19 个，均 visited 两列表；每个动作包含 down/up。r7 两份 forward AX 各自显示对应 AXList 有焦点。[r7-62-reverse-tab-actions.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-r2/r7-62-reverse-tab-actions.json:1) 则有 180 个 Shift+Tab 动作、flags=131072、投递前字符 U+0019、visited=[]；[r7-reverse-final-ax.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-r2/r7-reverse-final-ax.json:1) 和已视检 PNG 显示焦点在命令文本区。结论为正向两个特定回合观察成功、原生反向入口 HOLD。不能只凭投递前字符推定失败根因，也不能用 headless 红绿测试关闭原生 HOLD。

下列 9 份命令回执均为 exit 1 / reaped，失败原样保留，各回合不能提升为整体成功：

| 失败回合 | 具体证据与影响 |
| --- | --- |
| [native-frost-connect-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-connect-r1.json:1) / [native-frost-connect-r1.log](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-connect-r1.log:1) | Files Tab 被当作 CheckBox，ExpectedOneMatchingElement；旧包仅历史证据。 |
| [native-frost-remote-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-remote-r1.json:1) / [native-frost-remote-r1.log](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-remote-r1.log:1) | Home 未满足选区断言；旧事件没有字符回执，不判根因。 |
| [native-frost-remote-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-remote-r2.json:1) / [native-frost-remote-r2.log](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-remote-r2.log:1) | Enter 已展开审核；选区摘要仍要求 AXList，报 Expected one AXList ... found 0。 |
| [native-frost-remote-finish-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-remote-finish-r1.json:1) / [native-frost-remote-finish-r1.log](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-remote-finish-r1.log:1) | 改名已确认并读回；后续 41-up 错把旧列表当作已刷新列表。 |
| [native-frost-tabs-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-tabs-r1.json:1) / [native-frost-tabs-r1.log](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-tabs-r1.log:1) | 正向 97 个按键动作到达两列表；反向触发内部期限断言，没有保存完整反向事件，次数未知。 |
| [native-frost-small-tabs-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-small-tabs-r1.json:1) / [native-frost-small-tabs-r1.log](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-small-tabs-r1.log:1) | 64-local-home 断言失败，保留失败且不判根因。 |
| [native-frost-small-tabs-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-small-tabs-r2.json:1) / [native-frost-small-tabs-r2.log](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-small-tabs-r2.log:1) | 68-remote-small-folder 精确路径断言失败；/var 与 /private/var 的原始/规范路径不同。 |
| [native-frost-tabs-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-tabs-r2.json:1) / [native-frost-tabs-r2.log](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-tabs-r2.log:1) | r7 正向 19 个动作到达两列表；反向 180 个动作 visited=[]，整体失败。 |
| [native-frost-reverse-tabs-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-reverse-tabs-r1.json:1) / [native-frost-reverse-tabs-r1.log](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-frost-reverse-tabs-r1.log:1) | 起点点击被 ForegroundWindowAndBoundedClickRequired guard 拒绝；该点击未投递，不能算反向入口通过。 |

另有 connect-r2、delete-r1、local-r1 三份命令回执 exit 0 / reaped，分别只证明其自身观察范围。故已核对的 12 份连接/分场景回执为 **3 份 exit 0、9 份 exit 1**；并非 12 次完整流程。remote-r2 在审核处中止，由 r3 明确接续；r3 在陈旧列表处失败，由 r4 明确刷新后另行删除。这些事实与 [native-notes.md](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-notes.md:21) 的分轮陈述一致，未回填成功。

**停止、birth 身份及私有目录/端口**

两份 session-final 各有 3 个根进程停止 true，共 6 个；分别记录两个端口关闭与 scratch absent。[native-cleanup-final.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/native-cleanup-final.json:1) 的 43+104=147 条 birth 身份已由本复核者通过 libproc proc_pidinfo 做当前只读查询：147 个 PID 均 absent，0 个活 birth 匹配、0 个查询错误；不使用 PID 存在性替代 birth 身份。两处私有 scratch 根及各自 state/fixture 子路径当前均 absent；只做存在性读取，没有列举其内容。

本轮被动执行 `/usr/sbin/lsof -nP -a -iTCP:51818,51819,64509,64510 -sTCP:LISTEN -Fp`，exit 1、stdout/stderr 均空，未见四个记录端口的监听；没有发起 socket 连接。结合原闭端口回执支持清理结论，不能外推未被累计身份捕获的进程。

[interruption-resource-readback-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/interruption-resource-readback-r1.json:1) 明确保留外层 PTY 91151 unknown 且 exit_code_inferred=false；r2 的 session-final 另有 ended_early=[77955]。本报告不从句柄消失、进程 absent 或清理 true 推定外层退出码/完整流程成功。旧 [full-gate-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/full-gate-r1.json:1) 实际 -15 / reaped / 106.653s，不会被 r2 的成功覆盖。[interrupted-gate-temp-cleanup.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/interrupted-gate-temp-cleanup.json:1) 的归属与空目录/lsof 证据已读，所记路径本轮仅核对 absent，未执行任何清理。

**工程门禁与复核执行口径**

已只读核对 [final-gate-summary.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/final-gate-summary.json:1) 与 full-gate-r2.json/log：exit 0 / reaped / 724.430s；独立解析既有日志合计普通 Rust 3210 passed / 0 failed / 48 ignored，rustdoc 14/0/0；工程 Python 284 run，其中 283 passed / 1 skipped / 0 failed。摘要列出的 42 个新增默认 Rust 名全部在原日志有通过记录。没有独立重编译或重跑这些测试，门禁不代签任何原生 HOLD。

本复核共执行 **8 次 exec_command 批处理**，内含 37 个顶层命令组（管道计一组），另有 4 个只读子命令（git 3 次、lsof 1 次）；**view_image 6 次**。Cargo/编译/测试执行/原生重放/网络连接/Git mutation/清理均为 0。之前对 362 个选定原件做过只读摘要库存，集合 SHA-256 为 `b18490ad436c3c65d832a900bc834d710301b9055c7eab01e30c135db2b852e8`；该摘要是当时库存锚点，不是收口时全目录重新扫描，也不代表逐件语义审查或逐张视检。按用户要求收口，未再次重算全部未变图片。

本报告未独立核实：Graphite/Lavender、其他语言/全部尺寸与焦点矩阵、Windows/Linux 桌面、IME、VoiceOver、反向原生入口、删除取消、人工硬件输入、完整审核横向滚动、完整产品、签名/安装/发行、远端 push 与后续无损归档/清理。本次没有等待或执行父归档。

实际仅新建本目录 **REPORT-r1.md、receipt.json**。原件保持原样；所有失败、NOT_RUN、HOLD 和外层退出未知继续有效。
