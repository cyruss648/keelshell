**KeelShell 文件列表键盘批次：全新非作者严格只读复核 r1**

结论：**REQUEST_CHANGES**。原冻结 r1 有一项 **P2-001 OPEN**；P0=0、P1=0、P2=1、P3=0。其余指定范围未发现第二项可确认缺陷。该结论只针对 r1，后续修复须另行窄审，不把本报告的开放问题改写为已关闭。

固定父 cwd 为 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`，HEAD=`e709d02d86ccfbb1a01677f7cda618b64050765b`，候选为未提交改动。冻结文件 `work/file-browser-keyboard-20261116/engineering-inputs-r1.json`：717 项，aggregate SHA-256=`11645d113c77a1c3b3ce5cd1337c4fb6f6cb837e4290e6bdbae55c9c7cf29463`。开始复核时已逐项重算字节摘要并核对完整工程路径集合，零增加、零遗漏、零 mismatch。原始证据见 [start-verification.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/review-source/start-verification.json)。

已读父 cwd 的 AGENTS.md、所引用 RTK.md、HANDOFF 顶部、SHARED_TARGET、ADR 0145、FILE_BROWSER_KEYBOARD，并核对两种 README、ROADMAP、HALLMARK_NATIVE、CAPABILITIES、FILES_WORKSPACE 和本批测试记录的新增承诺。Rust 复核使用本机 `/Users/hdh/.agents/skills/rust-best-practices/SKILL.md` 及相关所有权、错误、测试和文档章节；用户禁止构建的约束优先，不执行 skill 建议的 Cargo/Clippy/fmt。

本轮没有编辑工程、Git index/HEAD、共享 target、父资源或其他路径，没有 Cargo、rustc、构建、fmt、clean、commit、push、安装或清理父资源。输出仅在本目录。源码评审边界为下表九个文件的本批差分与判断这些差分必要的上下文；额外只读 GPUI 依赖定义用于核实焦点 API 合同，不把其代码列为本批发现。

| 文件及 r1 行号 | 已检查内容 | r1 SHA-256 |
| --- | --- | --- |
| [crates/keelshell-app/src/files.rs:1072](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files.rs:1072) | 句柄创建、暂停与目录结果落地 | `ce39d684e4d453109a56293d0fb02304f1c2e44a424e9541e35cc5fd84f072fa` |
| [crates/keelshell-app/src/files/browser_keyboard.rs:121](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/browser_keyboard.rs:121) | 精确焦点、绘制身份、按键、审核与滚动 | `dd44ac35a6efe823d089ef39bd29a4efb6c13de2d49539a0aa1dd1f0be87577b` |
| [crates/keelshell-app/src/files/browser_keyboard_tests.rs:99](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/browser_keyboard_tests.rs:99) | 13 项真实 GPUI 分发/受控 SFTP 专项 | `ba8c1e086a2e7362c7a3efe663be3d54719d17faaf673847af51562d3c065b75` |
| [crates/keelshell-app/src/files/selection.rs:74](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/selection.rs:74) | 有界选择、稳定锚点/游标和 31 项本机测试 | `74187bb0e3417ab9766f82ca824dc8a883fc112b46e677c069a337719daffe4c` |
| [crates/keelshell-app/src/files/local_browser.rs:114](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/local_browser.rs:114) | 输入订阅、改选撤销与本地原生路径 | `1613b62dbe3a9637a171cbbdcd5d12163929ed621b5d3e4b0e3dcda7e8061b17` |
| [crates/keelshell-app/src/files/local_view.rs:140](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/local_view.rs:140) | 本地行、滚动及 AX 声明 | `0862126f0e50a0ddf7b142643377adfe06a4a03971abb9342143fe015aa17dfb` |
| [crates/keelshell-app/src/files/view.rs:132](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/view.rs:132) | 远程行、隐藏边界及完整状态 AX 标签 | `c8e83e8e16de369e9b34e0c7d6f4e53782db8a6a33cb0db6ac4aded88cf9ed19` |
| [crates/keelshell-app/src/files/action_view.rs:51](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/action_view.rs:51) | 隐藏工具时撤销重命名意图并移交焦点 | `47df9b5f22886483ce63ab5308b4f25ad7226270dcc72c7d5d8ac2d6bc6c4cdc` |
| [crates/keelshell-app/src/files/editor_keyboard_tests.rs:15](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/editor_keyboard_tests.rs:15) | 复用 harness 的可见性变化，不新增生产行为 | `6f35466d8bac61a6f83e135aca50453ce76ebdc082dfe01aa8209df4fbd63b61` |

**P2-001 OPEN：两个列表不在 Tab 停靠序列，纯键盘入口缺失。**

主位置为 [crates/keelshell-app/src/files.rs:1072](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files.rs:1072)；相关接线为 [crates/keelshell-app/src/files/browser_keyboard.rs:222](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/browser_keyboard.rs:222)。两个 `browser_keyboard_focus` 都由裸 `cx.focus_handle()` 创建。`track_focus` 只跟踪这个句柄，没有将其变为 Tab stop。已只读核实锁定 GPUI 实现：FocusHandle 新建时 `tab_stop=false`；带显式 handle 的 `track_focus` 保留其标志；TabStopMap 的 next/prev 跳过 false。没有找到其他位置为这两个私有 handle 启用停靠。

触发：用户从路径框或其他输入用 Tab/Shift+Tab 浏览文件区，未先点击文件行、复选框或列表空白。影响：无法抵达精确的本地/远程列表焦点，方向、范围、全选以及 F2/Delete 等列表键不会工作；子按钮即使可达，也不会代替列表处理这些键，因为 [crates/keelshell-app/src/files/browser_keyboard.rs:247](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/browser_keyboard.rs:247) 正确要求列表本身精确聚焦。与 [docs/product/FILE_BROWSER_KEYBOARD.md:6](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/product/FILE_BROWSER_KEYBOARD.md:6) 的“也可使用 Tab 到达列表”承诺冲突。

现有 13 项专项通过仍不能排除此缺陷：`install_remote` 在 r1 第 39–44 行、`browse_local` 在第 89–95 行直接 `.focus()` 列表。建议为两个显式句柄启用 `tab_stop(true)`，并从 unrelated input 开始，用真实 Tab/Shift+Tab 找到两列表、再按方向键验证选择，禁止测试先直接聚焦列表。父已通过当前复核会话确认接受本 P2，并报告新红例 `both stops reached=[false,false]`、`exit 101 / reaped / 1 failed / 1330 filtered`；此红例为**父方报告**，不是本 reviewer 独立重编译或执行。

**其他重点范围的结论与证据。**

- 精确焦点与路由：browser_keyboard.rs r1:243–262 只在列表本身聚焦时处理受支持按键；子按钮/输入返回原路由；本地 Rename/Delete 不消费。341 项父回归含既有编辑器/终端测试；本轮 13 项有其他输入、复选框点击聚焦和表格卸载案例。没有新增浏览器全部按键的终端逐字节回环测试，不将静态分发判断写成完整终端原生验收。
- 原子限额与锚点：selection.rs r1:76–105 在提交 paths/anchor/cursor 前检查 32 项限额；139–152 的全选先拒绝 33 项。键盘调用当前可见排序的稳定路径，不用 BTreeSet 字典序当显示顺序。31 项模型测试覆盖扩展、缩短、反向、重排、过滤、首尾、32/33 边界与非 UTF-8 PathBuf；键盘专项实际检查 33 项全选/Shift+End 均保留原选区与游标。
- 重命名与删除：browser_keyboard.rs r1:318–380 的 F2 只填名称并聚焦，Enter 消费一次意图，重查 busy、operation、工具可见、名称焦点、绘制身份和完整单选元数据，再由已加载目录形成精确目的路径。local_browser.rs r1:119–155、500、535 和 action_view.rs r1:63 分别撤销其他相关输入变化、改选、隐藏工具的意图；名称编辑本身保留 F2 意图。专项核对原/新完整路径、确认前原文件及字节仍在、取消不写，以及独立确认后的完整 SFTP 内容/目录读回。重复键和审核 Enter 不调用确认。
- busy / suspend / 旧绘制：browser_keyboard.rs r1:121–198 拒绝 suspended、无 session、审核、队列详情、编辑器/合并覆盖及本地读取/选择器状态，并绑定 session token、实际连接 ID、目录、完整条目元数据、排序和隐藏偏好。r1:273–282 允许 busy 时只改选择，阻止发起新操作。files.rs r1:1275–1295 的 suspend 清除会话、刷新 token、撤销选择和 F2 意图。专项分别执行 busy/review 和七种旧绘制身份/条目/偏好变化；未新增独立 suspend 原生按键场景。
- 本地来源与导航：browser_keyboard.rs r1:293–316 只浏览普通目录或将普通文件原生路径交给现有 use_local_path；链接/特殊对象不作为来源打开，不启动传输。上级/刷新使用已加载目录。非法 UTF-8 值测试为明确注入的 PathBuf，不是在 APFS 成功创建了非法文件名；用例核对不能 lossily 写入传输文本。
- 可见性与主题/AX：移动按可见行位置 `scroll_to_item`，本地/远程成功加载均回到起点；焦点边框置于滚动区外。专项对远程末行与滚动视口做严格像素比较，未放宽 1px 容差；本地首尾及多尺寸真实桌面没有在本轮独立验收。列表/选项声明 ListBox、ListBoxOption、selected 和 active-descendant；底部位置/状态的 aria_label 使用完整文本。三主题通过公共 registry/Palette/token，共六个主题×语言组合的标签与键盘选择测试。该测试实际断言标签/registry，未断言完整 AccessKit 树、VoiceOver 宣读、IME 或系统 AX 事件。

**实际独立执行：三个直接二进制命令，统一 180 秒总预算。**

执行对象为父预构建不可变副本 `work/file-browser-keyboard-20261116/review-app-tests-r1`，SHA-256=`889c51d1a3f7bb9ba0ade1ac8a154af378a82e0be38503f98bfd7f4fd66a1f0d`。执行前后摘要一致。临时数据根 `TMPDIR` 指向本 reviewer 目录的 `test-tmp`。这是**预构建执行，不是独立重编译**，不触碰唯一 Cargo target。

| 直接参数 | 真实结果 | 退出 / reap / 超时 | 实际耗时 |
| --- | --- | --- | --- |
| `--list --format terse` | 1330 个测试名，与 review-binary-r1.json 及父 app-inventory-r1.log 逐名一致 | 0 / true / false | 1.438277s |
| `files::browser_keyboard_tests:: --test-threads=1 --nocapture` | 13 passed / 0 failed / 0 ignored / 1317 filtered | 0 / true / false | 3.478944s |
| `files::selection::tests:: --test-threads=1 --nocapture` | 31 passed / 0 failed / 0 ignored / 1299 filtered | 0 / true / false | 0.014744s |

两组共独立执行 44 个互异用例：键盘 13 个本批新增；选择模型 31 个包括原 3 个和本机新增 28 个。不能把 44 个都称为新增，也不能将作者 rustc wrapper 31 项再次相加。Windows surrogate 条件用例不在此 macOS 库存或执行范围。库存只列出 1330 名，**没有独立执行全部 1330 项**。日志和实际进程退出回执在 [inventory.receipt.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/review-source/inventory.receipt.json)、[browser-keyboard.receipt.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/review-source/browser-keyboard.receipt.json)、[selection.receipt.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/review-source/selection.receipt.json)。父 Cargo 库存带编译/运行前缀，原始日志不逐字节等同直接库存输出；[逐名比对](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/review-source/parent-inventory-comparison.json)相等，不以总数替代逐名检查。

另已只读核对父 `files-regression-r1.json` 和 `.log`：实际 exit 0 / reaped / 159.260027s，341 passed / 0 failed / 0 ignored，含本轮全部 13+31 名，零遗漏。父 `browser-keyboard-r5` 为 13/0/0；作者独立 rustc wrapper 31/31（含新增 28）为父/作者来源，均不标为本轮独立执行。见 [parent-evidence.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/review-source/parent-evidence.json)。

**冻结、修复与签署边界。**

reviewer 开始时 r1 工程完整零漂移，预构建摘要精确匹配。父收到 P2 后开始有授权修复；r1 评审结束复查发现仅 files.rs、browser_keyboard_tests.rs 两项已变化，不能再声称当前工作区仍等于 r1。见 [r1-post-review-verification.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/review-source/r1-post-review-verification.json)。本报告仍只绑定 start-verification 保存的 r1 文件摘要及上述 r1 行号，原 P2 保持 OPEN；修改后的源码、14 项专项、新冻结及新副本尚待另行窄审。

父报告旧 full-gate-r1 已 SIGTERM 后实际 `-15 / reaped / 106.653s`，以及旧原生会话已停止、两端口关闭/私有目录 absent；这些是父方进度，本报告不独立代签。原 r1–r4 失败、旧门禁中断和不完整原生状态保持。reviewer 未运行完整门禁、Clippy、fmt、依赖策略、正常 GUI/MCP 构建、原生桌面操作或 Windows/Linux 检查，未安装/发布/提交。正常程序构建不能由测试副本代签，测试副本也不能签为真实 macOS 桌面体验。

建议父在显式修复 Tab 入口并提供新冻结/新副本后，进行限定窄审，再独立完成当前冻结的完整成功门禁和所需真实桌面观察。**r1 当前不建议合并；不存在 P0/P1，唯一阻挡项为 P2-001。**
