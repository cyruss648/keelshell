**KeelShell 文件列表键盘批次：全新非作者严格只读最终复核 r2**

结论：**限定源码/功能范围 APPROVE；合并建议 CONDITIONAL_APPROVE，等待父方同一冻结的最终成功完整门禁及本批所需新包/原生证据。** 当前开放 P0=0、P1=0、P2=0、P3=0。累计发现一项 P2-001，已通过本次窄修和独立预构建执行关闭；没有第二项可确认缺陷。本 reviewer 没有代签完整门禁、正常 GUI/MCP 构建或真实桌面。

原 [REPORT-r1.md](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/review-source/REPORT-r1.md) 和 [receipt-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/review-source/receipt-r1.json) 保持原字节及 P2 OPEN；本报告另行记录修复关闭，不改写历史。当前 REPORT.md 为本 r2 报告的同字节入口，receipt.json 为最终机器回执。

固定 cwd=`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`，HEAD=`e709d02d86ccfbb1a01677f7cda618b64050765b`，候选仍未提交。工程冻结为 `work/file-browser-keyboard-20261116/engineering-inputs-r2.json`，717 项，aggregate SHA-256=`d849a4fc427ef1b2abb114fabb88f5fa6c67a167b1e35d0021e7026e737e7166`。开始与独立测试结束后均重算逐文件摘要并核对完整路径集合，零增加、零遗漏、零字节漂移，HEAD 未变化。

相对 r1 只变更 files.rs 和 browser_keyboard_tests.rs，其余 **715 项工程输入**完全相同。限定修复只为两个句柄增加 `tab_stop(true)`，并增加一个 Tab/Shift+Tab GPUI 测试。已将这两处修订从内存中的 r2 完整文本反向移除，重建的两个 r1 完整文件 SHA-256 都精确等于起始冻结，确认没有夹带其他修改。证据见 [r1-to-r2-narrow-diff.log](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/review-source/r1-to-r2-narrow-diff.log)、[逐字节反向重建回执](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/review-source/r1-to-r2-narrow-diff-verification.json)、[r2-start-verification.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/review-source/r2-start-verification.json) 和 [r2-post-review-verification.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/review-source/r2-post-review-verification.json)。

评审读取 AGENTS.md、RTK.md、HANDOFF 顶部、SHARED_TARGET、ADR 0145、FILE_BROWSER_KEYBOARD，并核对 README 中英版、ROADMAP、HALLMARK_NATIVE、CAPABILITIES、FILES_WORKSPACE 与本批记录。采用本机 rust-best-practices skill；用户的严格只读与禁止构建约束优先。只审下列九个源文件的本批差分和必要上下文；r2 两路径窄差分重新检查，另外七个受审源文件逐字节沿用 r1 已审内容。

| 文件与 r2 位置 | r2 SHA-256 |
| --- | --- |
| [crates/keelshell-app/src/files.rs:1072](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files.rs:1072) | `6fbd9dda4ef666aaa616403324609d1c6c2a3ef7ba29d1302127b1fa35d94b82` |
| [crates/keelshell-app/src/files/browser_keyboard.rs:201](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/browser_keyboard.rs:201) | `dd44ac35a6efe823d089ef39bd29a4efb6c13de2d49539a0aa1dd1f0be87577b` |
| [crates/keelshell-app/src/files/browser_keyboard_tests.rs:142](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/browser_keyboard_tests.rs:142) | `db8970d02d0f8a9a28be27e00dc2d206edf57b4c0a960f271d6be5c0e43e7825` |
| [crates/keelshell-app/src/files/selection.rs:74](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/selection.rs:74) | `74187bb0e3417ab9766f82ca824dc8a883fc112b46e677c069a337719daffe4c` |
| [crates/keelshell-app/src/files/local_browser.rs:114](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/local_browser.rs:114) | `1613b62dbe3a9637a171cbbdcd5d12163929ed621b5d3e4b0e3dcda7e8061b17` |
| [crates/keelshell-app/src/files/local_view.rs:140](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/local_view.rs:140) | `0862126f0e50a0ddf7b142643377adfe06a4a03971abb9342143fe015aa17dfb` |
| [crates/keelshell-app/src/files/view.rs:132](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/view.rs:132) | `c8e83e8e16de369e9b34e0c7d6f4e53782db8a6a33cb0db6ac4aded88cf9ed19` |
| [crates/keelshell-app/src/files/action_view.rs:51](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/action_view.rs:51) | `47df9b5f22886483ce63ab5308b4f25ad7226270dcc72c7d5d8ac2d6bc6c4cdc` |
| [crates/keelshell-app/src/files/editor_keyboard_tests.rs:15](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/editor_keyboard_tests.rs:15) | `6f35466d8bac61a6f83e135aca50453ce76ebdc082dfe01aa8209df4fbd63b61` |

**P2-001：r1 OPEN → r2 CLOSED。**

原问题：两个列表使用默认 `tab_stop=false` 的显式 FocusHandle，虽然能鼠标/程序聚焦，却无法用 Tab/Shift+Tab 到达；受支持的列表键又正确要求精确列表焦点，因此纯键盘入口失效。原主位置 files.rs r1:1072、接线 browser_keyboard.rs:222；与键盘指南第 6 行的 Tab 承诺冲突。

修复位于 [crates/keelshell-app/src/files.rs:1072](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files.rs:1072)：本地与远程句柄现在都显式 `.tab_stop(true)`，保留两者独立身份，没有扩大键盘事件处理条件。新增回归位于 [crates/keelshell-app/src/files/browser_keyboard_tests.rs:142](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/browser_keyboard_tests.rs:142)：两方向各自从 unrelated input 重新取得起点，用真实 `window.press("tab"/"shift-tab")` 和渲染分发，在最多 128 步内分别断言两个精确列表 FocusHandle 被到达。fixture helper 在准备阶段原本会直接聚焦列表，但**每个被观测的 Tab 序列均先重新聚焦 other，序列内部没有直接 focus 列表**；新断言不由准备阶段焦点满足。

已只读查看父红例原件：`browser-tab-red-r1` 实际 exit 101 / reaped / 17.470417s，0 passed / 1 failed / 0 ignored / 1330 filtered，断言 `[false,false]` 对 `[true,true]`。父绿例 `browser-keyboard-r6` 实际 exit 0 / reaped / 16.767052s，14/0/0，新增用例逐名通过。父红/绿为父执行，不能标为本 reviewer 独立构建。随后本 reviewer 用 r2 精确副本独立执行了新增用例所在的全部 14 项专项并通过，足以关闭此 P2；原件见 [r2-parent-red-green-evidence.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/review-source/r2-parent-red-green-evidence.json)。

**其余源码与功能检查结果。**

| 重点 | 本次判断和对应证据 | 实际限制 |
| --- | --- | --- |
| 列表/子控件/终端路由 | browser_keyboard.rs:243–262 精确判断列表本身焦点；子输入、按钮及本地不支持的 F2/Delete 返回原路由；14 项包含 unrelated input、复选框点击、隐藏表格；新增用例核对两方向 Tab 入口 | 本轮未独立逐键执行终端字节回环；终端/列表是不同分发子树的静态检查，父 341 项为 r1 的另层回归证据 |
| 32 项整次拒绝、稳定锚点 | selection.rs:76–105 在提交 paths/anchor/cursor 前拒绝超限，139–152 全选先拒绝 33 项；路径身份和当前可见排序共同决定扩展/缩短/反向；31 模型与键盘预算用例均独立通过 | 31 项含原 3 项及本机新增 28 项，不全是新增；Windows surrogate 条件用例未在本机运行 |
| F2/name Enter/删除审核 | browser_keyboard.rs:318–380 检查意图、焦点、单选、完整元数据和绘制身份；名称由原加载目录形成精确目标；输入变化/改选/隐藏工具撤销旧意图；专项含精确原/新路径、确认前不写、取消保留、独立确认后 SFTP 完整读回 | 受控测试服务与 GPUI 分发不等于真实桌面；普通名称输入 Enter 不创建操作，重复按键与审核正文 Enter 不确认 |
| busy/suspend/旧绘制 | browser_keyboard.rs:121–198 绑定会话 token、连接 ID、目录、条目所有相关元数据、排序与隐藏偏好，并拒绝覆盖/读取/选择器状态；273–282 busy 只许选择。files.rs suspend 清会话、刷新 token、撤销选择/F2 | 已有专项执行七种旧绘制变化、busy/review、卸载；没有新增独立 suspend 桌面按键场景 |
| 本地路径与导航 | 原生 PathBuf 身份保留；普通目录/文件才可打开/使用；本地 Enter 仅浏览或填路径；上级/刷新基于已加载目录，不使用未提交路径草稿 | 非 UTF-8 UI 反例是明确注入 PathBuf，不是 APFS 成功创建非法名称；没有启动实际文件传输 |
| 首尾可见/主题/AX | 可见行索引交给对应 ScrollHandle；加载结果复位到起点；焦点边框在滚动区外。专项严格核对远程末行与视口几何，三 registry 主题×中英两语言标签/选择通过；角色/选中/active descendant 及完整状态 aria_label 有源码声明 | 本地首尾、多尺寸、系统 AX/VoiceOver/IME 未独立验收；主题测试实际断言标签/registry，未检查整个 AccessKit 树或宣读 |

文档承诺现与源码中的 Tab 入口一致。本批记录仍标 IN_PROGRESS，保留早期失败、旧门禁中断与旧原生自动脚本失败，并明确旧截图不能代签最终修订；没有发现宣称最终完整门禁或新原生回合已通过的承诺。仅测试记录文档较 r1 新增父方进度，不影响 717 项工程冻结。

**独立执行回执：新副本，三个直接命令，180 秒总预算。**

运行对象 `work/file-browser-keyboard-20261116/review-app-tests-r2`，SHA-256=`721fc08a87f4a715d032f616d52c6e830048ea5dc4aab03ecd21c09d8610613b`，执行前后相同。`TMPDIR` 指向本 reviewer 目录的 test-tmp-r2。未调用 Cargo、rustc 或构建，未使用/修改父唯一 target。

| 参数 | 实际结果 | 退出 / reap / 超时 | 耗时 |
| --- | --- | --- | --- |
| `--list --format terse` | 1331 名，逐名等于 review-binary-r2.json；相对 r1 只增加 Tab 回归，无缺名 | 0 / true / false | 1.347127s |
| `files::browser_keyboard_tests:: --test-threads=1 --nocapture` | 14 passed / 0 failed / 0 ignored / 1317 filtered | 0 / true / false | 6.316465s |
| `files::selection::tests:: --test-threads=1 --nocapture` | 31 passed / 0 failed / 0 ignored / 1300 filtered | 0 / true / false | 0.017062s |

r2 共 **45 个互异测试通过**，其中本机新增 42（键盘 14 + 模型新增 28），另 3 为模型原有测试。两个过滤组的每个实际执行名均逐项等于库存对应模块，不只比总数。库存 1331 名不表示独立运行全部 1331 项。r1 的 13+31 与 r2 的 14+31 是不同修订的重复验证，不能加为 89 个互异测试。父 341/0/0 文件模块回归及作者 rustc wrapper 31/31 均保持来源区分，不计入 r2 独立测试数。

直接原件在 [r2-inventory.receipt.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/review-source/r2-inventory.receipt.json)、[r2-browser-keyboard.receipt.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/review-source/r2-browser-keyboard.receipt.json)、[r2-selection.receipt.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/file-browser-keyboard-20261116/review-source/r2-selection.receipt.json)，对应 stdout/stderr 日志在同目录。**预构建执行不是独立重编译**；实际编译来源由父回执负责。本 reviewer 没有运行 fmt、Clippy、全仓测试、依赖策略、正常 GUI/MCP 构建、打包、原生桌面/系统 AX、跨平台测试或安装/发布，也没有任何 Git 变更、提交、推送及父资源清理。

签署时最终 full-gate-r2、新正常包及新原生观察仍由父推进，状态保持 PENDING，不从旧 gate `-15 / reaped / 106.653s` 或旧 package-r1 接续截图推断成功。父须另将最终结果绑定本 r2 冻结；若工程输入再变化，应审查精确差分并重新绑定，不能自动沿用本批准。三平台完整桌面、IME/VoiceOver 和发行不在本次限定批准范围。

本轮源码复核已完成，唯一 P2 在 r2 关闭，r1 记录不变。**建议父收取本报告后关闭 reviewer 会话，继续独立完成门禁与限定原生验收。**
