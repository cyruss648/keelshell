"""Bind the completed gate to full engineering inputs and new named tests."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
receipt = json.loads((BASE / "full-gate-r2.json").read_text())
assert receipt["exit_code"] == 0 and receipt["reaped"] and not receipt["timed_out"]
text = (BASE / "full-gate-r2.log").read_text()
workspace = text.split("Running: cargo test --workspace --locked -- --test-threads=4\n", 1)[1]
workspace = workspace.split("Running: cargo test -p keelshell-ai", 1)[0]
totals = {kind: dict(passed=0, failed=0, ignored=0) for kind in ["ordinary", "rustdoc"]}
kind = "ordinary"
for line in workspace.splitlines():
    if line.strip().startswith("Doc-tests "):
        kind = "rustdoc"
    elif line.strip().startswith("Running "):
        kind = "ordinary"
    match = re.search(r"^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;", line)
    if match:
        for key, value in zip(["passed", "failed", "ignored"], match.groups()):
            totals[kind][key] += int(value)
assert totals["ordinary"] == dict(passed=3210, failed=0, ignored=48), totals
assert totals["rustdoc"] == dict(passed=14, failed=0, ignored=0), totals
inventory = json.loads((BASE / "review-binary-r2.json").read_text())["names"]
passed = set(re.findall(r"^test (.+?) \.\.\. ok$", workspace, re.M))
baseline = subprocess.check_output(
    ["git", "show", "e709d02d86ccfbb1a01677f7cda618b64050765b:crates/keelshell-app/src/files/selection.rs"],
    cwd=ROOT, text=True,
)
old_model = set(re.findall(r"fn (\w+)\(", baseline))
expected = [
    name for name in inventory
    if name.startswith("files::browser_keyboard_tests::")
    or name.startswith("files::selection::tests::") and name.rsplit("::", 1)[1] not in old_model
]
assert len(expected) == len(set(expected)) == 42
assert set(expected).issubset(passed), set(expected) - passed
app_section = workspace.split("unittests src/main.rs", 1)[1].split("test result:", 1)[0]
app_executed = set(re.findall(r"^test (.+?) \.\.\. (?:ok|ignored)", app_section, re.M))
assert app_executed == set(inventory), (len(app_executed), len(inventory))
assert "Ran 284 tests" in text and "OK (skipped=1)" in text
freeze = json.loads((BASE / "engineering-inputs-r2.json").read_text())
names = subprocess.check_output(
    ["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"], cwd=ROOT
).split(b"\0")
current = {
    name.decode() for name in names
    if name and not name.startswith(b"docs/") and (ROOT / name.decode()).is_file()
}
assert current == {row["path"] for row in freeze["inputs"]}
assert len(current) == freeze["count"] == 717
mismatches = [
    row["path"] for row in freeze["inputs"]
    if hashlib.sha256((ROOT / row["path"]).read_bytes()).hexdigest() != row["sha256"]
]
assert not mismatches, mismatches
summary = {
    "gate": receipt, "engineering_inputs": freeze["count"],
    "engineering_sha256": freeze["aggregate_sha256"],
    "complete_engineering_path_set_matches": True, "input_mismatches": mismatches,
    "rust": totals, "app_inventory_count": len(inventory), "app_executed_names_match": True,
    "python": dict(run=284, passed=283, skipped=1, failed=0),
    "new_default_rust_tests": sorted(expected),
    "format_strict_clippy_xy_policy_and_three_controllers_passed": True,
}
with (BASE / "final-gate-summary.json").open("x") as stream:
    json.dump(summary, stream, indent=2)
    stream.write("\n")
print(json.dumps({k: v for k, v in summary.items() if k not in ["new_default_rust_tests", "gate"]}))
