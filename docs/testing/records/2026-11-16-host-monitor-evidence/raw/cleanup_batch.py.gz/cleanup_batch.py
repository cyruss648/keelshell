"""Remove only this batch after its exact source and originals exist in Git."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
EVIDENCE = ROOT / "docs/testing/records/2026-11-16-host-monitor-evidence"


def file_digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--commit", required=True)
    args = parser.parse_args()
    assert len(args.commit) == 40
    assert BASE == ROOT / "work/host-monitor-20261116" and not BASE.is_symlink()
    assert not (EVIDENCE / "cleanup-final.json").exists()
    current_head = subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=ROOT, timeout=15,
    ).decode().strip()
    assert current_head == args.commit
    binding = json.loads((EVIDENCE / "commit-input-binding.json").read_text())
    assert binding["source_commit"] == args.commit and not binding["mismatches"]
    subprocess.run(
        [sys.executable, "-B", str(EVIDENCE / "verify_binding.py"),
         "--commit", args.commit,
         "--output", str(EVIDENCE / "pre-cleanup-commit-binding.json")],
        cwd=ROOT, timeout=60, check=True,
    )
    gate = json.loads((BASE / "full-gate-r3.json").read_text())
    assert gate["exit"] == 0 and gate["reaped"] and not gate["timed_out"]
    resolution = json.loads((BASE / "review-resolution-r3.json").read_text())
    assert resolution["open_findings"] == 0 and resolution["final_full_gate"] == "PASSED"
    archive = json.loads((EVIDENCE / "archive-manifest.json").read_text())
    omitted = json.loads((EVIDENCE / "omitted-artifacts.json").read_text())
    expected = {
        path: (row["source_sha256"], row["source_bytes"])
        for path, row in archive["files"].items()
    }
    assert len(expected) == archive["count"]
    for row in omitted["files"]:
        assert row["path"] not in expected
        expected[row["path"]] = row["sha256"], row["bytes"]
    entries = list(BASE.rglob("*"))
    assert all(not path.is_symlink() for path in entries)
    actual = {path.relative_to(BASE).as_posix(): path
              for path in entries if path.is_file()}
    assert set(actual) == set(expected), "Batch changed after evidence sealing"
    for name, path in actual.items():
        checksum, size = expected[name]
        assert path.stat().st_size == size and file_digest(path) == checksum, name
    binaries = json.loads((BASE / "normal-binaries-r1.json").read_text())
    for row in binaries:
        path = Path(row["path"])
        assert not path.is_relative_to(BASE)
        assert path.stat().st_size == row["bytes"] and file_digest(path) == row["sha256"]
    target = ROOT / "work/recovery-batch-integration-20261115/target"
    assert target.is_dir() and not target.is_relative_to(BASE)
    resources = json.loads((BASE / "cleanup-resource-readback-r4.json").read_text())
    assert resources["all_owned_ids_and_names_absent"]
    assert not resources["creation_reconciliation_from_absence"]
    assert not resources["matching_author_branches"]
    registered = subprocess.check_output(
        ["git", "worktree", "list", "--porcelain"], cwd=ROOT, timeout=15,
    ).decode()
    for row in resources["author_worktrees"]:
        assert not Path(row["path"]).exists()
        assert "worktree " + row["path"] + "\n" not in registered
    file_count = len(actual)
    byte_count = sum(row[1] for row in expected.values())
    shutil.rmtree(BASE)
    assert not BASE.exists()
    for row in binaries:
        assert Path(row["path"]).is_file()
    assert target.is_dir()
    record = {
        "schema": 1,
        "recorded_utc": datetime.now(timezone.utc).isoformat(),
        "source_commit": args.commit,
        "removed_directory": str(BASE),
        "directory_absent": True,
        "files_removed": file_count,
        "logical_bytes_removed": byte_count,
        "raw_originals_committed": archive["count"],
        "omitted_rebuildable_files": omitted["count"],
        "all_batch_files_matched_sealed_hashes_before_removal": True,
        "normal_binaries": binaries,
        "normal_binaries_preserved": True,
        "only_valid_target_preserved": True,
        "owned_resource_readback": "raw/cleanup-resource-readback-r4.json.gz",
        "author_worktrees_absent": True,
        "source_authors_and_reviewers_closed": 7,
        "no_user_chat_created": True,
        "no_other_task_resource_touched": True,
        "original_failure_and_unknown_evidence_preserved_in_git": True,
    }
    with (EVIDENCE / "cleanup-final.json").open("x") as stream:
        json.dump(record, stream, indent=2)
        stream.write("\n")
    print(json.dumps({key: value for key, value in record.items()
                      if key != "normal_binaries"}))


if __name__ == "__main__":
    main()
