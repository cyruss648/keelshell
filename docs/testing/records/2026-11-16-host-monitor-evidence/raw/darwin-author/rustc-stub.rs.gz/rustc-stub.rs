#![allow(dead_code)]
#![forbid(unsafe_code)]
mod monitor {
    #[derive(Debug,Clone,Copy,PartialEq,Eq)]
    pub enum MonitorPlatform { Linux, Darwin }
    #[derive(Debug)]
    pub enum MonitorError { InvalidData(&'static str) }
    pub type MonitorResult<T> = Result<T, MonitorError>;
    #[derive(Debug,Clone,Copy,PartialEq,Eq)]
    pub enum CapabilityReason { CommandMissing, PermissionDenied, CommandFailed, InvalidOutput }
    #[derive(Debug,Clone,Copy,PartialEq,Eq)]
    pub enum CapabilityState { Unknown, Available, Unavailable(CapabilityReason) }
    #[derive(Debug,Clone,PartialEq,Eq)]
    pub struct CpuCounters { pub ticks: [u64;8] }
    #[derive(Debug,Clone,PartialEq,Eq)]
    pub struct MemorySnapshot { pub total_bytes:u64, pub available_bytes:Option<u64>, pub free_bytes:Option<u64>, pub swap_total_bytes:Option<u64>, pub swap_free_bytes:Option<u64> }
    #[derive(Debug,Clone,PartialEq,Eq)]
    pub struct NetworkCounters { pub name:String, pub received_bytes:u64, pub transmitted_bytes:u64 }
    #[derive(Debug,Clone,PartialEq,Eq)]
    pub struct FilesystemSnapshot { pub source:String, pub mount:String, pub total_bytes:u64, pub used_bytes:u64, pub available_bytes:u64, pub used_percent:u32 }
    #[derive(Debug,Clone,PartialEq,Eq)]
    pub enum DiskIoError { MissingData }
    #[derive(Debug,Clone,PartialEq,Eq)]
    pub struct DiskIoSnapshot;
    #[derive(Debug,Clone,PartialEq)]
    pub struct Snapshot { pub platform:MonitorPlatform, pub boot_time:u64, pub uptime_seconds:f64, pub load_average:[f64;3], pub cpu:CpuCounters, pub memory:MemorySnapshot, pub networks:Vec<NetworkCounters>, pub filesystems:Vec<FilesystemSnapshot>, pub disk_io:Result<DiskIoSnapshot,DiskIoError> }
fn columns(mut line: &str, count: usize) -> MonitorResult<(Vec<&str>, &str)> {
    let mut fields = Vec::with_capacity(count);
    for _ in 0..count {
        line = line.trim_start();
        let end = line
            .find(char::is_whitespace)
            .ok_or(MonitorError::InvalidData("incomplete row"))?;
        fields.push(&line[..end]);
        line = &line[end..];
    }
    let remainder = line.trim_start();
    if remainder.is_empty() {
        return Err(MonitorError::InvalidData("empty final column"));
    }
    Ok((fields, remainder))
}
impl MemorySnapshot {
    /// Used memory calculated as total minus the kernel's available estimate.
    pub fn used_bytes(&self) -> Option<u64> {
        self.total_bytes.checked_sub(self.available_bytes?)
    }
}
#[path = "/Users/hdh/.codex/worktrees/darwin-monitor-20261116/keelshell/crates/keelshell-session/src/monitor/darwin.rs"]
mod darwin;
}
