"""Resume a proven successful owned build after receipt bookkeeping failed."""
from contextlib import ExitStack
import json
import os
from pathlib import Path
import re
import sys
import time

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
import monitor_recovery_lab as lab

old_path = BASE / 'ss-tools-r1/result.json'
old = json.loads(old_path.read_text())
assert old['failure'] == {'type': 'KeyError', 'message': "'steps'"}
actual = next(row for row in old['cleanup']['processes'] if row['name'] == '001-prepare-tools')
assert actual['reaped'] and actual['observed_stopped'] and actual['returncode'] == 0
# The original UNKNOWN receipt stays immutable. This is direct completed-child
# evidence, not a completion inference from a later absent-resource read.
identifier = (BASE / 'ss-tools-r1/001-prepare-tools.log').read_text().splitlines()[-1]
assert re.fullmatch('[0-9a-f]{64}', identifier)
out = BASE / 'ss-tools-recovery-r2'
out.mkdir(mode=0o700)
receipt = {'schema': 1, 'owner': old['owner'], 'commands': [], 'processes': [],
           'resources': [], 'steps': [], 'cleanup': {}, 'scope': old['scope'],
           'prior_record_unchanged': str(old_path.relative_to(ROOT)),
           'completed_build_resolution': {'basis': 'actual original child reaped with exit zero',
                'process': actual, 'full_image_id': identifier,
                'original_failure': old['failure'], 'original_mutation_status': 'UNKNOWN'}}
deadline = time.monotonic() + 580
code = 1
with ExitStack() as stack:
    runner = lab.ClientRunner(out, deadline - 70, stack, receipt, lambda: None)
    api = lab.PodmanLab(runner, receipt['owner'], receipt, lab.interop.executable('podman'))
    try:
        image = api.register('image', old['resources'][0]['name'])
        image['id'] = identifier
        image['mutations'].append({'command': 'prior-build-direct-completion-evidence',
                                   'status': 'COMPLETED', 'returncode': 0,
                                   'basis': 'completed_build_resolution'})
        assert api.bind(image) == identifier
        binaries = json.loads((BASE / 'session-binaries-r4.json').read_text())
        binary = next(row for row in binaries if row['name'] == 'monitor_interop')
        args = [sys.executable, '-B', str(ROOT / 'scripts/monitor_recovery_lab.py'),
                '--opt-in', 'localhost-owned-fixture', '--output', str(BASE / 'linux-recovery-r3'),
                '--source-sha', '539c172389b4450570026f023ff89d50df90f910',
                '--test-binary', binary['stable'], '--test-binary-sha256', binary['sha256'],
                '--base-image', identifier, '--timeout', '480']
        code, _ = api.command('real-linux-lab', args, seconds=500, allowed=(0, 1), binary=True,
                              environment=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'))
        receipt['lab_exit'] = code
    except BaseException as error:
        receipt['failure'] = lab.failure(error)
    finally:
        receipt['cleanup']['resources'] = api.cleanup()
        stopped, confirmed = lab.stop_clients(runner, deadline)
        receipt['cleanup'].update(processes=stopped, processes_confirmed=confirmed)
        receipt['cleanup']['confirmed'] = confirmed and all(row.get('absent') for row in receipt['cleanup']['resources'])
        receipt['result'] = 'PASSED' if code == 0 and receipt['cleanup']['confirmed'] else 'FAILED'
        (out / 'result.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k:receipt.get(k) for k in ['result','failure','lab_exit']}))
raise SystemExit(0 if receipt['result'] == 'PASSED' else 1)
