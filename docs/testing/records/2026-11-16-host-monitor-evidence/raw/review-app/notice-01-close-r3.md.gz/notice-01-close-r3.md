# APP-P2-01 — CLOSED

源码修复和独立预构建复跑均已完成。原发现与父红证据不改写。

- 修复：新测试断言暂停后的第一个样本 CPU 为 None，再刷新一次验证 50%；生产暂停与历史合同不变。
- 源码：`crates/keelshell-app/src/monitor_tests/darwin.rs` SHA-256 为 `5d931b7053a0e4a65b9ff445b1d4a9392594d4545311359a794f7d7e0bf0f772`。
- app 稳定预构建：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/host-monitor-20261116/bins/app-r2`，SHA-256 为 `282cae510800e260a68af1abf612307dabe2008f3c223f45c9f00e0650d6074c`，核对前后不变。
- 实际独立命令：上述 binary 加 `monitor::tests::darwin:: --test-threads=1 --nocapture`。
- 实际结果：exit 0，4 passed / 0 failed / 0 ignored，0.278422 秒；四个具体名称包括原失败用例。
- 原件：`app-01-darwin-r2.stdout`、`app-01-darwin-r2.stderr`、`app-risk-tests-r2.json`。
- 全部 app 复核专项：12 条命令、21 passed / 0 failed / 0 ignored；11 个范围文件执行前后无漂移。

本结论来自父预构建副本的独立运行，没有独立重新编译、Cargo 或 target 访问，不代替最终完整门禁或原生桌面验收。
