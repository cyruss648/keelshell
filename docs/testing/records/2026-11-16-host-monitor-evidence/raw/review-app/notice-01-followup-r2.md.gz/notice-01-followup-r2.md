# APP-P2-01 — 修复来源与父红证据

状态：SOURCE_FIX_VERIFIED / PREBUILT_RETEST_PENDING。

已核对当前源码相对 `source-snapshot-r3` 的全部 11 个范围文件：仅
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_tests/darwin.rs`
发生变化，SHA-256 为
`5d931b7053a0e4a65b9ff445b1d4a9392594d4545311359a794f7d7e0bf0f772`。

该窄差分增加第 40 行开始的暂停后首样 CPU 未知断言，然后在第 46 行执行第二次手动刷新，继续在第 53 行验证 50%。生产暂停、历史连续性和速率代码摘要不变，原 MCP、内存趋势及 iowait 未知值断言保留。源码修复符合 notice 要求。

父已实际复现原失败：`app-monitor-r1` 的 `exit 101 / 69 passed / 1 failed / 0 ignored`，失败位置为旧测试第 45 行，`None` 对 `Some(50.0)`。此为父执行，不能计入 reviewer 独立运行数。

父原始日志与命令回执已逐字节复制为 `parent-app-monitor-r1.log` 和
`parent-app-monitor-r1.json`；摘要见 `notice-01-parent-red-binding.json`。
原 notice 与静态发现证据保持不变。

待父提供包含修复的新 app 稳定预构建副本、摘要、用例清单及最终来源绑定后，独立执行该用例和相关专项，再关闭运行验证条件。当前没有执行 Rust 重新编译或完整门禁。
