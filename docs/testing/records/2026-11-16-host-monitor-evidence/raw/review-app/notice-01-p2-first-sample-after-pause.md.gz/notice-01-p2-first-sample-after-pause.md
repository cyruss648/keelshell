# APP-P2-01 — 新增 Darwin 测试跨越暂停边界期待 CPU 速率

状态：OPEN / REQUEST_CHANGES。发现时间见同目录 `notice-01-trace.json`。
这是源码审核发现，尚未执行 Rust 测试，不声称已有运行失败。

位置：

- `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_tests/darwin.rs:35`：暂停后只刷新一次。
- `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_tests/darwin.rs:45`：断言该次采样 CPU 为 `Some(50.)`。
- `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor.rs:238`：暂停调用 `history.interrupt()`。
- `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_history.rs:66`：`interrupt()` 将 `continuous` 置为 false。
- `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_history.rs:126`：没有连续区间时 CPU 返回 `None`。
- `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor.rs:350`：UI 使用上述 CPU 结果覆盖原始速率。

触发与复现：

1. 运行新增 `monitor::tests::darwin::darwin_ssh_samples_keep_used_memory_mcp_and_trends_unknown`。
2. 构造器的首次资源采样完成后，测试调用 `set_paused(true)`，中断历史连续性。
3. 测试只执行一次手动刷新。它是暂停边界后的首个样本，所以 CPU 应保持未知。
4. 第 45 行的 `Some(50.)` 与实际代码确定的 `None` 冲突。

影响：在成功解析 Darwin fixture 的情况下，这个新增默认测试仍会失败，阻塞 app 专项与最终完整门禁；不能通过削弱暂停断段契约来使其变绿。

建议：保留暂停后首个样本 CPU 未知的断言，再增加一次有效手动刷新验证 50%；内存/MCP 未知值断言继续保留。

证据与边界：`notice-01-source-excerpts.txt` 保存当时带行号的五处源码，`notice-01-trace.json` 保存三文件 SHA-256 和静态状态推导。没有运行 Cargo、Rust binary、格式化程序或访问 target，没有修改生产源码。
