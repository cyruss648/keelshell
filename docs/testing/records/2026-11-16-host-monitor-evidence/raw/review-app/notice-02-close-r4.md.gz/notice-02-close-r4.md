# APP-P2-02 — 修复与独立预构建执行闭合

状态：**CLOSED**。原 notice、官方归档、受控红证据和 report-r2 保留。

当前修复源码：
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor.rs`
SHA-256：
`7adb9395ff8db239e59fb0edf1a589a8d6d842d5c302556e5f6c0773ff9868b7`。

已核对以下窄差分：

- 第 60–65 行 selector 只遍历 `/usr/bin/uname` 与 `/bin/uname`，
  同时检查 `-f` 与 `-x`；两个候选都缺失时 exit 66。
- 第 66–80 行进程分派包含同一 selector 文本；
  第 539 行资源分派直接嵌入 `PLATFORM_SELECTOR`。
  平台识别没有回退到任意 PATH。
- 现有 `command_text` 对 66 的映射为 `CapabilityUnavailable(CommandMissing)`，
  不再把候选缺失当成 UnsupportedPlatform。
- 第 1172 行新增回归实际执行 `/bin/sh`，把两个固定路径替换为私有 fixture，
  覆盖 `/usr/bin` 缺失、`/bin` 可执行返回 Linux，以及两者都缺失返回 66。
  进程脚本还断言包含相同 selector。子 shell 清空环境，仅用私有 PATH，
  有两秒截止、超时 kill/wait 和 stdout 断言。
- 其余 10 项范围文件摘要不变，未扩大 Darwin 采集实现范围。

本 reviewer 实际执行的稳定副本：
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/host-monitor-20261116/bins/keelshell_session-r4`。

SHA-256：
`d45b07a984babf9b767956c494e11fb2566168186655fa18fe6a1b70612751a3`。
执行前确认普通文件、非符号链接、link count 1、字节数及父 metadata 摘要一致；
直接 `--exact ... --list` 确认一个具体测试名存在。

精确执行参数：

```text
--exact monitor::tests::platform_selector_supports_bin_only_uname_and_reports_both_paths_missing --nocapture --test-threads=1
```

实际结果：**exit 0；1 passed / 0 failed / 0 ignored**。
执行前后 11 项源码及 binary 摘要一致；TMPDIR/TMP/TEMP 都指向 review-app，
测试结束后私有目录内无遗留条目。
原件为 `selector-independent-r4.json`、`selector-risk-r4.json/.stdout/.stderr`
和 `selector-list-r4.json/.stdout/.stderr`。

父修后实际 Mac localhost SSH r3 六项通过、session monitor r4 的 81 项通过
已另行读回，见 `parent-receipts-readback-r3.json`；不并入独立计数。
该项关闭依据是源码修复及独立 selector 回归，未宣称真实 Linux SSH 或桌面验收。
使用的是父预构建副本，没有独立重编译、Cargo 或 target 访问。
