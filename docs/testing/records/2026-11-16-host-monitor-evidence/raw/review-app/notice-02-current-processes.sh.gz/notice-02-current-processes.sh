LC_ALL=C; export LC_ALL
case "$(/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/host-monitor-20261116/review-app/notice-02-path-model/usr/bin/uname -s)" in
  Linux) ;;
  Darwin)
    [ -x /bin/ps ] || exit 66
    /bin/ps -ww -axo pid=,user=,pcpu=,pmem=,args= || exit 65
    exit 0
    ;;
  *) exit 64 ;;
esac
printf 'selected Linux process branch\n'
