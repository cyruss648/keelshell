case "$(/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/host-monitor-20261116/review-app/notice-02-path-model/usr/bin/uname -s)" in
Darwin)
printf 'selected Darwin branch\n'
;;
Linux)
printf 'selected Linux resource branch\n'
;;
*) exit 64 ;;
esac
