"""Run only the reviewed shell dispatch prefixes in an isolated path model.

This does not run a collector, SSH server, Cargo, a Linux binary, or production
code. Absolute uname paths are mapped below this evidence directory so a
missing /usr/bin/uname can be modeled without changing the host filesystem.
"""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess


ROOT = Path("/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell")
OUT = Path(__file__).resolve().parent
SOURCE = ROOT / "crates/keelshell-session/src/monitor.rs"
OLD = OUT / "source-snapshot-final/crates/keelshell-session/src/monitor.rs"
MODEL = OUT / "notice-02-path-model"


def dispatches(text):
    match = re.search(r'const PROCESSES_SCRIPT: &str = r#"(.*?)"#;', text, re.S)
    assert match, "process script not found"
    script = match.group(1)
    process = script[: script.index("\nesac") + len("\nesac")]
    process += "\nprintf 'selected Linux process branch\\n'\n"

    # Decode only the shell format literal, without executing either collector.
    match = re.search(r'let script = format!\(\s*("(?:\\.|[^"\\])*")', text)
    assert match, "snapshot dispatcher format not found"
    snapshot = json.loads(match.group(1))
    snapshot = snapshot.replace("{}", "printf 'selected Darwin branch\\n'")
    snapshot = snapshot.replace(
        "{linux_script}", "printf 'selected Linux resource branch\\n'"
    )
    assert "case " in snapshot and "*) exit 64" in snapshot
    return {"processes": process, "resources": snapshot}


def main():
    assert Path.cwd() == ROOT
    assert OUT == ROOT / "work/host-monitor-20261116/review-app"
    (MODEL / "bin").mkdir(parents=True, exist_ok=True)
    (MODEL / "usr/bin").mkdir(parents=True, exist_ok=True)
    uname = MODEL / "bin/uname"
    uname.write_text("#!/bin/sh\nprintf 'Linux\\n'\n")
    uname.chmod(0o700)
    assert not (MODEL / "usr/bin/uname").exists()
    env = dict(os.environ)
    env["PATH"] = str(MODEL / "bin")
    rows = []
    for version, path in [("previous_reviewed", OLD), ("current", SOURCE)]:
        data = path.read_bytes()
        for facility, script in dispatches(data.decode()).items():
            # This is the only path translation; dispatch control flow remains
            # the exact source prefix. PATH lookup already uses the model root.
            translated = script.replace(
                "/usr/bin/uname", shlex.quote(str(MODEL / "usr/bin/uname"))
            )
            translated = translated.replace(
                "$(/bin/uname -s)",
                "$(" + shlex.quote(str(MODEL / "bin/uname")) + " -s)",
            )
            label = f"{version}-{facility}"
            (OUT / f"notice-02-{label}.sh").write_text(translated)
            result = subprocess.run(
                ["/bin/sh", "-c", translated],
                cwd=ROOT,
                env=env,
                text=True,
                capture_output=True,
                timeout=5,
            )
            (OUT / f"notice-02-{label}.stdout").write_text(result.stdout)
            (OUT / f"notice-02-{label}.stderr").write_text(result.stderr)
            expected = 0 if version == "previous_reviewed" else 64
            rows.append(
                {
                    "version": version,
                    "facility": facility,
                    "source_sha256": hashlib.sha256(data).hexdigest(),
                    "command": ["/bin/sh", "-c", translated],
                    "cwd": str(ROOT),
                    "exit_code": result.returncode,
                    "expected_for_reproduction": expected,
                    "matches_expected": result.returncode == expected,
                    "stdout": result.stdout,
                    "stderr": result.stderr,
                }
            )
    receipt = {
        "captured_at": datetime.now(timezone.utc).isoformat(),
        "operation": "Controlled shell dispatch reproduction",
        "layout": "Only bin/uname exists; usr/bin/uname absent; bin and usr/bin separate",
        "boundary": (
            "Path mapping model on macOS /bin/sh; no Linux runtime, collector, "
            "SSH, Rust API invocation, Cargo, or target access"
        ),
        "commands": rows,
        "verified": all(row["matches_expected"] for row in rows),
    }
    (OUT / "notice-02-dispatch-repro-r1.json").write_text(
        json.dumps(receipt, ensure_ascii=False, indent=2) + "\n"
    )
    print(
        json.dumps(
            {
                "verified": receipt["verified"],
                "commands": [
                    {key: row[key] for key in ("version", "facility", "exit_code")}
                    for row in rows
                ],
                "boundary": receipt["boundary"],
            },
            indent=2,
        )
    )
    return 0 if receipt["verified"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
