# APP-P2-02 — 官方布局核验与受控 shell 复现

状态：**OPEN / REQUEST_CHANGES**。本补充保留原 notice，不以 Mac SSH 成功关闭 Linux 分派回归。

当前位置：

- `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor.rs:61`
- `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor.rs:528`

当前文件 SHA-256：
`f280c96f6d31ae3b4770f888ca077c02f32f05e908e018e7a6e83e74fca86ab8`。

## 实际核验的官方文件布局

从 Alpine 官方发布站读取固定的 `alpine-minirootfs-3.22.0-x86_64.tar.gz`
和其 `.sha256`，两项 HTTP 均为 200。归档为 3,655,173 字节，
实际 SHA-256 与官方 checksum 一致：
`18879884e35b0718f017a50ff85b5e6568279e97233fc42822229585feb2fa4d`。

只读取归档成员表，没有解压或执行归档。归档实际包含：

| 成员 | 类型 |
| --- | --- |
| `bin` | 独立目录 |
| `bin/uname` | 指向 `/bin/busybox` 的符号链接 |
| `bin/busybox` | 普通文件 |
| `usr/bin` | 独立目录 |
| `usr/bin/uname` | 不存在 |

来源、完整归档和 checksum 均保存在本证据目录；
机器可读结果为 `notice-02-official-layout-r1.json`。
这项实际核验补足了原 notice 中包内容链接未形成可审计在线回执的限制。
归档成员表证明这种布局确实存在，不证明其中所有监控依赖、SSH 或 ps 已可用。

## 实际 shell 对照

命令：

```text
python3 -B work/host-monitor-20261116/review-app/notice-02-dispatch-repro.py
```

脚本仅在 review-app 下建立路径模型：`bin/uname` 返回 Linux，
`usr/bin/uname` 不存在；不改宿主 `/bin` 或 `/usr/bin`。
从旧审查快照和当前源码抽取两处实际 case 分派，以证据目录根替换
`/usr/bin/uname` 的绝对根，资源分支体改为 printf 标记，保留 case 控制流。
这不是完整采集器或 Rust API 测试。

| 分派来源 | 进程前缀 | 资源前缀 |
| --- | --- | --- |
| 旧 PATH 分派 | exit 0，进入 Linux | exit 0，进入 Linux |
| 当前固定 `/usr/bin/uname` | exit 64 | exit 64 |

顶层诊断命令 exit 0，表示四个对照结果符合复现预期；
不能把两个生产分派 exit 64 记成用例通过。
逐条 shell、stdout、stderr 和来源摘要见
`notice-02-dispatch-repro-r1.json` 及 `notice-02-*.sh/.stdout/.stderr`。

错误及缓存后果仍为源码推导：`command_text` 对 64 调用 `checked_text`，
首次返回 `Unsupported`；`error_state` 记录 `UnsupportedPlatform`，
后续资源或进程调用提前返回相应负缓存。显式 reset 后仍执行相同缺失路径。

## 需要的窄修与边界

保留可信系统路径策略，同时支持 `/usr/bin/uname` 与 `/bin/uname`，
两者都缺失时保留缺命令语义；增加仅 `/bin/uname` 布局的分派回归。
资源与进程两处都需要覆盖，不能只改 fixture matcher。

父实际 Mac localhost SSH r2 六项通过、清理回执已读回，但该机器的
`/usr/bin/uname` 存在，所以不能覆盖本项触发条件。
本 reviewer 未运行真实 Linux、SSH、Cargo 或 target；当前证据为
官方归档布局、受控 shell 执行以及 Rust 错误/缓存源码推导。
