# APP-P2-02 — 新分派固定 /usr/bin/uname，回归只提供 /bin/uname 的 Linux

状态：OPEN / REQUEST_CHANGES。这是报告关闭前新导入的 dispatch 窄差分发现。
`report-r1.md` 只对应其所列旧摘要，不能据此批准当前已变化的 session 来源。

绝对位置：

- `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor.rs:61`
- `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor.rs:528`

触发：Linux 远端的有效系统 `uname` 位于 `/bin/uname`，没有
`/usr/bin/uname`，也没有把两个目录合并的符号链接。原代码通过 PATH 的 `uname -s`
能够识别 Linux；新代码在核心资源和 ps 的外层分派均无条件执行
`/usr/bin/uname -s`。

影响：命令替换失败后平台字符串为空，进入 `*) exit 64`，将真实 Linux 误判为
不支持平台。资源与进程两项都失败，并被各自的 UnsupportedPlatform 负缓存保持，
导致原本可用的 `/proc` 资源和 `ps` 读取同时丢失。重新检测仍重复相同绝对路径，
无法恢复。此问题与 Darwin 采集器 ABI 无关，属于本 reviewer 的父 dispatch 契约范围。

静态复现：

1. 在上述 Linux 文件布局中确认 `uname -s` 返回 Linux、`/bin/uname -s` 返回 Linux，
   `/usr/bin/uname -s` 返回找不到文件。
2. 通过新的 `LinuxMonitor.snapshot()` 或 `processes()` 调用固定脚本。
3. 外层 case 得到空字符串并返回 64；首个 API 错误为 Unsupported，后续调用走
   UnsupportedPlatform 负缓存。旧外层 PATH 分派不发生此回归。

核对来源：Alpine 官方 coreutils 包内容明确把 uname 安装在 `/bin/uname`，不能把
`/usr/bin/uname` 当作 Linux 通用保证：
`https://pkgs.alpinelinux.org/contents?arch=armhf&branch=v3.22&name=coreutils&repo=main`。
这里只用上游包内容佐证文件布局的现实性，没有声称运行过 Alpine 或真实 Linux SSH。
来源漂移、原/新摘要见 `source-audit-drift-r1.json`；当前 monitor.rs 摘要为
`f280c96f6d31ae3b4770f888ca077c02f32f05e908e018e7a6e83e74fca86ab8`。

建议：保持可信系统路径策略时，至少明确支持并检测 `/usr/bin/uname` 与
`/bin/uname` 两个位置；缺失路径应按缺失分类，不能误签平台不支持。
为“仅 /bin/uname 存在”的布局补回归，并保留 Darwin 固定路径的安全目标。

验证边界：这是源码分派和缓存状态推导，未运行 Cargo、target 或实际 Linux 容器。
已有 app-r2 的 21 项成功仍绑定旧 session 来源，不应移签本项新差分。
