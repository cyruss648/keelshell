case "$(uname -s)" in
Darwin)
printf 'selected Darwin branch\n'
;;
Linux)
printf 'selected Linux resource branch\n'
;;
*) exit 64 ;;
esac
