# 2026-11-16 App/UI 与父集成契约 — 非作者复核

结论：**APPROVE，限定范围且最终完整门禁待定**。

开放发现为 P0 **0**、P1 **0**、P2 **0**、P3 **0**。
累计确认一项 P2：`APP-P2-01`，已按源码窄差分和独立预构建复跑关闭。
本报告批准所列源码与验证范围；不宣称未执行的完整门禁、真实 Mac SSH 或原生桌面已经通过。

## 身份、范围与来源

父 checkout 始终显式使用：
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`。
目标差分基线与复核结束时 HEAD 均为
`539c172389b4450570026f023ff89d50df90f910`。
本批源码为未提交工作区变化，内容身份由逐文件 SHA-256 绑定。

最终复核的 11 项清单为 `source-manifest-final.json`，
排序后的 `sha256 + 两个空格 + 仓库相对路径 + LF` 原文为 `reviewed-sha256.txt`，
该原文集合 SHA-256：
`62cd10aaedc7a85cb84801785ba9a3ac2a9c7b4e6709273978d4d6edc41b088e`。
完整字节副本位于 `source-snapshot-final/`。这只是本复核范围的来源固定，
不是父的最终全工程冻结。

限定审核指定的 6 个 app 文件、Darwin SSH 集成测试、2 个 Python runner 文件，
以及 session `monitor.rs` 的内存、跨平台速率、dispatch/cache 合同。
session capability cache 与 MCP DTO/调用点仅作为调用契约背景读取。
Darwin 采集器、ABI 与 df 实现的正确性由另一 reviewer 负责；Linux 容器实验、
其他产品功能和历史实现不在本报告的批准范围。

已读取 RTK、AGENTS/HANDOFF 当前批次与持续约束、测试 STRATEGY、
共享 target 合同、ADR 0143 和监控能力产品说明。复核仅在
`work/host-monitor-20261116/review-app/` 写证据。
没有修改生产源码，没有运行 Cargo，没有读取、运行或修改 target 内文件，
没有提交、推送、格式化修改或清理其他资源。
父 metadata 中的 source-executable 路径仅作为来源文本读取，没有跟随该路径访问。

## 发现及修复

`APP-P2-01` 原位置为：
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_tests/darwin.rs:45`。
原测试在暂停打断 CPU 连续区间后只刷新一次，却期待 `Some(50.)`。
`monitor.rs:238` 的历史中断、`monitor_history.rs:126` 的连续性筛选以及
`monitor.rs:350` 的最终 CPU 采用共同要求该次值为 None。
影响为新增默认测试必然失败，阻塞 app 专项及最终门禁。

发现后立即落盘 `notice-01-p2-first-sample-after-pause.md`，
保留当时三文件摘要、带行号源码和静态状态推导。
父随后实际复现 `exit 101 / 69 passed / 1 failed / 0 ignored`，
原始日志和命令回执已复制并由 `notice-01-parent-red-binding.json` 绑定；
这是父执行，未计入独立测试数。

修复仅增加新测试的暂停后首样 None 断言和第二次手动刷新，
在当前测试第 53 行继续验证 50%。生产暂停、历史和速率文件摘要不变，
MCP/内存趋势/iowait 未知值断言保持。
新 app-r2 中四项 Darwin 测试独立全部通过，包含原失败名称，
因此 CLOSED；详见 `notice-01-close-r3.md`。

## 独立实际命令及计数

下列计数均来自本 reviewer 保存的 stdout/stderr 和退出码。
父的整组 app 70 项与 session 79 项结果不并入独立执行数。

| 独立操作 | 命令数 | 实际结果 | 原件 |
| --- | ---: | --- | --- |
| Python OpenSSH runner 专项，`python3 -B -m unittest discover -s scripts -p test_openssh_interop.py -v` | 1 | exit 0；8 passed / 0 failed / 0 skipped | `runner-python-tests-r1.*` |
| session-lib-r1 六项数值模型及两项 cache 授权精确用例 | 8 | 全部 exit 0；8 passed / 0 failed / 0 ignored | `session-contract-tests-r1.json` 及 8 组 stdout/stderr |
| 集成后的 keelshell_session-r2 跨平台速率精确用例 | 1 | exit 0；1 passed / 0 failed / 0 ignored | `session-final-platform-r2.*` |
| app-r2 四项 Darwin、七项 history、十项授权/布局/缓存/进程回执精确专项 | 12 | 全部 exit 0；21 passed / 0 failed / 0 ignored | `app-risk-tests-r2.json` 及 12 组 stdout/stderr |
| 预构建直接 `--list` | 3 | 全部 exit 0；session model 21 名、Darwin ignored 套件 6 名、app monitor 70 名 | `session-model-list-r1.*`、`darwin-interop-list-r1.*`、`app-list-r2.*` |
| 限定范围 `git diff --check` | 3 | 全部 exit 0；只检查 tracked 差分，不当作 Rust 格式门禁 | `diff-check-r1.*`、`diff-check-r3.*`、`diff-check-final.*` |

行为执行共 **22 条命令，38 次测试通过、0 失败**，
对应 **37 个不同用例**；其中 session 跨平台用例在集成后的 r2 binary 又执行一次，
不计为新的不同用例。清单命令不是测试执行，六个真实 Mac SSH 测试未运行。
限定检查与列名另有 6 条命令；来源读取、摘要采集与探索性搜索不计为门禁。
探索阶段一次 `rg` 包含不存在的历史测试文件路径而返回 2，另一次 MCP 搜索包含不存在的
`src/mcp.rs`；均已改查实际路径，没有把这些读取探查当成通过的测试或 gate。

app 独立专项覆盖暂停修复、Mac 资源与只读进程入口、Python 缺失缓存/显式恢复、
内存 MCP None、历史平台切换、未知值断线、过期和未来结果、暂停 ABA、
新连接 cache 授权、未发送命令取消、迟到进程身份、已发送信号回执不重放，
以及三主题/明暗/双语、900×580 紧凑控制、层级滚动、AX 语义与绘制零新增 exec。
所有 app 测试前后 11 个范围文件及 app binary 摘要不变。

## SHA-256 清单

下表路径均相对于上方固定的绝对 checkout；JSON 清单同时包含每项绝对路径、
字节数与基线 blob 的 SHA-256。

| 源码 | 当前 SHA-256 |
| --- | --- |
| `crates/keelshell-app/src/monitor.rs` | `9f316513fc94c8bd94c0aef2343f7f6902b53098d8bfbf7582a0191df0907fe0` |
| `crates/keelshell-app/src/monitor_capabilities.rs` | `f5df00fd1a57114b47b7a6699e7b7f3733789a8fff6dbc7c178cbb0a80f60f09` |
| `crates/keelshell-app/src/monitor_history.rs` | `79d91cb8b467b854b0a27553cc96d254ab88c0db508b54bbb4710f2116cdc0a9` |
| `crates/keelshell-app/src/monitor_tests.rs` | `68c616c8ee300d59c409a8cc583cf6327e50103207e2b1961b0b1741d22ec3c1` |
| `crates/keelshell-app/src/monitor_tests/capabilities.rs` | `3b747195fd185a4df4a20b5a88eeee8955d3009f62a82b228aef0a92ed20707a` |
| `crates/keelshell-app/src/monitor_tests/darwin.rs` | `5d931b7053a0e4a65b9ff445b1d4a9392594d4545311359a794f7d7e0bf0f772` |
| `crates/keelshell-session/tests/darwin_monitor_interop.rs` | `de2a8c9c184fed1cb911ed9f2fd485bde3cb87ef24ddad280cc9a8b8380d69d7` |
| `scripts/openssh_interop.py` | `81500e1ea62e9e7a1eb518561906f1075dc227c2176c6850ac0f89f8ab03bc8a` |
| `scripts/test_openssh_interop.py` | `bfac68a0a644b03206bff6538d6315a1b094463a1ddf3ed1522ea3ab99ce3b02` |
| `crates/keelshell-session/src/monitor.rs` | `63794e87128589b761faf347d0c7eca1723b3e15cbd2573f1b63408b48071c90` |
| `crates/keelshell-session/src/monitor/capabilities.rs` | `0ec34394bcf9bf53ecb2503859405245885f32c13da8c866454b9226916bf28e` |

| 实际使用的预构建 | SHA-256 | 用途 |
| --- | --- | --- |
| `work/host-monitor-20261116/bins/app-r2` | `282cae510800e260a68af1abf612307dabe2008f3c223f45c9f00e0650d6074c` | 70 名清单与 21 项独立 app 执行 |
| `work/host-monitor-20261116/bins/session-lib-r1` | `e1abff7ca01a182fbc8ac9bb21acfff46a0296e6834f7b265772760dd4ad87fa` | 21 名 model 清单与 8 项独立执行 |
| `work/host-monitor-20261116/bins/keelshell_session-r2` | `53d56e642071cdbec02f19427f6fbf1806aec4718ef8c577dcfbc8a3f9e1b727` | 集成后跨平台精确用例 |
| `work/host-monitor-20261116/bins/darwin_monitor_interop-r1` | `70839ce493ccbe5900aa4cfcaa0c4279ad7231d8676c4baff6972b087a66f3ee` | 只列六个 ignored 名称，没有执行真实 SSH |

使用前均确认稳定路径为普通文件且 link count 为 1，没有跟随到 target 的符号链接或硬链接。
app-r2 和 session-lib-r1 执行前后摘要均一致。

## 批准条件与验收边界

1. 父的最终工程冻结必须逐项包含本报告 11 个范围文件的相同摘要；如发生语义变化，
   需对变化复核和执行必要专项。可在同一冻结绑定最终完整门禁回执，不把当前批准改写为已跑全门禁。
2. 最终格式、严格 Clippy、全部测试、依赖政策及相关工程检查由父执行；
   本 reviewer 没有运行 Cargo，也没有独立重新编译这些 binary。
   SHA 与具体用例名核验减少来源歧义，不能消除信任父构建流程的限制。
3. 新增 Darwin label 测试遍历主题、明暗与语言，既有紧凑测试验证操作、几何及滚动。
   它们是 headless GPUI 证据，不能签署新增 Darwin 内存卡片在真实 Mac 窄窗、
   键盘、IME、VoiceOver 或其他平台桌面的视觉与辅助技术验收。
4. app fixture 返回人工帧并不执行远端 shell。它的 Darwin 模式仍可能匹配复合脚本中的
   Linux 命令字符串；这类成功只说明协议采用/UI 状态，不能证明真实 Darwin 分派、
   内核计数、Python 能力、df 或 socket 互通。固定六项真实 Mac SSH、另一 reviewer 的
   采集器审查及 Linux 真实降级/恢复证据须独立保留。
5. 本报告没有启动真实 Mac SSH、生产机器连接、安装、遥测、发行或 native GUI，
   没有批准这些未执行范围。原始失败、后续修复与成功专项各自留存。

完整源码判断见 `source-review-r1.md`；最终建议为 **APPROVE**，
允许父在这些限定条件下继续绑定最终冻结与完整门禁。
