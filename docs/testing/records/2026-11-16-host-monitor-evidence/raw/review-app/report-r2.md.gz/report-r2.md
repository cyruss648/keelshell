# 2026-11-16 App/UI 与父集成契约 — 当前来源复核

结论：**REQUEST_CHANGES**。当前开放 P0 **0**、P1 **0**、P2 **1**、P3 **0**。
唯一开放发现为 `APP-P2-02`，属于用户指定的父平台 dispatch 契约。
`APP-P2-01` 保持 CLOSED；六个 app 文件没有新的开放发现。
最终完整门禁仍 PENDING；实际 Mac SSH 与桌面验收分别记录。

本报告取代 `report-r1.md` 对当前来源的建议，原报告、失败和补充均保留。
父可以在修复后的窄差分完成复核后收取新的条件批准；
当前不能把旧来源批准或 Mac 成功移签到 Linux 分派回归。

## 当前发现

**[P2] APP-P2-02：固定 `/usr/bin/uname` 使仅有 `/bin/uname` 的 Linux 资源与进程分派返回 64。**

绝对位置：

- `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor.rs:61`
- `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor.rs:528`

触发为真实 Linux 的 uname 只位于 `/bin/uname`，而 `/usr/bin` 未与 `/bin` 合并。
本批后来将原有 PATH 分派改成固定 `/usr/bin/uname`。该命令缺失时 case
取得空字符串，进入 unsupported 分支。即使 `/proc` 可读或兼容的 ps 已安装，
采集也会被外层提前阻断。首次 API 返回 Unsupported，随后缓存
UnsupportedPlatform；显式重查仍无法越过同一缺失路径。

已实际读取 Alpine 官方 3.22.0 x86_64 minirootfs 并核对官方 SHA-256；
归档的 bin 与 usr/bin 为独立目录，bin/uname 指向 bin/busybox，
usr/bin/uname 不存在。受控路径模型执行两个旧分派均 exit 0，
两个当前分派均 exit 64。该执行只验证 shell 控制流，未运行 Linux、
SSH、采集器或 Rust API；缓存后果由当前源码核对。

详见 `notice-02-p2-uname-location-regression.md`、
`notice-02-followup-r2.md`、`notice-02-official-layout-r1.json`
和 `notice-02-dispatch-repro-r1.json`。
建议两处分派均保留 `/bin/uname` 回退，增加对应回归，并正确区分缺命令与平台不支持。

## 已关闭发现与本轮窄差分

`APP-P2-01`：新增 Darwin 测试原先在暂停后的第一个样本期待 CPU 50%，
违背现有断段合同。父实际复现 69 passed / 1 failed 后仅修改测试：
首样 None，第二次刷新才 50%。生产暂停、速率与历史实现保持。
本 reviewer 已在父 app-r2 上独立运行四项 Darwin 测试全部通过，
包含原失败名称；关闭原件 `notice-01-close-r3.md` 保持。

相对 report-r1 的 11 项来源，当前只有两项字节变化：

1. session monitor.rs 两处分派改为固定 `/usr/bin/uname`，内部 matcher 同步修改；
   该项产生上面的开放发现。
2. Darwin SSH 集成测试连接准入改 `/usr/bin/uname -s`；socket 测试改为首次
   Unsupported、第二次 typed cached UnsupportedPlatform。后者与实际 API 一致，
   测试没有减弱 Mac 进程只读、unknown 内存、速率、df 或授权撤销断言。
   父真实 r1 的 5 passed / 1 failed 原件已保存，r2 的修后成功另列。

六个 app 文件、两个 Python 文件及 capability cache 文件摘要均与旧审查相同。
free/available/used 区分、MCP None、历史断段、跨平台速率、Mac Stop 按钮与
direct run 双拦截、连接 cache 授权、迟到结果、后台 I/O、主题和双语的
已审结论保持；没有用上述稳定性消除新增 dispatch 风险。

## 来源身份与范围

所有父 checkout 命令显式 workdir：
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`。
基线及本次读回 HEAD：
`539c172389b4450570026f023ff89d50df90f910`。
未提交源码以逐文件 SHA-256 固定，不将 HEAD 当成本批变更内容身份。

当前清单 `source-manifest-r2-final.json`，字节副本 `source-snapshot-r2/`，
排序摘要原文 `reviewed-sha256-r2.txt`。其集合 SHA-256：
`b71ee0694b256fb242d572b36256b5d950b000e15e52d7406457d383618bc7a1`。
这是限定审查冻结，不是父全工程冻结。

| 源码（相对固定的绝对 checkout） | SHA-256 |
| --- | --- |
| `crates/keelshell-app/src/monitor.rs` | `9f316513fc94c8bd94c0aef2343f7f6902b53098d8bfbf7582a0191df0907fe0` |
| `crates/keelshell-app/src/monitor_capabilities.rs` | `f5df00fd1a57114b47b7a6699e7b7f3733789a8fff6dbc7c178cbb0a80f60f09` |
| `crates/keelshell-app/src/monitor_history.rs` | `79d91cb8b467b854b0a27553cc96d254ab88c0db508b54bbb4710f2116cdc0a9` |
| `crates/keelshell-app/src/monitor_tests.rs` | `68c616c8ee300d59c409a8cc583cf6327e50103207e2b1961b0b1741d22ec3c1` |
| `crates/keelshell-app/src/monitor_tests/capabilities.rs` | `3b747195fd185a4df4a20b5a88eeee8955d3009f62a82b228aef0a92ed20707a` |
| `crates/keelshell-app/src/monitor_tests/darwin.rs` | `5d931b7053a0e4a65b9ff445b1d4a9392594d4545311359a794f7d7e0bf0f772` |
| `crates/keelshell-session/tests/darwin_monitor_interop.rs` | `f127da7888f515a6fd5dda07c489a96353697b2a8943f8323203a6f6d0051c7d` |
| `scripts/openssh_interop.py` | `81500e1ea62e9e7a1eb518561906f1075dc227c2176c6850ac0f89f8ab03bc8a` |
| `scripts/test_openssh_interop.py` | `bfac68a0a644b03206bff6538d6315a1b094463a1ddf3ed1522ea3ab99ce3b02` |
| `crates/keelshell-session/src/monitor.rs` | `f280c96f6d31ae3b4770f888ca077c02f32f05e908e018e7a6e83e74fca86ab8` |
| `crates/keelshell-session/src/monitor/capabilities.rs` | `0ec34394bcf9bf53ecb2503859405245885f32c13da8c866454b9226916bf28e` |

Darwin 采集器、ABI 和 df 实现由另一 reviewer 负责；本报告不签这些实现。
capability cache 与 MCP 调用点为合同背景读取；产品范围、Linux 实验实现、
全仓工程和原生桌面不在独立批准范围。
已读 RTK、AGENTS/HANDOFF、STRATEGY、SHARED_TARGET、ADR 和监控产品合同。

## 独立实际执行

下面复用摘要未变部分的既有证据，不为增加计数重复执行全部测试。

| 操作 | 命令数 | 实际结果 |
| --- | ---: | --- |
| Python runner 单测，`python3 -B -m unittest discover -s scripts -p test_openssh_interop.py -v` | 1 | exit 0；8 passed / 0 failed / 0 skipped |
| session-lib-r1 数值模型与 cache 授权精确测试 | 8 | 全部 exit 0；8 passed / 0 failed / 0 ignored |
| session-r2 跨平台速率精确复跑 | 1 | exit 0；1 passed / 0 failed / 0 ignored |
| app-r2 Darwin、history、授权/布局/绘制无 I/O 等专项 | 12 | 全部 exit 0；21 passed / 0 failed / 0 ignored |
| 三份预构建具体测试库存 | 3 | exit 0；列名，不计测试执行 |
| scoped `git diff --check`（含当前来源再核对一次） | 4 | exit 0；仅 tracked 空白差分，不替代 rustfmt |
| 新分派路径模型诊断 | 1 顶层命令，4 条 shell | 诊断 exit 0；旧对照 2×exit 0，当前复现 2×exit 64 |

Rust/Python 行为测试共 **22 条命令、38 次通过、37 个不同用例**，
失败、ignored、skipped 均为 0；一次 session 用例为重复执行。
分派诊断单列，不并入这些通过数。来源审计曾因两文件变化 exit 1，
保存在 `source-audit-drift-r1.json`；这不是测试失败。
独立执行详情和 stdout/stderr 分别见 `runner-python-tests-r1.json`、
`session-contract-tests-r1.json`、`session-final-platform-r2.json`、
`app-risk-tests-r2.json` 及原报告引用的逐条原件。

| 使用的稳定预构建 | SHA-256 |
| --- | --- |
| `work/host-monitor-20261116/bins/app-r2` | `282cae510800e260a68af1abf612307dabe2008f3c223f45c9f00e0650d6074c` |
| `work/host-monitor-20261116/bins/session-lib-r1` | `e1abff7ca01a182fbc8ac9bb21acfff46a0296e6834f7b265772760dd4ad87fa` |
| `work/host-monitor-20261116/bins/keelshell_session-r2` | `53d56e642071cdbec02f19427f6fbf1806aec4718ef8c577dcfbc8a3f9e1b727` |
| `work/host-monitor-20261116/bins/darwin_monitor_interop-r1`（只列名） | `70839ce493ccbe5900aa4cfcaa0c4279ad7231d8676c4baff6972b087a66f3ee` |

执行前核对普通文件、非符号链接、link count 1、SHA 与测试名。
app-r2 当前再次读回 SHA 不变。以上都是父提供的预构建，
**没有独立编译**，且 Rust 执行早于最后的 uname 字面量变化；
这些成功不能证明新绝对路径的运行效果或消除构建来源信任边界。

## 父执行回执读回

本 reviewer 已复制并逐项摘要绑定以下原件，见 `parent-receipts-readback-r2.json`：

- app-monitor-r3：70 passed / 0 failed / 0 ignored；外层 exit 0、reaped、未超时。
- 实际 Darwin localhost OpenSSH r2：6 passed / 0 failed / 0 ignored；
  外层 exit 0、reaped、未超时。测试日志 SHA-256
  `6a85f0276f253994ac804e3ee97cd35e17d2f96f4400b3547105fd66d60965d8`，
  result.json SHA-256
  `29e14381d9c628295df53dd69b064d88f468a88e72cdfef155f6a29aeb06ead9`。
- r2 清理回执记录 33 个 birth identities，observed/owned processes stopped、
  私有目录删除均为 true，ancestry_unverified 为空；本 reviewer 额外读回该私有路径 absent。
  没有独立重新枚举存活 PID；不超出回执声明的 ancestry 观察边界。
- 真实 Mac SSH r1 的 5/1 失败及修后 r2 分别保留，不把原件改写为成功。

父执行的 70 和 6 不并入独立 38 次通过。真实 Mac SSH 六项覆盖当前内存未知值、
资源计数、区间速率、实际 df、只读 ps 与 Linux 动作拒绝、cache 授权撤销；
它们不覆盖仅 `/bin/uname` 的 Linux。

## 后续绑定与限制

APP-P2-02 修复后需要只复核受影响的资源/进程分派与回归，再出新的来源结论；
没有修复不能以“最终门禁待定”条件批准该已知回归。
收到条件批准后，父可以把相同最终工程输入的完整门禁单独绑定，
不改写旧报告签署时的 pending 或失败状态。

当前没有运行 Cargo，没有访问或修改 target，没有修改生产源码或执行格式化，
没有提交、推送、清理其他资源；所有新增证据只写 review-app。
读取回执中记录的 target 路径只是读取文字，没有跟随该路径访问。

三主题、双语和紧凑布局的独立专项为 headless GPUI 与人工 SSH 帧。
fixture 不执行远端 shell，可能匹配复合脚本里的 Linux 字符串，
不能据此签真实 Darwin 分派或采集。真实 SSH 回执也不能签原生 Mac 窄窗、
键盘、IME、VoiceOver、Windows/Linux 桌面或完整产品验收。
完整门禁仍 PENDING，Darwin 采集器的另一 reviewer 结论单独收取。
