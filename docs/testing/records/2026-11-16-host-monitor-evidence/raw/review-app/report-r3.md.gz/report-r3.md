# 2026-11-16 App/UI 与父集成契约 — 最终限定复核

结论：**APPROVE，限定源码范围，最终完整门禁与正常程序构建回执待父绑定**。

当前开放发现：P0 **0**、P1 **0**、P2 **0**、P3 **0**。
累计确认的两项 P2 `APP-P2-01`、`APP-P2-02` 均已关闭。
本报告签署当前固定来源；没有把 pending 工程门禁、原生桌面或其他 reviewer
的采集器实现范围写成通过。

本报告取代旧来源的建议。`report-r1.md`、`report-r2.md`、原 notice、
红证据和修后成功均保留原件；父后续可以附加同一输入的门禁绑定，不改写这些报告。

## 来源与范围

父 checkout 始终显式 workdir：
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`。
目标差分基线及最终读回 HEAD 均为：
`539c172389b4450570026f023ff89d50df90f910`。
源码仍为未提交工作区差分，逐文件 SHA-256 是本批内容身份。

本次固定 11 项来源，见 `source-manifest-r3-final.json`，
字节快照 `source-snapshot-r3-final/`，
排序摘要原文 `reviewed-sha256-r3.txt`。该摘要原文的 SHA-256 为：
`8f6f7afc642707bc2cab45747ec50a7fb4597fac530ff706c3c9e3717ac0f8ba`。

父候选为 `candidate-inputs-r1.json`，实际清单 713 项且路径无重复，
父声明 aggregate：
`66936ab5115a3abe55ef6e9bd8e460f8bf4b9462252d249a028f35d10c9b5740`。
原文件 SHA-256：
`86db0ba0043d2431db04458404451d0e71a97035c4f523da4f01bcfa130eeddb`。
已逐项确认本复核的 **11/11** 路径、摘要和字节数与父候选及当前文件一致，
见 `candidate-input-binding-r3.json`。
没有独立重新读取其余 702 个工程输入，父 aggregate 按其声明记录；
不能把限定绑定当成全工程冻结的独立认证。

范围为指定六个 app 文件、Darwin SSH 集成测试、两个 Python runner 文件，
以及 session monitor.rs 的模型、跨平台速率、平台 dispatch/cache 合同。
capability cache 与 MCP DTO/调用点仅作为调用合同背景读取。
Darwin 内核采集、ABI、df 实现由另一 reviewer 负责；Linux 实验实现、
其他产品功能和原生桌面不在本报告批准范围。

已读 RTK、AGENTS/HANDOFF、STRATEGY、SHARED_TARGET、ADR 0143 和监控产品合同。
只在 review-app 下写证据；未修改生产源码、运行 Cargo、访问或修改 target、
格式化修改、提交、推送或清理其他资源。
回执中的 target 路径仅作为文字读取，没有跟随访问。

## 发现闭合

**APP-P2-01，CLOSED。** 原位置：
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_tests/darwin.rs:45`。
新增测试在暂停后的首个样本错误期待 CPU 50%，违背现有历史断段合同。
父实际复现 69 passed / 1 failed；仅改新测试，首样断言 None，
第二次刷新断言 50%，没有改变生产暂停合同。
本 reviewer 在 app-r2 独立执行四项 Darwin 测试全部通过，包含原失败名称。
详见 `notice-01-close-r3.md`；父红日志保持。

**APP-P2-02，CLOSED。** 原两处位置：
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor.rs:61`
和同文件原第 528 行。
后来导入的固定 `/usr/bin/uname` 回归仅有 `/bin/uname` 的 Linux。
官方 Alpine 固定归档及 checksum 已核验这种布局存在；
受控 shell 对照为旧分派 2×exit 0、问题分派 2×exit 64。
这些是归档布局与控制流证据，未运行实际 Linux SSH。

修后第 60–65 行 selector 只检查 `/usr/bin/uname`、`/bin/uname`，
要求 `-f && -x`，均缺失 exit 66，沿现有 API 映射为 CommandMissing。
进程脚本含同一前缀，资源第 539 行直接嵌入常量。
新增第 1172 行回归执行真实、有界的 `/bin/sh`，覆盖 bin-only 与双缺失。
本 reviewer 在 session-r4 精确独立执行 **1 passed / 0 failed / 0 ignored**；
前后 11 项源码和 binary 摘要无漂移，测试私有目录已回收。
因此关闭，详见 `notice-02-close-r4.md`、源码窄 diff 和独立执行回执。

## 主要合同结论

| 风险 | 本次结论与证据边界 |
| --- | --- |
| free、available、used | free 独立展示；used 仅从 available 做 checked_sub，不从 free 推算。session 模型、app MCP 和历史源码及专项一致。 |
| MCP null 与趋势断段 | Option 未跳过序列化；未知 used、iowait 不填 0，趋势在未知、暂停、重启、时钟或平台变化时断段。未启动真实 MCP server。 |
| 跨平台速率 | CPU/network/disk 不跨平台相减，Darwin iowait 保持 None。模型与历史专项已独立运行。 |
| Mac 进程只读 | Stop 入口和 direct run 都要求 Linux snapshot；ProcessIdentity 私有并绑定连接。Mac 不发终止命令。 |
| 授权与迟到结果 | cache Arc、generation、revision、panel generation 和 freshness 分别校验，pause/retirement 撤销授权。相关独立专项通过。 |
| UI I/O | render、MCP 缓存读取和 locale 路径不新增 SSH；阻塞操作由后台 worker 执行。绘制零 exec 专项通过。 |
| 三主题、双语、窄布局 | 使用 registry、Palette 和组件 token。独立 headless 专项覆盖主题/语言、紧凑操作、滚动、键盘及 AX；新增 Mac 卡片的真实桌面布局未验收。 |
| 平台分派与缺命令 | selector 修复和真实 shell 单项已通过；socket 首次 Unsupported、后续 typed cache 的测试修正符合当前 API。 |
| fixture 真实性 | app 人工帧不执行 shell，matcher 可能命中复合脚本中的 Linux 字符串。其成功只证明解析/采用/UI；实际 Mac localhost SSH 单独记录。 |

## 独立执行命令与计数

所有命令均在上方固定 workdir 执行，原件含参数、退出码、stdout/stderr。
摘要未变部分复用既有专项，不重复作者全部门禁。

| 独立操作 | 命令数 | 实际结果 | 记录 |
| --- | ---: | --- | --- |
| `python3 -B -m unittest discover -s scripts -p test_openssh_interop.py -v` | 1 | exit 0；8 passed / 0 failed / 0 skipped | `runner-python-tests-r1.json` |
| session-lib-r1 六项数值模型、两项 cache 授权 | 8 | 全部 exit 0；8 passed / 0 failed / 0 ignored | `session-contract-tests-r1.json` |
| session-r2 跨平台速率精确复跑 | 1 | exit 0；1 passed / 0 failed / 0 ignored | `session-final-platform-r2.json` |
| app-r2 Darwin 4、history 7、授权/布局/缓存/进程回执 10 | 12 | 全部 exit 0；21 passed / 0 failed / 0 ignored | `app-risk-tests-r2.json` |
| session-r4 新 selector 精确回归 | 1 | exit 0；1 passed / 0 failed / 0 ignored | `selector-independent-r4.json` |
| 直接测试库存 `--list` | 4 | 全部 exit 0；列名，不算执行 | 三份旧库存及 `selector-list-r4.json` |
| 限定 `git diff --check` | 5 | 全部 exit 0；tracked 空白差分，不替代 rustfmt | 旧三次、r2-final、r3-final |
| 问题分派的受控路径模型诊断 | 1 顶层命令，4 条 shell | 诊断 exit 0；旧对照 2×0、问题分派 2×64 | `notice-02-dispatch-repro-r1.json` |

Rust/Python 行为测试合计 **23 条命令、39 次通过、38 个不同用例**，
失败、ignored、skipped 均为 0。一次 session 用例为重复执行。
分派红诊断不并入通过数，列名和 diff check 不算行为测试。
新增 selector 的实际完整 argv 为：

```text
/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/host-monitor-20261116/bins/keelshell_session-r4 --exact monitor::tests::platform_selector_supports_bin_only_uname_and_reports_both_paths_missing --nocapture --test-threads=1
```

源码发布前审计曾因两文件变化 exit 1，原件 `source-audit-drift-r1.json`；
本次回执派生脚本曾错误预期 session 80 项，而实际为 81，已从原日志修正，
见 `receipt-readback-derivation-error-r3.json`。
这两次是来源/派生检查失败，没有记成 Rust 测试失败或隐藏成通过。
早期不存在路径的探索搜索退出码见 report-r1；不属于门禁。

## 父执行的实际回执

已读取、复制并摘要绑定，未并入独立 39 次通过：

- app-monitor-r3：**70 passed / 0 failed / 0 ignored**，
  外层 exit 0、reaped、未超时。六个 app 文件摘要保持。
- session monitor r4：**81 passed / 0 failed / 0 ignored**，
  外层 exit 0、reaped、未超时，包含新增 selector 回归。
- 最终实际 Mac localhost SSH r3：**6 passed / 0 failed / 0 ignored**，
  外层 exit 0、reaped、未超时。测试日志 SHA-256：
  `094497c01a03bfbc47a2fa495bf52a5af4f28d9a59f0319f029380e718a315a9`；
  result.json SHA-256：
  `7aab8160d37a347bd22c2bee5e6acc4eb5ebf7d21301e4ce00f8610103718eb2`。
- 最终 r3 清理回执记录 **33** 个 birth identities，
  owned/observed processes stopped 和私有目录删除均 true，
  ancestry_unverified 为空。本 reviewer 再次读回该私有目录 absent。
  未独立重新枚举所有存活 PID，不超出回执所述 ancestry 观察边界。

绑定见 `parent-receipts-readback-r2.json`、`parent-receipts-readback-r3.json`。
Mac SSH r1 的 5/1 红证据、修后 r2 六项成功与最终 r3 六项成功分别保留。
这些测试覆盖实际 kernel counters、内存未知值、区间速率、df、只读 ps、
Linux 动作拒绝和 cache 授权；不能据此签原生桌面或真实 Linux 全场景。

## SHA-256 清单

下表路径均相对于上方绝对 checkout，JSON 清单另含每项绝对路径及字节数。

| 源码 | SHA-256 |
| --- | --- |
| `crates/keelshell-app/src/monitor.rs` | `9f316513fc94c8bd94c0aef2343f7f6902b53098d8bfbf7582a0191df0907fe0` |
| `crates/keelshell-app/src/monitor_capabilities.rs` | `f5df00fd1a57114b47b7a6699e7b7f3733789a8fff6dbc7c178cbb0a80f60f09` |
| `crates/keelshell-app/src/monitor_history.rs` | `79d91cb8b467b854b0a27553cc96d254ab88c0db508b54bbb4710f2116cdc0a9` |
| `crates/keelshell-app/src/monitor_tests.rs` | `68c616c8ee300d59c409a8cc583cf6327e50103207e2b1961b0b1741d22ec3c1` |
| `crates/keelshell-app/src/monitor_tests/capabilities.rs` | `3b747195fd185a4df4a20b5a88eeee8955d3009f62a82b228aef0a92ed20707a` |
| `crates/keelshell-app/src/monitor_tests/darwin.rs` | `5d931b7053a0e4a65b9ff445b1d4a9392594d4545311359a794f7d7e0bf0f772` |
| `crates/keelshell-session/tests/darwin_monitor_interop.rs` | `f127da7888f515a6fd5dda07c489a96353697b2a8943f8323203a6f6d0051c7d` |
| `scripts/openssh_interop.py` | `81500e1ea62e9e7a1eb518561906f1075dc227c2176c6850ac0f89f8ab03bc8a` |
| `scripts/test_openssh_interop.py` | `bfac68a0a644b03206bff6538d6315a1b094463a1ddf3ed1522ea3ab99ce3b02` |
| `crates/keelshell-session/src/monitor.rs` | `7adb9395ff8db239e59fb0edf1a589a8d6d842d5c302556e5f6c0773ff9868b7` |
| `crates/keelshell-session/src/monitor/capabilities.rs` | `0ec34394bcf9bf53ecb2503859405245885f32c13da8c866454b9226916bf28e` |

| 独立使用的稳定预构建 | SHA-256 | 用途 |
| --- | --- | --- |
| `work/host-monitor-20261116/bins/app-r2` | `282cae510800e260a68af1abf612307dabe2008f3c223f45c9f00e0650d6074c` | 列名与 21 项 app 专项 |
| `work/host-monitor-20261116/bins/session-lib-r1` | `e1abff7ca01a182fbc8ac9bb21acfff46a0296e6834f7b265772760dd4ad87fa` | 列名与 8 项模型/cache |
| `work/host-monitor-20261116/bins/keelshell_session-r2` | `53d56e642071cdbec02f19427f6fbf1806aec4718ef8c577dcfbc8a3f9e1b727` | 跨平台精确复跑 |
| `work/host-monitor-20261116/bins/keelshell_session-r4` | `d45b07a984babf9b767956c494e11fb2566168186655fa18fe6a1b70612751a3` | 新 selector 精确列名与执行 |
| `work/host-monitor-20261116/bins/darwin_monitor_interop-r1` | `70839ce493ccbe5900aa4cfcaa0c4279ad7231d8676c4baff6972b087a66f3ee` | 只列六个名，未独立执行 |

所有实际执行副本先核对普通文件、非符号链接、link count 1、摘要及具体库存。
**全部 Rust 独立执行都使用父预构建，没有独立重新编译。**
早期 app/session 成功绑定当时来源，不能自行证明后来的 uname 变化；
最后该窄差分由源码复核和 session-r4 新回归单独闭合。
匹配摘要与测试名也不能消除对父构建来源的信任限制。

## 批准条件

1. 父最终工程冻结与提交绑定须包含本报告 11 项相同摘要。
   如果再变更源码，对变化重新窄审和执行必要专项；不移签旧批准。
2. 本报告签署时最终 `scripts/check.py` 完整门禁 **PENDING**，
   正常 GUI/MCP 构建完成回执也尚未收取。父在相同最终工程输入上
   实际完成格式、严格 Clippy、测试、依赖政策及相关构建后，单独附加成功终态绑定；
   不修改报告来倒填“已执行”。
3. Darwin 采集器实现由另一 reviewer 的报告负责；
   Linux 真实降级/恢复与其他验收分别保留范围和结果。
4. 本批独立 UI 证据为 headless GPUI；未验收真实 Mac 新卡片在窄窗中的
   可见性、键盘、IME、VoiceOver，也未验收 Windows/Linux 桌面。
   实际 localhost SSH 六项成功不替代这些桌面范围。

在上述来源与验收边界内，最终建议为 **APPROVE**。
