# App/UI 与父集成契约 — 源码审核记录

基线及当前 HEAD：`539c172389b4450570026f023ff89d50df90f910`。
本批实现仍在工作区，不把 HEAD 当成未提交变更的内容身份。
范围摘要见 `source-manifest-r4.json`；该清单不是父的最终工程冻结。
以下为源码判断，实际运行与最后建议另见最终报告。

## 来源与只读边界

已读取 RTK、工程 AGENTS、HANDOFF 的当前批次与持续约束、测试 STRATEGY、
共享 target 归属合同、ADR 0143 与当前监控能力产品合同。
Rust 技能只用于所有权、线程、错误和测试语义核对；本轮明确禁止的
Cargo、格式化修改与 target 访问没有执行。

复核 6 个指定 app 文件、父新增 Darwin SSH 集成测试、2 个 Python runner 文件，
并核对 session `monitor.rs` 的内存、跨平台速率、分派、缓存契约。
session capability cache 与 MCP DTO/调用点仅作为调用合同背景读取。
不复核 Darwin 内核 ABI、采集器实现和 Linux 容器实验实现。

## 按风险核对

| 风险 | 源码判断 | 证据与限制 |
| --- | --- | --- |
| free 与 available/used 混淆 | 未发现回退推算 | `MemorySnapshot.used_bytes()` 仅从 available 使用 checked_sub；新增 free 字段不参与。app 的 MCP 和趋势统一使用此方法。 |
| MCP null | 未发现把未知变成 0 或移除字段 | MCP DTO 的 `memory_used_bytes: Option<u64>` 无 skip-serialization 属性；app Darwin 测试断言 None。只核对源码，未运行 MCP 服务。 |
| 趋势断段 | 平台、启动时间、时钟、计数器和暂停检查保持 | 历史模型先检查平台相等；空值使 vertices 停止连线。新跨平台历史回归已列入源码清单，app 执行待新 binary。 |
| 平台速率 | 未发现跨平台相减 | session 在 CPU/network 推导前拒绝平台变化；disk 计算也传入平台一致条件。Darwin iowait 保持 None。已独立执行预构建 6 项模型回归。 |
| Mac 进程只读 | 入口与 run 有两层限制 | Stop 入口要求已验证的 Linux snapshot；run 同时拦截 Inspect/Terminate。ProcessIdentity 私有并绑定 SSH 连接，不能由公开进程行直接构造。 |
| Linux 专用 socket 操作 | 主操作与 run 拒绝已有 Darwin snapshot | 顶部 Sockets 按钮禁用，run 拦截 Sockets/Probe；平台仍未知时由固定远端平台检查 fail closed。此处不声称已完成 Mac 缺 Python 的原生交互验收。 |
| 连接授权及迟到结果 | 未发现新增越权路径 | 同一 cache Arc、generation、revision、panel generation、10 秒截止分别校验；suspend 撤销报告与待审核进程。已独立执行预构建 2 项 cache 授权回归。 |
| UI I/O | 新增 render/MCP/locale 路径只读缓存 | SSH 与 reset 在 execute_job 后台 worker；UI 检查只读 atomics，主题/语言刷新仅 notify。未执行真实窗口观察。 |
| 三主题与双语 | 新控件沿用 registry、Palette、组件 token | 资源标签、内存原因、能力名称与 Mac 操作语义均有双语文本。源码中的新增 Darwin 测试遍历主题/明暗/语言，但主要核对 AX 标签。 |
| 狭窄布局 | 未签署实际 Darwin 窄窗验收 | 既有测试覆盖 900×580 和 260 px 面板操作几何；新增 Darwin label 测试只用原 harness，不能把标签存在等同于可见或可达。待独立 headless 专项；真实桌面保持 NOT_RUN。 |
| 实际 SSH 范围 | 新套件目标与平台准入一致 | `--monitor-darwin` 与 zmodem 互斥，在非 Darwin 主机上先拒绝、后创建资源。六项测试为 opt-in，使用 pinned owned loopback SSH 与固定实际命令，不自动安装、提权或终止 Mac 进程。未执行这六项真实 SSH。 |
| fixture 不自证真实成功 | 按其实际边界使用 | app Peer 返回合成帧，只能证明解析、采用和 UI 状态；它不执行 shell 的 Darwin/Linux 分支。既有 matcher 可在 Darwin 模式匹配包含 Linux 字符串的复合脚本；因此不能据该 fixture 宣称 Darwin 实际采集或 socket 互通成功。真实套件与另一个 reviewer 的采集器证据必须另记。 |

## 已知发现

`APP-P2-01`：暂停后首样 CPU 应未知，而新测试原来期待 50%。
原 notice、源码摘录、父实际红证据均保存。父仅修改新测试，
增加首样 None 断言与第二次刷新；已核对 11 个范围文件中仅该测试变化。
状态为源码修复通过、等待新 app 预构建专项。没有削弱生产暂停或历史合同。

除此之外，当前源码审核未确认 P0、P1 或其他 P2/P3。
尚未执行的门禁、原生与动态范围不是通过项。
