/* Syntax-only assertions against the current local arm64 macOS public SDK. */
#include <stddef.h>
#include <stdint.h>
#include <sys/time.h>
#include <sys/sysctl.h>
#include <mach/mach.h>
#include <mach/mach_init.h>
#include <mach/mach_time.h>
#include <mach/host_info.h>
#include <mach/vm_statistics.h>
#include <net/if.h>

#if !defined(__arm64__) || !defined(__LP64__)
#error This review evidence is intentionally limited to local arm64 LP64.
#endif

_Static_assert(sizeof(void *) == 8 && sizeof(long) == 8, "LP64");
_Static_assert(sizeof(integer_t) == 4 && (integer_t)-1 < 0, "signed Mach word");
_Static_assert(sizeof(natural_t) == 4 && (natural_t)-1 > 0, "unsigned Mach word");
_Static_assert(sizeof(host_t) == 4 && sizeof(host_flavor_t) == 4, "host arguments");
_Static_assert(sizeof(mach_msg_type_number_t) == 4, "Mach output count");
_Static_assert(sizeof(vm_size_t) == sizeof(size_t) && sizeof(vm_size_t) == 8, "page output");
_Static_assert(sizeof(struct timeval) == 16, "timeval output buffer");
_Static_assert(sizeof(((struct timeval *)0)->tv_sec) == 8, "timeval seconds");
_Static_assert(sizeof(((struct timeval *)0)->tv_usec) == 4, "timeval microseconds");
_Static_assert(offsetof(struct timeval, tv_usec) == 8, "timeval layout");
_Static_assert(sizeof(mach_timebase_info_data_t) == 8, "timebase output buffer");
_Static_assert(offsetof(mach_timebase_info_data_t, denom) == 4, "timebase layout");
_Static_assert(HOST_VM_INFO == 2 && HOST_VM_INFO_REV2_COUNT == 15, "VM flavor/count");
_Static_assert(sizeof(vm_statistics_data_t) == 60, "VM word buffer");
_Static_assert(offsetof(vm_statistics_data_t, free_count) == 0, "free first word");
_Static_assert(HOST_CPU_LOAD_INFO == 3 && HOST_CPU_LOAD_INFO_COUNT == 4, "CPU flavor/count");
_Static_assert(sizeof(host_cpu_load_info_data_t) == 16, "CPU word buffer");
_Static_assert(CPU_STATE_USER == 0 && CPU_STATE_SYSTEM == 1 &&
               CPU_STATE_IDLE == 2 && CPU_STATE_NICE == 3, "native CPU order");
_Static_assert(IF_NAMESIZE == 16, "interface name output buffer");

#define MATCH_FUNCTION(name, type) _Static_assert(_Generic(&(name), type: 1, default: 0), #name)
MATCH_FUNCTION(sysctlbyname, int (*)(const char *, void *, size_t *, void *, size_t));
MATCH_FUNCTION(mach_host_self, mach_port_t (*)(void));
MATCH_FUNCTION(host_statistics, kern_return_t (*)(host_t, host_flavor_t, host_info_t,
                                                mach_msg_type_number_t *));
MATCH_FUNCTION(host_page_size, kern_return_t (*)(host_t, vm_size_t *));
MATCH_FUNCTION(mach_timebase_info, kern_return_t (*)(mach_timebase_info_t));
MATCH_FUNCTION(mach_continuous_time, uint64_t (*)(void));
MATCH_FUNCTION(if_indextoname, char *(*)(unsigned int, char *));
