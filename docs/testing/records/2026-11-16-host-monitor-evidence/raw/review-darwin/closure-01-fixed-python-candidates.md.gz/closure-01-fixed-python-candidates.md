**DARWIN-P2-01: CLOSED — fixed interpreter candidates, r3 verification**

The original [notice](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/host-monitor-20261116/review-darwin/notice-01-unvalidated-python-path.md) and its failing provenance probe are preserved. This receipt supersedes its OPEN status for the exact repaired inputs below.

The parent repaired [darwin.rs:56](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/darwin.rs:56): selection considers only `/usr/bin/python3`, `/opt/homebrew/bin/python3`, and `/usr/local/bin/python3`, in that order, requiring a regular executable. The command executes the exact quoted `"$ks_python"` path with `-I -S -B`, and absence retains exit 66. Resource and ps Darwin platform dispatch now use fixed `/usr/bin/uname`; the existing Linux bodies retain their prior contract.

Independent evidence:

- The reviewer decoded the current Rust format string and executed only its shell selection prefix with an inert earlier PATH. It selected `/usr/bin/python3`, emitted no sentinel, exited 0 and reaped the owned shell. The native kernel collector was not invoked. See `fixed-python-selection-r1.{stdout,json}`.
- Parent workspace binary `bins/keelshell_session-r3`, SHA256 `9907eee3fb2ee6c1b933cefb9f278368c3838b7d958b6e2e7728f91fcb53a178`, was independently hashed before and after execution. Metadata agrees, and the independent `--list` equals the parent inventory byte for byte: 291 total tests, 45 Darwin names exactly matched against current source.
- The reviewer independently executed six selected r3 regressions: the new earlier-PATH selection case, generated command contract, two numeric-anchor df cases, the platform rate break and the loopback dispatch fixture. **6 passed / 0 failed / 0 ignored / 285 filtered**, exit 0. The new test executes selection only and bounds `/bin/sh` to 2 seconds, with kill/wait on deadline. TMPDIR was the allowed review directory.
- The unchanged core collector SHA is `a897b660f9ecde0feddca413f28d51338a68e87a90403aa799aaa80f74c00359`; previous independent collector risk results remain applicable to it.

Repair input SHA256:

| Source | SHA256 |
| --- | --- |
| monitor.rs | `f280c96f6d31ae3b4770f888ca077c02f32f05e908e018e7a6e83e74fca86ab8` |
| monitor/darwin.rs | `12d9f627caaec53c1ef43ef1a7dd7167c231afb443ec9d411df9fe8af646abfa` |
| monitor/darwin/tests.rs | `1f8e93c0e3c544f8273016fb270b97492c925d79659e466a6f21693dd9462372` |

Machine evidence: [verification-r3.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/host-monitor-20261116/review-darwin/verification-r3.json). Full argv, exits and output: `r3-narrow-regressions.{json,stdout}` and `r3-evidence-verification.{json,stdout}`.

**Boundary:** this is independent execution of a parent-built actual-workspace binary, not independent Rust recompilation. No Cargo/shared target access or native Darwin SSH runner was performed by this reviewer. Fixed path provenance does not attest remote interpreter installation ownership or grant cross-platform/native acceptance. DARWIN-P2-02 was still OPEN at this r3 checkpoint; its subsequent repair and closure are recorded in [closure-02](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/host-monitor-20261116/review-darwin/closure-02-portable-default-tests.md).

**Final r4 addendum:** monitor.rs now has SHA256 `7adb9395ff8db239e59fb0edf1a589a8d6d842d5c302556e5f6c0773ff9868b7`. Resource and ps platform detection use only fixed `/usr/bin/uname`, then `/bin/uname`, with `-f && -x`, quoted invocation and exit 66 when neither exists. This preserves the earlier fixed Python repair while covering the Linux bin-only layout. The reviewer independently ran the new bounded bin-only/missing shell test, earlier-PATH test and loopback dispatch regression from actual-workspace r4: **3 passed / 0 failed / 0 ignored / 289 filtered**. Binary SHA256 before and after is `d45b07a984babf9b767956c494e11fb2566168186655fa18fe6a1b70612751a3`; independent inventory equals the parent inventory (292 total, 45 Darwin). The exact final inputs match all eight entries in `candidate-inputs-r1.json`. See [verification-final-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/host-monitor-20261116/review-darwin/verification-final-r1.json) and `r4-narrow-regressions.{json,stdout}`. **DARWIN-P2-01 remains CLOSED on the final r4 input.**
