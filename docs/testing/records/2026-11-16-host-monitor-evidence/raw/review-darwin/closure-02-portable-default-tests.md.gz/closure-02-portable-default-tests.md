**DARWIN-P2-02: CLOSED — narrow main-entry guards, portable cases retained**

The original [notice](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/host-monitor-20261116/review-darwin/notice-02-non-posix-default-tests.md) and the three actual API-absence tracebacks are preserved. This receipt supersedes the original OPEN status for the repaired test source.

The parent added individual `@unittest.skipUnless(hasattr(signal, "SIGALRM") and hasattr(signal, "alarm"), ...)` guards at [test_darwin_monitor_collector.py:174](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_darwin_monitor_collector.py:174), lines 180 and 186. Only the three `collector.main()` cases receive this new guard. The existing POSIX `ChildTests` class guard remains; all ten Netstat cases and six portable capacity/wire cases remain unconditional.

Repaired script SHA256:
`a54e07b8d088bb47d240ead2882086767d3bad8a707b55a9047660a3fb1db582`.
The collector source is unchanged:
`a897b660f9ecde0feddca413f28d51338a68e87a90403aa799aaa80f74c00359`.

Independent checks:

- `python3 -I -S -B scripts/test_darwin_monitor_collector.py`: **30 run / 30 passed / 0 errors / 0 skipped**, exit 0, bounded and reaped. Evidence: `promoted-collector-suite-r2.{stderr,json}`.
- `portable_guard_probe.py` supplies a signal module lacking both APIs and `os.name="nt"` **before loading the actual test file**, so its real decorators are evaluated against the absent APIs. It then discovers the entire suite: **30 run / 16 passed / 14 skipped / 0 errors / 0 failures**. Exactly the three main-entry cases and eleven POSIX Child cases skip; all portable netstat/capacity/wire cases execute. Evidence: `non-posix-guard-repair-r2.{stdout,json}`.
- `python-signal-official-availability.stdout` independently fetched the official Python signal documentation and preserved its Unix availability declarations for SIGALRM and alarm. The initial web tool attempts returned no usable text; this bounded read-only HTTPS fetch supplied the source evidence.

The API-absence probe is a local simulation, **not native Windows acceptance**. It does not exercise Windows process lifecycle or Windows ABI. The repaired macOS run creates only owned, bounded child processes, and its temporary environment is the permitted review directory. No Cargo/shared target operations or project source edits were performed by the reviewer.
