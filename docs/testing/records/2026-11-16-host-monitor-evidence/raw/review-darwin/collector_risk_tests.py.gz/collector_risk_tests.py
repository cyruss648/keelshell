"""Reviewer-authored risks on the unchanged collector, never native acceptance."""

import ctypes as C
from pathlib import Path
import signal
import subprocess
import sys
import time
import types
import unittest
from unittest import mock

ROOT = Path("/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell")
SOURCE = ROOT / "crates/keelshell-session/src/monitor/darwin.py"
collector = types.ModuleType("review_darwin")
exec(compile(SOURCE.read_bytes(), str(SOURCE), "exec"), collector.__dict__)
HEADER = b"Name Mtu Network Address Ipkts Ierrs Ibytes Opkts Oerrs Obytes Coll\n"
LINK = b"en0 1500 <Link#4> a:b:c:d:e:f 10 0 123 20 0 456 0\n"
LOOP = b"lo0 16384 <Link#1> 10 0 999 20 0 888 0\n"


class Networks(unittest.TestCase):
    def test_link_totals_ignore_address_family_rows_and_keep_u64_precision(self):
        raw = HEADER + LINK.replace(b"123", b"18446744073709551615") + LOOP
        raw += b"en0 1500 192.0.2 192.0.2.1 10 - 123 20 - 456 -\n"
        raw += b"en0 1500 fe80::%en0 fe80::1%en0 10 - 123 20 - 456 -\n"
        self.assertEqual(collector.parse_netstat(raw),
                         [("en0", 4, 2**64 - 1, 456), ("lo0", 1, 999, 888)])

    def test_duplicate_link_indices_and_overflowing_counters_are_rejected(self):
        for raw in [HEADER + LINK + LINK.replace(b"en0", b"en1"),
                    HEADER + LINK.replace(b"123", b"18446744073709551616"),
                    HEADER + LINK.replace(b"<Link#4>", b"<Link#4294967296>"),
                    HEADER + LINK.replace(b"<Link#4>", b"<Link#0>")]:
            with self.subTest(raw=raw), self.assertRaises(collector.CollectionFailure):
                collector.parse_netstat(raw)

    def test_256_links_fit_but_257_and_oversize_raw_do_not(self):
        rows = [LINK.replace(b"en0", f"en{i}".encode()).replace(
            b"<Link#4>", f"<Link#{i + 1}>".encode()) for i in range(257)]
        self.assertEqual(len(collector.parse_netstat(HEADER + b"".join(rows[:256]))), 256)
        for raw in [HEADER + b"".join(rows), b"x" * (collector.MAX_CHILD_OUTPUT + 1)]:
            with self.assertRaises(collector.CollectionFailure):
                collector.parse_netstat(raw)

    @staticmethod
    def resolver(names):
        def resolve(index, buffer):
            if index not in names:
                return None
            name = names[index]
            buffer.raw = name.ljust(16, b"\0")
            return C.addressof(buffer)
        return types.SimpleNamespace(if_indextoname=resolve)

    def test_truncated_prefixes_resolve_to_distinct_full_kernel_names(self):
        raw = HEADER + LINK.replace(b"en0", b"longinter*")
        raw += LINK.replace(b"en0", b"longinter").replace(b"<Link#4>", b"<Link#5>")
        libc = self.resolver({4: b"longinterface1", 5: b"longinterface2"})
        with mock.patch.object(collector, "run_bounded", return_value=("ok", raw)):
            self.assertEqual(collector.collect_networks(libc),
                             [("longinterface1", 123, 456), ("longinterface2", 123, 456)])

    def test_failed_unterminated_mismatched_and_duplicate_kernel_names_are_rejected(self):
        for names, raw in [
            ({}, HEADER + LINK),
            ({4: b"x" * 16}, HEADER + LINK),
            ({4: b"en1"}, HEADER + LINK),
            ({4: b"en0", 5: b"en0"},
             HEADER + LINK + LINK.replace(b"<Link#4>", b"<Link#5>")),
        ]:
            with self.subTest(names=names):
                with mock.patch.object(collector, "run_bounded", return_value=("ok", raw)):
                    with self.assertRaises(collector.CollectionFailure):
                        collector.collect_networks(self.resolver(names))


class AbiAndOptionalData(unittest.TestCase):
    def test_local_ctypes_signatures_and_buffer_layouts(self):
        libc = collector.library()
        self.assertEqual((C.sizeof(collector.Timeval), collector.Timeval.tv_usec.offset,
                          C.sizeof(collector.Timebase)), (16, 8, 8))
        self.assertEqual(libc.host_statistics.argtypes,
                         [C.c_uint32, C.c_int, C.POINTER(C.c_int32), C.POINTER(C.c_uint32)])
        self.assertEqual(libc.host_page_size.argtypes, [C.c_uint32, C.POINTER(C.c_size_t)])
        self.assertEqual(libc.mach_continuous_time.restype, C.c_uint64)
        self.assertEqual(libc.if_indextoname.argtypes, [C.c_uint32, C.POINTER(C.c_char)])
        self.assertEqual(libc.if_indextoname.restype, C.c_void_p)

    def test_host_word_call_checks_exact_returned_count(self):
        def statistics(_host, _flavor, data, count):
            self.assertIsInstance(count._obj, C.c_uint32)
            C.cast(data, C.POINTER(C.c_uint32))[0] = 0xFFFFFFFF
            return 0
        libc = types.SimpleNamespace(host_statistics=statistics)
        self.assertEqual(collector.host_words(libc, 7, 2, 15)[0], 0xFFFFFFFF)
        def short(_host, _flavor, _data, count):
            count._obj.value -= 1
            return 0
        libc.host_statistics = short
        with self.assertRaises(collector.CollectionFailure):
            collector.host_words(libc, 7, 2, 15)

    def test_sysctl_call_is_read_only_and_rejects_incorrect_returned_size(self):
        def sysctl(key, data, length, new_data, new_length):
            self.assertEqual(key, b"hw.memsize")
            self.assertEqual((new_data, new_length), (None, 0))
            self.assertEqual(length._obj.value, 8)
            data._obj.value = 17179869184
            return 0
        libc = types.SimpleNamespace(sysctlbyname=sysctl)
        self.assertEqual(collector.sysctl_value(libc, b"hw.memsize", C.c_uint64()).value,
                         17179869184)
        def short(_key, _data, length, _new_data, _new_length):
            length._obj.value = 4
            return 0
        libc.sysctlbyname = short
        with self.assertRaises(collector.CollectionFailure):
            collector.sysctl_value(libc, b"hw.memsize", C.c_uint64())

    def test_optional_capacity_skip_failure_and_invalid_utf8(self):
        with mock.patch.object(collector, "run_bounded", side_effect=AssertionError):
            self.assertEqual(collector.collect_capacity(True), ("skipped", b""))
        for status in ["missing", "permission_denied", "timeout", "failed", "invalid_output"]:
            with mock.patch.object(collector, "run_bounded", return_value=(status, b"")):
                self.assertEqual(collector.collect_capacity(False), (status, b""))
        for raw in [b"\xff", b"bad\0df", b"bad\rdf"]:
            with mock.patch.object(collector, "run_bounded", return_value=("ok", raw)):
                self.assertEqual(collector.collect_capacity(False), ("invalid_output", b""))

    def test_renderer_matches_real_frame_fixture_and_exact_output_boundary(self):
        frame = (ROOT / "crates/keelshell-session/src/monitor/darwin/fixtures/schema1-skipped.txt").read_bytes()
        header = frame.split(b"\n@@KS:df@@\n", 1)[0].decode().splitlines()[1:]
        fields = [tuple(line.split("\t", 1)) for line in header
                  if not line.startswith(("df_status\t", "df_bytes\t"))]
        self.assertEqual(collector.render(fields, "skipped", b""), frame)
        empty_length = len(collector.render([], "ok", b""))
        payload_length = collector.MAX_OUTPUT - empty_length
        for _ in range(3):
            payload_length = collector.MAX_OUTPUT - empty_length - (len(str(payload_length)) - 1)
        self.assertEqual(len(collector.render([], "ok", b"x" * payload_length)), collector.MAX_OUTPUT)
        with self.assertRaises(collector.CollectionFailure):
            collector.render([], "ok", b"x" * (payload_length + 1))


class OwnedChildren(unittest.TestCase):
    def run_owned(self, code, **kwargs):
        actual = subprocess.Popen
        children = []
        def spawn(*args, **options):
            self.assertEqual(options["env"], collector.CHILD_ENV)
            self.assertEqual(options["cwd"], "/")
            self.assertEqual(options["stdin"], subprocess.DEVNULL)
            self.assertEqual(options["stderr"], subprocess.DEVNULL)
            child = actual(*args, **options)
            children.append(child)
            return child
        started = time.monotonic()
        try:
            with mock.patch.object(collector.subprocess, "Popen", side_effect=spawn):
                return collector.run_bounded(
                    [sys.executable, "-I", "-S", "-B", "-c", code], **kwargs)
        finally:
            self.assertLess(time.monotonic() - started, 2.0)
            self.assertTrue(children and all(child.returncode is not None for child in children))

    def test_output_flood_is_bounded_and_owned_child_is_reaped(self):
        result = self.run_owned("import os,time;os.write(1,b'x'*65536);time.sleep(5)", limit=1024)
        self.assertEqual(result, ("invalid_output", b""))

    def test_silent_timeout_is_bounded_and_owned_child_is_reaped(self):
        self.assertEqual(self.run_owned("import time;time.sleep(5)", seconds=0.1),
                         ("timeout", b""))

    def test_closed_stdout_still_has_a_bounded_exit_wait(self):
        self.assertEqual(self.run_owned("import os,time;os.close(1);time.sleep(5)", seconds=0.1),
                         ("timeout", b""))

    def test_child_failure_discards_stdout_and_private_stderr(self):
        self.assertEqual(self.run_owned("import sys;print('discard');sys.stderr.write('private');sys.exit(3)"),
                         ("failed", b""))

    def test_global_deadline_exception_still_reaps_owned_child(self):
        previous = signal.signal(signal.SIGALRM, collector.deadline)
        try:
            signal.setitimer(signal.ITIMER_REAL, 0.1)
            with self.assertRaises(collector.DeadlineExceeded):
                self.run_owned("import time;time.sleep(5)")
        finally:
            signal.setitimer(signal.ITIMER_REAL, 0)
            signal.signal(signal.SIGALRM, previous)


if __name__ == "__main__":
    unittest.main(verbosity=2)
