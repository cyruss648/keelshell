"""Sign the bounded source review and command ledger without project mutation."""

import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path("/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell")
OUT = ROOT / "work/host-monitor-20261116/review-darwin"
WORK = ROOT / "work/host-monitor-20261116"
freeze = json.loads((OUT / "source-sha256-final-r1.json").read_text())
verification = json.loads((OUT / "verification-final-r1.json").read_text())
for row in freeze["files"]:
    data = (ROOT / row["path"]).read_bytes()
    assert hashlib.sha256(data).hexdigest() == row["sha256"] and len(data) == row["bytes"]
candidate_data = Path(freeze["candidate_manifest"]).read_bytes()
assert hashlib.sha256(candidate_data).hexdigest() == freeze["candidate_manifest_sha256"]
candidate = json.loads(candidate_data)
for row in candidate["inputs"]:
    data = (ROOT / row["path"]).read_bytes()
    assert hashlib.sha256(data).hexdigest() == row["sha256"] and len(data) == row["bytes"]
assert (OUT / "final-baseline-r2.stdout").read_text().strip() == freeze["baseline"]
assert verification["open_findings"] == {"P0": 0, "P1": 0, "P2": 0, "P3": 0}
assert hashlib.sha256((WORK / "bins/keelshell_session-r4").read_bytes()).hexdigest() == verification["binary_sha256_before_and_after"]
records = []
for path in OUT.glob("*.json"):
    obj = json.loads(path.read_text())
    if isinstance(obj, dict) and {"label", "argv", "returncode", "reaped"} <= obj.keys():
        records.append(dict(obj, receipt_file=str(path)))
records.sort(key=lambda row: (row.get("started_utc", ""), row["label"]))
assert len({row["label"] for row in records}) == len(records)
assert all(row["cwd"] == str(ROOT) for row in records)
nonzero = [row["label"] for row in records if row["returncode"] != 0]
unreaped = [row["label"] for row in records if not row["reaped"]]
assert nonzero == ["finalization-source-guard-r1"] and not unreaped
bootstrap = json.loads((OUT / "bootstrap.json").read_text())
resume = json.loads((OUT / "resume-bootstrap.json").read_text())
top_total = len(records) + bootstrap["shell_commands"] + resume["shell_commands"] + 1
ledger = {
    "counting_unit": "Top-level review command/action counted once; not all OS execve calls. One shell pipeline is one action.",
    "recorded_command_receipts_before_this_generation": len(records),
    "recorded_nonzero": nonzero,
    "recorded_unreaped": unreaped,
    "bootstrap_shell_commands": bootstrap["shell_commands"],
    "bootstrap_exec_calls": bootstrap["exec_tool_calls"],
    "bootstrap_limit": "19 commands in 5 combined exit-zero streams; inner per-command exits were not recorded.",
    "resume_shell_actions": resume["shell_commands"],
    "resume_exec_calls": resume["exec_tool_calls"],
    "resume_limit": "Three context recovery commands have actual exit 0; no independent start/elapsed receipts.",
    "report_generation_commands": 1,
    "report_generation_receipt": str(OUT / "final-report-generation-r1.json"),
    "report_generation_note": "Counted here once; run.py writes its actual exit/time/reaped receipt after this script returns.",
    "top_level_review_commands_total": top_total,
    "nested_test_and_probe_children": "Excluded from top-level command total; bounded shell/collector children are recorded in the test/probe evidence. Tests are not counted as separate commands.",
    "web_tool_calls": 4,
    "web_tool_usable_text_responses": 0,
    "official_https_fetch_commands": 1,
    "official_https_fetch_included_in_recorded_commands": True,
    "cargo_commands": 0,
    "rust_compile_commands": 0,
    "clang_syntax_only_commands": 1,
    "native_darwin_ssh_runner_commands_by_reviewer": 0,
    "full_gate_commands_by_reviewer": 0,
    "git_commit_push_merge_commands": 0,
    "source_or_cargo_target_mutations_by_reviewer": 0,
    "commands": records,
}
(OUT / "command-ledger-final-r1.json").write_text(json.dumps(ledger, indent=2) + "\n")
sha_rows = "\n".join(
    f"| [{row['path']}]({row['absolute_path']}) | `{row['sha256']}` |"
    for row in freeze["files"]
)
stamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
report = f"""**Darwin 资源采集、解析与 session 集成：新非作者只读复核最终报告 r1**

签署时间：`{stamp}`。建议 **APPROVE（限定源码范围，full gate 待定）**。
开放发现明确为 **P0=0、P1=0、P2=0、P3=0**。
本轮累计发现 P0=0、P1=0、P2=2、P3=0；两个 P2 均已修复、独立窄验证并闭合。
本批准只覆盖下列 8 个精确文件及相关增量；full gate 必须随后绑定相同候选输入并通过，
才能形成工程合入结论。未签署 UI、真实 Darwin SSH runner、Linuxlab 或跨架构原生接受。

父 workdir 始终显式使用 `{ROOT}`。初始及最终 HEAD 读回均为
`{freeze['baseline']}`。已先读 RTK、AGENTS、HANDOFF、ADR 0143、测试 STRATEGY
及 SHARED_TARGET；Rust skill 验证建议按用户本次只读与唯一共享 target 约束执行。
本 reviewer 的文件写入全部位于 `{OUT}`，未修改项目源码、Cargo/target，
未执行 Cargo、Rust 编译、格式化、Clippy、提交、推送或真实 Darwin SSH runner。

**发现及闭合证据**

| 发现 | 原始触发、位置和影响 | 最终修复与独立验证 | 状态 |
| --- | --- | --- | --- |
| DARWIN-P2-01 | 原 darwin.rs:56–58 用 `command -v python3` 后执行裸 `python3`；较早 PATH wrapper 能在 Python 隔离参数生效前被选中，伪造采样或忽略约束。原 notice 保留旧源码、绝对位置、无害 sentinel 与内层 exit 66；不声称绕过 SSH 认证。 | [darwin.rs:56]({ROOT}/crates/keelshell-session/src/monitor/darwin.rs:56) 只选择三个固定绝对 Python 候选，要求 -f/-x，执行 quoted path；缺失仍 exit 66。独立执行实际 Rust 字符串的 selection 前缀，并从真实 workspace r3/r4 执行 earlier-PATH 回归，均通过。新平台分派也使用固定 uname 候选。 | **CLOSED**；[notice-01]({OUT}/notice-01-unvalidated-python-path.md)、[closure-01 含最终 r4 addendum]({OUT}/closure-01-fixed-python-candidates.md) |
| DARWIN-P2-02 | 新默认 Python 测试末尾三项未经 guard 调用 collector.main()，在缺少 Unix alarm API 时于 [darwin.py:329]({ROOT}/crates/keelshell-session/src/monitor/darwin.py:329) 抛 AttributeError，阻断 Windows 默认 Python 阶段。独立 API 缺失复现保留 3/3 errors。 | [测试文件:174]({ROOT}/scripts/test_darwin_monitor_collector.py:174)、180、186 仅给三项 main-entry 加 SIGALRM && alarm 可用性 guard；ChildTests POSIX guard 保留。最终本机 30/30；导入前 API 缺失 + os.name=nt 模拟 16 passed、14 skipped、0 errors，16 个 portable netstat/capacity/wire 用例全部执行。 | **CLOSED**；[notice-02]({OUT}/notice-02-non-posix-default-tests.md)、[closure-02]({OUT}/closure-02-portable-default-tests.md) |

旧 notice 的 OPEN 文本属于当时检查点，以上 closure 回执明确取代其状态。
初始失败证据、修复前通过的 macOS 30 用例，以及修复后结果均保留；未用后续通过覆盖旧失败。

**重点源码核对**

| 检查面 | 结论、实际证据与边界 |
| --- | --- |
| 本机公开 Apple ABI | 独立读取 SDK 公开 headers，12 项 SHA 与导入 ABI 证据一致。独立 C `-target arm64-apple-macos27.0 -fsyntax-only -fno-modules -Wall -Wextra -Werror` 通过：host/natural/integer/count 32 位、integer signed pointer、LP64 page size、timeval size16/偏移8、timebase size8、VM flavor2/count15/size60/free word0、CPU flavor3/count4 和 user/system/idle/nice、IF_NAMESIZE16、7 组原型。ctypes args/restype、返回 word count、sysctl returned size 和缓冲声明另有独立用例。 |
| ABI 接受范围 | 实机 arm64，macOS 27.2.1 / 26B131，SDK `/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX27.2.sdk`。仅本机 SDK/arm64 声明和布局证据。`intel_4k_pages_and_unit_timebase_are_supported` 是合成 parser 用例，不能证明 Intel 或任何跨架构原生接受。 |
| ticks、回绕、时间 | Mach CPU state 依内核命名与顺序重排；输入限制 u32，整数时基乘除用 u128 检查后再转浮点，拒绝零、溢出及不一致值。本机 mach_continuous_time header 明确休眠期间推进。32 位回绕/计数下降使 checked subtraction 失败并断开该 CPU rate，不推测扩展计数；boot/platform/非正时间改变均断段。 |
| 内存及不可用字段 | free_count × kernel page size，校验 sysconf/page 一致及 total 上界；拒绝旧 VM word 的 UINT32_MAX 饱和证据。free 不伪装 available/used；Darwin available/used/swap 未知，disk I/O 为 MissingData、iowait 未知。 |
| 实际 netstat 格式 | 固定 `/usr/sbin/netstat -ibn`，严格 header 与 Link 行尾 7 数字，Ibytes/Obytes 分别索引 2/5；不累计 IPv4/IPv6 行。精确 u64、重复 link index、if_indextoname 的缓冲/NUL/完整名称/展示前缀/重复名称、256/257 和原始 1 MiB 上界均核对；独立用例覆盖两个相同截短展示前缀的不同完整接口及名称解析失败。 |
| 固定命令和 Python 隔离 | Python 仅 `/usr/bin/python3`、`/opt/homebrew/bin/python3`、`/usr/local/bin/python3`，顺序固定、-f/-x、quoted path；`-I -S -B`、stdin 脚本。libSystem、netstat、df、Darwin ps 固定绝对路径；sysctl newp=None/len=0；子进程固定 env、cwd=/、stdin/stderr=DEVNULL。无 helper 文件写入、安装或提权。固定位置合同不额外证明远端安装所有权。 |
| 最终 uname 窄修 | [monitor.rs:60]({ROOT}/crates/keelshell-session/src/monitor.rs:60) 的资源前缀和 ps 分派只按 `/usr/bin/uname`、`/bin/uname` 选 -f/-x 候选，quoted invocation，缺全部 exit 66。独立 r4 bin-only/missing 回归通过，两个 shell 子用例各有 2s deadline/kill/wait；fixture 前缀随实际 case 调整。旧 Linux body 保持先前合同，本报告不扩大为 Linuxlab 验收。 |
| bounded 子进程 | 子输出 1 MiB、单命令 3s、收割 1s、主 alarm10s、session 截止和 combined 输出 2 MiB。独立实际 owned-child 风险覆盖洪泛、静默、提前 EOF、失败/private stderr 和 DeadlineExceeded 的 finally 收割。新 shell 回归各限 2s 并 kill/wait；测试 TMPDIR 固定本复核目录。未声称 OS 不可中断等待的原生覆盖。 |
| 严格 frame | 合计 stdout/stderr 严格 2 MiB；schema/platform/units、未知/重复字段及接口、无符号范围、有限浮点、UTF-8 byte length、df 长度、完成标记和尾部均核对。Rust 覆盖逐字节截断、重复/嵌入标记、u32/u64/u128 边界；独立 Python render 覆盖恰好 2 MiB 及超 1 byte。 |
| 可选 df 与数值锚修复 | 已审父针对真实 `/bin/df -Pk` 中 `map auto_home` source 空格增加的 bounded unique numeric-anchor parser：row8192/source1024/mount4096 bytes、512 filesystems。source 空格和 Unicode mount 保留，歧义候选/超长行拒绝；invalid df 独立降级 Capacity InvalidOutput，核心资源保留。两项新回归在真实 workspace r2/r3 预构建程序中均由 reviewer 执行通过。 |
| 缓存与 transport | Resources 仅对 UnsupportedPlatform/CommandMissing 负缓存；reset/revision/generation 防旧结果回填。optional df 缓存跳过不冒充新观测；Session 映射 Transport，Transport 被排除于 missing 负缓存。独立执行 6 项 capability 用例；真实 SSH 的缺失/恢复注入属于对应 runner。 |
| session rates 与 actions | 来源平台进入 Snapshot，platform/boot/非正远端间隔改变断开 CPU/network 连续 rate；network 使用远端 elapsed。Darwin ps 只读；inspect_process 仍拒绝非 Linux，Darwin ps 不创建私有 ProcessIdentity；socket/actions 与 UI 路由的原生接受由各自 reviewer 负责。 |

**本 reviewer 实际执行**

| 验证 | 实际结果 | 归属与解释 |
| --- | --- | --- |
| r2 真实 workspace 预构建风险组 | **55 passed / 0 failed / 0 ignored / 235 filtered** | 44 Darwin + 6 capabilities + 4 时间/rates + 1 loopback fixture |
| r3 修复风险组 | **6 passed / 0 failed / 0 ignored / 285 filtered** | 新 earlier-PATH、命令生成、两项 df、平台断段、loopback |
| r4 最终窄回归 | **3 passed / 0 failed / 0 ignored / 289 filtered** | earlier-PATH、bin-only/missing uname、loopback；`r4-narrow-regressions.{{json,stdout}}` |
| Rust 去重计数 | **64 次执行通过，57 个不同测试名** | 三轮重叠明确去重；其中 Darwin 45 名均实际执行过。未将 292 项库存冒充全量通过。 |
| 独立 collector 风险脚本 | **15 run / 15 passed** | 直接加载 SHA 未改变的实际 darwin.py；5 个实际 owned children 收割成功；`independent-collector-risks-r1.*` |
| promoted 最终 Python 文件 | **30 run / 30 passed / 0 skipped** | 修复后脚本实际执行，`promoted-collector-suite-r2.*`；修复前 30/30 是单列历史结果 |
| API 缺失修复验证 | **30 run：16 passed / 14 skipped / 0 errors / 0 failures** | 导入前替换 API/平台名，3 个 main-entry + 11 个 POSIX Child 跳过，portable16 全执行；**不是 Windows 原生运行** |
| 修复前 API 缺失复现 | **3 run / 3 errors**，probe exit0 | 成功复现原缺陷，不计作通过的产品测试 |
| SDK syntax-only / 原 PATH / 修复 selection | 各命令 exit0；原 PATH 内层 shell66 | 原 PATH probe 证明问题；修复 selection 只运行前缀、不运行内核 collector |
| source、候选、库存及导入校验 | **8 scope 文件、713 candidate 文件、68 作者证据、12 headers 零 mismatch** | 713 项只核 SHA/长度；其余 705 项未做源码审查。tracked `git diff --check` exit0，仅 whitespace 检查。 |

最终二进制：
`{WORK}/bins/keelshell_session-r4`，
SHA256 **`d45b07a984babf9b767956c494e11fb2566168186655fa18fe6a1b70612751a3`**，
40,236,032 bytes。执行前后 SHA 一致，与 `session-binaries-r4.json` 元数据相符。
独立 `--list` 与父库存逐 byte 一致：292 total，Darwin45 与当前源码逐名相符。
早期 r2 SHA `53d56e642071cdbec02f19427f6fbf1806aec4718ef8c577dcfbc8a3f9e1b727`，
r3 SHA `9907eee3fb2ee6c1b933cefb9f278368c3838b7d958b6e2e7728f91fcb53a178` 的证据均保留。
**这些是 reviewer 独立执行父提供的真实 workspace 二进制；没有独立 Rust 重编译。**
SHA/库存和父 build receipt 支持此测试边界，不替代完整构建来源或 full gate。

父侧结果仅作为明确归属的上下文：最新 monitor:: **81/81**（含45 Darwin），
真实 MacSSH r3 **6/6**；本 reviewer 未执行这些整组命令或该原生 runner。
父原 r1 monitor **76/1** 的旧 SNAPSHOT_SCRIPT fixture 比较失败、MacSSH r1 **5/1**
的首次 Unsupported 被误判为 cached typed error，均保留，后续修复不覆盖旧记录。
作者导入的 68 件证据按 manifest 独立核 SHA；其中 standalone Rust stub42/42、
作者 Python30/30 和本机 collector/df 原始失败不计为本 reviewer 的 workspace/SSH
原生验收。导入旧 collector_tests.py 未原地改写或以失效相对 ROOT 误运行。

**最终 sourceSHA 与候选绑定**

| 复核文件 | SHA256 |
| --- | --- |
{sha_rows}

本表的机器清单为
[source-sha256-final-r1.json]({OUT}/source-sha256-final-r1.json)。
候选文件 [candidate-inputs-r1.json]({WORK}/candidate-inputs-r1.json) 共713项：
父 aggregate 字段读回 **`66936ab5115a3abe55ef6e9bd8e460f8bf4b9462252d249a028f35d10c9b5740`**；
manifest 文件自身独立 SHA256 为
`86db0ba0043d2431db04458404451d0e71a97035c4f523da4f01bcfa130eeddb`。
独立复算全部713项文件内容 SHA/bytes，0差异；本轮8项逐一匹配。
未重算父 aggregate 算法，不把该字段读回冒充独立 aggregate 计算。
finalize 时再次核对源文件及713项内容，防止并行修改后的旧输入签署。
完整绑定见 [verification-final-r1.json]({OUT}/verification-final-r1.json)。

**实际命令账本**

本报告生成前有 argv/cwd/exit/reaped 记录的顶层命令 **{len(records)}** 条；
非零 **{len(nonzero)}** 条、未收割 **{len(unreaped)}** 条。唯一非零是报告源漂移保护
`finalization-source-guard-r1` exit2：父正在修 PATH 时旧报告生成被主动阻止，
没有签署旧报告；不是测试失败。其开始时间/耗时未由 wrapper 捕获，回执未补造。
引导阶段另 **19** 条 shell 命令、5次组合 exec 最终均exit0，
未伪造19条内部单独退出；context 恢复另 **3** 条顶层 shell 动作，实际exit0，
无逐条 start/elapsed 回执。本报告生成再 **1** 条，合计 **{top_total}** 条。
按顶层审计动作/argv 计数，一条 pipeline 算一个动作，不是操作系统全部 execve 数；
wrapper 与其受测 argv 不重复计数，测试用例和内部 owned subprocess 不混入命令总数。
本次生成的实际回执由 wrapper 随后写到 `final-report-generation-r1.json`。

另有4次 web 工具尝试未返回可用文本；一次有界官方 Python signal 文档 HTTPS
读取已包含在上述命令数。Cargo=0、Rust编译=0、clang syntax-only=1、
真实Darwin SSH runner=0、full gate=0、提交/推送/merge=0。
详细 argv/退出及计数口径见
[command-ledger-final-r1.json]({OUT}/command-ledger-final-r1.json)。

**批准条件与未验范围**

两个已知复核发现已在该候选关闭，允许父启动最终 full gate；本批准不以继续等待该门禁
代替源码判断。full gate 仍 **PENDING**，须在相同候选输入上绑定成功回执；
相关文件漂移需要重新核对并更新绑定。本 reviewer 未签 full gate 的 fmt/Clippy、
全 workspace 构建/测试、依赖策略或原生桌面接受。
UI/真实Darwin runner、Linuxlab 保持各自 reviewer 责任。
本机 SDK/macOS arm64 证据和 API 缺失模拟不支持 Intel、Windows 或其他架构原生接受，
也不证明真实系统压力下每一种权限、挂起或内核错误均已运行覆盖。
"""
report_path = OUT / "report-final-r1.md"
assert not report_path.exists()
report_path.write_text(report)
print(json.dumps({
    "report": str(report_path),
    "report_sha256": hashlib.sha256(report.encode()).hexdigest(),
    "recommendation": "APPROVE - source scope only, full gate pending",
    "open_findings": verification["open_findings"],
    "closed_P2": 2,
    "recorded_command_receipts_before_generation": len(records),
    "top_level_review_commands_total": top_total,
    "candidate_scope_matches": True,
    "source_drift": [],
}, indent=2))
