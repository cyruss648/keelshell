"""Write the source review and exact command ledger inside the allowed folder."""

import datetime
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path("/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell")
OUT = ROOT / "work/host-monitor-20261116/review-darwin"
freeze = json.loads((OUT / "source-sha256-r1.json").read_text())
drift = [row["path"] for row in freeze["files"]
         if hashlib.sha256((ROOT / row["path"]).read_bytes()).hexdigest() != row["sha256"]]
if drift:
    print(json.dumps({"source_drift_requires_followup": drift}))
    raise SystemExit(2)
records = []
for path in OUT.glob("*.json"):
    obj = json.loads(path.read_text())
    if isinstance(obj, dict) and {"label", "argv", "returncode", "reaped"} <= obj.keys():
        records.append(obj)
records.sort(key=lambda row: row["started_utc"])
bootstrap = json.loads((OUT / "bootstrap.json").read_text())
ledger = {
    "recorded_commands": len(records), "recorded_nonzero": [
        row["label"] for row in records if row["returncode"] != 0],
    "recorded_unreaped": [row["label"] for row in records if not row["reaped"]],
    "bootstrap_exec_tool_calls": bootstrap["exec_tool_calls"],
    "bootstrap_shell_commands": bootstrap["shell_commands"],
    "bootstrap_per_command_exitcodes": "not individually recorded; five combined streams exit 0",
    "report_generation_commands": 1,
    "top_level_commands_total": len(records) + bootstrap["shell_commands"] + 1,
    "nested_owned_popen_launches": {
        "inert_path_probe_shell": 1, "collector_risk_test_children": 5,
        "excluded_from_top_level_total": True,
    },
    "web_tool_calls": 2, "web_usable_sources_returned": 0,
    "cargo_commands": 0, "rustc_commands": 0, "native_ssh_runner_commands": 0,
    "clang_syntax_only_commands": 1,
    "baseline": freeze["baseline"], "final_source_drift": drift, "commands": records,
}
(OUT / "command-ledger-r1.json").write_text(json.dumps(ledger, indent=2) + "\n")
sha_rows = "\n".join(
    f"| [{row['path'].removeprefix('crates/keelshell-session/src/')}]" 
    f"({row['absolute_path']}) | `{row['sha256']}` |"
    for row in freeze["files"]
)
stamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
report = f"""**Darwin 资源采集、严格解析和 session 集成：新非作者只读复核 r1**

签署时间：`{stamp}`。建议 **REQUEST_CHANGES**。
开放发现：**P0=0，P1=0，P2=1，P3=0**。
本结论仅针对以下精确文件和增量，不包含 UI、真实 Darwin SSH runner、
Linuxlab、跨架构原生或完整产品验收。完整门禁保持 PENDING；
待已知 P2 关闭并经窄差分复核后，可保留相同最终输入的完整门禁待定条件批准。

父 workdir 始终显式为
`{ROOT}`，HEAD 初始和最终读回均为基线
`539c172389b4450570026f023ff89d50df90f910`。
已先读 RTK、AGENTS、HANDOFF 当前批次、ADR 0143、测试 STRATEGY 和 SHARED_TARGET。
所有复核文件只写于 `{OUT}`。没有修改项目源码、Cargo/target，没有执行
Cargo、Rust 编译、格式化、提交、推送或真实 Darwin SSH runner。
Rust skill 的验证建议以用户本次只读和共享 target 约束为准。

**开放发现：DARWIN-P2-01，未验证的 PATH 解释器选择。**

位置：
[darwin.rs:56]({ROOT}/crates/keelshell-session/src/monitor/darwin.rs:56)
至 58 行；调用：
[monitor.rs:527]({ROOT}/crates/keelshell-session/src/monitor.rs:527)
至 532 行。`command -v python3` 只确认可解析，随后的裸 `python3`
仍会执行 PATH 中较早的同名 wrapper，未验证或固定绝对路径。
在认证用户 PATH 前部存在这种条目时，`-I -S -B` 尚未获得真正 Python 的解释；
wrapper 可以忽略参数或伪造合法采样帧，破坏本次要求的受信固定绝对命令边界。
这不等同于绕过 SSH 认证，也不声称能够使恶意主机可信。

无害复现把只打印固定 sentinel 并返回 66 的 executable 放入本复核目录，
使用当前启动器同样的检查、参数和原 collector stdin 正文。
实际 stdout 为 `REVIEW_UNTRUSTED_PATH_SELECTED\\n`，shell exit 66，已 wait/reap；
因此真实 collector 未执行。probe 本身因成功验证该条件而 exit 0。
证据为 [path-interpreter-probe-r1.stdout]({OUT}/path-interpreter-probe-r1.stdout)。
建议使用明确受信的固定绝对解释器候选或已审核绝对路径合同，
执行该精确引用路径，并加入 earlier-PATH wrapper 的回归；
新 Darwin 分派的 `uname` 也应固定系统路径。
缺失解释器的 typed reason、负缓存和显式 reset 行为须保留。
阻塞发现已立即落盘
[notice-01]({OUT}/notice-01-unvalidated-python-path.md)，原始 notice 保留。

**其余重点核对结果。**

| 检查面 | 本轮结论和证据 |
| --- | --- |
| Apple ABI 与 ctypes | 独立读取当前本机公开 SDK 的 12 个 header，逐项 SHA 与导入证据一致。独立 C `-fsyntax-only -fno-modules -Wall -Wextra -Werror` 静态断言通过：32 位 host/word/count、signed integer pointer、LP64 page size、16 字节 timeval/偏移 8、8 字节 timebase、VM 15 words、CPU 4 words 和顺序、16 字节 if-name，以及 7 组函数原型。Python 实际声明与缓冲布局另经独立用例核对。 |
| ABI 接受边界 | 当前设备 `arm64`、macOS `27.2.1 / 26B131`、SDK `MacOSX27.2.sdk`。这是局部 ABI 和声明证据；未交叉编译、未运行 Intel/Windows/Linux 原生 ABI。名为 `intel_4k_pages_and_unit_timebase_are_supported` 的合成 parser 用例只验证输入模型，不能签 Intel 原生。 |
| Mach ticks 与时间 | 按 user/system/idle/nice 内核顺序命名传输并重排到模型；tick 按 u32 接受，u128 检查整数时基乘除；拒绝零、溢出、不一致值。`mach_continuous_time` 的本机 header 明确休眠期间推进。速率使用正向远端间隔；32 位回绕/计数下降以 checked subtraction 断开 CPU 值，不发明延续计数。 |
| 内存、缺失值 | free_count × kernel page size，并与 sysconf/page 对齐和 total 上限交叉验证。拒绝旧 VM UINT32_MAX 饱和值。Darwin available/used/swap 均未知，disk I/O 为 MissingData，iowait 不产生伪 0。 |
| netstat 字段 | 固定 `/usr/sbin/netstat -ibn`；严格 header 和 link 行尾 7 个数字，Ibytes/Obytes 分别取索引 2/5。IPv4/IPv6 地址族行不累计；重复 link index、重复解析后名称、计数溢出、超 256 接口和超 1 MiB 原始输出被拒绝。if_indextoname 按索引解析截短展示名并检查 NUL、完整名、前缀和重复。独立新增风险用例包含同展示前缀的两个不同完整名字及失败/未终止/不匹配名称。 |
| 固定命令、隔离、读写 | libSystem、netstat、df、Darwin ps 均固定绝对路径；子命令环境固定、cwd=/、stdin/stderr=DEVNULL、close_fds。Python 采用 -I -S -B、stdin 脚本、不写 helper 文件、sysctl newp=None/len=0，不安装、不提权、不读取进程环境。启动器的 PATH 风险见唯一开放 P2，不能被这些下游约束抵消。 |
| 子进程边界 | 最大子输出 1 MiB、单子进程 3s、收割 1s、主 alarm 10s、session 另有截止和 combined stdout/stderr 2 MiB。独立真实子进程用例验证洪泛、静默、提前 EOF、失败和全局 DeadlineExceeded 的 finally 收割；只作用于该调用持有的 Popen。未声称覆盖 OS 不可中断内核等待。 |
| 严格 frame | stdout+stderr 合计 2 MiB；严格 schema/platform/units、单字段和接口去重、未知字段、整数/浮点、UTF-8 边界、精确 df 字节长度、完成标记和尾部检查。测试涵盖逐字节截断、重复/嵌入标记、非有限值和 u64/u32/u128 边界。Python render 另独立检查恰好 2 MiB 和超 1 字节。 |
| 可选 df 与父窄修 | 父发现本机真实 source `map auto_home` 包含空格，原 first-columns 假设会 InvalidOutput。已审新增 bounded unique numeric-anchor parser：行 8192 bytes、source 1024、mount 4096、总 filesystem 512；source 空格和 Unicode mount 保留，多个数值候选/超长行拒绝。歧义或非法 df 仅使容量 InvalidOutput，保留核心计数。两项新增回归已在真实 workspace 预构建二进制中独立执行通过。 |
| 缓存与 transport | Resources 仅对 UnsupportedPlatform/CommandMissing 提前返回，明确 reset 清零并撤销旧 generation/revision；optional df 负缓存跳过后不伪刷新旧 checked_at。Session error 映射 Transport，cached_reason 排除 Transport，不能成为 CommandMissing。独立执行既有 6 项 capability 测试；未独立执行真实 SSH 的缺失/恢复故障注入，留给对应 runner。 |
| 跨平台与 Linux actions | Snapshot 标记来源平台，rates_since 在 platform/boot/非正时间改变时拒绝连续 CPU/network 值，Darwin iowait 未知。读取 ps 的 Darwin 分支为只读；inspect_process 仍先拒绝非 Linux，私有 ProcessIdentity 不由 Darwin ps 创建；socket 分派仍拒绝 Darwin。UI 和真实操作路由验收由另一 reviewer 负责。 |

**本轮实际验证与来源。**

父提供的真实 workspace 预构建二进制：
`{ROOT}/work/host-monitor-20261116/bins/keelshell_session-r2`，
SHA256 `53d56e642071cdbec02f19427f6fbf1806aec4718ef8c577dcfbc8a3f9e1b727`，
40,533,600 bytes。执行前后均核对摘要，独立 `--list` 与父清单逐字节一致：
290 项库存，其中 44 个 Darwin 名与当前源码的 44 项逐名相符。
元数据来自 `integrated-binaries-r2.json`，父真实 workspace build receipt exit 0；
源码 r2 到 r3 摘要零漂移。**本 reviewer 未独立重编译**，
库存和 build receipt 不能替代完整编译来源证明；最终工程门禁仍须父在相同最终
输入上绑定成功回执。

| reviewer 自己执行 | 结果 | 计数说明 |
| --- | --- | --- |
| r2 binary `--list` | exit 0 | 只列库存，不计测试通过 |
| 选定 Rust 风险组 | **55 passed / 0 failed / 0 ignored / 235 filtered**，exit 0、reaped | 44 Darwin + 6 capabilities + 4 rates/time + 1 已修 fixture 的 loopback 回归；55 个名字唯一 |
| 独立 collector 风险脚本 | **15 run / 15 passed / 0 failed**，exit 0、reaped | 直接加载当前 darwin.py；五个 owned 实际子进程均退出并收割，其余为解析/ABI/可选数据边界 |
| 本机 arm64 SDK 静态断言 | exit 0、reaped | 一次 C syntax-only，未输出 object/target |
| PATH provenance 无害复现 | probe exit 0；内层 shell 66 | 证明问题存在，不是修复通过 |
| 基线、范围摘要、库存、导入证据校验 | exit 0 | 7 项 source、68 项作者证据、12 项 SDK header 零 mismatch |
| tracked 范围 `git diff --check` | exit 0 | 仅 whitespace 只读检查，不代表 rustfmt/Clippy/full gate |

父 r1 旧监控结果为 76 passed / 1 failed，
原因是 fixture 对旧 SNAPSHOT_SCRIPT 做完全相等比较，不识别新增 case 分派；
父已修改 fixture，r2 79/79 是父结果，未冒充本 reviewer 运行。
作者 68 件证据已按导入 manifest 独立复算摘要，零 mismatch。
其中 standalone Rust stub 的 42/42、本机 kernel collector 和真实 df 的原始失败
保持各自事实；reviewer 未运行作者 stub，也不将其计作 workspace 或 SSH/native 验收。
imported `collector_tests.py` 使用原作者相对 ROOT，未原地改写或直接误运行该迁移路径。

**精确 sourceSHA 清单。**

范围共 7 个文件（5 个作者导入文件，另有父 monitor/capabilities 集成）。
相对首次 r1，r2 仅 monitor fixture、darwin.rs 容量解析及 darwin/tests.rs 两项回归
变化；本报告采用 r2/r3 相同内容。文件全文与差分、初始摘要均保留。

| 文件 | SHA256 |
| --- | --- |
{sha_rows}

机器可读清单：
[source-sha256-r1.json]({OUT}/source-sha256-r1.json)；
SDK 清单：
[sdk-sha256-r1.json]({OUT}/sdk-sha256-r1.json)；
库存和导入核对：
[verification-r1.json]({OUT}/verification-r1.json)。

**实际命令计数。**

有完整独立 argv/cwd/exit/reaped 回执的顶层命令 **{len(records)}** 条，
非零 **{len(ledger['recorded_nonzero'])}**，未收割 **{len(ledger['recorded_unreaped'])}**。
启用记录器之前另有 **19** 条引导只读 shell 命令，分为 **5** 次 exec；
这五次组合输出的最终 exit 均为 0，未伪造每条内部命令的独立退出回执。
本报告生成另 **1** 条顶层命令，故顶层命令共 **{ledger['top_level_commands_total']}** 条。
内层受测 Popen 启动另外记账：5 个风险子进程、1 个 PATH probe shell；
不把它们混入顶层命令数，也不把 55 项测试算成 55 条命令。
另有 2 次辅助 web 调用，未返回可用来源；ABI 结论只依赖本机公开 SDK。
Cargo=0、Rust 编译=0、真实 Darwin SSH runner=0、clang syntax-only=1。
完整 argv 和退出信息见
[command-ledger-r1.json]({OUT}/command-ledger-r1.json)。

本报告是当前冻结输入的非作者源码/风险复核，未签署 UI、真实 Darwin SSH、
Linuxlab、跨架构、Clippy/fmt/full gate、原生桌面或完整产品接受。
开放 P2 尚未关闭，因此当前不作条件 APPROVE；已知源码发现关闭后的完整门禁待定
可以作为后续限定批准的明确条件。
"""
(OUT / "report-r1.md").write_text(report)
print(json.dumps({
    "report": str(OUT / "report-r1.md"),
    "recommendation": "REQUEST_CHANGES",
    "open_findings": {"P0": 0, "P1": 0, "P2": 1, "P3": 0},
    "recorded_commands": len(records),
    "top_level_commands_total": ledger["top_level_commands_total"],
    "source_drift": drift,
    "report_sha256": hashlib.sha256(report.encode()).hexdigest(),
}, indent=2))
