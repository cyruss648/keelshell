"""Decode the actual Rust format string and check its shell selection only."""

import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path("/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell")
OUT = ROOT / "work/host-monitor-20261116/review-darwin"
path = ROOT / "crates/keelshell-session/src/monitor/darwin.rs"
source = path.read_text()
literal = re.search(r'format!\(\s*"((?:\\[\s\S]|[^"\\])*)"', source).group(1)
literal = re.sub(r"\\\n\s*", "", literal)
template = json.loads('"' + literal + '"')
selection, invocation = template.split('\n"$ks_python" -I -S -B - ', 1)
assert "command -v python3" not in selection
assert "for ks_candidate in /usr/bin/python3 /opt/homebrew/bin/python3 /usr/local/bin/python3; do" in selection
assert invocation.startswith("{} ")
fake_dir = OUT / "inert-path-probe"
result = subprocess.run(
    ["/bin/sh", "-c", selection + "\nprintf '%s\\n' \"$ks_python\""],
    cwd=ROOT, env={"PATH": str(fake_dir)},
    stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=2,
)
candidates = ["/usr/bin/python3", "/opt/homebrew/bin/python3", "/usr/local/bin/python3"]
expected = next((item for item in candidates if Path(item).is_file() and os.access(item, os.X_OK)), None)
if expected:
    assert result.returncode == 0 and result.stdout == (expected + "\n").encode()
else:
    assert result.returncode == 66 and result.stdout == b""
assert b"REVIEW_UNTRUSTED_PATH_SELECTED" not in result.stdout
monitor = (ROOT / "crates/keelshell-session/src/monitor.rs").read_text()
assert 'case \\"$(/usr/bin/uname -s)\\" in' in monitor
assert 'case "$(/usr/bin/uname -s)" in' in monitor
print(json.dumps({
    "parser_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
    "decoded_current_rust_format_string": True,
    "executed_selection_prefix_only": True,
    "kernel_collector_executed": False,
    "earlier_path_entry_executed": False,
    "expected_candidate": expected, "returncode": result.returncode,
    "stdout": result.stdout.decode(), "stderr": result.stderr.decode(),
    "owned_shell_reaped": True, "fixed_uname_dispatch_verified": True,
}, indent=2))
