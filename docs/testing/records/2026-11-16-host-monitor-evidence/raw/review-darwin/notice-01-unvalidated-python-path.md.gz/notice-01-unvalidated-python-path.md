# DARWIN-P2-01: Darwin Python launcher executes an unvalidated PATH entry

Status: OPEN. Severity: P2. Recommendation for the current source: REQUEST_CHANGES.

Baseline: `539c172389b4450570026f023ff89d50df90f910`.
Current `darwin.rs` SHA256:
`9cd458e785b46933b77b7fe0208d58612111d05f5b5bd56c54fef9e35ef0adaf`.

Location:
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/darwin.rs:56-58`.
The containing session dispatch is
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor.rs:527-532`.

Trigger: the authenticated remote shell's PATH contains a directory before the
intended interpreter that supplies its own executable named `python3` (including
a relative/current-directory entry). `command -v` only establishes resolvability;
the following bare `python3` invocation selects that executable without validating
or fixing its absolute path.

Impact: `-I -S -B` protects interpreter startup only after a real interpreter is
selected. An arbitrary wrapper selected first can ignore those flags, execute
other operations, or emit a fabricated valid resource frame. Thus the new Darwin
collector does not meet the requested fixed trusted absolute command boundary,
even though its netstat, df, ps and libSystem paths are fixed. This is not a claim
of bypassing SSH authentication or of a malicious host becoming trustworthy.

Evidence: the inert reproduction in `path_probe.py` uses the current launcher's
same checks/options and the unmodified collector body. It places an executable
that only prints `REVIEW_UNTRUSTED_PATH_SELECTED` and exits 66 in a directory
inside this review folder. Running the launcher with that directory first in
PATH prints the sentinel and exits 66, proving that the actual Python collector
was not invoked. The probe itself exits 0, its shell child was waited/reaped,
and no project source or Cargo/target file was changed.

Recorded result: `path-interpreter-probe-r1.stdout` and
`path-interpreter-probe-r1.json`. This is a local inert launch-contract
reproduction, not a native Darwin SSH acceptance run.

Suggested fix: select the interpreter from an explicitly trusted, fixed absolute
candidate list appropriate for supported installations, or an already reviewed
absolute interpreter contract, then execute that exact quoted path. Do not accept
an arbitrary PATH resolution as trusted. Add a regression with an inert earlier
PATH entry and preserve the explicit missing-interpreter/cache/reset behavior.
The `uname` selector for the new Darwin dispatch should also use its fixed
system path so that platform provenance is not selected by an earlier wrapper.

The independently executed parent r2 binary passed 55 selected tests, including
the 44 Darwin parser cases and both new df regressions. Those tests do not cover
interpreter path provenance and do not close this finding.
