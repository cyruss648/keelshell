# DARWIN-P2-02: New default tests call Unix-only alarm APIs without a guard

Status: OPEN. Severity: P2.

Source:
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_darwin_monitor_collector.py:174-186`.
Default discovery:
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/check.py:73`.
The called implementation accesses signal.SIGALRM before its try block:
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/darwin.py:328-330`.

Trigger: the normal Python discovery runs on Windows. Only ChildTests has a
POSIX guard (test file lines 71-72). CapacityAndWireTests is unconditional, and
its last three tests call collector.main(). Mocking sys.platform or library()
does not avoid the initial signal.signal(signal.SIGALRM, ...) call.

Impact: those three new default tests raise AttributeError because Windows
does not provide signal.SIGALRM/alarm. Thus adding this suite to the default
cross-platform gate makes the Windows Python stage fail independently of Rust
or native UI behavior.

Evidence: read the exact source and Python's official signal documentation,
whose SIGALRM and alarm entries declare Unix availability. The independently
executed `windows_alarm_probe.py` runs the same three test methods against a
signal API lacking SIGALRM: all three raise AttributeError at darwin.py:329.
`windows-alarm-api-absence-r1.stdout` preserves all three tracebacks;
`windows-alarm-api-absence-r1.json` records the successful reproduction command,
exit 0, bounded and reaped. Tested script SHA256:
`ce58f022a4699336e4eebbd3423989e7274623ec066ef3a2b0552758593b5339`.
The same script independently passes 30/30 on the current macOS host
(`promoted-collector-suite-r1.stderr`), which does not address the missing API.
The API-absence probe is not a Windows execution or cross-architecture
acceptance.

Suggested fix: guard these three main-entry tests on availability of the Unix
alarm APIs, or patch the alarm interface explicitly when testing only the
return-code/diagnostic contract. Preserve all portable parser/wire tests in the
default gate. Do not skip the entire useful portable suite.

Official source consulted:
`https://docs.python.org/3/library/signal.html#signal.SIGALRM`
and its signal.alarm entry.
