"""Inert reproduction of the new launcher's unvalidated PATH interpreter."""

import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path("/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell")
OUT = ROOT / "work/host-monitor-20261116/review-darwin"
parser = ROOT / "crates/keelshell-session/src/monitor/darwin.rs"
source = ROOT / "crates/keelshell-session/src/monitor/darwin.py"
assert "command -v python3 >/dev/null 2>&1 || exit 66" in parser.read_text()
assert "python3 -I -S -B - {} 2>/dev/null <<'KS_DARWIN_PY'" in parser.read_text()
fake_dir = OUT / "inert-path-probe"
fake_dir.mkdir(exist_ok=True)
fake = fake_dir / "python3"
fake.write_text("#!/bin/sh\nprintf 'REVIEW_UNTRUSTED_PATH_SELECTED\\n'\nexit 66\n")
fake.chmod(0o700)
launcher = (
    "LC_ALL=C; export LC_ALL\n"
    "command -v python3 >/dev/null 2>&1 || exit 66\n"
    "python3 -I -S -B - 1 2>/dev/null <<'KS_DARWIN_PY'\n"
    + source.read_text() + "\nKS_DARWIN_PY\n"
)
result = subprocess.run(
    ["/bin/sh", "-c", launcher], cwd=ROOT,
    env=dict(os.environ, PATH=str(fake_dir) + ":/usr/bin:/bin:/usr/sbin:/sbin"),
    stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=5,
)
print(json.dumps({
    "parser_sha256": hashlib.sha256(parser.read_bytes()).hexdigest(),
    "collector_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
    "launcher": "Same Darwin script body and options; no SSH or native collector execution",
    "returncode": result.returncode,
    "stdout": result.stdout.decode(), "stderr": result.stderr.decode(),
    "owned_child_reaped": True,
    "source_or_target_changes": False,
    "inert_executable": str(fake),
}, indent=2))
assert result.returncode == 66
assert result.stdout == b"REVIEW_UNTRUSTED_PATH_SELECTED\n"
