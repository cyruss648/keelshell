"""Load the actual promoted suite with absent alarm APIs before decorators run."""

import contextlib
import ctypes
import hashlib
import io
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import types
import unittest
from unittest import mock

ROOT = Path("/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell")
source = ROOT / "scripts/test_darwin_monitor_collector.py"
os_proxy = types.ModuleType("os")
os_proxy.__dict__.update(vars(os))
os_proxy.name = "nt"
signal_proxy = types.ModuleType("signal")
signal_proxy.__dict__.update({
    key: value for key, value in vars(signal).items()
    if key not in {"SIGALRM", "alarm"}
})
module = types.ModuleType("review_portable_collector_tests")
module.__file__ = str(source)
stream = io.StringIO()
with mock.patch.dict(sys.modules, {"os": os_proxy, "signal": signal_proxy}):
    exec(compile(source.read_bytes(), str(source), "exec"), module.__dict__)
    suite = unittest.defaultTestLoader.loadTestsFromModule(module)
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
main_names = {
    "test_platform_failure_emits_no_untrusted_diagnostic",
    "test_core_failure_emits_no_untrusted_diagnostic",
    "test_missing_required_netstat_uses_missing_command_exit",
}
skipped = [test.id() for test, _reason in result.skipped]
assert result.wasSuccessful() and result.testsRun == 30
assert len(skipped) == 14
assert sum(".ChildTests." in name for name in skipped) == 11
assert {name.rsplit(".", 1)[-1] for name in skipped
        if ".CapacityAndWireTests." in name} == main_names
assert all(".NetstatTests." not in name for name in skipped)
assert "Ran 30 tests" in stream.getvalue()
print(json.dumps({
    "test_source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
    "boundary": "Simulation of absent SIGALRM/alarm and os.name=nt before test import; not native Windows execution",
    "tests_run": result.testsRun,
    "passed": result.testsRun - len(result.skipped),
    "errors": len(result.errors), "failures": len(result.failures),
    "skipped": skipped,
    "portable_netstat_and_capacity_wire_tests_still_run": True,
    "trace": stream.getvalue(),
}, indent=2))
