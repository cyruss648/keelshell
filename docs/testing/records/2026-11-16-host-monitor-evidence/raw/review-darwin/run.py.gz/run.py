"""Record bounded read-only review commands; outputs stay in this directory."""

import datetime
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path("/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell")
OUT = ROOT / "work/host-monitor-20261116/review-darwin"
label = sys.argv[1]
args = sys.argv[2:]
timeout = 45
if args[:1] == ["--timeout"]:
    timeout = int(args[1])
    args = args[2:]
if args[:1] == ["--"]:
    args = args[1:]
if not args or "/" in label or (OUT / f"{label}.json").exists():
    raise SystemExit("require unique label and command")
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
clock = time.monotonic()
env = dict(os.environ, GIT_OPTIONAL_LOCKS="0", PYTHONDONTWRITEBYTECODE="1", TMPDIR=str(OUT))
process = subprocess.Popen(
    args, cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    start_new_session=True,
)
timed_out = False
try:
    stdout, stderr = process.communicate(timeout=timeout)
except subprocess.TimeoutExpired:
    timed_out = True
    os.killpg(process.pid, signal.SIGKILL)
    stdout, stderr = process.communicate(timeout=10)
record = {
    "label": label, "argv": args, "cwd": str(ROOT), "started_utc": started,
    "elapsed_seconds": time.monotonic() - clock,
    "returncode": process.returncode, "timed_out": timed_out,
    "reaped": process.poll() is not None,
}
(OUT / f"{label}.stdout").write_bytes(stdout)
(OUT / f"{label}.stderr").write_bytes(stderr)
(OUT / f"{label}.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record))
sys.stdout.flush()
sys.stdout.buffer.write(stdout)
sys.stderr.buffer.write(stderr)
raise SystemExit(process.returncode if process.returncode >= 0 else 128 - process.returncode)
