"""Hash the exact review scope without reading Cargo outputs or changing source."""

import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path("/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell")
paths = [
    "crates/keelshell-session/src/monitor.rs",
    "crates/keelshell-session/src/monitor/capabilities.rs",
    "crates/keelshell-session/src/monitor/darwin.rs",
    "crates/keelshell-session/src/monitor/darwin.py",
    "crates/keelshell-session/src/monitor/darwin/tests.rs",
    "scripts/test_darwin_monitor_collector.py",
]
paths += sorted(str(p.relative_to(ROOT)) for p in
                (ROOT / "crates/keelshell-session/src/monitor/darwin/fixtures").rglob("*")
                if p.is_file())
files = []
for path in paths:
    data = (ROOT / path).read_bytes()
    files.append({
        "path": path, "absolute_path": str(ROOT / path),
        "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data),
        "lines": len(data.splitlines()),
    })
print(json.dumps({
    "recorded_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "baseline": "539c172389b4450570026f023ff89d50df90f910",
    "cwd": str(ROOT), "files": files,
}, indent=2))
