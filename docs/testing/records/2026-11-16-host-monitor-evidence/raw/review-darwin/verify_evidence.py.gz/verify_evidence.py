"""Verify reviewer receipts and source/binary inventories; no project mutation."""

import hashlib
import json
from pathlib import Path
import re

ROOT = Path("/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell")
OUT = ROOT / "work/host-monitor-20261116/review-darwin"
WORK = ROOT / "work/host-monitor-20261116"

freeze = json.loads((OUT / "source-manifest-r3.stdout").read_text())
previous = json.loads((OUT / "source-manifest-r2.stdout").read_text())
assert freeze["files"] == previous["files"]
assert all(hashlib.sha256((ROOT / row["path"]).read_bytes()).hexdigest() == row["sha256"]
           for row in freeze["files"])
(OUT / "source-sha256-r1.json").write_text(json.dumps(freeze, indent=2) + "\n")

binary = WORK / "bins/keelshell_session-r2"
expected_sha = "53d56e642071cdbec02f19427f6fbf1806aec4718ef8c577dcfbc8a3f9e1b727"
assert hashlib.sha256(binary.read_bytes()).hexdigest() == expected_sha
actual_inventory = (OUT / "r2-independent-list.stdout").read_bytes()
expected_inventory = (WORK / "keelshell_session-r2-inventory.txt").read_bytes()
assert actual_inventory == expected_inventory
actual_names = [line.removesuffix(": test") for line in
                actual_inventory.decode().splitlines() if line.endswith(": test")]
source = (ROOT / "crates/keelshell-session/src/monitor/darwin/tests.rs").read_text()
source_names = re.findall(r"#\[test\]\s+fn ([A-Za-z0-9_]+)", source)
darwin_names = [name for name in actual_names if name.startswith("monitor::darwin::tests::")]
assert len(source_names) == len(darwin_names) == 44
assert {name.removeprefix("monitor::darwin::tests::") for name in darwin_names} == set(source_names)
passed_names = re.findall(r"^test (.+) \.\.\. ok$", (OUT / "focused-prebuilt-r2.stdout").read_text(), re.M)
assert len(passed_names) == len(set(passed_names)) == 55
assert set(darwin_names).issubset(passed_names)

import_receipt = json.loads((WORK / "darwin-author-evidence-import.json").read_text())
import_mismatch = []
for row in import_receipt["files"]:
    data = (WORK / "darwin-author" / row["path"]).read_bytes()
    if len(data) != row["bytes"] or hashlib.sha256(data).hexdigest() != row["sha256"]:
        import_mismatch.append(row["path"])
assert len(import_receipt["files"]) == 68 and not import_mismatch

sdk = Path("/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX27.2.sdk")
author_abi = json.loads((WORK / "darwin-author/abi-evidence.json").read_text())
sdk_rows = []
for row in author_abi["headers"]:
    if row["relative_path"].startswith(("i386/", "mach/i386/")):
        continue
    path = sdk / "usr/include" / row["relative_path"]
    data = path.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    assert digest == row["sha256"]
    sdk_rows.append({
        "absolute_path": str(path), "sha256": digest, "bytes": len(data),
        "lines_checked": [[entry["start_line"], entry["end_line"]] for entry in row["evidence"]],
    })
(OUT / "sdk-sha256-r1.json").write_text(json.dumps({
    "sdk_path": str(sdk), "architecture": "arm64 LP64 only",
    "os": "macOS 27.2.1 build 26B131",
    "evidence": "Local public headers, independent C syntax-only assertions, ctypes declarations",
    "cross_architecture_acceptance": False, "headers": sdk_rows,
}, indent=2) + "\n")

result = {
    "source_files": len(freeze["files"]), "r2_to_r3_source_drift": [],
    "current_source_mismatch": [], "binary_sha256": expected_sha,
    "binary_bytes": binary.stat().st_size,
    "inventory_matches_parent_byte_for_byte": True,
    "inventory_tests": len(actual_names), "darwin_source_and_binary_tests": len(darwin_names),
    "focused_unique_passes": len(passed_names),
    "author_import_files": len(import_receipt["files"]), "author_import_mismatch": import_mismatch,
    "local_sdk_headers_verified": len(sdk_rows),
    "independent_rust_recompilation": False, "author_stub_executed_by_reviewer": False,
}
(OUT / "verification-r1.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
