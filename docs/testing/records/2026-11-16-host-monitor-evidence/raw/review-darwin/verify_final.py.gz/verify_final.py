"""Bind final review inputs, parent candidate and independently executed tests."""

import datetime
import hashlib
import json
from pathlib import Path
import re

ROOT = Path("/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell")
OUT = ROOT / "work/host-monitor-20261116/review-darwin"
WORK = ROOT / "work/host-monitor-20261116"
EXPECTED = "d45b07a984babf9b767956c494e11fb2566168186655fa18fe6a1b70612751a3"
AGGREGATE = "66936ab5115a3abe55ef6e9bd8e460f8bf4b9462252d249a028f35d10c9b5740"

freeze = json.loads((OUT / "source-manifest-r8.stdout").read_text())
assert freeze["files"] == json.loads((OUT / "source-manifest-r7.stdout").read_text())["files"]
assert len(freeze["files"]) == 8
for row in freeze["files"]:
    data = (ROOT / row["path"]).read_bytes()
    assert len(data) == row["bytes"] and hashlib.sha256(data).hexdigest() == row["sha256"]

candidate_path = WORK / "candidate-inputs-r1.json"
candidate_data = candidate_path.read_bytes()
candidate = json.loads(candidate_data)
assert candidate["schema"] == 1 and candidate["baseline"] == freeze["baseline"]
assert candidate["count"] == len(candidate["inputs"]) == 713
assert candidate["aggregate_sha256"] == AGGREGATE
index = {row["path"]: row for row in candidate["inputs"]}
assert len(index) == 713
for row in candidate["inputs"]:
    relative = Path(row["path"])
    assert not relative.is_absolute() and ".." not in relative.parts
    data = (ROOT / relative).read_bytes()
    assert len(data) == row["bytes"] and hashlib.sha256(data).hexdigest() == row["sha256"], row["path"]
for row in freeze["files"]:
    assert index[row["path"]]["sha256"] == row["sha256"]
    assert index[row["path"]]["bytes"] == row["bytes"]

binary = WORK / "bins/keelshell_session-r4"
assert hashlib.sha256(binary.read_bytes()).hexdigest() == EXPECTED
assert (OUT / "r4-binary-hash.stdout").read_text().split()[0] == EXPECTED
metadata = json.loads((OUT / "r4-build-metadata.stdout").read_text())
entry = next(row for row in metadata if row["name"] == "keelshell_session")
assert entry["sha256"] == EXPECTED and entry["bytes"] == binary.stat().st_size
assert Path(entry["stable"]) == binary
inventory = (OUT / "r4-independent-list.stdout").read_bytes()
assert inventory == (WORK / "keelshell_session-r4-inventory.txt").read_bytes()
names = [line.removesuffix(": test") for line in inventory.decode().splitlines()
         if line.endswith(": test")]
assert len(names) == len(set(names)) == 292
source = (ROOT / "crates/keelshell-session/src/monitor/darwin/tests.rs").read_text()
source_names = re.findall(r"#\[test\]\s+(?:#\[[^\n]+\]\s+)*fn (\w+)", source)
darwin_names = [name.removeprefix("monitor::darwin::tests::") for name in names
                if name.startswith("monitor::darwin::tests::")]
assert len(source_names) == len(darwin_names) == 45
assert set(source_names) == set(darwin_names)
pass_groups = {}
for label, expected in (("focused-prebuilt-r2", 55), ("r3-narrow-regressions", 6),
                        ("r4-narrow-regressions", 3)):
    passed = re.findall(r"^test (.+) \.\.\. ok$", (OUT / f"{label}.stdout").read_text(), re.M)
    assert len(passed) == len(set(passed)) == expected
    pass_groups[label] = passed
assert set(pass_groups["r4-narrow-regressions"]).issubset(names)
unique_passes = set().union(*map(set, pass_groups.values()))
assert sum(map(len, pass_groups.values())) == 64 and len(unique_passes) == 57
assert {"monitor::darwin::tests::" + name for name in darwin_names} <= unique_passes
assert "monitor::tests::platform_selector_supports_bin_only_uname_and_reports_both_paths_missing" in pass_groups["r4-narrow-regressions"]

guard = json.loads((OUT / "non-posix-guard-repair-r2.stdout").read_text())
script_row = next(row for row in freeze["files"] if row["path"] == "scripts/test_darwin_monitor_collector.py")
assert guard["test_source_sha256"] == script_row["sha256"]
assert guard["tests_run"] == 30 and guard["passed"] == 16
assert len(guard["skipped"]) == 14 and guard["errors"] == guard["failures"] == 0
assert guard["portable_netstat_and_capacity_wire_tests_still_run"]
promoted = (OUT / "promoted-collector-suite-r2.stderr").read_text()
assert "Ran 30 tests" in promoted and "\nOK\n" in promoted
independent = (OUT / "independent-collector-risks-r1.stderr").read_text()
assert "Ran 15 tests" in independent and "\nOK\n" in independent
for label in (*pass_groups, "non-posix-guard-repair-r2", "promoted-collector-suite-r2",
              "independent-collector-risks-r1", "sdk-arm64-static-assertions-r1"):
    receipt = json.loads((OUT / f"{label}.json").read_text())
    assert receipt["returncode"] == 0 and receipt["reaped"] and not receipt["timed_out"]

freeze["candidate_manifest"] = str(candidate_path)
freeze["candidate_manifest_sha256"] = hashlib.sha256(candidate_data).hexdigest()
freeze["candidate_aggregate_field"] = AGGREGATE
freeze["candidate_inputs_content_hashes_verified"] = 713
freeze["review_scope_matches_candidate"] = True
(OUT / "source-sha256-final-r1.json").write_text(json.dumps(freeze, indent=2) + "\n")
result = {
    "recorded_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "baseline": freeze["baseline"],
    "reviewed_source_files": 8,
    "current_source_drift": [],
    "candidate_inputs_content_hashes_verified": 713,
    "candidate_content_mismatch": [],
    "candidate_manifest_sha256": freeze["candidate_manifest_sha256"],
    "parent_reported_candidate_aggregate_field": AGGREGATE,
    "aggregate_algorithm_recomputed": False,
    "review_scope_matches_candidate": True,
    "other_705_files_source_reviewed": False,
    "binary_sha256_before_and_after": EXPECTED,
    "binary_bytes": binary.stat().st_size,
    "parent_metadata_consistent": True,
    "inventory_byte_for_byte_equal": True,
    "inventory_total_tests": 292,
    "darwin_source_and_inventory_tests": 45,
    "rust_passes_by_command": pass_groups,
    "rust_test_executions_passed": 64,
    "rust_unique_test_names_passed": 57,
    "final_promoted_python_passed": 30,
    "independent_collector_risk_cases_passed": 15,
    "non_posix_simulated": {"passed": 16, "skipped": 14, "errors": 0},
    "independent_rust_recompilation": False,
    "native_windows_execution": False,
    "native_darwin_ssh_runner_execution_by_reviewer": False,
    "notices": {"DARWIN-P2-01": "CLOSED", "DARWIN-P2-02": "CLOSED"},
    "open_findings": {"P0": 0, "P1": 0, "P2": 0, "P3": 0},
    "recommendation": "APPROVE - source scope only; full gate pending on identical candidate inputs",
}
(OUT / "verification-final-r1.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
