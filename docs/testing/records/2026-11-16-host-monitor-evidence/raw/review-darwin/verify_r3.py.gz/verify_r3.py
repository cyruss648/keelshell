"""Verify the parent-built r3 binary, current source and narrow repair receipts."""

import datetime
import hashlib
import json
from pathlib import Path
import re

ROOT = Path("/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell")
OUT = ROOT / "work/host-monitor-20261116/review-darwin"
WORK = ROOT / "work/host-monitor-20261116"
EXPECTED = "9907eee3fb2ee6c1b933cefb9f278368c3838b7d958b6e2e7728f91fcb53a178"
binary = WORK / "bins/keelshell_session-r3"
digest = hashlib.sha256(binary.read_bytes()).hexdigest()
assert digest == EXPECTED
before = (OUT / "r3-binary-hash.stdout").read_text().split()[0]
assert before == digest
metadata = json.loads((OUT / "r3-build-metadata.stdout").read_text())
entry = next(row for row in metadata if row["name"] == "keelshell_session")
assert entry["sha256"] == digest and entry["bytes"] == binary.stat().st_size
assert Path(entry["stable"]) == binary
inventory = (OUT / "r3-independent-list.stdout").read_bytes()
assert inventory == (WORK / "keelshell_session-r3-inventory.txt").read_bytes()
names = [line.removesuffix(": test") for line in inventory.decode().splitlines()
         if line.endswith(": test")]
darwin_names = [name.removeprefix("monitor::darwin::tests::") for name in names
                if name.startswith("monitor::darwin::tests::")]
source = (ROOT / "crates/keelshell-session/src/monitor/darwin/tests.rs").read_text()
source_names = re.findall(r"#\[test\]\s+(?:#\[[^\n]+\]\s+)*fn (\w+)", source)
assert len(names) == len(set(names)) == 291
assert len(darwin_names) == len(source_names) == 45
assert set(darwin_names) == set(source_names)
passed = re.findall(r"^test (.+) \.\.\. ok$", (OUT / "r3-narrow-regressions.stdout").read_text(), re.M)
assert len(passed) == len(set(passed)) == 6 and set(passed).issubset(names)
launcher = "monitor::darwin::tests::earlier_path_python_cannot_select_the_collector_interpreter"
assert launcher in passed
freeze = json.loads((OUT / "source-manifest-r6.stdout").read_text())
previous = json.loads((OUT / "source-manifest-r5.stdout").read_text())
assert freeze["files"] == previous["files"]
assert all(hashlib.sha256((ROOT / row["path"]).read_bytes()).hexdigest() == row["sha256"]
           for row in freeze["files"])
probe = json.loads((OUT / "fixed-python-selection-r1.stdout").read_text())
assert probe["owned_shell_reaped"] and probe["decoded_current_rust_format_string"]
assert not probe["earlier_path_entry_executed"] and not probe["kernel_collector_executed"]
assert probe["fixed_uname_dispatch_verified"]
for label in ("r3-narrow-regressions", "fixed-python-selection-r1"):
    receipt = json.loads((OUT / f"{label}.json").read_text())
    assert receipt["returncode"] == 0 and receipt["reaped"] and not receipt["timed_out"]
result = {
    "recorded_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "baseline": freeze["baseline"],
    "source_snapshot": "source-manifest-r6.stdout",
    "source_snapshot_files": len(freeze["files"]),
    "r5_to_r6_source_drift": [],
    "current_source_drift": [],
    "binary_sha256_before_and_after": digest,
    "binary_bytes": binary.stat().st_size,
    "parent_metadata_consistent": True,
    "inventory_byte_for_byte_equal": True,
    "inventory_total_tests": len(names),
    "darwin_source_and_inventory_tests": len(darwin_names),
    "narrow_passed_tests": passed,
    "independent_rust_recompilation": False,
    "kernel_collector_executed_by_launcher_checks": False,
    "DARWIN-P2-01": "CLOSED on exact Rust inputs in source-manifest-r6.stdout",
}
(OUT / "verification-r3.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
