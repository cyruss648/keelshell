"""Reproduce the three new default tests with the Windows alarm API absent."""

import hashlib
import io
import json
from pathlib import Path
import signal
import types
import unittest
from unittest import mock

ROOT = Path("/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell")
source = ROOT / "scripts/test_darwin_monitor_collector.py"
module = types.ModuleType("review_default_collector_tests")
module.__file__ = str(source)
exec(compile(source.read_bytes(), str(source), "exec"), module.__dict__)
names = [
    "test_platform_failure_emits_no_untrusted_diagnostic",
    "test_core_failure_emits_no_untrusted_diagnostic",
    "test_missing_required_netstat_uses_missing_command_exit",
]
suite = unittest.TestSuite(module.CapacityAndWireTests(name) for name in names)
stream = io.StringIO()
without_alarm = types.SimpleNamespace(signal=signal.signal)
with mock.patch.object(module.collector, "signal", without_alarm):
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
print(json.dumps({
    "test_source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
    "boundary": "Only the documented Windows absence of SIGALRM is simulated; not native Windows execution",
    "tests_run": result.testsRun, "errors": len(result.errors),
    "failures": len(result.failures), "skipped": len(result.skipped),
    "trace": stream.getvalue(),
}, indent=2))
assert result.testsRun == 3 and len(result.errors) == 3
assert all("SIGALRM" in text for _test, text in result.errors)
