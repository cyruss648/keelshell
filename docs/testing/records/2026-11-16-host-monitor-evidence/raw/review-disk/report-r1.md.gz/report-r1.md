**限定结论：APPROVE。开放 P0=0、P1=0、P2=0、P3=0；零开放发现。**

签署时间 `2026-11-16T05:12:34.126592+08:00`。本次为新的非作者只读窄审，批准仅覆盖 `final-inputs-r2.json` → `final-inputs-r6.json` 的三个测试文件增量。完整 **full-gate-r3 保持 PENDING**；本报告不签署完整门禁或产品总体验收。

固定目录为 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`，初始及最终读回 HEAD 均为 `539c172389b4450570026f023ff89d50df90f910`。已读实际 AGENTS.md、`/Users/hdh/.codex/RTK.md` 及 HANDOFF 当前批次短段；使用 rust-best-practices 的相关源码、测试和注释规则。HANDOFF 的旧 r2 运行中表述按本次新需求和实际终态回执理解。

独立按清单顺序重算 `SHA256(UTF-8(path + NUL + sha256 + newline) 的拼接)`：r1 至 r6 各 713 项的集合摘要均匹配；路径集合、顺序完全一致，新增/删除/重复路径均为 0。最终 r6 集合摘要为 `e0b6ae274c4fad8d1246df5cba5c21b779b8afa6341385818a99b0a2264effd3`，现场 **713/713 项 SHA-256 与 bytes 匹配，0 mismatch**，最终读回无漂移。相对 r2 恰好变三个测试文件、其余 710 项相同；相对 r5 只增 Darwin 测试文件首行。713 项仅核对输入身份，不代表重新审查全部功能。

| 源码范围 | 判定及证据 |
| --- | --- |
| [disk_monitor.rs:175](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/disk_monitor.rs:175) | 唯一行为变化为对精确 `include_str!("../src/monitor/darwin.py")` 使用一次 `split_once`；缺失则经 `ok_or(...)?` 使测试失败，对 prefix 和 suffix 两段完整执行原 `kill/sudo/install` 拒绝条件。将此块在内存恢复为旧 guard，可逐字恢复 r2 SHA 与长度。r3→r4 仅 assertion 的 rustfmt 布局，可精确恢复 r3 SHA/长度；此文件 r4→r6 未变。 |
| [disk_monitor_independent.rs:250](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/disk_monitor_independent.rs:250) | 对同一次已捕获 SSH exec 用 `rsplit_once("\n;;\nLinux)\n")` 选取当前固定脚本的 Linux 分支，使用完整且锚定末尾的 `strip_suffix("\n;;\n*) exit 64 ;;\nesac\n")`，再与原 `SNAPSHOT_SCRIPT` 的全部 bytes 对应正文相等。将新增块恢复为旧末尾 assertion，可逐字恢复 r2 SHA 与长度。 |
| [monitor/darwin/tests.rs:1](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/darwin/tests.rs:1) | 第一行是 `#![cfg(test)]`，位于既有 `#![expect(...)]` 之前。仅移除这 14 bytes 即精确恢复 r5 和 r2 SHA/长度，全部 45 个测试声明及正文保持。父 [darwin.rs:432](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/darwin.rs:432) 已有 `#[cfg(test)]` 加 path 加 `mod tests`，因此新增 inner cfg 仅重复明确测试模块边界，未隐藏原本会发布的生产代码。 |

第一文件中，Linux 磁盘数值、设备消失、BootChanged、BootIdentity、其他资源值断言，以及五次原始命令数量和 `commands.windows(2)` 完全相等断言均保留；第二文件的 250ms exec deadline、200–700ms elapsed、Timeout 类型、owned task join、listener 关闭及 `commands.len() == 1` 断言均保留。[monitor.rs:51](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor.rs:51) 与第 55 行的两处原有 `-r` 读权限检查连同整份生产文件逐字未变。上述结论同时由精确旧文件重建和 710 项身份连续性支持。

第一 guard 的分割满足 `prefix + exact_payload + suffix == command`，只删除一次精确固定正文。模型按现场固定源码组装的 command 为 13,500 bytes：prefix 542、payload 12,064、suffix 894；所有其余 shell bytes 均留在两段中扫描，包含 Linux 分支、heredoc 分隔及默认分支。第二份完整 payload 不会一并删除，其 `child.kill()` 留在 suffix 会使 guard 拒绝；没有完整 payload 则直接失败。[darwin.py:71](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/darwin.py:71) 中 `child` 来自本次 `subprocess.Popen`，第 125–127 行仅 poll/kill/wait 这个 owned child；本次资产身份与 r2 相同，继续沿用既有 Darwin 源码审查范围。本批准只认可这个固定资产的排除，不构成对监控目标或其他进程操作的授权。

第二 assertion 有明确边界：它检查最后一个精确 Linux 分隔符后的完整正文和锚定结尾，并不单独验证此前 OS wrapper 或要求分支唯一。当前 command 来自未改变的固定生成器；第一 guard 继续扫描周围 shell，并拒绝重复完整 payload/完整 command。两项 assertion 仍是固定源码的回归测试，不能解释为任意 shell 的通用授权解析器。

[remote_only.rs:17](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/remote_only.rs:17) 原 guard 本身相对 r2 未改，仍只识别位于开头的 inner `cfg(test)`，没有放宽路径推断或父属性推断。为已有测试专用外部模块补齐其显式标识符合原 guard 契约。

| 本 reviewer 实际执行/核对 | 结果 |
| --- | --- |
| 静态及身份检查 | **39/39 通过，0 失败**；另明确逐项核对 713 个输入 SHA/长度。详见 identity-r1.json。 |
| 纯内存字符串模型 | **6,876/6,876 符合预期，0 失败**，含 6,871 个负例和 5 个正向控制。周围每个 byte 边界各插入 kill/sudo/install：4,314；重复/缺失/正文改变/UTF-8 负例：8；Linux 正文每个边界插入三词：2,541；分隔、尾部及正文控制：8；完整 command 重复配对检查：1；其余正向控制：4。未执行任何构造 shell 或 payload。 |
| 父预构建 `bins/disk-monitor-r4` | 独立库存 3 项；运行结果 **2 passed / 0 failed / 1 ignored**，exit 0、reaped、0.038183s，timeout=30s。SHA `bf58bf29895d7c83f036281d83dafe91aebb92383ed6f2397ba7dde297ef0123`，18,929,376 bytes，来源为 disk-monitor-binary-r4.json；对应文件 r4→r6 未变。 |
| 父预构建 `bins/disk-independent-r5` | 独立库存 4 项；精确执行 `optional_collector_does_not_renew_exec_deadline_on_partial_data`：**1 passed / 0 failed / 0 ignored / 3 filtered**，exit 0、reaped、0.264058s，timeout=30s。SHA `1b8a6c6fe719da88c09c25ab5297026a92aa923a751ff728a8c6e4a2c1c2898e`，19,021,576 bytes，来源为 disk-independent-binary-r5.json；对应文件 r5→r6 未变。 |

两次库存命令各有 30s timeout，均 exit 0/reaped。独立执行 Rust 测试合计 **3 passed / 0 failed / 1 ignored**，另 3 filtered；库存命令不计为行为测试。两份 Rust 程序均是父预构建副本，本 reviewer 未独立编译，未从成功执行推断缓存产物包含全部最新源码。

纯内存模型用相同非空 UTF-8 byte patterns 映射 Rust `split_once/rsplit_once/strip_suffix`，并非 Rust 编译测试。探索中曾把“仅去掉 payload 最后换行”误设为缺失负例；紧随其后的 wrapper 换行仍会补成精确 payload 子串，因此它应是正向控制。另一次旧文件重建 helper 的注释锚点漏了 `Keep the`，已更正锚点。两项均是 reviewer 检查构造错误，已分别保留 memory-exploration-r1.json 和 identity-exploration-r1.json；最终上述计数为修正后的实际结果，无产品开放发现。

父方新回执经只读核实：format-r6 为 **exit 0 / reaped / 1.947s**；remote-only-r6 为 **5/0/0、exit 0 / reaped / 0.257s**；session-monitor-r6 为 **81/0/0、211 filtered、exit 0 / reaped / 2.173s**。这是父方执行的专项结果，本 reviewer 没有重新运行这三个命令。父第二磁盘 target 的 disk-independent-r5 为 4/0/0，已与本次独立精确用例执行区分。

保留并核对历史终态：full-gate-r2 **exit 1 / reaped / 487.225s**；session-regression-r4 **exit 101 / reaped / 46.702s**；session-regression-r5 **exit 101 / reaped / 192.371s**。新专项成功不覆盖这些失败原件，也不代替新完整门禁。三份主要源码批准报告的实际 SHA 仍匹配 review-resolution-r1.json；此前 lint 窄审仅作为旧范围背景，本报告只追加上述三文件增量。

全部写入仅位于本 `review-disk/`。未修改源码、Git index 或运行 Cargo、Rust 编译、Clippy、rustfmt、target 写入、容器/worktree 操作；未复制大文件。独立 native/真实远端联调为 0，忽略的私有真实 Linux 样本测试未执行。完整 workspace、三平台原生桌面、IME、辅助技术、安装和发布均不在本次批准内。**建议接续父方最终完整门禁；full-gate-r3 仍为 PENDING。**

机器清单：[manifest-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/host-monitor-20261116/review-disk/manifest-r1.json)。
