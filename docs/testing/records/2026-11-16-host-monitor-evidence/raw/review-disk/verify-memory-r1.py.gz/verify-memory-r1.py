"""Pure in-memory counterexamples; never executes a collector or shell."""
from pathlib import Path
import hashlib
import json
import re
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
MONITOR = (ROOT / "crates/keelshell-session/src/monitor.rs").read_text()
DARWIN = (ROOT / "crates/keelshell-session/src/monitor/darwin.rs").read_text()
PAYLOAD = (ROOT / "crates/keelshell-session/src/monitor/darwin.py").read_bytes()


def raw_constant(name):
    return re.search(
        r'const ' + name + r': &str = r#"(.*?)"#;', MONITOR, re.S
    ).group(1)


def format_literal(source):
    quoted = re.search(r'format!\(\s*("(?:\\.|[^"\\])*")', source, re.S).group(1)
    return json.loads(re.sub(r"\\\n[ \t]*", "", quoted))


darwin_command = (
    format_literal(DARWIN[DARWIN.index("pub(super) fn script"):])
    .replace("{}", "0")
    .replace("{COLLECTOR}", PAYLOAD.decode())
)
command = (
    format_literal(MONITOR[MONITOR.index("let script = format!("):])
    .replace("{PLATFORM_SELECTOR}", raw_constant("PLATFORM_SELECTOR"))
    .replace("{}", darwin_command)
    .replace("{linux_script}", raw_constant("SNAPSHOT_SCRIPT"))
    .encode()
)
prefix, found, suffix = command.partition(PAYLOAD)
assert found == PAYLOAD and command.count(PAYLOAD) == 1
assert prefix + PAYLOAD + suffix == command
expected = raw_constant("SNAPSHOT_SCRIPT").encode()
separator = b"\n;;\nLinux)\n"
terminator = b"\n;;\n*) exit 64 ;;\nesac\n"
outer, _, _ = command.rpartition(separator)


def utf8(data):
    try:
        data.decode("utf-8")
        return True
    except UnicodeDecodeError:
        return False


def guard(data):
    left, sep, right = data.partition(PAYLOAD)
    return utf8(data) and bool(sep) and all(
        token not in shell
        for shell in (left, right)
        for token in (b"kill", b"sudo", b"install")
    )


def linux_matches(data):
    _, sep, right = data.rpartition(separator)
    return (
        utf8(data)
        and bool(sep)
        and right.endswith(terminator)
        and right[:-len(terminator)] == expected
    )


groups = []
started = time.monotonic()


def group(name, cases, predicate):
    failures = []
    count = 0
    digest = hashlib.sha256()
    for case_id, value, wanted in cases:
        count += 1
        actual = predicate(value)
        digest.update(
            case_id.encode() + b"\0" + hashlib.sha256(value).digest()
            + bytes([wanted, actual])
        )
        if actual != wanted:
            failures.append({"case": case_id, "expected": wanted, "actual": actual})
    groups.append({
        "name": name, "cases": count, "passed": count - len(failures),
        "failed": len(failures), "failures": failures,
        "case_digest_sha256": digest.hexdigest(),
    })


def shell_insertions():
    for side, shell in (("prefix", prefix), ("suffix", suffix)):
        for token in (b"kill", b"sudo", b"install"):
            for index in range(len(shell) + 1):
                changed = shell[:index] + token + shell[index:]
                data = (
                    changed + PAYLOAD + suffix if side == "prefix"
                    else prefix + PAYLOAD + changed
                )
                yield f"{side}/{token.decode()}/{index}", data, False


group("tokens at every surrounding-shell byte boundary", shell_insertions(), guard)
group("duplicate, absent, altered payload and invalid UTF-8", [
    ("duplicate-before", prefix + PAYLOAD + PAYLOAD + suffix, False),
    ("duplicate-after", command + PAYLOAD, False),
    ("duplicate-full-command", command + command, False),
    ("no-payload", prefix + suffix, False),
    ("empty", b"", False),
    ("interior-change", prefix + PAYLOAD.replace(b"child.kill()", b"child.wait()", 1) + suffix, False),
    ("nonreconstructible-truncation", prefix + PAYLOAD[:-16] + suffix, False),
    ("invalid-UTF8", b"\xff" + command, False),
], guard)
group("positive controls for exact collector", [
    ("current-fixed-command", command, True),
    ("unicode-shell", "注释".encode() + command + "结束".encode(), True),
    ("only-exact-payload", PAYLOAD, True),
    ("newline-supplied-by-wrapper", prefix + PAYLOAD[:-1] + suffix, True),
], guard)


def body_insertions():
    for token in (b"kill", b"sudo", b"install"):
        for index in range(len(expected) + 1):
            changed = expected[:index] + token + expected[index:]
            yield (
                f"body/{token.decode()}/{index}",
                outer + separator + changed + terminator, False,
            )


group("Linux complete body equality under insertions", body_insertions(), linux_matches)
group("Linux branch framing and body controls", [
    ("missing-separator", command.replace(separator, b"\n;;\nOther)\n"), False),
    ("missing-terminator", command[:-len(terminator)], False),
    ("extra-tail", command + b"printf tail\n", False),
    ("extra-body", outer + separator + expected + b"printf body\n" + terminator, False),
    ("duplicate-body", outer + separator + expected + expected + terminator, False),
    ("truncated-body", outer + separator + expected[:-1] + terminator, False),
    ("invalid-UTF8", b"\xff" + command, False),
    ("current-fixed-command", command, True),
], linux_matches)
group("paired checks reject full-command duplication", [
    ("duplicate-fixed-command", command + command, False),
], lambda data: guard(data) and linux_matches(data))

result = {
    "schema": 1,
    "scope": "Pure in-memory model of the two Rust string assertions",
    "source_binding": {
        "monitor.rs": hashlib.sha256(MONITOR.encode()).hexdigest(),
        "darwin.rs": hashlib.sha256(DARWIN.encode()).hexdigest(),
        "darwin.py": hashlib.sha256(PAYLOAD).hexdigest(),
    },
    "command": {
        "sha256": hashlib.sha256(command).hexdigest(), "bytes": len(command),
        "prefix_bytes": len(prefix), "payload_bytes": len(PAYLOAD),
        "suffix_bytes": len(suffix), "linux_body_bytes": len(expected),
    },
    "limitations": [
        "Models Rust split_once/rsplit_once/strip_suffix on the same exact nonempty UTF-8 byte patterns; not compiled Rust",
        "No shell, collector, external target, or process action is executed",
        "Second assertion checks the last Linux branch and anchored suffix; it intentionally does not validate the prefix or enforce unique branches",
        "First guard rejects forbidden surrounding bytes and repeated full payloads; it is an assertion over fixed source, not a general shell authorization parser",
    ],
    "groups": groups,
    "cases": sum(g["cases"] for g in groups),
    "failed": sum(g["failed"] for g in groups),
    "seconds": round(time.monotonic() - started, 6),
}
(OUT / "memory-cases-r1.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n"
)
print(json.dumps(result, ensure_ascii=False, indent=2))
raise SystemExit(1 if result["failed"] else 0)
