"""Read parent evidence and kernel identities; never invoke a resource client."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path.cwd()
BASE = ROOT / "work/host-monitor-20261116"
OUT = BASE / "review-recovery"
assert ROOT == Path("/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell")
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / "scripts"))
import openssh_interop as interop

BASELINE = "539c172389b4450570026f023ff89d50df90f910"
LABEL = "io.keelshell.monitor-recovery.owner"
TOOLS = {"df": "Filesystems", "ps": "Processes", "ss": "Sockets"}
REASONS = {
    "missing": "CommandMissing",
    "unsupported": "UnsupportedOptions",
    "permission": "PermissionDenied",
}
PHASES = (
    "degraded", "cached-0", "cached-1", "repaired-without-reset",
    "new-connection", "explicit-reset",
)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text())


labdir = BASE / "linux-recovery-r3"
toolsdir = BASE / "ss-tools-recovery-r2"
oldpath = BASE / "ss-tools-r1/result.json"
lab = load(labdir / "result.json")
resumed = load(toolsdir / "result.json")
old = load(oldpath)
assert lab["status"] == "PASSED" and lab["returncode"] == 0
assert lab["observations_admissible"] and lab["input_bytes_unchanged"]
assert lab["source_sha"] == BASELINE
assert lab["source_sha256"] == lab["source_sha256_after"]
for path, expected in lab["source_sha256"].items():
    assert digest(ROOT / path) == expected, path
binary = Path(lab["test_binary"]["path"])
assert digest(binary) == lab["test_binary"]["sha256"] == lab["test_binary"]["sha256_after"]
assert all(test["status"] == "PASSED" for test in lab["tests"])
assert len(lab["tests"]) == 2

raw_manifest = {}
for directory in (labdir, toolsdir, BASE / "ss-tools-r1"):
    for path in sorted(directory.rglob("*")):
        if path.is_file():
            raw_manifest[str(path.relative_to(ROOT))] = {
                "bytes": path.stat().st_size, "sha256": digest(path),
            }
assert set(lab["logs"]) == {p.name for p in labdir.glob("*.log")}
for name, expected in lab["logs"].items():
    assert raw_manifest[str((labdir / name).relative_to(ROOT))] == expected, name

fixture = load(labdir / "rust-0/fixture.json")
identity = fixture["identity"]
assert fixture["owner"] == lab["owner"]
assert int(identity["effective_caps_hex"], 16) == 0x400C5
assert int(identity["bounding_caps_hex"], 16) == 0x400C5
assert re.fullmatch(r"net:\[\d+\]", identity["network_namespace"])
for tool, metadata in fixture["tools"].items():
    assert metadata["path"] == f"/usr/bin/{tool}"
    assert re.fullmatch(r"[0-9a-f]{64}", metadata["sha256"])


def observation(value, failed=None):
    counts = value["counts"]
    assert counts["owner"] == lab["owner"]
    assert counts["identity"] == identity and counts["tools"] == fixture["tools"]
    for tool, capability in TOOLS.items():
        expected = f"Unavailable({REASONS[failed[1]]})" if failed and failed[0] == tool else "Available"
        assert value["capabilities"][capability] == {"checked": True, "state": expected}
    assert value["capabilities"]["Resources"] == {"checked": True, "state": "Available"}
    snapshot = value["snapshot"]
    assert snapshot["uptime_seconds"] > 0 and snapshot["memory_total_bytes"] > 0
    assert snapshot["network_count"] > 0 and any(snapshot["cpu_ticks"])
    assert snapshot["boot_time"] == baseline["snapshot"]["boot_time"]
    assert snapshot["uptime_seconds"] >= baseline["snapshot"]["uptime_seconds"]
    if failed and failed[0] == "df":
        assert snapshot["filesystem_count"] == 0
    else:
        assert snapshot["filesystem_count"] > 0
    for tool, key in (("ps", "processes"), ("ss", "sockets")):
        if failed and failed[0] == tool:
            assert value[key] == {
                "capability": TOOLS[tool], "reason": REASONS[failed[1]],
                "type": "CapabilityUnavailable",
            }
        else:
            assert value[key]["count"] > 0


baseline = load(labdir / "rust-0/baseline.json")
observation(baseline)
for group in ("probes", "invocations", "delegations"):
    assert baseline["counts"][group] == dict.fromkeys(TOOLS, 1)
assert baseline["counts"]["requests"] == {"core": 1, "ps": 1, "ss": 1}
previous = baseline["counts"]
case_rows = []
for selected in TOOLS:
    for mode in REASONS:
        name = f"{selected}-{mode}"
        details = []
        for phase in PHASES:
            value = load(labdir / "rust-0" / f"{name}-{phase}.json")
            negative = phase in PHASES[:4]
            observation(value, (selected, mode) if negative else None)
            counts = value["counts"]
            assert counts["modes"] == {
                tool: mode if tool == selected and phase in PHASES[:3] else "real"
                for tool in TOOLS
            }
            assert counts["requests"]["core"] == previous["requests"]["core"] + 1
            for tool in TOOLS:
                for group in ("probes", "invocations", "delegations"):
                    delta = 1
                    if tool == selected:
                        if phase in PHASES[1:4]:
                            delta = 0
                        elif phase == "degraded":
                            delta = int(group == "probes" or
                                        (group == "invocations" and mode != "missing"))
                    assert counts[group][tool] == previous[group][tool] + delta, (name, phase, group, tool)
                if tool in ("ps", "ss"):
                    delta = int(not (tool == selected and phase in PHASES[1:4]))
                    assert counts["requests"][tool] == previous["requests"][tool] + delta
            details.append({
                "phase": phase, "capability_state": value["capabilities"][TOOLS[selected]]["state"],
                "selected_counter_delta": {
                    group: counts[group][selected] - previous[group][selected]
                    for group in ("probes", "invocations", "delegations")
                },
                "core_delta": counts["requests"]["core"] - previous["requests"]["core"],
            })
            previous = counts
        case_rows.append({"case": name, "phases": details})
summary = load(labdir / "rust-0/summary.json")
assert summary == lab["tests"][0]["summary"]
assert summary["completed_cases"] == [row["case"] for row in case_rows]
assert previous["requests"]["core"] == 55
assert previous["mode_changes"] == 21
assert previous["delegations"] == dict.fromkeys(TOOLS, 43)
assert previous["invocations"] == dict.fromkeys(TOOLS, 45)
assert previous["probes"] == dict.fromkeys(TOOLS, 46)
assert load(labdir / "rust-1/fixture.json") == previous
assert load(labdir / "rust-1/transport-readback.json") == previous
for repetition in range(2):
    value = load(labdir / f"rust-1/transport-{repetition}.json")
    for key in ("snapshot", "processes", "sockets"):
        assert value[key] == {"type": "Session", "reason": "Transport"}
    for capability in ("Resources", "Processes", "Sockets"):
        assert value["capabilities"][capability] == {"checked": True, "state": "Unavailable(Transport)"}
    assert value["capabilities"]["Filesystems"] == {"checked": False, "state": "Unknown"}
transport_summary = load(labdir / "rust-1/summary.json")
assert transport_summary == lab["tests"][1]["summary"]
for value in (summary, transport_summary):
    assert value["source_sha"] == BASELINE and value["binary_sha256"] == digest(binary)
    assert value["native_app"] == "NOT_RUN"
for index, logname in enumerate(("019-rust-test-0.log", "020-rust-test-1.log")):
    text = (labdir / logname).read_text()
    assert f'test {lab["tests"][index]["name"]} ... ok' in text
    assert "test result: ok. 1 passed; 0 failed; 0 ignored;" in text

cleanup_rows = []
births = {}
for receipt, directory, expected_processes, barrier_count in (
    (lab, labdir, 41, 20), (resumed, toolsdir, 9, 2),
):
    cleanup = receipt["cleanup"]
    assert cleanup["confirmed"] and cleanup["client_barrier_confirmed"] and cleanup["processes_confirmed"]
    assert not cleanup.get("ancestry_unverified", [])
    commands = receipt["commands"]
    assert len(commands) == len(receipt["steps"]) == len(cleanup["processes"]) == expected_processes
    byname = {row["name"]: row for row in commands}
    assert len(byname) == expected_processes
    assert {r["name"] for r in cleanup["client_barrier"]} == {r["name"] for r in commands[:barrier_count]}
    for step in receipt["steps"]:
        command = byname[step["name"]]
        assert step["reaped"] and command["reaped"] and step["returncode"] == command["returncode"]
    for rows in (cleanup["client_barrier"], cleanup["processes"]):
        for row in rows:
            command = byname[row["name"]]
            assert row["pid"] == command["pid"] and row["returncode"] == command["returncode"]
            assert row["reaped"] and row["observed_stopped"] and row["identities"]
            assert row["pid"] in [r["pid"] for r in row["identities"]]
            for entry in row["identities"]:
                births[(entry["pid"], tuple(entry["birth"]))] = None
    events = [json.loads(line) for line in (directory / "events.jsonl").read_text().splitlines()]
    assert [e["command"] for e in events if e["event"] == "command-end"] == commands
    assert len([e for e in events if e["event"] == "command-start"]) == len(commands)
    for resource in receipt["resources"]:
        kind, identifier, name = resource["kind"], resource["id"], resource["name"]
        assert re.fullmatch("[0-9a-f]{64}", identifier)
        assert all(op["status"] == "COMPLETED" and op["returncode"] == 0 for op in resource["mutations"])
        binds = [c for c in commands if c["name"].endswith("bind-" + kind)]
        assert binds
        for command in binds:
            value = load(directory / (command["name"] + ".log"))
            if kind == "network":
                value = value[0]
            assert value["id"].removeprefix("sha256:") == identifier
            assert value["labels"][LABEL] == receipt["owner"]
            assert (name in value["names"] if kind == "image"
                    else value["name"].lstrip("/") == name)
        removes = [c for c in commands if c["name"].endswith("remove-" + kind)]
        assert len(removes) == 1 and removes[0]["returncode"] == 0
        assert removes[0]["argv"][-1] == identifier and removes[0]["reaped"]
        absence = [c for c in commands if c["name"].endswith("verify-absent-" + kind)]
        assert len(absence) == 2
        assert {c["argv"][-1] for c in absence} == {identifier, name}
        assert all(c["returncode"] == 1 and c["reaped"] for c in absence)
        actual = next(r for r in cleanup["resources"] if r["kind"] == kind)
        assert actual == dict(kind=kind, name=name, id=identifier, absent=True, absence_observed=True)
        cleanup_rows.append(dict(receipt=str((directory / "result.json").relative_to(ROOT)), **actual))
    for command in commands:
        if command["name"].endswith("image-consumers"):
            assert load(directory / (command["name"] + ".log")) == []
assert lab["cleanup"]["private_directory_removed"]
private = Path(lab["private_directory"])
assert private.parent == ROOT / "work" and not private.exists() and not private.is_symlink()
network = next(r for r in lab["resources"] if r["kind"] == "network")
container = next(r for r in lab["resources"] if r["kind"] == "container")
assert network["configuration"]["internal"] and not network["configuration"]["dns_enabled"]
security = container["security"]
assert security["readonly"] and not security["privileged"] and not security["mounts"]
assert "no-new-privileges" in security["security_opt"]
assert container["fixture"]["identity"] == identity
assert set(container["network"]["Networks"]) == {network["name"]}
assert list(container["network"]["Networks"].values())[0]["NetworkID"] == network["id"]
assert set(container["network"]["Ports"]) == {"2222/tcp"}
bindings = container["network"]["Ports"]["2222/tcp"]
assert len(bindings) == 1 and bindings[0]["HostIp"] == "127.0.0.1"
creation = next(c["argv"] for c in lab["commands"] if c["name"].endswith("create-ssh"))
assert "--read-only" in creation and "--cap-drop=ALL" in creation
assert [creation[i + 1] for i, value in enumerate(creation) if value == "--cap-add"] == [
    "CHOWN", "DAC_READ_SEARCH", "SETUID", "SETGID", "SYS_CHROOT",
]
assert len([s for s in creation if s == "--tmpfs"]) == 3
assert not set(creation).intersection({"--volume", "-v", "--mount", "--privileged"})

historical = {
    "linux-recovery-r1/result.json": "9b5240bc52c9d9372e77ccbc7cfa4963243b767d9ef4b5b045d8aba63bb09fc4",
    "linux-recovery-r2/result.json": "cd4a7aac19d720278cea750bf5d44974c8059de125b0156d081fb16ba9f4059f",
    "ss-tools-r1/result.json": "24897652a5219821a4b3142bd93ce5e255abc2957965a3b1d19f266a9cef4251",
}
for rel, expected in historical.items():
    assert digest(BASE / rel) == expected
    value = load(BASE / rel)
    assert value.get("status", value.get("result")) == "FAILED"
assert not old["cleanup"]["confirmed"]
assert old["resources"][0]["mutations"][0]["status"] == "UNKNOWN"
assert old["failure"] == {"type": "KeyError", "message": "'steps'"}
original_child = next(r for r in old["cleanup"]["processes"] if r["name"] == "001-prepare-tools")
assert original_child["reaped"] and original_child["observed_stopped"] and original_child["returncode"] == 0
assert old["commands"][0]["pid"] == original_child["pid"]
assert old["commands"][0]["client_barrier"][0] == original_child
buildlog = (BASE / "ss-tools-r1/001-prepare-tools.log").read_text()
identifier = buildlog.splitlines()[-1]
assert re.fullmatch("[0-9a-f]{64}", identifier)
resolution = resumed["completed_build_resolution"]
assert resolution["process"] == original_child
assert resolution["full_image_id"] == identifier == resumed["resources"][0]["id"] == lab["base_image"]["id"]
assert resolution["original_failure"] == old["failure"] and resolution["original_mutation_status"] == "UNKNOWN"
assert old["owner"] == resumed["owner"]
assert old["resources"][0]["name"] == resumed["resources"][0]["name"]
assert "deb.debian.org/debian" in buildlog and "Setting up iproute2 (6.1.0-3)" in buildlog
assert "STEP 1/3: FROM 77353e13649fe86ce434ffb958fcdf43317abe4ffdc0916fa7225edd407bb082" in buildlog
assert resumed["result"] == "PASSED" and resumed["lab_exit"] == 0
assert not any(c["name"].endswith(("prepare-tools", "create-network", "create-ssh", "build-offline"))
               for c in resumed["commands"])
assert [op["command"] for op in resumed["resources"][0]["mutations"]] == [
    "prior-build-direct-completion-evidence", "007-remove-image",
]
for entry in original_child["identities"]:
    births[(entry["pid"], tuple(entry["birth"]))] = None
for pid, birth in births:
    current = interop.process_info(pid)
    assert current is None or tuple(current[2]) != birth, (pid, "original kernel identity still present")
    births[(pid, birth)] = "absent" if current is None else "pid-reused-with-different-birth"

secret_patterns = (
    rb"-----BEGIN [A-Z ]*PRIVATE KEY-----",
    rb"KS_MONITOR_LAB_V1 [0-9a-f]{64}",
    rb"KEELSHELL_MONITOR_TOKEN=[0-9a-f]{64}",
)
scanned = []
for directory in (labdir, toolsdir, BASE / "ss-tools-r1"):
    for path in sorted(directory.rglob("*")):
        if path.is_file() and path.suffix in (".json", ".jsonl", ".log"):
            data = path.read_bytes()
            assert not any(re.search(pattern, data) for pattern in secret_patterns), path.name
            scanned.append(str(path.relative_to(ROOT)))
for filename in ("016-export-host.pub.log", "017-export-client.log", "018-export-token.log"):
    assert (labdir / filename).stat().st_size == 0

result = {
    "checked_utc": datetime.now(timezone.utc).isoformat(),
    "parent_linux_result": {
        "path": str(labdir / "result.json"), "sha256": digest(labdir / "result.json"),
        "status": lab["status"], "returncode": lab["returncode"], "elapsed_seconds": lab["elapsed_seconds"],
        "passed_opt_in_tests": 2, "completed_cases": len(case_rows), "raw_recovery_observations": 55,
        "transport_error_observations": 2, "transport_counters_unchanged": True,
        "final_counts": previous, "case_audit": case_rows,
    },
    "tools_resolution": {
        "path": str(toolsdir / "result.json"), "sha256": digest(toolsdir / "result.json"),
        "status": resumed["result"], "lab_exit": resumed["lab_exit"],
        "direct_original_child_completion_matches": True, "original_child": original_child,
        "fresh_owner_full_id_tag_bindings": True, "creation_replayed": False,
        "old_unknown_and_failed_receipt_unchanged": True, "original_failed_hashes": historical,
        "original_build_log_sha256": digest(BASE / "ss-tools-r1/001-prepare-tools.log"),
        "network_package_preparation": "official Debian iproute2 6.1.0-3 installed in owned derived image; not offline",
        "normal_lab_build": "offline --pull=never --network=none; shared original base was not a mutation target",
    },
    "cleanup": {
        "lab_clients": 41, "tools_clients": 9, "lab_pre_resource_barrier_clients": 20,
        "tools_pre_resource_barrier_clients": 2, "all_receipt_children_reaped_and_stopped": True,
        "live_kernel_identity_readback": [
            {"pid": pid, "birth": list(birth), "status": status}
            for (pid, birth), status in sorted(births.items())
        ],
        "resource_receipt_readbacks": cleanup_rows, "private_directory_absent_on_reviewer_read": True,
        "resource_absence_boundary": "parent command/log receipts only; reviewer did not query Podman",
        "effective_and_bounding_mask": "0x400c5", "read_only_no_host_mounts": True,
        "internal_dns_free_network_single_loopback_publication": True,
    },
    "evidence": {
        "all_41_parent_declared_log_hashes_and_sizes_match": True,
        "source_before_after_matches_current": True, "binary_sha256": digest(binary),
        "raw_files": raw_manifest, "credential_pattern_scan_files": len(scanned),
        "credential_pattern_scan_boundary": "known private-key/control-token patterns and zero-byte export logs; not arbitrary-secret detection",
    },
    "reviewer_boundary": {
        "podman_invocations": 0, "resource_mutations": 0, "independent_rust_compilation": "NOT_RUN",
        "independent_linux_execution": "NOT_RUN", "native_desktop": "NOT_RUN", "final_full_gate": "PENDING",
        "raw_json_does_not_serialize": "capability timestamps, connection authority, socket addresses; these are Rust assertions bound to the parent binary",
    },
}
with (OUT / "parent-final-evidence-audit-r1.json").open("x") as stream:
    stream.write(json.dumps(result, indent=2) + "\n")
print(json.dumps({
    "status": "PASSED", "recovery_cases": 9, "raw_recovery_observations": 55,
    "typed_transport_observations": 2, "parent_log_hashes_verified": 41,
    "owned_resource_receipt_cleanups": len(cleanup_rows),
    "live_kernel_identities_checked": len(births), "same_original_identity_present": 0,
    "original_failed_receipts_unchanged": 3, "podman_invocations": 0,
}))
