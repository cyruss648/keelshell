**MR-01 CLOSED for source and fixture bootstrap.** The original notice and failed Linux r1 receipt remain unchanged.

The reviewed correction at `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/monitor_recovery_lab.py:145` adds CHOWN and DAC_READ_SEARCH to SETUID, SETGID and SYS_CHROOT. The exact effective/bounding capability contract at `:154` is `0x400c5`; DAC_OVERRIDE, NET_ADMIN and SYS_ADMIN are excluded. The container retains a read-only root filesystem, no host mounts, an internal owned network, no-new-privileges and localhost-only publication.

This resolves the ownership transfer in `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/monitor_recovery/fixture.py:269` and root read/search access for the dedicated account's 0700 STATE tree. Approval applies to this disposable fixture. CHOWN allows ownership changes, and DAC_READ_SEARCH is not scoped to a single path; their combination must not be described as a general path-scoped read-only permission.

Independent verification:

- `python-final-independent-r1.json`: 33 test methods passed, zero failures/errors/skips, inputs unchanged. This includes the 23 supplied regressions and 10 reviewer regressions. Each of the five required capability bits was independently removed from both actual identity fields and rejected; adding DAC_OVERRIDE, NET_ADMIN or SYS_ADMIN was also rejected.
- Parent real Linux r2 reached the SSH fixture and real collectors with effective and bounding masks `00000000000400c5`, matching source bytes for all six reviewed files. Core `/proc`, real `/usr/bin/df` and real `/usr/bin/ps` succeeded; delegation counters were 1 for df and ps. This is completed parent evidence, read back by the reviewer, not a reviewer-created container.
- R2 subsequently failed because the existing image lacked real ss. Its status remains FAILED / exit 1 / 7.245s / observations_admissible=false; this does not invalidate the bootstrap correction or establish full recovery acceptance.
- R2 recorded all three owned resources absent, all 40 clients stopped/reaped, private directory removed, and cleanup.confirmed=true.

Exact six-file approval is bound by `source-reviewed-r1.json`, aggregate SHA-256 `27a9df3cdf351576dc3ced48300b8c408318a175cd167f18d9b795406f434b63`, with immutable reviewed copies in `source-snapshot-r1/`. Parent Linux r2 receipt SHA-256 is `cd4a7aac19d720278cea750bf5d44974c8059de125b0156d081fb16ba9f4059f`; safe partial readback is in `parent-linux-r2-partial-observations.json`.
