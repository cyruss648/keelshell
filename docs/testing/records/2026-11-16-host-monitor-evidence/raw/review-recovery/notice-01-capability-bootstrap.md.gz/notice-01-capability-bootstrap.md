# P2 MR-01 — fixture bootstrap needs a capability excluded by the container

Status: OPEN; source blocker for the recovery lab. Baseline HEAD is `539c172389b4450570026f023ff89d50df90f910`. This is a non-author, read-only source finding, not a claim of an independently executed Linux container.

- Location: `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/monitor_recovery_lab.py:138` drops all capabilities, and `:145` adds only SETUID, SETGID and SYS_CHROOT. `check_isolation()` at `:154` requires exactly the corresponding mask `0x400c0`.
- Trigger: `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/monitor_recovery/fixture.py:269` calls `os.lchown` on the root-created private STATE tree to transfer ownership to `ksmonitor`, during `prepare()` and before the sshd/readiness startup.
- Impact: arbitrary file-owner changes require Linux CAP_CHOWN. That bit is absent from the effective and bounding masks required by this runner, so the bootstrap owner transfer must fail with EPERM on the intended Linux configuration. `serve()` cannot reach a usable fixture, and neither real recovery test can run.
- Follow-on boundary: simply adding CHOWN is insufficient unless root readback is also considered. STATE is mode 0700 and is transferred to ksmonitor, whereas the default-root `status` call reads STATE/counts.json. Without DAC_OVERRIDE or a deliberate user-scoped status/read/export design, that readback is denied as well. Keep the final capability assertion aligned with the chosen implementation.

Reproduction to be performed by the parent in its already-authorized real lab: retain the existing create arguments and exact cap mask, start the owned image, preserve fixture stderr and failed readiness records, then bind any correction to new source hashes. The reviewer will not create or modify Podman resources.

Independent follow-up: add a reviewer-owned regression that checks the existing bootstrap/owner-transfer contract against the exact capability policy; preserve the initial failing result. A source correction can instead remove the privileged ownership transition by preparing the state through the dedicated account and arranging only the necessary owner-scoped readback. Do not grant broad host privileges or host mounts.

Normative check: Linux man-pages `capabilities(7)` defines CAP_CHOWN as permission to make arbitrary changes to file UIDs/GIDs. The bit is 0, so the existing mask `0x400c0` excludes it.
