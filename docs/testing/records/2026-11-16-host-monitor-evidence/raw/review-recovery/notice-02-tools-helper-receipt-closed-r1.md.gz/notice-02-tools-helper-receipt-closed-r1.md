**MR-02：CLOSED。** 关闭范围为本次一次性 tools helper 事故的恢复与资源清算；原失败执行、UNKNOWN mutation 和 cleanup=false 原件全部保留。原 helper 没有因此被认定已修复或可重复使用。

原问题仍定位于 [prepare_ss_and_run.py:25](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/host-monitor-20261116/prepare_ss_and_run.py:25) 缺少 receipt `steps`，触发 [ssh_path_lab.py:178](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/ssh_path_lab.py:178) 的 KeyError。独立本地子进程复现及失败原始 notice 保留于本 review 目录。

恢复依据是肯定的原始完成证据：[resume_ss_and_run.py:17](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/host-monitor-20261116/resume_ss_and_run.py:17) 要求原失败恰为 KeyError `'steps'`，且原 `001-prepare-tools` 子进程 PID 48726 已 `observed_stopped=true`、`reaped=true`、`returncode=0`。该行与原 command 的 PID、barrier、kernel birth identity 完全一致；原 build log 末行给出完整 image ID。独立反例测试拒绝 unreaped、未停止、非零、signal、None exit 和不完整 ID，即使伪造 absence=true 也无法通过。

新 receipt 在 [resume_ss_and_run.py:26](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/host-monitor-20261116/resume_ss_and_run.py:26) 补齐 `steps`，显式记录 `original_mutation_status=UNKNOWN`；在 [:38](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/host-monitor-20261116/resume_ss_and_run.py:38) 注册并 fresh bind：

- owner：`keelshell-monitor-206f2e86e9ce41f2`
- exact tag：`localhost/keelshell-monitor-206f2e86e9ce41f2:ss-tools`
- full ID：`ef3f082c34cc3d3f52bc4f17cbfb23736cad9c2ce885a560fed6cf9ad9de0d12`

复核新 receipt 的全部 9 个命令，包含复用前和删除前的 owner/full-ID/tag readback、空 consumers、按完整 ID 删除 exit 0、按 ID 和 tag 分别 exists exit 1；没有再次 build/create。9 个 clients 全部停止/reap；删除前 barrier 覆盖先前 2 个 clients。正常 child lab 独立完成 2/2 opt-in、9 组恢复组合，且三个 child 资源已清理。新 tools receipt 的 `result=PASSED`、`lab_exit=0`、`cleanup.confirmed=true`。

这不是从资源缺席推断创建完成；新 receipt 的 COMPLETED 只来源于原实际已完成子进程与 fresh identity binding。原记录继续 FAILED / UNKNOWN / cleanup=false，其 SHA-256 保持 `24897652a5219821a4b3142bd93ce5e255abc2957965a3b1d19f266a9cef4251`。

新 [ss-tools-recovery-r2/result.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/host-monitor-20261116/ss-tools-recovery-r2/result.json) SHA-256：`ba1c683058c0eab70e7278c84f4c18c96006012ab71d99ed337fd47f546f24e5`。完整交叉核对见 [parent-final-evidence-audit-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/host-monitor-20261116/review-recovery/parent-final-evidence-audit-r1.json)。资源 absence 来自父实际命令与日志；本 reviewer 没有执行 Podman。
