# P2 MR-02 — work-only helper omits the LabRunner receipt steps list

Status: OPEN for the acceptance-only helper and its cleanup evidence; this is outside the six production/lab source files. Baseline HEAD is `539c172389b4450570026f023ff89d50df90f910`.

- Location: `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/host-monitor-20261116/prepare_ss_and_run.py:25` constructs the receipt without `steps`, then passes it to `ClientRunner` at `:32`.
- Trigger: `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/ssh_path_lab.py:178` unconditionally appends a completed process result to `self.receipt["steps"]`. When the tools build exits, this raises KeyError before PodmanLab.command receives the exit code or binds the image. Cleanup exists commands encounter the same missing field.
- Impact: the tools image was actually built and tagged, but the helper exits before launching linux-recovery-r3. Its build mutation correctly remains UNKNOWN, and cleanup cannot confirm absence. A build log reporting success cannot be substituted for the failed runner receipt or for Linux test acceptance.
- Completed evidence: `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/host-monitor-20261116/linux-with-ss-r1.json` reports exit 1, 4.731 seconds, reaped. `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/host-monitor-20261116/ss-tools-r1/result.json` reports FAILED / KeyError 'steps', no lab_exit, cleanup.confirmed=false, and an UNKNOWN image mutation. Its SHA-256 is `24897652a5219821a4b3142bd93ce5e255abc2957965a3b1d19f266a9cef4251`.
- Resource evidence: build output names `localhost/keelshell-monitor-206f2e86e9ce41f2:ss-tools` and full image ID `ef3f082c34cc3d3f52bc4f17cbfb23736cad9c2ce885a560fed6cf9ad9de0d12`. This is a candidate identity from the log, not permission to delete it without fresh owner/full-ID/exact-name inspection.

Parent action: supply the complete receipt contract before a separately numbered attempt. Retain ss-tools-r1 and linux-with-ss-r1 as failed originals. Reconcile and clean the old image in a new bounded receipt only after clients actually stop/reap, and verify owner label, complete ID and exact tag before deletion. A later absent read must not rewrite the original UNKNOWN mutation or cleanup=false into success.

The reviewer has performed no Podman command and will inspect completed parent receipts only. This does not reopen the already-reviewed CHOWN/DAC_READ_SEARCH source correction.
