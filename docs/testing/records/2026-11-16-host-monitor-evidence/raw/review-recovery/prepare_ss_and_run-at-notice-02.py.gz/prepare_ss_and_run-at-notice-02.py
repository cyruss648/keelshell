"""Owned acceptance-only iproute2 image; shared base remains unchanged."""
from contextlib import ExitStack
import json
import os
from pathlib import Path
import sys
import time
import uuid

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
import monitor_recovery_lab as lab

out = BASE / 'ss-tools-r1'
out.mkdir(mode=0o700)
context = out / 'context'
context.mkdir(mode=0o700)
base_image = '77353e13649fe86ce434ffb958fcdf43317abe4ffdc0916fa7225edd407bb082'
(context / 'Containerfile').write_text(
    'FROM ' + base_image + '\n'
    'RUN apt-get -o Acquire::Retries=0 -o Acquire::http::Timeout=15 -o Acquire::https::Timeout=15 update '
    '&& apt-get -y -o Acquire::Retries=0 -o Acquire::http::Timeout=15 -o Acquire::https::Timeout=15 install --no-install-recommends iproute2 '
    '&& /usr/bin/ss -V && dpkg-query -W iproute2\n')
receipt = {'schema': 1, 'owner': 'keelshell-monitor-' + uuid.uuid4().hex[:16],
           'base_image': base_image, 'commands': [], 'processes': [], 'resources': [],
           'cleanup': {}, 'shared_image_modified': False,
           'scope': 'Acceptance-only owned image with Debian iproute2; actual Linux lab remains offline'}
deadline = time.monotonic() + 720
code = 1
with ExitStack() as stack:
    runner = lab.ClientRunner(out, deadline - 70, stack, receipt, lambda: None)
    api = lab.PodmanLab(runner, receipt['owner'], receipt, lab.interop.executable('podman'))
    try:
        image = api.register('image', 'localhost/' + receipt['owner'] + ':ss-tools')
        api.command('prepare-tools', ['build', '--pull=never', '--force-rm', '--no-cache',
                    '--label', lab.LABEL + '=' + receipt['owner'], '--tag', image['name'],
                    str(context)], seconds=150, mutation=image)
        api.bind(image)
        receipt['prepared_image_id'] = image['id']
        binary = json.loads((BASE / 'session-binaries-r3.json').read_text())
        binary = next(row for row in binary if row['name'] == 'monitor_interop')
        args = [sys.executable, '-B', str(ROOT / 'scripts/monitor_recovery_lab.py'),
                '--opt-in', 'localhost-owned-fixture', '--output', str(BASE / 'linux-recovery-r3'),
                '--source-sha', '539c172389b4450570026f023ff89d50df90f910',
                '--test-binary', binary['stable'], '--test-binary-sha256', binary['sha256'],
                '--base-image', image['id'], '--timeout', '480']
        code, _ = api.command('real-linux-lab', args, seconds=500, allowed=(0, 1), binary=True,
                              environment=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'))
        receipt['lab_exit'] = code
    except BaseException as error:
        receipt['failure'] = lab.failure(error)
    finally:
        receipt['cleanup']['resources'] = api.cleanup()
        stopped, confirmed = lab.stop_clients(runner, deadline)
        receipt['cleanup'].update(processes=stopped, processes_confirmed=confirmed)
        receipt['cleanup']['confirmed'] = confirmed and all(row.get('absent') for row in receipt['cleanup']['resources'])
        receipt['result'] = 'PASSED' if code == 0 and receipt['cleanup']['confirmed'] else 'FAILED'
        (out / 'result.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k:receipt.get(k) for k in ['result','failure','lab_exit','prepared_image_id']}))
raise SystemExit(0 if receipt['result'] == 'PASSED' else 1)
