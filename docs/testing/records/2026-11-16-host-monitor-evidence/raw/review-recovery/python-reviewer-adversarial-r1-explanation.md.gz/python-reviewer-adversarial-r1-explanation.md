# Independent probe r1 retained as failed reviewer-harness evidence

The first probe command exited 1, with 9 test methods run, 0 assertion failures and 3 subtest errors across two methods. These are reviewer-harness errors, not additional production findings:

1. The reviewer supplied the earlier `uname` wrapper prefix after the parent had updated both production and fixture to the absolute `/usr/bin/uname` prefix. The fixture correctly rejected this obsolete outer wrapper before exec. Both normal/cached subcases therefore raised PermissionError instead of reaching the reviewer's exec interception.
2. One malformed-input subcase tried to put a NUL into an operating-system environment variable. Python rejected that before fixture code ran.

The r1 JSON's mechanically derived `passed: 6` subtracts error subcases from test methods and is not a correct successful-method count. There were 7 successful methods and two methods with errors. The harness now counts addSuccess callbacks, and the original stdout, stderr and JSON remain unchanged.

R2 uses the current absolute wrapper prefix and tests only values admissible in SSH_ORIGINAL_COMMAND. No production file was modified to resolve these harness errors. Both original source manifests and original failed outputs remain available.
