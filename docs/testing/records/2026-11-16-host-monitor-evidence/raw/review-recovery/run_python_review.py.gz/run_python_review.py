"""Reviewer harness: all persistent output and temporary files stay in review."""

import hashlib
import importlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest


ROOT = Path.cwd()
OUT = ROOT / "work/host-monitor-20261116/review-recovery"
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
sys.dont_write_bytecode = True
TEMP = OUT / "tmp"
TEMP.mkdir(mode=0o700, exist_ok=True)
tempfile.tempdir = str(TEMP)
os.environ["TMPDIR"] = str(TEMP)
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(OUT))


def hashes():
    files = [
        ROOT / "scripts/monitor_recovery_lab.py",
        ROOT / "scripts/test_monitor_recovery_lab.py",
        ROOT / "scripts/monitor_recovery/fixture.py",
        ROOT / "scripts/monitor_recovery/tool.py",
        ROOT / "scripts/monitor_recovery/Containerfile",
        ROOT / "scripts/ssh_path_lab.py",
        ROOT / "scripts/openssh_interop.py",
        ROOT / "crates/keelshell-session/tests/monitor_interop.rs",
        ROOT / "crates/keelshell-session/src/monitor.rs",
        ROOT / "crates/keelshell-session/src/monitor/capabilities.rs",
    ]
    for optional in (
        ROOT / "work/host-monitor-20261116/resume_ss_and_run.py",
        ROOT / "work/host-monitor-20261116/ss-tools-r1/result.json",
        ROOT / "work/host-monitor-20261116/ss-tools-r1/001-prepare-tools.log",
    ):
        if optional.is_file():
            files.append(optional)
    return {
        str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in files
    }


def main():
    prefix, *modules = sys.argv[1:]
    before = hashes()
    original_popen = subprocess.Popen

    def safe_popen(args, *positional, **keywords):
        executable = args[0] if isinstance(args, (list, tuple)) else args
        if Path(executable).name in ("podman", "cargo", "rustc", "docker"):
            raise AssertionError("Reviewer harness forbids container and build commands")
        return original_popen(args, *positional, **keywords)

    subprocess.Popen = safe_popen
    start = time.monotonic()
    suite = unittest.TestSuite(
        unittest.defaultTestLoader.loadTestsFromModule(importlib.import_module(module))
        for module in modules
    )
    class CountSuccesses(unittest.TextTestResult):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.successful_methods = []

        def addSuccess(self, test):
            super().addSuccess(test)
            self.successful_methods.append(test.id())

    result = unittest.TextTestRunner(verbosity=2, resultclass=CountSuccesses).run(suite)
    after = hashes()
    record = {
        "argv": sys.argv,
        "cwd": str(ROOT),
        "elapsed_seconds": round(time.monotonic() - start, 6),
        "run": result.testsRun,
        "failures": len(result.failures),
        "errors": len(result.errors),
        "skipped": len(result.skipped),
        "expected_failures": len(result.expectedFailures),
        "unexpected_successes": len(result.unexpectedSuccesses),
        "passed": len(result.successful_methods),
        "source_before": before,
        "source_after": after,
        "inputs_unchanged": before == after,
        "real_linux_lab": "NOT_RUN",
        "rust_compilation": "NOT_RUN",
        "podman_invocations": 0,
        "temporary_root": str(TEMP),
    }
    with (OUT / (prefix + ".json")).open("x") as stream:
        json.dump(record, stream, indent=2)
        stream.write("\n")
    print(json.dumps({k: v for k, v in record.items() if k not in ("source_before", "source_after")}))
    return 0 if result.wasSuccessful() and before == after else 1


if __name__ == "__main__":
    sys.exit(main())
