**最终建议：APPROVE 本次六文件 source 与已完成 runtime/cleanup 证据；条件为父最终 sole full gate 通过并保持本次输入绑定。Open P0=0、P1=0、P2=0、P3=0；没有剩余实际阻塞。** 历史 P2 MR-01、MR-02 均已闭合，失败原件继续保留。Full gate 在本签字时为 PENDING，本报告允许父启动该 gate。

本次为非作者独立只读复核。固定 workdir 为 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`，baseline/复核 HEAD 均为 `539c172389b4450570026f023ff89d50df90f910`。已读 RTK、AGENTS、HANDOFF、ADR0143、testing STRATEGY/SHARED_TARGET。reviewer 仅写本 review 目录，未修改产品文件、Cargo/target、提交推送或操作 Podman 资源。

最终六文件 aggregate SHA-256 为 `f07c101b3dae85e5b54c73c3b8da8e78b892814ef7367e9bb344510892d06315`，定义为 path→SHA256 映射按 key 排序的紧凑 UTF-8 JSON，无尾换行。精确 source、context SHA 和只读快照见 [source-reviewed-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/host-monitor-20261116/review-recovery/source-reviewed-r2.json)：

| Source | SHA-256 |
| --- | --- |
| [monitor_interop.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/monitor_interop.rs) | `04500b0880612afff9d0a4256fe323e397a6b5e7b1cdd589bb2bca932d43c203` |
| [monitor_recovery_lab.py](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/monitor_recovery_lab.py) | `c4f2326fdc0ed76f1f6a1a1a8a62f05a2bae7a8b4ff62978b106754818acdb79` |
| [test_monitor_recovery_lab.py](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_monitor_recovery_lab.py) | `9cb9471369c1911fe6883fb5a4574814f237a9dfa2e388884cc03746e65c9fa3` |
| [fixture.py](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/monitor_recovery/fixture.py) | `4c2c43e689928d736136477a2f7b8b80a0f0a3ef8dcd9b026e8b7791cc4d489f` |
| [tool.py](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/monitor_recovery/tool.py) | `a46e6d452be1ead3145f7da7cb3a5bb60c4d7c9f98c9e18fabd08517b6be3ca9` |
| [Containerfile](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/monitor_recovery/Containerfile) | `9b4b034b63d0fbb996e5e7ab304610de166a211e02da64240862eb84f8718186` |

候选 freeze **713/713 项 SHA 和 bytes 全匹配**，独立重算 aggregate 为 `66936ab5115a3abe55ef6e9bd8e460f8bf4b9462252d249a028f35d10c9b5740`，编码为 manifest 顺序的 `path + NUL + sha256 + newline`。manifest 文件自身 SHA 为 `86db0ba0043d2431db04458404451d0e71a97035c4f523da4f01bcfa130eeddb`，两者不可混用。见 [candidate-inputs-readback-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/host-monitor-20261116/review-recovery/candidate-inputs-readback-r1.json)。713 项字节绑定不扩张本次代码审查范围。

最后窄差分审查通过：[fixture.py:69](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/monitor_recovery/fixture.py:69) 与 production selector 同步固定 `/usr/bin/uname`、`/bin/uname` 候选；[:97](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/monitor_recovery/fixture.py:97) 仍只提取精确已知 SNAPSHOT/CACHED Linux body，Darwin 文本丢弃后才 exec。独立 hostile PATH 与 injected Linux body 反例通过。成功路径使用真实 `/proc`、固定绝对 df/ps/ss；wrapper 只注入故障。**该 lab 证明 Linux body/真实工具，不证明 Linux 上完整原始 Darwin/Linux snapshot 外壳分派；真实 Mac SSH 的完整分派属于另项验收。**

| 实际执行或证据核对 | 结果与边界 |
| --- | --- |
| 独立 `python3 -B -u work/host-monitor-20261116/review-recovery/run_python_review.py python-final-independent-r2 test_monitor_recovery_lab test_reviewer_safety` | exit 0、reaped；**35/35**，0 failures/errors/skips，外部计时 1.458423s；23 supplied + 12 reviewer methods，输入前后不变 |
| 独立 stable r4 `--list`、`--list --ignored` | 2 命令均 exit 0/reaped，恰为 2 个预期 ignored tests；执行 monitoring tests 数为 0 |
| 独立 `python3 -B work/host-monitor-20261116/review-recovery/audit_final_evidence.py` | exit 0；核对 55 恢复观测、2 transport 观测、41 log hashes、4 owned resource cleanup receipts、51 kernel birth identities |
| 父实际 Linux r3 | **2/2 opt-in PASSED**；9 组 df/ps/ss × missing/unsupported/permission；exit 0，14.692s，observations_admissible=true |
| 父 tools recovery r2 | PASSED，lab_exit=0、cleanup=true；原 child 完成证据恢复，未重发创建 |

独立 Python 原始结果见 [python-final-independent-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/host-monitor-20261116/review-recovery/python-final-independent-r2.json)。35 是最终不同 test methods 数，不累计重复执行。早期 reviewer harness r1 的旧 selector/NUL 输入错误原件保留并已更正说明；七份导入 author 原件（含旧 Python failure）重新核对 SHA 均未变。

Rust r4 binary 为 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/host-monitor-20261116/bins/monitor_interop-r4`，18,047,712 bytes，SHA `d1ccd581b937904227bdbea49238bc75db2ffacecbfd133b975627c34de4b570`。见 [rust-prebuilt-inventory-r4.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/host-monitor-20261116/review-recovery/rust-prebuilt-inventory-r4.json)。reviewer 独立验证 bytes/inventory，**没有独立编译 Rust，也没有自行运行 Linux lab**；构建来源是父提供的 provenance，runtime 是父完成后独立审计的真实记录。

九组故障均核对 degraded、cached-0、cached-1、repaired-without-reset、new-connection、explicit-reset 六阶段。故障首次 probe +1；missing invocation +0，其他故障 +1，成功 delegation +0；两次 cached 与修复后未 reset 均不增加故障工具的三个计数，core 与未受影响工具继续；新连接和显式 reset 恢复真实 delegation。最终 core=55，每个工具 delegation=43、invocation=45、probe=46。新认证 SshSession、连接 authority、缓存 checked_at 不变和监听 `:2222` 的断言位于 [monitor_interop.rs:413](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/monitor_interop.rs:413)、[:440](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/monitor_interop.rs:440)、[:314](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/monitor_interop.rs:314)；raw JSON 未序列化这些时间/authority/地址，因此它们的运行证明来自绑定 binary 的实际成功断言。

Transport 两次 raw observation 均为 `Session/Transport`，Filesystems 保持 Unknown，独立认证 verifier readback 的完整 counters 与关闭前一致；[:505](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/monitor_interop.rs:505) 还断言重复 transport 尝试使 report revision 失效。它没有被归类为 command missing 或永久负缓存。

runtime/cleanup 审计见 [parent-final-evidence-audit-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/host-monitor-20261116/review-recovery/parent-final-evidence-audit-r1.json)。实际 effective/bounding mask 均为 `0x400c5`；readonly、no host mounts、internal/DNS-free bridge、单个 loopback publication 与三个 tmpfs 创建参数匹配。MR-01 的 CHOWN/DAC_READ_SEARCH 仅批准用于该 disposable fixture；前者移交 tmpfs 所有权，后者允许 root 状态读取，不能描述为通用的路径范围只读授权。

子 lab 41 clients、tools helper 9 clients 均有实际 stopped/reaped 行；资源读取前 barrier 分别覆盖此前 20/2 clients。reviewer 只读检查包括旧 build 在内的 51 个不同 kernel birth identity，当前均不再存在。三个 child 资源及一个 tools image 均在删除前 fresh bind owner + full ID + exact name/tag，删除 exit 0，随后按 ID/name 各 exists exit 1；image consumers 为空。private directory 在 reviewer 当前读取时亦不存在。资源 absence 是父命令/日志证据，本 reviewer 未查询 Podman。源码和安全回归还覆盖 UNKNOWN 不被 absence 洗白、barrier 未确认禁止资源读取、单资源清理错误不跳过其他资源、私有目录替换拒绝。

临时 key/token 的 export logs 均为零字节；所有已提供相关 JSON/JSONL/log 中未发现 private-key/control-token 已知模式。源码以最小环境 exec，异常不回显原 control command。该检查限定于这些已知模式和已提供证据，不宣称检测任意未知秘密。

**MR-02 已通过独立的新恢复 receipt 闭合本次事故与清算。** 原 build 的 PID 48726 实际 stopped/reaped/exit 0 与完整日志 image ID 是新 COMPLETED 的依据；fresh owner/full-ID/tag bind 后复用，未重发 build/create。原 `ss-tools-r1` 继续 FAILED / UNKNOWN / cleanup=false，SHA `24897652a5219821a4b3142bd93ce5e255abc2957965a3b1d19f266a9cef4251`。详见 [MR-02 closure](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/host-monitor-20261116/review-recovery/notice-02-tools-helper-receipt-closed-r1.md)。原 helper 原件仍是失败实现；本次关闭不赋予它可重复使用的批准。

父 Linux r1/r2 原件仍分别 FAILED（bootstrap / 无真实 ss），其 SHA 未变。r3 result SHA 为 `e26d050b1d00a5201fb648e1d0f0167beff5e069c61e3014399733f849060f4c`，tools recovery result SHA 为 `ba1c683058c0eab70e7278c84f4c18c96006012ab71d99ed337fd47f546f24e5`。official Debian iproute2 的 owned derived-image 准备需要网络；后续正常 lab build/run 才是 offline，未把共享原始 base 作为 mutation 目标。

本签字关闭 source/runtime/cleanup 待复核项；**父 sole full gate 仍 PENDING**。gate 必须绑定上述候选输入，若 source 改动须窄复核。独立 Python 安全测试没有被当成 Linux 验收；预构建 binary、父真实 Linux 和 native desktop 验收继续分别记账。
