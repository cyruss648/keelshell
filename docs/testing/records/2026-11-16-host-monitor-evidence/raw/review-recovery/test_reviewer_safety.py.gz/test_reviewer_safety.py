"""Independent behavioral probes; no Podman, Linux fixture, or Rust acceptance."""

import ast
from contextlib import contextmanager, redirect_stderr
import copy
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

import monitor_recovery_lab as lab
from test_monitor_recovery_lab import fixture


class ExecCaptured(Exception):
    pass


PORTABLE_SELECTOR = """ks_uname=''
for ks_candidate in /usr/bin/uname /bin/uname; do
  if [ -f "$ks_candidate" ] && [ -x "$ks_candidate" ]; then ks_uname="$ks_candidate"; break; fi
done
[ -n "$ks_uname" ] || exit 66
"""
WRAP_START = PORTABLE_SELECTOR + 'case "$("$ks_uname" -s)" in\nDarwin)\n'


def record():
    return {"resources": [], "commands": [], "processes": [], "steps": [], "cleanup": {}}


def counts():
    return {
        "requests": {"core": 0, "ps": 0, "ss": 0},
        "probes": dict.fromkeys(fixture.TOOLS, 0),
        "invocations": dict.fromkeys(fixture.TOOLS, 0),
        "delegations": dict.fromkeys(fixture.TOOLS, 0),
        "modes": dict.fromkeys(fixture.TOOLS, "real"),
        "tools": {name: {"path": "/usr/bin/" + name} for name in fixture.TOOLS},
    }


@contextmanager
def locked(value):
    yield value


class IndependentSafetyTests(unittest.TestCase):
    def test_portable_selector_matches_production_and_ignores_hostile_path(self):
        source = (lab.ROOT / "crates/keelshell-session/src/monitor.rs").read_text()
        match = re.search(r'const PLATFORM_SELECTOR: &str = r#"(.*?)"#;', source, re.S)
        self.assertIsNotNone(match)
        self.assertEqual(match.group(1), PORTABLE_SELECTOR)
        self.assertEqual(fixture.PLATFORM_SELECTOR, PORTABLE_SELECTOR)
        with tempfile.TemporaryDirectory() as directory:
            fake = Path(directory) / "uname"
            fake.write_text("#!/bin/sh\nprintf 'HOSTILE_PATH_WAS_USED\\n'\n")
            fake.chmod(0o700)
            command = ["/bin/sh", "-c", PORTABLE_SELECTOR + '"$ks_uname" -s']
            process = subprocess.run(command, capture_output=True, text=True, timeout=3,
                                     env=dict(os.environ, PATH=directory))
            self.assertEqual(process.returncode, 0)
            self.assertNotIn("HOSTILE_PATH_WAS_USED", process.stdout)
            self.assertEqual(process.stdout.strip(), "Darwin" if sys.platform == "darwin" else "Linux")

    def test_forced_snapshot_never_passes_untrusted_darwin_text_to_exec(self):
        # Exercise forced(), not merely the string extraction helper.
        hostile = "printf should-never-execute; $(id); `id`\n;;\nLinux)\necho injected"
        for body in (fixture.SNAPSHOT, fixture.CACHED_SNAPSHOT):
            value = counts()
            command = (
                WRAP_START + hostile
                + "\n;;\nLinux)\n" + body + "\n;;\n*) exit 64 ;;\nesac\n"
            )
            with self.subTest(cached=body == fixture.CACHED_SNAPSHOT), \
                    patch.object(fixture, "guard"), \
                    patch.object(fixture, "locked_state", lambda: locked(value)), \
                    patch.dict(os.environ, {"SSH_ORIGINAL_COMMAND": command}), \
                    patch.object(fixture.os, "execve", side_effect=ExecCaptured) as execute:
                with self.assertRaises(ExecCaptured):
                    fixture.forced()
                executable, arguments, environment = execute.call_args.args
                self.assertEqual(executable, "/bin/sh")
                self.assertEqual(arguments, ["sh", "-c", body])
                self.assertNotIn(hostile, arguments[-1])
                self.assertEqual(value["requests"]["core"], 1)
                self.assertEqual(value["probes"]["df"], int(body == fixture.SNAPSHOT))
                self.assertEqual(set(environment), {"PATH", "LC_ALL", "LANG", "HOME"})

    def test_modified_linux_body_is_rejected_before_counter_or_exec(self):
        for suffix in ("\nid\n", "; id", "\r\n", "\n# comment", "\n;;\nLinux)\nid"):
            value = counts()
            original = copy.deepcopy(value)
            command = (
                WRAP_START + "anything\n;;\nLinux)\n"
                + fixture.SNAPSHOT + suffix + "\n;;\n*) exit 64 ;;\nesac\n"
            )
            with self.subTest(suffix=repr(suffix)), patch.object(fixture, "guard"), \
                    patch.object(fixture, "locked_state", lambda: locked(value)), \
                    patch.dict(os.environ, {"SSH_ORIGINAL_COMMAND": command}), \
                    patch.object(fixture.os, "execve") as execute:
                with self.assertRaises(PermissionError):
                    fixture.forced()
                execute.assert_not_called()
                self.assertEqual(value, original)

    def test_real_tool_delegation_uses_absolute_path_and_minimal_environment(self):
        for name in fixture.TOOLS:
            value = counts()
            arguments = ["literal-argument", "literal $(not-a-shell)"]
            with self.subTest(tool=name), patch.object(fixture, "guard"), \
                    patch.object(fixture, "locked_state", lambda: locked(value)), \
                    patch.dict(os.environ, {"REVIEW_UNRELATED_SECRET": "synthetic-do-not-forward"}), \
                    patch.object(fixture.os, "execve", side_effect=ExecCaptured) as execute:
                with self.assertRaises(ExecCaptured):
                    fixture.tool(name, arguments)
                executable, argv, environment = execute.call_args.args
                self.assertTrue(Path(executable).is_absolute())
                self.assertEqual(executable, "/usr/bin/" + name)
                self.assertEqual(argv, [name, *arguments])
                self.assertEqual(set(environment), {"PATH", "LC_ALL", "LANG", "HOME"})
                self.assertEqual(environment["HOME"], "/home/ksmonitor")
                self.assertEqual(value["invocations"][name], 1)
                self.assertEqual(value["delegations"][name], 1)

    def test_all_injected_failure_modes_never_exec_a_successful_tool(self):
        for name in fixture.TOOLS:
            for mode, status in (("missing", 127), ("unsupported", 2), ("permission", 126)):
                value = counts()
                value["modes"][name] = mode
                with self.subTest(tool=name, mode=mode), patch.object(fixture, "guard"), \
                        patch.object(fixture, "locked_state", lambda: locked(value)), \
                        patch.object(fixture.os, "execve") as execute, redirect_stderr(io.StringIO()):
                    self.assertEqual(fixture.tool(name, ["-ignored"]), status)
                    execute.assert_not_called()
                    self.assertEqual(value["invocations"][name], 1)
                    self.assertEqual(value["delegations"][name], 0)

    def test_cleanup_error_at_each_stage_does_not_skip_other_resources(self):
        for failing_stage in ("exists", "bind", "remove"):
            with self.subTest(stage=failing_stage), tempfile.TemporaryDirectory() as directory:
                receipt = record()
                for number, kind in enumerate(("image", "network", "container"), 1):
                    receipt["resources"].append({
                        "kind": kind, "name": "owned-" + kind, "id": str(number) * 64,
                        "mutations": [{"status": "COMPLETED", "command": "create"}],
                    })
                runner = type("Runner", (), {"deadline": time.monotonic() + 3,
                                             "output": Path(directory)})()
                api = lab.PodmanLab(runner, "owned", receipt, "never-executed")
                removed = set()
                visited = set()

                def command(label, argv, **kwargs):
                    kind = next((k for k in ("container", "network", "image") if k in label), None)
                    if kind is not None:
                        visited.add(kind)
                    if kind == "container" and (
                        (failing_stage == "exists" and "exists" in label)
                        or (failing_stage == "remove" and label.startswith("remove-"))
                    ):
                        raise lab.LabFailure("InjectedCleanupFailure", label)
                    if "exists" in label or "absent" in label:
                        return (1 if kind in removed else 0), ""
                    if label.startswith("remove-"):
                        removed.add(kind)
                        kwargs["mutation"]["mutations"].append(
                            {"status": "COMPLETED", "command": label}
                        )
                    return 0, ""

                def bind(resource):
                    visited.add(resource["kind"])
                    if resource["kind"] == "container" and failing_stage == "bind":
                        raise lab.LabFailure("OwnershipMismatch", "injected mismatch")
                    return resource["id"]

                with patch.object(lab, "stop_clients", return_value=([], True)), \
                        patch.object(api, "command", side_effect=command), \
                        patch.object(api, "bind", side_effect=bind), \
                        patch.object(api, "json", return_value=[]):
                    rows = api.cleanup()
                self.assertEqual(visited, {"container", "network", "image"})
                self.assertEqual(removed, {"network", "image"})
                self.assertFalse(rows[0]["absent"])
                self.assertTrue(all(row["absent"] for row in rows[1:]))

    def test_pending_and_unknown_mutations_stay_unknown_for_every_resource_type(self):
        for status in ("PENDING", "UNKNOWN"):
            receipt = record()
            receipt["resources"] = [
                {"kind": kind, "name": "owned-" + kind, "id": str(i) * 64,
                 "mutations": [{"command": "create", "status": status}]}
                for i, kind in enumerate(("image", "network", "container"), 1)
            ]
            api = lab.PodmanLab(type("Runner", (), {"deadline": time.monotonic() + 3})(),
                                "owned", receipt, "never-executed")
            with self.subTest(status=status), patch.object(lab, "stop_clients", return_value=([], True)), \
                    patch.object(api, "command", return_value=(1, "")):
                rows = api.cleanup()
            self.assertEqual(len(rows), 3)
            for row in rows:
                self.assertTrue(row["absence_observed"])
                self.assertFalse(row["absent"])
                self.assertEqual(row["mutation_completion"], "UNKNOWN")

    def test_all_resource_binds_reject_owner_or_full_id_or_name_mismatch(self):
        for kind in ("container", "network", "image"):
            for mismatch in ("owner", "id", "name"):
                resource = {"kind": kind, "name": "owned-" + kind, "id": "a" * 64}
                value = {"id": "a" * 64, "labels": {lab.LABEL: "owned"},
                         "name": resource["name"], "names": [resource["name"]]}
                if mismatch == "owner":
                    value["labels"][lab.LABEL] = "foreign"
                elif mismatch == "id":
                    value["id"] = "b" * 64
                else:
                    value["name"], value["names"] = "foreign", ["foreign"]
                api = lab.PodmanLab(None, "owned", record(), "never-executed")
                result = [value] if kind == "network" else value
                with self.subTest(kind=kind, mismatch=mismatch), \
                        patch.object(api, "json", return_value=result), \
                        patch.object(api, "journal") as journal:
                    with self.assertRaises(lab.LabFailure) as caught:
                        api.bind(resource)
                    self.assertEqual(caught.exception.kind, "OwnershipMismatch")
                    journal.assert_not_called()

    def test_unreaped_or_live_or_unverified_client_never_satisfies_barrier(self):
        for reaped, stopped, uncertain in ((False, True, False), (True, False, False),
                                           (True, True, True)):
            runner = type("Runner", (), {"processes": [object()],
                                         "ancestry_unverified": {123} if uncertain else set()})()
            rows = [{"reaped": reaped, "observed_stopped": stopped}]
            with self.subTest(reaped=reaped, stopped=stopped, uncertain=uncertain), \
                    patch.object(lab.process_lab, "shutdown", return_value=rows):
                observed, confirmed = lab.stop_clients(runner, time.monotonic() + 3)
                self.assertEqual(observed, rows)
                self.assertFalse(confirmed)

    def test_runtime_capability_contract_requires_every_bit_and_rejects_write_bypass(self):
        row = {
            "network": {"Networks": {"owned": {"NetworkID": "b" * 64}},
                        "Ports": {"2222/tcp": [{"HostIp": "127.0.0.1", "HostPort": "12345"}]}},
            "security": {"privileged": False, "network_mode": "bridge", "readonly": True,
                         "security_opt": ["no-new-privileges"], "mounts": [], "image": "a" * 64},
            "fixture": {"owner": "owned", "identity": {
                "effective_caps_hex": "400c5", "bounding_caps_hex": "400c5",
                "network_namespace": "net:[100]", "pid1_birth_ticks": 123,
                "boot_id": "297a70af-36d7-4e83-a4ca-07bf3bf7fa8e",
            }},
        }
        self.assertEqual(lab.check_isolation(row, {"id": "b" * 64}, {"id": "a" * 64}, "owned"),
                         12345)
        # CHOWN, DAC_READ_SEARCH, SETGID, SETUID, SYS_CHROOT are all necessary.
        # Also reject DAC_OVERRIDE, NET_ADMIN and SYS_ADMIN independently.
        rejected_masks = [0x400C5 & ~(1 << bit) for bit in (0, 2, 6, 7, 18)]
        rejected_masks += [0x400C5 | (1 << bit) for bit in (1, 12, 21)]
        for field in ("effective_caps_hex", "bounding_caps_hex"):
            for mask in rejected_masks:
                changed = copy.deepcopy(row)
                changed["fixture"]["identity"][field] = f"{mask:x}"
                with self.subTest(field=field, mask=f"{mask:x}"):
                    with self.assertRaises(lab.LabFailure) as caught:
                        lab.check_isolation(changed, {"id": "b" * 64}, {"id": "a" * 64}, "owned")
                    self.assertEqual(caught.exception.kind, "NamespaceIdentityUnknown")

    def test_private_cleanup_refuses_symlink_without_touching_other_directory(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            protected = root / "protected"
            protected.mkdir()
            (protected / "owner").write_text("owned")
            (protected / "valuable").write_text("preserve")
            link = root / "replaced"
            link.symlink_to(protected, target_is_directory=True)
            identity = (protected.stat().st_dev, protected.stat().st_ino)
            with self.assertRaises(lab.LabFailure) as caught:
                lab.private_remove(link, identity, "owned")
            self.assertEqual(caught.exception.kind, "PrivateIdentityMismatch")
            self.assertEqual((protected / "valuable").read_text(), "preserve")
            self.assertTrue(link.is_symlink())

    def test_resume_requires_actual_completed_child_and_full_id_not_absence(self):
        path = lab.ROOT / "work/host-monitor-20261116/resume_ss_and_run.py"
        tree = ast.parse(path.read_text())
        start = next(i for i, node in enumerate(tree.body) if isinstance(node, ast.Assign)
                     and any(isinstance(t, ast.Name) and t.id == "old" for t in node.targets))
        end = next(i for i, node in enumerate(tree.body) if isinstance(node, ast.Assign)
                   and any(isinstance(t, ast.Name) and t.id == "out" for t in node.targets))
        # Only execute the real helper's read/guard prefix, stopping before mkdir,
        # ClientRunner construction or any resource command.
        prefix = compile(ast.Module(body=tree.body[start:end], type_ignores=[]), str(path), "exec")
        original = json.loads(
            (lab.ROOT / "work/host-monitor-20261116/ss-tools-r1/result.json").read_text()
        )
        identifier = "ef3f082c34cc3d3f52bc4f17cbfb23736cad9c2ce885a560fed6cf9ad9de0d12"

        class MemoryFile:
            def __init__(self, text):
                self.text = text

            def read_text(self):
                return self.text

        class MemoryBase:
            def __init__(self, text):
                self.text = text

            def __truediv__(self, name):
                self.expected_name = name
                return MemoryFile(self.text)

        def check(value, image_id=identifier):
            base = MemoryBase("unrelated earlier build output\n" + image_id + "\n")
            namespace = {"old_path": MemoryFile(json.dumps(value)), "BASE": base,
                         "json": json, "re": re}
            exec(prefix, namespace)
            self.assertEqual(base.expected_name, "ss-tools-r1/001-prepare-tools.log")
            return namespace["identifier"]

        self.assertEqual(check(original), identifier)
        for changes in (
            {"reaped": False}, {"observed_stopped": False},
            {"returncode": 125}, {"returncode": -15}, {"returncode": None},
        ):
            changed = copy.deepcopy(original)
            child = next(r for r in changed["cleanup"]["processes"]
                         if r["name"] == "001-prepare-tools")
            child.update(changes)
            # Even an alleged absent resource cannot substitute for completion.
            changed["cleanup"]["resources"][0]["absence_observed"] = True
            changed["cleanup"]["resources"][0]["absent"] = True
            with self.subTest(changes=changes), self.assertRaises(AssertionError):
                check(changed)
        for image_id in ("short-id", identifier[:12], identifier.upper()):
            with self.subTest(image_id=image_id), self.assertRaises(AssertionError):
                check(original, image_id)


if __name__ == "__main__":
    unittest.main()
