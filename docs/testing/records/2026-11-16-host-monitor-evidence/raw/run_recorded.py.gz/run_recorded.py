import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument("--timeout", type=float, default=300)
parser.add_argument("name")
parser.add_argument("command", nargs=argparse.REMAINDER)
args = parser.parse_args()
command = args.command[1:] if args.command[:1] == ["--"] else args.command
output = Path(__file__).resolve().parent
environment = dict(os.environ, CARGO_TARGET_DIR=str(
    Path.cwd() / "work/recovery-batch-integration-20261115/target"))
started = time.monotonic()
with (output / (args.name + ".log")).open("xb") as log:
    process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT,
                               env=environment, start_new_session=True)
    timed_out = False
    try:
        exit_code = process.wait(timeout=args.timeout)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            exit_code = process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            exit_code = process.wait()
receipt = {"command": command, "cwd": str(Path.cwd()), "exit": exit_code,
           "seconds": round(time.monotonic() - started, 3),
           "timed_out": timed_out, "reaped": True}
with (output / (args.name + ".json")).open("x") as stream:
    json.dump(receipt, stream, indent=2)
    stream.write("\n")
print(json.dumps(receipt), flush=True)
raise SystemExit(0 if exit_code == 0 else 1)
