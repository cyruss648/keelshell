"""Bind the completed gate to its frozen engineering paths and actual test names."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    receipt = json.loads((BASE / "full-gate-r3.json").read_text())
    assert receipt["exit"] == 0 and receipt["reaped"] and not receipt["timed_out"]
    freeze = json.loads((BASE / "final-inputs-r6.json").read_text())
    actual_paths = {
        name.decode()
        for name in subprocess.check_output(
            ["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"],
            cwd=ROOT,
            timeout=30,
        ).split(b"\0")
        if name and not name.startswith(b"docs/") and (ROOT / name.decode()).is_file()
    }
    assert actual_paths == {row["path"] for row in freeze["inputs"]}
    for row in freeze["inputs"]:
        data = (ROOT / row["path"]).read_bytes()
        assert len(data) == row["bytes"] and digest(data) == row["sha256"], row["path"]
    aggregate = "".join(
        f"{row['path']}\0{row['sha256']}\n" for row in freeze["inputs"]
    ).encode()
    assert digest(aggregate) == freeze["aggregate_sha256"]

    log_bytes = (BASE / "full-gate-r3.log").read_bytes()
    log = log_bytes.decode()
    stages = [line for line in log.splitlines() if line.startswith("Running: ")]
    assert len(stages) == 7, stages
    assert "Dependency version policy: passed" in log
    workspace = log.split("Running: cargo test --workspace ", 1)[1]
    workspace = workspace.split('"phase": "after-workspace-tests"', 1)[0]
    counts = {"rust": {"passed": 0, "failed": 0, "ignored": 0},
              "rustdoc": {"passed": 0, "failed": 0, "ignored": 0}}
    section = "rust"
    suites = []
    target = None
    for line in workspace.splitlines():
        if line.lstrip().startswith("Doc-tests "):
            section = "rustdoc"
            target = line.strip()
        elif line.lstrip().startswith("Running "):
            section = "rust"
            target = line.strip()
        match = re.fullmatch(
            r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;.*",
            line,
        )
        if match:
            result = dict(zip(("passed", "failed", "ignored"), map(int, match.groups())))
            for key, value in result.items():
                counts[section][key] += value
            suites.append({"kind": section, "target": target, **result})
    assert counts["rust"]["passed"] > 0 and counts["rust"]["failed"] == 0
    assert counts["rustdoc"]["passed"] > 0 and counts["rustdoc"]["failed"] == 0
    expected = json.loads((BASE / "expected-new-default-tests-r1.json").read_text())
    passed_names = re.findall(r"^test (\S+) \.\.\. ok$", workspace, flags=re.MULTILINE)
    assert len(expected["names"]) == expected["count"] == len(set(expected["names"]))
    for name in expected["names"]:
        assert passed_names.count(name) == 1, (name, passed_names.count(name))

    python_stage = log.split("Running: cargo fmt ", 1)[0]
    runs = re.findall(r"^Ran (\d+) tests? in .*$", python_stage, flags=re.MULTILINE)
    skips = re.findall(r"^OK \(skipped=(\d+)\)$", python_stage, flags=re.MULTILINE)
    assert len(runs) == 1 and len(skips) <= 1
    helper_runs = re.findall(r"^Ran (\d+) tests? in .*$", workspace, flags=re.MULTILINE)
    python_run = int(runs[0])
    python_skips = int(skips[0]) if skips else 0
    result = {
        "schema": 1,
        "gate": receipt,
        "log_sha256": digest(log_bytes),
        "final_inputs": "final-inputs-r6.json",
        "input_count": freeze["count"],
        "aggregate_sha256": freeze["aggregate_sha256"],
        "complete_paths_and_hashes_match_after_gate": True,
        **counts,
        "python": {"run": python_run, "passed": python_run - python_skips,
                   "skipped": python_skips},
        "python_helpers_run": list(map(int, helper_runs)),
        "new_default_rust_tests": expected["count"],
        "new_default_rust_names": expected["names"],
        "all_new_default_rust_names_passed_exactly_once": True,
        "format": "PASS",
        "strict_clippy": "PASS",
        "dependency_x_y_policy": "PASS",
        "ai_controller_groups": ["readiness", "observer", "small-stack"],
        "stages": stages,
        "suites": suites,
        "preserved_previous_gates": {
            "r1": "exit 1 at test-only Clippy assertions; unchanged",
            "r2": "exit 1 at disk fixture guard matching owned Darwin child cleanup; unchanged",
        },
        "native_desktop_acceptance": "NOT_RUN",
    }
    with (BASE / "final-gate-summary-r3.json").open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(json.dumps({key: value for key, value in result.items()
                      if key not in ("suites", "stages", "new_default_rust_names")}))


if __name__ == "__main__":
    main()
