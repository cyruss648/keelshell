# KeelShell Kit 0.10 固定包非作者原生证据复核 — r2

日期：2026-11-16（Asia/Shanghai）。复核方式：严格只读、独立文件审阅；**独立构建 0、测试 0、GUI 操作 0、应用启动 0、网络探测 0、容器操作 0**。只在 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-review-20261116` 写报告和摘要。

**结论：限定批准 `APPROVE_LIMITED`；完整原生验收及发行 `HOLD`。P0=0、P1=0、P2=1、P3=0。** 唯一确认产品发现是父已报告的英文顶栏右端裁切，本次已从原图独立确认。批准只覆盖下述已观察状态和证据绑定，不能替代完整原生重放、平台验收或后续 UI 修复验收。

## 固定身份与原件更正

- 源码/包固定提交：`3c331c1cc3cc428c33c606b9af578057325871b9`。源码内容均通过 `git show --no-textconv 3c331c1cc3cc428c33c606b9af578057325871b9:<path>` 获取；逐项核对 engineering-inputs-r1.json 的 **719/719 个唯一工程路径，字节 SHA-256 mismatch=0**。记录内集合摘要为 `f0f64a6629b2441d63eef1e801189eaef69dd848aea0039eef4d09ff143b5164`；本次逐 blob 核对，不冒称重跑作者门禁。
- app 实际文件 SHA-256：`f78cdfd3446bea3a40e3b390c4aa29af1d480c2a45c452118fc81f480971b790`；MCP：`5166352519c48c15f2d02db8986c4d9301ccd8e0d055c736cf9471bd88ce584b`。[清单](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/package-r1/package-manifest.json:2) 中 5 个文件全部重新只读散列，5/5 相等；[进程身份](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/native-process-r1.json:2) 记录 PID 33358、PPID 33356、出生时间 2026-11-16 17:10:01、同一 app 路径/哈希/源码提交。
- 直接读取包字节：GUI 与 MCP 均 ARM64 Mach-O executable，macOS `LC_BUILD_VERSION minos=15.0.0 / SDK=27.2.0`，Info.plist 最低系统 `15.0` 一致。这里只是静态结构核对。清单明确 `installed=false`、`signed_by_packaging_script=false`，且打包脚本不执行原生验收。
- `ui/` 全部 **19 张图（02–20）与 21 份 AX（01–21）**已读；01/21 本来只有 AX，没有对应图片。本次不是仅抽取最低要求的帧。
- **19 个 `.png` 文件的真实字节格式全部为 JPEG，真实尺寸全部为 2880×1866。** 文件头均按 JPEG magic 识别，并逐一执行只读 `/usr/bin/sips -g format -g pixelWidth -g pixelHeight <原路径>`，19/19 均 `format: jpeg / pixelWidth: 2880 / pixelHeight: 1866 / exit 0`。图片查看器按真实格式解码，查看时自动缩放不改变原件；不把栅格像素推定为 GPUI 逻辑 viewport。扩展名/格式差异是 CUA 原件保存形式，**不计产品缺陷**；没有转码、重命名、另存或改动输入图像。
- 初版曾未校验格式，按 PNG 固定偏移产生无效 `png_dimensions`。该错误由本复核造成，已更正；初版原字节保留为 [summary-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-review-20261116/summary-r1.json)（16,320 bytes，SHA-256 `ccda49af162b794163df9174533c6ac0e7945e6ccf3e6de3cac14961e8b8f1a4`，仍是 `IN_PROGRESS` 历史件）。其中尺寸字段和状态不能作为最终结论；[summary-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-review-20261116/summary-r2.json) 是更正后的完整摘要，不回写 r1。

## 发现

| 等级 | 数量 | 结论 |
| --- | ---: | --- |
| P0 | 0 | 本次证据范围内未发现 |
| P1 | 0 | 本次证据范围内未发现 |
| P2 | 1 | P2-01：固定包英文工作区顶栏右端裁切，OPEN |
| P3 | 0 | 本次证据范围内未发现 |

**P2-01 — 英文顶栏没有完整落在窗口内。** [原图 15](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/15-lavender-en-files.png)、[原图 18](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/18-lavender-en-rule-editor.png)、[原图 19](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/19-lavender-en-dynamic-rule.png) 均可直接看到顶栏右侧 Themes 控件只露开头，后面的语言切换没有完整进入画面。该现象发生于本次雾紫浅色英文工作区、AI 侧栏显示的三种状态。影响是可见设置入口不完整，正常发现和点击使用受损；**不声称 AX 节点消失，也不声称所有键盘/AX 路径不可达**。三份对应 AX 第 18–23 行仍包含 Workspace settings、Themes and appearance 和 Switch language。

固定源码 `3c331c1cc3cc428c33c606b9af578057325871b9:crates/keelshell-app/src/workspace/view.rs` 的 1172–1185 行保留非紧凑英文标签，1243–1252 行工具组 `flex_shrink_0()`，1302–1335 行将设置组排到尾部，1759–1762 行仅按宽度选紧凑模式。它们与截图溢出现象一致，是定位线索；本次没有重放布局或将其归因为上游 Kit 的缺陷。父已声明另片修复，旧包此发现仍开放；后续源码、测试或新包不能把旧图重新签成完整通过。

`3c331c1cc3cc428c33c606b9af578057325871b9:crates/keelshell-app/src/workspace/view.rs:1243–1252`

```text
1243:         let toolbar_group = |id: &'static str, label_zh: &'static str, label_en: &'static str| {
1244:             let group = div()
1245:                 .id(id)
1246:                 .test_support()
1247:                 .role(accesskit::Role::Group)
1248:                 .aria_label(t(cx, label_zh, label_en))
1249:                 .flex_shrink_0()
1250:                 .flex()
1251:                 .items_center()
1252:                 .gap_1();
```

`3c331c1cc3cc428c33c606b9af578057325871b9:crates/keelshell-app/src/workspace/view.rs:1759–1762`

```text
1759:         // Keep the brand at the wide breakpoint, but use compact action labels
1760:         // at the breakpoint itself so every group remains inside the toolbar.
1761:         let compact_toolbar = viewport.width <= px(1280.);
1762:         let show_brand = viewport.width >= px(1280.);
```

## 全部原始 UI 逐项核对

表内图片链接保留原 `.png` 文件名，实际格式均为 JPEG；AX 链接带精确锚点行。图与 AX 的角色、文案、值及画面可见性分别核对，AX 枚举到的离屏控件不直接算可见。

| 编号 / 原件 | 直接观察 | 允许结论的边界 |
| --- | --- | --- |
| 01 无图片原件 · [AX](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/01-hostkey-review.ax.txt:8) | 只有 AX；显示可信指纹核对提示、收到的 SHA256 指纹和取消/信任后重连按钮，指纹与 fixture-hostkey-r1.json 一致。 | 没有对应截图或点击事件原始记录；不签 host key 变更拒绝场景。 |
| 02 [图 02](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/02-frost-files.png) · [AX](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/02-frost-files.ax.txt:42) | 霜白浅色中文；SSH 已连接，终端提示含自有容器 ID 前缀；本地 fixture-local.txt 与远端 /home/fixture/fixture.txt 同时可见。AX 63–95 对应目录和条目。 | 仅列目录；队列计数均 0，不签上传、下载或写入。 |
| 03 [图 03](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/03-frost-ai.png) · [AX](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/03-frost-ai.ax.txt:10) | 霜白中文 AI 草稿名称 aXb 在输入框及左侧列表可见，AX Value 同为 aXb；正文处于顶部。 | 仅最终 ASCII 状态，不能独立还原按键序列。 |
| 04 [图 04](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/04-frost-ai-options.png) · [AX](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/04-frost-ai-options.ax.txt:10) | 仍是 aXb 草稿及顶部请求协议/认证区域，固定取消/应用可见。 | 该图没有展示正文下部已滚到；文件名 options 不代替实际画面。 |
| 05 [图 05](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/05-frost-ai-scroll.png) · [AX](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/05-frost-ai-scroll.ax.txt:10) | 顶部布局与 04 基本相同；没有可确认的正文滚动位移。 | 父报告轮滚数次无可见变化；没有独立事件命中/滚动增量记录，不判实现 bug，也不签轮滚通过。 |
| 06 [图 06](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/06-frost-ai-drag.png) · [AX](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/06-frost-ai-drag.ax.txt:40) | 与 05 相比正文已移到上下文窗口、输出上限、推理/采样、请求头及代理区；滚动条滑块下移，固定底栏仍可见。 | 结合父报告，可认可一次拖 scrollbar 后的视口变化；不能外推轮滚、键盘或所有滚动路径。 |
| 07 [图 07](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/07-frost-ai-header.png) · [AX](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/07-frost-ai-header.ax.txt:53) | 新增一个空请求头行；PNG 可见名称、临时值/环境引用/凭据库引用、删除、秘密值输入；AX 53–68 还包含加密保存/清除等控件。 | 仅展开/新增草稿行；AX 中存在的更低控件不等于全部在 PNG 中可见，不签请求发送或秘密持久化。 |
| 08 [图 08](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/08-frost-tunnels.png) · [AX](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/08-frost-tunnels.ax.txt:60) | 霜白中文隧道页；连接仍在，临时本地端点 127.0.0.1:0 → 127.0.0.1:22；未绑定保存连接，New 禁用。 | 空隧道运行列表；未启动转发。 |
| 09 [图 09](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/09-graphite-appearance.png) · [AX](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/09-graphite-appearance.ax.txt:9) | 曜石中文外观页，AX 明确曜石已应用/深色；深色表面和琥珀强调与图一致。 | 只覆盖此选择状态，未覆盖曜石全部明暗模式。 |
| 10 [图 10](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/10-graphite-tunnels.png) · [AX](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/10-graphite-tunnels.ax.txt:60) | 曜石中文隧道及 AI 侧栏实际显示；SSH 连接仍在，端点和空运行状态与 08 对应。 | 未启动/停止隧道；相同 AX 不能证明相同像素或相同主题。 |
| 11 [图 11](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/11-graphite-files.png) · [AX](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/11-graphite-files.ax.txt:96) | 曜石中文双文件列表及远端编辑器；内容 KeelShell native fixture，AX 110 为 25 字节、UTF-8、无 BOM、LF，与容器种子一致。 | 支持远端文件读取到编辑草稿；没有保存、差异应用或其他编码读写证据。 |
| 12 [图 12](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/12-graphite-ai.png) · [AX](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/12-graphite-ai.ax.txt:8) | 曜石中文 AI 配置为空列表，PNG 有点击新建配置的空状态说明；取消/应用存在。 | 与先前 aXb 草稿未应用一致；单张空态不能证明所有取消路径或磁盘回滚。 |
| 13 [图 13](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/13-graphite-ai-draft.png) · [AX](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/13-graphite-ai-draft.ax.txt:9) | 曜石中文新建未命名 AI 草稿，完整顶部字段和固定取消/应用底栏可见。 | 没有应用或 provider 连接结果。 |
| 14 [图 14](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/14-lavender-en-appearance.png) · [AX](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/14-lavender-en-appearance.ax.txt:10) | 雾紫英文外观页，AX 明确 Lavender 已应用/Light；三个主题卡片与英文说明可见。 | 仅雾紫浅色英文该状态，不等于全主题/语言/尺寸矩阵。 |
| 15 [图 15](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/15-lavender-en-files.png) · [AX](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/15-lavender-en-files.ax.txt:42) | 雾紫英文 SSH/SFTP 文件与 UTF-8 草稿仍在；右侧 AI 侧栏可见。英文顶栏右端在整张截图边界被裁切。 | P2-01；Themes 只露开头，语言入口图内未见完整显示，尽管 AX 20–23 保留这些控件。 |
| 16 [图 16](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/16-lavender-profile-tab.png) · [AX](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/16-lavender-profile-tab.ax.txt:17) | 雾紫英文连接编辑表单；Name/Host/Username/Port/Tags 等有 AX。底部认证按钮 AX 为 Password authentication；PNG 只到被底栏截住的 Tags。 | 认证控件在 PNG 视口外；Tab 焦点链及可见滚动尚未验收。 |
| 17 [图 17](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/17-lavender-profile-auth-attempt.png) · [AX](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/17-lavender-profile-auth-attempt.ax.txt:17) | 同一 profile 的 AX 已变为 Agent / key authentication，并增加 Private key path（AX 18）；PNG 认证区域仍在视口外。 | 与父报告 Tab+Return 切换一致，但 AX focused 仍是窗口根；不能从这两张图证明认证控件被滚动显示或鼠标可达。 |
| 18 [图 18](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/18-lavender-en-rule-editor.png) · [AX](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/18-lavender-en-rule-editor.ax.txt:67) | 保存的 Native fixture 连接处于 Connected；新建 Local 规则编辑器实际显示名称、bind/目标字段、Disabled、Cancel/Review save。AX 75 Enable rule=off。 | P2-01 同样可见；只到规则草稿，没有保存审核确认或实际启动。 |
| 19 [图 19](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/19-lavender-en-dynamic-rule.png) · [AX](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/19-lavender-en-dynamic-rule.ax.txt:67) | 名称为 Native rule draft，Dynamic SOCKS5 选中，目标地址/端口输入消失，出现无预设目标说明；Enable rule 仍 off，取消和审核保存可见。 | P2-01 同样可见；不等于 SOCKS5 网络链路通过。 |
| 20 [图 20](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/20-lavender-en-ai-draft.png) · [AX](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/20-lavender-en-ai-draft.ax.txt:9) | 雾紫英文 AI 新建未命名草稿，英文名称/请求协议/认证等字段、固定 Cancel/Apply 实际可见。 | 没有 provider 认证、模型发现、测试连接或请求往返结果。 |
| 21 无图片原件 · [AX](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/ui/21-final-cancelled-drafts.ax.txt:72) | 只有 AX；规则编辑器与 AI 配置模态均不在树内，恢复隧道页，文本 This connection has no named rules yet；SSH Native fixture 仍 Connected。 | 可认可取消后的 UI 末态；没有对应 PNG、最终 AI 目录重新打开或磁盘快照，不能签完整持久回滚/正常退出。 |

## 关键证据的限界

**主题/语言。** 霜白浅色中文 02–08 的白/蓝表面、中文业务标签与固定源码默认 `ThemeId=frost` 及 registry 的 Frost 定义一致；没有独立拍摄霜白选择卡，主题族认定使用快照序列、色彩和固定源码交叉支持。曜石深色中文在 09 的选中状态和 10–13 实际页面同时有证据；雾紫浅色英文在 14 的选中状态和 15–20 实际页面同时有证据。不是三主题所有明暗模式、所有语言组合或所有尺寸通过。

**真实 SSH/SFTP。** [自有 fixture 记录](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/fixture-container-r1.json) 的容器 ID `acb312c8798c…` 与终端提示吻合；端口 `33183`、用户 fixture、回环绑定在连接/进程外部探针中一致。[OpenSSH 探针回执](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/fixture-openssh-probe-r1.json:2) 为历史 `0/reaped`，对应 [原始 stdout](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/fixture-openssh-probe-r1.log) 的两行为 `owned native fixture`、`/home/fixture`，35 bytes；host key 原始 fingerprint 与 AX 01 相同。[fixture 定义](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/container-context/Containerfile:2) 种子为 `KeelShell native fixture\n`，[SFTP 配置](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/sshd-public/sshd_config:17) 设置真实 internal-sftp；02/11/15 的文件列表及 11/15 编辑器/AX 对应 25-byte UTF-8 内容。可限定认可自有 SSH 连接、SFTP 列目录与远端读入草稿；本复核没有连接任何机器，也没有独立读服务器状态。上传/下载完成数为 0，没有文件保存完成链路。

**ASCII 输入。** 03–07 的名称 `aXb` 仅证明该字段最终显示并经 AX 暴露这个 ASCII 草稿，且在视口变化后仍保留；静态末态本身不能独立重建输入/左移/插入的每一步。固定 `i18n.rs:103–109` 将组件 locale 和 LayoutDirection 与所选语言同步，是实现意图的静态依据，**不是 IME、RTL/双向文本或 VoiceOver 完整验收**。21 份 AX 的 focused UI 都只报告窗口根，未提供真实屏幕阅读器朗读、输入法 composing/commit 或完整控件焦点轨迹。

**滚动与请求头。** 03/04/05/06 的 AX **逐字节相同**（SHA-256 `09774f1c175df6b54c57b75323d2d9570a113d6408342f14957d3ded4df868e2`），但 05→06 的图片正文位置明显不同；AX 列出全部语义节点不能替代像素视口判断。父报告 wheel 多次未见变化、拖 AI scrollbar 成功，与现有图片序列一致；只认可该次拖动产生可见位移。固定 `ai_settings/view.rs:405–431` 将 overflow viewport 和 vertical scrollbar 绑定到同一个 `form_scroll`，源码已经有滚动实现；缺少 wheel 命中、方向、增量、设备/边界信息，**不能直接签 scroll 实现 bug，也不能签轮滚全通过**。07 图片和 AX 53–68 证明新增空 header 行，未配置真实秘密或发起模型请求；AX 中列出的更低操作不等于画面已全部显示。

**profile 认证与焦点。** 16/17 的 auth 在正文可见底部以外，图片没有显示认证按钮/私钥字段；AX `Password authentication`→`Agent / key authentication` 以及新增 `Private key path` 支持状态确实切换。Tab+Return 操作经过来自父提供的说明，本复核独立操作为 0；AX focused 仍是窗口根，不把它当完整焦点链证据。固定 `workspace/modals.rs:47–55` 已有正文 `overflow_y_scroll()`，825–851 行把 auth 放在 Tags 后、916 行使用 680 逻辑像素高度；**记录离屏和可见滚动未验收，不归因于“缺少 scroll 实现”**。

**规则编辑与取消。** 18 的 Local 草稿与 19 的 Dynamic 草稿有真实图片/AX：类型选择变化、目标字段隐藏、名称输入、Enabled=false、Cancel/Review save 都对上。固定 `tunnels/rules.rs:799–806` 默认 disabled，1511–1555 行按 Dynamic 条件显示目标说明；`391–399` 的取消只清 review/editor，1691–1708 行将 Cancel 与 Review save 分别接线。21 AX 的无命名规则文本和编辑器消失支持取消后 UI 末态，不能证明磁盘持久回滚或实际转发启停。AI 方面，12 空配置与此前未应用 aXb 一致、20→21 支持模态已关闭；固定 `ai_settings/view.rs:473–489` 的 Cancel/Apply 分开，`ai_settings.rs:1219–1225` Close 取消 pending 操作和 vault 任务并发出 Close，而 Apply 在 1211 行另发事件。最终 AI 目录没有再次打开，不将全部取消路径、后台持久化和退出审核一并签过。

## 构建、打包、进程与清理回执

下表是**父已有执行记录的独立审阅**，不是本复核执行次数。六份 `.log` 的实际字节数和 SHA-256 已分别与 JSON 比较，**6/6 一致**。

| 历史回执 | 原始结果 | 日志/关联核对 | 可认可范围 |
| --- | --- | --- | --- |
| [normal-release-build-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/normal-release-build-r1.json:2) | 0 / reaped；443.596 s；未超时/未中断 | 18,620 bytes；[构建原日志](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/normal-release-build-r1.log:555) 含 keelshell-app 实际编译，567 行 gpui-kit 0.10.0，568 行 release finished | 普通 `--release --locked` app/MCP 构建回执；不是测试或完整 native acceptance |
| [package-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/package-r1.json:2) | 0 / reaped；0.273 s | [原日志](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/package-r1.log) 209 bytes，说明只 stage，没有安装/签名/发布/运行 | 此固定包的打包记录和 5/5 字节清单 |
| [inspect-package-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/inspect-package-r1.json:2) | 0 / reaped；0.263 s | [原日志](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/inspect-package-r1.log:24) 3,649 bytes；minos、结构及动态依赖记录；与本次直接读取 Mach-O/Plist 一致 | 静态包结构，原日志 48 行仍明确 GUI acceptance separate |
| [fixture-image-build-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/fixture-image-build-r1.json:2) | 0 / reaped；16.776 s | 2,046 bytes，日志哈希一致；image ID 与运行/清理记录关联 | 自有 OpenSSH fixture 准备记录，不代替 app/native 验收 |
| [fixture-openssh-probe-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/fixture-openssh-probe-r1.json:2) | 0 / reaped；0.163 s | 35 bytes、可信 known_hosts/公钥路径、同一端点 | 自有 endpoint 外部 OpenSSH 可达记录；本次独立 SSH 执行 0 |
| [native-app-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/native-app-r1.json:2) | **241 / reaped**；active_processes=0；pipes_drained=true；未超时/未中断 | 0-byte app log 哈希一致；[退出请求](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/native-exit-request-r1.json:5) 明确 SIGTERM，关闭审核仅观察、没有经 GUI 确认 | 有界控制器收口；**绝不记正常退出 0** |

`native-app-r1.json.seconds=1474.1671073750003` 是整次运行时长，不是 SIGTERM→reaped 的退出延迟；原件没有单独测这个延迟。`241` 保持回执实值，不用正常构建的 0 覆盖退出结果。

[自有资源清理原件](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/kit010-native-20261116/owned-native-resource-cleanup-r1.json:1) 记录：同一容器 stop `--time 10` exit 0；同一 image rmi exit 0，随后 absent 检查分别 exit 1 且 `container_absent=true / image_absent=true`。两次 exit 1 是清理后的 absent 检查结果，不伪造为运行失败或成功 0。private 的 4 文件、runtime 的 11 文件已删除且 `exists_after=false`，本复核读取磁盘也确认这两个路径不存在。凭据正文未读取、复制或归档；没有重建 fixture/恢复 runtime，没有执行新的 Podman/信号/清理动作。容器/镜像 absent 结论来自指定清理回执，本次未重新查询 daemon。

## 保持 HOLD 的范围与交接

- **H01 — 英文顶栏完整布局和后续修复**：P2-01 在旧包仍开放；后续 view.rs/tests 改动和任何测试均不移签此包。
- **H02 — profile 底部认证区域的可见滚动、鼠标可达、Tab 完整焦点路径**：16/17 只有 AX 状态切换，PNG 未显示 auth；父报告 Tab+Return，不存在本复核动作重放。
- **H03 — 轮滚、触控板、键盘、边界、嵌套及全尺寸滚动**：05 无可见变化，06 拖动有变化；没有足够数据判定轮滚实现缺陷或完整通过。
- **H04 — IME、RTL、双向文本、组合字符、完整输入交互和 VoiceOver**：aXb 是 ASCII 末态；原始 AX focused 均为窗口根，没有输入法组合/屏幕阅读器朗读或实际焦点序列记录。
- **H05 — 全主题明暗/系统模式、语言和尺寸/缩放/多窗口矩阵，以及 Windows/Linux 原生桌面**：仅当前 macOS arm64 包所拍摄的三个主题/语言状态，屏幕栅格尺寸不能替代逻辑 viewport 或其他平台。
- **H06 — SSH host key 变化 fail-closed、跳板/代理/认证完整矩阵；SFTP 上传下载、保存、合并、其他编码和恢复**：已有证据局限可信指纹提示、fixture 连接、列目录及 UTF-8 读取；队列完成 0、无保存链路回执。
- **H07 — 隧道保存审核确认、实际本地/远程/SOCKS5 转发、启停/冲突/恢复**：18/19 是编辑草稿，21 是取消末态，未观察启动流量。
- **H08 — AI provider 认证、模型发现、请求头发送、秘密存储/清除和零出站保证**：只有配置 UI 和空秘密字段，不能由控件文案/disabled 状态证明协议往返或全局无请求。
- **H09 — 取消的磁盘持久回滚、关闭审核确认、正常退出 0**：12/21 是有限 UI 证据，private/runtime 已按授权删除；app 最终真实回执为 SIGTERM 后 241/reaped。
- **H10 — 签名、公证、覆盖安装、发行及完整产品验收**：manifest installed=false / signed_by_packaging_script=false，且 native acceptance 不由打包脚本执行；本次不运行发行门禁。

## 只读边界、保存校验与最终签署

- 本次独立 unit/integration/GPUI/native tests：**run 0 / passed 0 / failed 0 / ignored 0**；构建、fmt、Clippy、依赖门禁均 0，GUI/应用执行和 CUA 调用均 0。图像本地解码、`sips -g`、Git blob 散列和文件读取只是证据核对。没有调用项目 `run_command.py`、打包/检查脚本或任何已构建测试二进制。
- 输出只有本目录的 `review-r2.md`、`summary-r2.json` 和原字节保留的 `summary-r1.json`。源码、测试、受保护文档、输入原件、Cargo target、Git index/分支/远端均未由本复核修改。没有写入目录外临时报告、修改 memory、提交或推送。
- 证据目录初次完整散列和收口复读都是 **70 文件 / 64,616,624 bytes**，路径/大小/字节摘要新增、删除或变化 **0**；全部每文件 SHA-256 和 JPEG 解码结果位于 r2 摘要。r1 历史 SHA-256 再读保持 `ccda49af162b794163df9174533c6ac0e7945e6ccf3e6de3cac14961e8b8f1a4`。
- HEAD 起止均为 `3c331c1cc3cc428c33c606b9af578057325871b9`；过程中已看到后续 `workspace/view.rs` 与 `workspace/tests/workbench_layout.rs` 工作树修改，以及父任务新增/修改的文档。它们**不在本包签署范围**；没有读取其后续源码字节替代固定 Git 源码，也没有运行后续测试。摘要保留起止 `git status --short` 以区分范围。
- 读取工具有过路径检索问题：首次列不存在的复核目录、一次 zsh 未引用通配符拒绝、一次 Git grep 无匹配返回 1；均属于只读检索状态，已改为精确路径/提交读取，不是产品或测试失败。元数据格式误判已作为 r1→r2 更正历史明确保留。
- 历史 memory 只用于固定 SHA/报告边界习惯；本报告的当前身份、图像、退出及清理事实全部来自本次指定原件/只读核对。适用了 Rust 最佳实践技能的相关静态审阅指导；用户的“不构建、不测试、不 GUI”优先，技能命令建议执行 0。

**最终建议：可按本报告逐项范围归档并引用这份固定包原生证据；完整 macOS 验收、跨平台验收和发行继续 HOLD。** P2-01 留在旧包名下，后续修复另片、另源码/包/证据验收；profile 离屏、wheel、IME/RTL/VoiceOver、持久化与正常退出的未知项继续开放。非作者复核工作已完成，可由父关闭；没有遗留自有运行进程/容器/新 GUI 会话。
