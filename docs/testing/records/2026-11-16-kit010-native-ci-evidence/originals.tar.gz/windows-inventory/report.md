# Windows CI 库存核对报告（严格只读、不构建）

- checkout / 源码：`3c331c1cc3cc428c33c606b9af578057325871b9`；开始及结束 HEAD 相同。
- Quality run `43834927464 / attempt 1`，Windows job `133189079055`，`native (windows-2025)`。
- 保存的 job 回执为 `completed/failure`，2026-11-16 08:53:28–09:17:10 UTC（北京时间 16:53:28–17:17:10）。仅核对已保存证据，没有查询实时 CI。
- 结论：批准本报告的窄范围执行证据；完整 Windows gate 保持 HOLD。preflight `70/0/0`；原八项 app 归档 `7/1/0`；app 全 target `1325/4/2 ignored`。
- 本地 Cargo、构建、测试执行、CI rerun、push、清理均为 0。所有派生文件仅写入本报告所在目录。读取 RTK、AGENTS、HANDOFF；当前用户只读限制覆盖历史交付授权。

## 证据身份与行号

- 原日志：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-directory-rename-delivery-20261116/windows-job-log-r2.log`，SHA-256 `ebe06d619e5e309ee8b111c44da4e8cb67d2fc3791df23af67e59a20335174a9`。
- 去 ANSI 日志：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-directory-rename-delivery-20261116/windows-job-log-r2.clean.txt`，SHA-256 `822899e109390b3c1c7245fe6977916e25ee7e7934154a4833743ccd947a8fe6`。
- 两份日志均为 3,970 行；逐字节验证 raw 仅去 ANSI 后与 clean 完全相同，行号一一对应。下文 L 行号适用于二者。CI checkout SHA 见 L92、L98、L160。
- job 回执：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-directory-rename-delivery-20261116/windows-job-r1.json`（单行 JSON，身份、终态及各 step 均在 L1）。
- 持久压缩包：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/testing/records/2026-11-16-windows-directory-rename-evidence/originals.tar.gz`，SHA-256 `41701965edfeb7c3fa6a630a9085d5e83cf889f00ca0bb2728f6411ea347a0e0`，1,763,368 字节；与 manifest 及固定源码 Git blob 相同。
- 仅以 Python tarfile 在内存读取指定成员；没有调用 extract/extractall，没有整包落盘解压，没有执行包内脚本。

| 预期库存成员 | SHA-256 | 条目数 |
| --- | --- | ---: |
| `batch/windows-expected-inventory-r1.json` | `9852311c244565cff24d6bfbb928c04dd5076c20e456fe3219982418039eef91` | 70 |
| `batch/windows-app-archive-expected-r1.json` | `dcee96c17643d101bd9050eb3f038e559cc1d0838ce3f74b87b1fc56989bae07` | 8 |

- 两个预期成员与归档 manifest 的路径、字节数、SHA 完全相符。原件中的历史 `NOT_RUN` 状态保留；本报告提供新 job 的派生执行状态。
- 八份 source-r6 快照逐一与固定 Git 提交、当前工作区相符；检查脚本、workflow、相关测试及所有六个 Cargo manifest 也与固定提交相符。详见 provenance-r1.json。

## Preflight 70 名逐项核对

- 启动 L456；宣布 70 tests 于 L458；逐项结果 L459–L528；汇总 L530：`70 passed / 0 failed / 0 ignored / 0 measured / 0 filtered out / 0.71s`。
- 预期 70、观测 70、唯一名 70；missing 0、unexpected 0、duplicate 0。下面保留完整限定名，全部各执行一次。

| # | 测试完整名 | 实际状态 | 日志行 |
| ---: | --- | --- | ---: |
| 1 | `directory_records::tests::fragmented_query_batches_preserve_unicode_names_and_exclude_dot_entries` | PASS | 459 |
| 2 | `directory_records::tests::lone_surrogates_and_embedded_path_separators_are_rejected` | PASS | 460 |
| 3 | `directory_records::tests::name_budget_is_shared_across_all_native_query_batches` | PASS | 461 |
| 4 | `directory_records::tests::next_entry_offset_can_include_native_alignment_padding` | PASS | 462 |
| 5 | `directory_records::tests::odd_or_oversized_utf16_name_lengths_are_rejected` | PASS | 463 |
| 6 | `directory_records::tests::overlapping_or_out_of_bounds_entry_offsets_are_rejected` | PASS | 464 |
| 7 | `directory_records::tests::truncated_header_and_name_never_yield_partial_success` | PASS | 465 |
| 8 | `native_diagnostics::tests::native_failure_diagnostics_never_format_untrusted_error_messages` | PASS | 466 |
| 9 | `native_diagnostics::tests::native_failure_observation_preserves_the_original_typed_os_error` | PASS | 467 |
| 10 | `path::tests::absolute_drive_and_extended_drive_have_identical_literal_components` | PASS | 468 |
| 11 | `path::tests::controls_streams_and_visual_path_disguises_are_rejected` | PASS | 469 |
| 12 | `path::tests::drive_relative_and_normalizing_path_spellings_are_rejected` | PASS | 470 |
| 13 | `path::tests::drive_root_is_a_directory_capability_without_a_fabricated_name` | PASS | 471 |
| 14 | `path::tests::filename_bound_counts_utf16_units_instead_of_utf8_bytes` | PASS | 472 |
| 15 | `path::tests::full_path_review_bound_is_enforced_before_native_access` | PASS | 473 |
| 16 | `path::tests::portable_aliases_fold_expanding_and_final_sigma_case_forms` | PASS | 474 |
| 17 | `path::tests::reserved_dos_names_are_rejected_with_extensions_and_superscript_aliases` | PASS | 475 |
| 18 | `path::tests::unc_and_device_namespaces_do_not_fall_back_to_drive_access` | PASS | 476 |
| 19 | `windows::security::tests::bounded_sid_parser_rejects_truncation_revision_and_subauthority_overflow` | PASS | 477 |
| 20 | `windows::security::tests::creation_descriptor_retains_sid_and_acl_ownership_across_moves` | PASS | 478 |
| 21 | `windows::security::tests::observation_detects_real_dacl_protection_changes` | PASS | 479 |
| 22 | `windows::security::tests::observation_detects_real_dacl_rights_changes` | PASS | 480 |
| 23 | `windows::security::tests::observation_encoding_detects_owner_and_group_sid_changes` | PASS | 481 |
| 24 | `windows::security::tests::observation_encoding_distinguishes_absent_null_and_empty_dacls` | PASS | 482 |
| 25 | `windows::security::tests::observation_encoding_rejects_excessive_entry_bytes` | PASS | 483 |
| 26 | `windows::security::tests::observation_excludes_acl_free_space` | PASS | 484 |
| 27 | `windows::security::tests::observation_excludes_sacl_and_pointer_representation_control_bits` | PASS | 485 |
| 28 | `windows::security::tests::observation_is_stable_across_requeries_and_duplicated_handles` | PASS | 486 |
| 29 | `windows::security::tests::observation_remains_bound_to_the_handle_after_path_replacement` | PASS | 487 |
| 30 | `windows::security::tests::private_creation_does_not_inherit_a_broad_parent_dacl` | PASS | 488 |
| 31 | `windows::security::tests::private_directory_is_protected_with_object_and_container_inheritance` | PASS | 489 |
| 32 | `windows::security::tests::private_file_is_verified_before_the_first_content_write` | PASS | 490 |
| 33 | `windows::security::tests::private_snapshot_rejects_a_truncated_or_extended_allow_entry` | PASS | 491 |
| 34 | `windows::security::tests::private_snapshot_rejects_an_owner_mismatch` | PASS | 492 |
| 35 | `windows::security::tests::private_snapshot_rejects_inherited_and_inherit_only_flags` | PASS | 493 |
| 36 | `windows::security::tests::private_snapshot_rejects_unknown_ace_types` | PASS | 494 |
| 37 | `windows::security::tests::security_queries_require_read_control_on_the_actual_handle` | PASS | 495 |
| 38 | `windows::security::tests::verify_private_rejects_a_directory_without_inheritance_flags` | PASS | 496 |
| 39 | `windows::security::tests::verify_private_rejects_a_null_dacl` | PASS | 497 |
| 40 | `windows::security::tests::verify_private_rejects_a_real_deny_ace` | PASS | 498 |
| 41 | `windows::security::tests::verify_private_rejects_a_single_everyone_allow_entry` | PASS | 499 |
| 42 | `windows::security::tests::verify_private_rejects_an_additional_everyone_allow_entry` | PASS | 500 |
| 43 | `windows::security::tests::verify_private_rejects_an_empty_dacl` | PASS | 501 |
| 44 | `windows::security::tests::verify_private_rejects_an_unprotected_dacl` | PASS | 502 |
| 45 | `windows::security::tests::verify_private_rejects_insufficient_owner_rights` | PASS | 503 |
| 46 | `windows::tests::complete_private_tree_is_published_through_its_retained_root` | PASS | 504 |
| 47 | `windows::tests::component_relative_operations_reject_every_escape_before_native_io` | PASS | 505 |
| 48 | `windows::tests::directory_cursor_keeps_the_held_identity_when_its_original_path_is_rebound` | PASS | 506 |
| 49 | `windows::tests::directory_cursor_preserves_private_dacl_and_rejects_regular_files` | PASS | 507 |
| 50 | `windows::tests::directory_enumeration_continues_after_a_full_native_query_buffer` | PASS | 508 |
| 51 | `windows::tests::directory_no_replace_syscall_preserves_other_empty_directories` | PASS | 509 |
| 52 | `windows::tests::directory_publication_retains_the_source_rebound_before_its_rename_lease` | PASS | 510 |
| 53 | `windows::tests::directory_rename_buffers_cover_one_and_255_utf16_unit_names` | PASS | 511 |
| 54 | `windows::tests::directory_rename_lease_preserves_private_kind_access_and_share_contracts` | PASS | 512 |
| 55 | `windows::tests::directory_rename_lease_retains_the_source_rebound_after_acquisition` | PASS | 513 |
| 56 | `windows::tests::directory_stamp_survives_sibling_writes_but_distinguishes_replacement` | PASS | 514 |
| 57 | `windows::tests::drive_chain_keeps_every_literal_ancestor_and_reopens_the_same_object` | PASS | 515 |
| 58 | `windows::tests::exclusive_create_preserves_an_existing_file_directory_and_case_alias` | PASS | 516 |
| 59 | `windows::tests::existing_private_entry_can_be_reopened_only_after_the_creation_writer_closes` | PASS | 517 |
| 60 | `windows::tests::file_rename_buffers_cover_one_and_255_utf16_unit_names` | PASS | 518 |
| 61 | `windows::tests::held_file_publication_retains_identity_and_leaves_no_old_name` | PASS | 519 |
| 62 | `windows::tests::opening_a_hard_linked_file_fails_instead_of_using_size_as_identity` | PASS | 520 |
| 63 | `windows::tests::private_directory_and_child_creation_do_not_rely_on_default_permissions` | PASS | 521 |
| 64 | `windows::tests::private_file_has_its_verified_dacl_before_the_first_content_write` | PASS | 522 |
| 65 | `windows::tests::private_file_sharing_allows_readback_and_rejects_other_writers_and_delete_openers` | PASS | 523 |
| 66 | `windows::tests::publication_into_a_retained_private_target_directory_supports_files_and_directories` | PASS | 524 |
| 67 | `windows::tests::reopened_directory_cursors_do_not_advance_or_restart_other_live_scans` | PASS | 525 |
| 68 | `windows::tests::retained_object_rename_never_replaces_a_file_or_empty_directory` | PASS | 526 |
| 69 | `windows::tests::security_observations_are_opaque_in_public_debug_output` | PASS | 527 |
| 70 | `windows::tests::simultaneous_enumerations_have_independent_native_scan_positions` | PASS | 528 |

- 本批三新例位于 L510、L512、L513，全部 PASS。原四项目录发布回归位于 L504、L509、L511、L524，全部 PASS。

## 原八项 app 归档逐项核对

- 八个预期名均存在且各一条结果；`7 passed / 1 failed / 0 ignored / 0 missing`。不能把 preflight 成功或其余七项成功扩大为八项全部成功。

| # | 测试完整名 | 实际状态 | 日志行 |
| ---: | --- | --- | ---: |
| 1 | `files::transfer_tests::archive_tests::archive_cancel_and_selection_change_never_publish_an_old_approval` | PASS | 2947 |
| 2 | `files::transfer_tests::archive_tests::archive_changed_local_content_is_rejected_before_any_publication` | PASS | 2948 |
| 3 | `files::transfer_tests::archive_tests::archive_corrupt_download_and_existing_local_target_preserve_destination` | PASS | 2950 |
| 4 | `files::transfer_tests::archive_tests::archive_draft_change_and_retired_session_reject_review` | PASS | 2951 |
| 5 | `files::transfer_tests::archive_tests::archive_large_manifest_keeps_last_member_and_fixed_review_actions` | PASS | 2954 |
| 6 | `files::transfer_tests::archive_tests::archive_pending_write_cancel_retains_close_hold_across_another_verified_upload` | PASS | 2956 |
| 7 | `files::transfer_tests::archive_tests::archive_tar_gz_download_extract_reviews_empty_folders_and_publishes_new_tree` | FAIL | 2957 |
| 8 | `files::transfer_tests::archive_tests::archive_zip_upload_requires_confirmation_and_preserves_exact_binary_members` | PASS | 2958 |

- 唯一归档失败详情 L3869–L3872：`extracted bytes: Os { code: 3, kind: NotFound, ... }`，panic 经 `test_server.rs:43` 的通用 Checked helper 报出。
- 最小阶段映射：固定源码 `crates/keelshell-app/src/files/archive_tests.rs:414–417` 先确认操作、等待 idle，再读取 `nested/data.bin`；此次在该读取处失败。因此没有证据可将此例归类为 fixture 启动失败，也不能宣称解包/发布成功。其后空目录存在和关闭 hold 释放断言未到达。这里不推断根因。
- 整个 `files::transfer_tests::archive_tests` 模块实际 12 名，`11/1/0`；额外四名通过不抵消原八项中的失败。

## 其他已运行 Rust targets

| 阶段 / package / target | passed | failed | ignored | 启动行 | 汇总或完成行 |
| --- | ---: | ---: | ---: | ---: | ---: |
| `preflight / keelshell-platform / lib:keelshell-platform` | 70 | 0 | 0 | 456 | 530 |
| `workspace / keelshell-ai / lib:keelshell-ai` | 94 | 0 | 0 | 1593 | 1691 |
| `workspace / keelshell-ai / integration:discovery_http` | 20 | 0 | 0 | 1693 | 1717 |
| `workspace / keelshell-ai / integration:header_name_secrets_http` | 4 | 0 | 0 | 1719 | 1727 |
| `workspace / keelshell-ai / integration:known_secrets_http` | 5 | 0 | 0 | 1729 | 1738 |
| `workspace / keelshell-ai / integration:local_agent_cli` | 0 | 0 | 4 | 1740 | 1748 |
| `workspace / keelshell-ai / integration:local_agent_directory_process` | 15 cases PASS | 未输出 libtest 计数 | N/A | 1750 | 1806 |
| `workspace / keelshell-ai / integration:local_agent_process` | 全部断言/场景组 PASS，数量未报告 | 未输出 libtest 计数 | N/A | 1807 | 2468 |
| `workspace / keelshell-ai / integration:local_environment_independent` | 1 | 0 | 0 | 2469 | 2474 |
| `workspace / keelshell-ai / integration:provider_http` | 17 | 0 | 0 | 2476 | 2497 |
| `workspace / keelshell-ai / integration:request_options_http` | 19 | 0 | 0 | 2499 | 2523 |
| `workspace / keelshell-app / bin:keelshell-app` | 1325 | 4 | 2 | 2525 | 3898 |

- 两个 process target 在 `crates/keelshell-ai/Cargo.toml:29–35` 声明 `harness=false`。directory controller L1806 明确报告 15 cases passed；process controller L2468 报告全部 assertions/scenario groups passed，但未输出场景总数。两者均随后启动下一 target，没有失败出口；不伪造 libtest 数量。
- controller JSON 中预期取消的 `ok:false/error:Cancelled` 是负向场景结果，不能计为 libtest 失败。
- workspace 已完成的 9 个 libtest targets 合计 `1485 passed / 4 failed / 6 ignored`；另有上述两个自定义 harness 成功。该数仅为 app 失败前已运行部分。
- 若另加独立 preflight，日志内 libtest 合计 `1555/4/6`，共 1,565 条逐名结果；它不等于完整 workspace gate，也不含 Python 和两个自定义 harness。

## App 的全部四项失败

| 完整名 | 结果行 | 详情行 | 已观察结果（不重查根因） |
| --- | ---: | --- | --- |
| `files::transfer_tests::archive_tests::archive_tar_gz_download_extract_reviews_empty_folders_and_publishes_new_tree` | 2957 | 3869–3872 | extracted bytes: Os { code: 3, kind: NotFound, message: "The system cannot find the path specified." } |
| `files::transfer_tests::explicit_download_continuation_preserves_partial_bytes_until_confirmation` | 3050 | 3874–3879 | assertion left == right failed; complete byte arrays remain in the original log |
| `files::transfer_tests::fixture_isolation_tests::held_existing_local_resume_excludes_other_fixture_sync_without_mutation` | 3051 | 3881–3884 | UI condition timed out after 5s; gpui-kit-0.10.0/src/test.rs:608:13 |
| `files::transfer_tests::fixture_isolation_tests::retained_window_keeps_admission_after_normal_harness_drop` | 3052 | 3886–3889 | UI condition timed out after 8s; gpui-kit-0.10.0/src/test.rs:608:13 |

- app 宣布 1,331 tests（L2527）；逐名计数与汇总 L3898 完全一致：`1325 passed / 4 failed / 2 ignored / 657.01s`，无 duplicate 或缺失结果。
- 四项失败列表 L3892–L3896；Cargo workspace 命令退出 101（L3901），check.py/CI step 退出 1（L3903）。不能把旧失败与当前不同失败互相移签。

## Rust ignored 的六个精确名字

| package / target | 测试名 | 行 | 原始原因 |
| --- | --- | ---: | --- |
| `keelshell-ai / local_agent_cli` | `installed_claude_ask_uses_no_tools_and_cleans_isolation` | 1743 | opt-in: set KEELSHELL_CLAUDE_EXECUTABLE to installed native Claude; loopback service only |
| `keelshell-ai / local_agent_cli` | `installed_claude_selected_directory_excludes_project_context_hooks_mcp_and_tools` | 1744 | opt-in native Claude and trusted launcher; owned malicious project and loopback service |
| `keelshell-ai / local_agent_cli` | `installed_codex_ask_uses_no_tools_and_cleans_isolation` | 1745 | opt-in: set KEELSHELL_CODEX_EXECUTABLE to installed native Codex; loopback service only |
| `keelshell-ai / local_agent_cli` | `installed_codex_selected_directory_excludes_project_context_hooks_mcp_and_tools` | 1746 | opt-in native Codex and trusted launcher; owned malicious project and loopback service |
| `keelshell-app / keelshell-app` | `ai_settings::local_environment::probe_admission_tests::probe_admission_legal_dual_cli_runs_only_owned_native_capability_probes` | 2564 | Requires an explicitly supplied owned native fixture; run separately from ordinary tests |
| `keelshell-app / keelshell-app` | `ai_settings::local_environment::reviewer_v2_tests::reviewer_v2_empty_model_and_hidden_incomplete_draft_allow_owned_capability_probe` | 2569 | requires explicitly supplied owned native mock-child, never a supplier executable |

## Python 与质量前置项

| 项目 | 实际结果 | 证据行 |
| --- | --- | --- |
| packaging unittest | 57 total；53 passed / 0 failed / 4 skipped；4.846s | L374–L430 各名；L433、L435 汇总 |
| scripts unittest | 290 total；256 passed / 0 failed / 34 skipped；6.594s | L550 命令、L551 256 点和 34 个 s、L553、L555 汇总 |
| 依赖 x.y policy | PASS | L548 |
| cargo fmt --all --check | PASS | L562–L563；check.py 的 check=True 子进程随后进入 Clippy |
| 严格 workspace / all-targets Clippy | PASS | L565 命令、L1147 Finished、L1148 后置观测，随后 L1150 启动 workspace tests |

- Python 的 skipped 独立报告，不并入 Rust ignored。scripts 为非 verbose 输出，没有逐名列表，不能声称其 290 名已逐名库存核对。
- fmt/Clippy/依赖策略通过只签该项质量门禁；不证明后续运行测试通过，也不证明依赖为实时官方最新版本。

## 未运行与不批准范围

- 源码静态候选共 94 个普通 Rust 测试 targets；workspace 实际启动 11 个，余 83 个没有启动行。候选来自固定提交的 Cargo manifests 与默认 src/lib.rs、src/main.rs、tests/*.rs；未跑 Cargo metadata，未推断各 target 的用例数或 cfg 后编译库存。

| package | 未启动 target 数 | 范围 |
| --- | ---: | --- |
| keelshell-core | 48 | lib + 47 integration targets |
| keelshell-mcp | 7 | lib + bin + 5 integration targets |
| keelshell-platform | 1 | workspace lib 未运行；独立 preflight 已 70/0/0，二者区分 |
| keelshell-session | 27 | lib + 26 integration targets |

- `keelshell-core` 未运行完整 target 列表：`lib:keelshell-core`, `integration:ai_inference`, `integration:ai_profile_storage`, `integration:archive`, `integration:archive_pax`, `integration:batch_audit`, `integration:batch_parameters`, `integration:batch_workflow`, `integration:completion_shell`, `integration:configuration_recovery`, `integration:connection_library`, `integration:connection_library_batch`, `integration:directory_compare`, `integration:directory_mirror`, `integration:directory_sync`, `integration:host_keys`, `integration:independent_workflow_audit`, `integration:knowledge_context`, `integration:knowledge_library`, `integration:knowledge_persistence`, `integration:openssh`, `integration:pane_layout`, `integration:profile_sync`, `integration:profile_sync_independent`, `integration:profile_sync_review`, `integration:profiles`, `integration:proxies`, `integration:reconnect`, `integration:recursive_mirror_final_review`, `integration:routes`, `integration:scheduled_workflow_review`, `integration:server_archive`, `integration:snippet_template_shell`, `integration:snippet_templates`, `integration:snippets`, `integration:storage`, `integration:theme_preferences`, `integration:transfer_recovery`, `integration:tunnel_rules`, `integration:tunnel_runtime`, `integration:update_preferences`, `integration:vault`, `integration:workflow_audit`, `integration:workflow_audit_profile_sync`, `integration:workflow_audit_schema`, `integration:workflow_audit_wire_compatibility`, `integration:workspace_layout`, `integration:zmodem`。
- `keelshell-mcp` 未运行完整 target 列表：`lib:keelshell-mcp`, `bin:keelshell-mcp`, `integration:authority`, `integration:ipc_transport`, `integration:startup_eof`, `integration:stdio_process`, `integration:stream_protocol`。
- `keelshell-platform` 未运行完整 target 列表：`lib:keelshell-platform`。
- `keelshell-session` 未运行完整 target 列表：`lib:keelshell-session`, `integration:archive_tools`, `integration:archive_transfer`, `integration:archive_validation`, `integration:batch_exec`, `integration:darwin_monitor_interop`, `integration:disk_monitor`, `integration:disk_monitor_independent`, `integration:independent_workflow_audit`, `integration:monitor_interop`, `integration:openssh_interop`, `integration:remote_completion`, `integration:remote_only`, `integration:server_archive`, `integration:ssh_loopback`, `integration:ssh_path_interop`, `integration:transfer_idle_eof_independent`, `integration:transfer_idle_eof_review`, `integration:transfer_idle_metadata_negative_review`, `integration:transfer_idle_metadata_positive_review`, `integration:transfer_idle_metadata_review`, `integration:transfer_idle_timeout`, `integration:transfer_metadata_idle`, `integration:workflow_audit`, `integration:workflow_exec`, `integration:zmodem`, `integration:zmodem_openssh`。

- Rustdoc：未出现任何 `Doc-tests` 启动或汇总；ai、core、mcp、platform、session 五个库的 rustdoc 均 NOT_RUN，不填虚构的测试数。
- `scripts/check.py:77–79` 的 readiness-error、observer-io-error、controller-small-stack 三种后续独立 controller 模式全部 NOT_RUN；同名 target 的普通模式成功不能代签这些模式。
- OpenSSH Windows 路径：保存的 job 回执 steps 7–9 为 skipped；`.github/workflows/ci.yml:37–48` 限定 macOS/Linux，本来就不在 Windows job 上执行。不把 skipped 算成功。
- 未核对其他平台新日志，不签 macOS/Ubuntu 的当前详细计数。真实桌面交互、安装、跨主题、IME、辅助技术、发行和完整产品验收均不属于此 CI 库存核对。

## 可批准范围与交付文件

- APPROVE：此固定源码 / run / attempt / job 的 70 项 preflight 全名与通过结果、原八项中的七项通过和一项失败、已执行 targets 的精确计数和 ignored / NOT_RUN 边界。
- HOLD：八项归档全过、app 全过、完整 Windows / workspace / rustdoc / 三种额外 controller 模式全过，以及任何发行或真实桌面验收。此任务没有实施完整代码评审，不扩签为合并建议。
- 工作区开始即有父任务修改：`docs/HANDOFF.md`、`docs/ROADMAP.md`、`docs/testing/records/2026-11-16-windows-directory-rename.md`。本子任务未修改或清理它们，没有要求工作区干净。

- `report.md`：本报告（含 70+8 名逐项表、targets、失败、ignored 和未运行边界）。
- `inventory-r1.json`：所有日志内 Rust target 的逐名状态、两个预期库存的逐项比对、app 失败、ignored 及 Python 结果。
- `summary-r1.json`：精确计数、运行 targets、83 个 NOT_RUN 候选、rustdoc 和 controller 边界、可批准范围。
- `provenance-r1.json`：SHA、输入文件摘要、tarfile 读取证明、source-r6 和固定 Git 字节绑定、只读限制回执。
- `verification-r1.json`：独立二次解析与产物读回校验；在本报告生成后写入。
