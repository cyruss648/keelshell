// Observation/actions are explicitly bound to the isolated test application's PID.
import AppKit
import ApplicationServices
import Foundation

func attribute(_ element: AXUIElement, _ name: String) -> CFTypeRef? {
    var value: CFTypeRef?
    return AXUIElementCopyAttributeValue(element, name as CFString, &value) == .success ? value : nil
}
func string(_ element: AXUIElement, _ name: String) -> String {
    return attribute(element, name) as? String ?? ""
}
func children(_ element: AXUIElement) -> [AXUIElement] {
    return attribute(element, kAXChildrenAttribute) as? [AXUIElement] ?? []
}
func emit(_ value: Any) throws {
    let data = try JSONSerialization.data(withJSONObject: value, options: [.prettyPrinted, .sortedKeys])
    print(String(decoding: data, as: UTF8.self))
}
struct Observation {
    var elements: [AXUIElement] = []
    var nodes: [[String: Any]] = []
    mutating func visit(_ element: AXUIElement, _ path: String, _ depth: Int) {
        if depth > 35 || elements.count >= 4000 { return }
        if string(element, kAXRoleAttribute) == kAXMenuBarRole { return }
        let index = elements.count
        elements.append(element)
        var node: [String: Any] = ["index": index, "path": path]
        for name in [kAXRoleAttribute, kAXSubroleAttribute, kAXTitleAttribute,
                     kAXDescriptionAttribute, kAXValueAttribute, kAXHelpAttribute,
                     kAXIdentifierAttribute, kAXEnabledAttribute, kAXFocusedAttribute] {
            if let value = attribute(element, name) {
                if let text = value as? String { node[name] = text }
                else if CFGetTypeID(value) == CFBooleanGetTypeID() { node[name] = (value as! NSNumber).boolValue }
            }
        }
        for name in [kAXPositionAttribute, kAXSizeAttribute] {
            if let value = attribute(element, name), CFGetTypeID(value) == AXValueGetTypeID() {
                let ax = value as! AXValue
                if AXValueGetType(ax) == .cgPoint {
                    var point = CGPoint.zero
                    if AXValueGetValue(ax, .cgPoint, &point) { node[name] = [point.x, point.y] }
                } else if AXValueGetType(ax) == .cgSize {
                    var size = CGSize.zero
                    if AXValueGetValue(ax, .cgSize, &size) { node[name] = [size.width, size.height] }
                }
            }
        }
        var actions: CFArray?
        if AXUIElementCopyActionNames(element, &actions) == .success { node["actions"] = actions as? [String] ?? [] }
        nodes.append(node)
        for (position, child) in children(element).enumerated() {
            visit(child, path + "." + String(position), depth + 1)
        }
    }
}

do {
    let args = CommandLine.arguments
    guard args.count >= 3, let pid = Int32(args[1]), pid > 1,
          let application = NSRunningApplication(processIdentifier: pid),
          application.executableURL?.lastPathComponent == "keelshell-app" else {
        throw NSError(domain: "IsolatedKeelShellPIDRequired", code: 1)
    }
    let root = AXUIElementCreateApplication(pid)
    AXUIElementSetMessagingTimeout(root, 3)
    let operation = args[2]
    if operation == "activate" {
        application.activate(options: [.activateIgnoringOtherApps])
        try emit(["pid": pid, "activated": true])
    } else if operation == "tree" {
        var observation = Observation()
        observation.visit(root, "app", 0)
        let windows = (CGWindowListCopyWindowInfo([.optionOnScreenOnly, .excludeDesktopElements], kCGNullWindowID)
            as? [[String: Any]] ?? []).filter { ($0[kCGWindowOwnerPID as String] as? Int32) == pid }
        try emit(["pid": pid, "axTrusted": AXIsProcessTrusted(), "nodes": observation.nodes,
                  "cgWindows": windows, "foregroundPID": NSWorkspace.shared.frontmostApplication?.processIdentifier ?? 0])
    } else if operation == "press" {
        guard args.count == 5 else { throw NSError(domain: "RoleAndExactLabelRequired", code: 2) }
        var observation = Observation()
        observation.visit(root, "app", 0)
        // GPUI may publish a label through title, description or value.
        let indexes = observation.nodes.filter { node in
            node[kAXRoleAttribute] as? String == args[3] &&
            [kAXTitleAttribute, kAXDescriptionAttribute, kAXValueAttribute, kAXIdentifierAttribute]
                .contains { node[$0] as? String == args[4] }
        }.compactMap { $0["index"] as? Int }
        guard indexes.count == 1, let index = indexes.first else {
            throw NSError(domain: "ExpectedOneMatchingElement", code: indexes.count)
        }
        let result = AXUIElementPerformAction(observation.elements[index], kAXPressAction as CFString)
        guard result == .success else { throw NSError(domain: "AXPress", code: Int(result.rawValue)) }
        try emit(["pid": pid, "pressedRole": args[3], "pressedLabel": args[4]])
    } else if operation == "resize" {
        guard args.count == 5, let width = Double(args[3]), let height = Double(args[4]),
              let window = (attribute(root, kAXWindowsAttribute) as? [AXUIElement])?.first else {
            throw NSError(domain: "WindowAndDimensionsRequired", code: 3)
        }
        var size = CGSize(width: width, height: height)
        let value = AXValueCreate(.cgSize, &size)!
        let result = AXUIElementSetAttributeValue(window, kAXSizeAttribute as CFString, value)
        try emit(["pid": pid, "resizeResult": result.rawValue])
    } else if operation == "scroll" {
        guard args.count == 6, let x = Double(args[3]), let y = Double(args[4]),
              let delta = Int32(args[5]),
              NSWorkspace.shared.frontmostApplication?.processIdentifier == pid,
              let info = (CGWindowListCopyWindowInfo([.optionOnScreenOnly, .excludeDesktopElements], kCGNullWindowID)
                as? [[String: Any]])?.first(where: {
                  ($0[kCGWindowOwnerPID as String] as? Int32) == pid &&
                  ($0[kCGWindowLayer as String] as? Int) == 0
              }),
              let bounds = info[kCGWindowBounds as String] as? [String: Double],
              let left = bounds["X"], let top = bounds["Y"],
              let width = bounds["Width"], let height = bounds["Height"],
              x > 10, y > 10, x < width - 10, y < height - 10,
              abs(delta) <= 200 else {
            throw NSError(domain: "ForegroundWindowAndBoundedScrollRequired", code: 6)
        }
        let location = CGPoint(x: left + x, y: top + y)
        CGWarpMouseCursorPosition(location)
        let move = CGEvent(mouseEventSource: nil, mouseType: .mouseMoved, mouseCursorPosition: location, mouseButton: .left)!
        move.post(tap: .cghidEventTap)
        Thread.sleep(forTimeInterval: 0.05)
        let event = CGEvent(scrollWheelEvent2Source: nil, units: .pixel, wheelCount: 1,
                            wheel1: delta * 20, wheel2: 0, wheel3: 0)!
        event.location = location
        if let windowNumber = info[kCGWindowNumber as String] as? Int64 {
            event.setIntegerValueField(.mouseEventWindowUnderMousePointer, value: windowNumber)
            event.setIntegerValueField(.mouseEventWindowUnderMousePointerThatCanHandleThisEvent, value: windowNumber)
        }
        event.setIntegerValueField(.scrollWheelEventIsContinuous, value: 1)
        event.post(tap: .cghidEventTap)
        Thread.sleep(forTimeInterval: 0.1)
        let actual = CGEvent(source: nil)!.location
        try emit(["pid": pid, "scrollLocalPoint": [x, y], "deltaPixels": delta * 20,
                  "cursor": [actual.x, actual.y], "postAllowed": CGPreflightPostEventAccess()])
    } else if operation == "key" {
        guard args.count >= 4, let code = UInt16(args[3]),
              NSWorkspace.shared.frontmostApplication?.processIdentifier == pid else {
            throw NSError(domain: "ForegroundTestApplicationRequired", code: 4)
        }
        let flags = args.count == 5 ? UInt64(args[4]) ?? 0 : 0
        for down in [true, false] {
            let event = CGEvent(keyboardEventSource: nil, virtualKey: code, keyDown: down)!
            event.flags = CGEventFlags(rawValue: flags)
            event.postToPid(pid)
        }
        try emit(["pid": pid, "keyCode": code, "flags": flags])
    } else {
        throw NSError(domain: "UnknownOperation", code: 5)
    }
} catch {
    try? emit(["error": String(describing: error)])
    exit(1)
}
