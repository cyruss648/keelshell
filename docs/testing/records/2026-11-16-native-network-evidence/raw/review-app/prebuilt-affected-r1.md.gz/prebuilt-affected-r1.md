# Independent execution of parent prebuilt test binary, r1

```text

running 19 tests
test monitor::path_comparison::tests::localization::path_comparison_localizes_painted_review_failures_and_observed_differences ... ok
test monitor::path_comparison::tests::path_comparison_candidate_retirement_revokes_review_synchronously ... ok
test monitor::path_comparison::tests::path_comparison_closing_inactive_candidate_revokes_review_without_selecting_it ... ok
test monitor::path_comparison::tests::path_comparison_late_result_rechecks_second_transport_before_adoption ... ok
test monitor::path_comparison::tests::path_comparison_minimum_workspace_can_reach_review_and_result_controls ... ok
test monitor::path_comparison::tests::path_comparison_preview_is_local_and_aba_requires_new_review ... ok
test monitor::path_comparison::tests::path_comparison_running_cancel_owns_worker_and_discards_revoked_reply ... ok
test monitor::path_comparison::tests::path_comparison_second_route_change_blocks_confirm_before_retirement_poll ... ok
test monitor::path_comparison::tests::path_comparison_stale_result_never_resurrects_after_selection_aba ... ok
test monitor::path_comparison::tests::path_comparison_three_themes_keep_review_actions_outside_scrolling_body ... ok
test monitor::path_comparison::tests::path_comparison_unknown_completion_disables_next_run_and_keeps_raw_samples ... ok
test workspace::modals::tests::authentication_footer_remains_visible_with_route_metadata_and_long_vault_feedback ... ok
test workspace::modals::tests::connection_form_keeps_save_and_cancel_outside_long_scrollable_drafts ... ok
test workspace::modals::tests::host_key_review_exposes_exact_identity_and_change_warning_to_accessibility ... ok
test workspace::modals::tests::ordinary_authentication_is_compact_without_a_duplicate_endpoint ... ok
test workspace::modals::tests::proxy_authentication_keeps_footer_and_password_focus_in_small_bilingual_windows ... ok
test workspace::modals::tests::proxy_connection_editor_can_scroll_to_click_and_edit_its_username ... ok
test workspace::tests::routes::windows::multiwindow_close_rejects_format_only_drift_then_reaps_a_and_keeps_b_ssh_live ... ok
test workspace::tests::routes::windows::orphan_cleanup_keeps_pending_jump_live_then_releases_cancelled_route ... ok

test result: ok. 19 passed; 0 failed; 0 ignored; 0 measured; 1254 filtered out; finished in 5.06s

```
