# KeelShell app 非作者限定复核 r1

本轮结论为 **APPROVE_SCOPED_SOURCE**；开放发现 **P0=0 / P1=0 / P2=0 / P3=0**。建议允许这 7 个文件的已审差分进入集成。最终交付仍需父最终冻结、全门禁、正常 GUI 构建和相关 native 回执与本报告输入绑定一致；r1 不签真实原生验收或范围外实现。

baseline 与实际 HEAD 均为 `5a6b30a2b9cca6d89aea551409738145608ac689`。工作树差分为 7 文件、311 增行、40 删行；集合 SHA-256 为 `995d547722583ede5bfa1f9fb5fa8113babb13a84a233c10e27a3512dd94151e`。差分 SHA-256 为 `ab823b045bf19da28d7b6037ff566080222b937f64c039f6bbe477de10f9c50d`。全部文件在审查前后及父预构建 298 项 app Rust 输入中一致。逐项 baseline/current 摘要和行号证据见 `report-r1.json` 与 `source-binding-r1.json`。

## 源码结论

- pending route 的最新已认证上游加入 GC 根，现有 child → parent 定点闭包保留其全部传递祖先。成功 hop 在同一前台更新内登记依赖，无维护 tick 插入的空窗。三跳以上仅源码推导。
- 取消/拒绝先移除 `connect_route`；普通失败同样移除。成功则在同一前台更新交接为 tab 根。最后 tab 关闭移除对应 session，孤儿依赖边随 ownership 退役清除；存在其他 tab 时由 200 ms 维护 tick 继续回收。
- 根、owned sessions 和依赖边均属本 Workspace；连接按 Arc 身份比较。过期 attempt id/index 不会接管新 route；本地落盘和观测到的兄弟窗配置变更会撤销旧 route。
- 指纹标题、引导、收到值、旧值与路径审核文本使用对应 Label/Group 语义；关键审核文本的 AX label 与绘制使用同一字符串。语言每次 render 重新选择，新增节点没有自动授权/点击路径。
- 主机密钥变化仍 fail closed；接受前检查当前 route、attempt 和 hop，按 scope 显式持久化后才进入后续认证。新增 host-key fixture 仅验证展示，没有点击接受以验证安全持久化。

## 独立执行父预构建测试

精确二进制 SHA-256：`054a8da30a98f78588997bf96a9b89886463a34c121ff40584d83776ac554444`。298 项 app Rust 输入及路径集合核验通过。独立 `--list` 为 1,273 项，库存 SHA-256 `93afb3e11501b38d3b6b5a0c1c028fcd50bfdbd8137b5ee392a62afa632745e0`，与父声明相同。

共执行 2 条测试二进制命令：1 次库存、1 次限定测试，均 exit 0 / reaped / 无超时。限定集与父 19 项逐名一致：11 项路径比较、6 项 modal、2 项 route/windows；结果 **19 passed / 0 failed / 0 ignored / 1,254 filtered out**，用时 **5.077618s**。没有独立重编译。编译器/格式化/lint 调用为 0，正常 app 启动为 0，Git 修改/提交/推送为 0，外部网络调用为 0。

原始运行日志保存在 `prebuilt-affected-r1.md` 和 `prebuilt-affected-r1.json`。临时夹具数据通过 TMPDIR 指向本 review 目录，执行使用最新用户消息授权的测试内 loopback SSH peers。未启动系统 sshd 或连接外部 SSH。

## 红证据与边界

只读核对父三项红测试原件：均 exit 101 / reaped，分别 0 passed / 1 failed。此前 AX 编译失败同为 exit 101 / reaped、两个 E0277，未运行测试。父 affected-green-r1 的 exit 0 / reaped / 15.973s、19/19 与当前独立预构建执行分别记录，不合并计数，不覆盖失败。

本轮小窗口、三主题、滚动、焦点及语言变化仅基于源码与合成 GPUI 测试。三跳以上、普通失败/过期 completion、双方同时 pending 的窗口隔离尚无本轮独立运行证明。真实 macOS AX 树/VoiceOver、极长身份/指纹、最终 GUI 包、父 r2 native、全门禁及 Windows/Linux 原生均待各自证据。

后续证据复核使用新编号报告，保留本 r1 原件。
