本轮限定 app r2 非作者审查完成：**APPROVE；P0 / P1 / P2 / P3 开放发现均为 0。** 结论只覆盖以下七文件相对 baseline 的差分，未签全产品验收。

**全仓最终冻结 r2 完整门禁：PENDING，由父后续绑定终态。** `docs/testing/STRATEGY.md:24` 要求最终冻结源码有一次完整成功门禁。父已启动 full-gate-r2；本报告不等待，也不把 r1 Rust gate 加 Python 重跑称为第二次完整 gate。

Baseline / 当前 HEAD：`5a6b30a2b9cca6d89aea551409738145608ac689`；补丁是该 HEAD 之上的工作区差分。七文件集合 SHA256：`995d547722583ede5bfa1f9fb5fa8113babb13a84a233c10e27a3512dd94151e`。

| 审查文件 | 当前 SHA256 |
| --- | --- |
| [crates/keelshell-app/src/workspace.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/workspace.rs) | `7e15aa701f0fc6c18817209d52d3999ee792fa99703ab5df121750047974754e` |
| [crates/keelshell-app/src/workspace/routing.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/workspace/routing.rs) | `829f77ec78e071cdc103a239002ecb7cbac89be681576f3501e94ab7b9b76634` |
| [crates/keelshell-app/src/workspace/modals.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/workspace/modals.rs) | `5a10d85494fd91359ae0eb33e02699b92d5ae83abb32616151fd6d1d2118cd8b` |
| [crates/keelshell-app/src/workspace/modals/tests.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/workspace/modals/tests.rs) | `cecad6d2365375d2f805b57846cdc27cf2c002510c3320cf40358cbe38686dda` |
| [crates/keelshell-app/src/workspace/tests/routes/windows.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/workspace/tests/routes/windows.rs) | `ab0e60f56d75d0f61e463d4399cce0ce7b7f42f2c3a39625ae95e2c395e46469` |
| [crates/keelshell-app/src/monitor_path_comparison.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_path_comparison.rs) | `28fdfa70da18155897cae7499273b098fbcfbe24bf8b8efd79f1bee0bdf08a66` |
| [crates/keelshell-app/src/monitor_tests/path_comparison_localization.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_tests/path_comparison_localization.rs) | `2e7cc95a287e8f3c5f1d6493d1168c0301511c0445bf19855b5786a3a4cba134` |

GC 根与传递依赖保留、取消/失败回收、最后 tab 结束、窗口隔离与废弃 route 的 r1 源码结论保持有效。关键位置是 [workspace.rs:1282](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/workspace.rs:1282) 与 [routing.rs:89](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/workspace/routing.rs:89)。AX 精确文本/角色与指纹变更 fail-closed 复核详见 JSON 的 `source_checks`；无需要列出 trigger/impact 的开放发现。

原 r1 冻结：699 项，aggregate `deba86e1554f9a5b1c4b6b2b649d441aef3fbd57dd9e47114cb250de8a9ef7d8`。最终 r2 冻结：699 项，aggregate `4ba8a00cbce305bd7d4935a158104c89ceb8313e8c2d2431bd43fa1513fca2c4`；本次逐项重算及路径集合核验全部匹配。恰好仅 `scripts/ssh_path_netem_lab.py`、`scripts/test_ssh_path_netem_lab.py` 两项改变，其余 697 项及 298 个 app Rust 输入未变。两项脚本的源码审查不在本范围。

| 验证来源 | 实际结果 |
| --- | --- |
| 既有独立父预构建测试执行 | 19 passed / 0 failed / 0 ignored / 1254 filtered；exit0、reaped、5.077618s；45s 上限 |
| 既有独立预构建 inventory | 1273 tests；exit0；与父清单一致 |
| 父正常 GUI/MCP build | exit0、reaped、28.966s |
| 父 package / inspect | 均 exit0、reaped；0.273s / 0.178s；5 个包成员 hash 及路径集合全部匹配 |
| 父 full-gate-r1 | exit0、reaped、705.126s；Rust 3105 passed / 0 failed / 40 ignored；rustdoc 14 passed；app 1271 passed / 2 ignored |
| 父 r1 Python / 嵌套 helper | 225 run / 1 skipped；helper 25 passed |
| 父两项脚本修改后的全 Python 重跑 | 227 run / 1 skipped；exit0、reaped、9.423s（unittest 内计时 9.318s） |
| 父 full-gate-r2 | 运行中，等待父对最终冻结绑定；本限定 app 报告不代签 |
| 原 native-flow-r2 | exit1、reaped、15.194s；14 步屏外 AXPress 未展开；原件保留 |
| 父分段 native / 清理 | 24–43 分段完成；18 条样本通过；supervisor exit0；两个端口关闭；18 birth identities 无活匹配；私有目录已不存在 |

独立执行使用的父预构建副本 SHA256：`054a8da30a98f78588997bf96a9b89886463a34c121ff40584d83776ac554444`。全过程只有 1 次测试执行 + 1 次 inventory（两个二进制进程均 exit0），本 r2 新增测试/构建执行均为 0；**没有独立重编译**。父同 target 构建、完整 gate 和正常 native 操作均为只读证据复核。

正常包 GUI SHA256：`64a9af1f2bbd3f0a52414bff237d1df665ee1c015aeeef4b6eb49ef329aff3e8`；MCP SHA256：`0e5efdcbe2069fb4ea3c809a99419c557d11ba0ba18e7ba8e5fc6ea0e9bde816`。manifest SHA256：`3ec55f4a9b72db14587ef21eaf6f3352d6e44480f24c78f2a946baaa2d06b1c2`。包 metadata 的 commit 是 baseline；工作区补丁身份另由冻结 hash、构建来源和实际 native 行为绑定。

真实 macOS fixture 的直连与 jump/target 每跳收到指纹，均与此前独立读取公钥后计算的 SHA256 精确一致，原生角色为 AXStaticText。target credential prompt 跨过真实 0.946222667s 等待后仍保留并成功进入经跳板会话；这里不声称逐 tick 仪表计数。24 审核文本与 28 本次来源全文一致，三个命令逐字匹配冻结 Rust 常量；中英文均保留固定命令、两条路线、每跳 pins 和 3MiB/8s/60s 边界。

18 条原生 AX 样本的 index、轮次、A/B 交替、类型、字节数和通过状态逐条核对成功，总合成字节数 3145728；完成状态为 AXStaticText，三个中位数组为 AXGroup。显示值与保留结果跨主题、语言切换一致；不从本地 fixture 推断普遍性能提升。

| 截图 | 实际可见范围 |
| --- | --- |
| 24–25 | 审核文本局部及确认/返回控件；没有证明全部精确命令与边界同屏可读 |
| 26（Frost） | 完成说明、三组中位数/差值均清晰可读 |
| 27–28 | 同上及前四条 raw samples；18 条完整样本、来源全文是 AX 证据 |
| 29/30、33/34 | 实际主题设置/应用；不是比较结果页 |
| 31/35 | 返回监控上方资源卡片；结果在 AX 状态中，屏内未显示 |
| 32/36 | Graphite/Lavender 来源尾部局部；不能签为三组结果全部同屏 |
| 37–39 | 英文样本/来源局部或监控前部；未据此签完整结果可见 |
| 40–41 | 请求 900×580 client，实际 900×612 外框；完成说明、首组命令往返中位数/差值可读，其他结果需滚动；终端及 SFTP 保留 |
| 42–43（Lavender English） | 恢复实际 1440×900；完成说明、三组中位数/差值及首条样本可读 |

**三主题全部结果同屏可读未成立。** 三主题实际应用和 AX 结果保留成立；Graphite 三组完整结果的屏内可读性，以及通过完整滚动逐项观察全部 18 样本/来源全文，仍是证据边界。

原生取消比较、完整 VoiceOver/键盘/IME、极端长身份文本、真实 changed-key 对抗交互、三跳以上及并行待连接窗口的专项 native 行为，以及 Windows/Linux、签名/安装/发布均未由本轮签收。changed-key 安全性及超出已执行专项的生命周期路径仍以源码复核为依据。

清理复核：父 session-final 与 summary 中 18 个 PID/birth 值逐项一致，无活匹配；本 reviewer 的只读 ps 查询 exit1、0 行，表示查询时 18 个 PID 均不存在，未发送信号；私有目录也已不存在。端口关闭来自父回执，本 reviewer 没有连接端口或操作测试 app/target。

合并建议：**同意上述 exact hashes 的七个 app 文件进入集成；整批最终合并仍由父以 r2 冻结上的成功完整门禁收口。** r1 报告、红测试、compile 失败及原 native-flow exit1 原件均已保持；新报告不覆盖任何前轮。

完整命令 argv、exit/count、逐文件/包/截图/回执 SHA256、源码定位、样本记录及边界见同目录 [report-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/native-network-20261116/review-app/report-r2.json)。
