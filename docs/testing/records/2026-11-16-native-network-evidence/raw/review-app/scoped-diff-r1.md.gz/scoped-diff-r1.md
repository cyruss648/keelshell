# Scoped source diff reviewed in r1

```diff
diff --git a/crates/keelshell-app/src/monitor_path_comparison.rs b/crates/keelshell-app/src/monitor_path_comparison.rs
index 5e8d0b8..4bf97b0 100644
--- a/crates/keelshell-app/src/monitor_path_comparison.rs
+++ b/crates/keelshell-app/src/monitor_path_comparison.rs
@@ -452,21 +452,25 @@ fn localized_review(plan: &PathComparisonPlan, cx: &App) -> String {
         [
             plan.connection_info(PathSide::A),
             plan.connection_info(PathSide::B),
         ],
         cx,
     )
 }
 
-fn observed_text(text: String) -> impl IntoElement {
-    // The observer and renderer share one string, never a second description.
-    // In normal builds this adds no element or state.
+fn observed_text(id: impl Into<ElementId>, text: String) -> impl IntoElement {
+    // The accessibility label, observer and renderer share the exact same text.
     let text: SharedString = text.into();
-    text.clone().test_text(text)
+    div()
+        .id(id)
+        .test_support()
+        .role(accesskit::Role::Label)
+        .aria_label(text.clone())
+        .child(text.clone().test_text(text))
 }
 
 fn review_text(routes: [&keelshell_session::SshConnectionInfo; 2], cx: &App) -> String {
     use std::fmt::Write;
     let mut text = String::new();
     for (side, route) in ["A", "B"].into_iter().zip(routes) {
         let _ = writeln!(text, "{} {side}", t(cx, "路径", "Path"));
         let mut hops = Vec::new();
@@ -639,17 +643,20 @@ impl Render for PathComparisonPanel {
                         div()
                             .id("path-comparison-review-body")
                             .test_support()
                             .h(px(160.))
                             .min_w_0()
                             .overflow_y_scroll()
                             .text_xs()
                             .whitespace_normal()
-                            .child(observed_text(localized_review(&review.plan, cx))),
+                            .child(observed_text(
+                                "path-comparison-review-text",
+                                localized_review(&review.plan, cx),
+                            )),
                     )
                     .child(
                         div()
                             .id("path-comparison-review-actions")
                             .test_support()
                             .flex()
                             .flex_shrink_0()
                             .flex_wrap()
@@ -682,16 +689,18 @@ impl Render for PathComparisonPanel {
                     .label(t(cx, "停止比较", "Stop comparison"))
                     .on_click(cx.listener(|panel, _, _, cx| panel.cancel(cx))),
             );
         }
         view = view.child(
             div()
                 .id("path-comparison-status")
                 .test_support()
+                .role(accesskit::Role::Label)
+                .aria_label(self.status.render(cx))
                 .min_w_0()
                 .text_xs()
                 .whitespace_normal()
                 .child(self.status.render(cx)),
         );
         if let Some(report) = &self.result {
             for kind in [
                 PathProbeKind::Exec,
@@ -700,43 +709,59 @@ impl Render for PathComparisonPanel {
             ] {
                 let (a, b) = (
                     report.summary(PathSide::A, kind),
                     report.summary(PathSide::B, kind),
                 );
                 if let (Some(a), Some(b)) = (a, b) {
                     view = view.child(
                         div()
+                            .id(("path-comparison-median", kind as usize))
+                            .test_support()
+                            .role(accesskit::Role::Group)
+                            .aria_label(format!(
+                                "{} ({}); A: {}; B: {}",
+                                kind_name(kind, cx),
+                                t(cx, "三次中位数", "median of three"),
+                                sample_time(a, kind),
+                                sample_time(b, kind),
+                            ))
                             .min_w_0()
                             .flex()
                             .flex_col()
                             .text_xs()
                             .gap_1()
                             .child(format!(
                                 "{} ({})",
                                 kind_name(kind, cx),
                                 t(cx, "三次中位数", "median of three"),
                             ))
                             .child(format!("A: {}", sample_time(a, kind)))
                             .child(format!("B: {}", sample_time(b, kind)))
                             .child(
                                 div()
                                     .id(("path-comparison-difference", kind as usize))
                                     .test_support()
-                                    .child(observed_text(difference_text(a, b, cx))),
+                                    .child(observed_text(
+                                        ("path-comparison-difference-text", kind as usize),
+                                        difference_text(a, b, cx),
+                                    )),
                             ),
                     );
                 } else {
-                    view = view.child(div().text_xs().child(format!(
-                        "{}: {}",
-                        kind_name(kind, cx),
-                        t(
-                            cx,
-                            "数据不足，无法完整比较。",
-                            "Insufficient data for a complete comparison."
+                    view = view.child(div().text_xs().child(observed_text(
+                        ("path-comparison-insufficient", kind as usize),
+                        format!(
+                            "{}: {}",
+                            kind_name(kind, cx),
+                            t(
+                                cx,
+                                "数据不足，无法完整比较。",
+                                "Insufficient data for a complete comparison."
+                            ),
                         ),
                     )));
                 }
             }
             view = view
                 .child(
                     Button::new("path-comparison-samples-toggle")
                         .ghost()
@@ -774,48 +799,48 @@ impl Render for PathComparisonPanel {
                                 PathSampleOutcome::Failed(reason) => {
                                     format!(
                                         "{}: {}",
                                         t(cx, "失败", "Failed"),
                                         failure_text(*reason, cx)
                                     )
                                 }
                             };
-                            div()
-                                .text_xs()
-                                .whitespace_normal()
-                                .child(observed_text(format!(
+                            div().text_xs().whitespace_normal().child(observed_text(
+                                ("path-comparison-sample", index),
+                                format!(
                                     "#{} {:?}  {} {}  {}  {} B  {:.2} ms  {}",
                                     index + 1,
                                     sample.path,
                                     t(cx, "轮", "round"),
                                     sample.round,
                                     kind_name(sample.kind, cx),
                                     sample.bytes,
                                     sample.elapsed.as_secs_f64() * 1000.,
                                     outcome,
-                                )))
+                                ),
+                            ))
                         })),
                 );
             }
             if let Some(source) = self
                 .result_source
                 .as_ref()
                 .filter(|_| self.show_result_review)
             {
                 view = view.child(
                     div()
                         .id("path-comparison-run-source")
                         .max_h(px(160.))
                         .overflow_y_scroll()
                         .min_w_0()
                         .text_xs()
                         .whitespace_normal()
-                        .child(observed_text(review_text(
-                            [&source.routes[0], &source.routes[1]],
-                            cx,
-                        ))),
+                        .child(observed_text(
+                            "path-comparison-run-source-text",
+                            review_text([&source.routes[0], &source.routes[1]], cx),
+                        )),
                 );
             }
         }
         view
     }
 }
diff --git a/crates/keelshell-app/src/monitor_tests/path_comparison_localization.rs b/crates/keelshell-app/src/monitor_tests/path_comparison_localization.rs
index 99ff51e..50cd968 100644
--- a/crates/keelshell-app/src/monitor_tests/path_comparison_localization.rs
+++ b/crates/keelshell-app/src/monitor_tests/path_comparison_localization.rs
@@ -36,16 +36,25 @@ fn path_comparison_localizes_painted_review_failures_and_observed_differences(
         cx.update_window(window, |_, window, cx| {
             crate::i18n::set_language(language, cx);
             h.panel.update(cx, |panel, cx| {
                 panel.preview(cx);
                 cx.notify();
             });
             window.render_frame(cx);
             let text = painted_text(window, "path-comparison-review-body");
+            assert_eq!(
+                window.find("path-comparison-review-text").role(),
+                Some(gpui_kit::accesskit::Role::Label)
+            );
+            assert_eq!(
+                window.find("path-comparison-review-text").label(),
+                Some(text.as_str()),
+                "the exact painted routes, commands and limits must be readable through AX"
+            );
             if language == keelshell_core::Language::ZhCn {
                 assert!(text.contains("单样本绝对期限八秒"));
                 assert!(text.contains("已核验密钥"));
                 assert!(text.contains("未确认清理"));
             } else {
                 assert!(text.contains("eight seconds per sample"));
                 assert!(text.contains("verified key"));
             }
@@ -72,24 +81,39 @@ fn path_comparison_localizes_painted_review_failures_and_observed_differences(
             window.render_frame(cx);
             let text = painted_text(window, "path-comparison-raw-samples");
             let expected_failure = if language == keelshell_core::Language::ZhCn {
                 "响应超过样本输出上限"
             } else {
                 "Sample output limit exceeded"
             };
             assert!(text.contains(expected_failure), "{text}");
+            assert_eq!(
+                window.find(("path-comparison-sample", 0_usize)).label(),
+                Some(text.as_str()),
+                "a failed raw sample must retain its reason in AX"
+            );
             h.panel.update(cx, |panel, cx| {
                 panel.result = Some(report(PathComparisonStatus::Complete));
                 panel.show_samples = false;
                 cx.notify();
             });
             window.render_frame(cx);
             let id = ("path-comparison-difference", PathProbeKind::Exec as usize);
             assert!(window.find(id).bounds().size.height > px(0.));
+            let difference = window.find(("path-comparison-difference-text", 0_usize));
+            assert_eq!(difference.role(), Some(gpui_kit::accesskit::Role::Label));
+            assert!(difference.label().is_some());
+            assert!(
+                window
+                    .find(("path-comparison-median", PathProbeKind::Exec as usize))
+                    .label()
+                    .unwrap_or_default()
+                    .contains("ms")
+            );
             let text = gpui_kit::base::test_support::texts(window)
                 .into_iter()
                 .map(|text| text.text().to_owned())
                 .collect::<Vec<_>>()
                 .join("\n");
             let equal_text = if language == keelshell_core::Language::ZhCn {
                 "观察差异不足，无法判断哪条路径更快。"
             } else {
diff --git a/crates/keelshell-app/src/workspace.rs b/crates/keelshell-app/src/workspace.rs
index bd4ffe6..8ebb914 100644
--- a/crates/keelshell-app/src/workspace.rs
+++ b/crates/keelshell-app/src/workspace.rs
@@ -1275,17 +1275,22 @@ impl Workspace {
             })
         {
             self.session_dependencies
                 .push((child.clone(), parent.clone()));
         }
     }
 
     fn close_orphaned_window_sessions(&mut self, cx: &App) {
-        let active: Vec<_> = self.remote_sessions.values().cloned().collect();
+        let active: Vec<_> = self
+            .remote_sessions
+            .values()
+            .chain(self.pending_route_session())
+            .cloned()
+            .collect();
         let required = self.retain_route_dependencies(&active);
         let background_busy = self.window_agent_busy(cx)
             || self.retired_window_panels.iter().any(|panels| {
                 panels
                     .files
                     .as_ref()
                     .is_some_and(|panel| panel.read(cx).window_close_busy())
                     || panels
diff --git a/crates/keelshell-app/src/workspace/modals.rs b/crates/keelshell-app/src/workspace/modals.rs
index a533900..a965f90 100644
--- a/crates/keelshell-app/src/workspace/modals.rs
+++ b/crates/keelshell-app/src/workspace/modals.rs
@@ -76,16 +76,36 @@ fn route_steps(steps: &[Connection], current: usize, cx: &App) -> AnyElement {
         .test_support()
         .flex()
         .flex_col()
         .gap_2()
         .children(steps.iter().enumerate().map(|(index, connection)| {
             div()
                 .id(("connection-route-step", index))
                 .test_support()
+                .role(accesskit::Role::Group)
+                .aria_label(format!(
+                    "{} {}{}: {} · {}{}",
+                    t(cx, "连接步骤", "Connection step"),
+                    index + 1,
+                    if index == current {
+                        t(cx, "，当前", ", current")
+                    } else {
+                        ""
+                    },
+                    connection.name,
+                    endpoint(connection),
+                    connection.proxy.as_ref().map_or_else(String::new, |proxy| {
+                        format!(
+                            " · {}: {}",
+                            t(cx, "网络代理", "Network proxy"),
+                            proxy_endpoint(proxy)
+                        )
+                    }),
+                ))
                 .p_2()
                 .rounded(px(6.))
                 .bg(rgb(if index == current {
                     visual.selected
                 } else {
                     visual.canvas
                 }))
                 .flex()
@@ -163,16 +183,29 @@ impl Workspace {
                     t(cx, "跳板", "Jump host")
                 }
             )
         };
         div()
             .id("connection-route-status")
             .flex_shrink_0()
             .test_support()
+            .role(accesskit::Role::Group)
+            .aria_label(format!(
+                "{title}; {}; {}{}",
+                connection.name,
+                endpoint(connection),
+                connection.proxy.as_ref().map_or_else(String::new, |proxy| {
+                    format!(
+                        "; {}: {}",
+                        t(cx, "网络代理", "Network proxy"),
+                        proxy_endpoint(proxy)
+                    )
+                }),
+            ))
             .flex()
             .flex_col()
             .gap_2()
             .child(div().text_xs().text_color(rgb(visual.accent)).child(title))
             .child(
                 div()
                     .text_sm()
                     .font_weight(FontWeight::SEMIBOLD)
@@ -495,44 +528,79 @@ impl Workspace {
                         t(cx, "身份认证", "Authenticate"),
                         login.connection.name
                     ))
                     .into_any_element(),
                 body.into_any_element(),
                 footer.into_any_element(),
             )
         } else if let Some(approval) = &self.host_approval {
+            let title = if approval.previous.is_some() {
+                t(cx, "服务器指纹已变更", "Server identity changed")
+            } else {
+                t(cx, "验证服务器指纹", "Verify server identity")
+            };
+            let guidance = t(
+                cx,
+                "请与可信来源核对服务器指纹后再接受。",
+                "Compare this fingerprint with a trusted source before accepting it.",
+            );
+            let received = format!(
+                "{}: {}",
+                t(cx, "收到的指纹", "Received"),
+                approval.fingerprint
+            );
             let body = div()
                 .flex()
                 .flex_col()
                 .gap_3()
                 .child(self.connection_route_status(cx))
                 .when(self.route_progress(cx).is_none(), |body| {
                     body.child(
                         div()
                             .text_sm()
                             .font_family("monospace")
                             .child(endpoint(&approval.connection)),
                     )
                 })
-                .child(div().text_sm().text_color(rgb(visual.muted)).child(t(
-                    cx,
-                    "请与可信来源核对服务器指纹后再接受。",
-                    "Compare this fingerprint with a trusted source before accepting it.",
-                )))
-                .child(div().text_sm().font_family("monospace").child(format!(
-                    "{}: {}",
-                    t(cx, "收到的指纹", "Received"),
-                    approval.fingerprint
-                )))
+                .child(
+                    div()
+                        .id("ssh-host-key-guidance")
+                        .test_support()
+                        .role(accesskit::Role::Label)
+                        .aria_label(guidance)
+                        .text_sm()
+                        .text_color(rgb(visual.muted))
+                        .child(guidance),
+                )
+                .child(
+                    div()
+                        .id("ssh-host-key-received")
+                        .test_support()
+                        .role(accesskit::Role::Label)
+                        .aria_label(received.clone())
+                        .text_sm()
+                        .font_family("monospace")
+                        .child(received),
+                )
                 .when_some(approval.previous.as_ref(), |body, previous| {
-                    body.child(div().text_sm().font_family("monospace").child(format!(
+                    let text = format!(
                         "{}: {previous}",
                         t(cx, "已信任的指纹", "Previously trusted")
-                    )))
+                    );
+                    body.child(
+                        div()
+                            .id("ssh-host-key-previous")
+                            .test_support()
+                            .role(accesskit::Role::Label)
+                            .aria_label(text.clone())
+                            .text_sm()
+                            .font_family("monospace")
+                            .child(text),
+                    )
                 });
             let footer = div()
                 .flex()
                 .flex_wrap()
                 .justify_end()
                 .gap_2()
                 .child(
                     Button::new("reject-host-key")
@@ -555,28 +623,28 @@ impl Workspace {
                         .on_click(
                             cx.listener(|view, _, window, cx| view.accept_host_key(window, cx)),
                         )
                         .map(|button| self.retain_modal_button("accept-host-key", button, cx)),
                 );
             (
                 px(480.),
                 div()
+                    .id("ssh-host-key-title")
+                    .test_support()
+                    .role(accesskit::Role::Label)
+                    .aria_label(title)
                     .text_lg()
                     .font_weight(FontWeight::SEMIBOLD)
                     .text_color(rgb(if approval.previous.is_some() {
                         visual.danger
                     } else {
                         visual.accent
                     }))
-                    .child(if approval.previous.is_some() {
-                        t(cx, "服务器指纹已变更", "Server identity changed")
-                    } else {
-                        t(cx, "验证服务器指纹", "Verify server identity")
-                    })
+                    .child(title)
                     .into_any_element(),
                 body.into_any_element(),
                 footer.into_any_element(),
             )
         } else if self.connecting {
             // The card leaves draft input and focus available during a handshake.
             return div()
                 .id("ssh-connection-progress")
diff --git a/crates/keelshell-app/src/workspace/modals/tests.rs b/crates/keelshell-app/src/workspace/modals/tests.rs
index cf4f1a1..e2a8e9a 100644
--- a/crates/keelshell-app/src/workspace/modals/tests.rs
+++ b/crates/keelshell-app/src/workspace/modals/tests.rs
@@ -210,16 +210,96 @@ fn ordinary_authentication_is_compact_without_a_duplicate_endpoint(cx: &mut Test
             assert!(contained(window.find("cancel-login").bounds(), footer));
         }
         window.click("cancel-login", cx);
         assert!(fixture.workspace.read(cx).login.is_none());
     })
     .checked("ordinary password authentication stays compact in both languages");
 }
 
+#[gpui_kit::test]
+fn host_key_review_exposes_exact_identity_and_change_warning_to_accessibility(
+    cx: &mut TestAppContext,
+) {
+    for previous in [None, Some("SHA256:previous-fixture-only".to_owned())] {
+        let fixture = mount(cx, 760., 560.);
+        cx.update_window(fixture.window, |_, window, cx| {
+            fixture.workspace.update(cx, |view, cx| {
+                let mut connection = view.state.connections[0].clone();
+                connection.name = "Owned target".into();
+                connection.host = "target.example.test".into();
+                connection.username = "operator".into();
+                view.state
+                    .update_connection(connection.clone())
+                    .checked("synthetic endpoint metadata");
+                view.prepare_login(connection.clone(), None, window, cx);
+                view.login = None;
+                let scope = view
+                    .state
+                    .connection_route(connection.id)
+                    .checked("fixture route")
+                    .host_key_scope(0)
+                    .unwrap_or_else(|| panic!("fixture scope"));
+                view.host_approval = Some(super::super::HostApproval {
+                    attempt: uuid::Uuid::new_v4(),
+                    index: 0,
+                    scope,
+                    connection,
+                    fingerprint: "SHA256:received-fixture-only".into(),
+                    previous: previous.clone(),
+                });
+                cx.notify();
+            });
+            for language in [Language::ZhCn, Language::En] {
+                i18n::set_language(language, cx);
+                window.render_frame(cx);
+                let identity = window.find("connection-route-status");
+                let label = identity.label().unwrap_or_default();
+                assert!(label.contains("Owned target"));
+                assert!(label.contains("operator@target.example.test:22"));
+                let received = window.find("ssh-host-key-received");
+                assert_eq!(received.role(), Some(gpui_kit::accesskit::Role::Label));
+                assert_eq!(
+                    received.label(),
+                    Some(if language == Language::En {
+                        "Received: SHA256:received-fixture-only"
+                    } else {
+                        "收到的指纹: SHA256:received-fixture-only"
+                    })
+                );
+                let title = window.find("ssh-host-key-title");
+                assert_eq!(
+                    title.label(),
+                    Some(match (language, previous.is_some()) {
+                        (Language::ZhCn, true) => "服务器指纹已变更",
+                        (Language::ZhCn, false) => "验证服务器指纹",
+                        (Language::En, true) => "Server identity changed",
+                        (Language::En, false) => "Verify server identity",
+                    })
+                );
+                if previous.is_some() {
+                    assert!(
+                        window
+                            .find("ssh-host-key-previous")
+                            .label()
+                            .unwrap_or_default()
+                            .contains("SHA256:previous-fixture-only")
+                    );
+                } else {
+                    assert!(window.try_find("ssh-host-key-previous").is_none());
+                }
+                assert!(!fixture.workspace.read(cx).connecting);
+                assert!(window.find("accept-host-key").visible());
+                assert!(window.find("reject-host-key").visible());
+            }
+        })
+        .checked("bilingual first-use and changed-key AX review without network actions");
+    }
+}
+
 #[gpui_kit::test]
 fn proxy_authentication_keeps_footer_and_password_focus_in_small_bilingual_windows(
     cx: &mut TestAppContext,
 ) {
     use keelshell_core::{ConnectionProxy, ProxyAuthentication, ProxyKind};
     for (width, height) in [(1280., 840.), (760., 560.), (480., 420.)] {
         let fixture = mount(cx, width, height);
         cx.update_window(fixture.window, |_, window, cx| {
diff --git a/crates/keelshell-app/src/workspace/routing.rs b/crates/keelshell-app/src/workspace/routing.rs
index e18b982..cf4fbd3 100644
--- a/crates/keelshell-app/src/workspace/routing.rs
+++ b/crates/keelshell-app/src/workspace/routing.rs
@@ -81,16 +81,22 @@ impl Workspace {
         changed
     }
 
     pub(super) fn route_progress(&self, _: &App) -> Option<(Vec<Connection>, usize)> {
         let route = self.connect_route.as_ref()?;
         Some((route.snapshot.hops().to_vec(), route.current))
     }
 
+    /// An authenticated prefix remains in use while the next hop awaits review
+    /// or authentication, even though no terminal tab owns it yet.
+    pub(super) fn pending_route_session(&self) -> Option<&SshSession> {
+        self.connect_route.as_ref()?.upstream.as_ref()
+    }
+
     fn route_is_current(&self) -> bool {
         let configuration_current = self.configuration_token_current();
         if !configuration_current || self.close_review.is_some() {
             return false;
         }
         let Some(route) = &self.connect_route else {
             return false;
         };
diff --git a/crates/keelshell-app/src/workspace/tests/routes/windows.rs b/crates/keelshell-app/src/workspace/tests/routes/windows.rs
index d1f39e8..6942f8e 100644
--- a/crates/keelshell-app/src/workspace/tests/routes/windows.rs
+++ b/crates/keelshell-app/src/workspace/tests/routes/windows.rs
@@ -33,16 +33,79 @@ async fn connected(
             })
     })
     .await;
     fixture
         .workspace
         .read_with(cx, |view, _| view.tabs[0].clone())
 }
 
+#[gpui_kit::test]
+async fn orphan_cleanup_keeps_pending_jump_live_then_releases_cancelled_route(
+    cx: &mut TestAppContext,
+) {
+    for cancel in [false, true] {
+        let (fixture, route) = mount_route(cx, false, true);
+        start_route(&fixture, &route, cx);
+        submit_secret(&fixture, route.gateway.id, cx);
+        login_for(&fixture, route.target.id, cx).await;
+        cx.update_window(fixture.window, |_, _, cx| {
+            fixture.workspace.update(cx, |view, cx| {
+                assert_eq!(view.owned_window_sessions.len(), 1);
+                let gateway = view.owned_window_sessions[0].clone();
+                // Force the production maintenance tick while a user is still
+                // reviewing the next hop, rather than racing a short prompt.
+                for _ in 0..3 {
+                    view.close_orphaned_window_sessions(cx);
+                }
+                assert!(
+                    view.owned_window_sessions
+                        .iter()
+                        .any(|session| session.same_connection(&gateway)),
+                    "an authenticated hop awaiting downstream credentials is still in use"
+                );
+                assert!(!gateway.is_closed());
+            });
+        })
+        .checked("maintenance must retain the live pending route prefix");
+        if cancel {
+            cx.update_window(fixture.window, |_, window, cx| {
+                fixture
+                    .workspace
+                    .update(cx, |view, cx| view.cancel_login(window, cx));
+            })
+            .checked("cancel the pending route through its production login action");
+            assert_eq!(route.target_state.authenticated.load(Ordering::Acquire), 0);
+        } else {
+            submit_secret(&fixture, route.target.id, cx);
+            cx.wait_for(fixture.window, Duration::from_secs(10), |_, cx| {
+                fixture
+                    .workspace
+                    .read(cx)
+                    .tabs
+                    .first()
+                    .is_some_and(|tab| tab.read(cx).visible_text().contains("TARGET READY"))
+            })
+            .await;
+            cx.update_window(fixture.window, |_, window, cx| {
+                fixture.workspace.update(cx, |view, cx| {
+                    view.show_connections = false;
+                    view.close_tab(&crate::workspace::CloseTab, window, cx);
+                });
+            })
+            .checked("a completed target releases its prefix when its last tab closes");
+        }
+        cx.wait_for(fixture.window, Duration::from_secs(10), |_, _| {
+            route.gateway_state.alive.load(Ordering::Acquire) == 0
+                && route.target_state.alive.load(Ordering::Acquire) == 0
+        })
+        .await;
+    }
+}
+
 #[gpui_kit::test]
 async fn multiwindow_close_rejects_format_only_drift_then_reaps_a_and_keeps_b_ssh_live(
     cx: &mut TestAppContext,
 ) {
     let (first, route) = mount_route(cx, false, true);
     let a_terminal = connected(&first, &route, cx).await;
     let second = super::super::windows::open_empty(&first, cx);
     let b_terminal = connected(&second, &route, cx).await;
```
