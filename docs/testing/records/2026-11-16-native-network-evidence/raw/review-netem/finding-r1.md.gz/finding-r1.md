# NETEM-R1-P2-01 — OPEN / P2

超时后仍存活的创建进程没有先停止和回收，资源检查可以提前记为 absent。

- 位置：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/ssh_path_netem_lab.py:229`（229–233）；同文件 368–373、656–661、679–685。
- 触发：Podman create/build/network create 超时或中断，名称已登记但后台变更还没有已知终态。
- 影响：cleanup 的一次 exists=1 会先写 absent=true；稍后停止客户端后没有资源复查，且客户端退出不能单独证明 daemon 侧请求已取消。延后创建可能留下资源而 cleanup.confirmed=true。该问题不将 FAILED 改为 MEASURED，也不推翻无超时的 r5 样本。
- 独立复现：`timeout-ownership-probes-r1.json`，exit 0，2/2 probes；真实自有 Python 子进程在超时与 exists 检查时都存活，最后 terminate/wait 回收。Podman 完全模拟，没有启动真实 lab 或制造实际晚到资源。
- 直接修复：在 absence 签署前停止/reap 创建客户端，解析精确自有结果；daemon 侧完成未知保持 UNKNOWN/CleanupUnconfirmed，并在取消屏障后复查。增加 timeout/signal 后延迟创建的有界回归。

当前建议 REQUEST_CHANGES，仅限五文件；其余源码/原件审查继续中。旧失败和成功原件均保留。
