# r2 残余 P2：异常退出的创建客户端仍被标成 COMPLETED

原发现 NETEM-R1-P2-01 保持 OPEN_RESIDUAL（本轮跟踪 NETEM-R2-P2-01，同一发现只计一次）。r1 的抛异常 timeout/check_interrupt 路径已修；独立红 2/2 失败、绿 24/24 通过。

位置：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/ssh_path_netem_lab.py:260`（260–265）；关联 391–407、437–443、734–741。源码 SHA256 `c1e1622715029963c9584b36066e33d36d21690f5b3b4ebb7bfcb96b7cad60ae`。

客户端若非零退出或被信号杀死，wait_bounded 返回 rc，创建状态先被写成 COMPLETED，然后才由 code-not-allowed 抛 CommandFailed。该路径没有证据证明已被 daemon 接收的请求结束。cleanup 只对 PENDING/UNKNOWN 拒绝签 absent，因而这个 COMPLETED 旁路可洗白未知。

`abnormal-client-probes-r2.json` 独立执行 exit0/reaped：真实自有 Python child 分别 exit125 和 SIGTERM/-15，均被记 COMPLETED；模拟 daemon 延迟出现前第一次 cleanup 已 absent=true，后来精确删除后第二次也 absent=true。模拟使用私有 thread/marker，没有 Podman 或真实 lab 副作用。

建议：创建客户端 generic 非零/信号退出保留 UNKNOWN；只有明确 daemon 终态才能转 COMPLETED。保留精确自有删除及 id/name 核对，但重复 absence 不能洗白 UNKNOWN；增加两种异常退出负例。r6 正常创建全 rc0，成功样本和实际清理原件继续有效。全仓 full-gate-r2 单列 PENDING。
