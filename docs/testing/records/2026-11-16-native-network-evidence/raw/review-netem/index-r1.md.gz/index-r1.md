# r1 报告入口与查询身份说明

结论保持 **REQUEST_CHANGES_SCOPED，P0=0 / P1=0 / P2=1 / P3=0**。父已接手 P2 修复；这份 r1 的固定源码与失败/成功原件均保留，尚未复核新冻结。

- [完整 Markdown 报告](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/native-network-20261116/review-netem/report-r1.md)
- [完整 JSON 报告](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/native-network-20261116/review-netem/report-r1.json)
- [五源码与 691 原件逐项哈希](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/native-network-20261116/review-netem/source-evidence-r1.json)
- [OPEN P2 与独立复现](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/native-network-20261116/review-netem/finding-r1.json)
- [逐命令 exit/count](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/native-network-20261116/review-netem/command-index-r1.json)
- [只读 cleanup 原始查询结果](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/native-network-20261116/review-netem/live-readback-r1.json)

对 Markdown cleanup 段的一处表述补充：45 条自有资源查询中，**42 条完整 ID、3 条精确名称**；名称查询除早期 capability probe 的 image/network，还包括未取得 image ID 的失败 real-r1。三条名称查询及其 exit 均逐项保存在 [clarification-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/native-network-20261116/review-netem/clarification-r1.json)。45 条都为预期 exit1/absent；共享基础镜像另 1 条 exit0；最终 r5 的 9 项全部是完整 ID。原 r1 不改写，样本、发现、哈希和建议不受此表述补充影响。

独立 Python 22/22、2 个负分支 probes、38 个 raw qdisc 独立解码、1,728 项原件审计核对、6 项保存的 tc/UAPI 对照；45 资源 absent / 共享镜像保留 / 578 birth identity 无存活 / 4 私有目录 absent。没有新真实 lab、Rust 重编译或原生/生产性能签署。
