# Linux IP/netem 独立只读复核 r1

结论：**REQUEST_CHANGES_SCOPED**。固定 baseline `5a6b30a2b9cca6d89aea551409738145608ac689`，仅复核五个新增 netem 文件。开放发现 **P0=0 / P1=0 / P2=1 / P3=0**。其余已审轴没有新增可执行发现。父已接受 P2 并自行修改 runner 与 Python 测试；本 r1 保留原始 OPEN 结论，新冻结应另编号窄差分复核。

**需修复：NETEM-R1-P2-01，超时创建尚未结束即签资源 absent。**

位置：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/ssh_path_netem_lab.py:229`（229–233）；同文件 368–373、656–661、679–685。

触发：Podman create / build / network create 超时或中断，名称已预登记，创建客户端或 daemon 侧请求还没有已知终态。`command()` 抛出异常时子进程仍可存活；`cleanup()` 先查询 exists，返回 1 就签 absent，随后才由 `shutdown()` 停止/reap 客户端，且没有屏障后的资源复查。

影响：晚到的后台创建可发生在 exists 检查之后，留下资源却让 cleanup.confirmed=true。进程回收本身不证明 daemon 侧请求已取消。顶层运行仍会 FAILED；这是清理证据与资源归属的问题，不把无超时的 r5 成功原件改签失败。

独立复现见 `timeout-ownership-probes-r1.json`：单独 Python 进程 exit 0 / reaped，2/2 probes。真实自有短命子进程在 CommandDeadline 及 cleanup exists 检查时都存活，cleanup 返回 absent=true；最后由 reviewer terminate/wait，子进程 exit -15 / reaped。Podman 完全模拟，没有制造真实晚到资源。直接修复：在核对资源前先停止/reap 超时或中断的创建客户端；daemon 完成未知保持 UNKNOWN/CleanupUnconfirmed，重复 exists 不能消除这一未知。增加 timeout/signal 后延迟完成的负例，并仅对精确自有资源完成屏障后核对。详见 `finding-r1.json` / `finding-r1.md`。

**源码与原件绑定。**

| 五文件 | 字节数 | SHA-256 |
| --- | ---: | --- |
| `scripts/ssh_path_netem_lab.py` | 38072 | `ea927b8d8f54de753af1da02829a7d362308707ff66684fc15e910a648ea5d10` |
| `scripts/test_ssh_path_netem_lab.py` | 21553 | `e0c1e2e5c5a992cfa845c95b9a2597d640a73d6221006adb199a2a189f44a4c7` |
| `scripts/ssh_path_netem/Containerfile` | 370 | `3f008246788b62b25616aa918de004fd7d200b95ad889963192b944ffbb72c00` |
| `scripts/ssh_path_netem/container.py` | 8861 | `8f5fc88fdff71f504fda5f9f5a8f7cb5b77be97e1125594bca94e340500134b3` |
| `scripts/ssh_path_netem/qdisc.py` | 7601 | `afbdc86c4e3388a55e1052c394639b63f2ce631b013470d29ac430a756828abe` |

当前 HEAD 在开始复核时为指定 baseline；五文件当时均为 baseline 之外的新文件，不用空的 tracked diff 冒充已审新增内容。逐项 SHA 与作者 source-manifest、父 netem-import-r1 对齐。另有 3 个支持文件，仅作 runner/进程身份/SSH 测试上下文，没有扩大差分。`source-evidence-r1.json` 保存完整五源码、三支持文件及 **691 份原件** 的 path/bytes/SHA256；集合摘要 `20652a222d8044ce67b3d95c95f934f0fba5c57b69cb335d4c5f04ac7910362c`。最后读回 **5+3+691，零 mismatch**，时间 `2026-11-15T19:01:54.471795+00:00`。父随后开始的修复不属于这个冻结。

| 关键原件 | SHA-256 |
| --- | --- |
| `source-manifest.json` | `e5cf423219d4d751fd567ecaab16f7689c46164ceda9148eb94ad2aae82e6807` |
| `author-record.json` | `8d65f8633b7e1b15954ad96cb304c69fca64afcf279912ddb7a0f67b43a93fc2` |
| `real-r5/result.json` | `49b6f9f9273884aea2563474423811a1e903c8a8a33a34e3d5004f12f9a2f0d1` |
| `real-r4/result.json` | `d568379b2a95c845d493ac4b3597054ca4d0df1865c441b265b80a4765df7aed` |
| `real-r3/result.json` | `6ab5c0f77a30bd0c6566c4993b178fe7900c8ea41c75cae7ed0226b942d20e93` |
| `signal-r1/result.json` | `f22dbb75c21cafee3939805c2827b88ea41829787e92c3a38a2d11179a24523c` |
| `cleanup-final.json` | `45e17e56c6bc7b62a385ac492cc88ceee367eb8a38e88055ca28f2dc138d568f` |
| `kernel-probe-r1/steps.json` | `0a498bf08cb79fe87706f2725ce1a99ffdf55738cc82f5761c8dc552342502fe` |
| `uapi-readback.json` | `d8d7b83af3b60039f8bdb9eba0772f907e47ae66434a76538bee20e0249afd5f` |

**真实 r5 与独立核验。**

r5 原件为 `MEASURED / exit 0 / 31.709s`，155 条命令全部 reaped；146 条 exit 0，9 条验证 absent 的 exists 返回预期 exit 1。5 次 opt-in 各执行恰好 1 项通过；3 场景各 18，合计 **54 个 Passed 原始样本**。实际受损侧为 delay 20,000,000ns、loss_u32=214748364（约 5%），其余侧为零延迟/零丢包。源码、辅助文件与父预构建 SHA 前后不变，预构建摘要 `c8fdcf0925cdd098044152714635ccb3581f2cc7dede6bdcc5b90e3b3407551c`。这里的 Rust 数字来自原件审查；本 reviewer 没有重跑该二进制或独立重编译。

| 场景 | 样本 | A/B drops | 样本比较 wall | 整个测试命令耗时 |
| --- | ---: | --- | ---: | ---: |
| baseline | 18 | 0 / 0 | 0.534823583s | 0.864099s |
| direct-impaired | 18 | 7 / 0 | 1.760584250s | 2.794353s |
| relay-impaired | 18 | 0 / 6 | 1.984378708s | 3.264381s |

独立整数解码器没有导入作者 qdisc 实现：**38** 份历史/最终 raw netlink 消息全部与 JSON 解码值一致，其中 r5 **12** 份 before/after 均能匹配原始命令日志。原件摘要、精确样本顺序、预算、完整状态、中位数、身份、权限、counter delta 等 **1,728/1,728 审计检查**通过；这是派生核对数，不是测试用例数。保存的 Linux UAPI 明确对应 tcmsg、netem qopt、LATENCY64/JITTER64、STATS2/BASIC/QUEUE/PKT64。基础镜像旧头文件尚无可选 seed enum；另用原有 capability probe 的 VM tc JSON 与原始 attribute 14、delay/jitter/limit/loss 比对，**6/6** 通过。没有对 VM 执行新的 tc 或其他命令；不把历史 tc 查询写成 r5 的新查询。

独立 Python：`/opt/homebrew/opt/python@3.15/bin/python3.15 -B -m unittest discover -s scripts -p test_ssh_path_netem_lab.py -v`，显式 `PYTHONDONTWRITEBYTECODE=1`，30 秒上限，实际 **exit 0 / reaped / 0.249871s / 22 run / 22 passed / 0 failed / 0 skipped**。保留完整 stdout/stderr、摘要与参数在 `unit-tests-r1.json`。另外的 2 个负分支 probe 单列，不加进 22 项。

**已审合同与限制。**

- 真实网络损伤：`container.py:120` 的转发只复制字节并保留 half-close，没有 sleep/rate/应用字节丢弃。`qdisc.py:152` 在独立 gate eth0 创建真实 kernel root netem，原始 rtnetlink readback 确认参数。CONNECT 会终止并重新建立 TCP；接受的是这套明确拓扑上的 kernel 网络损伤，不是透明的 Internet 端到端拓扑。
- 同 logical target/route/pin：A 为 CONNECT A → target:2222；B 为 CONNECT B → jump:2223 → 127.0.0.1:2222。三份原始 review.txt 的最终 host/port/user/target fingerprint 相同，jump 独立 pin；原有 Rust 支持代码明确这样构造。5 次原始 opt-in 包含 precancel 与 target/jump 错 pin 拒绝。未扩大 Rust 差分。
- Drop 归因：受损两侧 before/after 队列均空，overlimits=0，transmitted+dropped 分别 109、135，均小于容量 1000，可排除这些窗口的队列溢出。清洁 control drops=0。**qdisc 窗口包围整个测试进程**，包含 Routes::connect/认证、比较后 check_alive 与关闭；plan timer 仅包围 plan.run。baseline 两个额外测试发生在 after-snapshot 之后。7/6 只能签为整个窗口的 eth0 qdisc skb 总 drops；没有逐协议/5-tuple/时间戳，不能证明每个 drop 属于 SSH IP、而非 ARP 等控制流，不能逐项归因到计时样本或推导重传成本。
- 隔离与权限：原件是一条 internal、DNS-free 的 IPv4 bridge；7 个独立 netns；gate 仅 NET_ADMIN=0x1000，server 仅 SETUID/SETGID/SYS_CHROOT=0x400c0。无 privileged/host network；只读 root、no-new-privileges、资源预算明确。6 个 gate publication 精确绑定 127.0.0.1，SSH server 无宿主 publication，目标和 jump 的开放/转发权限受固定端口约束。
- 失败不补签：r4 完成 54 samples 但受损两侧零 drop，仍为 **FAILED / exit1 / observations_admissible=false**；r3 1% 成功属于旧源码历史；signal-r1 为 **INTERRUPTED / 130 / cleanup confirmed / 不准入观察**。旧失败、部分报告与 qdisc bytes 保留；新输出目录不可复用。上述事实不能关闭新发现的未知创建终态分支。

**只读 cleanup 复查。**

本 reviewer 执行 **46 条有界只读 Podman exists**：45 个历史自有资源均为预期 exit1/absent；共享基础镜像一条 exit0/仍在。零意外结果、零跳过。45 中仅早期 capability probe 的 network/image 使用原回执中保留的精确名称，其来源限制保留；最终 r5 的 9 个资源都有完整 ID。按 PID + kernel birth 核对 **578 条**历史身份，0 存活、0 未知；**4/4** 私有目录 absent。r5 原 cleanup 另有 **155/155 host 子进程 reaped/observed_stopped、9/9 资源 absent**。没有启动 VM、lab、容器或清理任何他人资源。真实成功运行的 cleanup 证据与 OPEN P2 的超时路径分开评价。

**命令与边界。**

`command-index-r1.json` 逐批记录命令/exit/count；Git 的 5 个子命令参数和 stdout/stderr 在 `git-read-commands-r1.json`，46 条 Podman 查询在 `live-readback-r1.json`，独立 Python 命令在各自 JSON。下表 exit 指整个 shell batch；没有虚构未单独捕获的 pipeline 各阶段状态。0 项表示该批没有执行仓库 unit tests。

| 批次 | 命令/用途 | exit | 仓库 unit 数 |
| --- | --- | ---: | ---: |
| C01 | pwd; rg --files for instructions/netem manifests (read-only bootstrap) | 0 | 0 |
| C02 | cat RTK/global AGENTS/repo AGENTS/HANDOFF; rg memory review conventions | 0 | 0 |
| C03 | sed current HANDOFF/memory; rg memory; Python read-only source/evidence inventory | 0 | 0 |
| C04 | python3 -B: capture 5 source + 3 support + 691 evidence hashes; five read-only Git commands | 0 | 0 |
| C05 | nl/sed: qdisc.py, container.py, Containerfile, runner lines 1-250 | 0 | 0 |
| C06 | nl/sed: runner lines 249-726; unit source lines 1-235 | 0 | 0 |
| C07 | nl/sed: runner missing chunk; remaining unit source; rg support context | 0 | 0 |
| C08 | nl/sed: existing runner/process ownership/SSH route test support only | 0 | 0 |
| C09 | python3 -B: read author/result/UAPI/cleanup/unit original receipts | 0 | 0 |
| C10 | independent Python unittest discover, -B and PYTHONDONTWRITEBYTECODE=1, 30-second limit | 0 | 22 |
| C11 | python3 -B: targeted original r3/r4/r5/signal reports, raw qdisc snapshots and timing windows | 0 | 0 |
| C12 | independent Python timeout/ownership probes; real private child, mocked Podman exists | 0 | 0 |
| C13 | python3 -B: write numbered P2 finding JSON/Markdown inside review-netem | 0 | 0 |
| C14 | nl/sed and Python: shutdown/identity, sample timing, inspected resources and parent prebuilt provenance | 0 | 0 |
| C15 | python3 -B: independent integer UAPI decoder and source/raw evidence audit | 0 | 0 |
| C16 | python3 -B: 46 bounded read-only Podman exists commands; 578 birth-identity reads; four private-directory exists reads | 0 | 0 |
| C17 | python3 -B: read saved capability tc/UAPI/Podman version outputs; no new VM operation | 0 | 0 |
| C18 | python3 -B: six saved-tc/UAPI crosschecks; final 5+3+691 hash readback | 0 | 0 |
| C19 | python3 -B: assemble numbered JSON/Markdown report and validate required evidence counts | 0 | 0 |

本 reviewer 没有运行 Cargo/rustc/rustfmt，没有 Git 修改/提交/推送，没有创建 agent/chat，没有修改生产或测试源码，没有新真实网络实验、PodmanVM/资源变更或清理。测试仅使用自己的隔离临时夹具。所有持久写入均在指定 review-netem 下，为编号 JSON/Markdown。

父后续消息报告 full-gate-r1 **exit0 / reaped / 705.126s**，Rust/app 输入未再变化；该项单列为父报告，未冒充本 reviewer 的全门禁执行/核验。父正在处理 runner/test P2，新源码尚不由本 r1 签署。仍不签原生桌面、Internet 路由、每样本 drop、TCP 重传统计、裸带宽、ICMP RTT 或生产性能收益。

**合并建议：当前五文件冻结 REQUEST_CHANGES。** 父已接手修复；待精确新冻结、窄差分及有意义的 timeout/signal 负例后另行复核。r1、r4、signal 与 r5 原件保持各自真实状态，父全门禁成功不能替代这个分支的修复证据。
