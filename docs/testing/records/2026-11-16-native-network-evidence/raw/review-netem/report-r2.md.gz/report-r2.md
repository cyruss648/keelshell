r2 结论：**REQUEST_CHANGES_SCOPED**。P0=0、P1=0、P2=1、P3=0；沿用 `NETEM-R1-P2-01`，残余编号 `NETEM-R2-P2-01`，只计一项。r1 报告与原始失败不改写。

冻结基线 `5a6b30a2b9cca6d89aea551409738145608ac689`；r2 全部 699 项已独立核验，aggregate `4ba8a00cbce305bd7d4935a158104c89ceb8313e8c2d2431bd43fa1513fca2c4`。相对 r1 仅 runner/test 两路径变化，697 项不变；r2 观察点源码无漂移。现有 r3 另作后续复审。

| 范围源码 | r2 SHA-256 |
| --- | --- |
| `scripts/ssh_path_netem_lab.py` | `c1e1622715029963c9584b36066e33d36d21690f5b3b4ebb7bfcb96b7cad60ae` |
| `scripts/test_ssh_path_netem_lab.py` | `b6d35fd03b2e865a3c04a9d4e4f3c07ef849fa4df9052f84895a62bd02a23b00` |
| `scripts/ssh_path_netem/Containerfile` | `3f008246788b62b25616aa918de004fd7d200b95ad889963192b944ffbb72c00` |
| `scripts/ssh_path_netem/container.py` | `8f5fc88fdff71f504fda5f9f5a8f7cb5b77be97e1125594bca94e340500134b3` |
| `scripts/ssh_path_netem/qdisc.py` | `afbdc86c4e3388a55e1052c394639b63f2ce631b013470d29ac430a756828abe` |

**P2 触发与影响。** 冻结 r2 的 `scripts/ssh_path_netem_lab.py:260–265` 在客户端返回非零或被信号终止后，先把 creation 写成 COMPLETED，随后才拒绝该退出码。客户端被 reap 不证明 daemon 已完成接受的创建。独立实际 Python child 分别退出 125 与 -15，加有界模拟延迟 daemon，两次均在早期 absent 查询及晚到资源精确删除后被签 absent=true。cleanup 的 UNKNOWN 守卫（391–407、437–443）因状态错误被绕过。真实 r6 九项创建均 rc0，未触发该残余。精确位置、触发、影响和直接修复见 [finding-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/native-network-20261116/review-netem/finding-r2.json)。

直接修复：只有明确成功的创建回复可设 COMPLETED；非零/信号及异常均保持 UNKNOWN。仍尽力按 owner/full-ID 精确删除，但重复 absent 不能洗白 daemon 完成未知。父已接受并在下一冻结修复；本 r2 仍按原输入保留 REQUEST_CHANGES。

独立 Python：旧 runner 的 timeout/interrupt 两项红回归 **2 run/2 fail，exit1/reaped/0.444902s**；r2 专项 **24/24，exit0/reaped/0.955641s**；两项实际 child125/-15 残余探针 **2/2 复现，exit0/reaped/0.248681s**。均独立进程、30s 或更短上限、`PYTHONDONTWRITEBYTECODE=1`，未运行 Podman 实验。父全 Python **227 run=226 passed+1 skipped，exit0/reaped/9.423s** 仅审原件，未在 reviewer 重跑。

r6 原件：wrapper **exit0/reaped/34.975s**，内部 runner **34.907s**；5 次 opt-in、三场景各18，共54成功样本。qdisc A/B drops 为 baseline **0/0**、direct **4/0**、relay **0/11**。受损侧20ms/约5%；12份 before/after raw netlink 独立解码，**618/618** 只读证据检查通过，192原件 exact manifest SHA `908d35c0f26bfb44429416ac021c64b0b57cc469f2d538c6c59689e798e24ddb`。同 logical target/route/pin、内部 bridge、权限与六个127.0.0.1 publication 检查无额外发现。两受损侧 packet+drop 为116/134、队列上限1000、起止空队列且 overlimits0；drop 仅可归到完整调用的 qdisc skb 计数，不能签单样本或协议归因。

r6 清理：creator barrier **96/96**，final **164/164** reaped/observed-stopped；**9/9** 自有资源 absent/absence-observed，18原始 full-ID/name 检查，164命令为146 exit0+18预期absence exit1。独立只读回查 **19命令**：18自有资源查询exit1、共享base查询exit0；164原始birth无活匹配，私有目录absent。原691原件、16份r1报告/证据记录零漂移，旧证据集 SHA `20652a222d8044ce67b3d95c95f934f0fba5c57b69cb335d4c5f04ac7910362c`。明细保留在 [evidence-audit-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/native-network-20261116/review-netem/evidence-audit-r2.json) 与 [live-readback-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/native-network-20261116/review-netem/live-readback-r2.json)。

全仓最终门禁条件 **PENDING_PARENT_BINDING**。`full-gate-r2` 已实际停止，**exit-15/reaped/404.37s**，stop回执3条birth无活匹配；不能改签成功。r1完整门禁exit0为历史事实，不能满足后续r3冻结。app r2已由独立app reviewer批准，本报告不扩差分。

范围限制：仅新五文件及既有三文件支持上下文；没有Cargo/rustc/rustfmt、Rust独立重编译或预构建独立执行，没有新lab/VM变更/资源删除。真实运行消费父预构建 `c8fdcf0925cdd098044152714635ccb3581f2cc7dede6bdcc5b90e3b3407551c`；不作生产性能、真实Internet路径、单样本丢包、重传、裸带宽或桌面验收承诺。命令exit/count见 [command-index-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/native-network-20261116/review-netem/command-index-r2.json)，完整机器可读签署见 [report-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/native-network-20261116/review-netem/report-r2.json)。
