**r3：APPROVE_SCOPED_SOURCE。开放 P0/P1/P2/P3 = 0/0/0/0；原 P2 在本冻结关闭。全仓最终门禁 PENDING，由父绑定终态。**

基线 `5a6b30a2b9cca6d89aea551409738145608ac689`。699项独立核验、零漂移；aggregate `f435b9fa78f9a40bc2962fa3043b983cf5818e1ab4e34db5deae5960dfc50e21`。相对r2仅runner/test两项变化，其余697项不变。

- runner SHA-256：`1be28cee2d6ed7960b2e5cf082fd771bcae194e4bc6763e3ce7077ab1444a9ed`
- test SHA-256：`4dc4991e28cfcbc9e0a13470b186a5bb8755d9585e0dc94c970b6039e3395671`

关闭依据：[runner第265行](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/ssh_path_netem_lab.py:265)仅rc0设COMPLETED，非零/信号与异常均UNKNOWN；[cleanup第442行](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/ssh_path_netem_lab.py:442)在重复absent及精确自有删除后仍保持未知，先stop/reap的creator barrier保留。旧r1/r2报告与原691原件保留、hash无漂移，不补签旧失败。

独立执行：旧r2 runner配精确r3测试 **2run/2fail，exit1/reaped/0.313961s**；r3专项 **26/26，exit0/reaped/0.891337s**，含timeout、interrupt、125及实际self-SIGTERM四分支。均独立进程、有界30s、禁写bytecode；daemon晚到为私有thread/marker模拟，不是新真实故障实验。

r7原件已核：wrapper **exit0/reaped/35.523s**、runner **35.456s**；5opt-in、3×18=54样本，drops A/B **0/0、7/0、0/8**。12份raw qdisc独立解码，**249/249**本轮原件检查通过；192原件manifest SHA `b27f33f412a08e55c07ba4d889f15f7a914c746c4781ec3cfb74ae52fea7e903`。creator **96/96**、final **164/164** reaped/observed-stopped，9资源、18个ID/name终查均confirmed。

reviewer追加只读 **19次exists**：18自有查询exit1，共享base查询exit0；164条birth无活匹配、6端口关闭、私有目录absent。原691文件与699输入末次读回均零漂移。

仅签新五文件的限定源码；app不重审。父预构建没有被本reviewer独立重编译或执行；无Cargo、新lab、Podman/VM修改或资源删除。drop仅为完整调用窗口qdisc skb计数，不承诺单样本归因或生产性能。`full-gate-r3` **PENDING**；已中止r2 gate仍exit-15，不作成功。

原件及每命令exit/count见 [report-r3.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/native-network-20261116/review-netem/report-r3.json)、[command-index-r3.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/native-network-20261116/review-netem/command-index-r3.json)、[evidence-audit-r3.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/native-network-20261116/review-netem/evidence-audit-r3.json)、[live-readback-r3.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/native-network-20261116/review-netem/live-readback-r3.json)；P2关闭见 [closure-r3.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/native-network-20261116/review-netem/closure-r3.json)。
