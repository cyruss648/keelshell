"""Export immutable originals before deleting this batch's disposable workspace."""
import gzip
import hashlib
import json
from pathlib import Path
import re

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
DEST = ROOT / "docs/testing/records/2026-11-16-native-network-evidence"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    final_gate = json.loads((BASE / "full-gate-r3.json").read_text())
    assert final_gate["exit"] == 0 and final_gate["reaped"]
    assert (BASE / "review-netem/report-r3.json").is_file()
    assert (BASE / "review-resolution-r1.json").is_file()
    exported, omitted = {}, []
    for path in sorted(BASE.rglob("*")):
        if not path.is_file():
            continue
        assert not path.is_symlink(), path
        relative = path.relative_to(BASE)
        name = relative.as_posix()
        data = path.read_bytes()
        discard = (
            relative.parts[0] == "bins"
            or (relative.parts[0] in ("package-r1", "package-r2")
                and path.name != "package-manifest.json")
            or name == "native_ax"
            or "__pycache__" in relative.parts or path.suffix == ".pyc"
        )
        if discard:
            omitted.append({"path": name, "bytes": len(data), "sha256": sha(data),
                            "reason": "Rebuildable binary/cache/package member; provenance and manifests retained"})
            continue
        # Match a complete PEM payload, not this helper's own marker literals.
        assert not re.search(
            rb"-----BEGIN (?:OPENSSH|RSA|EC) PRIVATE KEY-----\s+"
            rb"[A-Za-z0-9+/=\s]+-----END (?:OPENSSH|RSA|EC) PRIVATE KEY-----",
            data,
        ), name
        compressed = gzip.compress(data, mtime=0)
        target = DEST / "raw" / (name + ".gz")
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as stream:
            stream.write(compressed)
        assert gzip.decompress(target.read_bytes()) == data
        exported[name] = {
            "source_bytes": len(data), "source_sha256": sha(data),
            "artifact": target.relative_to(DEST).as_posix(),
            "artifact_bytes": len(compressed), "artifact_sha256": sha(compressed),
        }
    manifest = {
        "schema": 1, "source_directory": BASE.name,
        "count": len(exported),
        "source_bytes": sum(item["source_bytes"] for item in exported.values()),
        "artifact_bytes": sum(item["artifact_bytes"] for item in exported.values()),
        "files": exported,
    }
    for name, value in (
        ("archive-manifest.json", manifest),
        ("omitted-artifacts.json", {
            "schema": 1, "count": len(omitted),
            "bytes": sum(item["bytes"] for item in omitted), "files": omitted,
        }),
    ):
        with (DEST / name).open("x") as stream:
            json.dump(value, stream, indent=2)
            stream.write("\n")
    print(json.dumps({key: manifest[key] for key in
                      ("count", "source_bytes", "artifact_bytes")}))


if __name__ == "__main__":
    main()
