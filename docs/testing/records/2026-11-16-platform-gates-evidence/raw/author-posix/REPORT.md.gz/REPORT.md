# Windows Python lab applicability and import boundary

Status: **READY_FOR_PARENT_REVIEW**. No commit or push. The managed author
worktree remains available for parent review and archival.

Baseline and current HEAD: `4fd193227bb9e5e5e4b49ad6f1503f10741f7383`.

## Delivery

- Patch: [`integration.diff`](integration.diff).
- Exact baseline/final file hashes, patch hash, test binding and read-only Git
  check receipts: [`integration.receipt.json`](integration.receipt.json).
- Patch SHA-256:
  `6cf439d80e56a17cd027284a8fbf49cebb9ed430c9a960a58095a000ed5597d9`.
- `git diff --check` and reverse `git apply --check` both exited 0.
- Exactly the five authorized test files and the previously announced monitor
  fixture import boundary changed. The two Windows owner files are byte-for-byte
  identical to the baseline; their hashes are in [`scope-check-r1.json`](scope-check-r1.json).

The patch changes these paths:

| Path | Reason and resulting behavior |
| --- | --- |
| `scripts/test_linux_file_interop.py` | Guard only the three real `ProcessTests`; ownership, command construction and seven controlled inventory/deadline contracts remain active. |
| `scripts/test_linux_local_backend.py` | Guard the two real runner process tests. Keep the exhausted-budget and all synthetic failure/acceptance tests active. The mocked cleanup failure now asserts the exact recorded PID, birth identity and mocked SIGKILL argument. |
| `scripts/test_ssh_path_lab.py` | Guard only real shebang inventory execution and the gate process that needs POSIX asyncio signal handlers/graceful SIGTERM. Keep loopback stream tests and the mocked emergency cleanup test active. |
| `scripts/test_ssh_path_netem_lab.py` | Guard the four real owned-client mutation tests and the real shebang inventory test. Keep netlink wire parsing, mocked exchanges, strict report/security/UNKNOWN contracts, loopback forwarding, digest rejection and CLI tests active. |
| `scripts/test_monitor_recovery_lab.py` | Guard the four real mutation clients, capture-failure child, real df wrapper and real shebang inventory child. Preserve portable collector/authentication/state/isolation contracts and add explicit import-boundary tests. |
| `scripts/monitor_recovery/fixture.py` | Move `fcntl` into `locked_state()` and `pwd` into `guard()`/`prepare()`. Imports are unconditional at the point of runtime use; no fallback, dependency stub or swallowed ImportError is introduced. |

## Cause and applicability

The parent's supplied, read-only `windows-job-r2.sanitized.log` reports 262 tests,
20 error entries, 2 failures and 15 skips. Several errors repeat the same test
when both its body and teardown fail. The actual failure paths are:

1. `openssh_interop.process_info()` explicitly supports only Linux `/proc` or
   Darwin `libproc` birth identities. Launching these runners on Windows fails
   after Popen; POSIX cleanup then references missing `SIGKILL`, leaving log
   handles open and causing WinError 32 during temporary-directory removal.
2. `ssh_path_lab.serve_gate()` uses asyncio signal handlers and expects a
   graceful SIGTERM exit. A Windows event loop/process does not satisfy that
   contract.
3. Valid runner invocations reject unsupported platforms before later inventory
   and digest checks.
4. The monitor fixture imported `fcntl` and `pwd` while loading constants and
   pure contracts. CI first failed at `fcntl`; moving only that import would
   expose the `pwd` import failure next.

The guards use the runners' exact supported OS set, `Darwin` and `Linux`, rather
than treating every POSIX platform as supported or checking only for SIGKILL.
They mark 19 individual real-capability cases as skipped on Windows. No module
is skipped. All original UNKNOWN, identity, cleanup, error, private-data,
authentication and isolation assertions remain.

Synthetic signal tests replace only their module's signal binding while the
signal-delivery function and process are already mocks. No real signaling is
introduced. CLI-only tests select a supported synthetic host so numeric,
no-op, digest and evidence-preservation checks actually reach their intended
branches on Windows. Three added tests separately prove Windows and FreeBSD
are rejected before output creation or any child launch.

The three new fixture tests prove portable import without fcntl/pwd, explicit
ModuleNotFoundError when their runtime capabilities are called, and propagation
of a genuinely missing portable dependency (`hashlib`) at import.

## Observed validation

All runs use only the five authorized Python test modules. No repository-wide
gate, Cargo invocation, target access, container, GUI, installation or main
checkout mutation was performed.

| Run | Discovered / run | Passed | Skipped | Failures | Errors | Exit | Wall time |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Real macOS Python, `native-r1` | 127 | 127 | 0 | 0 | 0 | 0 | 6.929 s |
| Windows boundary simulation, `windows-contracts-r2` | 127 | 108 | 19 | 0 | 0 | 0 | 0.566 s |
| FreeBSD boundary simulation, `freebsd-contracts-r1` | 127 | 108 | 19 | 0 | 0 | 0 | 0.833 s |

The six added tests account for the increase from the original 121 scoped test
methods to 127. The Windows and FreeBSD rows are **macOS-hosted boundary
simulations**, not execution on those operating systems.

| Module | Real macOS passed | Windows simulation passed | Precisely skipped |
| --- | ---: | ---: | ---: |
| `test_linux_file_interop` | 17 | 14 | 3 |
| `test_linux_local_backend` | 39 | 37 | 2 |
| `test_ssh_path_lab` | 17 | 15 | 2 |
| `test_ssh_path_netem_lab` | 27 | 22 | 5 |
| `test_monitor_recovery_lab` | 27 | 20 | 7 |
| Total | 127 | 108 | 19 |

Raw artifacts:

- [`native-r1.log`](native-r1.log), [`native-r1.receipt.json`](native-r1.receipt.json),
  [`native-r1.results.json`](native-r1.results.json).
- [`windows-contracts-r2.log`](windows-contracts-r2.log),
  [`windows-contracts-r2.receipt.json`](windows-contracts-r2.receipt.json),
  [`windows-contracts-r2.results.json`](windows-contracts-r2.results.json).
- [`freebsd-contracts-r1.log`](freebsd-contracts-r1.log),
  [`freebsd-contracts-r1.receipt.json`](freebsd-contracts-r1.receipt.json),
  [`freebsd-contracts-r1.results.json`](freebsd-contracts-r1.results.json).
- Preserved pre-fix safety-blocked simulation:
  [`baseline-windows-contracts-r1.log`](baseline-windows-contracts-r1.log),
  [`baseline-windows-contracts-r1.receipt.json`](baseline-windows-contracts-r1.receipt.json),
  [`baseline-windows-contracts-r1.results.json`](baseline-windows-contracts-r1.results.json).
  This local baseline ran 99 loader entries: 83 passed, 10 failures, 6 errors.
  It intentionally prevented 10 unmocked child launches, and monitor discovery
  collapsed to one failed import. These are simulation numbers, not the actual
  Windows CI counts.

The simulations remove SIGKILL, make fcntl/pwd imports unavailable, and forbid
unmocked subprocess launches. After the fix there were zero forbidden launch
attempts and zero real children in both simulations. Their results contain the
full discovered and skipped method names.

Every outer process had a 55-second timeout and was actually waited/reaped;
none timed out. The real macOS worker recorded 186 direct Popen children,
including bounded process-table probes. All already had reaped return codes at
suite completion; emergency cleanup was unused. Existing descendant
birth-identity/exit assertions also executed. The run produced one gate-child
bytecode artifact; its creation time was bound to this run and only that owned
file was removed. [`bytecode-cleanup-r1.json`](bytecode-cleanup-r1.json) records
its hash and absence; the harness now propagates PYTHONDONTWRITEBYTECODE to
future child invocations. No remaining script bytecode was found.

## Integration and unverified boundaries

The parent can inspect or apply `integration.diff` against the stated baseline;
all six final source hashes match all three successful result receipts.
[`integration-checks.log`](integration-checks.log) preserves the exact
read-only verification commands and exit codes.

Actual Windows Python execution, Windows symlink privileges, Windows asyncio
loopback behavior, the full CI discovery inventory and the parent's native
Windows owner-test correction remain unverified by this author. The simulation
does not change Python into a Windows runtime. Actual Linux execution and
native application acceptance are also NOT_RUN. The parent should integrate
this patch with its separately owned Windows correction and obtain the real
Windows CI result.

The author has not committed, pushed, archived the worktree or changed the
parent's Windows owner files. Parent review is pending.
