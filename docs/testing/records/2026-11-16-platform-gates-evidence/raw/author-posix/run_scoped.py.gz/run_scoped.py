"""Bounded outer process and raw-log receipt for the five authorized modules."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("label")
    parser.add_argument("mode", choices=("native", "Windows", "FreeBSD"))
    args = parser.parse_args()
    log = HERE / f"{args.label}.log"
    receipt = HERE / f"{args.label}.receipt.json"
    summary = HERE / f"{args.label}.results.json"
    command = [sys.executable, "-B", str(HERE / "suite_worker.py"), args.mode, str(summary)]
    started_utc = datetime.now(timezone.utc).isoformat()
    started = time.monotonic()
    timed_out = False
    with log.open("xb") as output:
        process = subprocess.Popen(
            command, cwd=ROOT, stdin=subprocess.DEVNULL, stdout=output,
            stderr=subprocess.STDOUT, start_new_session=True,
            env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
        )
        try:
            code = process.wait(timeout=55)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGTERM)
            try:
                code = process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                code = process.wait(timeout=2)
    value = {
        "label": args.label,
        "mode": args.mode,
        "command": command,
        "cwd": str(ROOT),
        "started_utc": started_utc,
        "elapsed_seconds": time.monotonic() - started,
        "timeout_seconds": 55,
        "timed_out": timed_out,
        "pid": process.pid,
        "returncode": code,
        "reaped": process.returncode is not None,
        "log": str(log),
        "log_sha256": hashlib.sha256(log.read_bytes()).hexdigest(),
        "results": str(summary),
    }
    receipt.write_text(json.dumps(value, indent=2) + "\n")
    print(json.dumps(value, indent=2))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
