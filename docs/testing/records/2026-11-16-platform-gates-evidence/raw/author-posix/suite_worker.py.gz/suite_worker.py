"""Scoped evidence worker; Windows mode checks contracts, not native acceptance."""

import argparse
from collections import Counter
from contextlib import ExitStack
import hashlib
import json
from pathlib import Path
import platform
import signal
import subprocess
import sys
import time
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
MODULES = (
    "test_linux_file_interop",
    "test_linux_local_backend",
    "test_ssh_path_lab",
    "test_ssh_path_netem_lab",
    "test_monitor_recovery_lab",
)
SOURCES = [f"scripts/{name}.py" for name in MODULES]
SOURCES.append("scripts/monitor_recovery/fixture.py")
sys.path.insert(0, str(ROOT / "scripts"))


def flatten(suite):
    for item in suite:
        if isinstance(item, unittest.TestSuite):
            yield from flatten(item)
        else:
            yield item


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("native", "Windows", "FreeBSD"))
    parser.add_argument("result", type=Path)
    args = parser.parse_args()
    started = time.monotonic()
    spawned = []
    forbidden = []
    real_popen = subprocess.Popen

    class TrackedPopen(real_popen):
        def __init__(self, *argv, **kwargs):
            super().__init__(*argv, **kwargs)
            spawned.append(self)

    def no_process(*argv, **kwargs):
        forbidden.append(repr(argv))
        raise AssertionError("A portable contract attempted an unmocked child launch")

    with ExitStack() as stack:
        if args.mode != "native":
            stack.enter_context(patch.object(platform, "system", return_value=args.mode))
            stack.enter_context(patch.dict(sys.modules, {"fcntl": None, "pwd": None}))
            if hasattr(signal, "SIGKILL"):
                old_kill = signal.SIGKILL
                del signal.SIGKILL
                stack.callback(setattr, signal, "SIGKILL", old_kill)
            stack.enter_context(patch.object(subprocess, "Popen", side_effect=no_process))
        else:
            stack.enter_context(patch.object(subprocess, "Popen", TrackedPopen))
        suite = unittest.defaultTestLoader.loadTestsFromNames(MODULES)
        inventory = [test.id() for test in flatten(suite)]
        result = unittest.TextTestRunner(verbosity=2).run(suite)

    live = [process.pid for process in spawned if process.returncode is None]
    emergency_reaps = []
    for process in spawned:
        if process.returncode is None:
            process.kill()
            process.wait(timeout=3)
            emergency_reaps.append(process.pid)
    value = {
        "mode": args.mode,
        "boundary": "Windows/FreeBSD modes emulate platform/import/signal boundaries on macOS; no native acceptance",
        "host": platform.platform(),
        "python": sys.version,
        "elapsed_seconds": time.monotonic() - started,
        "inventory": inventory,
        "inventory_by_module": dict(Counter(name.split(".")[0] for name in inventory)),
        "tests_run": result.testsRun,
        "passed": result.testsRun - len(result.skipped) - len(result.failures) - len(result.errors),
        "failures": [test.id() for test, _ in result.failures],
        "errors": [test.id() for test, _ in result.errors],
        "skipped": [{"test": test.id(), "reason": reason} for test, reason in result.skipped],
        "forbidden_process_attempts": forbidden,
        "spawned_children": [{"pid": process.pid, "returncode": process.returncode} for process in spawned],
        "children_all_reaped_by_suite": not live,
        "emergency_reaps": emergency_reaps,
        "source_sha256": {
            name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in SOURCES
        },
    }
    args.result.write_text(json.dumps(value, indent=2) + "\n")
    return 0 if result.wasSuccessful() and not live and not forbidden else 1


if __name__ == "__main__":
    raise SystemExit(main())
