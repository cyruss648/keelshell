# Deferred native reverse-Tab investigation

This is an investigation note, not a fix or native acceptance.

The previous actual Frost/macOS file-browser run reached both lists by forward Tab.
Reverse Tab did not reach them in 180 events and ended in the command textarea.
Keep that result HOLD. Graphite/Lavender, IME and assistive technology remain open.

Current locked GPUI Kit/base/component are 0.9.1. Read dependency source from
`rsproxy.cn-e3de039b2554c837/gpui-base-0.9.1` under the local Cargo registry,
not older cached versions. No dependency source has been edited.

Confirmed source observations:

- GPUI macOS parses U+0019 as key `tab`, retaining the shift modifier.
- `gpui-base/src/root.rs` binds shift-tab to root `TabPrev`.
- `src/input/base/mode.rs` defines the textarea's default layout as `PlainText`.
- `src/input/editor/indent.rs` considers `PlainText` indentable. `apply_indent`
  returns without propagating when the computed edit set is empty.
- `src/input/base/state.rs` registers multiline indent/outdent action handlers.
- KeelShell creates its command input with `TextareaState::new(...).rows(2)`
  in `crates/keelshell-app/src/workspace.rs`. The command bar in
  `workspace/view.rs` captures completion/arrows/Escape/Enter but no tab action.

This suggests the command textarea may consume reverse Tab as outdent, including
when no edit is possible. It does not prove the complete native failure cause.
Next work should reproduce at the actual command focus, assert that navigation
preserves command bytes, and scope any routing to the composer only. Preserve
editor indentation, IME composition, terminal input and active modal ownership.
Use a new regression before a production change, then actual reverse-Tab
observation on the newly built native program. Do not close HOLD from headless
GPUI dispatch alone.
