# 精确 SHA 的 CI 只读回执

- 仓库：`cyruss648/keelshell`；固定 SHA：`4fd193227bb9e5e5e4b49ad6f1503f10741f7383`。
- 本地 HEAD 读回：`4fd193227bb9e5e5e4b49ad6f1503f10741f7383`。
- 查询时间：2026-11-16T02:01:35.865327+00:00；事件 `push`；工作流 `Quality / ci.yml`。

## 当前 4fd 运行

Run `43789081172` / attempt `1`：`in_progress` / `None`；head_sha `4fd193227bb9e5e5e4b49ad6f1503f10741f7383`；event `push`。

| Job ID | 平台/名称 | 状态 | 结论 |
| --- | --- | --- | --- |
| 133043263253 | native (windows-2025) | completed | failure |
| 133043263463 | native (ubuntu-24.04) | in_progress | None |
| 133043263469 | native (macos-26) | in_progress | None |

失败 job `133043263253` 的 API 失败 step：5: Rust quality gate。不推断根因。

## 旧运行（与本次分开）

- `e67266107e7493dc97235c97a759c1c6904b4c9a`：run `43788787155` / attempt `1` / event `push` / `completed` / `cancelled`。
- `6d80c259b9a80facbf0f2fdeea986e18978c714f`：run `43787872183` / attempt `1` / event `push` / `completed` / `cancelled`。
- `e709d02d86ccfbb1a01677f7cda618b64050765b`：run `43786596563` / attempt `1` / event `push` / `completed` / `cancelled`。

## 边界与执行证据

- 总查询耗时 9.179 秒。每个子进程均有超时并 communicate/wait 实际 reap；见 receipt.json。
- 仅使用 gh API GET 和 git rev-parse HEAD；只写本目录。
- 运行中/排队 job 仍待后续验证，不等待终态，不代表三平台原生验收。
- 原响应可能截在每页 30 runs / 100 jobs；未遍历更早历史。
- 没有运行 Cargo、编译、修改源码/共享 target、Git 写入或远端写入。

- Windows 失败日志仅 GET 一次，实际 exit 1 / reaped，gh 拒绝输出含 terminal escape sequences 的响应；原 stdout/stderr 已保留。未取得可审计的具体错误正文，根因未验证，不重试。
