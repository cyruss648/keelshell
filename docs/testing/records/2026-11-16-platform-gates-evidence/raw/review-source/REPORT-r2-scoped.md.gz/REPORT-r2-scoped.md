截至 2026-11-16，**限定批准六文件 POSIX 适用性、Windows 夹具诊断及 workflow 共八文件的源码范围；整个候选仍等待 r3 归档增量，暂不作最终批准。**
这份报告由本批新开的非作者 reviewer 独立读取源码并执行专项后形成；
作者及父方结果没有计作本 reviewer 的独立执行。

| 评审范围 | P0 | P1 | P2 | P3 | 判断 |
| --- | ---: | ---: | ---: | ---: | --- |
| 六文件 POSIX 适用性及懒导入 | 0 | 0 | 0 | 0 | APPROVE_SCOPED |
| Windows 夹具诊断单文件 | 0 | 0 | 0 | 0 | APPROVE_DIAGNOSTICS_ONLY |
| workflow 两行增量 | 0 | 0 | 0 | 0 | APPROVE_SCOPED |
| 归档两文件 | 未最终签署 | 未最终签署 | 见 notice 中两项待处理 | 未最终签署 | HOLD_FOR_R3 |

**来源和只读边界**

工作目录为 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`，
实际读取 HEAD 为指定基线 `4fd193227bb9e5e5e4b49ad6f1503f10741f7383`。
已读取 AGENTS、RTK、HANDOFF 当前批次及持续约束。
写入仅在本 `review-source/`；使用 `-B`、`PYTHONDONTWRITEBYTECODE`，
测试临时目录固定在本目录的 `scratch/`。未执行 Cargo、格式化、源文件修改、
提交、push、target 操作、容器或 GUI；测试只管理自行启动的隔离子进程和回环服务。

r1 的 717 项工程字节逐项相符，集合 SHA-256 为
`6bf6b1abb5cfaaeada90b5eddb191c5d24ba963acb3e2c9eefa63b145b50afb5`，
九文件当前 Git 差分与 `candidate-r1.diff` 逐字节相同。
`source-before.json` 保存读取前摘要与路径，九份候选和基线源码分别原样复制在
`candidate-originals/`、`baseline-originals/`。

r2 的 717 项也在接收时逐项相符，重新计算集合 SHA-256 为
`d826de85d8c62ae38fc8475824d6dff4d55f8f120a621588b45a373f8d19b505`。
独立比较 r1/r2 清单，唯一变化为 `.github/workflows/ci.yml`：
`d0c199a9b66108d1015f303b5ec362d2ad956df010fc306d87e6c0619d85a418`
变为 `9a1093af5660890adb1eb5619d928205fa4207bf082777f88b05704a02f9dfb1`。
其余 716 项保持，十文件差分与 `candidate-r2.diff` 相同。
这项授权增量不是漂移失败，详见 `r1-to-r2-binding.json`。
八文件审查后的摘要为零 mismatch，见 `nonarchive-source-after-r2.json`。

**六文件结论及精确源码位置**

- `scripts/test_linux_file_interop.py:24–27,251–305` 仅为真实进程类的三项测试增加 Darwin/Linux 条件；所有权、命令构造、超时和清理纯合同仍运行。
- `scripts/test_linux_local_backend.py:23–26,363–395` 精确限制两项真实进程合同；`:429–453` 将 mock 的信号参数变成独立 mock 数据，并仍断言向精确 PID/identity 传入 SIGKILL，未删除清理失败断言。
- `scripts/test_monitor_recovery_lab.py:28–31,126–140,154–168,309–347,402–424` 精确限制七项真实宿主实验；`:234–255` 对懒导入、执行时缺依赖和普通依赖导入失败均保留显式错误；`:389–399,426–458` 分开校验支持宿主下的 CLI/摘要合同与不支持宿主先拒绝、不创建目录或进程的合同。
- `scripts/test_ssh_path_lab.py:21–24,267–323` 仅限制两项真实子进程；`:212–245` 分别覆盖支持宿主 CLI 校验和不支持宿主入口拒绝；`:257–265` 的 mock 信号仍校验精确身份并保持未确认清理状态。五个真实 TCP 回环转发测试不被跳过。
- `scripts/test_ssh_path_netem_lab.py:24–27,295–309,439–457` 精确限制五项真实子进程；`:408–437,475–489` 使纯 CLI/证据合同继续执行，同时明确不支持宿主无副作用拒绝。Netlink 字节解析和真实 TCP 回环合同不被跳过。
- `scripts/monitor_recovery/fixture.py:127–136,165–175,237–280` 将 `fcntl` 只移到锁上下文入口，将 `pwd` 只移到 guard/prepare 入口；导入合同不再要求 POSIX 包。缺包在锁/guard/prepare 真正执行前抛错，不允许无锁继续、不吞导入错误；prepare 在 import pwd 前没有文件变更。

模拟 Windows 的跳过集合逐名核验为 **3 + 2 + 7 + 2 + 5 = 19**，
与 FreeBSD 的集合完全一致；Darwin 的相同 127 名全部实际执行通过。
`exact-19-posix-skips.json` 保存每个完整测试名、路径、定义行和 skip 理由。
模拟额外屏蔽 fcntl/pwd、SIGKILL/SIGHUP/SIGQUIT/SIGUSR1/SIGUSR2、
fork/getpgid/getpgrp/getuid/geteuid/killpg/setsid；没有用仅改平台名字的结果代签 Windows。
两份模拟过程中跟踪到的真实 Popen 数均为零；回环 TCP 测试仍实际运行。

**Windows 诊断结论**

`scripts/test_windows_native_crash.py:594–608` 只包装原观察过程：
OSError 保存类型名、errno、winerror 后原样 re-raise；
`:610–649` 保留原发布、完整身份绑定、deadline 缩短、ACK 和 SIGINT 行为，
仅增固定阶段标识；`:655–666` 把观察状态附在原失败断言中。
没有改变 native skip、归属校验、句柄终态、管道排空、期限或错误断言，
原 native Windows 失败原因仍为 UNKNOWN。

独立注入 PermissionError(EACCES)/winerror 32 的控制用例确认：
异常仍被重新抛出，identity_observation 为 reading_publication，
ACK 未创建，controller 保留 owned_preparation_failed，
新增诊断没有带出异常私有文本。
这是 mock 诊断合同；69 项本机运行中的进程实验使用真实 Darwin POSIX 后端。
Windows Job/句柄/API 模型及这份本机结果均不是原生 Windows 验收。

**workflow 窄审结论**

`.github/workflows/ci.yml:5–6` 仅在 `on.push` 下增加原因注释和
`paths-ignore: ['docs/**']`；`:7` 的 pull_request 保持。
去掉这两行后与基线全文逐字节一致。Ruby Psych 安全解析成功，
结构核验确认 push 其他条件、事件集合、PR、所有非触发配置、concurrency、
三平台 matrix 和全部 steps 都不变。
macos-26、ubuntu-24.04、windows-2025 均保留，所有门禁步骤保留。
解析器使用 YAML 1.1，会将未加引号的 on 表示为布尔键 true；
本次对两份文件使用相同解析器，并有独立逐字节还原校验。
证据见 `workflow-narrow-check.json`、`workflow-parse.stdout.json`。
这是触发配置源码签署，没有在 GitHub 创建/取消 run 或验证运行时事件调度。

**实际命令、计数和等待回执**

主命令为
`python3 -B work/focus-navigation-20261116/review-source/run_review.py`，
实际 Python 为 `/opt/homebrew/opt/python@3.15/bin/python3.15`，版本 3.15.2，
实际宿主 Darwin。它顺序启动下列七条独立命令，均实际 bounded wait/reap；
每个完整 argv、PID、期限、退出码、时长和输出摘要保存在
`commands.json` 及同名 `*.command.json`，逐名结果在 `*.result.json`。

命令前缀为 `python3 -B work/focus-navigation-20261116/review-source/review_driver.py`。

| 后缀参数 | run | pass | skip | fail | error | exit / reaped | 外层耗时 / 期限 |
| --- | ---: | ---: | ---: | ---: | ---: | --- | --- |
| `--suite labs --label labs-darwin` | 127 | 127 | 0 | 0 | 0 | 0 / true | 5.849s / 120s |
| `--suite labs --label labs-simulated-windows --simulate-host Windows` | 127 | 108 | 19 | 0 | 0 | 0 / true | 0.503s / 60s |
| `--suite labs --label labs-simulated-freebsd --simulate-host FreeBSD` | 127 | 108 | 19 | 0 | 0 | 0 / true | 0.483s / 60s |
| `--suite archive --label archive-candidate`，历史 r2 | 27 | 27 | 0 | 0 | 0 | 0 / true | 1.545s / 45s |
| `--suite windows --label windows-diagnostic-module-darwin` | 69 | 68 | 1 | 0 | 0 | 0 / true | 6.189s / 120s |
| `--suite controls --label independent-controls`，历史 r2 控制 | 7 | 7 | 0 | 0 | 0 | 0 / true | 0.119s / 20s |
| `--suite red --label baseline-clock-red`，预期旧版红例 | 2 | 0 | 0 | 1 | 1 | 1 / true | 0.108s / 20s |

七条中六条候选/控制命令 exit 0；旧版红例 exit 1 为预期失败原件。
旧版时钟第二项实际 1.855 秒，显示两段预算续期；
第一项在 0.35 秒消失前已经 CleanupUnknown。它们说明预算缺陷，
不说明原 CI errno 或根因。当前修改归档文件后不得继续沿用这份历史绿例作最终 r3 证明。

驱动器跟踪到 246 个实际直接 Popen：lab 177、归档 15、诊断模块 54。
每个返回时均已有 returncode，waitpid 均报已 reap；
驱动器没有强制补杀任何漏掉的直接子进程，没有超时命令。
测试内部对真实后代、借用管道和终态使用原有有界清理及断言。
这份跟踪不是所有孙进程的独立出生身份库存。
Ruby YAML 解析另一个直接子进程实际 communicate(timeout=10)、exit 0 / reaped，
0.118 秒，见 workflow 回执；它没有运行 workflow。

**归档 HOLD 与最终签署条件**

已读 Ampere 调查原件并独立核对旧源码、两处旧堆栈；
旧 line166 是 post-reap OSError，原始 errno 未知。
因此不将一秒预算、历史 27/27 或纯时钟模型表述为已修复旧 macOS CI。
已记录 `notice-r2-archive-hold.md`：
post-reap EPERM 路径及测试 reap 后缓存 PGID fallback 由父修复，
等待 r3 冻结后只审这两个归档文件的授权增量。
原件保持，未重跑正在修改的归档文件。

父在当前会话转述 session 包专项 221.500s / exit 0 / reaped，
本 reviewer 没有执行 Cargo，也未读取并验证其逐项计数与完整回执，
所以仅记录为父方状态，不计入独立测试。
最终完整门禁尚未绑定；真实 Windows 的初始失败原因、真实 macOS CI 新回合、
Linux、三平台原生桌面、IME/辅助技术、反向 Tab、主题完整焦点矩阵和发行
均不由这份源码报告代签。

本报告批准范围只允许进入下一步归档增量审查与父最终门禁准备；
整个批次的最终源码批准仍为 HOLD_FOR_R3。
