**最终结论：有条件批准 r4 限定源码，父可立即启动完整门禁。P0=0、P1=0、P2=0、P3=0；无未解决源码阻塞。**

2026-11-16，非作者独立复核。此前八文件与最终 archive 两文件共同绑定 r4；批准状态为 `APPROVE_SOURCE_SCOPED_CONDITIONAL_FINAL_GATE_REAL_PLATFORM`。

基线 `4fd193227bb9e5e5e4b49ad6f1503f10741f7383`；最终 717 inputs SHA-256：
`04b232fb2095b490614d509d3545ea72afa65a998646300617df87f6af11180f`。
已有读取前后逐项核对均零漂移，差分逐字节匹配 candidate-r4.diff。r1→r2 唯一增量为 workflow；r2→r4 仅两个 archive Python 文件变化，其余715项相同，均属授权冻结转换。原件及完整审查保留在 [既有 REPORT.md](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/focus-navigation-20261116/review-source/REPORT.md)；本次只整理报告与 receipt，未新增调查或重跑。

**源码结论与精确位置**

六文件适用性批准：真实宿主能力测试精确 skip **19=3+2+7+2+5**，纯合同继续跨平台执行。

| 文件位置 | 结论 |
| --- | --- |
| [test_linux_file_interop.py:24](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_linux_file_interop.py:24) | 仅3项真实进程测试受限 |
| [test_linux_local_backend.py:23](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_linux_local_backend.py:23) | 仅2项真实进程测试受限 |
| [test_monitor_recovery_lab.py:28](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_monitor_recovery_lab.py:28) | 仅7项真实实验受限 |
| [test_ssh_path_lab.py:21](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_ssh_path_lab.py:21) | 仅2项真实进程测试受限，回环TCP继续 |
| [test_ssh_path_netem_lab.py:24](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_ssh_path_netem_lab.py:24) | 仅5项真实进程测试受限 |
| [fixture.py:130](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/monitor_recovery/fixture.py:130) | fcntl懒导入；pwd在166、238行懒导入，实际使用缺依赖仍显式失败 |

[Windows诊断:594](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_windows_native_crash.py:594)（594–608、610–649、655–666）仅补阶段、errno、winerror并原样抛错；身份、ACK、期限及终态断言未放宽。注入拒绝访问确认仍失败且无ACK。**真实Windows旧失败原因未知，不认定已修复。**

[archive生产:154](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/archive_validation.py:154)：154–167行在初始kill前建立唯一1秒绝对截止，先kill-owned-group再按剩余预算reap；初始kill/wait错误立即UNKNOWN。168–187行reap后仅signal0，仅post-reap EPERM在原截止内重试；必须ESRCH确认，持续EPERM/存在超时及其他错误保持UNKNOWN。99–106行诊断固定phase及数值errno；393–407行main仍65且无可采用输出。6秒工作期限包含前面cleanup，最后最多追加1秒cleanup；[Rust调用:20](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/archive_validation.rs:20)、123–159行仍受10秒总期限约束，不宣称硬实时保证。

[archive测试:248](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/archive_validation/test_archive_validation.py:248)：248–266行沿用生产1秒窗口、后代睡9秒、elapsed<2.5且必须实际status0；268–303行移除reap后缓存PGID再kill；419–498行覆盖短暂/持续EPERM及其他错误。两项历史P2在限定源码/回归范围关闭。旧macCI **line166是post-reap OSError，非line168截止耗尽；原errno未知**，不得推定根因。旧27/27、父status -9失败与后续green均保留。

[workflow:5](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/.github/workflows/ci.yml:5)：5–6行仅push增加注释及 `paths-ignore: ['docs/**']`；7行PR触发不变。安全YAML解析与10项结构核验通过，三平台job、concurrency及门禁步骤未变；实际GitHub事件执行待定。

**已有独立执行**

Darwin / Python3.15.2；实际入口命令如下，完整子进程argv、时限、日志摘要见receipt引用的原件：

```text
python3 -B /Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/focus-navigation-20261116/review-source/run_review.py
python3 -B /Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/focus-navigation-20261116/review-source/run_archive_r4.py
```

| 专项 | run/pass/skip | exit/reaped |
| --- | --- | --- |
| 五lab模块Darwin | 127/127/0 | 0/true |
| 模拟Windows | 127/108/19 | 0/true |
| 模拟FreeBSD | 127/108/19 | 0/true |
| Windows诊断模块，本机Darwin | 69/68/1 | 0/true |
| 最终r4 archive | 30/30/0 | 0/true |
| 最终r4独立controls | 7/7/0 | 0/true |

上述均无失败/错误。模拟不等于原生Windows；旧时钟红例1fail/1error及r2新EPERM红例1error为历史预期失败，另存原件。所有测试驱动有界等待并reap；累计跟踪261个直接Popen均已reap，不冒充全部孙进程独立库存。

父告知session专项221.500s/exit0/reaped、archive Rust 11/11（含30Python）及packaging exit0，单列父方结果。reviewer未运行Cargo或完整门禁。

**待定条件**：最终fullgate及真实Windows/macCI回执，其他真实平台/原生桌面验收与历史根因均不由本报告代签。后续工程字节须继续绑定r4；新增工程变更需增量复核。生产树保持只读；全部review写入仅在本目录，无源码/格式、提交push、生产清理、Cargo/target、容器或GUI操作。
