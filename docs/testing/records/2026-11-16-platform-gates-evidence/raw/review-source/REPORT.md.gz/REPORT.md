**最终结论：有条件批准 r4 十文件的限定源码范围，允许父启动最终完整门禁。开放 P0 = 0、P1 = 0、P2 = 0、P3 = 0。**

本报告日期为 2026-11-16，由本批新开的非作者 reviewer 独立审查和执行 Python
专项后形成。批准标识为 `APPROVE_SOURCE_SCOPED_CONDITIONAL_FINAL_GATE_REAL_PLATFORM`。
它覆盖先前八文件及最终两个 archive 文件；不签署尚未完成的完整门禁或真实平台验收。

| Severity | 最终开放数量 | 结论 |
| --- | ---: | --- |
| P0 | 0 | 未发现 |
| P1 | 0 | 未发现 |
| P2 | 0 | 两项历史归档 HOLD 已在 r4 的限定源码与回归范围关闭 |
| P3 | 0 | 本次十文件源码范围未发现；文档整体不属于本报告签署范围 |

**固定来源、增量关系与读写边界**

checkout 为 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`。
实际 HEAD 为指定基线 `4fd193227bb9e5e5e4b49ad6f1503f10741f7383`。
已读取 AGENTS、RTK、HANDOFF 当前批次和持续约束。
全部写入仅在本 `review-source/`；测试临时目录也固定在其 `scratch/` 下。
没有修改生产源码或格式，没有提交、push、清理生产资源、执行 Cargo、操作 target、
容器或 GUI。实际测试子进程按有界等待管理并确认 reap。

最终 r4 冻结为 **717 项**，集合 SHA-256：
`04b232fb2095b490614d509d3545ea72afa65a998646300617df87f6af11180f`。
读取前及专项结束后的逐项摘要均相符，零 mismatch；集合摘要重新计算相符。
当前十文件差分与 `candidate-r4.diff` 逐字节相同，diff SHA-256 为
`6236aa970e27a00abff69d7ab07b7e03973ad9d6fe1ca99651d545b2921b9327`。
见 `source-before-r4.json`、`source-after-r4.json`、
`engineering-inputs-r4.original.json`、`candidate-r4.original.diff`，
十份最终原件保存在 `candidate-r4-originals/`。

来源转换是明确授权的增量，未记作漂移失败：

| 冻结 | 集合摘要 | 相对上一审查冻结 |
| --- | --- | --- |
| r1 | `6bf6b1abb5cfaaeada90b5eddb191c5d24ba963acb3e2c9eefa63b145b50afb5` | 原九文件；717 项逐项相符 |
| r2 | `d826de85d8c62ae38fc8475824d6dff4d55f8f120a621588b45a373f8d19b505` | 唯一增量 `.github/workflows/ci.yml`，其余 716 项相同 |
| r4 | `04b232fb2095b490614d509d3545ea72afa65a998646300617df87f6af11180f` | 相对 r2 仅两个 archive Python 文件变化，其余 715 项相同 |

因此此前八文件的审查与执行结果可以绑定最终 r4；没有重复执行未变范围。
旧 r1/r2 源码、清单、报告、红绿执行及 HOLD notice 全部保留，没有回填或改写。
详细八文件审查原件见 `REPORT-r2-scoped.md`；
最终本报告以 r4 承接其限定结论。

**六文件 POSIX 适用性：批准**

精确 skip 数为 **3 + 2 + 7 + 2 + 5 = 19**，仅涉及需要 Darwin/Linux
内核出生身份、POSIX 信号/进程组或真实宿主工具的测试。
纯所有权、解析、CLI、预算、失败证据、模拟清理和回环 TCP 合同继续运行。

| 文件及精确位置 | 独立审查结论 |
| --- | --- |
| `scripts/test_linux_file_interop.py:24–27,251–305` | 仅真实 ProcessTests 三项受宿主条件约束；其他 14 项继续运行 |
| `scripts/test_linux_local_backend.py:23–26,363–395,429–453` | 两项真实进程合同受限；mock 的 SIGKILL 是数据，仍断言精确 PID/identity 和失败状态；其他 37 项继续运行 |
| `scripts/test_monitor_recovery_lab.py:28–31,126–140,154–168,234–255,309–347,389–458` | 七项真实实验受限；懒导入与执行失败合同继续运行；支持宿主 CLI 校验与不支持宿主无副作用拒绝分开覆盖 |
| `scripts/test_ssh_path_lab.py:21–24,212–245,257–265,267–323` | 两项真实子进程受限；mock 身份/信号合同保留，五项真实 TCP 转发测试没有被跳过 |
| `scripts/test_ssh_path_netem_lab.py:24–27,295–309,408–457,475–489` | 五项真实子进程受限；字节解析、证据、CLI 和回环 TCP 合同继续运行 |
| `scripts/monitor_recovery/fixture.py:127–136,165–175,237–280` | fcntl 只在进入锁时导入，pwd 只在 guard/prepare 时导入；缺依赖在使用前显式失败，不无锁继续或吞掉错误 |

Darwin 的 127 名测试全部执行通过。模拟 Windows/FreeBSD 各保持相同完整库存，
108 pass / 19 skip，跳过集合完全一致，逐名路径和定义行见
`exact-19-posix-skips.json`。
模拟额外屏蔽 fcntl/pwd、多项 POSIX 信号和 fork/getpgid/getpgrp/getuid/geteuid/
killpg/setsid；两份模拟过程中真实 Popen 数均为零。
这证明导入和适用性合同，没有运行原生 Windows 或 FreeBSD。

**Windows 夹具诊断：仅批准诊断改动**

`scripts/test_windows_native_crash.py:594–608` 对原观察过程包装 OSError，
仅记录异常类别、errno、winerror，随后原样 re-raise；
`:610–649` 只增加阶段标记，发布、身份绑定、期限缩短、ACK、SIGINT 行为保持；
`:655–666` 将阶段诊断加入原失败断言。
没有新增 skip，没有放宽原始句柄、Job 归属、终态、管道或退出码断言。

独立注入 PermissionError(EACCES)/winerror 32 的控制确认：
异常不被吞掉、ACK 未产生、阶段为 reading_publication、
owned_preparation_failed 保持，新增诊断不带异常私有文本。
69 项本机专项为 68 pass / 1 skip；真实进程部分使用 Darwin POSIX 后端。
原 Windows 失败的原因仍为 **UNKNOWN**，本改动没有被标成已修复。

**archive r4：批准；历史两项 HOLD 在限定范围关闭**

生产源码 `crates/keelshell-session/src/archive_validation.py` 的不变量：

- `:154–167` 在清理入口只建立一个一秒绝对截止。先对未 reap 的 leader
  所有进程组发一次 SIGKILL，随后 wait 只取剩余预算。初始 kill 的 OSError
  或 wait 超时/OSError 立即抛 CleanupUnknown，不进入观察重试。
- `:168–187` 在 reap 之后只发 signal 0。只有 ProcessLookupError/ESRCH 才确认
  absent；仅 errno.EPERM 被视作未确认并在原截止内重试。成功的 signal 0
  表示组仍存在，不是清理成功；持续 EPERM/存在到期仍 UNKNOWN。
  EACCES/EIO/EINVAL 等其他观察错误立即 UNKNOWN，不被重试或当成 absent。
- `:99–106,162–186` 的失败诊断只由固定阶段及 OS 数值 errno/None 构造，
  不加入子进程输出、路径或原始错误文字；`:393–407` 的 main 仍返回 65，
  未确认清理时没有可采用 JSON。四种新阶段均由独立控制核对零 stdout/stderr。
- `:29–34,198–204,358–383` 保持单命令一秒、共享工作六秒。
  collect 只创建一次工作截止；前面清理同步消耗后续工作余量。
  正常计时模型中只有最后一个已启动调用的清理可能再使用最多一秒，
  不会为十个命令各新增一个独立尾部预算。
  Rust `crates/keelshell-session/src/archive_validation.rs:20,123–159`
  仍共享十秒 SSH 总期限并拒绝迟到结果。
  helper 启动、进程创建、系统调用和调度不是硬实时保证，6+1 不构成全系统十秒实测保证。

测试文件 `crates/keelshell-session/src/archive_validation/test_archive_validation.py`：

- `:419–450` 新增短暂 EPERM → ESRCH 的同截止回归；`:452–481` 覆盖持续 EPERM
  不成功且不续期；`:483–498` 覆盖其他 OSError 立即 UNKNOWN。
  独立将第一项放到保存的 r2 源码上执行，确实 **1 run / 1 error**；
  最终 r4 专项包含相同用例并通过，覆盖旧报告尚未覆盖的 post-reap 错误分支。
- `:268–303` 移除了旧 finally 中 reap 后使用缓存 PGID 再 SIGKILL 的 P2。
  保留 supervisor/group 绑定、唯一 kill 发生在 leader.returncode 尚为 None、
  descendant absent 和 leader 已 reap 的断言；返回后仅作非破坏性观察。
- `:248–266` 的继承管道回归改用既有生产一秒工作窗口，后代仍睡九秒，
  elapsed < 2.5 覆盖一秒 work + 一秒 cleanup 及少量调度余量。
  断言仍精确要求 `("timed_out", 0, b"")`，不会接受 status -9。
  独立 AST 控制确认生产 run_owned/collect/main、supervisor 与所有工作/输出预算
  均与 r2 保持，fixture 调整没有扩大生产参数。

已独立核对旧 CI 两段堆栈：基线 line166 是 post-reap OSError 分支，
line168 才是期限耗尽。**旧 errno 未记录，真实原因没有被确认**。
r4 补上 EPERM 的合理候选路径及 fail-closed 回归，
不等于证明旧 CI 一定因 EPERM、zombie 或调度回收造成。
历史 P2 关闭只指限定源码、测试和缺失分支覆盖，真实 CI 仍待验证。
调查原件及修正依据见 `macos-investigation-r1.original.md`、
`macos-cause-correction.json`、`historical-macos-traces.txt`。

父的 `archive-cleanup-green-r2` 原失败也已原样复制并核对日志摘要：
30 run / 1 failure，实际 status -9 与要求 0 不同，exit 1 / reaped / 1.855s。
后续 `archive-cleanup-green-r3` 是另一份新执行：
30/30，exit 0 / reaped / 2.667s。两份分别保留，
见 `parent-archive-history-binding.json`；父方成功没有计作独立执行。

**workflow 两行增量：批准**

`.github/workflows/ci.yml:5–6` 仅在 push 下增加原因注释及
`paths-ignore: ['docs/**']`；`:7` 的 pull_request 保持。
删除这两行后与基线全文逐字节相同。
Ruby Psych 安全解析及十项结构核验通过：
push 其余条件、事件集合、PR、全部非触发配置、concurrency、三平台 matrix、
所有门禁步骤均保持。`macos-26 / ubuntu-24.04 / windows-2025` 未删减。
路径过滤仅属于 push，PR 触发继续按原定义。
证据见 `workflow-narrow-check.json` 和 `workflow-parse.stdout.json`。
没有实际创建/取消 GitHub run，也没有将配置审查当作 CI 运行成功。

**独立执行的实际命令与计数**

实际宿主 Darwin，Python 3.15.2。
实际解释器路径为 `/opt/homebrew/opt/python@3.15/bin/python3.15`。
cwd 始终是本 checkout。主命令：

```text
python3 -B work/focus-navigation-20261116/review-source/run_review.py
python3 -B work/focus-navigation-20261116/review-source/run_archive_r4.py
```

前者执行原范围及历史 r2 回归，后者只执行授权的最终 archive 增量。
它们的实际完整子进程 argv、PID、期限、退出码、时长及日志摘要存于
`commands.json`、`archive-r4-commands.json`、各 `*.command.json`，
逐名结果和库存存于各 `*.result.json`、`*.inventory.json`。

| 专项/版本 | 实际 run | pass | skip | fail | error | exit / reap | 外层耗时 / 上限 |
| --- | ---: | ---: | ---: | ---: | ---: | --- | --- |
| 五模块 Darwin，r4 不变范围 | 127 | 127 | 0 | 0 | 0 | 0 / true | 5.849s / 120s |
| 同库存模拟 Windows，r4 不变范围 | 127 | 108 | 19 | 0 | 0 | 0 / true | 0.503s / 60s |
| 同库存模拟 FreeBSD，r4 不变范围 | 127 | 108 | 19 | 0 | 0 | 0 / true | 0.483s / 60s |
| Windows 诊断模块 Darwin，r4 不变范围 | 69 | 68 | 1 | 0 | 0 | 0 / true | 6.189s / 120s |
| 最终 r4 archive suite | 30 | 30 | 0 | 0 | 0 | 0 / true | 2.473s / 45s |
| 最终 r4 独立 archive 控制 | 7 | 7 | 0 | 0 | 0 | 0 / true | 0.098s / 20s |
| 保存的 r2 + EPERM 新红例，预期错误 | 1 | 0 | 0 | 0 | 1 | 1 / true | 0.087s / 20s |
| 历史 r2 archive suite | 27 | 27 | 0 | 0 | 0 | 0 / true | 1.545s / 45s |
| 历史 r2 独立控制，包括 Windows 注入 | 7 | 7 | 0 | 0 | 0 | 0 / true | 0.119s / 20s |
| 基线旧时钟红例，预期失败 | 2 | 0 | 0 | 1 | 1 | 1 / true | 0.108s / 20s |

模拟/历史/新候选是不同上下文，没有加总成一次全仓或原生平台验收。
历史 r2 控制中的 EPERM 立即失败预期只描述当时版本，未沿用到 r4。
最终 r4 七项独立控制覆盖 kill/wait 不重试、kill/wait 时间共同扣减、
EPERM/存在混合直到 ESRCH、EPERM 后 EIO、main 无输出及生产预算/调用链不变。

十个测试驱动外层均实际 wait/reap，无超时。
驱动内部累计跟踪 261 个真实直接 Popen：lab 177、诊断 54、历史 archive 15、
最终 archive 15。全部已有退出码，waitpid 均确认已 reap，没有靠驱动补杀漏掉的直接子进程。
真实后代、管道及 group 终态由专项内的原有有界等待和断言覆盖；
该跟踪不冒充全部孙进程的独立出生身份库存。
Ruby YAML 解析为另一个有界 communicate 的子进程，
timeout 10 秒，实际 exit 0 / reaped / 0.118 秒。

**父方结果与未验边界**

父在当前会话告知早期 session 包专项 221.500s / exit 0 / reaped，
随后最终 archive Rust 专项 11/11（内含 30 项 Python）与 packaging 专项 exit 0。
这些是父方执行状态；本 reviewer 没有执行 Cargo，
没有把它们计入独立命令数或代替最终完整门禁。
早期 session 专项也不证明 r4 include_str helper 已在最终 Rust 产物中重新编译；
最终完整门禁需绑定本 r4 冻结及实际产物。

本批准的条件是后续工程字节继续保持本 r4 冻结，
父完成并绑定最终完整门禁与相应平台回执；新增工程变更需要增量审查。
原 Windows 原生故障原因仍未知；新真实 Windows/macOS/Linux CI 和桌面验收
不得由 Darwin、本机 Python 或平台模拟代签。
反向 Tab、完整焦点/主题/尺寸矩阵、IME/辅助技术、安装与发行保持各自原有开放边界。
本 reviewer 未执行容器、GUI、Rust 重编译或完整工程门禁。

**交付建议：本 r4 十文件源码可以进入父的最终完整门禁；不以本报告宣称 CI、
原生桌面或历史故障根因已经通过验收。**
