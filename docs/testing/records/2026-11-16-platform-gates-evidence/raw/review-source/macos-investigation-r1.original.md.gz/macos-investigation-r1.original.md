# macOS archive_validation 只读调查

本调查支持“清理使用单一 1 秒绝对截止”的预算设计，但**不能将当前仅调整预算的候选签署为已修复这份 CI 日志中的失败**。日志绑定基线 `4fd193227bb9e5e5e4b49ad6f1503f10741f7383`，两处异常均来自基线第 166 行的 post-reap `except OSError`，不是第 168 行的期限耗尽。增加预算不会改变该立即抛出的分支。具体 errno 没有保留，不能确定就是 EPERM，也不能确定曾等待满 0.2 秒。

用户最后告知父已获得模型红例“1 fail / 1 error”和修后“27/27”。本调查没有运行这些测试，也没有读取这次新执行回执；这项转述不作为独立执行证据。按要求停止扩展调查，不重复 Laplace 的最终九文件复核。

**身份、范围与实际动作**

- checkout：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`；开始时 HEAD 实际为上述基线，两份目标 Python 文件的基线差分为空。
- 已先读 AGENTS、RTK 和 HANDOFF 当前交付片。父在调查期间修改了候选文件；下文明确区分基线行号与所读候选行号，不能拿移动后的候选第 166 行解释旧 CI。
- 只做文件读取、Git 只读查询和 Apple 公开源码 GET。测试执行为 **0**；未执行 Cargo、格式化、进程实验、容器操作、提交或推送。唯一写入是本目录的 REPORT.md、receipt.json。
- Windows 原生夹具诊断、POSIX 测试适用性、最终九文件批准和后续真实 CI 不属于本调查结论。

**已确认的失败证据**

| 证据 | 实际读到的内容 |
| --- | --- |
| `work/focus-navigation-20261116/ci-jobs-r3.json`，macOS job 对象 | Quality run `43789081172`、attempt `1`、job `133043263469`，head_sha 为基线，`native (macos-26)`，completed / failure。该文件是父此前捕获的回读，本调查未重新请求 GitHub CI。 |
| `macos-job-r1.sanitized.log:11–20,106–112` | runner 声明 macOS `26.7.2 / 25G332`、`macos-26-arm64`，检出基线。 |
| 同日志 `4281–4301` | `test_child_that_never_reads_fixed_stdin_cannot_block_output_or_timeout`：`run_owned:310 → terminate_and_wait:166 → CleanupUnknown`。 |
| 同日志 `4304–4326` | `test_combined_per_command_stdout_stderr_flood_is_capped_and_reaped`：同样落在基线第 166 行。 |
| 同日志 `4329–4332,4501–4514` | Python 25 run / 2 errors；Rust 包装测试失败；该次 session 库 287 passed / 1 failed / 4 ignored，Cargo exit 101，门禁步骤 exit 1。不是整套 Python 工程测试未开始 Rust。 |
| 历史 `docs/testing/records/2026-11-16-file-browser-keyboard-evidence/raw/full-gate-r2.log.gz`，解压行 `3875–3878` | 旧本地 helper 25 tests / OK，Rust 包装测试 ok。其 `full-gate-r2.json.gz` 记录 exit_code 0 / reaped / 724.429846375002s。这只是旧回执，不是本次重新执行或新候选验收。 |

基线 `archive_validation.py:144–169` 的顺序是：一次 `killpg(SIGKILL)` → `child.wait(timeout=0.2)` → 另起 0.2 秒观察期限 → `killpg(pgid, 0)`。第 164 行仅在 ProcessLookupError 时返回；第 166 行对其他 OSError 立即 UNKNOWN；第 168 行才是观察到组仍存在并耗尽期限。两处堆栈证明 wait 已正常返回并进入非破坏性观察，未证明之后是哪种 errno。

**生命周期判断与推断边界**

基线 `archive_validation.py:62–91,198–208,243–255,301–315` 有明确的归属设计：supervisor 是新 session/进程组 leader；它 wait 自己的直接工具，通过工具不继承的 status FD 报告退出码，然后保持存活。父在读取工具结果和管道时不 poll/reap leader，最后在 leader 未 reap 时杀整个组。这个顺序需要保留。`main:375–389` 在清理不明时不输出可采用报告，亦应保留。

超时或输出超限发生时，直接工具可能仍在运行。父一次 SIGKILL 同时覆盖 supervisor 和工具，不能保证 supervisor 先 wait 工具。父随后 wait 的只是 supervisor，不能由此推出工具或全部后代已经 reap。正常工具已经由 supervisor wait 的路径，与这类提前收尾路径不同。是否出现残留 zombie、由谁在什么时刻回收，会受实际执行顺序影响；此前本机通过不能排除另一次调度下失败。

本调查只读取得 Apple XNU 提交 `f6217f891ac0bb64f3d375211650a4c1ff8ca1ea` 的两个源码文件，下载摘要见 receipt：

- `bsd/kern/kern_sig.c:1709–1718` 的组迭代过滤 SZOMB，未找到可计数成员的 POSIX 路径返回 EPERM；因此“组尚有 zombie → signal 0 返回 EPERM”有公开源码依据。
- `bsd/kern/kern_exit.c:2472–2473,2827–2828` 展示退出时子进程改挂 initproc，以及 reap 时离开进程组的操作。这支持退出与组彻底消失不是同一阶段的解释。

以上是**机制依据**，没有核对 CI 实际内核二进制与该 XNU 提交的对应关系。日志没有 errno、进程状态快照或回收时间线，因此“这两次一定是孤儿 zombie / EPERM / launchd 回收慢 / 等待超过 0.2 秒”均不能写成已证实根因。

**对单一 1 秒绝对截止的独立评价**

读到的候选生产文件 SHA-256 为 `a5825078ae7c956f94e515dc537d80e2a275fed01769edc1ca72cc6acb0d2e86`。其 `archive_validation.py:147–173` 在开始清理时固定截止，wait 取剩余时间，观察和每次短轮询也只取同一剩余时间；一次 kill-before-reap、post-reap 仅 signal 0 的顺序保持。**作为预算设计合理，可推进。**

父对 6 秒预算的计算成立：基线 `collect:340–365` 只建立一次总截止；每个 `run_owned` 进入前检查同一截止，工作循环以该截止和单命令截止较早者为准，清理同步完成后才进入下一次调用。前面 cleanup 的耗时已经消耗后续工作余量。正常计时模型中只有最后一个已启动调用的清理可能越过 6 秒，最多再用 1 秒；不是十个调用各额外获得一秒。

Rust `archive_validation.rs:20,88–91,123` 的 10 秒还覆盖 SSH open、exec acknowledgement、输出等阶段。6+1 留有名义 3 秒余量，**不等于已经证明全部操作一定小于 10 秒**：helper 启动/导入、路径 stat、进程创建、调度与系统调用耗时并不是硬实时保证。1 秒可以是明确的清理政策预算，不是测得的 Darwin 回收延迟上界；本调查不主张继续加任意 sleep 或以预算替代确认。

当前候选 `:168–169` 仍对所有非 ESRCH 的观察 OSError 立即 UNKNOWN。这保持了保守性，但也意味着仅换成共享 1 秒，不能覆盖旧日志已确认的错误分支。新模型测试候选 `test_archive_validation.py:367–415` 分别覆盖“0.35 秒后 signal 0 从成功变成 ESRCH”和“reap 花 0.85 秒后观察不得续期”，都是有意义的边界测试；它们没有产生观察 OSError。它们是替换 monotonic/sleep 的时钟模型，不是 Darwin 进程或真实调度回归。

**最小合理补充与有意义回归**

最小候选是保留共享绝对截止及一次组 SIGKILL，把 **post-reap 观察中的 EPERM** 当作“尚未确认”，允许在同一剩余期限内继续 signal 0 观察。只有 ESRCH 能确认 absent；持续存在或持续 EPERM 到期仍抛 CleanupUnknown。初次破坏性 kill 的权限错误、wait 失败和其他未知观察错误仍 fail closed。这样没有把 EPERM 当作成功，也没有在 leader reap 后再次发送破坏性信号。是否需要这一补充的现场证据仍是实际 errno；公开源码加现有堆栈使它成为应覆盖的具体候选。

建议保留父的两项新时钟模型，再补以下三类，不要求本调查执行：

1. **短暂 EPERM → ESRCH**：reap 后第一次或连续若干次 signal 0 抛 `PermissionError(errno.EPERM)`，随后在同一截止前 ESRCH。断言此前不能报告成功，ESRCH 后才能完成，破坏性 kill 只有一次且发生在 wait 前。旧实现及仅预算候选均会先红，这才覆盖本日志所处的 OSError 分支。
2. **持续 EPERM / 持续存在**：到共同截止仍为 UNKNOWN；reap 已消耗大部分预算时不得再获得一秒。非 EPERM 的观察错误、初次 kill 权限拒绝和 wait 超时继续 UNKNOWN；不因重试而输出 JSON。
3. **重用 PGID 的观察模型**：leader reap 后，所有后续调用只能 signal 0；即使观察到组长期存在，也不能再 kill、不能将其认定为自己仍拥有的组。现有无报告测试 `test_archive_validation.py:179–190` 的语义继续保持。

随后由父或 CI 在真实 macOS 运行原有超时、flood、关闭 stdio 后代和完整 helper 测试。模型红绿与真实平台收尾结论分别记录；本调查未执行或签署后者。

**supervisor 两阶段请求方案**

父提出的“向 leader PID 发 SIGTERM，handler 只置 flag；supervisor 用短切片 wait 等工具，收到请求后 kill 并实际 wait 直接工具，再结束 status 管道；父有界读取后再 killpg / wait leader / 确认 absent”在方向上合理。它使常见直接工具有原父负责 reap，减少依赖系统回收的机会；不能保证已孤立的 grandchildren、逃组进程或损坏 supervisor。

这比预算修补多出协议和关闭状态，当前无需强行引入。若后续采用，至少需要：

- SIGTERM 只发给尚未 reap 的 leader PID；处理器先安装，只置 flag，并覆盖 Popen 创建前后收到停止请求的竞态。supervisor watchdog 仍有明确边界。
- 父当前 finally 在基线 `:303–305` 先关闭 control FD，握手必须先于此关闭完成。EOF 本身也可能来自 supervisor 异常退出，不能独立充当“工具已 reap”的回执，必须结合完整可信状态帧。
- 正常工具完成后仍可按现有逻辑写状态并 EOF。若改成“只有收到请求才 EOF”，必须调整主循环 `:217–224` 对所有 FD EOF 的依赖，否则正常完成会等待到工作超时。
- 握手、直接工具 wait、最终组清理都消耗同一清理截止，不能分阶段续期。回执缺失不能签成功；失败路径仍尝试有界的组收尾并保留 UNKNOWN。最终组 SIGKILL 仍须发生在 leader reap 前。

**附带的既有夹具风险**

基线及所读候选 `test_archive_validation.py:300–305` 的成功后代测试，在 `run_python` 已完成 leader reap 后，finally 可能用缓存的 group 数字执行真实 `killpg(SIGKILL)`。`getpgid(descendant) == group` 是数值检查，不能重新取得已释放的 leader 归属，检查与信号间也有竞态。未观察到误杀；新回归不应复制这段 fallback。若需要修夹具，应在归属仍保留时安排 teardown，不能为测试清理放宽产品的 PGID 规则。这是既有测试风险，不是本次两个 CI 错误已证实的根因。

**交付判断**

调查范围内未发现新的 P0/P1 生产安全绕过。一个 P2 阻止“预算候选已修复本次 CI”的签署：已记录的 post-reap OSError 分支未被覆盖；另记录一个 P2 既有夹具归属风险及一个 P3 证据表述问题（候选 ADR `:38` 已把原因写成“观察上限过短”，目前证据不足）。支持共享绝对预算设计，不批准将现有差分或转述的 27/27 等同于本次 macOS 原因已确认或真实 CI 已修复。

全部结论来自上述实际读取；报告不是全仓批准，不替代 Laplace 复核，也不更改 UNKNOWN、清理确认或 leader 未 reap 时的 PGID 归属合同。
