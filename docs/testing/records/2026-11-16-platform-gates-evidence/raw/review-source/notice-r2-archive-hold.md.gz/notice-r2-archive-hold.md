归档范围保持 HOLD，等待父发布 r3 冻结；这不是新的候选或新增范围。

已按 2026-11-16 用户纠正，独立核对基线
`4fd193227bb9e5e5e4b49ad6f1503f10741f7383` 的源码行和历史 macOS 堆栈：
`archive_validation.py:166` 为 post-reap `except OSError` 下的
`raise CleanupUnknown() from None`；`:168` 才是观察期限耗尽。
原始 errno 未记录，不能认定为 EPERM、孤儿 zombie 或已经等待满 0.2 秒。
原始调查已无修改复制为 `macos-investigation-r1.original.md`，
来源摘要及基线行存于 `macos-cause-correction.json`，
两段堆栈存于 `historical-macos-traces.txt`。

历史 r2 的单一一秒预算设计及 27/27 专项不覆盖 post-reap 短暂
EPERM → ESRCH 的分支，也不能证明旧 macOS CI 故障已修复。
父已告知正在补这项共享截止下的非破坏性 signal 0 回归，
持续 EPERM、其他 OSError、初始 kill/wait 错误继续 UNKNOWN。
本 reviewer 不再执行 r2 归档测试，等待固定 r3 后审增量。

另一项已读源码确认的 P2 是既有测试
`crates/keelshell-session/src/archive_validation/test_archive_validation.py:300–305`
在 leader reap 后的 finally 中用缓存 PGID 再发 SIGKILL；数值
`getpgid(descendant) == group` 不重新建立归属，并有检查到发信号的竞态。
未观察到误杀。父已明确将移除该 fallback；待 r3 验证关闭。

六文件适用性、Windows 诊断及 workflow 的八文件范围可先限定签署，
不将这两个归档待处理项隐去，也不把 r1 → r2 唯一 workflow 增量当作来源漂移失败。

本会话可用工具中没有暴露 `send_input`；已通过当前用户会话进度消息说明此 HOLD，
没有借用其他聊天或消息服务向未知对象发送消息。
