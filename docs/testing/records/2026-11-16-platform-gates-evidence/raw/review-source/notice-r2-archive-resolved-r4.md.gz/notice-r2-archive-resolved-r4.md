r2 归档 HOLD 已由最终 r4 的限定源码审查关闭，旧 notice 与原件保持不变。

- 最终冻结 717 项，集合
  `04b232fb2095b490614d509d3545ea72afa65a998646300617df87f6af11180f`，
  审查前后均零 mismatch；r2 → r4 仅两个 archive Python 文件变化。
- 仅 post-reap EPERM 的 signal 0 在同一绝对一秒内重试，ESRCH 才确认；
  初始 kill/wait、其他查询错误立即 UNKNOWN，持续 EPERM/存在到期 UNKNOWN。
  最终独立 30/30、独立控制 7/7；保存的 r2 同一新 EPERM 用例 1 run / 1 error。
- 测试 reap 后使用缓存 PGID 再 SIGKILL 的 finally 已移除，
  原始未 reap 时的唯一 kill、归属和终态断言保持。
- 原 macOS CI line166 的 errno 仍未知；此关闭不表示已经证实或修复旧 CI 的真实根因。

最终开放 P0/P1/P2/P3 均为 0，有条件批准十文件源码并允许父进入完整门禁。
完整门禁、真实平台和历史故障结论的边界以最终 `REPORT.md` 为准。
