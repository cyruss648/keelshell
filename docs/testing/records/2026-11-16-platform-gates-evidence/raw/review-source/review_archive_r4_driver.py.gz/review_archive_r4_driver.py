"""Read-only candidate review driver; all artifacts and scratch data stay here."""
import argparse
import contextlib
import importlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import tempfile
import time
import unittest
from unittest import mock

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
LAB_MODULES = (
    "test_linux_file_interop",
    "test_linux_local_backend",
    "test_monitor_recovery_lab",
    "test_ssh_path_lab",
    "test_ssh_path_netem_lab",
)


def flatten(suite):
    for item in suite:
        if isinstance(item, unittest.TestSuite):
            yield from flatten(item)
        else:
            yield item


class RecordedResult(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.events = []

    def addSuccess(self, test):
        self.events.append({"id": test.id(), "status": "passed"})
        super().addSuccess(test)

    def addSkip(self, test, reason):
        self.events.append({"id": test.id(), "status": "skipped", "reason": reason})
        super().addSkip(test, reason)

    def addFailure(self, test, error):
        self.events.append({"id": test.id(), "status": "failed"})
        super().addFailure(test, error)

    def addError(self, test, error):
        self.events.append({"id": test.id(), "status": "error"})
        super().addError(test, error)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--suite", choices=("labs", "archive", "windows", "controls", "red"), required=True)
    parser.add_argument("--label", required=True)
    parser.add_argument("--simulate-host")
    args = parser.parse_args()
    actual_host = platform.system()
    scratch = HERE / "scratch" / args.label
    scratch.mkdir(parents=True, exist_ok=False)
    tempfile.tempdir = str(scratch)
    os.environ.update(TMPDIR=str(scratch), TMP=str(scratch), TEMP=str(scratch),
                      PYTHONDONTWRITEBYTECODE="1")
    os.environ.pop("KEEL_CONTROL_EVIDENCE_DIR", None)
    sys.path[:0] = [str(ROOT / "scripts"), str(HERE)]
    started = time.monotonic()
    real_popen = subprocess.Popen
    children = []

    def observed_popen(*values, **options):
        child = real_popen(*values, **options)
        children.append(child)
        return child

    with contextlib.ExitStack() as stack:
        stack.enter_context(mock.patch.object(subprocess, "Popen", observed_popen))
        if args.simulate_host:
            stack.enter_context(mock.patch.object(platform, "system", return_value=args.simulate_host))
            stack.enter_context(mock.patch.dict(sys.modules, {"fcntl": None, "pwd": None}))
            import signal
            for module, names in (
                (signal, ("SIGKILL", "SIGHUP", "SIGQUIT", "SIGUSR1", "SIGUSR2")),
                (os, ("fork", "getpgid", "getpgrp", "getuid", "geteuid", "killpg", "setsid")),
            ):
                for name in names:
                    if hasattr(module, name):
                        stack.enter_context(mock.patch.object(module, name))
                        delattr(module, name)
        loader = unittest.TestLoader()
        if args.suite == "labs":
            suite = loader.loadTestsFromNames(LAB_MODULES)
        elif args.suite == "windows":
            suite = loader.loadTestsFromName("test_windows_native_crash")
        elif args.suite == "archive":
            directory = ROOT / "crates/keelshell-session/src/archive_validation"
            suite = loader.discover(str(directory), pattern="test_archive_validation.py")
        else:
            module = importlib.import_module("test_archive_review_r4")
            if args.suite == "red":
                module.use_baseline()
                suite = loader.loadTestsFromNames([
                    "test_archive_review_r4.candidate_tests.OwnedProcessTests."
                    "test_post_reap_permission_error_stays_pending_until_confirmed_absence",
                ])
            else:
                suite = loader.loadTestsFromModule(module)
        inventory = [test.id() for test in flatten(suite)]
        (HERE / f"{args.label}.inventory.json").write_text(json.dumps(inventory, indent=2) + "\n")
        runner = unittest.TextTestRunner(verbosity=2, resultclass=RecordedResult)
        result = runner.run(suite)

    child_rows = []
    leaked = []
    for child in children:
        row = {"pid": child.pid, "returncode": child.returncode}
        if child.returncode is None:
            # Only direct children created and retained by this interpreter.
            # They are unreaped here, so their PIDs cannot refer to a new child.
            leaked.append(child.pid)
            child.kill()
            child.wait(timeout=2)
            row["forced_by_review_driver"] = True
            row["returncode"] = child.returncode
        try:
            waited = os.waitpid(child.pid, os.WNOHANG)
        except ChildProcessError:
            row["already_reaped"] = True
        else:
            row["already_reaped"] = False
            row["unexpected_waitpid"] = list(waited)
            leaked.append(child.pid)
        child_rows.append(row)
    report = {
        "suite": args.suite, "actual_host": actual_host, "simulated_host": args.simulate_host,
        "python": sys.version, "inventory_count": len(inventory),
        "tests_run": result.testsRun, "passed": sum(e["status"] == "passed" for e in result.events),
        "skipped": len(result.skipped), "failures": len(result.failures), "errors": len(result.errors),
        "events": result.events, "direct_children": child_rows, "leaked_direct_children": leaked,
        "duration_seconds": time.monotonic() - started,
    }
    (HERE / f"{args.label}.result.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report.items()
                      if k not in ("events", "direct_children", "python")}, sort_keys=True))
    return 0 if result.wasSuccessful() and not leaked else 1


if __name__ == "__main__":
    raise SystemExit(main())
