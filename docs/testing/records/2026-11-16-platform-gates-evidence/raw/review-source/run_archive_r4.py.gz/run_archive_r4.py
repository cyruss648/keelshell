"""Bounded, wait/reap supervised Python-only review commands."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
COMMANDS = (
    ("archive-r4-independent", "archive", None, 45),
    ("archive-r4-controls", "controls", None, 20),
    ("archive-r2-eperm-red", "red", None, 20),
)


def main():
    records = []
    for label, suite, host, budget in COMMANDS:
        command = [sys.executable, "-B", str(HERE / "review_archive_r4_driver.py"),
                   "--suite", suite, "--label", label]
        if host:
            command += ["--simulate-host", host]
        start = time.monotonic()
        row = {"label": label, "command": command, "cwd": str(ROOT), "timeout_seconds": budget}
        with (HERE / f"{label}.stdout.log").open("xb") as stdout, \
                (HERE / f"{label}.stderr.log").open("xb") as stderr:
            child = subprocess.Popen(command, cwd=ROOT, stdin=subprocess.DEVNULL,
                                     stdout=stdout, stderr=stderr,
                                     env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
                                     start_new_session=True)
            row["pid"] = child.pid
            try:
                child.wait(timeout=budget)
                row["timed_out"] = False
            except subprocess.TimeoutExpired:
                row["timed_out"] = True
                # The direct leader is still an unreaped owned child.
                os.killpg(child.pid, signal.SIGKILL)
                child.wait(timeout=5)
            row.update(returncode=child.returncode, reaped=child.returncode is not None,
                       elapsed_seconds=time.monotonic() - start)
        for suffix in ("stdout.log", "stderr.log"):
            value = (HERE / f"{label}.{suffix}").read_bytes()
            row[suffix] = {"bytes": len(value), "sha256": hashlib.sha256(value).hexdigest()}
        path = HERE / f"{label}.command.json"
        path.write_text(json.dumps(row, indent=2) + "\n")
        records.append(row)
        print(json.dumps(row, sort_keys=True), flush=True)
        expected = 1 if suite == "red" else 0
        if row["timed_out"] or row["returncode"] != expected:
            break
    (HERE / "archive-r4-commands.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
