"""Independent r4 archive controls; synthetic PIDs and a bounded fake clock."""
import ast
import errno
import importlib.util
import io
from pathlib import Path
import signal
import subprocess
import types
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SOURCE = ROOT / "crates/keelshell-session/src/archive_validation/test_archive_validation.py"
spec = importlib.util.spec_from_file_location("candidate_archive_tests_r4", SOURCE)
candidate_tests = importlib.util.module_from_spec(spec)
spec.loader.exec_module(candidate_tests)
probe = candidate_tests.probe


def use_baseline():
    source = HERE / "candidate-originals/crates/keelshell-session/src/archive_validation.py"
    old = types.ModuleType("r2_archive_helper")
    exec(compile(source.read_bytes(), str(source), "exec"), old.__dict__)
    candidate_tests.probe = old


class IndependentR4Controls(unittest.TestCase):
    def test_initial_eperm_never_retries_or_reaps_even_if_later_lookup_would_disappear(self):
        child = types.SimpleNamespace(pid=1234, wait=mock.Mock())
        with mock.patch.object(probe.os, "killpg", side_effect=[
            PermissionError(errno.EPERM, "PRIVATE_SENTINEL"), ProcessLookupError(),
        ]) as kill, mock.patch.object(probe.time, "sleep") as sleep:
            with self.assertRaises(probe.CleanupUnknown) as caught:
                probe.terminate_and_wait(child)
        kill.assert_called_once_with(child.pid, signal.SIGKILL)
        child.wait.assert_not_called()
        sleep.assert_not_called()
        self.assertEqual(caught.exception.args, ("group_kill_failed", errno.EPERM))
        self.assertTrue(caught.exception.__suppress_context__)
        self.assertNotIn("PRIVATE_SENTINEL", str(caught.exception))

    def test_wait_oserror_or_timeout_never_retries_or_observes_after_failed_wait(self):
        for error in (PermissionError(errno.EPERM, "PRIVATE_SENTINEL"),
                      subprocess.TimeoutExpired("PRIVATE_SENTINEL", 0.5)):
            with self.subTest(error_type=type(error).__name__):
                child = types.SimpleNamespace(pid=1234, wait=mock.Mock(side_effect=error))
                with mock.patch.object(probe.os, "killpg") as kill, \
                        mock.patch.object(probe.time, "sleep") as sleep:
                    with self.assertRaises(probe.CleanupUnknown) as caught:
                        probe.terminate_and_wait(child)
                self.assertEqual(kill.call_args_list, [mock.call(child.pid, signal.SIGKILL)])
                child.wait.assert_called_once()
                sleep.assert_not_called()
                self.assertEqual(caught.exception.args,
                                 ("leader_wait_unconfirmed", getattr(error, "errno", None)))
                self.assertTrue(caught.exception.__suppress_context__)
                self.assertNotIn("PRIVATE_SENTINEL", str(caught.exception))

    def test_wait_cost_and_kill_cost_share_the_absolute_envelope_during_eperm(self):
        clock = [0.0]
        timeouts = []
        signals = []
        def kill(pid, number):
            signals.append(number)
            if number == signal.SIGKILL:
                clock[0] = 0.25
            else:
                raise PermissionError(errno.EPERM, "PRIVATE_SENTINEL")
        def wait(timeout):
            timeouts.append(timeout)
            clock[0] = 0.997
        def sleep(seconds):
            self.assertLessEqual(seconds, 0.003000000001)
            clock[0] += seconds
        child = types.SimpleNamespace(pid=1234, wait=wait)
        with mock.patch.object(probe.os, "killpg", side_effect=kill), \
                mock.patch.object(probe.time, "monotonic", side_effect=lambda: clock[0]), \
                mock.patch.object(probe.time, "sleep", side_effect=sleep):
            with self.assertRaises(probe.CleanupUnknown) as caught:
                probe.terminate_and_wait(child)
        self.assertEqual(timeouts, [0.75])
        self.assertAlmostEqual(clock[0], 1.0)
        self.assertEqual(caught.exception.args, ("group_absence_unconfirmed", errno.EPERM))
        self.assertEqual(signals[0], signal.SIGKILL)
        self.assertTrue(all(number == 0 for number in signals[1:]))

    def test_eperm_present_eperm_then_esrch_is_observation_only_until_absence(self):
        clock = [0.0]
        signals = []
        answers = iter((PermissionError(errno.EPERM, "private"), None,
                        PermissionError(errno.EPERM, "private"), ProcessLookupError()))
        def kill(pid, number):
            signals.append(number)
            if number == 0:
                answer = next(answers)
                if answer is not None:
                    raise answer
        child = types.SimpleNamespace(pid=1234, wait=mock.Mock())
        with mock.patch.object(probe.os, "killpg", side_effect=kill), \
                mock.patch.object(probe.time, "monotonic", side_effect=lambda: clock[0]), \
                mock.patch.object(probe.time, "sleep", side_effect=lambda seconds: clock.__setitem__(0, clock[0] + seconds)):
            probe.terminate_and_wait(child)
        self.assertEqual(signals, [signal.SIGKILL, 0, 0, 0, 0])
        self.assertAlmostEqual(clock[0], 0.015)
        child.wait.assert_called_once()

    def test_eperm_followed_by_eio_is_immediately_unknown_and_not_a_success(self):
        clock = [0.0]
        with mock.patch.object(probe.os, "killpg", side_effect=[
            None, PermissionError(errno.EPERM, "private"), OSError(errno.EIO, "private"),
        ]) as kill, mock.patch.object(probe.time, "monotonic", side_effect=lambda: clock[0]), \
                mock.patch.object(probe.time, "sleep", side_effect=lambda seconds: clock.__setitem__(0, clock[0] + seconds)) as sleep:
            with self.assertRaises(probe.CleanupUnknown) as caught:
                probe.terminate_and_wait(types.SimpleNamespace(pid=1234, wait=mock.Mock()))
        self.assertEqual(kill.call_count, 3)
        sleep.assert_called_once_with(0.005)
        self.assertEqual(caught.exception.args, ("group_query_failed", errno.EIO))

    def test_all_new_unknown_phases_keep_main_65_with_no_json_or_stderr(self):
        for phase, number in (
            ("group_kill_failed", errno.EPERM),
            ("leader_wait_unconfirmed", None),
            ("group_query_failed", errno.EIO),
            ("group_absence_unconfirmed", errno.EPERM),
        ):
            with self.subTest(phase=phase):
                stdout = types.SimpleNamespace(buffer=io.BytesIO())
                stderr = io.StringIO()
                with mock.patch.object(probe.sys, "argv", ["-c"]), \
                        mock.patch.object(probe.sys, "stdout", stdout), \
                        mock.patch.object(probe.sys, "stderr", stderr), \
                        mock.patch.object(probe.signal, "signal"), \
                        mock.patch.object(probe, "collect", side_effect=probe.CleanupUnknown(phase, number)):
                    self.assertEqual(probe.main(), 65)
                self.assertEqual(stdout.buffer.getvalue(), b"")
                self.assertEqual(stderr.getvalue(), "")

    def test_production_work_budgets_supervisor_and_dispatch_unchanged_from_r2(self):
        old = ast.parse((HERE / "candidate-originals/crates/keelshell-session/src/archive_validation.py").read_bytes())
        new = ast.parse((ROOT / "crates/keelshell-session/src/archive_validation.py").read_bytes())
        def select(tree):
            picked = {}
            for node in tree.body:
                if isinstance(node, ast.Assign):
                    for target in node.targets:
                        if isinstance(target, ast.Name) and target.id in {
                            "COMMAND_SECONDS", "TOTAL_SECONDS", "CLEANUP_SECONDS",
                            "COMMAND_OUTPUT", "TOTAL_OUTPUT", "SUPERVISOR",
                        }:
                            picked[target.id] = ast.dump(node, include_attributes=False)
                if isinstance(node, ast.FunctionDef) and node.name in {"run_owned", "collect", "main"}:
                    picked[node.name] = ast.dump(node, include_attributes=False)
            return picked
        self.assertEqual(select(new), select(old))
        self.assertEqual(len(select(new)), 9)
