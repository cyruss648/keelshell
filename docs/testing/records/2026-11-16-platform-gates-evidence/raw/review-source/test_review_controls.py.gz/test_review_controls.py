"""Independent clock, fail-closed and diagnostic counterexamples; no actual PIDs."""
import errno
import importlib.util
import json
from pathlib import Path
import signal
import subprocess
import types
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SOURCE = ROOT / "crates/keelshell-session/src/archive_validation/test_archive_validation.py"
spec = importlib.util.spec_from_file_location("candidate_archive_tests", SOURCE)
candidate_tests = importlib.util.module_from_spec(spec)
spec.loader.exec_module(candidate_tests)
probe = candidate_tests.probe


def use_baseline():
    source = HERE / "baseline-originals/crates/keelshell-session/src/archive_validation.py"
    old = types.ModuleType("baseline_archive_helper")
    exec(compile(source.read_bytes(), str(source), "exec"), old.__dict__)
    candidate_tests.probe = old


class CleanupControls(unittest.TestCase):
    def test_kill_time_is_deducted_from_the_single_wait_allowance(self):
        clock = [0.0]
        signals = []
        timeouts = []
        def kill(pid, number):
            signals.append(number)
            if number == signal.SIGKILL:
                clock[0] = 0.3
            else:
                raise ProcessLookupError()
        child = types.SimpleNamespace(pid=1234, wait=lambda timeout: timeouts.append(timeout))
        with mock.patch.object(probe.time, "monotonic", side_effect=lambda: clock[0]), \
                mock.patch.object(probe.os, "killpg", side_effect=kill):
            probe.terminate_and_wait(child)
        self.assertAlmostEqual(timeouts[0], 0.7)
        self.assertEqual(signals, [signal.SIGKILL, 0])

    def test_denied_initial_kill_does_not_reap_or_claim_absence(self):
        child = types.SimpleNamespace(pid=1234, wait=mock.Mock())
        with mock.patch.object(probe.os, "killpg", side_effect=PermissionError(errno.EPERM, "private")):
            with self.assertRaises(probe.CleanupUnknown):
                probe.terminate_and_wait(child)
        child.wait.assert_not_called()

    def test_wait_oserror_prevents_post_reap_observation(self):
        child = types.SimpleNamespace(pid=1234, wait=mock.Mock(side_effect=OSError(errno.EIO, "private")))
        with mock.patch.object(probe.os, "killpg") as kill:
            with self.assertRaises(probe.CleanupUnknown):
                probe.terminate_and_wait(child)
        self.assertEqual(kill.call_args_list, [mock.call(child.pid, signal.SIGKILL)])

    def test_denied_observation_stays_unknown_after_successful_wait(self):
        child = types.SimpleNamespace(pid=1234, wait=mock.Mock())
        with mock.patch.object(probe.os, "killpg", side_effect=[None, PermissionError(errno.EPERM, "private")]) as kill:
            with self.assertRaises(probe.CleanupUnknown):
                probe.terminate_and_wait(child)
        self.assertEqual(kill.call_args_list, [mock.call(child.pid, signal.SIGKILL), mock.call(child.pid, 0)])
        child.wait.assert_called_once()

    def test_absent_initial_group_still_requires_leader_wait(self):
        events = []
        def kill(pid, number):
            events.append(number)
            raise ProcessLookupError()
        child = types.SimpleNamespace(pid=1234, wait=lambda timeout: events.append("wait"))
        with mock.patch.object(probe.os, "killpg", side_effect=kill):
            probe.terminate_and_wait(child)
        self.assertEqual(events, [signal.SIGKILL, "wait", 0])

    def test_persistent_or_reused_group_only_receives_signal_zero_after_reap(self):
        clock = [0.0]
        events = []
        def wait(timeout):
            events.append("wait")
            clock[0] = 0.9
        def sleep(seconds):
            self.assertGreater(seconds, 0)
            self.assertLessEqual(seconds, 0.005)
            clock[0] += seconds
        child = types.SimpleNamespace(pid=1234, wait=wait)
        with mock.patch.object(probe.os, "killpg", side_effect=lambda pid, number: events.append(number)), \
                mock.patch.object(probe.time, "monotonic", side_effect=lambda: clock[0]), \
                mock.patch.object(probe.time, "sleep", side_effect=sleep):
            with self.assertRaises(probe.CleanupUnknown):
                probe.terminate_and_wait(child)
        self.assertEqual(events[:2], [signal.SIGKILL, "wait"])
        self.assertTrue(all(event == 0 for event in events[2:]))
        self.assertAlmostEqual(clock[0], 1.0)


class DiagnosticControls(unittest.TestCase):
    def test_publication_oserror_is_reraised_and_diagnostic_contains_no_private_text(self):
        import test_windows_native_crash as tests
        code_error = PermissionError(errno.EACCES, "PRIVATE_REVIEW_SENTINEL")
        code_error.winerror = 32
        captured = {}
        owner = types.SimpleNamespace(process=types.SimpleNamespace(pid=4242))
        class StopAfterMessage(Exception):
            pass
        def inspect(value, message):
            captured.update(message)
            raise StopAfterMessage()
        def controller(*args, **kwargs):
            try:
                kwargs["tick"](owner.process)
            except OSError as error:
                self.assertIs(error, code_error)
                captured["same_exception_reraised"] = True
            else:
                self.fail("diagnostics swallowed the preparation failure")
            return subprocess.CompletedProcess([], 125, "", ""), {
                "errors": ["owned_preparation_failed"], "terminal": None,
            }
        instance = tests.PreparationTreeTests()
        with mock.patch.object(tests.probe, "owner_for_host", return_value=owner), \
                mock.patch.object(tests.probe, "run_owned", side_effect=controller), \
                mock.patch.object(tests, "ready_pids", side_effect=code_error), \
                mock.patch.object(instance, "assertIsNotNone", side_effect=inspect):
            with self.assertRaises(StopAfterMessage):
                instance.tree()
        self.assertTrue(captured["same_exception_reraised"])
        self.assertEqual(captured["identity_observation"], {
            "phase": "reading_publication",
            "failure": {"kind": "PermissionError", "errno": errno.EACCES, "winerror": 32},
        })
        self.assertFalse(captured["ack_created"])
        self.assertEqual(captured["receipt"]["errors"], ["owned_preparation_failed"])
        self.assertNotIn("PRIVATE_REVIEW_SENTINEL", json.dumps(captured))
