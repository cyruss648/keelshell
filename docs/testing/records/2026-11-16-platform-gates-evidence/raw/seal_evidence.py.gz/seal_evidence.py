"""Losslessly seal completed batch originals; run after all writers have stopped."""
import gzip
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
DESTINATION = ROOT / "docs/testing/records/2026-11-16-platform-gates-evidence"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    assert not DESTINATION.exists(), "Preserve earlier archives"
    files = {}
    for path in sorted(BASE.rglob("*")):
        if not path.is_file() or "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        assert not path.is_symlink()
        relative = path.relative_to(BASE).as_posix()
        data = path.read_bytes()
        artifact = "raw/" + relative + ".gz"
        compressed = gzip.compress(data, mtime=0)
        target = DESTINATION / artifact
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(compressed)
        assert gzip.decompress(target.read_bytes()) == data
        files[relative] = {
            "artifact": artifact,
            "source_bytes": len(data),
            "source_sha256": sha(data),
            "artifact_sha256": sha(compressed),
        }
    for name, row in files.items():
        assert sha((BASE / name).read_bytes()) == row["source_sha256"], name
    manifest = {
        "count": len(files),
        "source_bytes": sum(row["source_bytes"] for row in files.values()),
        "files": files,
    }
    (DESTINATION / "archive-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({key: value for key, value in manifest.items() if key != "files"}))


if __name__ == "__main__":
    main()
