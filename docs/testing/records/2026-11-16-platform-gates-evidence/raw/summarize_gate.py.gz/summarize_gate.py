"""Bind the completed gate to the final engineering set and compiled inventory."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]


def main():
    receipt = json.loads((BASE / "full-gate-r1.json").read_text())
    assert receipt["controller_exit"] == receipt["observed_exit"] == 0
    assert not receipt["timed_out"] and not receipt["errors"]
    assert receipt["terminal"]["direct_reaped"] and receipt["terminal"]["active_processes"] == 0
    assert receipt["terminal"]["pipes_drained"]
    text = (BASE / "full-gate-r1.log").read_text()
    workspace = text.split("Running: cargo test --workspace --locked -- --test-threads=4\n", 1)[1]
    workspace = workspace.split("Running: cargo test -p keelshell-ai", 1)[0]
    totals = {kind: dict(passed=0, failed=0, ignored=0) for kind in ["ordinary", "rustdoc"]}
    kind = "ordinary"
    for line in workspace.splitlines():
        if line.strip().startswith("Doc-tests "):
            kind = "rustdoc"
        elif line.strip().startswith("Running "):
            kind = "ordinary"
        match = re.search(r"^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;", line)
        if match:
            for key, value in zip(["passed", "failed", "ignored"], match.groups()):
                totals[kind][key] += int(value)
    assert totals["ordinary"] == dict(passed=3210, failed=0, ignored=48), totals
    assert totals["rustdoc"] == dict(passed=14, failed=0, ignored=0), totals
    assert "Ran 290 tests" in text and "OK (skipped=1)" in text
    assert "Ran 30 tests" in workspace
    inventory_text = (BASE / "app-inventory-r1.log").read_text()
    inventory = re.findall(r"^(.+): test$", inventory_text, re.M)
    assert len(inventory) == len(set(inventory)) == 1331
    app_section = workspace.split("unittests src/main.rs", 1)[1].split("test result:", 1)[0]
    executed = set(re.findall(r"^test (.+?) \.\.\. (?:ok|ignored)", app_section, re.M))
    assert executed == set(inventory), (len(executed), len(inventory))
    freeze = json.loads((BASE / "engineering-inputs-r4.json").read_text())
    names = subprocess.check_output(
        ["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"],
        cwd=ROOT, timeout=30,
    ).split(b"\0")
    current = {
        name.decode() for name in names
        if name and not name.startswith(b"docs/") and (ROOT / name.decode()).is_file()
    }
    assert current == {row["path"] for row in freeze["inputs"]}
    assert len(current) == freeze["count"] == 717
    mismatch = [
        row["path"] for row in freeze["inputs"]
        if hashlib.sha256((ROOT / row["path"]).read_bytes()).hexdigest() != row["sha256"]
    ]
    assert not mismatch, mismatch
    summary = {
        "gate": receipt, "engineering_inputs": freeze["count"],
        "engineering_sha256": freeze["aggregate_sha256"],
        "complete_engineering_path_set_matches": True, "input_mismatches": mismatch,
        "rust": totals, "app_inventory_count": len(inventory),
        "app_executed_names_match": True,
        "python": dict(run=290, passed=289, skipped=1, failed=0),
        "archive_helper": dict(run=30, passed=30, failed=0),
        "format_strict_clippy_xy_policy_and_three_controllers_passed": True,
    }
    with (BASE / "final-gate-summary.json").open("x") as output:
        json.dump(summary, output, indent=2)
        output.write("\n")
    print(json.dumps({key: value for key, value in summary.items() if key != "gate"}))


if __name__ == "__main__":
    main()
