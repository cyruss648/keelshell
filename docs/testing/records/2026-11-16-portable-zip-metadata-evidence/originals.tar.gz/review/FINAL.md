**最终限定批准：APPROVE。本批三个工程文件 P0 = 0、P1 = 0、P2 = 0、P3 = 0。**

原 [静态 REPORT.md](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/zip-unix-metadata-review-20261116/REPORT.md) 保持原文。本补充件记录用户随后授权的一次非作者独立宿主功能专项，实际执行成功；不能扩大为独立编译、当前修订 Windows 执行或全产品验收。

签署仍绑定 HEAD `2f29744a2615393bcc5bedb81cd2c425e7bc6372`、工程基线 `f094de6ad2789d168f5a24bacb316c98b83608ac`、`source-r2` 与 `candidate-r2.diff`，719 项输入聚合 `bf46afc32603f312f3ff9e7edb5e48ea9bb4c3073b109c072e2f6ded44a8f4fd`。

**独立执行的来源与结果**

使用父在 Dos 负例 finally 精确恢复、scope 重新编译后复制的 Darwin arm64 预编译测试程序：

`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/zip-unix-metadata-integration-20261116/review-binary/archive-tests`

程序为普通文件、非 symlink，4,558,792 bytes。独立读取的 SHA-256 在运行前后均为：

`f317ce23f6ff0117b89f6efdeeae9b62a30fcec1e08826e2ed84eeabf12887b3`

[review-binary-binding-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/zip-unix-metadata-integration-20261116/review-binary-binding-r1.json) 文件 SHA-256 为 `b34be78500f7050f4da7c9848951a98ed2869cf77b67595150c44a2f13c05c00`。其中冻结、程序摘要、字节数、父 receipt、恢复后编译日志和 41 名库存均已核对。父 scope 原日志确有 core 重新编译及后续全 target 通过；本次没有重新编译。

| 独立命令 | 实际结果 | 外层观测用时 |
| --- | --- | ---: |
| 稳定副本 `--list` | exit 0；41 名、41 唯一名；与 source-r2 的 41 个测试名逐项相等 | 0.408s |
| 同一副本 `--test-threads=4` | exit 0 / reaped；41 passed、0 failed、0 ignored、0 filtered | 9.175s |

独立 wrapper 总耗时 9.635s，预算 115s，小于用户指定的 120s；两个子进程均无超时且已直接 wait 回收。完整执行结果的 41 个唯一名称与独立 list 逐项相等。

以下两项均已独立列出并实际运行，结果为 ok：

- `zip_records_private_file_and_directory_modes_in_unix_metadata`
- `reencoding_discards_dangerous_incoming_permissions_and_ownership`

运行前后重新读取冻结的 719 个工程文件均零漂移。没有运行 Cargo、Clippy、fmt、CI、负例或共享 target 中的程序；没有写共享 target、工程、docs，没有提交、推送或清理。独立编译 0，Windows native 0，桌面 GUI 0。实际 Rust 功能验证来自上述宿主预编译副本，独立完整执行 1 次、41 例，另有独立 list 1 次。

**原件与只读命令数量**

- [independent-list.log](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/zip-unix-metadata-review-20261116/independent-list.log)：2,577 bytes，SHA-256 `901e5469f4a2f549589ae17ecae17e6e96c06a57556724b641941d6bedd504d1`。
- [independent-archive.log](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/zip-unix-metadata-review-20261116/independent-archive.log)：3,009 bytes，SHA-256 `c3bed085e64d29cf66505cb0254a2e7f1a0a9ba5554ee8fed15bdcec57bef392`。
- [independent-test-receipt.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/zip-unix-metadata-review-20261116/independent-test-receipt.json)：命令、预算、退出码、回收、前后摘要、完整 41 名 list/result 与冻结恢复事实。
- [static-receipt.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/zip-unix-metadata-review-20261116/static-receipt.json)：静态命令账、源码/原件绑定与交付摘要。

实际只读静态 exec 共 35 次，其中静态报告原阶段 34 次、补充的二进制来源与父库存核对 1 次；32 次 exit 0、3 次非零诊断，原因与补救见原 REPORT。计数单位为顶层 exec 调用，不拆分内嵌只读 Git 子命令或 Python 语句。另有独立专项 wrapper exec 1 次、交付收据写入与最终读回 exec 1 次；不计作额外静态通过或 Rust 测试。独立程序子命令共 2 条（list、完整执行各 1），未重试。

补充只读核对还直接从父 scope 原日志重建 compiled/result：346 名各唯一且逐项相等，342 ok / 4 ignored；与父 summary 相等。这是 reviewer 对父原件的独立分析，父的 342 项结果不计作 reviewer 独立测试。

**批准范围与采用条件**

本批 production ZIP metadata 修复、完整 raw metadata 回归和 CI 提前暴露 core/session 范围的实现可采用。没有可行动的 API 误用、安全、跨平台代码、库存 guard 或测试有效性发现。父恢复后的宿主专项、两项预期红例与本次独立 41 例均按真实来源记录。

当前修订的新精确 Windows codec/session 实际结果仍待取得；八个 Windows 必需名及完整 session inventory 需在该平台原件中核对，Zmodem 候选未集成、其本次 Windows 实际结果仍为 0。旧 f094 的 run `43859165104` 保持 completed/failure：macOS/Ubuntu success，Windows 后续 core archive 39/1；不得移签。

本批最终全产品门禁、当前修订的 Windows 执行和桌面原生验收均不由本次预编译专项替代。采用时保持冻结身份，按项目合同完成相应门禁与状态文档。这些范围限制不是新增代码发现，不将本批 APPROVE 改记为代码 HOLD。
