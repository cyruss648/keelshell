**APPROVE：本批三个工程文件的非作者静态评审通过。P0 = 0，P1 = 0，P2 = 0，P3 = 0。**

本报告保留静态阶段的原始结论；后续获授权的独立预编译测试执行另记补充报告，不改写此阶段的执行数量。结论只覆盖下述冻结候选，不签署完整产品、当前修订的 Windows 实际执行或原生桌面验收。父测试待定或范围未运行不构成代码发现。

评审日期为 2026-11-16。已读根 AGENTS.md、`/Users/hdh/.codex/RTK.md`、当前 HANDOFF、共享 target 合同，以及 rust-best-practices 第 1、2、4、5、8 章。参考记忆仅用于只读评审的证据分层惯例；本次源码、依赖和执行事实均从当前原件核实。

**签署对象与冻结**

主树：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`。
HEAD：`2f29744a2615393bcc5bedb81cd2c425e7bc6372`。
工程基线：`f094de6ad2789d168f5a24bacb316c98b83608ac`。
已核实两提交之间仅有 docs 变动，工作区工程差异正好为指定三个文件。

签署以 [source-r2 快照](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/zip-unix-metadata-integration-20261116/source-r2)、[candidate-r2.diff](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/zip-unix-metadata-integration-20261116/candidate-r2.diff) 和 [inputs-freeze-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/zip-unix-metadata-integration-20261116/inputs-freeze-r1.json) 为准。

| 输入 | SHA-256 |
| --- | --- |
| 719 项冻结聚合，按 `path + NUL + sha256 + LF` 复算 | `bf46afc32603f312f3ff9e7edb5e48ea9bb4c3073b109c072e2f6ded44a8f4fd` |
| inputs-freeze-r1.json 文件 | `85591a4f87760eaf507f617aee689d6d633c79187fea4648f36b9702e0c3f4cf` |
| candidate-r2.diff | `3df18ffbab526856b0c9d9a691b4ff6ae1b524a5b6b7857f0f40ade780901234` |
| .github/workflows/ci.yml | `d11a06dfd3862ac8a407b8729310e8399ae68e8b431a5ba28f4579e9bb22e753` |
| crates/keelshell-core/src/archive.rs | `bc950cc74f339b37a7ddc87f5b2d50425a561133706140cf23788a40734cfdd0` |
| crates/keelshell-core/tests/archive.rs | `296783931f3d8284d39efe8e9e93f107076976cd41f7fc2ebc23babf4f377049` |

719 条路径唯一且有序，与 HEAD 全部非 docs 跟踪路径集合相等，遗漏和额外路径均为 0。三份快照与冻结逐项相等；在内存中按 HEAD 应用 diff 的 5 个 hunk 后，三文件均逐字节等于 source-r2。初次及父负例恢复后均独立读取全部 719 项，零漂移。父明确授权的短暂 Dos 变异不作为最终候选发现。

**代码、安全与 API 核查**

1. [encode_zip 的公共 options](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/zip-unix-metadata-integration-20261116/source-r2/crates/keelshell-core/src/archive.rs:230) 显式选择 `System::Unix`，file、directory 分支分别保留 `0600`、`0700`。修改作用于 ZIP 容器元数据，不授予文件系统操作权限。没有修改解码、路径验证、大小边界、发布操作或原错误传播。
2. 已核实实际依赖为 lock 中的 zip 9.6.0，registry 要求仍为 `9.6`。本地缓存 `.crate` 摘要与 lock checksum `80cc68510ea7553c30a69c732de5278e94183f68765af6c642dbccefd6ec777e` 相等；压缩包 67 个普通文件与指定依赖源码逐字节相等。本地未提供 `.cargo-checksum.json`，改用该完整压缩包核对，没有下载或修改依赖。
3. [FileOptions 定义](/Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837/zip-9.6.0/src/write/options.rs:50) 证明 SimpleFileOptions 可 Copy；链式 `.system()`、`.compression_method()`、`.unix_permissions()` 使用合法。文件 normalize 和 directory 写入分别补 regular/directory 类型位。`ZipFile::name()` 在该版本返回 Result，测试中的 `.unwrap()` 与实际 API 相符。
4. [zip 的 system 选择](/Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837/zip-9.6.0/src/types.rs:466) 确认未指定 system 时 Windows 默认 Dos；[get_unix_mode](/Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837/zip-9.6.0/src/format/functions.rs:31) 对 Dos 文件合成 `0664`，对 Unix 解读 external attributes 的高 16 位。候选修复与真实失败机制一致，未通过放宽权限断言规避失败。
5. 没有新增生产 panic、unsafe、阻塞 I/O、凭据处理、依赖或公开 API；原有 typed Result 与 bounded writer 路径保持。

**测试有效性与 CI 库存**

新增 [zip_records_private_file_and_directory_modes_in_unix_metadata](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/zip-unix-metadata-integration-20261116/source-r2/crates/keelshell-core/tests/archive.rs:639) 包含文件、非空父目录、显式空目录及二进制载荷。逐项检查 creator system、`unix_mode()`、原始 central signature、creator OS 字节 3，以及 external attributes 高 16 位的完整 type/mode；最后比较完整 ArchiveBundle roundtrip。central 偏移 `+5`、`+38..+42` 与依赖写入结构相符。

原始属性断言补足了依赖 `unix_mode()` 会清除 SUID/SGID/sticky 位的盲区；roundtrip 比较也避免仅凭被测 entry 自己推导的 kind 得到空洞成功。没有新增 cfg 或 ignore。core archive 静态库存 41 名。

原 [reencoding_discards_dangerous_incoming_permissions_and_ownership](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/zip-unix-metadata-integration-20261116/source-r2/crates/keelshell-core/tests/archive.rs:672) 函数正文与 HEAD 逐字节相等，保留危险权限输入、ZIP 0600、TAR 0600 和 uid/gid = 0 断言。正文 SHA-256 为 `b57c6070ff874434400410cf278e5608588813bbce88d43de206e82a737f372d`。

[Windows codec preflight](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/zip-unix-metadata-integration-20261116/source-r2/.github/workflows/ci.yml:35) 检查两个精确测试名后执行整个 core archive target；[session preflight](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/zip-unix-metadata-integration-20261116/source-r2/.github/workflows/ci.yml:52) 检查原三项 archive 与三项 Zmodem 精确名后执行整个 session lib。八个名称均能沿 Windows 模块路径映射到有效且未 ignored 的测试。

静态 11 项 workflow 检查全部通过：Windows 条件、pwsh、list 失败传播、区分大小写的完整行 membership、执行 exit code、完整 core target、完整 session lib、无 ignore/skip 选择、无错误绕过、原 full gate 保留、步骤顺序。各步骤失败继续阻止后续 gate，没有取消或重跑旧 CI 的逻辑变更。库存 guard 证明八个必需名称存在；完整清单及实际执行结果仍应在新精确 Windows 原件中逐项核对。

**父执行原件的只读复核；不计为 reviewer 独立测试**

已核对 [scoped-gate-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/zip-unix-metadata-integration-20261116/scoped-gate-r1.json)、[scoped-gate-r1.log](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/zip-unix-metadata-integration-20261116/scoped-gate-r1.log) 及 [scoped-summary-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/zip-unix-metadata-integration-20261116/scoped-summary-r1.json)。父命令实际 exit 0 / reaped / 51.622s，active processes = 0、pipes drained；fmt check、x.y policy、严格 workspace all-target Clippy 通过。

| 父宿主专项 | passed | failed | ignored |
| --- | ---: | ---: | ---: |
| core archive target | 41 | 0 | 0 |
| session lib | 288 | 0 | 4 |
| app archive 子集 | 13 | 0 | 0 |
| 总计 | 342 | 0 | 4 |

父摘要记录 compiled/result 共 346 个唯一名称逐项相等，719 输入零漂移。恢复后的 scope 日志明确重新编译 core，之后两项权限测试和整个 archive target 通过。该批未重跑全产品门禁。

已读 [Dos 负例原日志](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/zip-unix-metadata-integration-20261116/dos-metadata-red-r1.log) 及控制脚本：两项分别真实 Rust exit 101；新用例失败为 `Dos != Unix`，原权限用例精确复现 `436 != 384`。finally 恢复生产 SHA `bc950c…cfdd0`；本次独立读取亦确认全部 719 项恢复。没有重复运行负例。

**旧精确 CI 的真实边界**

[source-ci-final-r1.log](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-archive-publication-integration-20261116/source-ci-final-r1.log) 绑定 run `43859165104`、源码 `f094de6ad2789d168f5a24bacb316c98b83608ac`，三平台均 completed：Ubuntu、macOS success，Windows failure。该 run 不包含本次 r2 修复。

从 [Windows 原日志](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-archive-publication-integration-20261116/source-windows-job-r2.log:538) 重新核对，而非仅采用摘要：

| 旧 Windows 范围 | 实际结果 |
| --- | --- |
| platform | 70 passed / 0 failed / 0 ignored |
| archive backend preflight | 29 passed / 0 failed / 1 原 ignored；30 名 list/result 逐项相等 |
| app | 1330 passed / 0 failed / 2 ignored；原四败均逐名 ok |
| core archive | 39 passed / 1 failed / 0 ignored |
| 完整 session lib / 三项 Windows Zmodem guard 用例实际结果 | 未运行 / 0 |

原唯一 core 失败见 [原日志定位](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-archive-publication-integration-20261116/source-windows-job-r2.log:3460)：旧源码 `tests/archive.rs:645`，left 436 (`0664`)、right 384 (`0600`)。原 gate 已实际运行并失败，不能写成全 gate 未运行或成功。Zmodem 候选没有集成，不能将宿主 session 通过移签为 Windows Zmodem 修复。

Windows 原日志 SHA-256 为 `a7b57d6aee70693e8ab2cdda3c2bc08a2bdce12a42d200b141a38895e80e6e2f`，与原 summary 相等。

**采用条件与范围限制**

- 可采用本批三文件代码；签署仅适用于上述冻结输入。工程输入改变后，需要按变化重新评估；父当前 scoped gate 的通过限定在其实际宿主范围。
- 本次独立功能专项如执行，应核对稳定副本的二进制摘要、恢复后重新编译来源、41 名库存及全部运行结果，另存补充件。独立编译始终为 0。
- 新精确源码 Windows CI 尚须实际执行 codec target 和完整 session lib，核对八个必需名及全量结果；原 symlink privilege ignore 和任何新增失败保持原样。当前修订的 Windows native 执行仍为 0。
- 按工程交付合同完成本次最终完整门禁及文档状态更新；旧 f094 gate failure 保持。全产品、桌面 GUI、跨平台互操作和发行验收均不在本报告签署范围。

**静态阶段执行账**

实际 34 次只读静态 exec 调用：31 次 exit 0；1 次嵌套 AGENTS 搜索无匹配 exit 1；1 次依赖初查使用两个不存在的旧布局文件名 exit 2，随后按真实目录完整核查；1 次尝试读取未提供的 `.cargo-checksum.json` exit 1，随后用 lock 绑定的原始 `.crate` 完成 67 文件核对。这三次非零均为检查过程事实，不是工程失败或 P0–P3 发现。

截至本文静态阶段，reviewer 独立 Rust 测试执行 0、Cargo 0、Clippy 0、fmt 0、CI 操作 0、独立编译 0、native/GUI 0。没有运行预存测试、负例或共享 target 中的程序，没有修改工程、target、docs，没有提交、推送或清理。本文及后续评审交付文件仅写入用户指定评审目录。
