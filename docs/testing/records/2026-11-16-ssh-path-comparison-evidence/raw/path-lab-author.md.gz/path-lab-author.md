# NET-03 SSH path lab 作者交接

日期：2026-11-16（Asia/Shanghai）。
受管 worktree：`/Users/hdh/.codex/worktrees/ssh-path-lab-20261116/keelshell`。

## 交付与边界

已读取该树 AGENTS、HANDOFF、`/Users/hdh/.codex/RTK.md`，并读取父树
`docs/adr/0141-reviewed-ssh-path-comparison.md`。遵守父方限定，只新增下列
四个产品/工程文件；本文件是用户指定的独立作者记录：

| 文件 | SHA256 |
| --- | --- |
| `scripts/ssh_path_lab.py` | `5d0346241c2369e00e610544e6ce2c6d96d7fc5d44230e1be8ec1d4be48a7cac` |
| `scripts/test_ssh_path_lab.py` | `9441dc2aa286e4d1e174a35bf1e8c6bdf54de41ff2c55125b9baeb872593b846` |
| `crates/keelshell-session/tests/ssh_path_interop.rs` | `3c5aaebb8f872e2602e02955a8f4d04bfc2210b122740386d07c8df3e2325482` |
| `docs/product/SSH_RELAY.md` | `be08298615a19403d5548b2f2c2150ca386e93c2b6a2bc4804761e79c146fa18` |

未运行 Cargo、rustc、rustfmt、Rust binary 或完整门禁；未改依赖、lock、
既有 runner、生产模块、UI、其他文档、Git index；未 commit/push。
共享 Cargo target 未使用，也未切换归属。

Rust integration 是依据约定 API 写好的待集成源码，
`NOT_COMPILED / NOT_RUN`。完整 OpenSSH 三场景和收益验证由父统一执行；
本作者不签真实路径比较通过、性能收益、NET-03/M4 全部完成或原生桌面验收。

## Runner 实现

必须传入 `--test-binary`，不包含 Cargo fallback。运行前读回 SHA256 与
`--list --ignored`，逐名验证三个 integration 用例；来源与共享 target 的
编译归属仍须由父独立核对，库存与 hash 本身不证明 fresh compilation。

临时启动真正的 target sshd 与独立 jump sshd，各自的 host key、client key、
authorized_keys、配置和日志均分离。所有 listener 为 `127.0.0.1`；
target 禁止转发，jump 只允许 `direct-tcpip` 到同一个 target、`MaxSessions 0`、
禁止 PTY。没有更改用户 SSH 配置或创建系统账户。

```text
A -> restricted HTTP CONNECT gate A -> target
B -> restricted HTTP CONNECT gate B -> jump -> target
```

两条连接的最终 `options.host/port/username/pin` 完全相同；B 使用真实
`SshSession::connect_through`。gate B 的唯一 CONNECT authority 是 jump，
gate A 的唯一 authority 是 target；均不能被用作任意目标代理。
跳板与最终目标分别使用各自生成的真实 host key 端到端 pin。

默认运行 `baseline`、`direct-impaired`、`relay-impaired`。每个场景单独启动
两个 gate，不修改已存在 tunnel 的参数或复用排队状态。默认受损 gate 的每个
方向独立执行至多 16 KiB 读取、写前等待 `20ms + chunk_bytes/524288`，再通过
drain 施加背压。准确标注为用户态 stream delay/throttle，不声称固定 RTT、
IP 丢包、netem 或 TCP 重传。两个损伤参数均零时拒绝运行损伤场景。

每场景一份完整比较，固定三轮 18 原始样本、每次 up/down 256 KiB、每比较
3 MiB；三场景合计 9 MiB 合成主载荷，额外有 SSH、固定 exec 与存活检查开销。
单样本八秒、plan 六十秒由传输模块负责；runner 给单次测试 72 秒外边界。
基线另运行两个负例/取消用例，各有 18 秒外边界。整次最多 300 秒，预留
20 秒清理，所有等待继续受同一个总 deadline 约束。

新 `--output` 目录保留配置规则（仅密钥路径，无密钥内容）、公开指纹、
库存与各子进程日志、场景 conditions、review 和原始 report。Rust 在任何
完整性断言前写入实际 report，Incomplete/Cancelled/Failed 不改签。
Python 再独立核对 18 样本、每组完整三轮、字节数、严格成功、原样本中位数与
轮次先后，使用有符号 `B_minus_A_ns`，不输出“加速”结论。

密钥使用 checkout `work/.ssh-path-private-*` 的独立 0700 目录，避开 Linux
`/tmp` 可写祖先与 StrictModes 的冲突，finally 删除整个目录。
复用 `openssh_interop.py` 的 Runner、进程 birth identity、累积 ancestry、
signal_owned、stop_owned 与 readiness；没有复制其整套框架。
正常/失败/超时/中断均逐一停止进程并实际 Popen.wait reap；进程库存失败时只
信号已记录的精确身份，仍实际 reap，但保留 cleanup unconfirmed 并退出失败。
父回执保留各进程 birth identity、退出、reap 和私有目录删除状态。

父侧集成四文件、格式化/构建并核对预构建 binary 来源后，可执行：

```sh
python3 scripts/ssh_path_lab.py \
  --test-binary /absolute/path/to/verified/ssh_path_interop-TEST_HASH \
  --output work/ssh-path-lab/r1
```

已有 output 会拒绝复用。也可使用 `--scenario baseline`、
`--scenario direct-impaired` 或 `--scenario relay-impaired` 分开保留运行证据。
不要把本作者的 Python 工程测试误作上述真实 Rust/OpenSSH 实验。

## Rust 新用例

三个都是默认 ignored，首行 `#![cfg(test)]`，无新增依赖：

1. `openssh_path_comparison_collects_eighteen_pinned_samples`
   — 同目标两真实路径、plan clone/session binding、审核文本、全部原始样本与
   中位数、数据量及期限；比较后两 target 与 jump 新通道仍可用。
2. `openssh_path_comparison_precancel_preserves_routes`
   — clone/同路线独立连接拒绝；预取消无样本、无中位数、清理确认，父连接存活。
3. `openssh_path_comparison_rejects_unpinned_target_and_jump`
   — 互换两个实际 host key 的有效指纹，分别断言
   `SessionError::ChangedHostKey`；错误最终 pin 后正确 jump 仍能连接目标。

不把预取消描述为已证明 exec 派发后的竞态取消；该范围由底层模块/父进一步
验证。本 integration 不创建远端文件，不请求 PTY，不读写用户业务内容。

## 实际 Python 工程验证

最终命令：

```text
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s scripts -p test_ssh_path_lab.py -v
exit 0; Ran 16 tests in 0.746s; OK

python3 -m unittest discover -s scripts -p test_openssh_interop.py -v
exit 0; Ran 6 tests in 0.005s; OK

python3 scripts/ssh_path_lab.py --help
exit 0
```

对两份新 Python 做 AST parse，四文件没有 trailing whitespace。
没有执行 Rust 格式或编译验证。

新增 Python 用例（16）：

```text
CleanupTests.test_early_inventory_rejection_retains_failed_receipt_and_cleanup
CleanupTests.test_gate_child_stops_and_is_reaped_with_a_live_connection
CleanupTests.test_inventory_failure_still_signals_only_recorded_identity_and_reaps
EvidenceTests.test_bad_numeric_cli_values_never_launch_a_process
EvidenceTests.test_complete_report_uses_signed_observed_difference
EvidenceTests.test_each_scenario_impairs_only_its_declared_gate
EvidenceTests.test_missing_failed_duplicate_and_wrong_payload_cannot_be_signed_complete
EvidenceTests.test_nonfinite_and_negative_elapsed_cannot_enter_a_summary
EvidenceTests.test_noop_impairment_is_rejected_before_launch
EvidenceTests.test_output_cannot_reuse_an_old_receipt
EvidenceTests.test_server_roles_have_separate_identity_and_minimal_forwarding
ForwardingTests.test_connect_preserves_binary_payload_already_buffered_after_headers
ForwardingTests.test_loopback_other_port_is_also_rejected
ForwardingTests.test_oversized_header_closes_without_an_upstream
ForwardingTests.test_throttle_has_measurable_delay_and_preserves_every_byte
ForwardingTests.test_wrong_authority_is_rejected_without_opening_any_upstream
```

这些测试实际使用 localhost asyncio socket，核对二进制字节、headers 后已缓冲
数据、half-close、速率等待、非授权 authority 拒绝；另真实启动两个 Python
子进程类型：短库存模拟器和 gate，均实际退出/reap。库存模拟器仅供验证
“零退出但没有目标用例库存不能判成功”，没有拿模拟器伪造 OpenSSH 验收。
所有测试临时目录经 TemporaryDirectory 回收，无 Rust 或真实 sshd 实验。

保留失败历史：首轮为 15 run / 1 failure / 1 error，3.798s。
gate 在新 Python 的 server.wait_closed 上先等待现有连接，导致其关闭测试三秒
超时；已调整为先关闭 listener、取消自己的 active tasks，再 wait_closed。
限速断言曾要求上下行时间完全相加（0.25s），实测 0.2247030839935178s，
两方向流水存在重叠；改为仍能区分无 pacing 的 0.18s 下界并核对所有字节。
首轮超时子进程由测试 finally kill + communicate 实际 reap。随后 15/15
通过，加入 no-op impairment 拒绝用例后最终 16/16；不把早先失败改写为通过，
也不叠加重复执行的测试数量。

## Podman 实际探查与清理

只读 `podman ps`、`podman images` 均 exit 0，确认本机有三个候选基础镜像。
没有进入、停止或修改现有 Slipway/Steer 资源。

三个独立临时容器均使用 `--pull=never --network=none --read-only
--cap-drop=all --cap-add=NET_ADMIN`，只执行 `command -v tc/sshd/python3` 等探查：

| 资源名称 | 镜像 | run exit | 工具输出 | rm exit | exists exit |
| --- | --- | --- | --- | --- | --- |
| `keelshell-path-capability-1b91845c3f` | `docker.io/library/ubuntu:latest` | 0 | 三个工具均未找到；内核标识 Linux | 0 | 1 |
| `keelshell-path-capability-8c60777576` | `docker.io/library/rust:1.98.1-slim-bookworm` | 0 | 三个工具均未找到 | 0 | 1 |
| `keelshell-path-capability-1a6915d090` | `docker.io/library/alpine:3.22` | 0 | 三个工具均未找到 | 0 | 1 |

每个容器的 finally 均执行 `podman rm --force --time 1 <exact-name>` 并读回
`podman container exists <exact-name>`；最后再次读回三个 exists，全部 exit 1、
空 stdout/stderr。Podman 客户端命令均 subprocess.run 有界并实际 reap。
没有新建 Podman network/image/volume，没有拉取或安装软件，没有运行 tc 或
修改宿主/任何容器 qdisc。NET_ADMIN 只是请求参数，不冒称实际验证过内核 netem
能力；由于现有工具不足，本批 **IP netem / IP loss = HOLD / NOT_TESTED**。
没有保留自有运行容器、进程或私钥；共享镜像与其他任务容器保留。
