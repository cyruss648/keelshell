# NET-03 SSH path comparison transport author handoff

Date: 2026-11-16 (Asia/Shanghai).
Baseline: `162d883460a98cd03056731fd8d4be76a41d5c15`.
Status: **READY_FOR_PARENT_INTEGRATION / NOT_COMPILED**.

The requested public API is retained, including `PathComparisonReport::summary`.
No Cargo commands, commits or pushes were performed. No Cargo target was touched.
No Cargo/lock/app/core/docs/scripts files were modified. Parent owns all subsequent
compilation, fixes, full gates, OpenSSH experiments and native acceptance.

## Complete source handoff (nine files)

All paths below are relative to this managed worktree. Copy every file, including
new/untracked files: `git diff` alone omits those files.

- `crates/keelshell-session/src/ssh.rs`
- `crates/keelshell-session/src/ssh/connection_info.rs`
- `crates/keelshell-session/src/path_comparison.rs`
- `crates/keelshell-session/src/path_comparison/transport.rs`
- `crates/keelshell-session/src/path_comparison/tests.rs`
- `crates/keelshell-session/src/lib.rs`
- `crates/keelshell-session/tests/ssh_loopback.rs`
- `crates/keelshell-session/tests/fixtures/path_comparison.rs`
- `crates/keelshell-session/tests/fixtures/upstream_proxy.rs`

`ssh.rs` includes `#[path = "path_comparison/transport.rs"]` as its private
`path_comparison_transport` module. This is deliberately an SSH child so it can
reuse the existing private `open_session_until` / `PendingChannel` owner. Do not
move the module into the public path_comparison module without adapting privacy.
`ssh_loopback.rs` registers the new fixture module. `upstream_proxy.rs` changes
only its fixture module visibility to `pub(super)` for reuse of the real proxy.

## Behavior and production boundaries

- Identity is constructed only after successful authentication. Missing/changed
  pins fail in `Client::check_server_key` before authentication; the immutable
  snapshot retains that accepted pin. Actual recursive jump snapshots come from
  `connect_through`'s live parent; direct connections have no jump. Proxy snapshots
  contain only validated kind/host/port, never credentials/userinfo. Review values
  are quoted/escaped. Distinct direct/proxied routes count as different routes.
- Eligibility rejects one connection and its clones, differing host/port/user/key,
  identical actual routes, and locally closed/closing connections. The plan owns
  exact A/B sessions; matches_sessions preserves their original order.
- Three rounds, each Exec/Upload/Download with A/B, B/A, A/B order. Eighteen
  successful samples transfer exactly 3 MiB of synthetic payload. The runner
  stops on its first unsuccessful sample. No absent rows or medians are invented.
- Every command contains the harmless `# KEELSHELL_PATH_PROBE` marker and uses
  `python3 -I -S -B -c` with a fixed pure-memory script and an eight-second POSIX
  alarm. `-B` prevents bytecode-cache writes. No files, PTY, sudo or subprocesses.
  No retries, profile lookup, AI, telemetry, persistence or automatic switching.
- A 60-second absolute comparison deadline and an eight-second absolute sample
  deadline include channel open, dispatch/acknowledgement, startup and completion.
  Cancellation is checked before open, after open/before EXEC, in flight and
  before adoption. A never-polled cancelled open does not start a request.
- stdin and output are concurrent. Upload input uses a fixed 16 KiB chunk; output
  is checked incrementally without a growing capture buffer. Its own combined
  output cap is 256 KiB + 128 bytes, independent of archive/diagnostic constants.
  Upload byte counts attest writer admission, not remote receipt; download counts
  are observed payload capped at 256 KiB. Failed rows retain partial counts.
- Passing requires positive exec ACK, exact stdout, no extended output/stderr,
  complete stdin/EOF send, output EOF, one explicit exit zero and peer CLOSE.
  Duplicate/out-of-order controls, excess/wrong/truncated bytes, missing status,
  nonzero exit, absent close, cancellation and timeout are fixed safe failures.
- A possibly queued EXEC is tracked before polling send. EOF + process termination
  + peer CLOSE can confirm remote completion even when output is invalid. Local
  CLOSE alone cannot clear uncertainty. Cancellation after unconfirmed dispatch,
  missing completion, unresolved open or cleanup timeout retains
  `cleanup_unconfirmed`. The parent UI must keep its revoke/reconnect policy.
- Normal cancellation/late-open cleanup closes only the owned channel. Existing
  exceptional owner policy is unchanged: an OPEN still unconfirmed at its
  deadline or a backpressured CLOSE can stop the affected shared SSH connection.
  This exceptional path is not proof of remote process cleanup; unknown remains
  unknown. This author did not change channel.rs or its broader transport policy.

## Added concrete Rust test names (not executed)

Fixture tests are in the existing `ssh_loopback` integration target. Protocol
malformation cases are grouped in one meaningful test rather than counted as
separate Rust tests. The local Python program test is `cfg(unix)`.

- `path_comparison::tests::summary_requires_complete_three_distinct_successful_rounds` (`crates/keelshell-session/src/path_comparison/tests.rs`)
- `path_comparison::tests::equal_and_zero_measured_durations_are_preserved_without_inventing_a_difference` (`crates/keelshell-session/src/path_comparison/tests.rs`)
- `path_comparison::tests::fixed_python_programs_exchange_exact_memory_samples_and_reject_extra_upload` (`crates/keelshell-session/src/path_comparison/tests.rs`)
- `path_comparison::comparison_seals_actual_recursive_hops_and_each_explicit_proxy_without_credentials` (`crates/keelshell-session/tests/fixtures/path_comparison.rs`)
- `path_comparison::comparison_eligibility_rejects_clones_same_route_and_every_endpoint_dimension` (`crates/keelshell-session/tests/fixtures/path_comparison.rs`)
- `path_comparison::comparison_strict_samples_follow_alternating_rounds_and_reviewed_commands` (`crates/keelshell-session/tests/fixtures/path_comparison.rs`)
- `path_comparison::comparison_malformed_ack_output_eof_exit_and_close_never_become_success` (`crates/keelshell-session/tests/fixtures/path_comparison.rs`)
- `path_comparison::comparison_precancelled_run_never_opens_channels` (`crates/keelshell-session/tests/fixtures/path_comparison.rs`)
- `path_comparison::comparison_cancelled_or_dropped_late_open_never_executes_and_preserves_jump_and_sibling` (`crates/keelshell-session/tests/fixtures/path_comparison.rs`)
- `path_comparison::comparison_cancelled_dispatched_probe_keeps_unknown_and_rejects_late_valid_result` (`crates/keelshell-session/tests/fixtures/path_comparison.rs`)
- `path_comparison::comparison_missing_close_hits_sample_deadline_and_retains_unconfirmed_cleanup` (`crates/keelshell-session/tests/fixtures/path_comparison.rs`)

Coverage includes actual recursive hop/proxy snapshots and secret exclusion;
clone/same-route/all four endpoint dimensions and proxy-only routing; exact
sample bytes/order/review-dispatch agreement; ack/stdout/stderr/EOF/exit/close
failures; a 3 MiB output flood during window-limited upload; precancellation;
late OPEN after cancellation or dropped future with zero EXEC and surviving
parent/sibling connections; cancellation before ACK and before late valid output;
and missing CLOSE deadline with explicit cleanup uncertainty. Duration assertions
never claim one path is faster. Summary tests reject partial, failed, duplicate,
wrong-round and unknown results and preserve real equal/zero measured durations.

## Checks actually performed

- Direct `rustfmt --edition 2024 --config skip_children=true` on all nine files:
  exit 0. No Cargo invocation.
- Recursive `rustfmt --check --edition 2024` on ssh.rs, path_comparison.rs and the
  new protocol fixture: exit 0; this also resolves the private transport path.
- `git diff --check`: exit 0.
- Python syntax and local execution of commands extracted from the Rust source:
  Exec exit 0 / exact 23 stdout bytes; Upload exit 0 / exact 32 acknowledgement
  bytes after 262144 input bytes; Download exit 0 / exact 262144 payload bytes;
  Upload with one extra byte exit 65 / empty stdout. All four had empty stderr.
  These are fixed-program checks, not Rust or SSH/OpenSSH/native acceptance.
- Rust compilation, Clippy, Rust test execution and native execution: NOT_RUN.
  The parent may repair compilation and remaining edge cases centrally.

## Frozen source SHA-256

- `9e811abd68ae834570a715b1c6b093df123e1fb1620cb1f590bf4d12f2f1f440`  `crates/keelshell-session/src/ssh.rs`
- `f81594615208d4f1a68e61eda1c722272d27766c51cd56050235755988e486da`  `crates/keelshell-session/src/ssh/connection_info.rs`
- `188bcf0af35ad5f442c4baccfdb5b1e02c8ca0c42d50bab60486ce9784683efe`  `crates/keelshell-session/src/path_comparison.rs`
- `c59e61d6b43abd2719f14d9b02c28195634b7b3d85191068833aefd516b33862`  `crates/keelshell-session/src/path_comparison/transport.rs`
- `ced3bd0e99b940d2988805f961c996f23464ef8ca1548a842bce8e57c9741115`  `crates/keelshell-session/src/path_comparison/tests.rs`
- `17c70ec9586b17b4e794a0a2b66112a65d1472f50957924aaf684500f6957e34`  `crates/keelshell-session/src/lib.rs`
- `4d3cde316522cc7cf7a68a65def1af49a5d02ecc1bf43149c604b123a5548c05`  `crates/keelshell-session/tests/ssh_loopback.rs`
- `4cc51964128e4f8bd55a3ef5a4f6a21bc1dcddd01579e185f984ac2c74a72614`  `crates/keelshell-session/tests/fixtures/path_comparison.rs`
- `fb996380c3f4189e41ddf96b2237bba6c9d20af185c7ce60c48b39b2e7c31435`  `crates/keelshell-session/tests/fixtures/upstream_proxy.rs`

This ignored report is an additional handoff file: `work/path-transport-author.md`.
