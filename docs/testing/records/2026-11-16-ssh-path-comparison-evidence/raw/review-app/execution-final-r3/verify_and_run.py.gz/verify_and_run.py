"""Read frozen inputs and independently run only the authorized stable test copy."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time

ROOT = Path("/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell")
WORK = ROOT / "work/ssh-path-comparison-20261116"
OUT = Path(__file__).resolve().parent
FREEZE = WORK / "frozen-inputs-r3.json"
BINARY = WORK / "bins-r3/keelshell-app"
EXPECTED_AGGREGATE = "066d7835e75d09895ae7a97f5b83863904a8dcbb0419bb1d8e865f89b7a047e0"
EXPECTED_BINARY = "bdf047b9f8ecf1550da5a97e195389e1ef6ed8b019abe96f08a0b0f9db420883"
RECEIPT = {
    "started_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "cwd": str(ROOT),
    "provenance": "Parent prebuilt stable copy; no independent recompilation.",
    "cargo_commands": 0,
    "commands": [],
}


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n")


def check_inputs(frozen):
    mismatches = []
    for row in frozen["inputs"]:
        path = ROOT / row["path"]
        actual = digest(path) if path.is_file() else None
        if actual != row["sha256"]:
            mismatches.append(dict(row, actual_sha256=actual))
    return mismatches


def run(name, arguments, timeout):
    started = time.monotonic()
    timed_out = False
    with (OUT / (name + ".log")).open("xb") as log:
        process = subprocess.Popen(
            arguments, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        try:
            code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGTERM)
            try:
                code = process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                code = process.wait()
    row = {
        "name": name, "command": arguments, "cwd": str(ROOT),
        "timeout_seconds": timeout, "timed_out": timed_out,
        "exit": code, "reaped": True,
        "seconds": round(time.monotonic() - started, 3),
        "log_sha256": digest(OUT / (name + ".log")),
    }
    RECEIPT["commands"].append(row)
    save(name + ".json", row)
    if timed_out or code != 0:
        raise RuntimeError(f"{name}: exit={code}, timed_out={timed_out}")
    return (OUT / (name + ".log")).read_text()


try:
    frozen = json.loads(FREEZE.read_text())
    freeze_sha = digest(FREEZE)
    aggregate = hashlib.sha256(
        "".join(row["path"] + "\0" + row["sha256"] + "\n"
                for row in frozen["inputs"]).encode()
    ).hexdigest()
    before = check_inputs(frozen)
    RECEIPT["freeze"] = {
        "path": str(FREEZE), "manifest_sha256": freeze_sha,
        "baseline": frozen["baseline"], "declared_count": frozen["count"],
        "actual_count": len(frozen["inputs"]),
        "declared_aggregate": frozen["aggregate_sha256"],
        "recomputed_aggregate": aggregate,
        "before_mismatches": before,
    }
    assert len(frozen["inputs"]) == frozen["count"] == 669
    assert aggregate == frozen["aggregate_sha256"] == EXPECTED_AGGREGATE
    assert not before, before
    old = json.loads((WORK / "frozen-inputs-r2.json").read_text())
    old_rows = {row["path"]: row["sha256"] for row in old["inputs"]}
    new_rows = {row["path"]: row["sha256"] for row in frozen["inputs"]}
    delta = {
        "modified": sorted(path for path in old_rows.keys() & new_rows.keys()
                           if old_rows[path] != new_rows[path]),
        "added": sorted(new_rows.keys() - old_rows.keys()),
        "removed": sorted(old_rows.keys() - new_rows.keys()),
        "unchanged": sum(old_rows[path] == new_rows[path]
                         for path in old_rows.keys() & new_rows.keys()),
    }
    declared = json.loads((WORK / "freeze-delta-r2-r3.json").read_text())
    assert sorted(delta["modified"] + delta["added"]) == sorted(declared["changed"])
    assert delta["removed"] == declared["removed"] == []
    assert delta["unchanged"] == declared["unchanged"] == 663
    RECEIPT["delta"] = delta
    rows = json.loads((WORK / "binaries-r3.json").read_text())
    app = next(row for row in rows if row["target"] == "keelshell-app")
    assert Path(app["path"]) == BINARY
    actual_binary = digest(BINARY)
    assert actual_binary == app["sha256"] == EXPECTED_BINARY
    assert BINARY.stat().st_size == app["bytes"]
    RECEIPT["binary"] = {
        "path": str(BINARY), "before_sha256": actual_binary,
        "bytes": BINARY.stat().st_size, "parent_metadata": app,
    }
    source_tests = []
    source_base = ROOT / "crates/keelshell-app/src/monitor_tests"
    for file, prefix in [
        ("path_comparison.rs", "monitor::path_comparison::tests::"),
        ("path_comparison_localization.rs", "monitor::path_comparison::tests::localization::"),
    ]:
        names = re.findall(
            r"#\[gpui_kit::test\]\s*(?:async\s+)?fn\s+(\w+)",
            (source_base / file).read_text(),
        )
        source_tests.extend(prefix + name for name in names)
    assert len(source_tests) == len(set(source_tests)) == 11
    save("pre-execution-audit.json", RECEIPT)
    inventory = run("inventory", [str(BINARY), "--list"], 30)
    named = re.findall(r"^(.+): test$", inventory, flags=re.MULTILINE)
    selected = sorted(name for name in named if "path_comparison" in name)
    assert len(named) == len(set(named)) == app["named_tests"] == 1271
    assert selected == sorted(source_tests), (selected, source_tests)
    expected_inventory = WORK / "bins-r3/keelshell-app-inventory.txt"
    assert inventory.encode() == expected_inventory.read_bytes()
    RECEIPT["inventory"] = {
        "named_tests": len(named), "selected_count": len(selected),
        "selected_names": selected, "source_names": sorted(source_tests),
        "matches_parent_inventory_byte_for_byte": True,
        "parent_inventory_sha256": digest(expected_inventory),
    }
    result = run(
        "path-comparison",
        [str(BINARY), "path_comparison", "--test-threads=1"],
        120,
    )
    passed = sorted(re.findall(r"^test (\S+) \.\.\. ok$", result, flags=re.MULTILINE))
    assert passed == selected, (passed, selected)
    assert "11 passed; 0 failed; 0 ignored;" in result
    after = check_inputs(frozen)
    RECEIPT["freeze"]["after_mismatches"] = after
    RECEIPT["freeze"]["manifest_unchanged"] = digest(FREEZE) == freeze_sha
    RECEIPT["binary"]["after_sha256"] = digest(BINARY)
    assert not after, after
    assert RECEIPT["freeze"]["manifest_unchanged"]
    assert RECEIPT["binary"]["after_sha256"] == EXPECTED_BINARY
    RECEIPT["tests"] = {
        "passed": 11, "failed": 0, "ignored": 0,
        "filtered_out": 1260, "passed_names": passed,
    }
    RECEIPT["status"] = "PASS"
except Exception as error:
    RECEIPT["status"] = "FAIL"
    RECEIPT["error"] = f"{type(error).__name__}: {error}"
finally:
    RECEIPT["finished_at"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save("verification.json", RECEIPT)
    print(json.dumps({
        "status": RECEIPT["status"],
        "error": RECEIPT.get("error"),
        "commands": RECEIPT["commands"],
        "tests": RECEIPT.get("tests"),
        "evidence": str(OUT / "verification.json"),
    }, indent=2), flush=True)
raise SystemExit(0 if RECEIPT["status"] == "PASS" else 1)
