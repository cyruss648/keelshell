# P2-003：新增 painted 测试阻塞 app 测试编译

状态：OPEN / OBSERVED_PARENT_BUILD_FAILURE。这是读取父方集中构建原件，
不是 reviewer 独立重编译或测试执行。

父方 `../focused-build-r2.json` 已记录真实终态：

- 命令：`cargo test -p keelshell-session -p keelshell-app --locked --no-run --message-format=json`
- `exit 101 / 7.52s / timed_out=false / reaped=true`

`../focused-build-r2.log` 的 app 编译器错误明确为：

```text
error: recursion limit reached while expanding `#[test]`
  --> crates/keelshell-app/src/monitor_tests/path_comparison_localization.rs:14:1
14 | #[gpui_kit::test]
```

触发：编译新增第 11 项 painted 测试。当前 app test target 编译失败，因此不能
获得这项测试以及整合 app 的完整库存或执行证据；它尚不能用于关闭原呈现发现。
记录时新文件仍为相同 `#[gpui_kit::test]` 及 `use super::*` 结构，
SHA256 为 `17f50b435755b284c4306d10cb4ed5699ca797ed435605e413e09da642702b81`。

修复建议：检查该嵌套测试模块的属性宏名称解析/导入及宏展开，先取得成功的
当前输入 no-run 和逐名库存，再实际执行第 11 项。这里不把编译器建议提高
recursion_limit 当作已经证明的正确修复，也没有修改源码或 Cargo。

同一次构建还有 session proxy fixture 的八项 privacy 错误，它们属于另一位
reviewer 的范围，本 notice 不将其计入本 app 发现。旧失败原件保留；
后续成功构建使用新编号，不能改签本次退出事实。
