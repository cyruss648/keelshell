# P3-002：结果区缺少相同耗时提示和约定的实测差异

状态：OPEN，源码复核发现；尚未编译或执行 Rust 测试。绑定 app 初始冻结
`inputs-r1.json`；生产 app 输入核验未变。

位置：`crates/keelshell-app/src/monitor_path_comparison.rs:526`–`:551`。
该循环在两个 `summary` 都为 `Some` 时只显示 A、B 中位数；没有相等分支、
差值或不足以比较的说明。`summary` 缺失时则完全省略对应操作。
同文件 `:294`–`:296` 的完成状态仅说明 18 个样本完成，不补充可比较性判断。

触发与确定性证据：现有 `monitor_tests/path_comparison.rs:337`–`:366` 的
`report(Complete)` 已构造全部 18 项成功样本，所有耗时均为 20ms。
session 的 `PathComparisonReport::summary`（父树
`crates/keelshell-session/src/path_comparison.rs:215`–`:239`）对 A、B 都会
返回 20ms；上述 UI 路径因此只生成两个相同数值，完全没有“数据不足”或
“无法判断差异”的明确说明。对普通不等的中位数也没有约定的有符号实测差异。
这是既有 fixture 能触发的呈现遗漏，不声称真实 SSH 已测得相同耗时。

影响：没有实现 `docs/adr/0141-reviewed-ssh-path-comparison.md:42`–`:44`
要求的“中位数及实测差异”和“相同耗时或不足以比较时明确显示数据不足”。
没有发现补零、自动选路或虚假加速结论；本项仅限结果语义缺失。

建议：显示有方向的实测差值，并对相等、零值或缺少可比较摘要的情形给出明确的
双语不足提示；继续保留实际中位数与原始样本。用现有相同 20ms 报告和一个不等
报告断言结果文字，不能只断言列表高度或完成状态。

证据边界：源码与现有测试数据分析；Rust 实际执行数为 0。修复后需由当前冻结的
预构建 GPUI binary 执行风险专项，并保留未独立重编译限制。
