**原生路径比较与双连接授权 app 最终复核 r3：APPROVE（本范围），整体合入有条件。**

本 reviewer 为非作者。完成本批 app 源码/测试有效性复核，并独立核验最终冻结、
父方稳定 binary 和完整库存，实际执行全部 11 项 `path_comparison` 测试通过。
累计三项 finding 均已关闭，没有新增有证据的问题。整体合入仍需父方完整门禁
对同一最终输入给出 exit 0 / reaped，并满足 session reviewer 的结论；
本报告不授权完整工程或三平台原生验收通过。

| Severity | 当前开放 | 本批累计关闭 |
| --- | ---: | ---: |
| P0 | 0 | 0 |
| P1 | 0 | 0 |
| P2 | 0 | 2 |
| P3 | 0 | 1 |

**范围、依据与只读合同。** 主树为
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`，
基线 `162d883460a98cd03056731fd8d4be76a41d5c15`。只评本批相对该基线的 app
差分；session API 仅沿 app 授权、身份及呈现调用边界读取，不代签 session 实现。
已读 AGENTS、RTK、当前 HANDOFF、ADR0141、STRATEGY、SHARED_TARGET 和
HALLMARK_NATIVE，并应用 rust-best-practices / rust-engineer 两技能。
全程未修改源码、格式、Cargo、lock、Git 或共享 target；没有 commit/push、
创建 chat、agent 或 worktree。自有写入仅为 review-app 下的 notice、report 与执行证据。

最终 app 复核范围共九个文件：

- [monitor_path_comparison.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_path_comparison.rs)。
- [monitor.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor.rs) 与
  [monitor_protocol.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_protocol.rs) 的新增桥接。
- [workspace/path_comparison.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/workspace/path_comparison.rs)、
  [workspace.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/workspace.rs) 与
  [reconnect.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/workspace/reconnect.rs) 的钩子。
- [monitor_tests/path_comparison.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_tests/path_comparison.rs)、
  [path_comparison_localization.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_tests/path_comparison_localization.rs) 与
  [workspace/tests/protocol_diagnostics.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/workspace/tests/protocol_diagnostics.rs) 的新增 helper。

初始冻结后的第 10 项测试、已告知修复及 cargo fmt 均按父方说明跟踪，未误报为未知漂移。
旧源码快照、差分、notice 和失败构建证据保留在 execution-r1/r2/r3 与阶段报告中。

**最终输入与产物绑定。** 以
[frozen-inputs-r3.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/frozen-inputs-r3.json)
标识未提交的最终源码。独立检查全部 669 项输入，按 manifest 顺序用
`path + NUL + sha256 + LF` 重算 aggregate；执行前后无不匹配项，manifest 本身未变。
该检查证明输入完整性，不表示对全部 669 项进行了逻辑复核。

| 项目 | 独立核验值 |
| --- | --- |
| 输入数量 | 669 |
| Aggregate SHA256 | `066d7835e75d09895ae7a97f5b83863904a8dcbb0419bb1d8e865f89b7a047e0` |
| Manifest 文件 SHA256 | `fd1aab536ba4c8463a76e16b4fde3c62be7c0400342014f4b41b72e3202071e7` |
| r2→r3 | 5 修改、1 新增、0 删除、663 不变，与 freeze-delta-r2-r3.json 一致 |
| 稳定 binary | `work/ssh-path-comparison-20261116/bins-r3/keelshell-app` |
| Binary SHA256，执行前后相同 | `bdf047b9f8ecf1550da5a97e195389e1ef6ed8b019abe96f08a0b0f9db420883` |
| Binary 大小 | 269397024 bytes |
| 独立完整库存 | 1271 个唯一测试，与父库存逐字节一致 |
| `path_comparison` 库存 | 11 项，逐名与当前源码定义一致 |

稳定副本与
[binaries-r3.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/binaries-r3.json)
相符。构建来源依赖父方同一 checkout 的集中编译证据；本 reviewer 没有独立重编译，
也未访问或切换共享 target。哈希及库存核验没有扩大为对独立构建的声明。

**实际执行。** 本 reviewer 直接执行稳定副本两次：一次库存、一次专项。
没有执行全部 1271 项；真正执行的 Rust 测试为 **11 passed / 0 failed / 0 ignored /
1260 filtered**。GPUI 测试中的主题、语言、状态或精度循环不另计测试数。

```text
/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/bins-r3/keelshell-app --list
/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/bins-r3/keelshell-app path_comparison --test-threads=1
```

| 命令 | 上限 | 实际终态 |
| --- | ---: | --- |
| `--list` | 30s | exit 0 / reaped / 未超时 / 0.019s |
| `path_comparison --test-threads=1` | 120s | exit 0 / reaped / 未超时 / 2.174s；libtest 内部报告 2.16s |

执行驱动实际命令为
`python3 work/ssh-path-comparison-20261116/review-app/execution-final-r3/verify_and_run.py`，
exit 0；工作目录为上述主树。驱动保存前后文件/manifest/binary 核验、
库存对照及逐名 passed 校验，见
[verify_and_run.py](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/review-app/execution-final-r3/verify_and_run.py)
及
[verification.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/review-app/execution-final-r3/verification.json)。
原始
[inventory.log](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/review-app/execution-final-r3/inventory.log)
SHA256 为 `c9273ba02d7c5a23ca38b97f15c842d5a4c7b5bcca85350071857da1003f6843`；
[path-comparison.log](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/review-app/execution-final-r3/path-comparison.log)
SHA256 为 `90dd2cff9d4d24e49b2801a4c5446b1e4dab89b16a685267c4e366ad6dd5992c`。
本次复核累计 Cargo / Clippy / rustfmt 执行数均为 **0**。

以下 11 个名称均实际执行为 ok；名称前缀为
`monitor::path_comparison::tests::`，首项另含 `localization::`：

| 测试名 | 生产边界与证据含义 |
| --- | --- |
| `path_comparison_localizes_painted_review_failures_and_observed_differences` | 实际 render/paint 的双语审核、精确命令、OutputLimit 与差值字面期望；报告输入明确为合成。 |
| `path_comparison_candidate_retirement_revokes_review_synchronously` | 候选 retirement 同步撤销。 |
| `path_comparison_closing_inactive_candidate_revokes_review_without_selecting_it` | 实际关闭 inactive candidate，不先选中它。 |
| `path_comparison_late_result_rechecks_second_transport_before_adoption` | reply 采用时重查第二连接 authority；直接向 finish 注入报告。 |
| `path_comparison_minimum_workspace_can_reach_review_and_result_controls` | 实际 900×580 Workspace、monitor-scroll、确认可达与结果列表有界。 |
| `path_comparison_preview_is_local_and_aba_requires_new_review` | 真实连接的本地 preview 零 probe；实际 Workspace A→B→A 后重新审核。 |
| `path_comparison_running_cancel_owns_worker_and_discards_revoked_reply` | 经生产 confirm 启动 worker，真实 SSH fixture 观测 EXEC 后撤销；核对 worker owner、迟到丢弃与原会话存活。 |
| `path_comparison_second_route_change_blocks_confirm_before_retirement_poll` | 保存路线/信任等候选 authority 变化后，确认不依赖后续 retirement poll。 |
| `path_comparison_stale_result_never_resurrects_after_selection_aba` | A→B→A 的迟到合成结果不能恢复已撤销授权。 |
| `path_comparison_three_themes_keep_review_actions_outside_scrolling_body` | 三主题家族 × Light/Dark × 中英文的实际组件几何、正文滚动与固定动作。 |
| `path_comparison_unknown_completion_disables_next_run_and_keeps_raw_samples` | 注入未知完成报告，保留原始样本并禁止再次比较。 |

**三项 finding 的最终关闭依据。**

**P2-001 CLOSED。** 原问题为中文界面完整审核说明与具体失败仍使用英文。
[ResultSource](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_path_comparison.rs:28)
现在只持有两个无凭据 `SshConnectionInfo`；完成来源不保留 plan/session。
[failure_text](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_path_comparison.rs:375)
对当前 18 类 typed failure 穷尽双语映射；
[review_text](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_path_comparison.rs:467)
从真实不可变连接元数据递归展示完整路径，并提供双语轮次、载荷、预算、
工具前提、计时、取消及未知清理说明。命令直接来自 `PathProbeKind::command()`，
和传输共享原始字节。实际通过的 painted 测试在两语言下核验审核与完整命令，
并在
[字面失败断言](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_tests/path_comparison_localization.rs:74)
检查 OutputLimit。18 类映射为源码穷尽性核验，未声称逐类运行了 18 个失败场景。

**P3-002 CLOSED，包含 r2 精度阈值补充。** 原问题为缺少有符号实测差异、
相等/不足状态；中途修复遗留 `<0.005ms` 的阈值不一致。
[difference_text](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_path_comparison.rs:423)
先处理零值/相等，再以 `a.abs_diff(b) < Duration::from_micros(10)` 判定不足，
仅显示时转换浮点，符号固定为 B−A；没有给不足结果宣称赢家。
实际 painted 测试使用独立字面期望覆盖双语 equal、
[±9µs 与 ±10µs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_tests/path_comparison_localization.rs:99)
和
[−10ms](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_tests/path_comparison_localization.rs:145)：
±9µs 显示不足，+10µs 为 `B − A: +0.01 ms`，−10µs 为
`B − A: -0.01 ms`，−10ms 为 `B − A: -10.00 ms`。
不再调用生产 helper 生成预期。零值及缺失摘要的处理已源码核验；
本次 painted 测试没有单独注入零值，不将其写作已执行零值用例。

**P2-003 CLOSED。** 原问题有父方 r2 的真实编译失败回执：
exit 101 / reaped / 7.52s，属性宏递归展开阻止新 painted 测试生成。
修复后的
[测试模块导入](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_tests/path_comparison.rs:4)
改为显式导入。最终稳定 binary 具有完整且一致的库存，新增测试已由本 reviewer
实际执行成功，因此关闭该阻塞。没有通过提高 recursion_limit 掩盖原问题，
没有改写旧失败终态，也没有把父方构建冒称 reviewer 构建。

**授权、生命周期与 UI 复核结论。** 沿本批生产调用链没有发现额外授权缺陷。
候选资格通过真实 live session 与不可变 endpoint/path 元数据交由
`PathComparisonPlan::new` 判断，拒绝同一实际连接和不可比端点/路径。
测试 Harness 分别 `connect` 与 `connect_through` 建立两个已认证目标连接，
并非同一连接的两份 clone。

审核绑定当前 base tab/pane selection revision 与候选 session，确认和 reply
采用均重新核对保存路线、信任/配置 authority 及会话身份。Workspace 的同步
选择撤销保证 A→B→A 不能恢复旧授权；关闭 inactive candidate、关闭 base 与重连
均有失效钩子。相应 app 测试实际触达生产控制器和 Workspace helper，
未将仅比较两个模型值当作生产边界测试。真实 trust/reconnect 网络过程仍未由本
reviewer 单独执行。

执行在 owned transport worker 上运行，窗口 owner 注册包含比较子面板；
UI 侧本地校验、非阻塞接收与异步轮询未见新增阻塞文件/网络 I/O。
撤销/drop 发出取消；迟到结果仍检查 authority，清理未知会保留样本并禁用继续比较。
源码和测试没有把线程退出或发送 CLOSE 当作远端进程退出确认。
finish/adoption/unknown 的合成报告仅证明 UI 采用与保留边界；
真实 worker 取消测试也不等于完整 18 个成功样本或远端进程清理验收。

视图使用 Palette/Kit/token，没有发现本批新增字面颜色、字体或主题 ID 分支。
三主题双语几何和最小 Workspace 专项均通过。新增文本 observer 使用与 renderer
相同的 SharedString，经实际 paint 收集；它有助于验证用户会看到的文本。
这些仍是 headless GPUI 组件检查，不能替代正常程序、系统窗口、AX、键盘、
IME 或屏幕阅读器验收。

**父方证据与明确限制。** 已读取
[focused-tests-r3.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/focused-tests-r3.json)
及专项日志：父方 exit 0 / reaped / 33.558s，app 11/11、
session lib 4/4、SSH loopback 11/11；普通命令中的可选 interop 三项 ignored。
这些是父方测试，未加到 reviewer 的 11 项执行数中。父方所报真实 lab 三场景、
session wire/协议专项由对应范围负责，本 app 报告不签独立实验或 session 通过。

报告落笔时未见 full-gate-r1.json 终态回执，本 reviewer 没有运行、等待完成或签署
完整门禁。严格只读约束下未重编译、未执行 Cargo/Clippy/rustfmt，也未启动正常 GUI
或开展 macOS/Windows/Linux 原生验收。保留这些验收边界不增加虚构 finding。
**最终建议：批准本批 app 源码及预构建专项复核；整体合入等待父方同一最终输入的
完整门禁 exit 0 / reaped 和其余 reviewer 结论。若最终输入再变更，需要重新绑定差分
及相关执行证据。**
