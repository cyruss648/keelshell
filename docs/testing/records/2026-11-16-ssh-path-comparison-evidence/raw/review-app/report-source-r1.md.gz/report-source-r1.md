# 原生路径比较与双连接授权：源码阶段复核 r1

结论：**REQUEST_CHANGES / EXECUTION_PENDING**。开放问题为 P0=0、P1=0、
P2=1、P3=1，已分别写入本目录 notice。没有发现本范围内有证据的双连接、
选择撤销或迟到结果授权缺陷。本报告不授予工程门禁、原生桌面或完整功能通过。

## 身份、范围与只读边界

新非作者 reviewer；主树为
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`。
只复核本批相对基线 `162d883460a98cd03056731fd8d4be76a41d5c15` 的 app 差分，
未编辑源代码、格式、Cargo、lock、Git 状态或共享 target，没有提交、推送、
创建 chat/agent/worktree。写入限本目录的 notice、report 和自有执行证据。

已读取 AGENTS、HANDOFF 的当前交接、ADR 0141、STRATEGY、SHARED_TARGET 和
HALLMARK_NATIVE，并应用 rust-best-practices 与 rust-engineer 两项技能。
技能中的修改、Cargo 或完整测试建议服从本次严格只读及集中编译约束。

初始 app 冻结 `inputs-r1.json` 的 298 项全部一致；HEAD 等于基线。
整合冻结 `../frozen-inputs-r1.json` 的 667 项也逐项与当前文件一致，
并独立按逐行 `path + NUL + sha256 + LF` 重算集合摘要：

`2035dc03867a9281c9ccd7be98289f62b29603a1815cbf23e34e16bb6fd4e0aa`

初始 app 冻结后仅测试文件变化，与用户告知的第 10 项测试及格式化一致；
其余 297 项初始 app 输入未变。整合 manifest 自身 SHA256 为
`b7b67711f4eefbc5f4f56e6f8aefc2e09a714a9009681c0f7191a3f01a2631ea`。
冻结、差分与哈希原件见 `execution-r1/`。

复核的八个 app 文件：

- `monitor_path_comparison.rs`、`workspace/path_comparison.rs`、
  `monitor_tests/path_comparison.rs` 三个新增文件。
- `monitor.rs`、`monitor_protocol.rs`、`workspace.rs`、
  `workspace/reconnect.rs` 及 `workspace/tests/protocol_diagnostics.rs` 的本批差分。

session 的 eligibility、不可变身份、review/summary API 仅为 app 调用边界读取，
不代替另一个 reviewer 的传输实现复核。历史代码仅沿本批调用链读取。

## 开放发现

1. **P2-001：中文审核正文与具体失败原因没有本地化。**
   `monitor_path_comparison.rs:478` 直接展示英文 `review_text()`，
   `:244`/`:615` 缓存并重放同一英文说明，`:588`–`:589` 直接插入
   英文 typed failure 的 Display。中文语言下无法获得完整中文审核限制或
   具体失败说明。命令原文及端点无需翻译。见
   `notice-P2-001-localized-review.md`。
2. **P3-002：结果区缺少 ADR 约定的实测差异和相同耗时提示。**
   `monitor_path_comparison.rs:526`–`:551` 只列 A/B 中位数。
   现有 Complete fixture 的全部耗时都是 20ms，但没有相等/不足说明；
   不等报告也没有实测差值。未发现补零、自动选路或虚假加速结论。
   见 `notice-P3-002-comparison-result-states.md`。

两项都是源码可确定的呈现遗漏；尚未将其描述为已执行失败或原生观察。
现有双语/结果几何测试没有断言这些语义，因此不能用其预期通过关闭发现。

## 已追踪的生产边界

- 候选通过 `PathComparisonPlan::new` 依据真实连接和不可变身份筛选，
  不用可编辑 profile 的 host 字段代替已连接端点。已导入 API 明确拒绝
  `same_connection`、不同端点/密钥、相同实际路径及非 live 连接。
  app fixture 分别通过 `connect` 与 `connect_through` 取得两个目标连接，
  不是一个连接的两份 clone。
- 基础 tab/pane 使用当前 `protocol_selection_token`；审核同时保留候选
  tab、真实 session 和 selection UUID。confirm 重新核对候选当前 authority、
  plan 的 A/B session 顺序及当前选择；finish 再核对 request/selection。
- tab/pane 选择变化同步撤销所有相关面板，A→B→A 生成新 token。
  关闭 inactive candidate 在移除映射的同一前台回合调用候选撤销；
  关闭 base 先 suspend 后保留面板所有者。重连先 suspend/remove 旧会话，
  再撤销其他面板对该候选的授权。
- 保存路线、信任和配置 epoch 均沿 `protocol_session_current` 检查；
  preview/confirm/reply 不依赖稍后的 retirement poll 才拒绝已变 authority。
  本批未另行执行真实 trust/reconnect 场景。
- 网络执行在具名 owned transport worker 内 `runtime.block_on(plan.run(...))`；
  UI 侧只做本地身份判断、非阻塞接收和 20ms 异步轮询。没有在新增 UI
  回调发现文件/网络 I/O、阻塞 recv 或等待 join。
- worker 使用比较子面板 entity owner，monitor 的 window owner 列表由一个
  扩为两个。撤销/drop 设置取消标志；结果缺失或 cleanup_unconfirmed 会
  禁止本面板再次比较，即使是迟到结果。busy 解除后允许释放/重连与现有
  新测试的显式合同一致；未把 worker 线程结束解释为远端清理已确认。
- 新视图使用 Palette、Kit 控件及组件圆角 token，没有新增 theme-ID
  业务分支、字面颜色或字体。160px 正文滚动与独立 actions 的源码存在；
  实际布局仍待当前 binary 验证。

## 测试有效性与实际执行

源码中有 **10 项新 GPUI 测试**，逐名库存保存在
`execution-r1/integrated-freeze-r1-audit.json`：

- 4 项授权/撤销控制器测试调用实际 Workspace 选择、retirement、关闭入口及
  生产 preview/confirm；候选路线和移除负例故意不先触发 poll。
- 2 项迟到测试直接向生产 `finish` 注入合成报告，验证采用边界；
  它们不证明真实 worker reply/协议成功。
- 1 项 unknown 测试向 `finish` 注入一项样本的未知报告，只证明 UI
  保留样本并禁止重跑；不证明远端进程回收。
- 1 项运行取消测试实际经 confirm 启动生产 worker，并等待真实 SSH fixture
  观察到 probe EXEC，再撤销和释放 fixture。它核对取消、丢弃与原会话存活；
  不把拒绝正常 probe 输出的 fixture 当作成功 18 样本验收。
- 1 项三主题 × 两明暗 × 双语检查将实际组件独立挂载，验证正文和动作几何。
  已告知的第 10 项则使用实际 900×580 Workspace 和 monitor-scroll 检查
  确认可达及结果列表高度；其报告是合成呈现数据。两项都不代签桌面/AX/键盘验收。

**本 reviewer 实际 Rust 测试执行数为 0；Cargo/rustfmt/Clippy 执行数均为 0。**
尚无作者预构建 binary 的独立执行。不能把上述源码 10 项写成 10/10 passed，
也不将参数循环或三主题组合额外计为 Rust tests。

实际只读命令包括 `pwd`、`rg`/`rg --files`、`cat`、`sed`、`nl`、
`wc`、`git rev-parse HEAD`、`git diff --no-ext-diff --no-textconv BASELINE -- APP_PATHS`、
`git show BASELINE:PATH` 和 `git worktree list --porcelain`；
Git 读取使用 `GIT_OPTIONAL_LOCKS=0`。三轮 Python 只读审计分别核对 298 项、
已告知的第 10 项增量及整合 667 项，输出仅写入本目录执行证据。
没有执行 Cargo 清理、target 归属切换或独立重编译。

另外读取到父方 `../focused-build-r1.json` 的真实终态为
`exit 101 / reaped / 4.044s`；其命令是
`cargo test -p keelshell-session -p keelshell-app --locked --no-run --message-format=json`。
日志只有一项 E0061，位于 session 旧 write_barrier fixture 的
`authenticate_stream` 调用缺少新增 jump 参数，app 测试尚未生成可用验收证据。
这是父方构建结果，且在另一个 reviewer 的 session 范围内，不另计本报告发现，
也未由本 reviewer 修改。

## 合入建议与后续条件

当前建议 **暂不合入**：先关闭上述两项呈现发现，再提供与最终冻结绑定的
成功工程门禁及 app binary/完整库存。收到后仅独立执行有意义的新增与风险专项，
披露使用父预构建、未独立重编译；复核修复的最终差分和本批具体测试名。
session、真实 OpenSSH、流延迟/限速实验、正常程序构建和三平台原生验收
保留各自证据边界。待补证据不构成新的虚构代码缺陷。
