# 修复差分源码复核 r2

结论：**REQUEST_CHANGES / EXECUTION_PENDING**。原 P2-001 已在源码层满足修复
要求，尚未签执行关闭；原 P3-002 仍有精度阈值遗漏。另观察到新 painted 测试
阻塞 app 编译，记为 P2-003。当前仍存在的问题为 P0=0、P1=0、P2=1、
P3=1；累计发现三项，其中一项 SOURCE_FIXED、两项 OPEN，完整执行关闭为零。

## 输入与严格只读

基线仍为 `162d883460a98cd03056731fd8d4be76a41d5c15`。本次按父方明确告知的
修复候选复核，尚未收到修复后的最终全仓冻结，不将这些已告知的修改记为未知漂移。
没有修改源码、格式、Cargo、lock、Git、共享 target；没有 commit/push，
也没有创建 chat、agent 或 worktree。新写入仅在本 review-app 目录。

与已核验的整合 r1 相比，采样时有四个既有工程文件改变：app 面板、app 原测试
模块、session path_comparison API 及 write_barrier 漏参修复；另新增
`monitor_tests/path_comparison_localization.rs`。本次仅读取必要的 session getter
和 SshConnectionInfo 类型，不代签 session 执行层。

源码快照、SHA256、相对 r1 的完整修复差分及 11 项测试名见
`execution-r2/repair-source-audit.json`。采样时：

- `monitor_path_comparison.rs`：`0574e50df546d9f67576051609b3e329fa9a1767b80599089d43f831ff9cadf9`
- `monitor_tests/path_comparison.rs`：`960098b88c21cc68e1f8334c649f027a492a6d6ab8d3299231105551f597566c`
- 新 localization 测试：`17f50b435755b284c4306d10cb4ed5699ca797ed435605e413e09da642702b81`

## P2-001：SOURCE_FIXED / EXECUTION_PENDING

源码已覆盖原发现的所有呈现入口：

- 生产审核调用 UI-owned `localized_review`；执行后的来源通过相同的
  `review_text` 按当前语言重新呈现，而非缓存英文。
- 完整路径遍历真实、递归的不可变 SshConnectionInfo，逐跳显示用户、主机、
  端口、已核验密钥和显式代理。字符串用 Debug 引号/转义保留值边界，
  不从 profile 重建真实路径。
- 轮次/先后顺序、载荷和额外开销、八秒/六十秒预算、POSIX/Python 3 前提、
  无文件/PTY/提权、计时含义、失败停止和 unknown/reconnect 限制均有中英文。
- 固定命令直接调用 public `PathProbeKind::command()`；与传输使用同一
  返回值，没有复制或翻译命令常量。
- `failure_text` 对当前 18 个 typed failure 做穷尽的双语映射，没有通配符
  或直接插入英文 Display 的残留。
- `ResultSource` 只有 `[SshConnectionInfo; 2]`。该类型及递归 jump 的字段均为
  端点、指纹、代理种类/端点等无凭据元数据，没有 session 或认证内容。
  完成来源不持有 plan；失效时清除来源。没有扩大确认或执行权限。

本状态只是源码复查通过，尚无 successful binary 或 reviewer 运行回执。
原 notice 与 r1 报告保持原件，不改写为已运行通过。

## P3-002：部分修复，仍 OPEN

结果区已增加有符号 B−A、相等/零值的不足提示，以及缺失摘要的显式数据不足。
仍有 `monitor_path_comparison.rs:434` 使用 `< 0.005ms`，而说明与用户明确要求
都是 `< 0.01ms`。A=20ms、B=20.009ms 会显示 +0.01ms，未进入不足状态。
补充证据、精确触发及整数 10µs 边界建议见
`notice-P3-002-source-r2-precision.md`。这是原发现的剩余部分，不重复计数。

## P2-003：新增测试编译阻塞

读取父方集中构建原件，`focused-build-r2` 实际为
`exit 101 / 7.52s / timed_out=false / reaped=true`，app 的确定错误是
`path_comparison_localization.rs:14` 的属性宏展开达到 recursion limit。
它阻止本次 app test target 生成有效库存/运行证据。
详见 `notice-P2-003-painted-test-build.md`；原始日志/receipt 摘要与诊断提取见
`execution-r2/parent-build-r2-observation.json`。

同次八项 session proxy fixture privacy 错误保留在父日志，不计入本范围。
这不是 reviewer 的独立构建，也没有擅自采用提高 recursion_limit 的建议。

## 第 11 项测试的源码有效性

新增模块通过现有 tests 模块明确注册，仍是一个实际 Rust 测试，而不是把双语
或多个报告状态重复计数。它使用真实连接 Harness 及生产组件的 render，通过
`gpui_kit::base::test_support::texts` 读取实际绘制文本，并在两个语言下：

- 独立断言审核的具体限制/已核验密钥，核对三个完整命令字节均存在。
- 注入明确标为合成的 OutputLimit/Complete 结果，检查原始失败呈现、
  相等提示与 `B − A: -10.00 ms`；全程断言零 probe EXEC。

这确实穿过生产呈现边界，但属于 headless 组件检查，不是协议或桌面验收。
失败和相等文字的期望目前分别再调用生产 `failure_text`/`difference_text`，
可以验证接线，却不能独立防止 helper 本身的错误翻译或提示回归。
精度边界的补测应使用明确字面期望；该建议已随原 P3 的补充 notice 给出。
没有把它扩成新的独立测试缺陷发现。

**本 reviewer 累计执行 Rust 测试 0 项；Cargo/Clippy/rustfmt 命令仍均为 0。**
源码库存由 10 增至 11，不代表 11/11 passed。
本次实际使用 `rg`、`sed`、`nl`、`wc`、`cat` 及两次 Python 证据审计；
一轮保存源码/差分/哈希/测试名，一轮只读提取父构建错误。
自有写入只在 execution-r2 和 notice/report 中。

当前建议继续暂不合入。先修复精度阈值和 app 编译阻塞，取得新冻结与
成功构建的 binary/完整库存，再由 reviewer 独立执行有意义专项。原 P2
需要运行证据后才签完整关闭；完整工程门禁、真实 OpenSSH/网络实验、
正常程序与三平台原生仍分别验收。
