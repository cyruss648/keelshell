"""Read-only audit of retained lab evidence; writes only its own new receipt."""

import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import statistics
import struct
import subprocess
import time


REVIEW = Path(__file__).resolve().parent
ROOT = REVIEW.parents[2]
WORK = REVIEW.parent
KINDS = ("Exec", "Upload", "Download")
SCENES = ("baseline", "direct-impaired", "relay-impaired")
SAMPLE = "openssh_path_comparison_collects_eighteen_pinned_samples"
EXTRAS = (
    "openssh_path_comparison_precancel_preserves_routes",
    "openssh_path_comparison_rejects_unpinned_target_and_jump",
)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def kernel_birth(pid):
    """Independent raw Darwin proc_bsdinfo read, without the runner's helper."""
    library = ctypes.CDLL("/usr/lib/libproc.dylib", use_errno=True)
    library.proc_pidinfo.argtypes = (
        ctypes.c_int, ctypes.c_int, ctypes.c_uint64, ctypes.c_void_p, ctypes.c_int,
    )
    library.proc_pidinfo.restype = ctypes.c_int
    buffer = ctypes.create_string_buffer(136)
    ctypes.set_errno(0)
    count = library.proc_pidinfo(pid, 3, 0, buffer, len(buffer))
    error = ctypes.get_errno()
    if count == 0 and error in (0, 2, 3):
        return None
    assert count == 136, (pid, count, error)
    seconds, micros = struct.unpack_from("=QQ", buffer.raw, 120)
    status = struct.unpack_from("=I", buffer.raw, 4)[0]
    return {"birth": ["darwin", seconds, micros], "zombie": status == 5}


def audit(lab, final):
    result = json.loads((lab / "result.json").read_text())
    assert result["outcome"] == "passed" and result["returncode"] == 0
    assert 0 < result["elapsed_seconds"] <= result["timeout_seconds"] <= 300
    assert result["netem"]["status"] == "HOLD"
    assert result["netem"]["ip_packet_loss"] == "NOT_TESTED"
    artifacts = {"result.json": sha(lab / "result.json")}
    freeze = json.loads((WORK / "frozen-inputs-r3.json").read_text())
    frozen = {row["path"]: row["sha256"] for row in freeze["inputs"]}
    for name, expected in result["source_sha256"].items():
        assert sha(ROOT / name) == expected == frozen[name], name
    binary = result["test_binary"]
    assert sha(Path(binary["path"])) == binary["sha256"]
    if final:
        row = next(row for row in json.loads((WORK / "binaries-r3.json").read_text())
                   if row["target"] == "ssh_path_interop")
        assert binary["path"] == row["path"] and binary["sha256"] == row["sha256"]
    actual_logs = {path.name for path in lab.glob("*.log")}
    assert actual_logs == set(result["logs"])
    for name, row in result["logs"].items():
        assert Path(name).name == name
        path = lab / name
        assert path.stat().st_size == row["bytes"] and sha(path) == row["sha256"], name
        artifacts[name] = sha(path)
    inventory = (lab / "inventory.log").read_text()
    assert {line[:-6] for line in inventory.splitlines() if line.endswith(": test")} == {
        SAMPLE, *EXTRAS,
    }
    endpoints = result["endpoints"]
    assert all(value.startswith("127.0.0.1:") for value in endpoints.values())
    assert endpoints["target"] != endpoints["jump"]
    pins = {}
    username = None
    for role in ("target", "jump"):
        pins[role] = re.search(r"SHA256:[A-Za-z0-9+/]+", (
            lab / f"{role}-host-fingerprint.log"
        ).read_text())[0]
        name = f"{role}-sshd_config.txt"
        artifacts[name] = sha(lab / name)
        lines = [shlex.split(line) for line in (lab / name).read_text().splitlines()]
        assert all(len(line) == 2 for line in lines)
        config = dict(lines)
        assert len(config) == len(lines), "Repeated config directive"
        required = {
            "Port": endpoints[role].rsplit(":", 1)[1],
            "AddressFamily": "inet", "ListenAddress": "127.0.0.1",
            "AuthenticationMethods": "publickey", "PubkeyAuthentication": "yes",
            "PasswordAuthentication": "no", "KbdInteractiveAuthentication": "no",
            "PermitEmptyPasswords": "no", "UsePAM": "no", "StrictModes": "yes",
            "PermitUserEnvironment": "no", "AllowAgentForwarding": "no",
            "AllowStreamLocalForwarding": "no", "PermitTunnel": "no",
            "X11Forwarding": "no", "PermitTTY": "no",
            "AllowTcpForwarding": "local" if role == "jump" else "no",
            "PermitOpen": endpoints["target"] if role == "jump" else "none",
            "MaxSessions": "0" if role == "jump" else "8",
        }
        assert all(config[key] == value for key, value in required.items())
        assert username is None or username == config["AllowUsers"]
        username = config["AllowUsers"]
        for key, filename in (
            ("HostKey", "host"), ("AuthorizedKeysFile", "authorized_keys"),
            ("PidFile", "sshd.pid"),
        ):
            assert config[key] == str(Path(result["temporary_directory"]) / role / filename)
    assert pins["target"] != pins["jump"]
    scene_results = []
    gate_endpoints = []
    assert [row["scenario"] for row in result["scenarios"]] == list(SCENES)
    for entry in result["scenarios"]:
        scene = entry["scenario"]
        assert entry["outcome"] == "passed"
        report = json.loads((lab / scene / "report.json").read_text())
        conditions = json.loads((lab / scene / "conditions.json").read_text())
        review = (lab / scene / "review.txt").read_text()
        for name in ("report.json", "conditions.json", "review.txt"):
            artifacts[f"{scene}/{name}"] = sha(lab / scene / name)
        assert conditions == entry["conditions"]
        assert conditions["ip_packet_loss"] == "NOT_TESTED"
        assert conditions["write_chunk_max_bytes"] == 16384
        for side in ("A", "B"):
            impaired = (scene == "direct-impaired" and side == "A") or (
                scene == "relay-impaired" and side == "B"
            )
            assert conditions[side] == {
                "delay_ms_per_write": 20 if impaired else 0,
                "bytes_per_second": 524288 if impaired else 0,
            }
        assert report["scenario"] == scene and report["schema"] == 1
        assert report["status"] == "Complete" and report["cleanup_unconfirmed"] is False
        assert 0 < report["wall_elapsed_ns"] < 60_000_000_000
        samples = report["samples"]
        expected_order = [
            (round_number, side, kind)
            for round_number in (1, 2, 3)
            for kind in KINDS
            for side in (("B", "A") if round_number == 2 else ("A", "B"))
        ]
        assert len(samples) == 18
        assert [row["index"] for row in samples] == list(range(18))
        assert [(row["round"], row["path"], row["kind"]) for row in samples] == expected_order
        for sample in samples:
            assert sample["outcome"] == "Passed" and sample["failure"] is None
            assert type(sample["elapsed_ns"]) is int and 0 < sample["elapsed_ns"] <= 8_000_000_000
            assert sample["bytes"] == (0 if sample["kind"] == "Exec" else 262144)
        assert sum(row["bytes"] for row in samples) == 3 * 1024 * 1024
        assert sum(row["elapsed_ns"] for row in samples) <= report["wall_elapsed_ns"]
        medians = {
            side: {
                kind: statistics.median(
                    row["elapsed_ns"] for row in samples
                    if row["path"] == side and row["kind"] == kind
                ) for kind in KINDS
            } for side in ("A", "B")
        }
        assert medians == report["median_ns"]
        differences = {kind: medians["B"][kind] - medians["A"][kind] for kind in KINDS}
        for kind in KINDS:
            observed = entry["observed_difference"][kind]
            assert observed["A_ns"] == medians["A"][kind]
            assert observed["B_ns"] == medians["B"][kind]
            assert observed["B_minus_A_ns"] == differences[kind]
        before_plan = review.split("\nPLAN\n", 1)[0]
        sides = before_plan.removeprefix("A\n").split("\nB\n")
        assert len(sides) == 2
        for side, text, route in (
            ("A", sides[0], ("target",)), ("B", sides[1], ("jump", "target")),
        ):
            expected = []
            for index, role in enumerate(route, 1):
                host, port = endpoints[role].rsplit(":", 1)
                expected.append(
                    f'Hop {index} SSH: user="{username}" host="{host}" port={port} '
                    f'verified fingerprint="{pins[role]}"'
                )
            assert [line for line in text.splitlines() if " SSH: " in line] == expected
            gate = entry["gate_endpoints"][side]
            gate_endpoints.append(gate)
            assert gate.startswith("127.0.0.1:")
            port = gate.rsplit(":", 1)[1]
            assert f'Hop 1 explicit proxy: HttpConnect host="127.0.0.1" port={port}' in text
            if side == "B":
                assert "Hop 2 explicit proxy: none" in text
        tests = [SAMPLE, *(EXTRAS if scene == "baseline" else ())]
        assert [row["name"] for row in entry["tests"]] == tests
        for index, row in enumerate(entry["tests"]):
            assert row["returncode"] == 0 and row["reaped"] is True
            log = (lab / f"{scene}-test-{index}.log").read_text()
            assert f"test {row['name']} ... ok" in log
            assert re.search(r"test result: ok\. 1 passed; 0 failed; 0 ignored;", log)
        scene_results.append({
            "scenario": scene, "ordered_samples": len(samples),
            "payload_bytes": sum(row["bytes"] for row in samples),
            "wall_elapsed_ns": report["wall_elapsed_ns"], "median_ns": medians,
            "B_minus_A_ns": differences, "executions_by_parent": len(tests),
        })
    assert len(set(gate_endpoints)) == 6
    assert not set(gate_endpoints) & set(endpoints.values())
    precancel = json.loads((lab / "baseline/precancel.json").read_text())
    assert precancel["status"] == "Cancelled" and precancel["samples"] == []
    assert precancel["cleanup_unconfirmed"] is False
    assert all(value is None for row in precancel["median_ns"].values() for value in row.values())
    artifacts["baseline/precancel.json"] = sha(lab / "baseline/precancel.json")
    cleanup = result["cleanup"]
    expected_processes = {(row["name"], row["pid"]) for row in result["processes"]}
    rows = cleanup["processes"]
    assert len(rows) == len(expected_processes) == 23
    assert {(row["name"], row["pid"]) for row in rows} == expected_processes
    assert cleanup["owned_processes_stopped"] is True
    assert cleanup["ancestry_unverified"] == []
    assert cleanup["temporary_directory_removed"] is True
    assert not os.path.lexists(result["temporary_directory"])
    identities = []
    for row in rows:
        assert row["observed_stopped"] is True and row["reaped"] is True
        assert row["returncode"] == 0
        assert row["pid"] in {item["pid"] for item in row["identities"]}
        for item in row["identities"]:
            now = kernel_birth(item["pid"])
            live_match = now is not None and now["birth"] == item["birth"] and not now["zombie"]
            assert not live_match, item
            identities.append({**item, "current": now, "original_identity_live": live_match})
    return {
        "lab": str(lab), "final_r3_binary_binding": final, "passed": True,
        "independently_reran_openssh_lab": False, "independent_recompile": False,
        "binary": binary, "source_sha256": result["source_sha256"],
        "logs_verified": len(result["logs"]), "artifacts_sha256": artifacts,
        "scenarios": scene_results, "parent_rust_executions": 5,
        "total_payload_bytes": sum(row["payload_bytes"] for row in scene_results),
        "direct_parent_reap_receipts": len(rows), "recorded_identities": identities,
        "private_directory_absent_independently": True,
        "listener_ports": sorted(int(value.rsplit(":", 1)[1])
                                 for value in [*endpoints.values(), *gate_endpoints]),
        "reap_boundary": "Parent wait/reap receipts audited; reviewer cannot reap another parent's child retroactively.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    assert output.parent == REVIEW
    assert not output.exists()
    started = time.monotonic()
    self_identity = kernel_birth(os.getpid())
    assert self_identity is not None and not self_identity["zombie"]
    assert abs(time.time() - self_identity["birth"][1]) < 60
    receipts = [audit(WORK / f"openssh-path-lab-r{index}", index == 2) for index in (1, 2)]
    ports = sorted({port for receipt in receipts for port in receipt["listener_ports"]})
    command = ["lsof", "-nP", "-a", "-iTCP:" + ",".join(map(str, ports)), "-sTCP:LISTEN"]
    process = subprocess.run(command, stdin=subprocess.DEVNULL, capture_output=True, text=True, timeout=10)
    assert process.returncode == 1 and not process.stdout.strip() and not process.stderr.strip(), (
        process.stdout, process.stderr,
    )
    result = {
        "passed": True, "labs": receipts,
        "kernel_reader_positive_control": {"pid": os.getpid(), **self_identity},
        "listener_query": {"argv": command, "exit": process.returncode, "reaped": True,
                           "stdout": process.stdout, "stderr": process.stderr},
        "total_identity_observations": sum(len(row["recorded_identities"]) for row in receipts),
        "total_endpoint_ports": len(ports), "elapsed_seconds": time.monotonic() - started,
    }
    with output.open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(json.dumps({
        "passed": result["passed"], "labs": [
            {key: row[key] for key in (
                "lab", "logs_verified", "parent_rust_executions", "total_payload_bytes",
                "direct_parent_reap_receipts", "private_directory_absent_independently",
            )} | {"recorded_identities": len(row["recorded_identities"])}
            for row in receipts
        ], "total_identity_observations": result["total_identity_observations"],
        "total_endpoint_ports": len(ports), "listener_query_exit": process.returncode,
    }, indent=2))


if __name__ == "__main__":
    main()
