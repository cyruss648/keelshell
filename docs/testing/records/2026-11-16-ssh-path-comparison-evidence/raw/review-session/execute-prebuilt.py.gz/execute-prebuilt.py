"""Copy a parent-designated binary, verify frozen inputs, and run exact tests."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time


REVIEW = Path(__file__).resolve().parent
ROOT = REVIEW.parents[2]


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit(freeze_path):
    freeze = json.loads(freeze_path.read_text())
    rows = freeze["inputs"]
    aggregate = hashlib.sha256(
        "".join(f"{row['path']}\0{row['sha256']}\n" for row in rows).encode()
    ).hexdigest()
    mismatches = [
        row["path"]
        for row in rows
        if not (ROOT / row["path"]).is_file()
        or sha256(ROOT / row["path"]) != row["sha256"]
    ]
    result = {
        "freeze": str(freeze_path),
        "manifest_sha256": sha256(freeze_path),
        "baseline": freeze["baseline"],
        "count": len(rows),
        "aggregate_sha256": aggregate,
        "mismatches": mismatches,
    }
    assert len(rows) == freeze["count"]
    assert aggregate == freeze["aggregate_sha256"]
    assert not mismatches, result
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--sha256", required=True)
    parser.add_argument("--freeze", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--test", action="append", required=True)
    parser.add_argument("--ignored", action="store_true")
    args = parser.parse_args()
    output = args.output.resolve()
    assert output.is_relative_to(REVIEW) and output != REVIEW
    output.mkdir(mode=0o700)
    temporary = output / "tmp"
    temporary.mkdir(mode=0o700)
    receipt = {
        "independent_recompile": False,
        "parent_source_binary_binding_independently_proven_by_this_script": False,
        "commands": [],
        "test_names": args.test,
        "test_count": 0,
        "passed_test_count": 0,
        "failed_test_count": 0,
        "passed": False,
    }

    def run(label, command, budget):
        started = time.monotonic()
        with (output / (label + ".log")).open("xb") as log:
            process = subprocess.Popen(
                command,
                cwd=output,
                env=dict(
                    os.environ,
                    PYTHONDONTWRITEBYTECODE="1",
                    TMPDIR=str(temporary),
                ),
                stdin=subprocess.DEVNULL,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
            timed_out = False
            try:
                code = process.wait(timeout=budget)
            except subprocess.TimeoutExpired:
                timed_out = True
                # This unreaped direct child's private process group is ours.
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    code = process.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    code = process.wait(timeout=2)
        text = (output / (label + ".log")).read_text(errors="replace")
        receipt["commands"].append(
            {
                "label": label,
                "argv": command,
                "exit": code,
                "seconds": time.monotonic() - started,
                "timed_out": timed_out,
                "reaped": True,
            }
        )
        assert code == 0 and not timed_out, text
        return text

    try:
        receipt["source_before"] = audit(args.freeze.resolve())
        assert sha256(args.binary) == args.sha256
        binary = output / "parent-prebuilt-test"
        with binary.open("xb") as stream:
            stream.write(args.binary.read_bytes())
        binary.chmod(0o700)
        assert sha256(binary) == args.sha256
        receipt["binary"] = {
            "parent_path": str(args.binary.resolve()),
            "copied_path": str(binary),
            "sha256": args.sha256,
        }
        inventory = run("inventory", [str(binary), "--list"], 10)
        names = [line[:-6] for line in inventory.splitlines() if line.endswith(": test")]
        receipt["inventory_count"] = len(names)
        assert len(names) == len(set(names)), "Duplicate inventory entries"
        assert set(args.test) <= set(names), "An exact requested test name is absent"
        for index, name in enumerate(args.test):
            command = [str(binary)]
            if args.ignored:
                command.append("--ignored")
            command += ["--exact", name, "--nocapture", "--test-threads=1"]
            receipt["test_count"] += 1
            try:
                text = run(f"test-{index:02d}", command, 45)
                assert re.search(
                    r"^test result: ok\. 1 passed; 0 failed; 0 ignored;",
                    text,
                    re.MULTILINE,
                ), text
            except AssertionError:
                receipt["failed_test_count"] += 1
                raise
            receipt["passed_test_count"] += 1
        receipt["source_after"] = audit(args.freeze.resolve())
        receipt["passed"] = True
    finally:
        (output / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
        print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
