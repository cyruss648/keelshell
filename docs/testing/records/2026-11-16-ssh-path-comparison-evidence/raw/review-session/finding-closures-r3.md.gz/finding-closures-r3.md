**2026-11-16 · 非作者 session / lab reviewer · r3 finding 关闭记录**

结论：原三项 finding 全部关闭。当前开放 P0=0、P1=0、P2=0、P3=0；历史发现 P1=1、P2=2。旧 notice、旧失败日志与中间报告全部保留，本文件记录最终关闭证据。

本记录绑定父提供的 baseline `162d883460a98cd03056731fd8d4be76a41d5c15` 与最终 669 项冻结，aggregate SHA256 `066d7835e75d09895ae7a97f5b83863904a8dcbb0419bb1d8e865f89b7a047e0`。独立逐项核验及专项执行前后均零 mismatch。使用父预构建副本，未独立重编译。

**P2-001：借用 relay 的取消覆盖缺口，关闭。**

原问题：首个被取消样本始终为 direct A，既未触碰借用 jump 的 relay child，也没有另建同 parent 的独立 sibling。原来的存活检查不足以支持 relay 资源清理结论。历史原件：[notice-P2-001-relay-cancellation-coverage.md](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/review-session/notice-P2-001-relay-cancellation-coverage.md)。

已读回修复：[path_comparison.rs:433](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/fixtures/path_comparison.rs:433) 的 `new_path(mode, relay_first)` 以真实 `connect_through` 创建第二条 child 和第三条独立 sibling，并断言 Path A 的认证后 metadata 确有 jump。[healthy():460](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/fixtures/path_comparison.rs:460) 分别在 direct、被测 child、独立 sibling 上发 fresh exec，并另在 parent 上发 exec。

以下三个具体名均已在 r2、r3 父预构建副本上由 reviewer 独立执行成功；原 direct 分支也保留并执行：

- `path_comparison::comparison_relay_child_cancelled_or_dropped_late_open_preserves_shared_parent_and_sibling`：显式取消及 drop 两条分支均等待 late OPEN 清理，确认 exec 计数为零，再验证 parent / child / sibling。
- `path_comparison::comparison_relay_child_dispatched_cancel_retains_unknown_and_preserves_shared_sibling`：HoldAck、HoldReply 均保留 `cleanup_unconfirmed`、取消失败行和无 summary；迟到回复不能恢复结果。
- `path_comparison::comparison_relay_child_missing_close_deadline_retains_unknown_and_shared_sibling`：真实约 8.04 秒触发 SampleDeadline，保留未知，再验证共享资源仍可用。

最终执行原件：[prebuilt-routes-r3/receipt.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/review-session/prebuilt-routes-r3/receipt.json)。本项验证的是上述实际风险场景；不将既有 owner 在极端未确认 OPEN / CLOSE 背压下的 transport-stop 策略概括为无条件永不关闭连接。

**P1-002：共享 proxy fixture 类型可见性导致编译阻塞，关闭。**

原问题：外围模块的可见性没有同步扩大内部类型的可见性，兄弟 path fixture 无法访问 `Mode` / `ProxyServer`。父构建中多条 E0603 计为同一个根因。历史原件：[notice-P1-002-proxy-fixture-visibility.md](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/review-session/notice-P1-002-proxy-fixture-visibility.md)。

已读回 [upstream_proxy_server.rs:15](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/fixtures/upstream_proxy_server.rs:15)、[Observed:23](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/fixtures/upstream_proxy_server.rs:23)、[ProxyServer:39](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/fixtures/upstream_proxy_server.rs:39) 的 `pub(crate)` 修正。父已有成功编译与 focused-tests-r3 回执；reviewer 独立枚举最终 loopback 库存 165 项，并执行全部 11 个 path fixture 具体名成功，其中真实递归 proxy / jump 用例实际访问这些类型。因此关闭源码可见性与本批测试不可执行的问题；不将该证据表述为 reviewer 独立编译。

**P2-003：DuplicateAck wire fault 被 russh 抑制，关闭。**

原问题：锁定 russh 0.65.1 的服务端 `channel_success` 使用 `wants_reply`，第一次成功 ACK 后第二次调用不再发包；旧 fixture 因而实际发送合法序列，却断言必须失败。reviewer 在 r2 exact 测试中实际复现 1 failed、exit 101 / reaped。此问题不代表生产 parser 接受真正重复 ACK。历史原件：[notice-P2-003-duplicate-ack-fixture.md](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/review-session/notice-P2-003-duplicate-ack-fixture.md)；失败原件：[prebuilt-malformed-r2/test-00.log](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/review-session/prebuilt-malformed-r2/test-00.log)。旧 helper 的 `test_count: 0` 是通过后才累计的旧记账行为，不能解释为没有执行：日志与 exit 101 明确证明实际执行了一个失败测试。

r3 删除误导的 wire fault，新增 [protocol_tests.rs:26](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/path_comparison/protocol_tests.rs:26)。对三种 kind，各先证明完整合法序列 `Passed`，再分别注入重复 ACK / EOF / exit，并提供其余完整合法尾部，要求结果仍为 `InvalidSequence`。它是一个实际 Rust test，内部含 3 个正对照和 9 个负向场景；明确只证明 decoded-message 边界。reviewer 独立执行该具体名成功。r2→r3 的 transport 生产差分只有 `#[cfg(test)]` 模块链接，未放宽生产协议校验。

其余 emitter 已逐项对照锁定 russh 本地源码：

| emitter | 服务端与客户端真实路径 | r3 证据 |
| --- | --- | --- |
| `AfterEof` | Exec 小响应在窗口内先入队 DATA，再显式 EOF，再 DATA；服务端没有 sent-EOF 数据抑制，客户端在 CLOSE 前分别转发 EOF / DATA | 加密 fixture 的异常组合具体名通过；协议失败不能生成成功 summary |
| `NoEof` | fixture 跳过 EOF；`close()` 只发 CLOSE / 删除 channel，不自动补 EOF | 同一加密具体名实际执行此循环分支成功 |
| `NoExit` | fixture 跳过 exit-status；服务端 CLOSE 不合成 exit-status，客户端也不补 | 同上 |
| `DuplicateExit` | 两次 `exit_status_request` 均直接编码 CHANNEL_REQUEST，没有 wants_reply 去重；客户端逐次转发 ExitStatus | 加密 fixture 通过，另有 decoded 控制重复负向测试 |
| 其余 Wrong / Truncated / Extra / Stderr / NoAck / BadExit / Reject | 明确改变输出或缺少 ACK / 非零退出 / 发送拒绝；没有依赖第二次 `channel_success` | 加密 fixture 通过 |
| Upload / Download Wrong 与 Upload Flood | 实际传输错误内容；Flood 在接收完整 stdin 前发送 3 MiB，超过客户端接收窗口，验证并行读写及 OutputLimit | 加密 fixture 通过，未超时，且保留真实清理结果 |

发射位置：[fixture reply:108](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/fixtures/path_comparison.rs:108)、[NoAck / Reject:229](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/fixtures/path_comparison.rs:229)、[Flood:249](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/fixtures/path_comparison.rs:249)；执行及断言：[malformed:711](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/fixtures/path_comparison.rs:711)。

核查所用依赖路径：[server channel_success:1062](/Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837/russh-0.65.1/src/server/session.rs:1062)、[server exit_status_request:1266](/Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837/russh-0.65.1/src/server/session.rs:1266)、[Encrypted eof / close:278](/Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837/russh-0.65.1/src/session.rs:278)、[data_with_writer:615](/Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837/russh-0.65.1/src/session.rs:615)、[client EOF:546](/Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837/russh-0.65.1/src/client/encrypted.rs:546)、[client DATA:590](/Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837/russh-0.65.1/src/client/encrypted.rs:590)、[client exit-status:667](/Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837/russh-0.65.1/src/client/encrypted.rs:667)。这是源码路径与真实加密 fixture 的联合证据，没有另做网络抓包，也没有宣称 duplicate ACK 已有加密 wire 覆盖。

最终两个相关 exact 命令均为 1 passed / 0 failed / 0 ignored，exit 0 / reaped。单元原件：[prebuilt-unit-r3/receipt.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/review-session/prebuilt-unit-r3/receipt.json)；加密 fixture 原件：[prebuilt-routes-r3/receipt.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/review-session/prebuilt-routes-r3/receipt.json)。
