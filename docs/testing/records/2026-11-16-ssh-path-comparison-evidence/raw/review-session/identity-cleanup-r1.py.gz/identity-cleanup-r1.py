"""Independent real-process check of the lab's existing cleanup boundary."""

from contextlib import ExitStack
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time


OUTPUT = Path(__file__).resolve().parent
ROOT = OUTPUT.parents[2]
sys.path.insert(0, str(ROOT / "scripts"))
import openssh_interop as interop
import ssh_path_lab as lab


def main():
    receipt = {"steps": [], "processes": []}
    child_pid_path = OUTPUT / "identity-child-pid-r1.json"
    child_reap_path = OUTPUT / "identity-child-reap-r1.json"
    owner_code = """
import json, signal, subprocess, sys, time
from pathlib import Path
child = subprocess.Popen([sys.executable, "-B", "-c", "import time; time.sleep(25)"])
def stop(signum, frame):
    if child.poll() is None:
        child.terminate()
    result = child.wait(timeout=2)
    Path(sys.argv[2]).write_text(json.dumps({"pid": child.pid, "exit": result, "reaped": True}))
    raise SystemExit(0)
signal.signal(signal.SIGTERM, stop)
Path(sys.argv[1]).write_text(json.dumps({"pid": child.pid}))
time.sleep(25)
stop(0, None)
"""
    sentinel = subprocess.Popen(
        [sys.executable, "-B", "-c", "import time; time.sleep(25)"],
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
        env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"),
    )
    sentinel_identity = interop.process_info(sentinel.pid)
    started = time.monotonic()
    passed = False
    try:
        with ExitStack() as stack:
            runner = lab.LabRunner(
                OUTPUT,
                time.monotonic() + 10,
                stack,
                receipt,
                lambda: None,
            )
            process = runner.start(
                "identity-owned-parent-r1",
                [
                    sys.executable,
                    "-B",
                    "-c",
                    owner_code,
                    str(child_pid_path),
                    str(child_reap_path),
                ],
                dict(os.environ, PYTHONDONTWRITEBYTECODE="1"),
            )
            try:
                until = time.monotonic() + 3
                while time.monotonic() < until:
                    runner.capture_owned()
                    if child_pid_path.exists() and len(runner.owned[process]) >= 2:
                        break
                    time.sleep(0.02)
                assert child_pid_path.exists(), "Owned parent did not create its child"
                child_pid = json.loads(child_pid_path.read_text())["pid"]
                assert child_pid in runner.owned[process], "Descendant identity was not recorded"
                assert sentinel.pid not in runner.owned[process], "Unrelated sentinel was adopted"
            finally:
                rows = lab.shutdown(runner, time.monotonic() + 6)
                receipt["cleanup"] = rows
            assert len(rows) == 1
            assert rows[0]["observed_stopped"] and rows[0]["reaped"]
            assert rows[0]["returncode"] == 0
            assert child_reap_path.exists(), "Owned parent did not actually reap its child"
            child_reap = json.loads(child_reap_path.read_text())
            assert child_reap["pid"] == child_pid and child_reap["reaped"]
            assert interop.same_process(
                interop.process_info(sentinel.pid), sentinel_identity
            ), "Cleanup killed or replaced the unrelated sentinel"
            assert sentinel.poll() is None
            receipt.update(
                owned_parent_pid=process.pid,
                owned_child_pid=child_pid,
                owned_child_reap=child_reap,
                unrelated_sentinel_pid=sentinel.pid,
                unrelated_sentinel_survived=True,
                recorded_owned_count=len(runner.owned[process]),
                ancestry_unverified=sorted(runner.ancestry_unverified),
            )
            passed = True
    finally:
        if sentinel.poll() is None:
            sentinel.terminate()
        sentinel.wait(timeout=3)
        receipt.update(
            unrelated_sentinel_final_exit=sentinel.returncode,
            unrelated_sentinel_reaped=True,
            passed=passed,
            seconds=time.monotonic() - started,
            command=[sys.executable, "-B", str(Path(__file__).resolve())],
            source_sha256={
                str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in [
                    ROOT / "scripts/ssh_path_lab.py",
                    ROOT / "scripts/openssh_interop.py",
                ]
            },
            boundary="One real process-identity cleanup check, not an SSH or Rust test",
        )
        (OUTPUT / "identity-cleanup-r1.json").write_text(
            json.dumps(receipt, indent=2) + "\n"
        )
        print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
