# [P1] New route fixture cannot compile through the proxy module boundary

Status: OPEN at parent focused-build-r2 (exit 101 / reaped). This reviewer did not run Cargo.

Location: `crates/keelshell-session/tests/fixtures/upstream_proxy.rs:4` and `crates/keelshell-session/tests/fixtures/path_comparison.rs:489` (same cause at 496, 583 and 610).

Exposing `upstream_proxy::proxy_fixture` with `pub(super) mod` does not widen the `pub(super)` visibility of the contained `ProxyServer`, `Mode`, their fields or methods. Their `super` is `upstream_proxy`; sibling `path_comparison` is outside that scope. The new fixture imports the module and uses these private items. Parent `focused-build-r2.log` contains eight E0603 diagnostics for `ProxyServer` and `Mode`; these are one visibility defect, not eight separate findings. This blocks the ssh_loopback integration test binary, including all new adversarial path-comparison tests.

Correction/evidence: expose only the reusable test fixture API at the integration-test crate scope, or re-home/share it under an appropriate common fixture module. Check all required public types, fields and methods, not only the module declaration. Obtain a new successful build and a concrete ssh_loopback inventory containing the new path_comparison names. Retain r2 failure; do not infer success from the other test artifacts that were emitted before Cargo exited 101.

The app macro recursion diagnostic in that same build belongs to the separate app reviewer and is not counted here.
