# [P2] Cancellation regressions never exercise the probed relay child

Status: OPEN. A meaningful-validation defect; no demonstrated production transport failure is claimed.

Scope: `crates/keelshell-session/tests/fixtures/path_comparison.rs:435-441`, `:779-803`, `:808-837`, `:842-859`; scheduling is `crates/keelshell-session/src/path_comparison.rs:330-338`.

`Pair::new` always binds A/first to `SshSession::connect(node.options())` and B/second to `connect_through(&jump, ...)`. The plan always starts round 1 with A Exec. HoldOpen, HoldAck, HoldReply, and missing CLOSE all stop or cancel that first sample. Consequently the late-open/drop test named `preserves_jump_and_sibling` opens/cancels a channel on the direct session; its jump and relayed session were never on the probe channel ownership chain. The dispatched-cancel and sample-deadline tests have the same limitation.

Trigger/impact: an error that closes a relay parent or sibling specifically during cancellation/late OPEN of a *relayed* probe can escape all these new regressions. Existing healthy checks on an unrelated route cannot establish this batch's advertised borrowed-parent survival boundary. Real OpenSSH's new cancellation test is pre-cancel only, and likewise cannot fill the admitted-OPEN/dispatched-EXEC gap.

Required evidence to close: exercise admitted late OPEN (cancel and dropped future), in-flight cancellation before ACK/after stdin EOF, and unconfirmed completion with the *probed* connection actually returned by `connect_through`; keep a separate already-authenticated sibling on the same jump. Observe the held child channel, release it late, assert no late EXEC for the OPEN cases, unknown for unconfirmed dispatch, and actual fresh exec/forwarding on the child, its parent and that sibling afterward. A swapped A/B parameter or explicit relay-first plan is sufficient for choosing the probed path; the independent sibling should remain independently owned. Keep concrete test names and run them from the fresh parent-provided binary.

Evidence boundary: this finding is source-proven against the imported fixture whose frozen r1 SHA256 is `4cc51964128e4f8bd55a3ef5a4f6a21bc1dcddd01579e185f984ac2c74a72614`. Rust tests have not yet been run by this reviewer; no Cargo, Git or source edits were performed. The 16 Python runner tests passed independently and do not cover this Rust ownership path.
