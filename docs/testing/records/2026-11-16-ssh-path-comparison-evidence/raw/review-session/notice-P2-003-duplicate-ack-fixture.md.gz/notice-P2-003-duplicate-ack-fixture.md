# [P2] DuplicateAck fault is suppressed by the server API; adversarial test fails

Status: OPEN, independently reproduced from the parent-designated prebuilt binary after verifying frozen r2 (668 inputs, aggregate `ea2ee7c4aaf26352d3b20bdee196c9a03f936f4c4d2eafcefa8ea527373e51ad`). No independent recompilation occurred.

Location: `crates/keelshell-session/tests/fixtures/path_comparison.rs:239-244` and `:718-746` (current line numbers around the grouped malformed-response test).

The `DuplicateAck` branch calls `session.channel_success(id)` twice, expecting two ACK messages. In the locked russh 0.65.1 implementation, server `Session::channel_success` emits only when channel.wants_reply is true, and the first invocation clears that flag; the second is a no-op. Therefore the fixture sends one valid ACK and valid output/EOF/exit/CLOSE, which the production probe correctly accepts. The fault label is not evidence of a wire-level duplicate.

Actual evidence: copied `ssh_loopback` SHA256 `620266e0e5445aa6cf3bca6d386f8f536fe94b59d5dc8d4e015d22179d8389a5`; independent inventory 165 named tests. Running exactly `path_comparison::comparison_malformed_ack_output_eof_exit_and_close_never_become_success --nocapture --test-threads=1` produces exit 101, `0 passed / 1 failed / 164 filtered`, with `DuplicateAck: PathComparisonReport { status: Complete, ... 18 Passed samples ..., cleanup_unconfirmed: false }`. Original output and exact commands are retained in `prebuilt-malformed-r2/`.

Trigger/impact: the mandatory adversarial regression currently fails, and it cannot attest duplicate-ACK transport rejection. Later cases in the same grouped test are not reached. Do not weaken the protocol or change the expected malformed result to Complete to make the gate green.

Required correction/evidence: inject the malformed sequence below this stateful server API so that two ACKs are actually emitted/observed, or test the duplicate-control state machine at its explicit unit boundary and remove the misleading wire-fault claim. Keep the distinct evidence boundaries honest and retain real encrypted-fixture checks for the malformations the public server API can emit. Rebuild, verify a superseding frozen set/inventory, then independently rerun this exact test and any newly added specific tests. Check other stateful fault emitters for similar suppression.

Primary API evidence inspected read-only: `/Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837/russh-0.65.1/src/server/session.rs:1062-1074`; this was source inspection only, with no dependency operation.
