# Frozen r1 has changed during independent review

Status: EVIDENCE HOLD, not a new uncorrected code finding.

The initial independent audit verified all 667 file hashes and aggregate `2035dc03867a9281c9ccd7be98289f62b29603a1815cbf23e34e16bb6fd4e0aa`. A subsequent audit observes parent edits; exact rows are retained in `source-drift-r1.json`. Do not bind later binaries to r1 without a superseding freeze and delta check.

The parent `focused-build-r1.json` has exit 101 / reaped and E0061 at `crates/keelshell-session/src/ssh/write_barrier_tests.rs:310`: authenticate_stream acquired a fourth parameter. The current caller already includes `None`, so this is a corrected source error awaiting new build evidence, not an independently compiled success. No Cargo or Git was invoked by this reviewer.
