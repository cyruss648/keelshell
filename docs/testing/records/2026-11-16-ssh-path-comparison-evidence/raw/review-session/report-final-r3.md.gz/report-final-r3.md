**2026-11-16 · 非作者 reviewer 最终限定报告：APPROVE（session 传输、lab runner、测试有效性与 SSH_RELAY 文档范围）**

当前开放 severity：**P0=0、P1=0、P2=0、P3=0**。原 P1=1、P2=2 均已用源码读回和实际执行关闭；旧 notice、r2 的真实失败、r1/r2 lab 原件与中间报告均保留。逐项触发、影响、修复行号及关闭证据见 [finding-closures-r3.md](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/review-session/finding-closures-r3.md)。

本结论可供父集成流程收取。整体合入由父负责在相同冻结上满足完整门禁、正常 build 与独立 app review 条件。签署前父最新消息已报告 full-gate-r1 实际 **exit 0 / reaped / 698.757s**，门禁后 669 项零 mismatch；正常 build 尚在执行。本 reviewer 未重复执行完整门禁，也未独立核定正常 build 终态，不能把本报告扩大为三平台原生验收或全产品验收。

**身份、冻结与只读边界**

父提供 baseline：`162d883460a98cd03056731fd8d4be76a41d5c15`。最终对象为 [frozen-inputs-r3.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/frozen-inputs-r3.json)：669 inputs，aggregate SHA256：

```text
066d7835e75d09895ae7a97f5b83863904a8dcbb0419bb1d8e865f89b7a047e0
```

reviewer 独立逐文件 SHA256、计数和 aggregate 校验通过，r3 专项执行前后均零 mismatch；r2→r3 六项 delta 与父清单匹配。manifest 自身 SHA256 为 `fd1aab536ba4c8463a76e16b4fde3c62be7c0400342014f4b41b72e3202071e7`。原件：[source-audit-r3.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/review-session/source-audit-r3.json)。

已读 AGENTS、RTK、HANDOFF、ADR0141、STRATEGY、SHARED_TARGET，按 rust-best-practices / rust-engineer 的适用审查要求工作。本次未执行 Cargo、格式化、依赖操作、Git、清理父资源或编辑源码；没有新建 agent、chat、worktree，没有 commit / push。所有 reviewer 写入及临时输出均限于本 review-session。遵照禁止 Git 的要求，未独立获取 baseline Git diff；以父提供 baseline、冻结及当前源文件绑定本次审查。

reviewer 复制并执行父提供的稳定 binary，核验其 SHA256 与具体库存。**未独立重编译；hash、库存与父构建声明不等于 reviewer 独立证明 source→binary 的编译链。**

| r3 父预构建 target | 独立库存 | 独立核验 SHA256 |
| --- | ---: | --- |
| keelshell_session | 245 | `b618591af2e12357c3d8fa5164bab30e362c4c40339ff0ab484f847e8f526d0b` |
| ssh_loopback | 165 | `ddd1be368d0294d308550f4c8b2c2e7047a22e73c8696e9305c0e18b64068db8` |
| ssh_path_interop | 3 | `c8fdcf0925cdd098044152714635ccb3581f2cc7dede6bdcc5b90e3b3407551c` |

父元数据：[binaries-r3.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/binaries-r3.json)。只执行稳定副本及 reviewer 自己的副本，没有运行共享 target 内文件。

**源码范围及结论**

已复核最初指定的 12 个源文件/文档，另读回新增 protocol_tests、proxy fixture 可见性修复及 write_barrier_tests 的参数修复；为判定真实清理和事件发射路径，窄读现有 channel owner、proxy 校验及锁定 russh 本地源码。app 控制器、布局和双语显示由独立 app reviewer 负责。

- [ssh.rs:255](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/ssh.rs:255) 先严格核验 pin；[authenticate_stream:473](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/ssh.rs:473) 仅在认证成功后创建 metadata。`connect_through` 传入实际 parent 的不可变快照，递归保留每跳 pin 及显式 proxy；没有从 profile 回填来源。[connection_info.rs:32](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/ssh/connection_info.rs:32) 不保存 proxy credentials，字段私有、无 mutator，review 值有转义。新 getter 只返回原快照引用。
- [PathComparisonPlan::new:261](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/path_comparison.rs:261) 要求不同真实连接、相同 requested host / port / user / verified key、不同递归 actual route；clone、相同路线、不同 endpoint 维度和关闭连接均有实际加密 fixture 覆盖。相同 pin 不解释为独占物理机器身份。
- [transport.rs:88](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/path_comparison/transport.rs:88) 保留同一个已 admitted OPEN future 收取 late-open 清理；取消前后再次检查授权，late OPEN 不获得 EXEC。新增 relay-first 风险用例确实探测借用 jump 的 child，并另建独立 sibling；三个被检查连接与 jump 均通过 fresh exec 证明仍可用。
- [transport.rs:175](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/path_comparison/transport.rs:175) 用固定 16 KiB 输入块、并行写入/读取和逐段输出验证，不按对端输出累计 capture buffer；stdout 与 extended-data 共同有固定 cap。上传完成 stdin EOF、严格 ACK、精确输出、无 stderr、EOF、exit 0 和 peer CLOSE 才能成功。CLOSE 入队不冒充进程退出，未证实派发程序结束时保留 unknown。
- [sample:43](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/path_comparison/transport.rs:43) 在 OPEN 前开始计时，sample 使用 `min(8s, comparison_until)`；[run:336](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/path_comparison.rs:336) 保持同一个 60 秒绝对期限，不为各步骤重置预算。真实 missing-CLOSE 用例约 8.04 秒失败并保留 unknown；三个固定程序的独立 POSIX alarm 均实际触发。
- [summary:217](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/path_comparison.rs:217) 拒绝 incomplete / cancelled / unknown、缺轮次、重复轮次、错误轮次和失败行；没有缺样本补零。实测零耗时按零保留。吞吐耗时含通道打开、命令/解释器启动、传输及完成，不解释为 ICMP RTT 或裸链路带宽。
- [ssh_loopback.rs:67](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/ssh_loopback.rs:67) 接入真实加密 [path fixture](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/fixtures/path_comparison.rs:108)；[upstream_proxy fixture](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/fixtures/upstream_proxy.rs:1) 验证递归 route 及 proxy 来源。r3 异常组合完整执行：11 种 Exec fault、Upload/Download 错内容及 Upload 3 MiB flood，共 14 个内部 fault 场景，计为一个 Rust test。flood 在完整 stdin 前发送超过窗口的数据，能揭示串行 write-then-read 死锁；不是只复述 parser 内部状态。
- [protocol_tests.rs:26](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/path_comparison/protocol_tests.rs:26) 用合法正对照及插入重复控制事件的负向场景验证 sticky rejection。duplicate ACK 明确是 decoded-message 边界；误导 wire emitter 已删除。AfterEof / NoEof / NoExit / DuplicateExit 不存在同类 wants_reply 抑制，其真实收发路径与加密执行见关闭记录。
- [ssh_path_lab.py:318](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/ssh_path_lab.py:318) 先核验三个具体 ignored 名，再要求每次 exact 调用明确执行 1 passed；[ssh_path_interop.rs:197](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/ssh_path_interop.rs:197) 在验收断言前保存真实 partial/failed report。runner 使用新目录、独立场景 gate、固定条件、有符号 B−A，失败不改签。
- [server_config:189](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/ssh_path_lab.py:189) 与实际保留配置均为 localhost、公钥认证、target 禁止转发、jump `MaxSessions 0` 且 PermitOpen 仅该 target。CONNECT gate 只接受其唯一 authority，限制 header / chunk，写入遵守 drain 背压。[shutdown:282](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/ssh_path_lab.py:282) 按累计 kernel birth identity 清理，逐个尝试并独立 wait/reap 直接子进程；inventory 失败不伪装成空表或确认清理成功。
- [test_ssh_path_lab.py](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_ssh_path_lab.py:1) 的真实 loopback 转发、错误 authority、header 上限、限速与字节保持、旧输出保护、零测试库存拒绝和 gate reap 等行为均实际执行。[SSH_RELAY.md](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/product/SSH_RELAY.md:1) 与源码及本地证据一致：专用受限跳板、不保证更快、完整路线审核、合成内存载荷、未知清理、用户态 stream pacing 和 IP loss / native 验收边界说明准确。

**reviewer 实际执行与命令计数**

最终 r3：**15 个 Rust test 实际执行、15 passed、0 failed、0 ignored**。每个测试均以 exact name 单独调用，检查日志必须为 1 passed；全部 exit 0 / reaped。两次完整库存与一次 interop ignored 库存合计 3 次 inventory。因此最终候选有 **18 次实际 binary 调用 = 15 次 exact test + 3 次 inventory**。

四个 session 具体名：

```text
path_comparison::tests::summary_requires_complete_three_distinct_successful_rounds
path_comparison::tests::equal_and_zero_measured_durations_are_preserved_without_inventing_a_difference
path_comparison::tests::fixed_python_programs_exchange_exact_memory_samples_and_reject_extra_upload
ssh::path_comparison_transport::tests::path_comparison_duplicate_controls_cannot_be_repaired_by_a_valid_tail
```

十一个 encrypted fixture 具体名：

```text
path_comparison::comparison_seals_actual_recursive_hops_and_each_explicit_proxy_without_credentials
path_comparison::comparison_eligibility_rejects_clones_same_route_and_every_endpoint_dimension
path_comparison::comparison_strict_samples_follow_alternating_rounds_and_reviewed_commands
path_comparison::comparison_malformed_ack_output_eof_exit_and_close_never_become_success
path_comparison::comparison_precancelled_run_never_opens_channels
path_comparison::comparison_cancelled_or_dropped_late_open_never_executes_and_preserves_jump_and_sibling
path_comparison::comparison_relay_child_cancelled_or_dropped_late_open_preserves_shared_parent_and_sibling
path_comparison::comparison_cancelled_dispatched_probe_keeps_unknown_and_rejects_late_valid_result
path_comparison::comparison_relay_child_dispatched_cancel_retains_unknown_and_preserves_shared_sibling
path_comparison::comparison_missing_close_hits_sample_deadline_and_retains_unconfirmed_cleanup
path_comparison::comparison_relay_child_missing_close_deadline_retains_unknown_and_shared_sibling
```

实际执行的库存命令及两个 exact 命令示例：

```text
/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/review-session/prebuilt-unit-r3/parent-prebuilt-test --list
/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/review-session/prebuilt-unit-r3/parent-prebuilt-test --exact ssh::path_comparison_transport::tests::path_comparison_duplicate_controls_cannot_be_repaired_by_a_valid_tail --nocapture --test-threads=1
/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/review-session/prebuilt-routes-r3/parent-prebuilt-test --list
/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/review-session/prebuilt-routes-r3/parent-prebuilt-test --exact path_comparison::comparison_malformed_ack_output_eof_exit_and_close_never_become_success --nocapture --test-threads=1
/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/review-session/prebuilt-interop-inventory-r3/parent-prebuilt-test --list --ignored
```

全部 18 条真实绝对 argv、每条 exit、耗时、reap、库存与冻结前后校验原样保存在 [unit receipt](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/review-session/prebuilt-unit-r3/receipt.json)、[fixture receipt](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/review-session/prebuilt-routes-r3/receipt.json)、[interop inventory receipt](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/review-session/prebuilt-interop-inventory-r3/receipt.json)。

此前 r2 reviewer 独立执行为 14 次实际 Rust test：13 passed、1 failed（DuplicateAck fixture）；另有 3 次 inventory。历史与最终合计 **29 次实际 Rust test 执行、28 passed / 1 历史 failed，35 次 binary 调用**。同名重跑没有算作新增用例，也没有用 r3 成功覆盖旧失败。

其他独立验证分开计数：

| 验证 | 实际结果 | 证据 |
| --- | --- | --- |
| Python 工程 suite，1 次 unittest 命令 | 16/16 passed；0 failed / skipped | [python-lab-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/review-session/python-lab-r1.json) |
| 固定程序语义 subprocess，9 次程序执行 | 9/9；真实验证正常输出及 short / wrong / extra / empty stdin 的 exit 65 | [fixed-program-probes-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/review-session/fixed-program-probes-r1.json) |
| 固定程序 alarm，3 次程序执行 | 3/3；故意不 EOF，各约 8.02 秒 SIGALRM、exit -14、实际 reap | [fixed-program-alarm-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/review-session/fixed-program-alarm-r1.json) |
| reviewer 自有 parent / child 身份清理，1 次专项脚本 | 1/1；两个 owned 进程实际停止 / reap；无关 sentinel 保持存活，后单独 reap | [identity-cleanup-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/review-session/identity-cleanup-r1.json) |
| 两轮父 OpenSSH 原件独立审计 | 各 54 个样本、23 份日志与全部条件 / medians / signed differences 通过 | [lab-audit-final-r3.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/review-session/lab-audit-final-r3.json) |

Python suite 实际命令为 `python3 -B -m unittest discover -s scripts -p test_ssh_path_lab.py -v`，设置 `PYTHONDONTWRITEBYTECODE=1`，TMPDIR 限于 review-session。固定程序 probe 的命令字节已再与 r3 三个常量逐字核对，完全相同；没有把早期不同 API 文件 hash 当成相同文件。以上程序 probe、alarm、清理专项均不计入 Rust / SSH test 数。

汇总机器原件：[execution-summary-final-r3.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/review-session/execution-summary-final-r3.json)。

**最终 r3 真实 OpenSSH lab 审计**

最终采用 [openssh-path-lab-r2/result.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/openssh-path-lab-r2/result.json)：它使用 r3 `ssh_path_interop`，binary SHA256 与父稳定副本及 reviewer 独立 hash 相同；三项 runner / interop source SHA256 与 r3 冻结一致。父外层报告 23.03 秒，result 原件内部 elapsed 为 22.886 秒，属于不同计时包络，未混写。

reviewer 使用独立审计算法核对三个场景全部 ordered samples 的 index、1/2/3 轮次、每种操作内 A/B→B/A→A/B 顺序、准确字节与总量、Passed / failure=null、Complete / cleanup=false、样本 ≤8 秒、wall <60 秒、六组各三次中位数以及顶层 B−A。三场景固定同 target / jump / user / pin；仅指定 gate 改为 20 ms / 524288 Bps，每场使用不同 gate 端口与队列。还核验 baseline 取消报告无样本 / 无 summary，以及真实具体名日志不是零测试。

以下为最终 r3 lab 的有符号 `B_minus_A_ns`，只记录本地观察：

| 场景 | ordered samples | Exec (ns) | Upload (ns) | Download (ns) |
| --- | ---: | ---: | ---: | ---: |
| baseline | 18 | -7054667 | 8864584 | -1153041 |
| direct-impaired | 18 | -123820042 | -959211500 | -937354125 |
| relay-impaired | 18 | 112208624 | 958303333 | 952270584 |

每轮 lab 实际由父执行 5 次 Rust command（3 个 unique tests）：采样具体名在三场景各一次，baseline 另跑 precancel / same-route 拒绝和双层错误 pin。reviewer 没有亲自重跑完整 OpenSSH lab；仅独立审计原件并执行前述 15 项预构建专项。两轮父 lab 的 10 次 Rust command 不并入 reviewer 执行数。

每场景 payload 为 3 MiB，每轮三场景合计 **9 MiB**；保留的 r1+r2 两轮合计 **18 MiB**。每轮有 54 个采样行，两轮为 108 个，不把每个 sample 冒充独立 Rust test。

实际清理复核独立于父的后续端口 connect 读回：reviewer 直接读取 Darwin kernel birth identity，并以自身活 PID 作正对照；两轮记录共 197 条身份当前均 absent。独立 `lsof` 对 16 个旧端口查询无监听，命令按“未匹配监听”返回 1 且 stdout / stderr 为空；两个私有目录 `lexists=false`。没有向父 PID 发信号、没有清理父目录、没有读取密钥内容。

两轮各 23 个直接 owned process 的 `observed_stopped / reaped` 回执全部为 true，ancestry_unverified 均为空。**这些是父实际 wait/reap 的回执，reviewer 无法追溯 wait 另一个 parent 的孩子。** 当前 kernel 不存在与私有目录不存在提供独立终态佐证；reviewer 自己的 parent/child 专项另外实际验证了清理及 reap。脚本 [audit-lab.py](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/review-session/audit-lab.py) 与最终审计原件保留每条身份、文件摘要及只读 listener 命令。旧 r1 仍明确绑定早期 r2 输入，没有被改签为 r3。

**父完整门禁与未验范围**

父在签署前最新回报：[final-gate-summary-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/ssh-path-comparison-20261116/final-gate-summary-r1.json) 对 full-gate-r1 记录 exit 0 / reaped / 698.757s，ordinary 3103 passed / 0 failed / 40 ignored、rustdoc 14/0、Python 工程 203、helper 25，fmt / 严格 Clippy / x.y / 三 controller 通过，新增 26 个具体名实际 ok，r3 669 项门禁后零 mismatch。此段明确归属父的报告，不计为本 reviewer 独立执行；正常 build 仍须父实际收取终态。

本报告没有独立重编译、运行完整门禁、取得 Git baseline diff 或深审 app UI。没有三平台原生桌面验收、Internet / 生产线路收益验收、IP loss / tc netem / 拥塞恢复实验；stream 模型的解释边界维持 HOLD / NOT_TESTED。没有强制耗尽整次 60 秒 comparison deadline 的端到端专项；其绝对期限来源已源码复核，8 秒 sample 与程序 alarm 分别已有实际证据。没有加密 wire 上真正重复 ACK 的执行证明；对应承诺只到 decoded-message parser 边界。没有远程真实用户机器或生产数据参与验证。

**签署建议：本 reviewer 的 r3 session / runner / 文档范围通过，三项历史 finding 关闭。父相同冻结的完整门禁条件据其最新回报已满足；正常 build、独立 app review 与整体合入/后续原生验收由父按各自证据收口。本 reviewer 工作结束。**
