# Session transport/lab independent review

Strictly read-only source review. Writes confined to this review-session directory. No Cargo, Git, formatting, dependency operations, shared-target access or source editing. Baseline and frozen manifest supplied by parent; baseline Git diff not independently obtained because Git is prohibited. Source audit checks each current file against the supplied manifest. Test execution pending parent-provided binaries and inventory.
