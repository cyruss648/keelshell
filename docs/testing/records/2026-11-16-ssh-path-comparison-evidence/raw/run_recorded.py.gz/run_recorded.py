import argparse, json, os, signal, subprocess, time
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument("name")
p.add_argument("--timeout",type=float,default=900)
p.add_argument("command",nargs=argparse.REMAINDER)
a=p.parse_args()
cmd=a.command
if cmd and cmd[0]=="--": cmd=cmd[1:]
out=Path(__file__).resolve().parent
started=time.monotonic()
env=dict(os.environ,CARGO_TARGET_DIR=str(Path.cwd()/"work/recovery-batch-integration-20261115/target"))
with (out/(a.name+".log")).open("xb") as log:
 process=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
 timed_out=False
 try: result=process.wait(timeout=a.timeout)
 except subprocess.TimeoutExpired:
  timed_out=True
  os.killpg(process.pid,signal.SIGTERM)
  try: result=process.wait(timeout=5)
  except subprocess.TimeoutExpired:
   os.killpg(process.pid,signal.SIGKILL); result=process.wait()
receipt={"command":cmd,"cwd":str(Path.cwd()),"exit":result,"seconds":round(time.monotonic()-started,3),"timed_out":timed_out,"reaped":True}
(out/(a.name+".json")).write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt),flush=True)
raise SystemExit(0 if result==0 else 1)
