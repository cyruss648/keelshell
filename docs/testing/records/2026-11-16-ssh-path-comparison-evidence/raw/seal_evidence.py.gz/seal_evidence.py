"""Export this owned batch after all writers have exited; keep binary receipts."""
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path

source = Path(__file__).resolve().parent
root = source.parents[1]
destination = root / "docs/testing/records/2026-11-16-ssh-path-comparison-evidence"
assert source == root / "work/ssh-path-comparison-20261116"
assert not (destination / "archive-manifest.json").exists()
compiled = {
    b"\x7fELF", b"\xcf\xfa\xed\xfe", b"\xfe\xed\xfa\xcf",
    b"\xca\xfe\xba\xbe", b"\xbe\xba\xfe\xca",
}
manifest, omitted = {}, {}
files = sorted(path for path in source.rglob("*") if path.is_file())
for path in files:
    assert not path.is_symlink(), path
    if "__pycache__" in path.parts:
        continue
    name = path.relative_to(source).as_posix()
    with path.open("rb") as stream:
        magic = stream.read(4)
        stream.seek(0)
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    size = path.stat().st_size
    if magic in compiled:
        omitted[name] = {"bytes": size, "sha256": digest, "reason": "Rebuildable compiled test copy"}
        continue
    original = path.read_bytes()
    assert hashlib.sha256(original).hexdigest() == digest
    artifact = "raw/" + name + ".gz"
    target = destination / artifact
    target.parent.mkdir(parents=True, exist_ok=True)
    compressed = gzip.compress(original, mtime=0)
    with target.open("xb") as stream:
        stream.write(compressed)
    assert gzip.decompress(target.read_bytes()) == original, name
    manifest[name] = {
        "source_bytes": size, "source_sha256": digest, "artifact": artifact,
        "artifact_bytes": len(compressed),
        "artifact_sha256": hashlib.sha256(compressed).hexdigest(),
    }
receipt = {
    "recorded_utc": datetime.now(timezone.utc).isoformat(),
    "source_directory": source.relative_to(root).as_posix(),
    "count": len(manifest), "source_bytes": sum(row["source_bytes"] for row in manifest.values()),
    "compressed_bytes": sum(row["artifact_bytes"] for row in manifest.values()),
    "all_decompressed_bytes_equal_originals": True, "files": manifest,
}
with (destination / "archive-manifest.json").open("x") as stream:
    json.dump(receipt, stream, indent=2)
    stream.write("\n")
with (destination / "omitted-artifacts.json").open("x") as stream:
    json.dump({
        "count": len(omitted), "bytes": sum(row["bytes"] for row in omitted.values()),
        "files": omitted,
    }, stream, indent=2)
    stream.write("\n")
print(json.dumps({key: value for key, value in receipt.items() if key != "files"}))
print(json.dumps({"omitted_compiled_copies": len(omitted), "bytes": sum(row["bytes"] for row in omitted.values())}))
