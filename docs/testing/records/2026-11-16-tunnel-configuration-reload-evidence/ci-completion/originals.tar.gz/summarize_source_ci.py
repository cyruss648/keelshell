"""Derive exact-source CI facts from complete logs without replaying tests."""

import argparse
from collections import Counter
import importlib.util
import json
from pathlib import Path
import re

BASE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("sealed_parser_r3", BASE / "summarize_ci_r3.py")
parser_r3 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(parser_r3)


def emitted_objects(text, key):
    decoder = json.JSONDecoder()
    found = []
    needle = '{"' + key + '":'
    for line in text.splitlines():
        offset = line.find(needle)
        if offset >= 0:
            value, _ = decoder.raw_decode(line[offset:])
            found.append(value[key])
    return found


def preflight(text, package, target):
    marker = f"##[group]Run $listing = & cargo test --locked -p {package} {target} -- --list"
    offset = text.index(marker)
    end = text.find("\n##[group]Run ", offset + len(marker))
    block = text[offset:end if end >= 0 else None]
    inventory = re.findall(r"^([\w:]+): test$", block, re.M)
    # RESULT is line-anchored; apply it line by line.
    results = [
        list(match.groups()) for line in block.splitlines()
        if (match := parser_r3.RESULT.search(line))
    ]
    assert len(inventory) == len(set(inventory))
    assert len(results) == len({name for name, _ in results})
    assert set(inventory) == {name for name, _ in results}
    summaries = [match.groups() for match in parser_r3.SUMMARY.finditer(block)]
    assert len(summaries) == 1
    counts = Counter(outcome for _, outcome in results)
    assert [counts[k] for k in ("ok", "FAILED", "ignored")] == [
        int(x) for x in summaries[0][1:4]
    ]
    return {
        "inventory": inventory, "results": results, "counts": dict(counts),
        "summary": list(summaries[0]), "inventory_mismatches": [],
    }


def summarize(log, platform):
    raw = log.read_bytes()
    text = parser_r3.normalize(raw)
    offset = text.index("##[group]Run python scripts/check.py")
    end = text.find("\n##[group]Run ", offset + 10)
    gate = text[offset:end if end >= 0 else None]
    # Later Rust tests also launch a separate Python archive-helper suite.
    # Attribute only the initial discovery's summary to this phase.
    python = gate.split("Running: cargo fmt --all --check\n", 1)[0]
    ran = re.findall(r"^Ran (\d+) tests? in ([\d.]+)s$", python, re.M)
    assert len(ran) == 1, ran
    python_states = re.findall(r"^(OK(?: \(.*\))?|FAILED \(.*\))$", python, re.M)
    assert len(python_states) == 1, python_states
    report = {
        "log": log.name,
        "raw_bytes": len(raw),
        "raw_sha256": parser_r3.hashlib.sha256(raw).hexdigest(),
        "platform": platform,
        "python": {
            "run": int(ran[0][0]), "seconds": float(ran[0][1]),
            "summary": python_states[0],
        },
        "tree_controls": emitted_objects(python, "actual_preparation_controls"),
        "job_preparation": emitted_objects(python, "actual_native_job_barrier_preparation"),
        "job_barrier": emitted_objects(python, "actual_native_job_barrier"),
        "tests_replayed": 0,
    }
    if "Running: cargo test --workspace --locked -- --test-threads=4\n" in gate:
        workspace = parser_r3.summarize(raw)
        report["workspace"] = workspace
        report["ordinary_rust"] = {
            k: sum(row["summary"][k] for row in workspace["suites"])
            for k in ("passed", "failed", "ignored")
        }
        report["rustdoc"] = {
            k: sum(row["summary"][k] for row in workspace["doctest_runs_unassigned"])
            for k in ("passed", "failed", "ignored")
        }
        report["app"] = next(
            row for row in workspace["suites"] if "keelshell_app-" in row["suite"]
        )
    else:
        report["workspace"] = "NOT_RUN"
    if platform == "windows":
        report["archive_preflight"] = preflight(text, "keelshell-core", "--test archive")
        report["session_preflight"] = preflight(text, "keelshell-session", "--lib")
    return report


def main():
    options = argparse.ArgumentParser(description=__doc__)
    options.add_argument("platform", choices=["windows", "macos", "ubuntu"])
    options.add_argument("log", type=Path)
    options.add_argument("output", type=Path)
    args = options.parse_args()
    report = summarize(args.log, args.platform)
    with args.output.open("x") as output:
        json.dump(report, output, indent=2)
        output.write("\n")
    print(json.dumps({
        "platform": args.platform,
        "python": report["python"],
        "ordinary_rust": report.get("ordinary_rust", "NOT_RUN"),
        "rustdoc": report.get("rustdoc", "NOT_RUN"),
        "tree_control_groups": len(report["tree_controls"]),
        "job_barrier_groups": len(report["job_barrier"]),
        "tests_replayed": 0,
    }))


if __name__ == "__main__":
    main()
