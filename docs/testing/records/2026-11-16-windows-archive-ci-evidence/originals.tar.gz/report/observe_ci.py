"""Observe only the authorized attempt; append receipts within the fixed deadline."""

from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time


BASE = Path(__file__).resolve().parents[1]
ROOT = BASE.parents[1]
SPEC = json.loads((BASE / "report/deadline.json").read_text())
DEADLINE = datetime.fromisoformat(SPEC["deadline_at_utc"]).timestamp()
SHA = SPEC["source_sha"]
RUN = SPEC["run_id"]
REPO = "repos/cyruss648/keelshell"
JOBS = {
    "windows": 133098539513,
    "macos": 133098539273,
    "ubuntu": 133098539119,
}
ANSI = re.compile(
    rb"\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)"
    rb"|\x1b\[[0-?]*[ -/]*[@-~]"
    rb"|\x1b[@-_]"
)


def now():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, value):
    with path.open("x") as output:
        json.dump(value, output, indent=2)
        output.write("\n")


def get(label, endpoint, raw_log=False):
    available = DEADLINE - time.time()
    if available <= 0:
        return {"label": label, "not_started_deadline": True}
    timeout = min(25.0 if raw_log else 12.0, available)
    suffix = ".raw.log" if raw_log else ".response.json"
    output_path = BASE / "originals" / (label + suffix)
    error_path = BASE / "originals" / (label + ".stderr.log")
    command = ["gh", "api", "--method", "GET"]
    if raw_log:
        command.append("--allow-escape-sequences")
    command.append(endpoint)
    started = time.monotonic()
    receipt = {
        "label": label,
        "started_at_utc": now(),
        "command": command,
        "timeout_seconds": timeout,
    }
    environment = dict(os.environ)
    environment.update(
        GH_PROMPT_DISABLED="1",
        GH_NO_UPDATE_NOTIFIER="1",
        GH_PAGER="cat",
        GIT_OPTIONAL_LOCKS="0",
    )
    with output_path.open("xb") as output, error_path.open("xb") as error:
        child = subprocess.Popen(
            command,
            cwd=ROOT,
            env=environment,
            stdout=output,
            stderr=error,
            start_new_session=True,
        )
        try:
            code = child.wait(timeout=timeout)
            timed_out = False
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            code = child.wait()
            timed_out = True
    payload = output_path.read_bytes()
    receipt.update(
        ended_at_utc=now(),
        elapsed_seconds=round(time.monotonic() - started, 6),
        exit_code=code,
        timed_out=timed_out,
        reaped=True,
        stdout_path=str(output_path.relative_to(BASE)),
        stdout_bytes=len(payload),
        stdout_sha256=hashlib.sha256(payload).hexdigest(),
        stderr_bytes=error_path.stat().st_size,
    )
    if raw_log and code == 0 and payload:
        plain = ANSI.sub(b"", payload)
        # Preserve CR/LF and tabs, while excluding other terminal controls.
        plain = bytes(value for value in plain if value >= 32 or value in (9, 10, 13))
        plain_path = BASE / "report" / (label + ".no-ansi.log")
        with plain_path.open("xb") as output:
            output.write(plain)
        receipt.update(
            no_ansi_path=str(plain_path.relative_to(BASE)),
            no_ansi_bytes=len(plain),
            no_ansi_sha256=hashlib.sha256(plain).hexdigest(),
        )
    write_json(BASE / "report" / (label + ".receipt.json"), receipt)
    if not raw_log and code == 0:
        try:
            receipt["response"] = json.loads(payload)
        except json.JSONDecodeError:
            receipt["invalid_json"] = True
    return receipt


def main():
    existing = sorted((BASE / "report").glob("snapshot-*.json"))
    sequence = int(existing[-1].stem.rsplit("-", 1)[1]) + 1 if existing else 1
    logs_done = set()
    for path in (BASE / "report").glob("*-logs.receipt.json"):
        value = json.loads(path.read_text())
        if value.get("exit_code") == 0 and value.get("stdout_bytes", 0) > 0:
            for platform in JOBS:
                if f"-{platform}-logs" in path.name:
                    logs_done.add(platform)
    last = None
    while time.time() < DEADLINE:
        prefix = f"{sequence:04d}"
        requests = [
            (
                prefix + "-run",
                f"{REPO}/actions/runs/{RUN}/attempts/1",
            ),
            *[
                (prefix + "-" + name, f"{REPO}/actions/jobs/{job}")
                for name, job in JOBS.items()
            ],
        ]
        with ThreadPoolExecutor(max_workers=4) as pool:
            results = list(pool.map(lambda item: get(*item), requests))
        run = results[0].get("response", {})
        bound = (
            run.get("id") == RUN
            and run.get("head_sha") == SHA
            and run.get("run_attempt") == 1
        )
        summary = {
            "sequence": sequence,
            "observed_at_utc": now(),
            "exact_source_attempt_bound": bound,
            "run": {
                key: run.get(key)
                for key in ("id", "head_sha", "run_attempt", "status", "conclusion")
            },
            "jobs": {},
        }
        terminal = []
        for (platform, job_id), result in zip(JOBS.items(), results[1:]):
            job = result.get("response", {})
            job_bound = (
                job.get("id") == job_id
                and job.get("run_id") == RUN
                and job.get("run_attempt") == 1
            )
            summary["jobs"][platform] = {
                key: job.get(key)
                for key in (
                    "id",
                    "run_id",
                    "run_attempt",
                    "status",
                    "conclusion",
                    "started_at",
                    "completed_at",
                )
            }
            summary["jobs"][platform]["bound"] = job_bound
            summary["jobs"][platform]["steps"] = [
                {
                    key: step.get(key)
                    for key in ("number", "name", "status", "conclusion")
                }
                for step in job.get("steps", [])
            ]
            if bound and job_bound and job.get("status") == "completed":
                if platform not in logs_done:
                    terminal.append(platform)
        write_json(BASE / "report" / f"snapshot-{prefix}.json", summary)
        print(
            json.dumps(
                {
                    "sequence": sequence,
                    "utc": summary["observed_at_utc"],
                    "exact_source_attempt_bound": bound,
                    "run_status": run.get("status"),
                    "run_conclusion": run.get("conclusion"),
                    "jobs": {
                        name: [value.get("status"), value.get("conclusion")]
                        for name, value in summary["jobs"].items()
                    },
                }
            ),
            flush=True,
        )
        if terminal:
            with ThreadPoolExecutor(max_workers=3) as pool:
                log_results = list(
                    pool.map(
                        lambda platform: (
                            platform,
                            get(
                                prefix + "-" + platform + "-logs",
                                f"{REPO}/actions/jobs/{JOBS[platform]}/logs",
                                True,
                            ),
                        ),
                        terminal,
                    )
                )
            for platform, result in log_results:
                complete = (
                    result.get("exit_code") == 0
                    and result.get("stdout_bytes", 0) > 0
                )
                if complete:
                    logs_done.add(platform)
                print(
                    json.dumps(
                        {
                            "platform": platform,
                            "log_saved": complete,
                            "exit_code": result.get("exit_code"),
                            "bytes": result.get("stdout_bytes"),
                        }
                    ),
                    flush=True,
                )
        last = summary
        all_terminal = all(
            value["bound"] and value.get("status") == "completed"
            for value in summary["jobs"].values()
        )
        if bound and all_terminal and len(logs_done) == len(JOBS):
            reason = "all_jobs_terminal_logs_saved"
            break
        remaining = DEADLINE - time.time()
        if remaining <= 0:
            reason = "fixed_wall_clock_deadline"
            break
        time.sleep(min(30.0, remaining))
        sequence += 1
    else:
        reason = "fixed_wall_clock_deadline"
    write_json(
        BASE / "report" / "observer-final.json",
        {
            "ended_at_utc": now(),
            "stop_reason": reason,
            "deadline_at_utc": SPEC["deadline_at_utc"],
            "deadline_extended": False,
            "logs_saved": sorted(logs_done),
            "last_snapshot": last,
        },
    )
    print(json.dumps({"observer_stopped": reason, "logs_saved": sorted(logs_done)}), flush=True)


if __name__ == "__main__":
    main()
