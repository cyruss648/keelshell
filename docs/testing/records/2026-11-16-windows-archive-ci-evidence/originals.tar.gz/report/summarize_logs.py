"""Extract actual test receipts without printing log paths, payloads or controls."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re


BASE = Path(__file__).resolve().parents[1]
STAMP = re.compile(r"(?m)^\d{4}-\d\d-\d\dT[0-9:.]+Z ?")
RUST_RESULT = re.compile(
    r"test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; "
    r"(\d+) ignored; (\d+) measured; (\d+) filtered out; finished in ([0-9.]+)s"
)
TARGET = re.compile(
    r"(?:Running (?:unittests|tests/)[^\n]*|Doc-tests [A-Za-z0-9_-]+)"
)
SECRETS = re.compile(
    r"(?i)(?:github_pat_[A-Za-z0-9_]+|gh[pousr]_[A-Za-z0-9_]+"
    r"|sk-(?:proj-)?[A-Za-z0-9_-]{16,}"
    r"|(?:authorization|private-token|password|api_key)\s*[:=]\s*\S+)"
)
WINDOWS_PATH = re.compile(r"""(?:\\\\\?\\)?[A-Za-z]:[\\/][^\s"'<>]*""")
POSIX_PATH = re.compile(r"""(?<![\w:])/(?:Users|home|tmp|private|var|opt|mnt|__w)/[^\s"'<>]*""")


def redact(text):
    text = SECRETS.sub("[REDACTED_SECRET]", text)
    text = WINDOWS_PATH.sub("[REDACTED_PATH]", text)
    return POSIX_PATH.sub("[REDACTED_PATH]", text)


def main():
    previous = sorted((BASE / "report").glob("log-summary-r*.json"))
    sequence = int(previous[-1].stem.split("-r")[1]) + 1 if previous else 1
    result = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_sha": "76b8253acd9bfa62180563f482e851064bc1ea34",
        "run_id": 43806549649,
        "attempt": 1,
        "platforms": {},
    }
    for platform in ("windows", "macos", "ubuntu"):
        logs = sorted((BASE / "report").glob(f"*-{platform}-logs.no-ansi.log"))
        if not logs:
            continue
        path = logs[-1]
        raw = path.read_bytes()
        text = STAMP.sub("", raw.decode("utf-8", errors="replace"))
        headers = list(TARGET.finditer(text))
        rust_results = []
        for match in RUST_RESULT.finditer(text):
            header = next(
                (h.group(0) for h in reversed(headers) if h.start() < match.start()),
                "UNKNOWN",
            )
            # Target names are extracted separately from machine-specific paths.
            target_match = re.search(
                r"keelshell[_-](?:app|core|session|ai|mcp|platform)(?:-[a-f0-9]+)?",
                header,
            )
            rust_results.append(
                {
                    "target": target_match.group(0) if target_match else redact(header),
                    "result": match[1],
                    "passed": int(match[2]),
                    "failed": int(match[3]),
                    "ignored": int(match[4]),
                    "measured": int(match[5]),
                    "filtered_out": int(match[6]),
                    "seconds": float(match[7]),
                    "line": text[: match.start()].count("\n") + 1,
                }
            )
        failures = sorted(
            set(
                re.findall(
                    r"(?m)^\s*test ([A-Za-z0-9_:]+) \.\.\. FAILED\s*$",
                    text,
                )
            )
        )
        diagnostics = [
            redact(line.strip())
            for line in text.splitlines()
            if "archive preparation must produce a full immutable review:" in line
        ]
        archive_tests = []
        for name, status in re.findall(
            r"(?m)^\s*test ([A-Za-z0-9_:]*::archive_tests::[A-Za-z0-9_]+) "
            r"\.\.\. (ok|FAILED|ignored)(?:[^\n]*)$",
            text,
        ):
            archive_tests.append({"name": name, "status": status})
        contexts = []
        for match in re.finditer(r"(?m)^failures:\s*$", text):
            following = text[match.start() :]
            end = re.search(r"(?m)^test result: FAILED[^\n]*", following)
            if end:
                contexts.append(redact(following[: end.end()]) + "\n")
        context_path = BASE / "report" / f"{platform}-failure-contexts-r{sequence:02d}.redacted.log"
        with context_path.open("x") as output:
            output.write("\n".join(contexts))
        result["platforms"][platform] = {
            "log_path": str(path.relative_to(BASE)),
            "log_bytes": len(raw),
            "log_sha256": hashlib.sha256(raw).hexdigest(),
            "rust_results": rust_results,
            "failed_test_names": failures,
            "archive_test_results": archive_tests,
            "safe_archive_diagnostics": diagnostics,
            "python_counts": re.findall(r"(?m)^Ran (\d+) tests? in ([0-9.]+)s", text),
            "python_outcomes": re.findall(
                r"(?m)^(?:OK(?: \(skipped=\d+\))?|FAILED \([^\n]*\))$", text
            ),
            "failure_context_path": str(context_path.relative_to(BASE)),
            "failure_context_sections": len(contexts),
        }
    output_path = BASE / "report" / f"log-summary-r{sequence:02d}.json"
    with output_path.open("x") as output:
        json.dump(result, output, indent=2)
        output.write("\n")
    print(
        json.dumps(
            {
                "summary": output_path.name,
                "platforms": {
                    name: {
                        "rust_result_blocks": len(value["rust_results"]),
                        "failed_test_count": len(value["failed_test_names"]),
                        "archive_results": len(value["archive_test_results"]),
                        "diagnostic_count": len(value["safe_archive_diagnostics"]),
                    }
                    for name, value in result["platforms"].items()
                },
            }
        )
    )


if __name__ == "__main__":
    main()
