# Windows archive diagnosis follow-up

- Exact source: `76b8253acd9bfa62180563f482e851064bc1ea34`.
- Repository: `cyruss648/keelshell`.
- Quality run: `43806549649`, attempt `1`.
- Windows job: `133098539513`.
- macOS job: `133098539273`.
- Ubuntu job: `133098539119`.
- Fixed start: `2026-11-16T05:03:58.119697+00:00`.
- Fixed deadline: `2026-11-16T05:33:58.119697+00:00`.
- Total wall-clock allowance: 1,800 seconds. It cannot be extended.

The authorized output root is this task directory. All writes, including
observation scripts, numbered API responses, receipts, original source files,
derived log reports and any candidate belong under this root. The formal
checkout and its Cargo target remain owned by the parent.

Read before investigation:

- `/Users/hdh/.codex/RTK.md`.
- Root `AGENTS.md`.
- Current November 16 section of `docs/HANDOFF.md`, including the exact source
  and active Quality run.
- `docs/testing/SHARED_TARGET.md`.
- Parent observation wrapper
  `work/archive-diagnostics-ci-20261116/run_command.py`, for reference only.
- Rust best-practices skill and the relevant coding, error, testing and
  documentation references.

The observer uses explicit `gh api --method GET`, with a 12-second bound per
status GET and a 25-second bound per log GET, shortened to the fixed remaining
allowance. Independent status reads run concurrently. A completed observation
cycle is followed by a sleep of at most 30 seconds. Each response and receipt
uses a new numbered filename; previous outputs are preserved.

Before a log download, the observer verifies the run ID, source SHA and
attempt, and checks the job's run ID and attempt. Terminal job logs are fetched
using `--allow-escape-sequences` and retained as original bytes. ANSI-free
copies are separate files. Log bodies, machine paths and secrets are excluded
from terminal output. Derived failure contexts redact machine paths and
credential-like text.

No Cargo, rustfmt, clean, commit, push, cancellation, rerun, user chat, new
worktree or additional agent is authorized in this task. Candidate validation
therefore cannot establish compilation, test execution, full gates, independent
review or Windows native acceptance. The parent owns subsequent compilation
and a new non-author review.

`source-baseline.json` binds the ten app archive files to the exact source and
records their matching working-copy bytes before investigation.
`archive-contract-baseline.json` records every top-level function body,
including all ten original active tests, two diagnostic tests and the separate
unsupported-platform test. Any candidate must preserve the existing tests and
their safety assertions, with no skips, retries, added waits, fabricated review
or substituted backend. A source change requires confirmation from the new
diagnostic evidence together with the exact code.
