# Windows archive 审核失败：限定源码调查

结论：**根因 UNKNOWN；仅交付诊断候选，不是修复。** 精确对象为
`80647edca4baa1a07532f328849f24d43819e864` /
Quality `43797131194` / attempt `1` / Windows job `133068379697`。
调查已停止；后续编译、非作者评审与真实 Windows 诊断由父任务下一批完成。

## 能证实的范围

- 八项失败均在 `crates/keelshell-app/src/files/archive_tests.rs:93–103`
  的 `reviewed()` 分支：没有观察到 `pending = TransferArchive(plan)`。
  尚未进入该次审核之后的确认步骤。现有 panic 没有记录实际 pending 类型、
  status、底层错误或 errno。
- 五项测试涉及上传，三项涉及下载解包。上传夹具已找到本地条目，
  下载夹具已找到远端条目，并派发选择点击；选择是否最终生效没有独立前置断言。
  `transfer_tests.rs:209–213` 只等待 `!busy`；`:234–240` 的点击 helper
  没有独立断言按钮已启用。不能把“未超时”解释为准备已成功启动。
- `archive.rs:153–231` 存在可直接返回或拒绝草稿/选择的入口；
  `files.rs:1753–1755` 可记录 worker 启动失败；
  `:1838–1851`、`:1976–1982` 可拒绝过期结果；
  `:2144–2154` 会把只读准备错误保存到 status。
  旧 helper 丢失了这些分支的区别，日志无法再缩小到其中某一个。
- `archive_draft_change_and_retired_session_reject_review` 与
  `archive_pending_write_cancel_retains_close_hold_across_another_verified_upload`
  各有两处 `reviewed()` 调用。旧日志不能区分第一次、第二次失败，
  因而不能断言所有失败前都没有发生过其他写入。
- session 准备先进行远端观察，再分别进入本地扫描或目的目录观察
  （`sftp/archive_transfer.rs:246–305`）。Windows 两个方向都会经过
  `local_windows.rs` 的路径/祖先句柄观察，但没有证据证明执行已到达那里。
  路径、权限、原生目录枚举、对象身份变化与 UI 准入仍是待区分的假说。
- extended-drive 支持、夹具 canonicalize、SFTP POSIX 路径处理不是已确认根因。
  成功 barrier 中的 `winerror=1816` 也不是这八项测试的错误码。

## 诊断候选

`archive-review-diagnostics.patch` 只修改 `archive_tests.rs`：233 行新增、
4 行删除，无生产源码改动。候选副本在 `candidate/crates/keelshell-app/src/files/`。

保留原有三项完整审核断言和全部既有测试正文。失败时增加 busy、operation
是否存在、精确 pending 变体名、会话/目录/本地 listing、选择计数、隔离/关闭保持、
atomic write 计数，以及审核按钮存在性、可见性、disabled 和 bounds。
`#[track_caller]` 让最终缺少审核的 panic 指向实际调用处。

status 仅输出固定分类标签；只对 I/O/worker 启动错误提取受限十进制
`(os error N)` 尾缀。不输出路径、输入值、审核正文、成员内容、凭据、SID、
句柄或远端文本。数字名为 `display_os_error`，不是保留的 typed `raw_os_error`；
`None` 不代表底层没有原生错误。另附两项尚未执行的诊断隐私/分类回归。

下一次输出 `review-error` 才能支持后台准备返回错误；`archive-binding-expired`
或 `browser-review-expired` 支持审核被撤销。其他标签、选择计数和按钮状态用于
继续区分入口未准入。即使取得数字错误码，也不能单独认定具体失败的 syscall。
候选没有增加等待、skip、自动重试或放宽安全断言。

## 校验与边界

- 17 份相关源码已从精确 CI 提交只读导出；再次读回均与父当前
  `9d0f886acda4e48058004a28f85ef1fa3c510d4c` 的工作区文件相同。
  补丁通过 Python 文本应用、反向还原、原测试正文/断言保持及尾空白检查。
  这些只证明文本适用性，不证明 Rust 类型、格式或运行正确性。
- **Cargo/rustc/rustfmt、Rust 测试、target、UI、真实 Windows 均未运行或访问。**
  本轮实际 Rust 测试执行数为 0；没有占用 Cargo、下载日志、Git mutation、
  提交、推送、创建会话或后台任务。仅写入本调查目录。
- CI 来源已改为
  `docs/testing/records/2026-11-16-command-composer-focus-evidence/raw/ci-followup/ci-observer/`。
  已核对封存的 report、analysis 与去 ANSI 日志；后者解压后 SHA-256 为
  `0a6cf7c960ef7420fb7445014398176261654537539c528c9421df2a56d03259`，
  493837 字节、3837 行、ESC 为 0。不再依赖旧 `work/platform-ci-followup-*`。
- `baseline.json` 保留来源/摘要；`static-checks.json` 保留实际静态检查；
  `expected-new-tests.txt` 是待编译回归名；`sha256.json` 是交付文件清单。
  **建议仅作为诊断候选集成，待父编译、评审和真实 Windows 运行；不能关闭故障。**

补丁 SHA-256：
`ea240445e8c93d337d2a6b9e8bda75607433e6b19de861e72176ea97bc54f745`
