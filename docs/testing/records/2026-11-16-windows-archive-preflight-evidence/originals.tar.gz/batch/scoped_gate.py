import subprocess,sys
commands = [
 ["cargo","fmt","--all","--check"],
 [sys.executable,"scripts/check.py","--policy-only"],
 ["cargo","clippy","--workspace","--all-targets","--locked","--","-D","warnings"],
 ["cargo","test","--locked","-p","keelshell-app","files::transfer_tests::archive_tests::","--","--list"],
 ["cargo","test","--locked","-p","keelshell-app","files::transfer_tests::archive_tests::","--","--test-threads=1"],
 ["cargo","test","--locked","-p","keelshell-session","--lib","sftp::archive_transfer::local::tests::","--","--list"],
 ["cargo","test","--locked","-p","keelshell-session","--lib","sftp::archive_transfer::local::tests::","--","--test-threads=1"],
]
for command in commands:
 print("Running: " + " ".join(command),flush=True)
 result=subprocess.run(command)
 if result.returncode: sys.exit(result.returncode)
