"""Seal the owned diagnostics and the completed prior CI without rewriting originals."""
import gzip,hashlib,io,json,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
BATCH=Path(__file__).resolve().parent
EVIDENCE=ROOT/"docs/testing/records/2026-11-16-windows-archive-preflight-evidence"
CI=ROOT/"work/workbench-fit-20261116"
files={}
for path in sorted(BATCH.rglob("*")):
 if path.is_file() and path.suffix in (".py",".json",".log",".diff"):
  files["batch/"+path.relative_to(BATCH).as_posix()]=path
# The complete three source snapshots include extensions outside the evidence suffixes.
for path in sorted((BATCH/"source-r1").rglob("*")):
 if path.is_file(): files["batch/"+path.relative_to(BATCH).as_posix()]=path
for name in ("windows-extraction-stage-candidate-20261116","windows-archive-preflight-review-20261116"):
 folder=ROOT/"work"/name
 assert folder.is_dir(),name
 for path in sorted(folder.rglob("*")):
  if path.is_file(): files[name+"/"+path.relative_to(folder).as_posix()]=path
for name in ("source-ci-final-r1","source-ci-watch-r1","source-ci-snapshot-r2",
             "macos-job-log-r1","ubuntu-job-log-r1","windows-job-log-r1"):
 for extension in (".json",".log"):
  path=CI/(name+extension); assert path.is_file(); files["ci/"+path.name]=path
for name in ("source-ci-summary-r1.json","windows-failure-summary-r1.json",
             "macos-job-log-r1.clean.txt","ubuntu-job-log-r1.clean.txt","windows-job-log-r1.clean.txt"):
 files["ci/"+name]=CI/name
files["tools/verify.py"]=EVIDENCE/"verify.py"
data={name:path.read_bytes() for name,path in sorted(files.items())}
rows=[{"path":name,"source_path":files[name].relative_to(ROOT).as_posix(),"bytes":len(raw),
       "sha256":hashlib.sha256(raw).hexdigest()} for name,raw in data.items()]
output=io.BytesIO()
with gzip.GzipFile(fileobj=output,mode="wb",mtime=0) as zipped:
 with tarfile.open(fileobj=zipped,mode="w",format=tarfile.PAX_FORMAT) as archive:
  for name,raw in data.items():
   entry=tarfile.TarInfo(name);entry.size=len(raw);entry.mode=0o644;entry.mtime=0
   archive.addfile(entry,io.BytesIO(raw))
packed=output.getvalue()
manifest={"schema":"keelshell.windows-archive-preflight.evidence.v1",
 "baseline_source":"6f0eb4c3827026807b38cb53d6f1681a64b3847c",
 "engineering_sha256":json.loads(data["batch/inputs-freeze-r1.json"])["aggregate_sha256"],
 "count":len(rows),"archive_bytes":len(packed),"archive_sha256":hashlib.sha256(packed).hexdigest(),
 "uncompressed_bytes":sum(row["bytes"] for row in rows),"entries":rows,
 "windows_native":"NOT_RUN","prior_ci":"failure","native_ui":"BLOCKED_MAC_LOCKED",
 "excluded":["target","application binaries","runtime","unrelated browser inventory"]}
for name in ("manifest.json","originals.tar.gz"): assert not (EVIDENCE/name).exists()
(EVIDENCE/"originals.tar.gz").write_bytes(packed)
(EVIDENCE/"manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
print(json.dumps({k:v for k,v in manifest.items() if k!="entries"}))
