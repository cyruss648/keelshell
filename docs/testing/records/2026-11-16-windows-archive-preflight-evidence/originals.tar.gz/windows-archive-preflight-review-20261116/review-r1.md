**Windows 归档预检 r1 — 新非作者严格只读评审与功能复核**

**结论：APPROVE 本批三文件未提交增量的静态范围，建议接纳候选。P0/P1/P2/P3 均为 0。Windows 类型检查、当前候选 Windows 实际执行及完整 Windows gate 继续 HOLD。**

评审时间 `2026-11-16T19:00:03.237284+08:00`。工作区 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`。起止 HEAD `6f0eb4c3827026807b38cb53d6f1681a64b3847c`；候选 SHA 与初始 `candidate-three-files-r1.json` 三项完全一致，实际三文件 diff 与 `candidate-r1.diff` 逐字节相等，74 行新增、2 行替换。此结论没有 Windows native 通过签署。

| 级别 | 开放数量 | 文件/行、触发与影响 |
| --- | ---: | --- |
| P0 | 0 | 无发现 |
| P1 | 0 | 无发现 |
| P2 | 0 | 无发现 |
| P3 | 0 | 无发现 |

**范围与精确绑定**

| 文件 | SHA-256 |
| --- | --- |
| .github/workflows/ci.yml | `029b8b955380a86d31da88a5b6c94f82c15d532b7ca482f9b15088c3083f60ab` |
| crates/keelshell-app/src/files/archive_tests.rs | `7e195be17fdb2b03628b6cb7e7ea191e86acbc6c2399906db7824b94426a15f4` |
| crates/keelshell-session/src/sftp/archive_transfer/local_windows/tests.rs | `48d59382ddb1096e10a7a84e458b5df01796c1567e216c52de3ef3a409b25fbb` |

候选 diff SHA-256 `1f8f104a4daf2acc022b8f3eaca17abc213964425a62391eefa35ac15e196ee2`。已独立只读核对冻结中的 719 项路径、字节数与 SHA，mismatch 0；按仓库 `sorted path + NUL + sha256 + LF` 规则重算聚合 `a86f82425764c4fcec2341c2bf47dc4e91be486039d60eb1a60c50256688606a`，与父冻结和 summary 一致。冻结绑定不扩大代码评审范围。

评审期间，父文档准备使 `docs/HANDOFF.md`、`docs/ROADMAP.md`、`docs/product/CAPABILITIES.md` 另外出现在 dirty paths 中。这三份文档不是本人的写入，不纳入签署；本报告只评审用户指定的三个文件。

已读 RTK、祖先/仓库 AGENTS、HANDOFF、SHARED_TARGET、rust-best-practices 第 1/2/4/5/8 章。本人 Cargo/fmt/Clippy/Rust 测试/PowerShell/Windows native/GPUI 原生执行均 **0**，未重做父测试，未编辑工程文件、提交、推送、清理、切换 checkout 或操作共享 target。只在授权评审目录写本报告与两份静态回执。

**重点复核：以下是核查结果，不是缺陷项**

| 复核点 | 文件/行 | 触发与影响、结论 |
| --- | --- | --- |
| 原生命令退出码 | [ci.yml:39](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/.github/workflows/ci.yml:39)、40、50、51 | 列库存返回非 0 时立即 `exit $LASTEXITCODE`；执行测试后同样立即交回原退出码。中间没有其它原生命令覆盖状态。Cargo 失败不会被循环或普通输出改成成功。 |
| 0 例库存与必需用例 | [ci.yml:43](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/.github/workflows/ci.yml:43)、44、46–47 | 即使 Cargo exit 0，空库存、错误模块或缺任一关键用例，都会缺少至少一条完整的 `name: test` 行；大小写敏感 `-cnotcontains` 后 `throw`，避免 0 例假绿。两个必需全名精确对应当前未 ignored 的 tokio 用例。 |
| 执行 filter 与 gate | [ci.yml:35](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/.github/workflows/ci.yml:35)、39、50–53 | Windows-only、显式 pwsh；列库存与执行都使用 `--locked -p keelshell-session --lib sftp::archive_transfer::local::tests::`。运行失败使 job 失败，后续普通 quality step 保持默认成功前置条件。无新增 skip、重试、错误忽略或强制继续。去除新增 step 后 workflow 全文等于 base。 |
| cfg Windows 模块路径 | [archive_transfer.rs:10](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/archive_transfer.rs:10)；[local_windows.rs:1062](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/archive_transfer/local_windows.rs:1062)；[tests.rs:1](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/archive_transfer/local_windows/tests.rs:1) | `cfg_attr(path=...)` 改源文件，模块名仍为 `local`，子模块仍为 `tests`。因此 filter 准确，不应按文件名使用 `local_windows::tests`。诊断只在 Windows test build 中存在。 |
| 固定日志是否泄漏 | [tests.rs:16](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/archive_transfer/local_windows/tests.rs:16)、23–52 | 输出只包含固定 Build/Publish 标签、实际 SessionError 变体名、Io 的 ErrorKind 与可选数值 raw OS code。20 个现有变体逐一对应，没有格式化错误 Display/Debug、source chain、动态消息或路径。非 Io 两字段 None。 |
| typed error 与安全断言 | [tests.rs:445](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/archive_transfer/local_windows/tests.rs:445)、458、459–476 | 两处只加借用 `&SessionError` 的 `inspect_err`，之后仍用原 `?` 传播。去掉新增 enum/logger 和两个 observer 后，整个 tests.rs 与 base 逐字节相等。私有权限、精确 bytes、空目录、staging 消失、root identity、reservation/隔离、fixture 与等待上限保持。 |
| 分类来源与因果边界 | [archive_tests.rs:225](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/archive_tests.rs:225)、304；[queue.rs:443](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/queue.rs:443) | 仅完整文本相等时分类 `queued-mutation-quarantined`；该固定文本实际来自 `Admission::Quarantined` 的 Failed terminal，经过 worker Failed→Transport 与原 status 包装。标签有真实既有源码来源；输出仍 redacted/None，不推断先前未知写入的根因、syscall 或修复成功。 |

app 移除一条匹配臂与一条回归输入后，原文件全部字节等于 base。所有原脱敏断言及安全状态保持。两个 Rust 文件均在 test-only 模块树中，本批没有生产 Rust 行为变更。

阶段标签只说明 `build_stage` / `publish_stage` 返回错误的边界。真实 typed Io 的 raw OS code 仍不能证明特定 syscall 或 NTSTATUS；app 的 `display_os_error` 仍只是原显示字符串后缀提取，原“不等于 typed error / syscall 证据”注释保持。

**静态回执与父执行证据分开**

最终 **36/36 项静态证据检查通过，失败 0**。内容是摘要、文本/控制流、反向逐字节还原及既有回执核对，不是编译或运行测试数。`git diff --check` exit 0，没有调用 formatter。逐项见 [static-receipt-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-archive-preflight-review-20261116/static-receipt-r1.json)。

| 来源 | 只读核对结果 | 可支持范围 |
| --- | --- | --- |
| 父 [scoped-gate-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-archive-preflight-integration-20261116/scoped-gate-r1.json) 与 [log:1](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-archive-preflight-integration-20261116/scoped-gate-r1.log:1) | observed/controller 0，direct_reaped true、active_processes 0、pipes_drained true；29.207744125 秒。6,176 字节及 SHA `5e6cc81e0847e060a9dd215891221438eefa508932e640980abe2ae07cdae1a9` 均与回执一致。 | 父串行 fmt/x.y/严格 workspace Clippy 通过。本人没有重跑。 |
| 父 scoped log [log:16](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-archive-preflight-integration-20261116/scoped-gate-r1.log:16)、41、61、69 | 独立从原 log 提取：app 列 13 名、执行 13/0/0；宿主 local 列 1 名、执行 1/0/0。14 名逐项相等、无重复、全部 ok；summary 一致。 | 当前宿主切片执行证据。宿主 local 一例不是 Windows backend，不能签 Windows 条件编译模块。 |
| 父 [windows-cross-clippy-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-archive-preflight-integration-20261116/windows-cross-clippy-r1.json) 与 [log:127](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-archive-preflight-integration-20261116/windows-cross-clippy-r1.log:127)、177 | observed/controller **101**，direct_reaped true、active_processes 0；6.879421416 秒。63,569 字节及 SHA `750ea34f5c5bfde2ab8f738571910094f6272bca3456288cfd8e44120876ea27` 一致。aws-lc-sys C build 缺 windows.h，探针另有缺 stdlib.h。 | **Windows session 目标类型检查未完成，Windows 实际执行 0**。保留失败，不能记为 cross-Clippy 通过。 |
| 用户补充的旧精确 8c CI | 用户报告 macOS/Ubuntu success + OpenSSH 绿，Windows 四败不变；本人未重新查询远端。 | 保留旧源码事实，不能移签当前未提交三文件候选。 |

父测试 log 另保留 `__eh_frame` compact unwind linker warning；父进程 exit 0 不应表述为完全没有 warning。

初轮静态检查器曾报告 44/46：一项把评审范围错误地等同于整个 dirty path 集合，另一项用子串 `error:?` 误匹配数值字段 `raw_os_error:?`。两者是检查器口径问题，已分别修正为显式三文件范围及完整插值字段检查；初轮原事实保留于 [static-check-attempt-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-archive-preflight-review-20261116/static-check-attempt-r1.json)，不列为源码缺陷，不改写成原轮通过。

**未验证与推荐边界**

Windows 源测试静态声明 29 项、其中 1 项保留 Developer Mode / symlink privilege 的既有 ignored；这是源声明数，不是 Windows 编译库存或运行结果。CI guard 要求两个关键完整名称出现，不宣称全 29 项库存逐名相等或 ignored 权限场景通过。新阶段诊断只加在嵌套树测试的 build/publish 两个返回点；fixture、中间 metadata、后续断言和空树用例保持原失败报告范围。

没有执行 PowerShell、Rust 编译/测试或实际 Windows runner，未验证当前候选精确 CI、Windows backend 类型检查成功、Windows 桌面、完整跨平台 gate 或发行验收。只读上下文定位不构成整库评审。后续精确 Windows CI 必须绑定本候选源码，读取编译库存及真实执行结果，并保留旧四败和本次 cross-Clippy 101。

**建议：接纳本批三文件候选，静态范围 APPROVE。Windows 类型检查/native 与完整 Windows gate 继续 HOLD。**

PowerShell、GitHub shell、Cargo filter/list 与 Rust inspect_err 的语义已对照官方文档，来源 URL 记录在 JSON 回执；文档语义核对不作为 native 执行证据。
