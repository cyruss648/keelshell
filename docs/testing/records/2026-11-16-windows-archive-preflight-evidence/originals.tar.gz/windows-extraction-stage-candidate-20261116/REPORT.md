# Windows 归档阶段诊断候选 — 2026-11-16

结论：按父最新收敛要求，仅增强既有 Windows nested-tree 单元用例的
build / publish 固定阶段诊断。新增等价测试模块已撤销，未修改生产逻辑，
未运行 Cargo、Clippy、GUI、Windows 测试、提交或 push。根因仍为 **UNKNOWN**。

## 最终改动及删减

唯一代码改动：

`crates/keelshell-session/src/sftp/archive_transfer/local_windows/tests.rs`

- 新增私有 `ExtractionStage::{Build, Publish}` 和 `extraction_stage_error`。
- 仅在既有
  `windows_archive_private_nested_tree_publishes_after_child_creation_handles_close`
  的 `build_stage`、`publish_stage` 调用后各加一个 `inspect_err`。
- 标签固定为 `build-stage`、`publish-stage`；输出固定 `SessionError` 变体名、
  `io::ErrorKind` 和 `raw_os_error`。非 I/O 错误的两个 I/O 字段均为 `None`。
  不输出错误 Display/Debug、错误 payload、路径、peer、内容或凭据。
- `inspect_err` 借用错误用于诊断，再由原来的 `?` 传播原始 `SessionError`；
  不包装为另一种错误，不把 UNKNOWN、隔离或失败转为成功。
- 原 Fixture、Lease、members、等待上限、断言、DACL/share/metadata 比较、
  identity 检查、句柄生命周期及 quarantine 处理全部保持原字节。

净代码差异为 48 行增加、2 行删除。两个删除行仅为添加方法链前的 `)?;`。

先前初稿的 `local_windows/extraction_stage_tests.rs` 没有必要的独特覆盖，
已删除；对应 `local_windows.rs` 新增模块声明也已撤销。
`local_windows.rs` 与基线逐字节相同。最终无第二套 Fixture/Lease、重复主流程、
NTFS 查询子进程、新服务器、新测试或新生产 API。

父负责 `.github/workflows/ci.yml` 的早期执行改动。本作者没有写入该文件，
也没有修改 app、文档入口、manifest、lockfile、target 或其他工作树。

## 预期用例与定位范围

本次诊断增强的精确用例名：

`sftp::archive_transfer::local::tests::windows_archive_private_nested_tree_publishes_after_child_creation_handles_close`

父要求早期库存检查的另一既有精确名：

`sftp::archive_transfer::local::tests::windows_archive_empty_private_tree_publishes_with_exact_root_identity`

完整静态预期名录保存在 `expected-tests.txt`，共 **29** 个源码声明，
其中 1 个原有 ignored；与基线逐项一致。不是编译库存或实际执行计数。

增强用例继续直接调用原私有函数，复用真实 `Reservation` / `MutationWorker`。
原成员仍是 Unicode nested 文件、显式空目录及零字节文件；不另建 app
`nested/data.bin = [1, 0, 254]` 的等价副本。原有成功断言继续检查完整字节、
空目录、DACL、staging 名消失、发布 root identity 和最终 reservation 完成。
新建/不覆盖、取消及未知交付继续由既有模块的其他用例覆盖。

若 `build_stage` 或 `publish_stage` 返回错误，新增日志可区分两阶段并保留
原 typed error / OS 数字。若失败发生在 prepare、后续独立 readback、
超时或 panic，仍使用原用例失败证据；这次两处诊断不宣称覆盖这些位置，
也不提供阶段内部 syscall 或新的 NTSTATUS 证据。

## 静态核验

基线：`8c07d61009dba14f989dd0c00a2a370dc7a2d37b`。
核验时共享 HEAD 已由并行父任务推进为
`6f0eb4c3827026807b38cb53d6f1681a64b3847c`，该提交为文档交付记录；
本作者没有执行提交。诊断代码在本次核验时仍是工作区修改。

`static-verification.json` 记录 13 项静态检查全部成立，包括：

- 删除诊断 helper 和两处 `inspect_err` 后，整个 `tests.rs` 精确还原基线字节。
  因此原用例正文、全部断言、Fixture/Lease 及隔离处理没有其他修改。
- 父生产文件与基线逐字节一致，新增模块文件不存在。
- 29 个源码测试名和 1 个 ignore 不变；当前 20 个 `SessionError` 变体均有固定名。
- 新诊断不格式化错误本身或动态 payload；两个阶段标签由私有枚举限定。
- 独立 `rustfmt --edition 2024 --check --config skip_children=true`：exit 0。
- 许可测试文件的 `git diff --check`：exit 0。

最终测试文件 SHA-256：
`48d59382ddb1096e10a7a84e458b5df01796c1567e216c52de3ef3a409b25fbb`。
原始差异为 `candidate.diff`；两个命令的完整空输出日志亦已保存。

## 未验证边界及父接续

- Cargo / cross-Clippy / Windows 实际执行均为 **0**，没有编译通过或原生通过结论。
  rustfmt 仅提供语法格式检查，不能代替类型检查。
- 不能据此确认实际临时卷为 NTFS、真实 app 解包已恢复、确认流程或窗口关闭
  已通过。`Authority`、SSH revalidation 和 app close hold 未在本轮执行。
- 本次不新增 quarantine、不清空其他测试的 quarantine，也不修改既有
  fixture cleanup。既有测试自身的临时目录及 UNKNOWN 生命周期语义不在
  本次修复范围；不把它们描述为已加强的持久取证保证。
- 原始失败归档与当前 `8c07d610…` 的 CI 状态不在本作者核验范围；
  不把未提交的诊断或父 workflow 修改移签为正在运行的 CI 输入。
- 父后续统一进行 cross-Clippy、本机 gate、独立评审和真实 Windows
  `--list` / 执行；使用 `expected-tests.txt` 核对名称，不能由 0 例或仅计数签绿。
  Windows 失败时应保留新增固定阶段行和原错误，不以 quarantine 为成功。

现有私有 API 足以完成本次最小阶段诊断，无需新增生产接口或 SSH fixture。
阶段内部更细粒度定位及真实 app 恢复仍须以父后续实际 Windows 结果为准。
