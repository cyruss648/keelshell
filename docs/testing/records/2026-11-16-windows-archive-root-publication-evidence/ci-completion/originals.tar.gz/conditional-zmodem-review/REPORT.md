**Windows Zmodem 父目录改名候选：新非作者静态评审**

日期：2026-11-16，Asia/Shanghai。评审者未参与 Meitner 候选编写；本次没有修改或集成候选。

结论：**当前提交形态 HOLD；两处正文方向可条件采用，采用前必须修正两处测试名称，并由父核对精确 Windows 日志及后续候选执行。** 开放发现为 P0=0、P1=0、P2=1、P3=0。在“后代保持打开、外层 rename 确实被拒绝”的前提下，候选没有放宽生产安全边界，也没有把任意错误当成成功；它改变了测试所证明的行为，不能继续声称证明“祖先已替换后的拒绝”。本评审没有取得新的 Windows session 失败或通过，不能将建议写成已确认根因、已修复或完整 Windows 通过。

父提供的活动上下文为 Quality `43859165104`、Windows job `133271138956`；这些编号只用于后续绑定。本评审未查询、等待、取消或重跑 CI，未读取父并行收集的后续日志，运行结果仍待父提供。

已读当前 `AGENTS.md`、`/Users/hdh/.codex/RTK.md`、`docs/HANDOFF.md`、`docs/testing/SHARED_TARGET.md`、ADR 0138/0148、产品 ZMODEM 文档，以及 `/Users/hdh/.agents/skills/rust-best-practices/SKILL.md` 和第 1、4、5、8、9 章。第 5.1 节要求名称准确表达状态及预期；第 1.6、8.2–8.5 节要求平台注释与实际契约相符。技能中的运行建议不覆盖用户本轮禁止执行 Rust/native 的限制。

**精确身份与复核范围。** 工作区为 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`。独立读回 HEAD=`9ad1cd92148ed3498a3e9882e707128e9c84b1b7`，其直接父提交为工程精确源码 `f094de6ad2789d168f5a24bacb316c98b83608ac`。两提交之间 15 个改动路径全部位于 `docs/`。开始时 tracked 工作区干净；受评测试及实现与 `git show f094de6:...`、作者 baseline 和回执逐字节一致。没有核查远端 tracking SHA，也没有重新执行全工程 719 输入冻结。

| 对象 | 独立核实身份 |
| --- | --- |
| 基线 `zmodem/local_windows/tests.rs` | Git blob `d9361c4166671058d0733b613d78d8dddab2e936`；SHA-256 `125a148b0ea76d8483411c30e9daa08566534c5152f193e39f62ddd2320d48e3` |
| 生产 `zmodem/local_windows.rs` | Git blob `9f8042f68b21b6e1e91801798cabdb89c3b8cc59`；SHA-256 `39cd38b4bb145ed55591e63f4016e479f38b06c5b0d5e8d41ce4d8e574ec2383` |
| 完整候选 tests.rs | SHA-256 `6ffd96fd35ace3a12324bc496ff7fcb678c3762f88d215e72355567fe3b80490` |
| `candidate.patch` | SHA-256 `9f57f8dbf82d7609c3cd18d1395544d7879a3496d6bdc19314f1bc6d093006f4` |
| 作者 REPORT.md | SHA-256 `5697477bef0778f51a684092026acafa15b97db034e48c1c0f21b5c6aaee75af` |
| 作者 source-receipt.json | SHA-256 `c06b32ad8a56c8948ad94fd870a8dbfa71ebb8e33aaaff35692678bf5804ff14` |

作者 artifact 索引中 7 个成员的哈希全部匹配。独立在内存中重放 patch 的两个 hunk，结果精确等于候选副本；另执行 `git apply --check --directory=work/windows-zmodem-parent-rename-candidate-20261116/baseline work/windows-zmodem-parent-rename-candidate-20261116/candidate.patch`，exit 0，没有应用补丁。45 个静态声明名称、顺序、属性保持；ignore 仍为 2，只有指定两处正文变化，其余 43 例与 helper/prefix 均字节相同。45/2 是源码声明数，不是本评审的编译或执行库存。

任务所称 `platform/windows_fs.rs` 在本精确工程的 crates Git 树中不存在，工作区根 `platform/windows_fs.rs` 亦不存在，不能假装审读该文件。本版实际边界为 [platform 导出](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/lib.rs:18)、[windows/mod.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/mod.rs:103)、[windows/native.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:94)。这三文件及平台 tests.rs、session zmodem.rs 共 5 个额外文件，均独立确认当前字节等于 `f094de6`；完整 blob/摘要见本目录 static-receipt.json。

**P2-01：两处名称仍表示不存在的替换及拒绝路径，采用前须改名。** 定位在候选 [tests.rs:249](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-zmodem-parent-rename-candidate-20261116/candidate/crates/keelshell-session/src/zmodem/local_windows/tests.rs:249) 与 [tests.rs:460](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-zmodem-parent-rename-candidate-20261116/candidate/crates/keelshell-session/src/zmodem/local_windows/tests.rs:460)，相关决定见作者 [REPORT.md:53](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-zmodem-parent-rename-candidate-20261116/REPORT.md:53)。

触发：两个测试在 rename 返回 PermissionDenied/raw 5 时继续，并要求 `plan.confirm` 成功；第一例完全没有建立替换对象，第二例也没有调用 `destination.publish`。名称却分别是 `confirmation_rejects_replaced_ancestor_even_with_same_bytes` 与 `reviews_reject_replaced_grandparent_with_original_leaf_and_source`。影响：后续 CI 按名称和旧库存记账时，会把操作系统阻止攻击的绿例误当成软件在实际替换后拒绝确认/发布的覆盖，掩盖被删除断言的证明边界。这是安全测试契约及验收证据问题；没有发现本候选引入生产行为漏洞。

建议分别改为以下准确名称，或含义等价的名称：

| 旧名 | 建议名 |
| --- | --- |
| `zmodem_upload_local_confirmation_rejects_replaced_ancestor_even_with_same_bytes` | `zmodem_windows_upload_review_blocks_ancestor_rename_while_source_is_open` |
| `zmodem_windows_reviews_reject_replaced_grandparent_with_original_leaf_and_source` | `zmodem_windows_reviews_block_grandparent_rename_with_open_leaf_and_source` |

不能为保持库存留下误导名字。保留旧日志/旧库存原件，为新版本另记两项旧→新映射、候选摘要及编译清单。静态声明总数可仍为 45，不能再将“名称完全不变”写进新回执。当前 scripts/.github 的源码搜索未发现这两旧名的显式引用；这不代替之后实际编译清单核对。Windows 文件路径虽然为 local_windows.rs，模块仍由 [zmodem.rs:24](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/zmodem.rs:24) 命名为 `local`，核对清单时应使用实际编译出的完整模块名。

**Windows 预期及实现关系。** 本次只读查阅官方资料 S1–S7；这是规范与源码分析，以下具体场景结论是基于持有关系的静态推导。

MS-FSA 2.1.5.15.12 要求目录改名前检查其下的 open，存在时拒绝为 STATUS_ACCESS_DENIED（S1）；2.1.4.2 从目录的 child links 开始并递归子树，检查现存 open，规则没有以 FILE_SHARE_DELETE 排除此检查（S2）。该算法 FALSE 表示存在 open，不能反向解读。NTFS 的 oplock 重检细节见附录 <186>（S3）。这是“后代仍打开”检查，不是“只要目录自身有句柄就一律不能改名”。

当前生产长期目录/源观察通过 [native.rs:94](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:94) 请求 FILE_GENERIC_READ、SHARE_ALL；目录不长期持有 DELETE。短期目录发布 lease 位于 [native.rs:359](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:359)，与这些测试的 std::fs::rename 前置攻击不同。源对象及 Parents 的保留防止身份复用，不能为了让攻击前置步骤成功而提前 drop。

Rust 官方 rename 文档说明 Windows 使用 MoveFileExW 并存在 SetFileInformationByHandle 回退（S5）。对照 1.100.0 标准库 rename 实现，ACCESS_DENIED 会尝试 FileRenameInfoEx，失败时通常保留原错误（S6）；该版本仅作静态对照，本评审未核验 CI runner 工具链。POSIX rename 标志对“已有目标”的替换语义不能推出源目录可带打开后代改名（S7）；两例 retained 本应缺席。raw OS 5 是 ERROR_ACCESS_DENIED（S4），但单个 raw 5 不能证明它来自某个特定 NT syscall，亦不能区分权限失败与后代检查。故两例的精确错误断言合理，但当前 run 的实际返回仍须由父核对，不能移签已过的平台预检。

| 场景及行号 | 实际持有关系、应验证行为及安全影响 |
| --- | --- |
| 基线 249–265；候选 249–273；rename 基线 257 / 候选 260 | `UploadPlan` 持有 Parents 及 `Source.descriptor`，即 reviewed/source.txt 的实际打开对象。见 [local_windows.rs:29](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/zmodem/local_windows.rs:29)、[local_windows.rs:156](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/zmodem/local_windows.rs:156)。在该 Windows 规则下，reviewed→retained 应被阻止；目录未替换时要求 confirm SourceChanged 没有成立条件。候选要求 kind=PermissionDenied 且 raw=5，意外成功立即报错；另验证 retained 缺席、完整祖先 stamps、命名源 ID、confirm 原字节及路径 readback。它验证攻击未生效且原审核仍有效，不验证替换后的拒绝。 |
| 基线 452–484；候选 460–497；rename 基线 464、466 / 候选 474 | plan 与 destination 各持有 leaf 及整条祖先链，plan 另持有 source.bin。outer 下已有打开后代，第一步 outer rename 即不应当作必然成功；即使假设第一步成功，第二步 leaf rename 仍有打开源文件，不能机械保留该成功假定。候选验证精确拒绝、两套完整祖先 stamps、原 source ID、leaf stamp、destination.revalidate、目标/staging 缺席、confirm/readback 原字节与 leaf 项数。结合检查是有效的，但没有分别证明 upload 和 destination 单独的阻止能力，也没有执行一次 publish。 |
| 基线 604–622；候选 617–635；rename 基线 611 / 候选 624 | prepare 只保留到空 reviewed 目录自身的链，以及两个尚未创建的名称；没有 Source、staging 或 target 后代句柄。[local_windows.rs:309](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/zmodem/local_windows.rs:309) 内 revalidate、枚举的临时对象返回时已释放，即便保留的 capability/clone 也是目录自身。后代检查的拒绝条件不成立，因此原 rename 成功前置仍应保留；不能把它也改成预期 raw 5。替换目录创建后，publish 必须 SourceChanged、mutated=false，且新旧两树均空。该例逐字节未变。 |

第三例是实际可达的“替换后的软件拒绝”场景。父链重验在 [local_windows.rs:138](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/zmodem/local_windows.rs:138) 比较新解析链与保留 stamps；publish 在 [local_windows.rs:366](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/zmodem/local_windows.rs:366) 先 revalidate，再 create_staging。新旧父 ID 不同应在设置 mutated 之前返回 SourceChanged。必须保留它对两树无写入的断言，并等待真实 Windows 执行；规范只说明它不因后代打开而被拒绝，不能替代完整权限/环境验收。

**是否削弱安全断言。** 两处确实删除了原 `confirm -> SourceChanged` 断言，第二处还删除了 `publish -> SourceChanged` 和 mutated=false；这不属于断言等价重写。原因是原祖先替换前置在当前持有策略下被 Windows 阻止，而非允许软件忽略真实替换。候选没有降低源/祖先保留、权限、DACL、元数据、no-replace、mutation/quarantine 或最终读回的生产要求，也没有增加 skip、延时、重试、成功/失败任选的分支。严格两项错误断言比 `.is_err()` 更窄。

未改 43 例仍包含同字节叶文件替换、硬链接重绑定、私有 DACL、持有 staging 禁止替换及释放后同字节 staging 替换等检查，分别见基线 [tests.rs:193](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/zmodem/local_windows/tests.rs:193)、[tests.rs:286](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/zmodem/local_windows/tests.rs:286)、[tests.rs:625](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/zmodem/local_windows/tests.rs:625)、[tests.rs:783](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/zmodem/local_windows/tests.rs:783)、[tests.rs:812](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/zmodem/local_windows/tests.rs:812)。保留它们有价值，但叶文件替换不能冒充相同 leaf/source 身份下的祖先替换。第三例也只补充 destination 的可达父替换拒绝，不能冒充 upload 的同场景覆盖。准确标识这种证明变化是本次条件采用的必要部分。

ADR 0148 只允许新建归档 staging 内部观察在完整 precompare 后转换；它不授权释放 Zmodem 已审核源及祖先句柄。平台 no-replace 的目标句柄、短期 DELETE lease 与后代打开检查是独立约束。不能为修测试而修改这些生产生命周期，或用“未调用 publish 时目标缺席”声称已经验证发布拒绝。

**采用条件与直接建议。**

1. 先由父继续收取现有精确 run 的原始日志，绑定 checkout HEAD、工程源码、Windows job/attempt、失败用例全名及完整错误。只有实际结果与这两处 rename 前置及错误预期相符，才将候选作为相应测试契约修订来集成。若日志只含裸 raw 5、无法区分准备阶段与 rename，根因定位仍须注明是静态推断；摘要和相同错误码不能冒充 syscall 现场证据。没有相符的新 session 失败时，本候选继续待用。
2. 采用前解决 P2-01，改两个名称，更新新库存映射与候选 patch/source-receipt 摘要，保留当前作者原件和本评审身份。当前哈希的条件意见不自动扩展到额外正文或生产改动；改名后应确认仍只有两处预期正文及两项名称变化。
3. 由父在主任务既有验证流程中对集成后的精确输入完成 Windows 编译清单与实际执行。两处应执行到精确错误、祖先/源身份及原字节断言；第三例应实际完成外层改名、替换及发布拒绝，mutated=false、两树空。本轮 reviewer 不启动任何验证，也不请求取消或重跑当前 run。
4. 保留其余 43 例及 2 个原 ignore 的边界，完成相关 Windows session/生产安全回归和工程所需门禁，再签署修订有效；不得把“静态 45 名”写成“45 个实际通过”。共享 target 的后续归属和编译库存遵循 SHARED_TARGET.md；本评审没有接触 target，不能代签该环节。

**实际执行及未验证边界。** 以下按一次 `functions.exec_command` 调用计数；脚本内部只读 Git 子进程不重复计为顶层调用，命令数也不是检查项或测试数。包括最终文件/源码读回，总计 **32 次本地静态命令调用，29 次 exit 0、3 次 exit 1**。第 22 次是 zsh 未匹配 `platform*` glob 的路径查找失败；第 26 次尾部路径过滤无匹配，exit 1 表示未找到旧文件布局。两次路径疑义已由精确 Git 树检查消除。第 31 次读回为 10 项成立、1 项不成立，exit 1：HEAD 未变、7 个受评工程文件及 8 个作者材料摘要均匹配，但“全 tracked 工作区干净”检查不成立，实际仅列出 ` M docs/ROADMAP.md`。本评审没有写该文件，未查看其修改内容、未还原或清理。第 32 次按受评范围核对输入及本报告回执，不要求并行任务的文档保持干净。这三次 exit 1 都不是 Rust/Windows/CI 执行结果；原退出事实保留。调用索引在 static-receipt.json。

| 验证/操作 | 本评审实际结果 |
| --- | --- |
| Python 输入、哈希、声明及内存 patch 检查 | 19 passed / 0 failed，exit 0 |
| 额外 5 个平台/模块文件绑定 | 全部匹配 f094de6，exit 0 |
| git apply --check | 1 次，exit 0；未应用 |
| Rust 编译、Rust 测试（含预编译二进制）、Clippy、rustfmt/全库 fmt | 各 0 次 |
| 独立 Windows / macOS / Linux native、GUI 或仿真执行 | 各 0 次 |
| 查询/等待/取消/重跑 CI、提交、推送、清理、worktree/chat 创建 | 各 0 次 |
| 写入 | 仅本评审 REPORT.md 与 static-receipt.json；工程、作者候选及共享 target 未改 |

最终读回以本目录回执的 7 个工程文件和 8 个作者材料摘要及 HEAD 为准；这是限定范围的零漂移检查，不是完整源码门禁。第 31 次观察到的 ROADMAP dirty 保持独立事实，不签全工作区干净。无法签署 Rust 类型正确、当前 Windows 两项精确返回、第三例运行成功、完整 session/gate、桌面或发行验收。

官方引用均于 2026-11-16 只读查阅，未将网页全文写入仓库。URL 置于代码格式便于持久核对：

- S1：MS-FSA 2.1.5.15.12，目录后代打开时拒绝改名。`https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-fsa/87f86c9b-6c2a-4803-84b7-131a74a434fa`
- S2：MS-FSA 2.1.4.2，child links、open 及递归检查。`https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-fsa/133840e4-778e-44ca-9b41-da2323615075`
- S3：MS-FSA Appendix A，<185>/<186> 的目标分享及 NTFS 后代 open 重检细节。`https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-fsa/4e3695bd-7574-4f24-a223-b4679c065b63`
- S4：Microsoft System Error Codes (0–499)，ERROR_ACCESS_DENIED=5。`https://learn.microsoft.com/en-us/windows/win32/debug/system-error-codes--0-499-`
- S5：Rust std::fs::rename，Windows API 及回退说明。`https://doc.rust-lang.org/std/fs/fn.rename.html`
- S6：Rust 1.100.0 官方标准库源码，library/std/src/sys/fs/windows.rs 的 rename（1233–1297）。`https://raw.githubusercontent.com/rust-lang/rust/1.100.0/library/std/src/sys/fs/windows.rs`
- S7：MS-FSCC 2.4.43，FileRenameInformationEx / POSIX 替换已有目标的语义；并对照 WDK FILE_RENAME_INFORMATION 的目录后代打开约束。`https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-fscc/4217551b-d2c0-42cb-9dc1-69a716cf6d0c`、`https://learn.microsoft.com/windows-hardware/drivers/ddi/ntifs/ns-ntifs-_file_rename_information`

本报告的采用建议只覆盖上述未集成候选的静态分析；名字纠正与精确 Windows 证据到位前，当前候选保持 HOLD。
