# Windows 归档测试候选 — 2026-11-16

结论：已完成测试候选；仅修改获准的工程文件
`crates/keelshell-session/src/sftp/archive_transfer/local_windows/tests.rs`。
原 29 个用例名均保留，其中 28 个用例正文及文件其余内容与基线逐字节相同；
修订原 clone 用例，按追加要求新增一个有区别价值的同内容换对象用例。
源码静态库存为 30 个用例，不代表已编译或执行的 Windows 库存。

## 补丁行为

- `windows_archive_manifest_clone_retains_every_original_ancestor_capability`
  在原 manifest 存活期间只复制祖先路径和不可变 FileInfo，不保留额外 capability。
  丢弃原 manifest 后，先逐一核对 clone 的每个祖先保留句柄与原始完整审核观测，
  并要求 `verify_sources` 正向成功。随后仅把源叶文件重命名至同一目录，
  在原名创建不同文件，逐一再次核对全部祖先；核对已移动对象和保留文件句柄
  仍为原 identity、原始字节及原 digest，新对象 identity 确实不同。
  最后要求 `verify_sources` 返回精确的 `SessionError::Invalid` 重新审核错误。
  原审核 stamp 和 digest 未改写，读取重命名后的旧对象只使用临时新观测。
- `windows_archive_same_content_replaced_staging_file_is_not_published_or_deleted`
  复用现有 Fixture、Lease 和 build_stage。把唯一审核文件移到 owned temporary
  的根目录（staging 外），通过 stage 的实际目录 capability 调用
  `create_file("file")`，写入完全相同的 `reviewed` 字节、同步并校验 private DACL，
  明确新旧 identity 不同。关闭创建 writer 后完整 capture 新树，要求私有权限、
  完整字节、digest 和库存校验成功，再要求 publish 返回精确的重新审核错误。
  拒绝后目的地不存在，stage 新对象和旧证据的 identity、相同字节、private DACL
  均保持，reservation 仍 quarantine。未新建 fixture 或生产接口。

所有 fixture I/O 使用 `?`，前置 rename、创建、capture 或读取失败会使测试失败；
没有 skip、任意错误成功分支、时间扩宽或审核观测替换。

## 实际静态验证

- 单文件 `rustfmt --edition 2024 --config skip_children=true`：exit 0。
- 同参数单文件 `rustfmt --check`：exit 0。
- 该文件 `git diff --check`：exit 0。
- `python3 work/windows-archive-publish-tests-candidate-20261116/verify_candidate.py`：
  exit 0，14/14 范围和结构检查。该脚本只检查文本、摘要和格式，不替代 Rust 编译。
- 工程增量：135 行增加、14 行删除。

基线 HEAD：`d4714c02c25f59861cfaa82b057161a9f484837c`。
用户提供的已审核源码：`8527cf2af581e50ac0e1f795176ab69737730e18`。
当前 tests.rs SHA-256：
`9170d8013075b33d6a3fb4273393d9e27925a6879935c83bfc61a83e559c5394`。
完整 patch、基线及候选摘要、用例名库存见本目录
`tests-candidate.patch`、`static-receipt-r1.json`。

本地读取旧精确 Windows 原日志及 clean 副本。clean 副本实际保存 platform
`70 passed / 0 failed / 0 ignored`，session `25 passed / 3 failed / 1 ignored`；
与用户提供的 run `43854113236` / job `133253865501` 身份分开记录。
三败保持历史失败，未改写原日志或将其签署给本候选。

## 未验证边界和交接

本任务未运行 Cargo、Clippy、工作区 fmt、Rust 编译或 Windows native 测试；
未提交、push、cleanup 或操作共享 target。Windows 实际执行为 0。
两处真实叶 rename 在保留观察句柄时能否成功，仍须父任务在 Windows 验证，
目前不写已过。新增用例也尚未在父生产补丁下编译或执行。

父任务并行修改的 `local_windows.rs` 不属于本候选的写集；
本任务没有修改生产、原 nested-tree 用例或原 unobserved-publication 用例。
父任务继续串行构建、核对新的精确编译库存、执行专项及完整门禁，并绑定新 CI。
本候选补丁及静态回执独立于既有源码签署；静态 14/14 不构成非作者审查批准。
