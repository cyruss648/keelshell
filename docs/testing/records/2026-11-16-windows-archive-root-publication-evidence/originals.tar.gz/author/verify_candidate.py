"""Check candidate scope and record static evidence without Cargo or target access."""

import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess


ROOT = Path(__file__).resolve().parents[2]
OUTPUT = Path(__file__).resolve().parent
BASE = "d4714c02c25f59861cfaa82b057161a9f484837c"
SOURCE = "crates/keelshell-session/src/sftp/archive_transfer/local_windows/tests.rs"
CLONE = "windows_archive_manifest_clone_retains_every_original_ancestor_capability"
ADDED = "windows_archive_same_content_replaced_staging_file_is_not_published_or_deleted"


def block(text, name):
    start = text.index("#[tokio::test]\nasync fn " + name + "(")
    end = text.index("\n#[", start)
    return text[start:end]


baseline = subprocess.run(
    ["git", "show", f"{BASE}:{SOURCE}"],
    cwd=ROOT,
    capture_output=True,
    check=True,
).stdout
current = (ROOT / SOURCE).read_bytes()
before = baseline.decode()
after = current.decode()
old_clone = block(before, CLONE)
new_clone = block(after, CLONE)
new_test = block(after, ADDED)
names = lambda text: re.findall(r"^(?:async )?fn (windows_archive_\w+)\(", text, re.M)
before_names = names(before)
after_names = names(after)
checks = {
    "only_one_existing_test_changed_and_one_test_added": (
        after.replace(new_test + "\n", "", 1).replace(new_clone, old_clone, 1) == before
    ),
    "all_29_original_names_preserved": (
        len(before_names) == 29
        and [name for name in after_names if name != ADDED] == before_names
    ),
    "new_inventory_30_unique_names": len(after_names) == len(set(after_names)) == 30,
    "ignore_attributes_unchanged": (
        re.findall(r"^#\[ignore.*$", before, re.M)
        == re.findall(r"^#\[ignore.*$", after, re.M)
    ),
    "clone_drops_original_before_positive_verification": (
        new_clone.index("drop(manifest);") < new_clone.index(
            "verify_sources(&retained, &members, &stop)?;"
        )
    ),
    "clone_snapshots_own_no_capability": (
        ".map(|(path, ancestor)| (path.clone(), ancestor.stamp.clone()))" in new_clone
    ),
    "clone_only_renames_leaf": (
        "std::fs::rename(&source, &moved)?;" in new_clone
        and "std::fs::rename(&outer" not in new_clone
    ),
    "clone_checks_each_original_ancestor_twice": (
        "for (path, original_stamp) in &original_ancestors" in new_clone
        and new_clone.count("verify_retained_ancestors()?;") == 2
    ),
    "clone_checks_original_identity_bytes_digest": all(
        text in new_clone for text in [
            "assert_eq!(held_stamp.identity, original_identity);",
            'assert_eq!(bytes, b"original");',
            "assert_eq!(Some(digest), entry.digest);",
        ]
    ),
    "both_cases_require_exact_review_changed_error": all(
        'Err(SessionError::Invalid(\n                "archive source, destination or ancestors changed; review again"'
        in body
        for body in [new_clone, new_test]
    ),
    "new_case_reuses_fixture_lease_and_private_creation_api": all(
        text in new_test for text in [
            "native(Fixture::new).await?",
            "Lease::new(&fixture).await?",
            'parent.create_file("file")?',
            "verify_private(replacement.as_file(), false)?;",
            "drop(replacement);",
        ]
    ),
    "new_case_captures_valid_same_digest_tree_before_publish": (
        new_test.index("let actual = capture_tree(") < new_test.index("publish_stage(")
        and "assert_eq!(replaced.digest, original_digest);" in new_test
        and "assert_ne!(replacement_identity, original_identity);" in new_test
    ),
    "new_case_keeps_evidence_identities_bytes_and_quarantine": all(
        text in new_test for text in [
            "assert!(!fixture.destination.exists());",
            'assert_eq!(std::fs::read(fixture.staging.join("file"))?, b"reviewed");',
            'assert_eq!(std::fs::read(&evidence)?, b"reviewed");',
            "assert_eq!(metadata(&replacement)?.identity, replacement_identity);",
            "assert_eq!(metadata(&original)?.identity, original_identity);",
            "assert!(lease.quarantined());",
        ]
    ),
}
fmt_cmd = [
    "rustfmt", "--check", "--edition", "2024", "--config", "skip_children=true", SOURCE
]
fmt = subprocess.run(fmt_cmd, cwd=ROOT, capture_output=True, text=True)
(OUTPUT / "rustfmt-check-r1.log").write_text(
    "command: " + " ".join(fmt_cmd) + f"\nexit_code: {fmt.returncode}\n"
    + fmt.stdout + fmt.stderr
)
checks["single_file_rustfmt_check"] = fmt.returncode == 0
patch = "".join(difflib.unified_diff(
    before.splitlines(keepends=True),
    after.splitlines(keepends=True),
    fromfile="a/" + SOURCE,
    tofile="b/" + SOURCE,
))
(OUTPUT / "tests-candidate.patch").write_text(patch)
receipt = {
    "baseline_commit": BASE,
    "source_commit_from_user": "8527cf2af581e50ac0e1f795176ab69737730e18",
    "path": SOURCE,
    "baseline_sha256": hashlib.sha256(baseline).hexdigest(),
    "candidate_sha256": hashlib.sha256(current).hexdigest(),
    "patch_sha256": hashlib.sha256(patch.encode()).hexdigest(),
    "checks": checks,
    "static_checks_passed": sum(checks.values()),
    "static_checks_total": len(checks),
    "original_test_count": len(before_names),
    "candidate_test_count": len(after_names),
    "unchanged_original_test_bodies": 28,
    "test_names": after_names,
    "windows_compilation": "NOT_RUN",
    "windows_native_execution": "NOT_RUN",
    "cargo_clippy_workspace_fmt_shared_target": "NOT_RUN_OR_TOUCHED",
    "limitations": [
        "Static scope/structure checks and rustfmt are not Rust type checking.",
        "Leaf-file rename with retained native observation handles awaits Windows execution.",
        "Concurrent parent production changes are outside this candidate's write set.",
        "Historical run 43854113236/job 133253865501 is not candidate acceptance.",
    ],
}
(OUTPUT / "static-receipt-r1.json").write_text(
    json.dumps(receipt, indent=2, ensure_ascii=False) + "\n"
)
print(json.dumps({key: receipt[key] for key in [
    "candidate_sha256", "static_checks_passed", "static_checks_total",
    "original_test_count", "candidate_test_count",
]}, indent=2))
raise SystemExit(0 if all(checks.values()) else 1)
