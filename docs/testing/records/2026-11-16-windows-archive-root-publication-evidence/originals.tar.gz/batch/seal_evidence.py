"""Seal owned root-publication inputs, prior CI, and independent review."""
import gzip,hashlib,io,json,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
BATCH=Path(__file__).resolve().parent
EVIDENCE=ROOT/"docs/testing/records/2026-11-16-windows-archive-root-publication-evidence"
OLD=ROOT/"work/windows-archive-preflight-integration-20261116"
files={}
for path in sorted(BATCH.rglob("*")):
 if path.is_file() and path.suffix in (".py",".json",".log",".diff",".txt"):
  files["batch/"+path.relative_to(BATCH).as_posix()]=path
for path in sorted((BATCH/"source-r1").rglob("*")):
 if path.is_file():files["batch/"+path.relative_to(BATCH).as_posix()]=path
for role,folder in [("author",ROOT/"work/windows-archive-publish-tests-candidate-20261116"),("review",ROOT/"work/windows-archive-publication-review-20261116")]:
 assert folder.is_dir()
 for path in sorted(folder.rglob("*")):
  if path.is_file():files[role+"/"+path.relative_to(folder).as_posix()]=path
for os_name in ("macos","ubuntu","windows"):
 for suffix in (".json",".log"):
  path=OLD/("windows-job-log-r1"+suffix) if os_name=="windows" else BATCH/("prior-"+os_name+"-job-r1"+suffix)
  files["ci/"+os_name+"-job-log-r1"+suffix]=path
files["ci/source-ci-summary-r1.json"]=BATCH/"prior-ci-summary-r1.json"
for label in ("source-ci-watch-r1","docs-push-r1","windows-cross-clippy-r1","dependencies-live-r1"):
 for suffix in (".json",".log"):
  path=OLD/(label+suffix);assert path.is_file();files["prior/"+path.name]=path
files["prior/dependencies-report-r1.json"]=OLD/"dependencies-report-r1.json"
legacy=ROOT/"work/workbench-fit-20261116"
for path in sorted(legacy.iterdir()):
 if path.is_file():files["legacy-workbench/"+path.name]=path
files["tools/verify.py"]=EVIDENCE/"verify.py"
data={name:path.read_bytes() for name,path in sorted(files.items())}
rows=[{"path":name,"source_path":files[name].relative_to(ROOT).as_posix(),"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()} for name,raw in data.items()]
output=io.BytesIO()
with gzip.GzipFile(fileobj=output,mode="wb",mtime=0) as zipped:
 with tarfile.open(fileobj=zipped,mode="w",format=tarfile.PAX_FORMAT) as archive:
  for name,raw in data.items():
   entry=tarfile.TarInfo(name);entry.size=len(raw);entry.mode=0o644;entry.mtime=0;archive.addfile(entry,io.BytesIO(raw))
packed=output.getvalue()
manifest={"schema":"keelshell.windows-archive-root-publication.evidence.v1","baseline_source":"d4714c02c25f59861cfaa82b057161a9f484837c","engineering_sha256":json.loads(data["batch/inputs-freeze-r1.json"])["aggregate_sha256"],"count":len(rows),"archive_bytes":len(packed),"archive_sha256":hashlib.sha256(packed).hexdigest(),"uncompressed_bytes":sum(r["bytes"] for r in rows),"entries":rows,"windows_native":"NOT_RUN","prior_ci":"failure","native_ui":"BLOCKED_MAC_LOCKED","excluded":["target","application and MCP binaries","runtime","full copied Microsoft pages"]}
for name in ("manifest.json","originals.tar.gz"):assert not (EVIDENCE/name).exists()
(EVIDENCE/"originals.tar.gz").write_bytes(packed);(EVIDENCE/"manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
print(json.dumps({k:v for k,v in manifest.items() if k!="entries"}))
