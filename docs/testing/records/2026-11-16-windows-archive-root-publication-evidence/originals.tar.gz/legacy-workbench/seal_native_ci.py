"""Retain only the explicit, non-sensitive evidence selections for the preceding source."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[2]
DEST = ROOT / "docs/testing/records/2026-11-16-kit010-native-ci-evidence"
SOURCE = "3c331c1cc3cc428c33c606b9af578057325871b9"
members = {}


def add(path, name, kind):
    assert path.is_file() and not path.is_symlink() and name not in members
    assert not set(Path(name).parts).intersection({"private", "runtime", "sshd-public"})
    data = path.read_bytes()
    members[name] = (data, {
        "path": name, "source_path": path.relative_to(ROOT).as_posix(),
        "kind": kind, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
    })


for folder, prefix, kind in [
    ("windows-directory-rename-delivery-20261116", "delivery", "original_receipt_or_log"),
    ("windows-ci-inventory-20261116", "windows-inventory", "derived_independent_inventory"),
    ("kit010-native-review-20261116", "native-review", "derived_independent_review"),
]:
    base = ROOT / "work" / folder
    for path in sorted(base.iterdir()):
        if path.is_file() and path.suffix in {".json", ".log", ".txt", ".md", ".py"}:
            add(path, f"{prefix}/{path.name}", kind)

native = ROOT / "work/kit010-native-20261116"
for path in sorted(native.iterdir()):
    if path.is_file() and path.suffix in {".json", ".log", ".py"}:
        add(path, f"native/{path.name}", "original_receipt_or_log")
for path in sorted((native / "ui").iterdir()):
    assert path.suffix in {".png", ".txt"}
    add(path, f"native/ui/{path.name}", "original_ui_bytes")
add(native / "package-r1/package-manifest.json", "native/package-manifest.json",
    "original_package_manifest")
add(native / "container-context/Containerfile", "native/Containerfile", "original_fixture_recipe")
add(native / "local-fixture/fixture-local.txt", "native/fixture-local.txt", "original_owned_fixture")

review = json.loads(members["native-review/summary-r2.json"][0])
assert review["status"] != "IN_PROGRESS", "wait for the independent reviewer"
freeze = json.loads(members["native/engineering-inputs-r1.json"][0])
package = json.loads(members["native/package-manifest.json"][0])
assert package["build"]["commit"] == SOURCE and freeze["count"] == 719
DEST.mkdir(exist_ok=True)
assert not (DEST / "originals.tar.gz").exists() and not (DEST / "manifest.json").exists()
raw = io.BytesIO()
with tarfile.open(fileobj=raw, mode="w") as retained:
    for name, (data, row) in sorted(members.items()):
        item = tarfile.TarInfo(name)
        item.size = len(data)
        item.mode = 0o644
        item.mtime = 0
        retained.addfile(item, io.BytesIO(data))
archive = gzip.compress(raw.getvalue(), mtime=0)
manifest = {
    "schema": "keelshell.kit010-native-ci.evidence.v1",
    "source_commit": SOURCE,
    "engineering_sha256": freeze["aggregate_sha256"],
    "app_sha256": package["binary_sha256"],
    "mcp_sha256": package["mcp_binary_sha256"],
    "archive_bytes": len(archive),
    "archive_sha256": hashlib.sha256(archive).hexdigest(),
    "count": len(members),
    "uncompressed_bytes": sum(len(data) for data, _ in members.values()),
    "screenshot_format": "Original JPEG bytes retained under the original .png capture filenames.",
    "excluded": ["private/", "runtime/", "sshd-public/", "package binaries and icon"],
    "entries": [row for _, row in sorted(members.values(), key=lambda item: item[1]["path"])],
}
for data, row in members.values():
    assert (ROOT / row["source_path"]).read_bytes() == data, row["source_path"]
(DEST / "originals.tar.gz").write_bytes(archive)
(DEST / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({key: manifest[key] for key in
                  ["count", "archive_bytes", "archive_sha256", "uncompressed_bytes"]}))
