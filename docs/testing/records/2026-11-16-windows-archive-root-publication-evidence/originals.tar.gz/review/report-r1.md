独立非作者静态评审：Windows 归档根目录发布修复（2026-11-16）

**结论：APPROVE，仅限冻结三文件的静态实现及本轮明确接受的平台契约。** P0=0、P1=0、P2=0、P3=0；无可操作缺陷发现，因此没有缺陷触发/影响条目。建议保留当前冻结候选进入父后续精确 Windows CI。Windows 类型检查、真实 Windows 执行、完整应用门禁、桌面及发行均未签署，本报告不证明 Windows 修复已实际通过。

评审绑定 baseline `d4714c02c25f59861cfaa82b057161a9f484837c`，读取时 HEAD 相同。719 项工程路径、大小和 SHA 全部核对，并重算 aggregate：
`56ba4c7b46f7fe7b03b789639db84a997c41f7363b9d856b6148af44086ac83a`。
聚合编码为冻结顺序的 `path + NUL + sha256 + LF`。当前三文件 diff 与 `candidate-r1.diff` 字节相同，diff SHA-256 为
`175fc0055e307a40a871befa60436670a271ed6b13e7f3b83ae2dde00057372a`。
三文件 SHA 和 14 项通过的可执行静态核验见同目录 `static-receipt-r1.json`。签署对象是工作区字节快照，并非新提交。

| 文件（相对本工作区） | 候选 SHA-256 |
| --- | --- |
| `.github/workflows/ci.yml` | `0833437e00d35fdd9fdac35a8ab85ab31115c9bb8b559105ec840a743d6321e9` |
| `crates/keelshell-session/src/sftp/archive_transfer/local_windows.rs` | `4687f089b5759a4095ff7e660dae1e7f766729246eca12ee90bdac4a93313c07` |
| `crates/keelshell-session/src/sftp/archive_transfer/local_windows/tests.rs` | `2be9fc335e49e764ec528e94e4792ad7353d528d5ae97c4bd7cebb486857d57b` |

先读 RTK、AGENTS、HANDOFF 当前规则、SHARED_TARGET，并应用 `rust-best-practices` 第 1、4、5、7、9 章的所有权、错误传播、测试和状态转换原则。仅评审三文件增量；旁读 ADR 0148、ARCHIVE_TRANSFERS 以及 guard、worker、platform 的必要依赖契约，没有扩大为整库审计。用户最新要求覆盖 HANDOFF 中上一候选和 CI 状态。

下文 `local_windows.rs` 和 `tests.rs` 的绝对位置分别为：

- `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/archive_transfer/local_windows.rs`
- `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/archive_transfer/local_windows/tests.rs`

**释放时序与剩余句柄。** `local_windows.rs:660–684` 消费 `Tree`，逐项保存完整 `FileInfo`、digest、children，丢弃每个 `HeldEntry`；保存值不再包含句柄。`:1042–1051` 完成第二份全树 capture/compare 后先显式 `drop(actual)`，核对祖先、名字、目标缺席和 worker，然后释放原树、复查 worker，并仅对始终保留的 `PrivateEntry` 根执行原 no-replace rename。源码前缀核对确认 Manifest/source 扫描完全不变，审核祖先也未参与转换。`build_stage` 的 `:930、:958、:993、:1014` 分别关闭子目录创建 capability、文件 writer、构建目录 map、created observations；未发现返回前遗留的 staging 后代句柄别名或逃逸。根和祖先句柄不是后代 open。平台 `crates/keelshell-platform/src/windows/mod.rs:241–254`、`native.rs:359–386` 的 rename 路径只临时重开根的 DELETE lease，不打开后代。释放后的生产调用链没有子项 create/write/flush 操作。

**完整读回与契约边界。** 此转换确实放弃了跨 rename 连续固定每个 staging 后代原生对象、阻止其身份复用的保证；ADR 对此明确限定，不能另行宣称对象连续性。它满足本轮明确接受的后验完整观察契约：`local_windows.rs:728–808` 从已匹配保留根身份的目标名字重开，检查私有 ACL、实际类型、身份唯一性、精确目录库存，逐文件读完全部 bytes 并与审核成员相等，同时核对读前后 metadata；`:832–850` 比较保存的完整 `FileInfo`（含完整 security）、digest 和 children，后代没有时间、身份或权限豁免，仅根沿用既有 modified/changed 归一。`:1062–1068` 再核对祖先、唯一目标、staging 缺席、命名根、全树链接和 worker。同 file ID 或 hash 单独不能授权成功。

该协议允许 rename 后、完整读回被接受前出现尚未验证的目标。外部同账户变更造成的失败目标会保留并隔离；协议不承诺持续排斥修改、名字一出现即可信或崩溃持久性。此处接受的是明确披露的后验检查边界，不能把隔离解释为回滚或撤销已发生的 rename。未发现该增量在约定边界内遗漏内容、权限或清单验证。

**部分字段 move 与 guard 生命周期。** `Staged`（`:853–857`）和 `Tree` 没有自身 `Drop`；移动 `stage.tree` 不会提前销毁 `stage.entry` 或 `stage.unverified`，新 helper 也不触碰 ticket。release 后的检查、rename、capture、compare、链接检查任一 `?` 失败，或发生展开式 panic，剩余 guard 都仍被 drop。`crates/keelshell-session/src/sftp/archive_transfer.rs:208–219` 将 reservation `finish(false)`，没有证据删除。成功只在 `local_windows.rs:1071` 转移 guard；`extract :1113–1115` 在 async owner 收到结果并通过 `authority.check` 后才清 ticket。

`crates/keelshell-session/src/sftp/archive_transfer/mutation_worker.rs:45–60` 仍只由实际收到 JoinHandle 结果的 owner 清 pending。worker panic/丢弃 await 没有被改成已知成功。普通错误被实际观察时 pending 可以清除，但 guard 的隔离独立存在；`pending=false` 不等同于发布已验证。`crates/keelshell-session/src/sftp/queue/reservations.rs:242–246` 的 `finish(false)` 仍立即 retire unknown。没有发现本增量导致提前解锁或失败后清理的路径。上述是静态所有权分析，未编译 Windows 条件代码。

**测试范围与证明力。** 按测试块逐字核对，baseline 29 个测试，候选 30 个，原 28 个块不变，仅改 clone 测试并新增一个回归。原 symbolic-link privilege 用例保持唯一 ignored。

- `tests.rs:295–365`：drop 原 manifest 后逐祖先核对原 stamp 和保留对象实际 metadata，先证明 `verify_sources` 成功；再仅 rename shared-delete 叶文件并替换，检查 clone 仍保有原 ID/bytes/digest，最后精确拒绝 `Invalid`。没有再要求平台禁止的外层目录改名成功，源及全部祖先保留契约仍被检查。
- `tests.rs:644–731`：保存原 ID/digest，消费 Tree，移走旧叶保留证据，创建私有同 bytes 新 ID 并 flush/关闭 writer；要求真实根 rename 成功，完整 capture 接受 bytes、私有 ACL 和库存，随后 `compare_published_observations` 精确返回 `Invalid`。drop 原 guard 后目标和旧证据仍有对应 bytes、私有权限及各自 ID，reservation 已 quarantine。没有用任意早期失败冒充后验拒绝。完整 `FileInfo` 的多个字段可能不同，因此不能额外宣称本例单独隔离了 identity 比较字段。
- 新回归不调用完整 `publish_stage` 或 `extract`，只覆盖私有 transition/readback 加 guard。原 nested-tree、unobserved 完整发布用例保持不变，继续承担原真实失败回归。30 名属于源声明/预期清单，尚不是 Windows 编译库存或运行结果。

**CI 增量。** `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/.github/workflows/ci.yml:42–52` 增加新回归精确全名的编译库存要求，仍串行运行原模块并传递退出码。没有重试、忽略错误、增加 ignored 或延长时限。PowerShell 数组的逗号表达式后接换行独立字符串静态可接受；本评审没有实际执行 PowerShell。

**父专项只读核对。** `scoped-gate-r1.json/log` 绑定 67,918 bytes，日志 SHA-256 为
`4c1294930756e0b0115ea4766c7586d6912727093782c15284c0df316fceb496`；
observed/controller exit 均 0、reaped、active=0、19.678337 秒。日志包含 fmt、x.y、严格 workspace all-target Clippy 成功，host session lib 为 `288 passed / 0 failed / 4 ignored`，app 归档为 `13/0/0`。我独立重提取 305 个唯一库存名和 305 个唯一 Rust 结果，逐项完全相同：301 ok、4 ignored，并核对 `scoped-summary-r1.json`。

原行首锚解析只得 304 名的偏差仍保留于 `inventory-parse-attempt-r1.json`。原 log 第 423 行 Python stderr 与 Rust 结果同行，`network_diagnostic::tests::cancel_inflight_reply_discards_result_and_pre_cancel_opens_nothing` 的完整 `ok` 后缀实际存在；依据模块名及完整结果后缀重提取可以恢复该结果。没有任何测试重跑，也没有修改原日志或偏差回执。

**官方依据核对。** MS-FSA 2.1.5.15.12 与 2.1.4.2 本轮独立 HTTP 读取均为 200，整页 SHA 分别为
`ced9c46ea004e29941aff65db2dcaea3cce1b79ef6f9639c43d3f4747e4a70c4`、
`92c7181bd59a7d92d3bf8cae90797d30e7686e4415b9a4136ee4fa460dd88c38`，
与父 `windows-spec-receipts-r1.json` 一致。原文支持目录 rename 检查后代 open 并拒绝访问的解释，share DELETE 不能单独免除检查。没有持久化整页或长段原文。此处核对的是设计依据，不能证明候选 Windows 实现运行正确。

**真正执行与未验证。** 本评审执行了规则/源码/回执读取、只读 git rev-parse/show/diff、Python SHA/字节/测试块/库存解析和两页官方 HTTP 读取。14 项自动静态核验全部通过，另完成 8 项人工语义审查；这些不是 Rust 测试次数。一次报告生成前的辅助 Python 脚本误将 summary 的 `[name, outcome]` 列表当成可哈希字符串，报 TypeError；修正解析后核对完成，无 Rust 重跑。一次旁读 queue 路径误写为 archive_transfer/queue.rs，返回不存在，随后读取真实 sftp/queue/reservations.rs；两次工具错误不被记作测试失败或通过。

独立 Cargo、Clippy、fmt、Rust 测试、PowerShell、native/UI、提交、推送和清理全部为 0；仅写获准 review 目录。旧 cross-Clippy 缺 Windows SDK `windows.h` 的失败不升级为通过：当前候选 Windows 类型检查为 **NOT_COMPLETED**，Windows 实际执行为 **0**。没有收取或重签新 CI，没有把静态批准及宿主测试扩大为完整解包、桌面、发行或安装通过。父后续仍需核对新精确 Windows 编译库存、29 个非 ignored 实际执行以及完整 app gate；本次静态评审到此收敛。
