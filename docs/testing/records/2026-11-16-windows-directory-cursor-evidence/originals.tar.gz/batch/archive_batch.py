"""Freeze the completed batch's retained originals without adding build output."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
OUT = ROOT / "docs/testing/records/2026-11-16-windows-directory-cursor-evidence"
receipt = json.loads((BASE / "full-gate-r2.json").read_text())
assert receipt["observed_exit"] == receipt["controller_exit"] == 0
assert receipt["terminal"]["direct_reaped"] and receipt["terminal"]["active_processes"] == 0
assert not receipt["timed_out"] and not receipt["interrupted"]
summary = json.loads((BASE / "full-gate-r2-summary.json").read_text())
assert summary["complete_input_path_and_byte_set_matches"]
files = {}
for path in sorted(BASE.rglob("*")):
    assert not path.is_symlink(), str(path)
    if path.is_file():
        files["batch/" + path.relative_to(BASE).as_posix()] = path.read_bytes()
for name in (
    "crates/keelshell-platform/src/windows/native.rs",
    "crates/keelshell-platform/src/windows/tests.rs",
    "crates/keelshell-app/src/files/transfer_tests.rs",
    "crates/keelshell-app/src/files/conflict_merge_tests.rs",
):
    files["source/" + name] = (ROOT / name).read_bytes()
rows = [
    {"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
    for name, data in sorted(files.items())
]
archive = OUT / "originals.tar.gz"
with archive.open("xb") as raw:
    with gzip.GzipFile(filename="", fileobj=raw, mode="wb", mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode="w") as tar:
            for name, data in sorted(files.items()):
                member = tarfile.TarInfo(name)
                member.size = len(data)
                member.mode = 0o644
                tar.addfile(member, io.BytesIO(data))
with tarfile.open(archive, "r:gz") as tar:
    assert len(tar.getmembers()) == len(files)
    for name, data in files.items():
        assert tar.extractfile(name).read() == data, name
reviews = []
for name in (
    "batch/reviewer/review-r1.md",
    "batch/reviewer-folder-pause/review.md",
    "batch/reviewer-merge/REPORT.md",
):
    reviews.append({"path": name, "sha256": hashlib.sha256(files[name]).hexdigest()})
manifest = {
    "base_commit": "80397acc98d5881cbd177d7259a54fd7f1556c4f",
    "archive": archive.name,
    "archive_bytes": archive.stat().st_size,
    "archive_sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
    "count": len(rows),
    "original_bytes": sum(row["bytes"] for row in rows),
    "engineering_inputs": summary["engineering_inputs"],
    "engineering_sha256": summary["engineering_sha256"],
    "reviews": reviews,
    "files": rows,
}
with (OUT / "archive-manifest.json").open("x") as output:
    json.dump(manifest, output, indent=2)
    output.write("\n")
print(json.dumps({key: value for key, value in manifest.items() if key != "files"}))
