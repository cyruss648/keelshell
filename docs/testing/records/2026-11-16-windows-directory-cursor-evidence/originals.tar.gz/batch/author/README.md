# Windows directory cursor conditional candidate — 2026-11-16

结论：提供可评审、尚未编译或执行的条件候选。仅应由父任务在隔离集成后依据
真实 Windows 执行决定采用。基线为
`878f13b4cb58a45dfe96f32fc1c389ac7799366d`。
本目录以外没有实施源码修改；未执行 Cargo、Windows 仿真、Git 写操作、推送、
建 chat 或建 worktree，也未接触父共享 Cargo target。

## 已核实的新预检

父提供 Quality `43815115588` / Windows job `133125296042`，
completed/failure `2026-11-16T06:14:52Z`。已实际读取父原始日志并核对 SHA-256
`955d86d6b266c69108844757391dd8766e89837be5ebea936b66ed3da07ccf6b`，
日志含精确基线 SHA 和 `48 passed; 16 failed; 0 ignored; finished in 0.50s`。

16 个失败 stdout 区块全部含成对的
`nt-create-file / InvalidFilename / Some(123) / 0xc0000033` 与
`open-directory-cursor / InvalidFilename / Some(123) / None`；
合计各 23 条，一些测试有多次尝试。详见 evidence 的逐测试计数与摘要。
这把本轮 platform 失败定位到游标的 native open；不是从 123 单独猜测。
原始完整 gate 为 skipped/NOT_RUN，由父报告；此候选未另行查询 run API。
此前八项 app 归档 review-error 是否消失仍 UNKNOWN，不能沿用此预检签署。
原始日志归档由父负责，本目录保存的是带来源摘要的提取件，不冒充完整原件。

## 候选机制与边界

`candidate/crates/keelshell-platform/src/windows/native.rs`：

- 将 `entries` 中 `open_child(parent, ".", true)` 换为专用
  `directory_cursor(parent)`，用空 NT 相对名重开持有对象。
- 沿用 `NtCreateFile` 的 `FILE_OPEN`、`FILE_DIRECTORY_FILE`、
  `FILE_SYNCHRONOUS_IO_NONALERT`、`FILE_GENERIC_READ` 中的 SYNCHRONIZE、
  `OBJ_DONT_REPARSE`、`FILE_OPEN_REPARSE_POINT`、全部分享模式及本地实际卷核验。
  不通过路径恢复来源，不使用 DuplicateHandle，不新增 Win32 ReOpenFile 调用，
  不尝试失败回退、放宽权限或重试。
- 重开前后比较 `directory_stamp()`，包含实际 volume/file identity、attributes、
  owner/group/DACL 观察，排除由兄弟文件写入引起的时间变化。
  先验证目录类型；创建/私有 DACL、独占普通文件 writer、无覆盖 rename、
  审核及不确定结果状态不变。普通目录不额外要求私有 DACL。
- 给 UTF-16 缓冲增加一个不计入 `UNICODE_STRING.Length/MaximumLength` 的终止单元，
  空名仍有真实有效 backing storage。非空名字的计数与原有 native 参数相同。
- 新句柄由 `File` 独占并 RAII 关闭；所有 native 查询仍要求同步句柄，
  不引入异步 IOSB/buffer 生命周期。

这是对文档和官方实现的工程推论，尚未证明该 empty-name reopen 在本项目的所有
Windows/文件系统组合可用。失败必须原样保留；不得按路径、去掉 DONT_REPARSE、
忽略 metadata/DACL 或共享 scan position 来取得绿例。

`sources/` 保存了真实 HTTP 200 正文、最终来源 URL、字节数、SHA-256 和正文抽取：

- Microsoft `NtCreateFile`：目录类型、relative RootDirectory、同步与 SYNCHRONIZE、
  open-reparse 以及 FILE_OPEN 契约。它没有直接完整说明空相对名游标的全部语义。
- Microsoft `NtQueryDirectoryFile`：扫描位置/搜索表达式跨调用延续，首次 scan、
  单条返回和 EOF；并发 namespace 变化的可见性由文件系统决定。
- Microsoft `ReOpenFile`：文档明确输入对象须通过 CreateFile 创建。本项目原目录
  使用 NtCreateFile；已有 rename lease 的调用不能单独证明适合此游标，所以没有
  扩大该 API 的使用。
- Rust 官方 `windows/remove_dir_all.rs`：`unicode_str!("")` 经
  `RootDirectory=held handle`、`OBJ_DONT_REPARSE`、
  `FILE_OPEN_REPARSE_POINT` 和 NtOpenFile 对实际持有对象进行删除操作。
  该代码是空相对名寻址的官方实现先例，不是 KeelShell 枚举成功的证据。
- Rust 官方 `windows/dir.rs` 与 `windows.rs` 提供 NT 相对打开及同步目录查询
  上下文；没有找到可直接代签本候选的独立 cursor 回归结果。

Rust master 来源是可变分支；本目录保存的字节及摘要固定本次读取的内容，
不宣称绑定 Rust release 或上游 commit。搜索工具空返回没有作为文档证据。
本任务应用了 rust-best-practices 与 rust-engineer；依用户限制没有执行其 Cargo 检查。

## 新 Windows 回归候选

`candidate/crates/keelshell-platform/src/windows/tests.rs` 保留全部原测试及断言，
增加三项；fixture 均为现有 tempfile，没有真实客户机器、外部网络或新依赖。

1. `reopened_directory_cursors_do_not_advance_or_restart_other_live_scans`
   先推进 parent 扫描和第一个新游标，再耗尽第二个游标，继续前两个扫描。
   每个完整集合都必须精确包含四个不同名称，覆盖中文和非 BMP。
   单次 native query 只取一条、不重启，确定性暴露复制句柄共享游标和重置其他扫描；
   不依赖调度概率。所有测试 helper 循环都有固定上限。
2. `directory_cursor_keeps_the_held_identity_when_its_original_path_is_rebound`
   将已持有目录从 `held` 改名到 `moved`，在原路径创建另一目录及不同 marker。
   原 capability 和新游标必须保持原 identity/security，并只看到原 marker。
   不要求 symlink 权限，也不借重解析指向替代路径。
3. `directory_cursor_preserves_private_dacl_and_rejects_regular_files`
   对真实私有 staging 重开后再次验证私有 DACL 和完整目录 stamp，
   并拒绝普通文件作为枚举目录。

已有大于 64 KiB 的多批次枚举、并发扫描、DACL、硬链接、无覆盖文件/目录发布、
Unicode 名称与 namespace 断言全部保留。没有新增 reparse 注入 fixture；
对持有对象并发转为 reparse 的实际 Windows 验证仍开放，不能把路径替换测试当作
该场景已经执行或通过。

## 父采用前的真实证据

1. 保留上述失败原件及精确源码绑定。将本 patch 放入父授权的集成源码并记录新 SHA；
   本候选本身没有进行集成。父如切换源码归属，遵守 SHARED_TARGET；此作者未使用该 target。
2. 在实际 Windows runner、新冻结输入及可核对编译日志下列出 platform lib inventory，
   必须含三个新测试完整名称及原有测试。固定此基线没有其他变化时预期是
   `64 + 3 = 67` 项；这只是源码推导，不能代替实际 inventory。
3. 实际执行 platform lib 串行预检，三项新例与原 64 项均不得失败或忽略。
   逐项保留结果及 operation/typed error/NTSTATUS。若空名仍失败或出现新
   sharing/identity/DACL/reparse 问题，保持失败，不自动采用。
4. 建议在同一实际 Windows runner 做独立、可编译的
   `directory_cursor -> parent.try_clone()` 变异，第一项新例必须失败；
   复原真实候选并再次成功。该变异当前 NOT_RUN。
5. platform 预检绿后才继续原完整 gate，格式、严格 Clippy、x.y policy 和测试照旧。
   八项 app 归档用例必须实际全部通过，且核对原 review/identity/no-replace/
   unknown-write 断言不变，才能声称它们已修复。原完整 gate NOT_RUN 保持原事实。
6. 新 SHA 的真实 Windows 执行和完整门禁只支持其准确环境；Windows 桌面、
   其他 Windows/文件系统、发行安装及业务验收没有由本候选完成。

## 工件与本地核验

- `implementation.patch`：仅生产 native.rs 的小补丁，相对精确基线。
- `candidate.patch`：生产改动和三项测试的组合补丁，相对同一精确基线。
- `baseline/.../{native.rs,tests.rs}`：通过只读 git show 取得的两份固定原件。
- `candidate/.../{native.rs,tests.rs}`：对应候选完整文件。
- `baseline-manifest.json`：基线文件 SHA-256 及最初工作源码相等核对。
- `verify_candidate.py`：仅重放本目录 patch、检查原测试保留、读取正式源码核对，
  并直接运行 rustfmt --check；不调用 Cargo、不写 Git、不访问 target。
- `validation.json`：实际静态/格式/工件核验结果，不能当成 Rust 编译或 Windows 执行。
- `evidence/platform-preflight-{excerpt.txt,receipt.json}`：真实失败日志的来源摘要和
  提取件，receipt 含 16 个失败区块的逐项统计。
- `sources/*`：六份官方正文、三份 HTML 正文提取及两份获取回执。
- `FILES.sha256`：除其自身之外所有交付文件的完整清单与摘要。

当前候选 Cargo/Clippy/类型编译、Rust 单元测试、Windows 执行、变异和完整 gate
均为 NOT_RUN。直接 rustfmt 检查和本地纯工件核验的结果见 validation.json。
