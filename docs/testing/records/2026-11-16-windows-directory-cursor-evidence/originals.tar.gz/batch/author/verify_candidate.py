#!/usr/bin/env python3
"""Verify candidate packaging without Cargo, Git writes, or a build target."""

from datetime import datetime, timezone
import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent
REPOSITORY = ROOT.parent.parent
MANIFEST = json.loads((ROOT / "baseline-manifest.json").read_text())
BASE = MANIFEST["base"]


def replay_unified(before, patch):
    """Replay one standard unified diff in memory, checking every old line."""
    old = before.splitlines(keepends=True)
    output = []
    position = 0
    lines = patch.splitlines(keepends=True)
    index = 2
    while index < len(lines):
        header = re.fullmatch(
            r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*\n", lines[index]
        )
        if header is None:
            raise ValueError("invalid unified diff hunk header")
        start = int(header[1]) - 1
        if start < position:
            raise ValueError("overlapping unified diff hunks")
        output.extend(old[position:start])
        position = start
        index += 1
        removed = added = 0
        while index < len(lines) and not lines[index].startswith("@@"):
            line = lines[index]
            if line[0] in " -":
                if position >= len(old) or old[position] != line[1:]:
                    raise ValueError("patch context does not match baseline")
                position += 1
                removed += 1
            if line[0] in " +":
                output.append(line[1:])
                added += 1
            if line[0] not in " +-":
                raise ValueError("unsupported patch line")
            index += 1
        if removed != int(header[2] or 1) or added != int(header[4] or 1):
            raise ValueError("unified diff hunk counts do not match")
    output.extend(old[position:])
    return "".join(output)


results = []
patches = []
for item in MANIFEST["files"]:
    name = item["file"]
    original = (ROOT / "baseline" / name).read_bytes()
    candidate = (ROOT / "candidate" / name).read_bytes()
    git_original = subprocess.run(
        ["git", "show", f"{BASE}:{name}"],
        cwd=REPOSITORY,
        capture_output=True,
        check=True,
    ).stdout
    before = original.decode()
    after = candidate.decode()
    patch = "".join(
        difflib.unified_diff(
            before.splitlines(keepends=True),
            after.splitlines(keepends=True),
            fromfile="a/" + name,
            tofile="b/" + name,
        )
    )
    patches.append(patch)
    checks = {
        "baseline_sha256_matches": hashlib.sha256(original).hexdigest()
        == item["sha256"],
        "baseline_matches_exact_git_object": original == git_original,
        "formal_source_still_matches_baseline": (REPOSITORY / name).read_bytes()
        == original,
        "patch_replays_to_candidate": replay_unified(before, patch) == after,
    }
    if name.endswith("tests.rs"):
        checks["no_existing_test_lines_removed"] = not any(
            line.startswith("-") and not line.startswith("---")
            for line in patch.splitlines()
        )
        original_tests = re.findall(r"#\[test\]\nfn (\w+)", before)
        candidate_tests = re.findall(r"#\[test\]\nfn (\w+)", after)
        checks["all_original_test_names_retained"] = set(original_tests) <= set(
            candidate_tests
        )
        checks["exactly_three_tests_added"] = len(candidate_tests) == len(
            original_tests
        ) + 3
        results.append(
            {
                "file": name,
                "checks": checks,
                "new_tests": [
                    test for test in candidate_tests if test not in original_tests
                ],
            }
        )
    else:
        results.append({"file": name, "checks": checks})

packaging = {
    "combined_patch_matches": (ROOT / "candidate.patch").read_text()
    == "".join(patches),
    "implementation_patch_matches": (ROOT / "implementation.patch").read_text()
    == patches[0],
}
formatting = subprocess.run(
    [
        "rustfmt",
        "--check",
        "--edition",
        "2024",
        *[str(ROOT / "candidate" / item["file"]) for item in MANIFEST["files"]],
    ],
    cwd=ROOT,
    capture_output=True,
    text=True,
    check=False,
)
passed = (
    all(all(result["checks"].values()) for result in results)
    and all(packaging.values())
    and formatting.returncode == 0
)
receipt = {
    "base": BASE,
    "checked_utc": datetime.now(timezone.utc).isoformat(),
    "passed": passed,
    "files": results,
    "packaging": packaging,
    "rustfmt": {
        "exit_code": formatting.returncode,
        "stdout": formatting.stdout,
        "stderr": formatting.stderr,
    },
    "cargo": "NOT_RUN",
    "windows_execution": "NOT_RUN",
    "clippy": "NOT_RUN",
    "mutation": "NOT_RUN",
    "full_gate": "NOT_RUN",
}
(ROOT / "validation.json").write_text(
    json.dumps(receipt, ensure_ascii=False, indent=2) + "\n"
)
print(json.dumps(receipt, ensure_ascii=False, indent=2))
raise SystemExit(0 if passed else 1)
