"""Freeze the complete non-document Git-visible engineering path set."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path.cwd()
paths = subprocess.check_output(
    ["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"]
).split(b"\0")
rows = [
    {"path": name.decode(), "sha256": hashlib.sha256((root / name.decode()).read_bytes()).hexdigest()}
    for name in sorted(set(paths))
    if name and not name.startswith(b"docs/") and (root / name.decode()).is_file()
]
aggregate = "".join(f"{row['path']}\0{row['sha256']}\n" for row in rows).encode()
value = {
    "count": len(rows), "aggregate_sha256": hashlib.sha256(aggregate).hexdigest(),
    "inputs": rows,
}
with Path(sys.argv[1]).open("x") as stream:
    json.dump(value, stream, indent=2)
    stream.write("\n")
print(json.dumps({key: value[key] for key in ["count", "aggregate_sha256"]}))
