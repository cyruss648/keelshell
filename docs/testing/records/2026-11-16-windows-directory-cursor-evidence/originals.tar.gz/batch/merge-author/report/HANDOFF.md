# 合并审核回归候选交付

结论：已准备一个仅修改测试同步的候选，尚未集成或编译。静态确认原用例存在
真实竞态；原 CI 缺少当时 busy/status 等状态，不能确认该竞态是该次失败的唯一根因。
未发现需要修改生产行为的充分证据。

- 基线 HEAD：`80397acc98d5881cbd177d7259a54fd7f1556c4f`。
- 唯一候选文件：`crates/keelshell-app/src/files/conflict_merge_tests.rs`。
- 补丁：`../patch/merge-review-race.patch`，一个 hunk，15 行增加、5 行删除。
- 原文件在失败源码 `878f13b4cb58a45dfe96f32fc1c389ac7799366d`
  与本基线逐字节一致；追踪的生产 files/merge/worker 及 Cargo.lock 也一致。

## 已确认的机制与修改

原用例 532–540 行仅执行 32 次 `cx.run_until_parked()`，没有等待完成保证。
`merge.rs:196` 先撤销旧 review；真实 transport worker 的结果经 `files.rs:1801`
的 16ms GPUI 定时器轮询送达。锁定的 gpui-pre 0.3.12 中，
`platform/test/dispatcher.rs:76` 仅排空可运行任务；
`gpui-pre-scheduler` 的 TestClock 需要显式推进。
因此 worker 尚未返回，或者接收器已停在未推进的定时器上时，32 轮仍可能结束，
随后对 replacement review 的 `checked_option` 会 panic。

候选改为检查 `!busy && operation_id.is_none()`；未完成时给真实线程 1ms 让步、
显式推进 GPUI 时钟 1ms，再排空就绪任务。等待使用墙钟 12 秒有界上限，
数值沿用既有 `Harness::idle`，没有增大现有超时常量。原循环没有时间保证，
既有 idle 使用 GPUI 测试时间；两者时钟语义并不等同。
没有重新请求读取、自动重试、跳过用例或新增主动重绘。

等待之后的全部原代码逐字节保留，包括新旧 UUID、active、未选 choices、
四种 retained pointer dispatch、草稿、pending、远端精确字节及零 atomic writes。
生产 select/choose/adopt/close 均核对 review UUID；receive_merge 仍核对路径、
基线、格式与草稿。没有生产补丁。

## 实际证据及边界

- 原完整日志保持原位，SHA-256：
  `66d534fd679d75a1d922c9269db55d55f98a49a2ae6632a947ac57b9ccaf8980`。
  本目录保存失败摘要 `previous-macos-failure-excerpt.log`。
- Quality `43815115588`，macOS job `133125295686`：
  `1338 passed / 1 failed / 2 ignored / 739.41s`；
  唯一失败为 stale_merge_frame_actions，旧日志指向 transfer_tests.rs:1747:32，
  消息 `replacement merge review`。
- 父最新提供旧 CI 终态：整体 failure；Ubuntu success，Mac/Windows failure。
  本片未查询远端，也未覆盖旧失败。
- 直接 `rustfmt --check --edition 2024 --config skip_children=true` 实际 exit 0。
  版本、命令及输出见 `rustfmt-check.json`。
- 12 项静态结构检查通过；单文件单 hunk 补丁在内存精确重建出候选字节。
  见 `static-validation.json`、`patch-validation.json`、`source-provenance.json`。
- Rust 编译、Clippy、Rust 测试、原生/UI 执行均为 **0**；未运行 Cargo，
  未访问共享 target，未进行 Git 写入，未创建 agent/chat/worktree 或后台任务。
  所有本片写入仅在指定目录的 baseline/candidate/patch/report。
  正式源码、transfer_tests.rs 及 Windows 两文件均未由本片修改。

## 父接续

按 SHARED_TARGET 取得构建槽；若切换源码副本，先按合同失效项目包并核对编译库存。
集成后先编译并单次执行：

```sh
cargo test --locked -p keelshell-app --bin keelshell-app files::transfer_tests::conflict_merge_tests::stale_merge_frame_actions_cannot_mutate_a_replacement_review -- --exact --nocapture --test-threads=1
```

应实际 `1/0/0`，再运行 conflict_merge_tests 模块及父集中 gate；任何失败保留原件，
不以重跑直到绿色代替证据。若仍缺 review，区分 worker 未结束与已结束但生产拒绝结果。
安全敏感的补充验证可分别移除 choose/close 的 UUID 检查，确认原断言能拒绝变异；
本片未执行变异验证，不声明四种回调均有独立变异拒绝证据。

风险：新增的是测试中的墙钟同步和显式虚拟时钟推进，仍需真实编译及调度验证；
不签原生验收，也不宣称旧 CI 已修复。作者已收尾，无需继续保持作者任务。

## SHA-256

| 产物 | SHA-256 |
| --- | --- |
| baseline 文件 | `990b9a089f15181b4d25977a402bd18cd79aa9ca4d88a1b7eb47dadfec3ae19a` |
| candidate 文件 | `ee205fc703c0b253252bfcf6c02dbdc914c3f536f209ba458183f516cc059efa` |
| patch | `dd84f658c4b778df20d8de6987105b668b3705c0a897a7db4ffacea8f50a8a5b` |
