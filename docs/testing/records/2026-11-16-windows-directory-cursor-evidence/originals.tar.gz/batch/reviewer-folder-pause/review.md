# 普通目录暂停测试：新非作者只读评审

结论：**APPROVE（仅本片源码）**。P0=0、P1=0、P2=0、P3=0；无阻断或建议性代码问题。

- 评审时间：2026-11-16T14:49:09+08:00。
- 基线与首末读回 HEAD：`80397acc98d5881cbd177d7259a54fd7f1556c4f`。
- 唯一评审对象：`crates/keelshell-app/src/files/transfer_tests.rs` 中 `ordinary_folder_transfer_pause_and_cancel_preserve_partial_tree_status` 的未提交 diff，29 行增加 / 6 行删除；变化仅在该函数内。
- 当前文件 SHA-256：`2605bd3278f85f1aa9fbd143601441c088adafcb6c0b5b47f70bc155e3ba1f52`；原始 Git diff SHA-256：`53d2aaf1caec02c432c8d131814547bd61fee3f0e9ece40bbf186d875381b3cc`。
- 已读 RTK、AGENTS、HANDOFF、SHARED_TARGET、rust-best-practices / rust-engineer 及相关 testing/async/pointer 参考。遵守本次更窄授权；其他 Windows 两文件和并行 merge 候选不在范围。依赖源码仅用于追踪本片的既有同步语义。

## 源码核对

1. **确实命中普通目录 fresh target**：`transfer_tests.rs:1588-1598` 创建全新普通目录及 768 KiB 文件，hold 使用 `/ordinary-tree/data.bin`。`files.rs:3623-3624` 引用 session 的真实 SFTP fixture；`tests/fixtures/sftp.rs:509-516` 设置 exact target、prefix=false，`:75-82` 只匹配 offset>0 的该 handle。`:817-820` 的 handle 就是 filename。目录实现 `src/sftp/directory.rs:219-225` 直接以 CREATE|WRITE|EXCLUDE 创建该目标，不走 atomic 临时文件。
2. **首个 WRITE 与真实进度**：fixture gate 允许 offset=0，`:855-884` 先 hold、后修改与成功 STATUS。目录实现 `directory.rs:229-245` 以 64 KiB 缓冲串行 await WRITE，确认成功后才记 progress；缓冲常量见 `sftp.rs:1329`。测试 `transfer_tests.rs:1603-1610` 同时等待 hold.entered>0、transferred>0 与 Running；不以伪造状态替代写入/ACK。
3. **selected job 与准确 channel**：`transfer_tests.rs:1612-1623` 从 panel.transfer_pause 安装观察器，false 不阻断转发。`parallel.rs:475-490` 为该任务创建 watch 并 select；`:226-234` 暴露 selected job 的 sender；`transfer.rs:155-158`、`parallel.rs:255-271` 将暂停操作转到该任务。`pause_handoff_fixture.rs:89-101` 用 same_channel 精确查找；`worker.rs:172-177` 在真实 TransferHandle::pause() 返回后才记录 forwarded，因此不能由 sibling channel 或 UI Pausing 状态冒签。
4. **release 顺序成立**：`transfer_tests.rs:1622-1629` 先观察 forwarded，再拒绝过期状态，最后 release、等待 Paused。`sftp.rs:234-235`、`control.rs:61-62` 已将暂停写入 session 的 requested_pause。目录第二次 WRITE 完成后必须进入 `context.progress()` / `checkpoint()`（`directory.rs:242-245`、`control.rs:221-236`），`:187-210` 发出真实 Paused 并等待，无法先写完剩余 768 KiB 再把完成视为暂停。
5. **异常 guard 有界**：`tests/fixtures/sftp.rs:131-148` 的 consuming release 与 Drop 清除同一 Arc 身份的 gate 并唤醒；`:89-108`、`:856-859` 的 10 秒兜底置 expired 并失败，非悄然放行。`pause_handoff_fixture.rs:70-74` 的 Drop 放行自己的 observer；本片使用非阻塞观察器，异常不引入 join/sleep 或无限等待。此为静态控制流判断，未独立注入 panic。
6. **原断言逐字节保持**：从 `h.phase(cx, TransferPhase::Paused).await;` 到函数末尾，与基线字节相同；`transfer_tests.rs:1629-1641` 仍检查 Paused、取消后 Cancelled、非空且小于源长度的 partial、精确 prefix 和 SSH 未关闭。函数外源码与基线逐字节相同；原 8 秒 Running 等待及 helper 的 12 秒 phase/idle 等待保持（`:209-223`），新增 5 秒 handoff 等待是条件同步。未扩原 deadline、无 skip/ignore、无 retry、无删改安全断言。

上述路径除显式说明外均以 `crates/keelshell-app/src/files/` 为前缀；session 路径以 `crates/keelshell-session/` 为前缀。

## 已有运行证据与边界

- 独立实际 Cargo 命令 **0**；独立执行测试 **0**，UI **0**，agent **0**。未运行 fmt/Clippy/check.py、未访问或修改 target、未写正式源码或 Git；仅写本 reviewer 目录。未开发审计框架。
- 只读核对作者原件，两个 log 的实际字节数与 SHA-256 均匹配对应 JSON。用户所说 integration 原件实际位于批次目录根，未找到嵌套 integration 子目录。
- 旧 `full-gate-r1`：observed/controller exit=1、direct_reaped=true、active_processes=0、485.786657166 秒；log `:2352-2355` 只有该用例的 12 秒 UI condition timeout，具体 await UNKNOWN；`:2361` app 1338 passed / 1 failed / 2 ignored。旧失败保持，不根据本次逻辑反推所有旧失败根因。
- 修后 `folder-pause-focused-r1`：observed/controller exit=0、direct_reaped=true、active_processes=0、16.626790750 秒；log `:1-2` 有当前 checkout 的 session/app Compiling，`:11-14` 精确该用例 1 passed / 0 failed / 0 ignored、1340 filtered、0.41 秒。此为作者实际编译专项证据，不是独立 Cargo 验证；链接器有原始 unwind table 大小 warning，未隐去。

- `work/windows-directory-cursor-integration-20261116/full-gate-r1.json` SHA-256 `83f851068b4dba94d37aca70b10ab6717ca607a99eee9a50cf0e20eb037123ce`; log SHA-256 `3a703cfbc1feadae8774d84e92c21bd63511f1b734b7bf7ea8608433ef260db1`。
- `work/windows-directory-cursor-integration-20261116/folder-pause-focused-r1.json` SHA-256 `365316de838a80ed1b3a73ece8d283fca02cd3851b61ac41e672edd1e179c8a9`; log SHA-256 `6cb70748fc5cd4e2a9147a58e85ae4aa7878bca61729d870631f4b3504ad8e94`。

建议：接受这片未提交测试修订；后续由父任务按其冻结输入完成最终完整 gate，保留旧失败与新编号。本 reviewer 不等待、不运行该 gate。**源码通过 ≠ 旧失败根因全部证实 ≠ 未来完整 gate 通过**；本报告不签 Windows/macOS/Linux 原生验收，也不扩大先前 Windows 静态批准。

本次评审已完成并关闭，无后续运行或等待。
