KeelShell Windows 目录游标修复：独立只读静态评审 r1

结论：**APPROVE_STATIC**。P0=0、P1=0、P2=0、P3=0；未发现需要修改这两处工程源码的问题。建议接受此修复并合入父集成分支，功能提交/推送继续遵守既定父门禁。本报告现在签署，不等待父完整门禁；本批准仅适用于下列冻结源码的静态评审，不能用于签署 Windows 运行恢复、文档正确性或完整产品。

签署时间：`2026-11-16T06:39:12.265619+00:00`。评审者不是作者。HEAD 起止均为 `80397acc98d5881cbd177d7259a54fd7f1556c4f`。冻结为 `work/windows-directory-cursor-integration-20261116/inputs-freeze-r1.json`，719 项工程路径和字节在独立审计起止均完全相等，aggregate 为 `67337a389845e537823adf5d10671d52b9fd3ec95df43ac1634161c1b5022749`。

已读 RTK、AGENTS、HANDOFF、SHARED_TARGET、rust-best-practices/rust-engineer 及相关所有权、错误处理、测试、注释和指针章节。依本次授权，所有写入限于本 reviewer 目录；未运行 Cargo、Rust 测试二进制、编译变异、UI 或 Git 写操作，未创建 agent/chat/worktree。只对 native.rs 和 windows/tests.rs 的差量给出结论；仅阅读必要的相邻类型、解码和安全契约。

| 严重性 | 发现数 | 需要修改的源码问题 |
| --- | ---: | --- |
| P0 | 0 | 无 |
| P1 | 0 | 无 |
| P2 | 0 | 无 |
| P3 | 0 | 无 |

两文件的基线字节也与真实失败的 `878f13b4cb58a45dfe96f32fc1c389ac7799366d` 对应文件完全相等，当前字节与 `integration/author/candidate/` 原候选相等。作者 README、两份原 patch、validation 等 15 份保留原件的路径、大小、SHA-256 全部匹配父保存的 author-copy receipt；未运行会覆盖作者 validation.json 的 verify_candidate.py。作者完整第三方正文未重分发，没有将其缺席判为损坏。

| 工程文件 | 基线 SHA-256 | 当前 SHA-256 |
| --- | --- | --- |
| `crates/keelshell-platform/src/windows/native.rs` | `1e439a8de27af7f8a46ea1d3fdcc454c7752cd7f50328b52f8532d7c519bd7d3` | `0fc2f6e04ae09ce5ad30eacaf09b5c5cc42d59e5b733ea0df0b4d757ffb2b986` |
| `crates/keelshell-platform/src/windows/tests.rs` | `797f725c9b07048b9a508b8edab3227ba595f5a219eaa500fc9bc1ac3c660244` | `7bbcd69bd03b15b91903b6a4ead4c56173a5456c05b0366e861ec921f08fded2` |

机制核对结果如下。表中“通过”表示源码及契约核对通过；实际 Windows 结果另列。

| 关注点 | 精确位置 | 结论与理由 |
| --- | --- | --- |
| 空相对 NT reopen | [native.rs:284](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:284)、[native.rs:289](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:289) | 通过。RootDirectory 来自借用的持有句柄，空名通过现有 NtCreateFile/FILE_OPEN 打开；没有路径恢复、缓存原路径、DuplicateHandle/try_clone、点子项或失败回退。新打开请求意在取得自己的扫描状态。空名在本项目实际 Windows 文件系统上得到独立 file object 的最终证据仍需运行新测试。 |
| UTF-16 与空名 backing | [native.rs:103](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:103)、[native.rs:111](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:111) | 通过。先按 UTF-16 单元数 checked_mul(2) 并 checked u16 转换，再 push(0)。Length/MaximumLength 保持原名字的字节计数，NUL 不计入；空名有实际 u16 存储。push 发生在取指针之前，调用期间 Vec 不再变动。 |
| FFI 同步与 RAII | [native.rs:142](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:142)、[native.rs:164](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:164)、[native.rs:181](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:181)、[native.rs:297](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:297) | 通过。原 FILE_SYNCHRONOUS_IO_NONALERT、含 SYNCHRONIZE 的访问权、栈 IOSB、同步查询和一次 File::from_raw_handle 保持。新 helper 返回 owned File；校验失败时 RAII 关闭，entries 在循环结束时关闭独立 cursor；parent 仅借用。没有新增生产 unsafe 块。 |
| 身份、DACL 和目录类型 | [native.rs:285](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:285)、[native.rs:290](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:290)、[mod.rs:81](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/mod.rs:81) | 通过。先取原 directory_stamp，再重开并比较。stamp 包含 volume/file identity、attributes、owner/group/DACL observation，目录类型错误先拒绝；不比较受兄弟写入影响的目录时间。没有给普通父目录额外强制 private DACL，也没有放宽私有对象检查。 |
| reparse 与实际本地卷 | [native.rs:123](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:123)、[native.rs:165](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:165)、[native.rs:186](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:186)、[native.rs:193](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:193)、[native.rs:254](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:254) | 通过。OBJ_DONT_REPARSE、FILE_OPEN_REPARSE_POINT、目录选项、metadata 的 reparse/delete-pending 拒绝、实际持有卷 remote-device 拒绝均逐字节保留。新 cursor 同样经过这些检查。并发转为 reparse 的真实 Windows 注入未执行。 |
| 原枚举算法 | [native.rs:299](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:299)、[native.rs:335](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:335) | 通过。64 KiB 分批循环、首批 restart=true/后续 false、EOF、长度和解码边界，以及之后 rename/错误转换代码逐字节相同。 |

新增回归的静态判断：

| 用例及位置 | 可捕获的错误与边界 |
| --- | --- |
| [reopened_directory_cursors_do_not_advance_or_restart_other_live_scans:372](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/tests.rs:372) | parent 先取一项，first cursor 再取一项，两者均保持存活，然后耗尽 second；随后继续 first 与 parent，每个结果都精确等于四个名字。helper 在每次查询使用 ReturnSingleEntry=true、RestartScan=false，因此共享游标会缺项；若在 opener 中重置已有扫描，会造成缺项或重复项而失败。这个顺序不依赖线程调度。包含中文和非 BMP 名称。以上为失败路径推演，DuplicateHandle/try_clone 编译变异没有执行。 |
| [directory_cursor_keeps_the_held_identity_when_its_original_path_is_rebound:398](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/tests.rs:398) | held 改名 moved 后，在旧 held 路径创建 replacement-only，原对象保留 original-only。重开 cursor 的 stamp 必须等于旧 stamp，held.entries 必须返回旧 marker，新路径返回新 marker；按缓存旧路径重开会返回错误身份或被 stamp guard 拒绝，测试均不能通过。此用例并不单独区分从持有句柄取当前路径再重建的实现；本片通过源码确认没有该实现。 |
| [directory_cursor_preserves_private_dacl_and_rejects_regular_files:419](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/tests.rs:419) | 重开真实 private staging 后，分别 verify_private(cursor)、完整 stamp 等值、verify_private(stage)，并拒绝普通文件作为目录游标。没有用 mock DACL 或删去原权限断言。 |
| [next_cursor_name:302](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/tests.rs:302)、[finish_cursor:358](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/tests.rs:358) | u64 对齐的 1 KiB 活缓冲足够容纳 fixture 单条名字；先验证 IOSB length，再由已有 decoder 检查记录和 UTF-16。单条 helper 最多 3 次 query（两 dot 加一项），收尾最多 5 步（四项加 EOF），错误继续传播。循环有界不等于 OS syscall 墙钟限时；本次没有签署运行耗时。 |

原测试保留：本文件从 19 项增至 22 项，仅插入 133 行；删去这一新增块后，文件与基线逐字节相同。原 49 处 assert/assert_eq/assert_ne 调用及全部 helper/fixture 保留，当前为 59 处。原并发回归 [tests.rs:266](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/tests.rs:266) 与跨 64 KiB 回归 [tests.rs:434](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/tests.rs:434) 的完整原正文均精确相等。后者仍创建 1,100 个长名字并比较完整集合，不缩小到单批枚举。其他工程文件与冻结一致，没有删除原安全断言。

已从持久 `delivery.tar.gz` 直接在内存读取完整 Windows 失败日志，磁盘解包 0。日志为 72,320 字节，SHA-256 `955d86d6b266c69108844757391dd8766e89837be5ebea936b66ed3da07ccf6b`，含精确 `878f13b...` 身份；16 个失败区块与作者提取件逐项一致。`nt-create-file / InvalidFilename / Some(123) / NTSTATUS=0xc0000033` 与外层 `open-directory-cursor` 各 23 条，表示同一错误在两个层次观察，不能相加成 46 个独立故障。真实旧结果仍为 platform **48 passed / 16 failed / 0 ignored**，旧完整 gate **NOT_RUN**。

| 原失败用例（windows::tests:: 前缀省略） | 当前函数行 | 保留和运行状态 |
| --- | --- | --- |
| `complete_private_tree_is_published_through_its_retained_root` | [124](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/tests.rs:124) | 原正文及断言保留；新 Windows 结果未验证 |
| `component_relative_operations_reject_every_escape_before_native_io` | [489](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/tests.rs:489) | 原正文及断言保留；新 Windows 结果未验证 |
| `directory_enumeration_continues_after_a_full_native_query_buffer` | [434](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/tests.rs:434) | 原正文及断言保留；新 Windows 结果未验证 |
| `directory_no_replace_syscall_preserves_other_empty_directories` | [154](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/tests.rs:154) | 原正文及断言保留；新 Windows 结果未验证 |
| `directory_rename_buffers_cover_one_and_255_utf16_unit_names` | [233](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/tests.rs:233) | 原正文及断言保留；新 Windows 结果未验证 |
| `exclusive_create_preserves_an_existing_file_directory_and_case_alias` | [66](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/tests.rs:66) | 原正文及断言保留；新 Windows 结果未验证 |
| `existing_private_entry_can_be_reopened_only_after_the_creation_writer_closes` | [474](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/tests.rs:474) | 原正文及断言保留；新 Windows 结果未验证 |
| `file_rename_buffers_cover_one_and_255_utf16_unit_names` | [228](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/tests.rs:228) | 原正文及断言保留；新 Windows 结果未验证 |
| `held_file_publication_retains_identity_and_leaves_no_old_name` | [80](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/tests.rs:80) | 原正文及断言保留；新 Windows 结果未验证 |
| `private_directory_and_child_creation_do_not_rely_on_default_permissions` | [53](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/tests.rs:53) | 原正文及断言保留；新 Windows 结果未验证 |
| `private_file_has_its_verified_dacl_before_the_first_content_write` | [37](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/tests.rs:37) | 原正文及断言保留；新 Windows 结果未验证 |
| `private_file_sharing_allows_readback_and_rejects_other_writers_and_delete_openers` | [238](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/tests.rs:238) | 原正文及断言保留；新 Windows 结果未验证 |
| `publication_into_a_retained_private_target_directory_supports_files_and_directories` | [174](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/tests.rs:174) | 原正文及断言保留；新 Windows 结果未验证 |
| `retained_object_rename_never_replaces_a_file_or_empty_directory` | [99](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/tests.rs:99) | 原正文及断言保留；新 Windows 结果未验证 |
| `security_observations_are_opaque_in_public_debug_output` | [503](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/tests.rs:503) | 原正文及断言保留；新 Windows 结果未验证 |
| `simultaneous_enumerations_have_independent_native_scan_positions` | [266](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/tests.rs:266) | 原正文及断言保留；新 Windows 结果未验证 |

原真实 platform 总数为 64；工程差量仅新增三项，故新 Windows 预期为 **67 项**。这是源代码推导，不是 reviewer 实际编译的 inventory，也不是 67 项已执行。须在精确新源码 Windows 日志中逐名核对 3 新项、原 16 个失败项及其余原项，不能仅凭总数或 cross-Clippy 宣称恢复。

执行和证据计数：

| 执行者/证据 | 实际结果 | 能证明的范围 |
| --- | --- | --- |
| reviewer Python 静态完整性审计 | 1 轮，脚本 exit 1；35 项检查中 34 PASS、1 原始 FAIL；审计内只读 Git 子命令 10 条，均 exit 0 | 唯一 FAIL 是检查器把父同期 docs 更新误算入“两工程文件”的范围，见下段；没有源码、冻结、patch、原件或旧失败日志匹配失败。原 receipt 不覆盖，不重复审计。 |
| reviewer 手工范围纠正 | 1 项；工程变更精确为两文件 | 对原 receipt 已记录的 changed paths 按本次工程范围排除 docs，确认只有 native.rs/tests.rs；不重新运行整个审计，不签文档内容。 |
| reviewer Rust/Cargo/预编译测试/Windows/编译变异/UI | 全部 0 | 没有使用或改动共享 target。没有独立运行时成功计数。 |
| 父 scoped-gate-r1，已读完整 log/receipt 并核 hash | exit 0 / reaped / 3.2129445s；4 个子命令 | 本机 platform 18/0/0；Windows 全 target cross-Clippy -D warnings、fmt、x.y 均通过。18 个 host 名称不含 Windows 模块，不能签新三项或旧 16 项 Windows 恢复。 |
| 父新鲜依赖查询 | 用户更新：37 包/113 声明全部通过、UNKNOWN=0 | 本评审没有扩大到依赖审查，也不将旧诊断批 UNKNOWN 数据移签到此批。 |
| 父新完整 full-gate-r1 | 签署前用户报告仍运行；本 reviewer 未读取或等待其终态 | 不预签成功，不把旧 gate NOT_RUN 改为通过。 |

审计检查器的范围误判明确保留：r1 的 changed paths 是 native.rs、tests.rs、docs/HANDOFF.md、docs/adr/0138-windows-handle-local-files.md。检查名是 only_two_engineering_files_changed，但实现误对全部 diff paths 作比较，导致 exit 1。按本次明确工程范围过滤 docs 后正好两文件，且起止 719 项工程路径/哈希已经全部匹配。这是 reviewer 核验脚本的范围错误，不是产品源码缺陷；不计为 P0–P3 源码发现。未为取得绿码再运行审计，原失败 JSON 完整保留。

外部语义依据：独立 HTTP 读取 4 个官方正文均为 200，仅保存 URL、读取时间、字节数、SHA-256 和命中标记；三份与作者来源相同的正文摘要一致。Microsoft NtCreateFile 支持相对 RootDirectory、目录/同步/访问权契约，NtQueryDirectoryFile 描述 file object 扫描及 restart；UNICODE_STRING 给出字节计数契约。Rust 官方 remove_dir_all 的空相对名寻址为实现先例。它们不直接证明本项目的独立目录 cursor 已在 Windows 成功；尤其不能把上游删除对象的空名先例代签为本项目枚举回归。没有重分发完整第三方正文。

尚未验证：新冻结的 Windows 原生执行/实际 67 项 inventory、三项新回归真实结果、共享/重置游标或旧路径 rebind 的可编译变异红绿、旧 16 项真实恢复、app 八项原归档回归及原正文断言是否真正到达、新完整 gate 终态、并发 reparse 注入、更广 Windows/文件系统矩阵、Windows GUI/跨平台原生产品与发行安装。**不能签署 app 八项已恢复。**

合并建议：代码层面接受这两个文件的修复；静态批准不要求等待未来门禁再签。父可按既定集中门禁流程提交/推送本片以获得精确 Windows 证据；是否签署 Windows 故障恢复须依据后续真实运行另记。若源码字节变化，本报告不自动覆盖新字节。reviewer 本次工作到此结束，不继续轮询父完整 gate。
