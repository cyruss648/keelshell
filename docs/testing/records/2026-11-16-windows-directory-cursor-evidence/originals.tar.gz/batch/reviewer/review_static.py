"""Read-only review integrity checks; all output stays beside this script."""

from datetime import datetime, timezone
from difflib import SequenceMatcher, unified_diff
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
INTEGRATION = OUT.parent
AUTHOR = INTEGRATION / "author"
BASE = "80397acc98d5881cbd177d7259a54fd7f1556c4f"
PREDECESSOR = "878f13b4cb58a45dfe96f32fc1c389ac7799366d"
AGGREGATE = "67337a389845e537823adf5d10671d52b9fd3ec95df43ac1634161c1b5022749"
FILES = [
    "crates/keelshell-platform/src/windows/native.rs",
    "crates/keelshell-platform/src/windows/tests.rs",
]
NEW_TESTS = [
    "reopened_directory_cursors_do_not_advance_or_restart_other_live_scans",
    "directory_cursor_keeps_the_held_identity_when_its_original_path_is_rebound",
    "directory_cursor_preserves_private_dacl_and_rejects_regular_files",
]
commands = []
checks = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    command = ["git", "--no-optional-locks", *args]
    result = subprocess.run(command, cwd=ROOT, capture_output=True, check=False)
    commands.append(
        {
            "argv": command,
            "exit_code": result.returncode,
            "stdout_sha256": sha(result.stdout),
            "stderr": result.stderr.decode(errors="replace"),
        }
    )
    if result.returncode:
        raise RuntimeError("read-only Git command failed")
    return result.stdout


def check(name, passed, evidence):
    checks.append({"name": name, "passed": bool(passed), "evidence": evidence})


def aggregate(rows):
    return sha("".join(f"{row['path']}\0{row['sha256']}\n" for row in rows).encode())


def snapshot():
    names = git("ls-files", "--cached", "--others", "--exclude-standard", "-z").split(b"\0")
    return [
        {"path": name.decode(), "sha256": sha((ROOT / name.decode()).read_bytes())}
        for name in sorted(set(names))
        if name and not name.startswith(b"docs/") and (ROOT / name.decode()).is_file()
    ]


head = git("rev-parse", "HEAD").decode().strip()
check("head_exact", head == BASE, head)
changed = git("diff", "--name-only").decode().splitlines()
check("only_two_engineering_files_changed", sorted(changed) == sorted(FILES), changed)
frozen_bytes = (INTEGRATION / "inputs-freeze-r1.json").read_bytes()
frozen = json.loads(frozen_bytes)
check("freeze_count", frozen["count"] == len(frozen["inputs"]) == 719, frozen["count"])
check(
    "freeze_aggregate_exact",
    aggregate(frozen["inputs"]) == frozen["aggregate_sha256"] == AGGREGATE,
    frozen["aggregate_sha256"],
)
start = snapshot()
check(
    "initial_engineering_path_set_exact",
    [x["path"] for x in start] == [x["path"] for x in frozen["inputs"]],
    len(start),
)
check("initial_719_hashes_exact", start == frozen["inputs"], aggregate(start))

author_receipt = json.loads((INTEGRATION / "author-copy-r1.json").read_text())
retained = author_receipt["retained"]
actual_author_paths = sorted(str(p.relative_to(AUTHOR)) for p in AUTHOR.rglob("*") if p.is_file())
expected_author_paths = sorted(row["path"] for row in retained)
check(
    "author_exact_15_retained_paths",
    actual_author_paths == expected_author_paths and len(retained) == 15,
    len(actual_author_paths),
)
author_hashes = []
for row in retained:
    data = (AUTHOR / row["path"]).read_bytes()
    author_hashes.append(
        {
            "path": row["path"],
            "bytes": len(data),
            "sha256": sha(data),
            "matches": len(data) == row["bytes"] and sha(data) == row["sha256"],
        }
    )
check("author_15_retained_files_exact", all(row["matches"] for row in author_hashes), 15)
source_files = []
original = {}
current = {}
patches = []
for name in FILES:
    before = git("show", f"{BASE}:{name}")
    predecessor = git("show", f"{PREDECESSOR}:{name}")
    after = (ROOT / name).read_bytes()
    original[name] = before.decode()
    current[name] = after.decode()
    source_files.append(
        {
            "path": name,
            "baseline_sha256": sha(before),
            "current_sha256": sha(after),
            "baseline_equal_predecessor": before == predecessor,
            "baseline_equal_author": before == (AUTHOR / "baseline" / name).read_bytes(),
            "candidate_equal_author": after == (AUTHOR / "candidate" / name).read_bytes(),
        }
    )
    patches.append(
        "".join(
            unified_diff(
                before.decode().splitlines(keepends=True),
                after.decode().splitlines(keepends=True),
                fromfile="a/" + name,
                tofile="b/" + name,
            )
        )
    )
check(
    "both_80397_baselines_equal_878f13b",
    all(x["baseline_equal_predecessor"] for x in source_files),
    source_files,
)
check(
    "both_author_baselines_exact",
    all(x["baseline_equal_author"] for x in source_files),
    2,
)
check(
    "both_author_candidates_equal_reviewed_source",
    all(x["candidate_equal_author"] for x in source_files),
    2,
)
check(
    "combined_original_patch_exact",
    "".join(patches) == (AUTHOR / "candidate.patch").read_text(),
    sha((AUTHOR / "candidate.patch").read_bytes()),
)
check(
    "original_implementation_patch_exact",
    patches[0] == (AUTHOR / "implementation.patch").read_text(),
    sha((AUTHOR / "implementation.patch").read_bytes()),
)

before = original[FILES[1]]
after = current[FILES[1]]
start_marker = "// Return one non-dot entry without ever restarting the held native scan."
end_marker = "#[test]\nfn directory_enumeration_continues_after_a_full_native_query_buffer"
a = after.index(start_marker)
b = after.index(end_marker)
check(
    "all_original_test_file_bytes_preserved",
    after[:a] + after[b:] == before,
    {"inserted_lines": len(after[a:b].splitlines()), "removed_original_lines": 0},
)
opcodes = SequenceMatcher(a=before.splitlines(), b=after.splitlines(), autojunk=False).get_opcodes()
check(
    "test_diff_only_inserts",
    all(tag in ("equal", "insert") for tag, *_ in opcodes),
    [tag for tag, *_ in opcodes],
)
old_tests = re.findall(r"#\[test\]\s+fn\s+(\w+)", before)
new_tests = re.findall(r"#\[test\]\s+fn\s+(\w+)", after)
added = [name for name in new_tests if name not in old_tests]
check(
    "exactly_three_new_tests_all_old_names_retained",
    added == NEW_TESTS and set(old_tests) <= set(new_tests),
    {"before_this_module": len(old_tests), "after_this_module": len(new_tests), "added": added},
)
old_assertions = len(re.findall(r"\bassert(?:_eq|_ne)?!\s*\(", before))
new_assertions = len(re.findall(r"\bassert(?:_eq|_ne)?!\s*\(", after))
check(
    "all_original_assertions_preserved",
    after[:a] + after[b:] == before and new_assertions > old_assertions,
    {"old_assertion_sites": old_assertions, "current_assertion_sites": new_assertions},
)
for name in (
    "simultaneous_enumerations_have_independent_native_scan_positions",
    "directory_enumeration_continues_after_a_full_native_query_buffer",
):
    position = before.index("fn " + name)
    following = before.find("\n#[test]", position)
    body = before[position : following if following >= 0 else len(before)]
    check(name + "_body_exact", body in after, name)
check(
    "no_new_ignore_or_should_panic",
    not re.search(r"#\[(?:ignore|should_panic)", after[a:b]),
    "new test insertion only",
)
native_before = original[FILES[0]]
native_after = current[FILES[0]]
native_prefix = native_after[: native_after.index("pub(super) fn directory_cursor(")]
native_old_prefix = native_before[: native_before.index("pub(super) fn entries(")]
backing = (
    "    // Keep live backing storage even for an empty handle-relative reopen name.\n"
    "    // UNICODE_STRING counts only the name; this terminator is not included.\n"
    "    encoded.push(0);\n"
)
check(
    "preexisting_open_metadata_and_volume_code_exact_except_backing",
    native_prefix.replace(backing, "", 1) == native_old_prefix,
    "all old flags, access, metadata, local_device and ownership preserved",
)
loop_marker = "    let mut storage = vec![0u64; 8192];"
check(
    "enumeration_loop_and_native_tail_byte_exact",
    native_after[native_after.index(loop_marker) :] == native_before[native_before.index(loop_marker) :],
    "64 KiB loop, restart handling, decoding, rename and NT error conversion unchanged",
)

archive = ROOT / "docs/testing/records/2026-11-16-windows-native-diagnostics-evidence/delivery.tar.gz"
with tarfile.open(archive, "r:gz") as stream:
    member = next(m for m in stream.getmembers() if m.name == "windows-native-job-log-r2.log")
    raw_log = stream.extractfile(member).read()
text = raw_log.decode()
check(
    "historical_full_windows_log_exact_in_memory",
    sha(raw_log) == "955d86d6b266c69108844757391dd8766e89837be5ebea936b66ed3da07ccf6b"
    and len(raw_log) == 72320
    and PREDECESSOR in text,
    {"bytes": len(raw_log), "sha256": sha(raw_log), "disk_extractions": 0},
)
sections = re.findall(r"---- ([^\r\n]+?) stdout ----", text)
old_receipt = json.loads((AUTHOR / "evidence/platform-preflight-receipt.json").read_text())
failed = [row["test"] for row in old_receipt["per_test_failure_sections"]]
check(
    "historical_16_failure_names_reconcile",
    sorted(sections) == sorted(failed) and len(failed) == 16,
    failed,
)
check(
    "all_16_failed_tests_still_present",
    all(name.removeprefix("windows::tests::") in old_tests for name in failed),
    16,
)
create_count = text.count(
    "native-files operation=nt-create-file kind=InvalidFilename raw_os_error=Some(123) nt_status=0xc0000033"
)
cursor_count = text.count(
    "native-files operation=open-directory-cursor kind=InvalidFilename raw_os_error=Some(123) nt_status=None"
)
check(
    "historical_failure_result_and_native_pairs_exact",
    "48 passed; 16 failed; 0 ignored" in text
    and create_count == cursor_count == 23,
    {"passed": 48, "failed": 16, "ignored": 0, "nt_create_lines": create_count, "cursor_lines": cursor_count},
)

scope_receipt_bytes = (INTEGRATION / "scoped-gate-r1.json").read_bytes()
scope_receipt = json.loads(scope_receipt_bytes)
scope_log = (INTEGRATION / "scoped-gate-r1.log").read_bytes()
scope_text = scope_log.decode()
check(
    "parent_scoped_gate_terminal_zero_reaped",
    scope_receipt["observed_exit"] == scope_receipt["controller_exit"] == 0
    and scope_receipt["terminal"]["direct_reaped"]
    and scope_receipt["terminal"]["active_processes"] == 0
    and scope_receipt["terminal"]["pipes_drained"]
    and not scope_receipt["timed_out"]
    and not scope_receipt["interrupted"],
    {"seconds": scope_receipt["seconds"], "receipt_sha256": sha(scope_receipt_bytes)},
)
check(
    "parent_scoped_log_exact",
    len(scope_log) == scope_receipt["log_bytes"] and sha(scope_log) == scope_receipt["log_sha256"],
    {"bytes": len(scope_log), "sha256": sha(scope_log)},
)
host_names = re.findall(r"^test ([^\s]+) \.\.\. ok$", scope_text, re.MULTILINE)
check(
    "parent_host_18_not_windows_runtime",
    len(host_names) == 18
    and "18 passed; 0 failed; 0 ignored" in scope_text
    and not any(name.startswith("windows::") for name in host_names),
    host_names,
)
check(
    "parent_four_scoped_commands_logged",
    len(re.findall(r"^Running:", scope_text, re.MULTILINE)) == 4
    and "Dependency version policy: passed" in scope_text
    and "cargo fmt --all --check" in scope_text
    and "--all-targets --target x86_64-pc-windows-msvc -- -D warnings" in scope_text
    and "Checking keelshell-platform" in scope_text,
    "readback only; reviewer Cargo executions 0",
)
git("diff", "--check", "--", *FILES)
check("git_diff_check", True, "exit 0; no source or Git writes")
end = snapshot()
check(
    "final_engineering_paths_and_719_hashes_exact",
    end == frozen["inputs"] == start,
    aggregate(end),
)
check(
    "author_15_files_still_exact_at_finish",
    all(
        sha((AUTHOR / row["path"]).read_bytes()) == row["sha256"]
        and (AUTHOR / row["path"]).stat().st_size == row["bytes"]
        for row in retained
    ),
    15,
)
check(
    "freeze_file_itself_unchanged",
    (INTEGRATION / "inputs-freeze-r1.json").read_bytes() == frozen_bytes,
    sha(frozen_bytes),
)
check("final_head_exact", git("rev-parse", "HEAD").decode().strip() == BASE, BASE)

receipt = {
    "checked_utc": datetime.now(timezone.utc).isoformat(),
    "review_type": "independent static only",
    "base_head": head,
    "engineering_aggregate_sha256": AGGREGATE,
    "checks_passed": sum(c["passed"] for c in checks),
    "checks_failed": sum(not c["passed"] for c in checks),
    "checks_total": len(checks),
    "checks": checks,
    "reviewed_files": source_files,
    "preserved_author_files": author_hashes,
    "historical_failed_test_names": failed,
    "new_windows_test_names": NEW_TESTS,
    "expected_windows_platform_inventory": {
        "old_from_real_log": 64,
        "added_by_source": 3,
        "expected": 67,
        "compiled_inventory_executed_by_reviewer": False,
    },
    "reviewer_execution_counts": {
        "python_static_audit_runs": 1,
        "read_only_git_subcommands": len(commands),
        "cargo": 0,
        "rust_tests": 0,
        "prebuilt_rust_tests": 0,
        "windows_runtime_tests": 0,
        "compiled_mutations": 0,
        "ui": 0,
        "git_writes": 0,
        "agents_chats_worktrees_created": 0,
        "archive_disk_extractions": 0,
    },
    "commands": commands,
    "parent_scoped_gate": {
        "executed_by": "parent",
        "exit_code": scope_receipt["observed_exit"],
        "seconds": scope_receipt["seconds"],
        "direct_reaped": scope_receipt["terminal"]["direct_reaped"],
        "host_platform": {"passed": 18, "failed": 0, "ignored": 0},
        "child_commands": 4,
        "windows_execution": "NOT_RUN",
    },
    "new_full_gate": "parent reports RUNNING; not read or awaited by reviewer",
}
(OUT / "static-audit-r1.json").write_text(
    json.dumps(receipt, ensure_ascii=False, indent=2) + "\n"
)
print(
    json.dumps(
        {
            key: receipt[key]
            for key in (
                "checks_passed",
                "checks_failed",
                "checks_total",
                "reviewed_files",
                "reviewer_execution_counts",
                "expected_windows_platform_inventory",
            )
        },
        ensure_ascii=False,
        indent=2,
    )
)
sys.exit(0 if receipt["checks_failed"] == 0 else 1)
