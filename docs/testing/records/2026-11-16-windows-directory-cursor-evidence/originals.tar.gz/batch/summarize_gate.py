"""Bind the completed batch gate to its source and executed package inventories."""
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
PREVIOUS = ROOT / "docs/testing/records/2026-11-16-archive-deadline-evidence/raw"
label, freeze_name = sys.argv[1:]

receipt = json.loads((BASE / f"{label}.json").read_text())
data = (BASE / f"{label}.log").read_bytes()
assert receipt["observed_exit"] == receipt["controller_exit"] == 0
assert not receipt["timed_out"] and not receipt["interrupted"]
assert receipt["terminal"] == {
    "direct_reaped": True, "active_processes": 0,
    "pipes_drained": True, "errors": [],
}
assert len(data) == receipt["log_bytes"]
assert hashlib.sha256(data).hexdigest() == receipt["log_sha256"]
text = data.decode()
freeze = json.loads((BASE / freeze_name).read_text())
names = subprocess.check_output(
    ["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"], cwd=ROOT,
).split(b"\0")
paths = {
    name.decode() for name in names
    if name and not name.startswith(b"docs/") and (ROOT / name.decode()).is_file()
}
assert paths == {row["path"] for row in freeze["inputs"]}
assert all(
    hashlib.sha256((ROOT / row["path"]).read_bytes()).hexdigest() == row["sha256"]
    for row in freeze["inputs"]
)
aggregate = "".join(
    f"{row['path']}\0{row['sha256']}\n" for row in freeze["inputs"]
).encode()
assert hashlib.sha256(aggregate).hexdigest() == freeze["aggregate_sha256"]
workspace = text.split(
    "Running: cargo test --workspace --locked -- --test-threads=4\n", 1,
)[1].split("Running: cargo test -p keelshell-ai", 1)[0]
ordinary, rustdoc = workspace.split("   Doc-tests ", 1)


def totals(part):
    rows = [
        tuple(map(int, row)) for row in re.findall(
            r"^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;", part, re.M,
        )
    ]
    assert rows
    return dict(zip(
        ("passed", "failed", "ignored"),
        (sum(row[index] for row in rows) for index in range(3)),
    ))


def package_output(package, target):
    match = re.search(
        r"^     Running " + re.escape(target)
        + r" \(work/recovery-batch-integration-20261115/target/debug/build/"
        + re.escape(package) + r"/[^\n]+\)\n", ordinary, re.M,
    )
    assert match, (package, target)
    return ordinary[match.end():].split("     Running ", 1)[0]


app = package_output("keelshell-app", "unittests src/main.rs")
inventory = set(re.findall(
    r"^(.+): test$",
    gzip.decompress((PREVIOUS / "app-inventory-r1.log.gz").read_bytes()).decode(), re.M,
))
executed = re.findall(r"^test (.+) \.\.\. (?:ok|ignored[^\n]*)$", app, re.M)
assert len(executed) == len(set(executed)) == len(inventory)
assert set(executed) == inventory
archive = package_output("keelshell-session", "tests/server_archive.rs")
archive_names = set(re.findall(r"^test (.+) \.\.\. ok$", archive, re.M))
previous_archive = gzip.decompress(
    (PREVIOUS / "archive-target-r1.log.gz").read_bytes(),
).decode()
assert archive_names == set(re.findall(r"^test (.+) \.\.\. ok$", previous_archive, re.M))
assert len(archive_names) == 40
platform = package_output("keelshell-platform", "unittests src/lib.rs")
retained_host_diagnostic_tests = [
    "native_diagnostics::tests::native_failure_diagnostics_never_format_untrusted_error_messages",
    "native_diagnostics::tests::native_failure_observation_preserves_the_original_typed_os_error",
]
assert all(f"test {name} ... ok" in platform for name in retained_host_diagnostic_tests)
python = re.search(r"^Ran (\d+) tests in [^\n]+\n\nOK \(skipped=(\d+)\)", text, re.M)
assert python
controllers = re.findall(r"^Running: (cargo test -p keelshell-ai[^\n]+)$", text, re.M)
assert len(controllers) == 3
artifacts = {}
for name in ("keelshell-app", "keelshell-mcp"):
    binary = ROOT / "work/recovery-batch-integration-20261115/target/debug" / name
    artifacts[name] = {
        "bytes": binary.stat().st_size,
        "sha256": hashlib.sha256(binary.read_bytes()).hexdigest(),
        "new_normal_build_or_package_acceptance": False,
    }
summary = {
    "gate": receipt,
    "engineering_inputs": freeze["count"],
    "engineering_sha256": freeze["aggregate_sha256"],
    "complete_input_path_and_byte_set_matches": True,
    "rust": {"ordinary": totals(ordinary), "rustdoc": totals(rustdoc)},
    "app": totals(app), "app_inventory_count": len(inventory),
    "app_executed_names_match_prior_compiled_inventory": True,
    "server_archive": {**totals(archive), "exact_40_names_match": True},
    "platform": {**totals(platform), "retained_host_diagnostic_names_passed": retained_host_diagnostic_tests},
    "python": {
        "run": int(python[1]), "passed": int(python[1]) - int(python[2]),
        "skipped": int(python[2]), "failed": 0,
    },
    "format_strict_clippy_xy_policy_and_three_controllers_passed": True,
    "controllers": controllers, "normal_artifacts_observed_only": artifacts,
    "windows_native_execution": 0, "new_native_gui_acceptance": False,
    "windows_expected_inventory": json.loads((BASE / "windows-expected-inventory-r1.json").read_text()),
}
with (BASE / f"{label}-summary.json").open("x") as output:
    json.dump(summary, output, indent=2)
    output.write("\n")
print(json.dumps(summary, indent=2))
