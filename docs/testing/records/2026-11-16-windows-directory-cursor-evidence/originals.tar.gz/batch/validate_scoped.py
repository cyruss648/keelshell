"""Run the relevant host and Windows cross checks in one owned Cargo slot."""
import subprocess
import sys

for command in [
    [sys.executable, "-B", "scripts/check.py", "--policy-only"],
    ["cargo", "fmt", "--all", "--check"],
    ["cargo", "test", "--locked", "-p", "keelshell-platform", "--lib", "--", "--test-threads=1"],
    [
        "cargo", "clippy", "--locked", "-p", "keelshell-platform", "--all-targets",
        "--target", "x86_64-pc-windows-msvc", "--", "-D", "warnings",
    ],
]:
    print("Running: " + " ".join(command), flush=True)
    subprocess.run(command, check=True)
