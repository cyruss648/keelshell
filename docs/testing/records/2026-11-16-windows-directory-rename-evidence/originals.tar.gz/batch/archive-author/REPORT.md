# 2026-11-16 本批证据封存工具交付

已完成 archive_batch.py 和持久证据目录 verify_evidence.py 的修正。写入范围仅为这两个脚本及本 archive-author 报告目录。工程源码、其他文档、共享 target 均未写入；Cargo、工程测试、GUI、commit、push、清理命令均为 0。没有执行封存、封存预检或验证器工作流，没有生成最终 originals.tar.gz、archive-manifest.json、README.md。

原验证器草稿原字节保存在 verify-evidence-draft-before-r1.txt（9,483 字节，SHA-256 39ec45dcc22d26e72b9bd53363e4e7d09b5ccbd8eb4532fbfb74a0a00d48ff25）。旧 static-check-r1/r2 及独立编译输出均保留；最新检查见 static-check-r3.json，旧检查的脚本摘要不移签到最终脚本。

归档工具要求显式 --final-freeze、--final-snapshot、--final-gate、--final-review。接受批次内相对路径或该目录内的绝对路径；gate 可为标签、receipt JSON 或 summary JSON；review 可为目录或其 summary.json。验证器默认读取 archive-manifest.json 的最终选择，也可传入全部四个参数严格比较，不会自动挑选最新编号或把既定编号视为通过。

当前父最终选择为 inputs-freeze-r6.json / source-r6 / full-gate-r4 / reviewer-tunnels-r6。只读回读 full-gate-r4-summary.json 得到：719 项，f0f64a6629b2441d63eef1e801189eaef69dd848aea0039eef4d09ff143b5164；实际 0/reaped/687.799s；普通 Rust 3223/0/48、rustdoc 14/0/0、app 1340/0/2 与 app-inventory-r6 的 1342 名一致、session 40 名、Python 290/289/1skip。此处是父原始摘要回读，不是本作者独立执行。最终评审已出现，decision 为 APPROVE_STATIC_R6_INCREMENT_AND_COMPOSITION_CONDITIONALLY；它自己的相同 r6 完整门禁绑定条件保持原文，工具将以最终原件重新检查。没有等待、驱动或重跑 reviewer。

准备执行时，从仓库根目录运行。第一条只读预检不写输出；确认资料已经稳定后，由父运行第二条一次封存：

```sh
python3 -B work/windows-directory-rename-integration-20261116/archive_batch.py --final-freeze inputs-freeze-r6.json --final-snapshot source-r6 --final-gate full-gate-r4 --final-review reviewer-tunnels-r6 --check-only
python3 -B work/windows-directory-rename-integration-20261116/archive_batch.py --final-freeze inputs-freeze-r6.json --final-snapshot source-r6 --final-gate full-gate-r4 --final-review reviewer-tunnels-r6
```

如果父选择更后面的最终修订，替换这四个参数即可。若增加了工具未知的历史失败，显式添加可重复参数，例如 --history-gate full-gate-r4=r6；映射会写入最终 manifest，避免猜测历史输入。也接受批次已有 gate-input-bindings.json。当前已知完整失败为 full-gate-r1→r3、full-gate-r2→r4、full-gate-r3→r5，均保留原 exit1/回收/日志；没有将它们判绿。

封存后使用：

```sh
python3 -B docs/testing/records/2026-11-16-windows-directory-rename-evidence/verify_evidence.py --current
python3 -B docs/testing/records/2026-11-16-windows-directory-rename-evidence/verify_evidence.py --index
python3 -B docs/testing/records/2026-11-16-windows-directory-rename-evidence/verify_evidence.py --source <完整40位源码SHA> --evidence <完整40位证据SHA>
```

--source 和 --evidence 分别绑定源码树和证据树；--index 可与独立 --source 组合，不能与 --evidence 组合。SHA 必须是完整小写 40 位 commit 身份。默认无参数与 --current 相同。验证不落盘解包、不生成 pyc、不运行工程命令；建议始终 python3 -B 启动。所有运行检查均使用显式异常，不受 python -O 关闭 assert 影响。

工具行为和保留范围：

- 每份 tar 成员逐长度、SHA-256、路径、重复名和 regular-file 类型核验；gzip/tar 固定排序和元数据。manifest 区分 original 与 derived 的数量和来源。最终 verifier 自身及 README 也有长度/SHA 绑定。
- 每轮完整 719 项冻结按 aggregate 和每个路径独立校验。r1/r2 使用精确 base 4d72e1e592bdd6194f6eadca3a6a760192b5fe82 加 r3 native/tests 及 SHA 验证的 r1 重构测试；r3 五文件、r4 snapshot-r4 六文件、r5 七文件、r6 八文件及后续所选快照分别重构完整输入。r4 没有父 manifest 时只在 tar 的 derived/source-r4-manifest.json 计算，不写历史目录或覆盖父原件。存在的父 source manifests 同样逐长度/SHA 核对。
- r2/r3 评审保持其原始同输入条件；r4/r5 静态 scope 与组合 HOLD 明确检查不变。只有所选最终评审自己的 719 项输入、零 P0–P3 和明确组合条件参与最终绑定，不转移旧批准。最终成功门禁还须核对 receipt、完整 summary、所选 compiled inventory、实际测试名、locale/AI/Files/tunnels 四名、server_archive 40 名和其他最终计数。
- stack repro 真实控制器 250、lldb 124/timed_out=true/全回收、真实重编译修复 1/0/0、AI 模块 79/0/2、locale exit101 红例与两次绿例、原故障线程 crash frames 全部保留。所有 receipt/log 组合逐长度/SHA 核对；未把旧失败改写为成功。
- dependencies-live-r3 的成功 receipt/log 自动纳入；旧 UNKNOWN 原件不动。37 包/113 项的说法来自既有父事实及元数据；若父另补本批 JSON report，目录原件扫描自动保留。本工具不访问官方 URL、不抓取依赖、不升级工具链。环境版本只保留 environment-r4 原件，不声称官方最新 Rust。
- 前批持久 cursor archive 实际已有 70 份 batch 原件。作者只读盘点得到 70 份逐字节相同副本，37 份未归档交付/CI/index/committed/回读原件；工具执行时再次对照旧 manifest 及全部成员，旧副本不重复，新材料置 previous-delivery/。已在旧归档的 author-cleanup-r1 只引用，后增清理记录会自动补存。
- Kit 当前 DELIVERY.json 列 25 份文件，加 DELIVERY 本身共 26 份；按清单逐长度/SHA 验证后置 kit-author/。不遍历或打包 downloads/upstream/diffs 第三方包。Microsoft 两份 HTML 不入 tar，现有来源 URL、抓取长度与 SHA receipt 保留；若 HTML 仍在本地会只读核对抓取摘要，不重新分发正文。
- windows-app-archive-expected-r1.json 自动封存并检查 8 名唯一和 current_windows_execution=NOT_RUN；70 名 Windows platform 也保持预期库存。前批真实 Windows 63/4/0 与本批实际 Windows 0 分开，不签本批 Windows、正常应用包、桌面或安装验收。
- 所有资料在内存预检、压缩回读，发布前再次核对原件和完整路径集及当前最终工程输入。任一父/reviewer 并发写入会失败关闭；资料稳定后再运行。写三个输出都用独占 xb、flush/fsync，现有输出或任何部分失败产物都保留且阻止覆盖；没有自动清理或 --force。若发布中途因磁盘/进程问题失败，需要父检查保留的部分产物，工具不会替父删除它们。

验证限制：只完成独立编译/静态检查和 CLI help，不把这些当成端到端封存、归档验证或工程验收。最新 r3 检查为 2 次 AST、4 次普通/优化 bytecode 编译、2 次 --help exit0；assert 节点 0、清理/解包落盘调用 0、工程测试 0。所有编译输出只在 archive-author/，封存工具明确跳过 pyc。最终压缩长度、成员数、manifest 摘要及 current/index/commit 绑定结果必须由父执行后填写。

全历史验证依赖仓库中 base commit 的 Git blobs 和前批持久 cursor 归档。封存前仍需原 scratch 材料以重新比对省略的 70 份原件；封存完成后的验证不依赖 scratch 副本。只复制本证据目录而不带基线 Git 对象和前批持久归档，不足以重构全部历史。

最终脚本字节如下；和 static-check-r3.json 一致：

- `work/windows-directory-rename-integration-20261116/archive_batch.py`：14590 字节；SHA-256 `46396017d4b7bd9459c3012478cfe87ecea3ac4f25c3189be8e7d4c3ab506031`。
- `docs/testing/records/2026-11-16-windows-directory-rename-evidence/verify_evidence.py`：40097 字节；SHA-256 `1b3ac27d93bbe21d6954622a8d481df4d4d3295429296a3f67b4f9089878aef3`。
