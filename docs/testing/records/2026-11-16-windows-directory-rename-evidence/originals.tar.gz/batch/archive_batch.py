"""Seal completed evidence once, with explicit final inputs and no cleanup.

Requires --final-freeze, --final-snapshot, --final-gate, --final-review.
--check-only performs readiness checks without writing. Existing outputs,
including partial failed attempts, are never overwritten or removed.
"""
import argparse
import gzip
import io
import os
from pathlib import Path
import re
import runpy
import subprocess
import sys
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
OUT = ROOT / "docs/testing/records/2026-11-16-windows-directory-rename-evidence"
# run_path loads the shared verifier without importing a local bytecode cache.
H = runpy.run_path(str(OUT / "verify_evidence.py"), run_name="archive_helpers")
EvidenceError = H["EvidenceError"]
require = H["require"]
digest = H["digest"]
record = H["record"]
json_bytes = H["json_bytes"]
file_row = H["file_row"]
read_regular = H["read_regular"]


def inventory(directory):
    require(directory.is_dir() and not directory.is_symlink(), "missing/linked directory: " + directory.name)
    result = []
    for path in sorted(directory.rglob("*")):
        require(not path.is_symlink(), "linked evidence: " + path.relative_to(ROOT).as_posix())
        if path.is_file():
            relative = path.relative_to(directory)
            if "__pycache__" not in relative.parts and path.suffix != ".pyc":
                require(not set(relative.parts) & {"downloads", "upstream", "diffs", "target"},
                        "unexpected build/third-party evidence directory: " + relative.as_posix())
                result.append(relative.as_posix())
    return result


def collect():
    files, origins, watched = {}, {}, {}

    def add(name, source):
        require(name not in files, "duplicate archive destination: " + name)
        data = read_regular(ROOT, source)
        files[name], origins[name], watched[source] = data, source, data
        return data

    batch_names = inventory(BASE)
    html = {"nt-create-file.html", "reopen-file.html"}
    for name in batch_names:
        if name not in html:
            require(not name.endswith(".html"), "unclassified third-party HTML: " + name)
            add("batch/" + name, H["BATCH"] + "/" + name)
    add("tools/verify_evidence.py", (OUT / "verify_evidence.py").relative_to(ROOT).as_posix())
    for item in record(files["batch/official-source-receipts-r1.json"], "official sources"):
        name = item["label"] + ".html"
        require(name in html, "unclassified official reference")
        source = H["BATCH"] + "/" + name
        if (ROOT / source).exists():
            data = read_regular(ROOT, source)
            watched[source] = data
            require(file_row(name, data) == {"path": name, "bytes": item["bytes"], "sha256": item["sha256"]},
                    "reference capture differs from fetch receipt: " + name)

    prefix = H["PREVIOUS_EVIDENCE"]
    manifest_data = add("previous-delivery/prior-archive-manifest.json", prefix + "/archive-manifest.json")
    packed = read_regular(ROOT, prefix + "/originals.tar.gz")
    watched[prefix + "/originals.tar.gz"] = packed
    previous = H["unpack"](packed, record(manifest_data, "previous manifest"))
    previous_names = inventory(ROOT / H["PREVIOUS_BATCH"])
    omitted, changed = [], []
    for name in previous_names:
        source = H["PREVIOUS_BATCH"] + "/" + name
        data = read_regular(ROOT, source)
        watched[source] = data
        old = "batch/" + name
        if old in previous and previous[old] == data:
            omitted.append(file_row(old, data))
        else:
            add("previous-delivery/" + name, source)
            if old in previous:
                changed.append({"path": name, "prior_sha256": digest(previous[old]), "retained_sha256": digest(data)})
    require(len(omitted) >= 70, "previous 70 archived originals not all available for duplicate comparison")
    delivery = record(add("kit-author/DELIVERY.json", H["KIT"] + "/DELIVERY.json"), "Kit delivery")
    H["check_rows"](delivery["files"])
    for row in delivery["files"]:
        require(not set(Path(row["path"]).parts) & {"downloads", "upstream", "diffs"},
                "third-party payload in Kit DELIVERY")
        data = add("kit-author/" + row["path"], H["KIT"] + "/" + row["path"])
        require(file_row(row["path"], data) == row, "Kit DELIVERY original mismatch: " + row["path"])
    reference = {
        "directory": prefix, "manifest_bytes": len(manifest_data), "manifest_sha256": digest(manifest_data),
        "archive_bytes": len(packed), "archive_sha256": digest(packed),
        "omitted_unchanged": omitted, "changed_since_prior_archive": changed,
        "policy": "Unchanged prior originals are referenced, not duplicated; later delivery/CI is retained.",
    }
    return files, origins, watched, reference, batch_names, previous_names


def readme_text(manifest):
    selection = manifest["final"]
    tool = "docs/testing/records/2026-11-16-windows-directory-rename-evidence/verify_evidence.py"
    failures = "\n".join(
        f"- `{row['receipt']}`：输入 `{row['input_revision']}`，控制器 exit"
        f"{row['controller_exit']}，{row['seconds']:.3f}s。"
        for row in manifest["historical_full_gate_failures"]
    )
    return f"""# Windows 目录发布句柄与 Kit 证据原件

共 {manifest['count']} 份成员，其中 {manifest['original_count']} 份原件、
{manifest['derived_count']} 份派生文件，合计 {manifest['original_bytes']} 未压缩字节。
压缩包 {manifest['archive_bytes']} 字节，SHA-256
`{manifest['archive_sha256']}`。`archive-manifest.json` 逐文件记录路径、长度、
SHA-256 和原件来源；`derived/` 明确区分派生重构说明。

最终选择为 `{selection['freeze']}`、`{selection['snapshot']}/`、
`{selection['gate']}`、`{selection['review']}`。完整工程输入
{manifest['engineering_inputs']} 项，SHA-256 `{manifest['engineering_sha256']}`。
只有该最终输入自身成功的完整门禁及相同输入的最终评审参与最终绑定。

历史完整门禁失败保留原件，不能被后来的通过改写：

{failures}

`batch/` 保留全部历史冻结、r3/r4/r5/r6 及后续所选快照、真实专项、
locale 两次 green 及 exit101 red、故障线程 crash frames 和分轮评审。
stack repro 控制器 exit250；lldb 控制器 exit124/timed_out=true，
进程全部回收。修订专项的真实重编译 `1/0/0` 和 ai_settings `79/0/2`
单独保存，不代替完整门禁。dependencies-live-r3 exit0 为新事实，旧 UNKNOWN 不变。
环境版本只引用 environment-r4 原始回执，不据此声明官方最新 Rust。

r2/r3 旧批准的相同输入门禁条件、r4/r5 的静态范围与组合 HOLD 保持原文。
最终评审自己的组合条件按最终冻结和门禁核对，不移签旧批准。
r1 测试是在修订后重构并按作者冻结 SHA 核实的字节，不称现场独立快照。
每轮完整输入从基线 `{manifest['base_commit']}` 加该轮快照或 r1 重构文件恢复，
路径映射见 `derived/input-bindings.json`。r4 无父清单时仅在 `derived/`
计算 snapshot-r4 的长度和 SHA；已有父清单也保留并核对。

`previous-delivery/` 补存前批交付、精确 CI、index/committed 绑定及回读原件。
前批已有归档中的 {len(manifest['previous_archive']['omitted_unchanged'])} 份副本不重复。
验证依赖仓库内前批持久归档和基线 Git blob，单独复制本目录不足以验证全历史。
`kit-author/` 按 DELIVERY 清单保留作者原件及 DELIVERY 本身；
downloads/upstream/diffs 第三方包不重新分发。Microsoft HTML 仅保留已有来源
URL、抓取长度与 SHA 元数据，全文不重新分发。工具不自动清理目录。

从仓库根目录执行以下只读校验，无参数等同于 --current：

```sh
python3 -B {tool} --current
python3 -B {tool} --index
python3 -B {tool} --source <完整40位源码SHA> --evidence <完整40位证据SHA>
```

验证器默认读取 manifest 的最终选择；也可同时传入四个 `--final-*` 参数比对。
源码 SHA 与证据 SHA 独立，支持 `--index --source`；缩写 SHA 不接受。
全部成员在内存核验，不解包、不编译、不执行测试。
前批 Windows 实际为 63/4/0；本批 Windows 原生执行仍 0，期望库存 70 名。
这不代表新正常包、安装、跨平台桌面、IME、辅助技术或完整产品验收。
"""


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    H["add_selection_arguments"](parser, required=True)
    parser.add_argument("--check-only", action="store_true", help="check readiness without publishing files")
    parser.add_argument("--history-gate", action="append", default=[], metavar="full-gate-rN=rM",
                        help="explicit input revision for an additional historical failed gate; repeatable")
    args = parser.parse_args()
    selection = H["selection_from_args"](args)
    outputs = ("originals.tar.gz", "archive-manifest.json", "README.md")
    for name in outputs:
        require(not (OUT / name).exists() and not (OUT / name).is_symlink(),
                "output already exists; preserve it and inspect manually: " + name)
    files, origins, watched, previous, batch_names, previous_names = collect()
    for key in ("freeze", "gate", "summary", "review"):
        require(selection[key] in files, "final material not ready: " + selection[key])
    final, history = H["reconstruct_history"](files, selection, H["source_files"](H["BASE_COMMIT"]))
    files["derived/input-bindings.json"] = json_bytes(history)
    for item in history:
        if item["revision"] not in ("r1", "r2"):
            files["derived/source-" + item["revision"] + "-manifest.json"] = json_bytes({
                "base": H["BASE_COMMIT"], "revision": item["revision"],
                "files": [file_row(path, files[name]) for path, name in sorted(item["replacements"].items())],
                "derived_from_retained_snapshot": True,
            })
    extra_bindings = {}
    for value in args.history_gate:
        label, separator, revision = value.partition("=")
        require(separator and re.fullmatch(r"full-gate-r\d+", label) and re.fullmatch(r"r\d+", revision),
                "use --history-gate full-gate-rN=rM")
        require(label not in extra_bindings or extra_bindings[label] == revision,
                "conflicting --history-gate: " + label)
        extra_bindings[label] = revision
    failures = H["historical_commands"](files, selection, extra_bindings)
    freezes = {item["aggregate_sha256"]: H["freeze_record"](files[item["freeze"]], item["freeze"]) for item in history}
    reviews = []
    for path in sorted(name for name in files if re.fullmatch(r"batch/reviewer[^/]*/summary\.json", name)):
        value = record(files[path], path)
        binding = value.get("input", value.get("final_input", value.get("input_binding", value)))
        sha = binding.get("aggregate_sha256", binding.get("engineering_sha256"))
        require(sha in freezes, path + ": review freeze missing")
        reviews.append(H["review_binding"](files, path, freezes[sha], final=path == selection["review"]))
    rows = [{**file_row(name, data), "kind": "original" if name in origins else "derived",
             "origin": origins.get(name, "retained snapshots and exact base Git blobs")}
            for name, data in sorted(files.items())]
    manifest = {
        "schema": H["SCHEMA"], "base_commit": H["BASE_COMMIT"], "archive": "originals.tar.gz",
        "count": len(rows), "original_bytes": sum(row["bytes"] for row in rows), "files": rows,
        "original_count": sum(row["kind"] == "original" for row in rows),
        "derived_count": sum(row["kind"] == "derived" for row in rows),
        "engineering_inputs": final["count"], "engineering_sha256": final["aggregate_sha256"],
        "final": selection, "previous_archive": previous, "historical_full_gate_failures": failures,
        "additional_gate_input_bindings": extra_bindings,
        "reviews": reviews, "verifier": file_row("verify_evidence.py", files["tools/verify_evidence.py"]),
    }
    result = H["validate"](files, manifest, lambda name: read_regular(ROOT, name), H["source_files"]())
    packed_stream = io.BytesIO()
    with gzip.GzipFile(filename="", fileobj=packed_stream, mode="wb", mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode="w", format=tarfile.USTAR_FORMAT) as archive:
            for name, data in sorted(files.items()):
                member = tarfile.TarInfo(name)
                member.size, member.mode = len(data), 0o644
                archive.addfile(member, io.BytesIO(data))
    packed = packed_stream.getvalue()
    manifest.update({"archive_bytes": len(packed), "archive_sha256": digest(packed)})
    require(H["unpack"](packed, manifest) == files, "in-memory archive readback mismatch")
    readme = readme_text(manifest).encode()
    manifest["readme"] = file_row("README.md", readme)
    payloads = {"originals.tar.gz": packed, "archive-manifest.json": json_bytes(manifest), "README.md": readme}
    # Fail before publishing if a parent/reviewer changed any original or path set.
    require(inventory(BASE) == batch_names, "batch inventory changed while preparing archive")
    require(inventory(ROOT / H["PREVIOUS_BATCH"]) == previous_names, "previous delivery inventory changed")
    for name, original in watched.items():
        require(read_regular(ROOT, name) == original, "original changed during preparation: " + name)
    H["match_inputs"](H["source_files"](), final, "pre-publication final source")
    if not args.check_only:
        for name in outputs:
            with (OUT / name).open("xb") as stream:
                stream.write(payloads[name])
                stream.flush()
                os.fsync(stream.fileno())
        for name in outputs:
            require(read_regular(OUT, name) == payloads[name], "published output readback mismatch: " + name)
    result.update({"published": not args.check_only, "archive_bytes": len(packed),
                   "archive_sha256": digest(packed), "final_selection": selection,
                   "outputs_retained_on_any_failure": True})
    print(json_bytes(result).decode(), end="")


if __name__ == "__main__":
    try:
        main()
    except (EvidenceError, OSError, KeyError, TypeError, ValueError, EOFError,
            tarfile.TarError, subprocess.TimeoutExpired) as error:
        print("Archive not sealed: " + str(error), file=sys.stderr)
        sys.exit(2)
