//! Explicit bilingual UI messages. Remote content is kept outside translations.

use std::fmt::Display;

use gpui_kit::{
    App, Global, InteractiveElement, ParentElement, Role, StatefulInteractiveElement, Styled,
    TestSupportExt, div,
};
use keelshell_core::Language;

#[derive(Default)]
struct Locale(Language);

impl Global for Locale {}

/// Current interface language, defaulting to Chinese before application setup.
pub fn language(cx: &App) -> Language {
    cx.try_global::<Locale>()
        .map_or(Language::ZhCn, |locale| locale.0)
}

/// Select a static message. Both supported languages are required at each call.
pub fn t(cx: &App, zh: &'static str, en: &'static str) -> &'static str {
    match language(cx) {
        Language::ZhCn => zh,
        Language::En => en,
    }
}

/// A tooltip whose visible content follows the live application language.
///
/// Kit's string tooltip retains the translation captured by its hover request.
/// The public GPUI tooltip builder instead owns a Kit tooltip whose element
/// reads Locale on every render, including while the pointer stays in place.
/// Use this once per element, without another string or builder tooltip.
pub(crate) trait LocalizedTooltipExt: InteractiveElement {
    /// Attach both complete translations without capturing the current locale.
    fn localized_tooltip(mut self, zh: &'static str, en: &'static str) -> Self {
        self.interactivity().tooltip(move |window, cx| {
            gpui_kit::component::tooltip::Tooltip::element(move |_, cx| {
                let label = t(cx, zh, en);
                div()
                    .id("localized-tooltip-content")
                    .role(Role::Tooltip)
                    .aria_label(label)
                    .max_w(gpui_kit::px(420.))
                    .child(label)
                    .test_support()
            })
            .build(window, cx)
        });
        self
    }
}

impl<E: InteractiveElement> LocalizedTooltipExt for E {}

/// An owned status retaining both translations so it can change language later.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct Message {
    zh: String,
    en: String,
}

impl Message {
    /// An empty status in both languages.
    pub fn empty() -> Self {
        Self::default()
    }
    /// Keep both complete translations, including any already formatted arguments.
    pub fn new(zh: impl Into<String>, en: impl Into<String>) -> Self {
        Self {
            zh: zh.into(),
            en: en.into(),
        }
    }

    /// Add the same uninterpreted technical detail to translated labels.
    ///
    /// Details may be a remote path, host or diagnostic. This does not translate
    /// or execute the detail, and callers must exclude credentials beforehand.
    pub fn detail(zh_label: &str, en_label: &str, detail: impl Display) -> Self {
        Self::new(
            format!("{zh_label}：{detail}"),
            format!("{en_label}: {detail}"),
        )
    }

    /// Borrow both translations for composing a complete bilingual review.
    pub(crate) fn translations(&self) -> (&str, &str) {
        (&self.zh, &self.en)
    }

    /// Render according to the current application language, without mutation.
    pub fn render(&self, cx: &App) -> String {
        match language(cx) {
            Language::ZhCn => self.zh.clone(),
            Language::En => self.en.clone(),
        }
    }
}

/// Update application and GPUI component translations, then redraw every window.
pub fn set_language(language: Language, cx: &mut App) {
    cx.set_global(Locale(language));
    gpui_kit::component::set_locale(language.code());
    // Component direction follows the selected app language, not the desktop locale.
    cx.refresh_windows();
}

#[cfg(test)]
mod tests {
    use super::{LocalizedTooltipExt, Message, language, set_language, t};
    use gpui_kit::{
        AppContext, Bounds, Context, IntoElement, ParentElement, Render, Styled, TestAppContext,
        Window, WindowBounds, WindowOptions,
        component::button::{Button, ButtonVariants},
        div, point, px, size,
        test::TestWindowExt,
    };
    use keelshell_core::Language;
    use std::time::Duration;

    struct TooltipFixture;
    impl Render for TooltipFixture {
        fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
            div().size_full().p_4().child(
                Button::new("live-locale-tooltip")
                    .ghost()
                    .label("SSH")
                    .localized_tooltip("新建 SSH 会话", "New SSH session"),
            )
        }
    }

    #[gpui_kit::test]
    fn already_open_tooltip_retranslates_without_pointer_movement(cx: &mut TestAppContext) {
        let (window, _) = cx.update(|cx| {
            gpui_kit::init(cx);
            set_language(Language::En, cx);
            gpui_kit::open_window(
                WindowOptions {
                    window_bounds: Some(WindowBounds::Windowed(Bounds::new(
                        point(px(0.), px(0.)),
                        size(px(640.), px(400.)),
                    ))),
                    ..Default::default()
                },
                cx,
                |_, cx| cx.new(|_| TooltipFixture),
            )
            .unwrap_or_else(|error| panic!("tooltip test window: {error}"))
        });
        cx.update_window(window, |_, window, cx| {
            window.render_frame(cx);
            window.hover("live-locale-tooltip", cx);
        })
        .unwrap_or_else(|error| panic!("hover real localized button: {error}"));
        cx.run_until_parked();
        cx.dispatcher.advance_clock(Duration::from_secs(1));
        cx.run_until_parked();
        cx.update_window(window, |_, window, cx| {
            window.render_frame(cx);
            let tooltip = window.find("localized-tooltip-content");
            assert!(tooltip.visible());
            assert_eq!(tooltip.label(), Some("New SSH session"));
        })
        .unwrap_or_else(|error| panic!("show hovered tooltip after bounded delay: {error}"));
        for (language, expected) in [
            (Language::ZhCn, "新建 SSH 会话"),
            (Language::En, "New SSH session"),
        ] {
            cx.update_window(window, |_, window, cx| {
                let pointer = window.mouse_position();
                set_language(language, cx);
                window.render_frame(cx);
                let tooltip = window.find("localized-tooltip-content");
                assert!(tooltip.visible());
                assert_eq!(tooltip.label(), Some(expected));
                assert_eq!(window.mouse_position(), pointer);
                assert!(tooltip.bounds().right() <= window.bounds().right());
                assert!(tooltip.bounds().bottom() <= window.bounds().bottom());
            })
            .unwrap_or_else(|error| panic!("translate still-hovered tooltip: {error}"));
        }
    }

    #[gpui_kit::test]
    fn defaults_to_chinese_and_retranslates_existing_messages(cx: &mut TestAppContext) {
        let message = Message::detail("主机", "Host", "ops@example:22");
        cx.update(|cx| {
            assert_eq!(language(cx), Language::ZhCn);
            assert_eq!(t(cx, "连接", "Connect"), "连接");
            assert_eq!(message.render(cx), "主机：ops@example:22");
            set_language(Language::En, cx);
            assert_eq!(t(cx, "连接", "Connect"), "Connect");
            assert_eq!(message.render(cx), "Host: ops@example:22");
            set_language(Language::ZhCn, cx);
            assert_eq!(message.render(cx), "主机：ops@example:22");
        });
    }

    #[gpui_kit::test]
    fn app_languages_keep_plain_input_navigation_ltr_after_rtl_locale(cx: &mut TestAppContext) {
        use gpui_kit::{
            base::LayoutDirection,
            component::input::{Input, InputState},
        };

        struct DirectionInput {
            state: gpui_kit::Entity<InputState>,
        }

        impl Render for DirectionInput {
            fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
                div()
                    .w(gpui_kit::px(300.))
                    .p_4()
                    .child(Input::new(&self.state).id("locale-direction-input"))
            }
        }

        let (handle, view) = cx.update(|cx| {
            gpui_kit::init(cx);
            gpui_kit::open_window(WindowOptions::default(), cx, |window, cx| {
                cx.new(|cx| DirectionInput {
                    state: cx.new(|cx| InputState::new(window, cx)),
                })
            })
            .unwrap_or_else(|error| panic!("locale direction test window: {error}"))
        });
        for selected in [Language::ZhCn, Language::En] {
            cx.update_window(handle, |_, window, cx| {
                // The deterministic scheduler defaults to LTR, so seed the
                // direction that a real RTL desktop supplies during Kit init.
                LayoutDirection::Rtl.set_global(cx);
                set_language(selected, cx);
                let state = view.read(cx).state.clone();
                state.update(cx, |state, cx| {
                    state.set_value("", window, cx);
                    state.focus(window, cx);
                });
                window.render_frame(cx);
                window.input("ab", cx);
                window.press("left", cx);
                window.input("X", cx);
                assert_eq!(
                    state.read(cx).value().as_ref(),
                    "aXb",
                    "the app language must control plain-input arrow navigation"
                );
            })
            .unwrap_or_else(|error| panic!("locale direction keyboard interaction: {error}"));
        }
    }
}
