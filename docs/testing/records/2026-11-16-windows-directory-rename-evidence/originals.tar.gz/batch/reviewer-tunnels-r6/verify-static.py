"""Read-only source/receipt verification; writes only beside this script."""
from collections import Counter
from datetime import datetime, timezone
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

OUT = Path(__file__).resolve().parent
BASE = OUT.parent
ROOT = BASE.parent.parent
ENV = os.environ | {"GIT_OPTIONAL_LOCKS": "0"}
PIN = "4d72e1e592bdd6194f6eadca3a6a760192b5fe82"
TUNNELS = "crates/keelshell-app/src/tunnels.rs"
EXPECTED = "f0f64a6629b2441d63eef1e801189eaef69dd848aea0039eef4d09ff143b5164"
FAILURE = (
    "workspace::tunnel_rule_tests::review_regressions::"
    "conflict_blocks_new_workspace_panels_until_authoritative_reload"
)
commands = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    path = Path(path)
    assert "target" not in path.parts, path
    return path.read_bytes()


def load(path):
    return json.loads(read(path))


def git(*args, data=None):
    command = ["git", *args]
    result = subprocess.run(
        command, cwd=ROOT, env=ENV, input=data, capture_output=True, check=True
    )
    commands.append({"argv": command, "exit": result.returncode})
    return result.stdout


def write(name, data):
    assert "/" not in name
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def aggregate(rows):
    return sha("".join(f"{r['path']}\0{r['sha256']}\n" for r in rows).encode())


head = git("rev-parse", "HEAD").decode().strip()
assert head == PIN
r6 = load(BASE / "inputs-freeze-r6.json")
paths = [r["path"] for r in r6["inputs"]]
assert len(paths) == len(set(paths)) == r6["count"] == 719
assert aggregate(r6["inputs"]) == r6["aggregate_sha256"] == EXPECTED
assert all("target" not in Path(p).parts for p in paths)

tree = git("ls-tree", "-rz", "--full-tree", PIN)
head_paths = []
for row in tree.split(b"\0"):
    if not row:
        continue
    meta, path = row.split(b"\t", 1)
    if not path.startswith(b"docs/"):
        assert meta.split()[1] == b"blob"
        head_paths.append(path.decode())
assert set(head_paths) == set(paths)

batch = git(
    "cat-file", "--batch",
    data="".join(f"{PIN}:{p}\n" for p in paths).encode(),
)
blobs = {}
offset = 0
for path in paths:
    end = batch.index(b"\n", offset)
    header = batch[offset:end].split()
    assert header[1] == b"blob"
    size = int(header[2])
    offset = end + 1
    blobs[path] = batch[offset:offset + size]
    offset += size
    assert batch[offset:offset + 1] == b"\n"
    offset += 1
assert offset == len(batch)

freezes = {}
specs = (
    ("r2", "inputs-freeze-r2.json", "source-r6"),
    ("r3", "inputs-freeze-r3.json", "source-r3"),
    ("r4", "engineering-inputs-r4.json", "snapshot-r4"),
    ("r5", "inputs-freeze-r5.json", "source-r5"),
    ("r6", "inputs-freeze-r6.json", "source-r6"),
)
for rev, name, snapshot in specs:
    obj = load(BASE / name)
    rows = obj["inputs"]
    assert [r["path"] for r in rows] == paths
    assert aggregate(rows) == obj["aggregate_sha256"]
    overrides = []
    for row in rows:
        path, expected_sha = row["path"], row["sha256"]
        data = blobs[path]
        if sha(data) != expected_sha:
            data = read(BASE / snapshot / path)
            overrides.append(path)
        assert sha(data) == expected_sha, (rev, path)
    freezes[rev] = {
        "manifest": str(BASE / name),
        "manifest_file_sha256": sha(read(BASE / name)),
        "count": len(rows),
        "aggregate_sha256": obj["aggregate_sha256"],
        "recomputed_aggregate_matches": True,
        "head_path_set_exact": True,
        "all_719_reconstructed": True,
        "head_blobs": 719 - len(overrides),
        "snapshot_root": str(BASE / snapshot),
        "snapshot_overrides": overrides,
        "mismatches": [],
    }

maps = {
    rev: {r["path"]: r["sha256"] for r in load(BASE / name)["inputs"]}
    for rev, name, _ in specs
}
transitions = {}
for a, b in (("r2", "r3"), ("r3", "r4"), ("r4", "r5"), ("r5", "r6")):
    transitions[f"{a}_to_{b}"] = [
        p for p in paths if maps[a][p] != maps[b][p]
    ]
assert transitions["r5_to_r6"] == [TUNNELS]
manifest_checks = {}
for rev, expected_count in (("r5", 7), ("r6", 8)):
    name = f"source-{rev}-manifest.json"
    rows = load(BASE / name)["files"]
    listed = {r["path"] for r in rows}
    actual = {
        str(p.relative_to(BASE / f"source-{rev}"))
        for p in (BASE / f"source-{rev}").rglob("*") if p.is_file()
    }
    assert len(rows) == len(listed) == expected_count and listed == actual
    for row in rows:
        data = read(BASE / f"source-{rev}" / row["path"])
        assert len(data) == row["bytes"]
        assert sha(data) == row["sha256"] == maps[rev][row["path"]]
    manifest_checks[rev] = {
        "manifest": str(BASE / name),
        "manifest_file_sha256": sha(read(BASE / name)),
        "files": rows,
        "all_lengths_hashes_and_freeze_rows_match": True,
    }
preserved_seven = []
for row in manifest_checks["r5"]["files"]:
    path = row["path"]
    assert read(BASE / "source-r5" / path) == read(BASE / "source-r6" / path)
    preserved_seven.append(path)

old = blobs[TUNNELS]
new = read(BASE / "source-r6" / TUNNELS)
assert sha(old) == maps["r5"][TUNNELS]
old_render = old.index(b"impl Render for TunnelsPanel {\n")
old_body = old.index(b"        let matching_rules = self.matching_rules();\n", old_render)
old_end = old.index(b"    }\n}\n\nasync fn start_forward(", old_body)
helper = new.index(b"impl TunnelsPanel {\n    // Keep inactive runtime builders")
new_body = new.index(b"        let matching_rules = self.matching_rules();\n", helper)
new_end = new.index(b"    }\n}\n\nimpl Render for TunnelsPanel {", new_body)
new_render = new.index(b"impl Render for TunnelsPanel {\n", new_end)
call = b"        self.runtime_view(cx)\n"
call_at = new.index(call, new_render)
segments = (
    ("outside_prefix", old[:old_render], new[:helper], 0, 0),
    ("render_management_and_early_return", old[old_render:old_body],
     new[new_render:call_at], old_render, new_render),
    ("ordinary_runtime_body", old[old_body:old_end],
     new[new_body:new_end], old_body, new_body),
    ("outside_suffix", old[old_end:], new[call_at + len(call):],
     old_end, call_at + len(call)),
)
segment_evidence = []
for name, left, right, before, after in segments:
    assert left == right, name
    segment_evidence.append({
        "name": name, "bytes": len(left), "sha256": sha(left), "byte_equal": True,
        "r5_start_line": old[:before].count(b"\n") + 1,
        "r6_start_line": new[:after].count(b"\n") + 1,
    })
reconstructed = b"".join(s[2] for s in segments)
assert reconstructed == old
helper_header = new[helper:new_body]
assert helper_header == (
    b"impl TunnelsPanel {\n"
    b"    // Keep inactive runtime builders out of the management branch's stack\n"
    b"    // frame: an editor can render inside an already nested workspace modal.\n"
    b"    #[inline(never)]\n"
    b"    fn runtime_view(&self, cx: &mut Context<Self>) -> AnyElement {\n"
    b"        let visual = crate::design::palette(cx);\n"
)
tokens = (
    b".on_click(", b"cx.listener(", b".disabled(", b".id(",
    b".aria_label(", b".accessibility_label(", b"Ordering::Acquire",
)
counts = {}
for token in tokens:
    before = old[old_render:old_end].count(token)
    after = new[new_body:new_end].count(token) + new[new_render:call_at].count(token)
    assert before == after
    counts[token.decode()] = {"r5": before, "r6": after}
diff = "".join(difflib.unified_diff(
    old.decode().splitlines(True), new.decode().splitlines(True),
    fromfile=f"{PIN}/{TUNNELS}", tofile=f"source-r6/{TUNNELS}",
))
(OUT / "r5-r6-tunnels.diff").write_text(diff)

receipts = {}
receipt_names = (
    "full-gate-r1", "full-gate-r2", "full-gate-r3",
    "kit-tunnels-stack-fixed-r1", "kit-tunnels-workspace-r1",
    "app-inventory-r6",
)
for name in receipt_names:
    obj = load(BASE / f"{name}.json")
    log = read(BASE / f"{name}.log")
    assert len(log) == obj["log_bytes"] and sha(log) == obj["log_sha256"]
    receipts[name] = {
        "receipt": str(BASE / f"{name}.json"),
        "receipt_file_sha256": sha(read(BASE / f"{name}.json")),
        "observed_exit": obj["observed_exit"],
        "controller_exit": obj["controller_exit"],
        "seconds": obj["seconds"],
        "terminal": obj["terminal"],
        "timed_out": obj["timed_out"],
        "interrupted": obj["interrupted"],
        "command": obj["command"],
        "cwd": obj["cwd"],
        "log": str(BASE / f"{name}.log"),
        "log_bytes": len(log), "log_sha256": sha(log),
        "log_matches_receipt": True,
        "test_summaries": [
            {"line": i, "text": line}
            for i, line in enumerate(log.decode().splitlines(), 1)
            if line.startswith("test result:")
        ],
    }

inventory_names = {}
for rev in ("r4", "r5", "r6"):
    log = read(BASE / f"app-inventory-{rev}.log").decode()
    names = [m[1] for m in re.findall(r"^(.+): (test|benchmark)$", log, re.M)]
    names = [line[:-6] for line in log.splitlines() if line.endswith(": test")]
    assert len(names) == len(set(names)) == 1342
    inventory_names[rev] = set(names)
assert inventory_names["r4"] == inventory_names["r5"] == inventory_names["r6"]
module_names = {p for p in inventory_names["r6"] if p.startswith("workspace::tunnel_rule_tests::")}
module_log = read(BASE / "kit-tunnels-workspace-r1.log").decode()
executed = re.findall(r"^test (.+) \.\.\. ok$", module_log, re.M)
assert len(executed) == len(set(executed)) == len(module_names) == 19
assert set(executed) == module_names and FAILURE in module_names
fixed_log = read(BASE / "kit-tunnels-stack-fixed-r1.log").decode()
assert f"test {FAILURE} ... ok" in fixed_log
assert "Compiling keelshell-app" in fixed_log

live_paths = sorted({
    p.decode() for p in git(
        "ls-files", "--cached", "--others", "--exclude-standard", "-z"
    ).split(b"\0") if p and not p.startswith(b"docs/")
})
assert all("target" not in Path(p).parts for p in live_paths)
assert live_paths == paths
live_rows = [{"path": p, "sha256": sha(read(ROOT / p))} for p in paths]
assert live_rows == r6["inputs"]

crash = load(BASE / "kit-tunnels-stack-crash-frames-r1.json")
prior_reports = {}
for rev, folder, report_name in (
    ("r2", "reviewer", "review.md"),
    ("r3", "reviewer-kit010", "report.md"),
    ("r4", "reviewer-stack-r4", "report.md"),
    ("r5", "reviewer-files-r5", "report.md"),
):
    summary = load(BASE / folder / "summary.json")
    prior_reports[rev] = {
        "report": str(BASE / folder / report_name),
        "report_sha256": sha(read(BASE / folder / report_name)),
        "summary": str(BASE / folder / "summary.json"),
        "summary_sha256": sha(read(BASE / folder / "summary.json")),
        "decision": summary["decision"],
        "findings_by_severity": summary["findings_by_severity"],
        "merge_recommendation": summary.get("merge_recommendation"),
        "whole_input_condition_transferred_to_r6": False,
    }

evidence = {
    "at_utc": datetime.now(timezone.utc).isoformat(),
    "project": str(ROOT), "baseline_commit": PIN,
    "read_only_git_commands": commands,
    "r6_input_aggregate": EXPECTED,
    "freezes_reconstructed": freezes,
    "transitions": transitions, "source_manifests": manifest_checks,
    "r5_seven_files_preserved_in_r6": preserved_seven,
    "tunnels": {
        "r5_from_pinned_HEAD_sha256": sha(old),
        "r5_bytes": len(old), "r6_sha256": sha(new), "r6_bytes": len(new),
        "segments": segment_evidence,
        "reverse_extraction_reassembles_entire_HEAD_file_byte_for_byte": True,
        "new_helper_header_exact": helper_header.decode(),
        "new_render_tail_exact": call.decode(),
        "call_counts": counts,
        "outside_extraction_unchanged": True,
        "new_context_entity_window_or_worker": False,
        "new_review_bypass_or_autonomous_execution": False,
        "new_stack_limit_assertion_or_test_changes": False,
    },
    "parent_receipts_read_back_only": receipts,
    "compiled_inventory_readback": {
        "r6_count": 1342, "unique": 1342, "r4_r5_r6_name_sets_equal": True,
        "failure_test_present": True, "workspace_tunnel_rule_module_names": sorted(module_names),
        "module_executed_passed": 19, "failed": 0, "ignored": 0,
        "module_executed_names_equal_inventory_subset": True,
        "inventory_does_not_prove_execution": True,
        "fresh_app_compile_seen_in_parent_fixed_log": True,
        "independently_verified_test_binary_or_dep_info": False,
    },
    "crash_readback": {
        "path": str(BASE / "kit-tunnels-stack-crash-frames-r1.json"),
        "sha256": sha(read(BASE / "kit-tunnels-stack-crash-frames-r1.json")),
        "reported_original_ips_sha256": crash["report_sha256"],
        "original_ips_independently_read": False,
        "faulting_thread": crash["faulting_thread"],
        "thread_name": crash["thread_name"],
        "frame_count": len(crash["faulting_frames"]),
        "selected_frames": [
            {"index": i, **row}
            for i, row in enumerate(crash["faulting_frames"]) if 7 <= i <= 18
        ],
        "stack_frame_bytes_or_infinite_recursion_established": False,
    },
    "prior_reports_read_back": prior_reports,
    "live_readback": {
        "all_719_paths_and_bytes_match_r6": True,
        "aggregate_sha256": aggregate(live_rows),
        "missing": [], "extra": [], "hash_mismatches": [],
    },
    "mechanism_boundary": {
        "management_returns_before_runtime_builder_call": True,
        "same_AnyElement_root_no_extra_layout_wrapper": True,
        "additional_palette_read_is_copy_only": True,
        "source_supports_smaller_management_render_frame": True,
        "actual_debug_frame_size_measured": False,
        "stack_upper_bound_proven": False,
        "compiler_inline_never_is_a_hint": True,
        "official_reference": "https://doc.rust-lang.org/reference/attributes/codegen.html#the-inline-attribute",
        "native_desktop_acceptance_established": False,
    },
}
write("static-evidence.json", evidence)
print(json.dumps({
    "r6_reconstructed": 719, "r6_aggregate": EXPECTED,
    "unchanged_previous_files": len(preserved_seven),
    "segments": segment_evidence, "call_counts": counts,
    "module": "19/0/0", "inventory": 1342,
    "live_input_match": True,
    "written": ["static-evidence.json", "r5-r6-tunnels.diff"],
}, ensure_ascii=False, indent=2))
