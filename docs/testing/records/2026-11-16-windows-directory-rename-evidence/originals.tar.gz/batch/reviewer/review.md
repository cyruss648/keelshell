**结论：APPROVE_STATIC；P0 / P1 / P2 / P3 均为 0。**

2026-11-16 独立非作者、严格只读复核。本批准只绑定下列 r2 工程输入。最终完整 gate 待父任务以同一冻结的成功回执补足；当前 Windows 功能与原生验收保持 HOLD。本审查未发现需立即发出 notice 的阻塞问题。

基线及审查起止 HEAD 均为 `4d72e1e592bdd6194f6eadca3a6a760192b5fe82`。r2 全部 719 项路径及字节在起点、终点均匹配，缺失、增加、摘要差异均为 0：

- aggregate：`d0707bf3c8971f4d1116fe9b9fc39b1d153d3471639764db0cebe0feb645f4b2`
- native.rs：`e2b082a91d3564bb436a062f024e18152f366d81df99dddd0fd5ab716b29c514`
- tests.rs：`2a41a12674277171d211e3533791cd736a7f0b0dbe8ceb782ff0523dad4bb965`
- 完整核对窗口：07:32:15–07:38:48 UTC（15:32:15–15:38:48 Asia/Shanghai）；见同目录 `inputs-begin-r2.json`、`inputs-end-r2.json`。

**核心检查与证据**

- [native.rs:94](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:94)：独立字节比较证明，普通 opener 仅搬出 access/share 计算；其余 NT 调用体相同。目录仍 READ/share-all，普通文件观察、私有重开、独占创建的访问权和分享参数保持。
- [native.rs:124](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:124)：两个私有调用点均保留 FILE_GENERIC_READ 和同步选项；UTF-16、UNICODE_STRING、OBJECT_ATTRIBUTES、IOSB、可选安全描述符存活至调用结束。成功返回的新 HANDLE 只由 File 接管一次，失败后已接管句柄由 RAII 关闭；原借用句柄不被接管。实际本地卷、对象类型和 reparse/删除待定/硬链接检查保持。
- [native.rs:359](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:359)：短 lease 以 source HANDLE 加空相对名请求 READ|DELETE、share READ|WRITE、FILE_OPEN；没有路径重建或备用路径打开。完整 FileInfo 比较及 private DACL 重验仍在返回之前。错误经 observe 原对象返回，未转成字符串或吞掉 kind/raw code；见 [native_diagnostics.rs:42](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/native_diagnostics.rs:42)。
- [native.rs:389](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:389)、[mod.rs:241](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/mod.rs:241)：no-replace syscall、名称预检及 lease 的局部生命周期保持。归档调用方的祖先/完整树复核和不确定结果隔离未改；见 [local_windows.rs:972](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/archive_transfer/local_windows.rs:972)。没有新增重试或清理失败对象。
- [tests.rs:517](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/tests.rs:517)、[tests.rs:561](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/tests.rs:561)：前/后 lease 路径替换测试检查原对象发布、不同身份替换对象及两者内容。后者复用同一 DELETE lease 完成中间改名，避免被第二次 DELETE 打开阻断；发布后的 READ/share-all 打开与活跃 lease 参数兼容。静态未见 Windows 测试夹具必然自阻断。
- [tests.rs:611](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/tests.rs:611)：检查 regular 的 InvalidData 拒绝、四类长期句柄在 lease 前/期间/释放后的 DELETE 与写属性拒绝（code 5）；另有写属性正向对照及分享前后成功/期间冲突（code 32）。DACL 正向保持得到检查；**新增例没有直接构造宽松 DACL 后调用 lease helper 的负例**。既有 DACL 拒绝测试仍在 [security/tests.rs:230](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/security/tests.rs:230)，不能将其写成新增 lease 负例已执行。

**r1 与 r2 分别绑定**

r1 aggregate `16037a06d3d88f25505b9f53154a7730f0defbab0798f061323f243d69442d47` 保持原件。r1→r2 719 项中仅 tests.rs 改变；仅在内存逆转五处错误取值修订，重建完整文件 SHA 精确匹配作者 r1 FROZEN 的 `b0d4cdf0ace84c0339542a0a4700df52917a552fe8ceda284e4540c5460277ff`。原消息、全部 88 条断言、原 19,200 字节/22 旧测试正文保持。Err 仍返回原错误，意外 Ok 仍令测试失败；没有 allow。生产字节未变。详见 `r1-r2-static-comparison.json` 与 `r1-r2-tests.diff`。作者 REPORT/FROZEN 未改写。

**执行与批准条件**

独立执行两次单文件 `rustfmt --check --edition 2024 --config skip_children=true` 和一次限定两文件的 `git diff --check`，三条命令均 exit 0；另做只读 Python 字节、路径、库存及回执摘要检查。**独立 Cargo、Clippy、Rust 测试、Windows、变异/red-green、GUI 执行均为 0。** 未访问共享 target，未运行作者脚本，主动写入仅在本 reviewer 目录；未修改工程/文档、提交、推送、建 worktree/chat 或启动容器。

已核对父 scoped-r1 原日志：`1/reaped/2.964s`，保留五处 expect_err lint 失败；scoped-r2：`0/reaped/2.890s`，fmt/x.y、host `18/0/0` 和 Windows cross-Clippy 通过。日志字节与回执 SHA 一致。这些是父执行证据，cross-Clippy 不是 Windows 执行。

本地两份 Microsoft 官方页面均与获取回执 SHA 匹配。它们支持同步参数、相对根与分享规则的审查，**不证明空名+DELETE 已实际 Windows 成功**。前一源码 run `43822369487` / job `133148170879` 原始日志的 `63/4/0`、四项 code 5 失败及三项游标成功只属于旧源码，不移签本批或旧评审。

父可在无需重新扩大本审查范围的前提下，另行绑定 **r2 完整 719 项相同输入**的最终完整 gate 成功回执及实际编译库存；输入改变须重新评估。本报告不等待该 gate。Windows 后续仍需核对精确新源码的实际预检库存及执行（源码预期 70 名，保留旧 67 加新 3）、原四项发布失败、新三项和相关 app 归档结果；当前不批准这些未执行功能或桌面验收。P0–P3 均无发现，因此没有缺陷触发/影响项或 notice。
