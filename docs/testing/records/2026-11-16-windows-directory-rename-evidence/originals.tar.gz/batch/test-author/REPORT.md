# Windows 目录发布 lease 回归作者报告

完成日期：2026-11-16。状态：**测试工程写集已冻结，仅完成静态验证，Windows 实际执行 NOT_RUN**。

## 范围与输入

- 基线 HEAD：`4d72e1e592bdd6194f6eadca3a6a760192b5fe82`。
- 唯一工程写集：`crates/keelshell-platform/src/windows/tests.rs`。
- 只追加 192 行、三个独立测试。原文件完整 19,200 字节前缀、全部 22 项既有测试及其辅助函数逐字节保留，没有修改旧断言、权限要求或 UNKNOWN 状态。
- 原文件 SHA-256：`7bbcd69bd03b15b91903b6a4ead4c56173a5456c05b0366e861ec921f08fded2`。
- 冻结文件：27,858 字节，SHA-256 `b0d4cdf0ace84c0339542a0a4700df52917a552fe8ceda284e4540c5460277ff`。
- 父生产候选回执：`../production-candidate-r1.json`，其中 native.rs SHA-256 为 `e2b082a91d3564bb436a062f024e18152f366d81df99dddd0fd5ab716b29c514`。本作者只读其 API 与分享契约，没有修改 native.rs。

既有 19 项覆盖目录完整树发布、no-replace、私有目标目录、UTF-16 名称边界、文件独占分享等；另三项覆盖独立目录扫描游标、游标前路径替换、游标 DACL/普通文件拒绝。新增例针对目录发布 DELETE lease，未重复游标测试。

## 新增测试

工程文件绝对路径：
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/tests.rs`。

1. 第 517 行：`directory_publication_retains_the_source_rebound_before_its_rename_lease`
   - 保留私有 stage 对象和原始内容，将其路径改名为 moved，再在原 stage 路径创建不同身份、不同内容的私有替换目录。
   - 通过公开 `Directory::rename_no_replace` 在路径替换之后取得 lease 并发布。
   - 检查 published 的 identity/attributes/security stamp、私有 DACL、精确子项和二进制内容；原 stage 替换对象的 stamp 和内容保持，moved 消失。

2. 第 561 行：`directory_rename_lease_retains_the_source_rebound_after_acquisition`
   - 先通过真实 `native::directory_rename_handle` 取得 lease 并核对私有 DACL/stamp。
   - 用同一个 lease 将原对象改名 moved，在原 stage 路径创建私有替换目录，再用该 lease 发布原对象。
   - 检查 lease、原保留句柄和 published 仍指向原 stamp，原二进制内容完整，替换目录及其内容保持，moved 消失。
   - 不另开 DELETE 句柄完成中间改名，避免被既有分享限制阻断而没有覆盖到路径替换后的发布。

3. 第 611 行：`directory_rename_lease_preserves_private_kind_access_and_share_contracts`
   - 私有普通文件被目录 lease helper 以 InvalidData 拒绝，拒绝前后文件元数据保持。
   - 对创建句柄、`as_directory`、`open_private_entry` 和 `open_directory` 四类长期句柄，在 lease 取得前、持有期间和释放后实际尝试重命名及设置修改时间，均要求 Windows access denied。
   - 显式请求 FILE_WRITE_ATTRIBUTES 的独立句柄能在同一目录设置固定时间，作为时间写入操作的正向对照；长期句柄不得因此获得写属性权限，修改时间保持。
   - 不分享 DELETE 的读打开者、另一个 DELETE 打开者在 lease 前后均可成功；lease 持有期间均须返回 sharing violation。由实际打开行为检查短期访问权、分享限制及释放恢复。
   - 核对 lease 与长期对象的 stamp、私有 DACL，以及空目录内容保持。

全部数据位于各例独立 TempDir。新代码不使用线程、sleep、调度时序、mock、手工删除或新增 unsafe；清理由 TempDir 承担。

## 静态验证与回执

- 读取并遵循 RTK.md、AGENTS.md、docs/HANDOFF.md，以及 Rust 测试、所有权、错误处理与 FFI 约定。
- 已读本地原始日志 `work/windows-directory-cursor-integration-20261116/source-windows-log-r3.log`：该旧执行实际 63 passed / 4 failed，四项均记有 reopen-directory-rename / PermissionDenied / raw_os_error=Some(5)。该旧执行结果没有移签给新增例或父新候选。
- 首轮单文件 rustfmt 检查 exit 1，仅报告新增代码换行；只调整新增代码后，最终单文件检查 exit 0。
- 最终 `rustfmt --check --edition 2024 --config skip_children=true crates/keelshell-platform/src/windows/tests.rs`：exit 0。
- 最终 `git diff --check -- crates/keelshell-platform/src/windows/tests.rs`：exit 0。
- 静态 Python 核对原始完整文件前缀字节相等、22 项原名保留、三个新名唯一、文本库存共 25 项；新增代码中 ignore、should_panic、unsafe、线程、sleep 和手工 remove 均为零。
- 检查前后 tests.rs 字节相等。可机读回执为 `static-receipt.json`；基线为 `baseline.json` / `tests-before.rs`，最终命令原始输出为 `rustfmt-check.log` / `git-diff-check.log`。

## 未执行边界与交回

本作者运行 Cargo、Clippy、Rust 类型检查、Windows 测试、变异/red-green、Podman、原生 UI 验收均为 **0 / NOT_RUN**。rustfmt 只能提供解析和格式证据，25 项只是源码文本库存，不是编译后或实际执行库存。

三个新例均必须实际取得目录 DELETE lease；前两项还必须实际发布原对象，第三项必须观察到真实 Windows 访问检查与分享冲突。基线 helper 的 PermissionDenied 缺陷应使其失败，但本作者没有执行该基线或新候选，因此“新例在旧实现已红”和“新实现已绿”均未建立。

工程写集现已冻结，供父任务独占 Cargo、统一格式与 cross-Clippy，再核对真实 Windows 编译库存和执行结果。本作者没有修改其他工程/文档、运行 format-all、清理、提交、推送，或创建用户 chat/worktree；共享 checkout 中父任务的其他变更不属于本作者写集。
