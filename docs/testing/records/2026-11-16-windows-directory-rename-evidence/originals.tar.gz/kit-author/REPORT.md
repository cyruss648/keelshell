# gpui-kit 0.10.0 迁移候选 — 2026-11-16

结论：可交给父任务在最终集中 gate 前集成，但**不建议仅改 manifest/lock**。
当前使用的组件 API 没有发现必须改调用点的破坏，资产没有字节变化；另外发现
一个实际行为迁移：0.10 新增按系统语言初始化 RTL，当前应用只提供中英文，
必须让组件布局方向跟随应用所选语言，否则在 RTL 桌面上会出现文案语言与
组件方向不一致，普通输入框左右键也会镜像。本候选只增加这处语言同步、
一项对应键盘回归，以及根依赖要求 `0.9` → `0.10`。

状态为 `STATIC_CANDIDATE_UNAPPLIED_UNCOMPILED`。本轮 Cargo、format、编译、
Rust 测试、原生运行均为 **0**，不能据此签编译兼容或原生验收。
唯一写集为本目录；父的 Windows 实现、独立测试、工程文档、manifest 和 lock
均未修改。检查基线 HEAD 为 `4d72e1e592bdd6194f6eadca3a6a760192b5fe82`；
实际读取的工作区依赖输入和 app 源码另有 SHA 快照，不能将并行父改动视为此 HEAD。

## 可立即审查的候选

- `patches/migration-candidate.patch`：合并候选，仅涉及以下两个应用文件。
- `patches/01-gpui-kit-0.10-requirement.patch`：根 `Cargo.toml` 的单行版本要求改为
  `0.10`，保持 x.y，既有六个语法 feature、默认 component/assets 和 dev
  `test-support` 声明均保留。
- `patches/02-selected-language-direction-and-regression.patch`：
  `i18n::set_language()` 在组件 locale 更新后调用
  `gpui_kit::base::LayoutDirection::from_locale(language.code()).set_global(cx)`。
  附有一项未编译回归
  `i18n::tests::app_languages_keep_plain_input_navigation_ltr_after_rtl_locale`：
  显式种下 RTL，在中英文两种选择下通过真正的 Input、绘制、焦点和按键派发，
  检查输入 `ab`、Left、`X` 得到 `aXb`。它不只断言全局变量。
- `analysis/candidate.json`：两文件及原 Cargo.lock 的基线 SHA；补丁未应用。
  此目录没有手写 lock 候选，父应由 Cargo 解析并审查。

建议父集成上述候选后统一更新 lock，再冻结最终组合输入并跑一次集中 gate。
如果当前 Windows 修复必须保持原范围，应将依赖升级整体后移；不要将已确认的
RTL 变化写成“只改版本即可完全等价”。

## 已确认的 API、资产与行为差异

| 范围 | 当前应用与 0.10.0 的直接证据 | 迁移判断 |
| --- | --- | --- |
| Facade、Window、GPUI 类型 | `gpui-kit/src/lib.rs` 仅 Quick Start 的两行文档改为使用 Label；去除注释/空行后的代码摘要一致。默认 `gpui-pre`、macros、platform 仍精确要求 `=0.3.12`。 | WindowOptions、open_window、application、App/Window、accesskit 等默认类型来源未切换。不能把这一点扩大为所有组件行为不变。 |
| 组件常用 trait | Component 的 component_traits、sizing、styled、window_ext、scroll/mod 源文件逐字节一致。Button/Checkbox/Popover 的既有调用接口仍在；其内部有 RTL、交互与辅助技术改动。 | 当前调用点不需机械重写。Button 非左键不抢焦点、disabled 不应用 hover/active 等需要行为复核。 |
| EditorState/InputState/TextareaState | Component 的 input/mod、state、editor、textarea、language_config 五文件逐字节一致；Base 的三个 concrete state 别名文件也一致。应用使用 `EditorState::new().language(...).searchable(false).folding(false).auto_close(false).smart_indent(false)`，不自行构造模式 extras。 | 这些构造与 reexport 路径保持。底层 state、movement、IME、选择及布局实现确有修改，需要下述专项。 |
| Textarea 关联类型 | Base `src/input/base/kind.rs:366` 起，TextareaMode 的 Extras 从 `()` 变为 TextareaExtras。扫描全部 `crates/**/*.rs`：TextareaMode、TextareaExtras、InputModeKind 和 `type Extras` 均无命中。 | 已确认未命中应用用法；不用改普通 TextareaState 构造。 |
| Editor gutter API | 发布说明称 `text_gutter_margin` 被 `text_origin_offset` 替代；但本机对应的官方 **0.9.1 已发布包**的 Base/Component 源码没有旧符号，0.10 源码同样没有。0.10 `src/input/base/state.rs:13549` 新增后者。应用两个符号均为零命中。 | 按已发布包实际差异判断：应用没有 gutter 调用需要替换。不能仅转述发布说明为本应用破坏证据。 |
| 额外移除的 Base API | 本地源码差异还显示 `dock_extent` 公共 helper 被移除，改由 dock renderer 提供关闭时尺寸。应用该符号零命中。 | 无当前调用迁移；此差异不是发布说明两个输入 API 的重复。 |
| 可选 gpui-fast | 最低要求从 0.1.14 升至 0.1.16；Fast 新的 Element blanket IntoElement 要求自定义 Element 删除重复实现。应用 manifest 未启用 gpui-fast，源码也无该 feature；默认仍 gpui-pre。应用 `SurfaceInputBoundary` 有一个自定义 IntoElement。 | **保留该自定义实现**。不能为未启用的 Fast 改动默认后端。lock 中出现 Fast 包不等于 feature 已启用；父解析 lock 后应复核实际 feature 图。 |
| Theme | 现有 `design/kit.rs` 写入的 118 个 color 字段在新 ThemeColor 中全部存在。Theme::update 的调用方式保持。新增 `list_highlight_foreground`；schema 可缺省并回退 blue，Select/Combobox/Command 的 highlight_matches 是 opt-in，应用零命中。 | 无 Theme struct literal 补字段或主题重设计候选；保留现有三个主题。新增高亮 token 不影响当前未开启的匹配高亮；以后开启时再明确映射。 |
| Assets | 五套官方旧包与本机 .cargo 目录逐文件一致。Assets 的 **1,831 个 assets/ 文件全部逐字节一致**，src/ 四文件、build.rs、default-icons 和 catalog 未变。Assets 包变化仅为 vcs、两个 manifest 及其 Cargo.lock。 | AllAssets、IconName/path、离线嵌入来源保持。当前 `application_source_resolves_every_declared_icon_offline` 仍应由父在新解析依赖下实际运行。 |
| test-support | Kit `src/test.rs`、test/events、test/input、test/query 四文件逐字节一致；五包 feature 表也全部相等。Base test_support 和 FocusTrap 的差异是为 Fast 添加条件化 IntoElement，默认 pre 分支保留。 | 未发现现有 test helper 的签名迁移；新增测试内容不算已运行。测试调度器让方向默认 LTR，原测试不自然覆盖 RTL 桌面，故附显式播种的回归。 |
| LayoutDirection | Base `src/layout_direction.rs:43,73,88` 与 lib.rs:251；Component Input `src/input/input.rs:541`；Base movement:293 起。系统方向在 native init 时读取；`component::set_locale()` 仅调用 rust_i18n，不同步方向。应用 i18n.rs:104 的 setter 当前也不设置方向。 | **需要功能代码候选**。中英文 code 映射到 LTR，兼顾启动和运行中语言切换，不改变主题、远程文本或终端语义。 |

机器可复核证据在 `analysis/compatibility-evidence.json`：零命中扫描带范围、
18 个关键文件的双版本 SHA、118 字段存在性、feature 表一致性和资产零变化。
全量路径/字节变化在 `analysis/*-files.json`；第三方完整 diff 仅在本地
`diffs/` 阅读，不作为应用补丁，也不应整份复制进工程文档。

## 具体新增风险与平台范围

1. **输入、编辑与 IME**：Base 现在按 grapheme cluster 移动/删除，unmark_text
   可能新发 Change；多行 IME candidate bounds 和 hit-test 的 gutter/行定位、
   长单行粘贴后的光标可见性都改变。Textarea 的 Cmd/Ctrl+Enter 不再插入换行。
   这会影响草稿 dirty 状态、查找替换位置、审核快照及提交键的传递。
   它不修改本项目编码器，但 UTF-16/GBK 保存必须确认审核/备份/读回仍精确，
   重复 Enter 或 IME 确认不能自动同意保存或发出终端命令。
2. **辅助技术**：新增 Input 的 TextRun 子节点、光标/选区；Label 开始提供 AX
   value；disabled input 有明确禁用语义。Base a11y_text.rs:23 起对
   inactive AX、unexposed 和 masked 字段直接不生成文本 runs，应用凭据控件
   已使用 masked(true)。这只是静态防护证据，仍要在 VoiceOver/UIA/AT-SPI
   检查敏感值不外露和可编辑值可读；旧 AX 根窗口观察不能代签新文本范围。
   Label::new 新增默认调用位置 ID，循环同级 Label 需要唯一 ID；当前四个
   应用构造点均在具名 preview 容器中，未发现本应用同级重复构造需要改写。
   直接 `.child("text")` 不会因依赖升级自动变成可访问 Label。
3. **Windows**：Theme `src/theme/mod.rs:147,386` 新同步约定：
   系统 auto-hide=true → Hover，false → Always；0.9 的对应模式为
   Scrolling/Hover。这是预期上游行为变化，不是主题重设计。
   WindowBorder 发起 resize 前会结束文本选择/active drag 并停止事件传播；
   Base 输入和 resize handle 在失活、bounds 变化、MouseExit 或丢失左键时
   取消手势。需确认拖动、窗口缩放、文件列表选择与模态审核不留悬挂状态。
   这些 UI 层变化不构成父 DELETE lease 修复的验收，也不触及其实现。
4. **Linux**：同样受 RTL、输入/AX 和鼠标手势变化影响；重点核对 X11/Wayland
   compositor 接管 resize/move 后恢复输入，以及 AT-SPI 文本接口。默认
   gpui-pre-platform 的 x11/wayland/runtime_shaders feature 要求未变，
   并非切换渲染后端。Reduced-motion 的 Linux portal 监听在 0.9.1 已存在，
   0.10 新增显式 preference/override API；应用没有相关 setter，不应把旧
   D-Bus 监听误报为本轮新增架构或强制引入显式偏好设置。
5. **测试盲区**：普通 deterministic 测试不读取系统 RTL/reduced-motion，
   模拟 IME 也不证明真实候选窗、平台输入法、GPU、辅助技术或桌面事件。
   编译和 cross-Clippy 不能代替原生平台验证。

## 最低 Rust 与依赖解析

五个新包及其旧版本均为 edition 2024，均没有声明 rust-version；所取上游根
manifest 同样没有新增 rust-version。因此**没有发现新声明的 MSRV 提升**，
但实际最低支持 Rust 仍是 UNKNOWN，不能将“未声明”写成“任意现有 Rust 都能编译”。
两版精确 commit 的根 rust-toolchain.toml 请求均为 404，失败回执保留；
它们不证明其他任意路径不存在工具链配置，也不改变本项目不 pin 的规则。

Base 唯一新增的普通依赖是 sys-locale `0.3`；当前 Cargo.lock 已有
sys-locale 0.3.2，官方元数据及本地 manifest 声明 rust-version=1.56。
默认 gpui-pre 仍精确 0.3.12。可选 Fast 最低要求提高，父的 lock 可能包含其
更新，即使应用未激活它；最终解析结果以父的 Cargo 和 feature 图为准。
不添加本项目 rust-version 或工具链 pin。

父可在集成 manifest 后执行受控 `cargo update -p gpui-kit --precise 0.10.0`，
审查 gpui-kit、gpui-base、gpui-component、gpui-component-macros、
gpui-kit-assets 五个 0.10.0 包与 checksum、sys-locale 的依赖边，以及可选 Fast
相关解析；本轮没有运行该命令，也没有伪造 lock 或保证其结果。

## 一次集中验证的精准建议

以下均为父后续建议，状态全部 `NOT_RUN`：

1. 合并父 Windows 修复、本依赖/语言候选及真实 lock；新非作者复核。
   冻结最终输入。若改变共享 target 的源码归属，严格按
   `docs/testing/SHARED_TARGET.md` 等父释放槽后失效本项目产物；不并发清理或编译。
2. 先列出新编译 app 测试库存并核对新增的方向回归名；父集中执行新方向回归、
   i18n 现有两例、assets 离线测试、design 与 workspace themes、window/modal
   scope/navigation、editor_keyboard/editor_search/editor_format/editor_encoding、
   terminal_text_input，以及 assistant 请求预览、AI settings/vault
   masking 与局部滚动相关现有回归。复用最终 full gate 已覆盖的实际运行，
   无须为了本报告重复一次相同长门禁；保留各专项的真实名称/计数和失败。
3. 最终工程 gate 由父按当前项目脚本统一跑一次：x.y、fmt、严格 workspace
   all-targets Clippy、workspace tests、rustdoc、Python 和 AI controller；
   官方依赖实时检查再确认 37 包状态。此次已知结果不能从先前 0.9.1 门禁移签。
4. Windows 精确 CI 仍需当前 platform preflight、目录发布回归及八项 app
   归档实际执行；本候选不降低父安全断言。Linux 的原生构建/测试以及 macOS
   本地门禁和真实桌面分别登记，不能用 cross-Clippy 或某平台成功替代其他平台。
5. 新增专项至少包含：a) 显式 RTL 初始状态下中英文 Input Left/Right 与文案；
   b) combining accent/emoji ZWJ 的移动、删除、undo，与 UTF-16 IME mark/commit/
   unmark 的 Change 次数和 dirty/review 保持；c) Textarea secondary Enter 无
   换行且不越过显式执行审核；d) 活跃辅助技术下 masked 文本不外露、普通字段
   selection/disabled/Label 语义；e) Windows 两种 scrollbar 偏好、X11/Wayland
   resize/拖动失去 MouseUp 的恢复。新增候选只提供了 a 的一项自动化，其余
   需要父决定复用现有覆盖或补专项，报告不声称覆盖完成。
6. 最小真实桌面复核：三主题、中英文与紧凑/普通窗口；Editor 单/多行中文输入法、
   Shift+Tab/Tab、窗口切换、粘贴、审核取消/确认；Windows UIA、Linux AT-SPI、
   macOS VoiceOver 以及实际 GPU/桌面缩放各自保留未验边界。旧的有限原生观察
   不随升级继承，发行验证也单列。

## 来源、回执与可回收材料

权威来源 URL、版本和包 SHA 表见 `SOURCES.md`；逐请求时间、HTTP 状态、
最终 URL、响应摘要和内容 SHA 在 `receipts/fetch.jsonl`。
十个双版本官方 crate 包均与 API checksum 相等；五个旧包另与当前 Cargo.lock
checksum 相等，并与本机 .cargo 中对应包逐文件一致，共 2,426 文件、
路径差异 0、内容差异 0。本机没有 .cargo-checksum.json，所以没有把缺失记录
当作完整性证明；改用下载的官方旧包直接比对。

本轮保存的 307 个 app/依赖相关输入在候选准备后的复读中零漂移
（`analysis/compatibility-evidence.json`），父并行修改的 Windows 与文档文件
不在这个不变断言内。静态补丁可应用性检查另见 `receipts/static-check.json`；
它不是格式化、编译或测试通过。

父保留所需报告、补丁与摘要后，可删除本目录的 `downloads/`（26 文件，
6,998,308 字节）、`upstream/`（4,857 文件，24,035,369 字节）和 `diffs/`
（5 文件，735,807 字节）。精确清单在 `analysis/removable-materials.json`。
本轮未实际删除任何材料，也未清理其他作者资源。
