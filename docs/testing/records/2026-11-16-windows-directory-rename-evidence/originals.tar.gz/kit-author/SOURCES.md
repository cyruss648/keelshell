# 官方来源与获取回执

获取日期：2026-11-16（UTC；完整起止时间保留于 receipts/fetch.jsonl）。

官方 registry 为 crates.io，包文件来自 static.crates.io；上游仓库来源由已发布 crate 的 repository 字段确认。所有请求均为公开只读 GET，无认证信息。

- Registry 元数据：https://crates.io/api/v1/crates/gpui-kit
- 官方 release：https://github.com/longbridge/gpui-kit/releases/tag/v0.10.0
- 0.9.1 crate VCS commit：`39ab849a93b5f15507b969164d49891db8d5b470`
- 0.10.0 crate VCS commit：`f697c3133d55c64fa8a5b67926147fb3dadd276d`
- commit 原件：https://api.github.com/repos/longbridge/gpui-kit/commits/f697c3133d55c64fa8a5b67926147fb3dadd276d
- 比较入口：https://github.com/longbridge/gpui-kit/compare/v0.9.1...v0.10.0

GitHub compare API 的响应有 300 个文件条目，可能达到服务返回上限；不拿它证明全仓差异穷尽。本报告的包兼容性判断采用完整、checksum 核对的已发布 crate 与本机旧包。

## 包 SHA-256

每个 SHA 均等于对应官方版本 API 的 checksum；旧版另等于工程 Cargo.lock checksum。

| 包文件 | SHA-256 |
| --- | --- |
| gpui-base-0.10.0.crate | `4f4e5aff50636223b268a687ad5788ec54fa77c8e57ca9e53d158f19e0425d95` |
| gpui-base-0.9.1.crate | `f3e9ae5237737cfd110d0ff513fcd9c20f97d98ebabd0a73164068177f0aca4f` |
| gpui-component-0.10.0.crate | `607c90f6985ac2b96e54102338994eaea143aff521375c6f9e7fc7ecb3ba3646` |
| gpui-component-0.9.1.crate | `e155c4914bd809d966660610d596f7b57c5cd38979ca2c132215057a91f23f03` |
| gpui-component-macros-0.10.0.crate | `510a438db463e4fcaec876a0cf76c3bfd900bc407207b0bc8c6076f91c09591b` |
| gpui-component-macros-0.9.1.crate | `9676a5d12c59ce295b5c82cc18365ad8b96cb683682e2e74668a56fb92544300` |
| gpui-kit-0.10.0.crate | `228cc61c0a71c4908af2e903807a81d2deabc03ec0be7f22189d43cf552af098` |
| gpui-kit-0.9.1.crate | `aca1dedfea73645b60b5893c9c16de0b1396f2cf4251d19e5f03a295c1b61879` |
| gpui-kit-assets-0.10.0.crate | `655474e0a0069db561d7d4029f84de59e41c0f1afff2301b23e00329968d3148` |
| gpui-kit-assets-0.9.1.crate | `cb5abe0bbd8f9226170c8726e529f6574519e297e9ed1bde86d5fd4d3536079a` |

## 所有请求

| HTTP | URL | 本地原件 | 内容 SHA-256 |
| --- | --- | --- | --- |
| 200 | https://crates.io/api/v1/crates/gpui-kit/0.9.1 | downloads/gpui-kit-0.9.1-metadata.json | 33e5068d10593964dafb03acb208134182cb70c7f133d9a81da47ff1ac970c95 |
| 200 | https://static.crates.io/crates/gpui-kit/gpui-kit-0.10.0.crate | downloads/gpui-kit-0.10.0.crate | 228cc61c0a71c4908af2e903807a81d2deabc03ec0be7f22189d43cf552af098 |
| 200 | https://crates.io/api/v1/crates/gpui-kit | downloads/gpui-kit-metadata.json | d97bcea39279aca98deb87199769a88d747acceb0c81f1602cfd4e7d229856d0 |
| 200 | https://static.crates.io/crates/gpui-component-macros/gpui-component-macros-0.10.0.crate | downloads/gpui-component-macros-0.10.0.crate | 510a438db463e4fcaec876a0cf76c3bfd900bc407207b0bc8c6076f91c09591b |
| 200 | https://static.crates.io/crates/gpui-kit/gpui-kit-0.9.1.crate | downloads/gpui-kit-0.9.1.crate | aca1dedfea73645b60b5893c9c16de0b1396f2cf4251d19e5f03a295c1b61879 |
| 200 | https://static.crates.io/crates/gpui-kit-assets/gpui-kit-assets-0.10.0.crate | downloads/gpui-kit-assets-0.10.0.crate | 655474e0a0069db561d7d4029f84de59e41c0f1afff2301b23e00329968d3148 |
| 200 | https://crates.io/api/v1/crates/gpui-base/0.10.0 | downloads/gpui-base-0.10.0-metadata.json | 5f7b8035604e39edf3ba6c200d38a529bf19f40ff20b7e1493994db630a91c6e |
| 200 | https://crates.io/api/v1/crates/gpui-component/0.10.0 | downloads/gpui-component-0.10.0-metadata.json | 21dc128df471611a25eaaba498f892bcd3fb00fba5e14e1dce67ca5f89886460 |
| 200 | https://static.crates.io/crates/gpui-component/gpui-component-0.10.0.crate | downloads/gpui-component-0.10.0.crate | 607c90f6985ac2b96e54102338994eaea143aff521375c6f9e7fc7ecb3ba3646 |
| 200 | https://crates.io/api/v1/crates/gpui-component-macros/0.10.0 | downloads/gpui-component-macros-0.10.0-metadata.json | 86182bf1800de9d71b8f97e737c6cb8b0457ad05ffee54b737dea5274c65a7be |
| 200 | https://crates.io/api/v1/crates/gpui-kit-assets/0.10.0 | downloads/gpui-kit-assets-0.10.0-metadata.json | 5876b0ea2eabad923c694a50e8d6238da4a68e078da68bd73c1bd92022be06b6 |
| 200 | https://static.crates.io/crates/gpui-base/gpui-base-0.10.0.crate | downloads/gpui-base-0.10.0.crate | 4f4e5aff50636223b268a687ad5788ec54fa77c8e57ca9e53d158f19e0425d95 |
| 200 | https://api.github.com/repos/longbridge/gpui-kit/releases/tags/v0.10.0 | downloads/release-v0.10.0.json | 66a41fee3cfe5f7258c8bbbbbe88a301e4fee68c08de987773c2993a34824c79 |
| 200 | https://api.github.com/repos/longbridge/gpui-kit/commits/f697c3133d55c64fa8a5b67926147fb3dadd276d | downloads/commit-0.10.0.json | e378742bd2ff7d9485702106e080d6864ec46006d650c277e090f40c0e97baef |
| 200 | https://static.crates.io/crates/gpui-component-macros/gpui-component-macros-0.9.1.crate | downloads/gpui-component-macros-0.9.1.crate | 9676a5d12c59ce295b5c82cc18365ad8b96cb683682e2e74668a56fb92544300 |
| 200 | https://crates.io/api/v1/crates/gpui-base/0.9.1 | downloads/gpui-base-0.9.1-metadata.json | a6addedb3ba47db52890a4f0daa7815dd69ae028a06a7721a1e98846cf694c8f |
| 200 | https://static.crates.io/crates/gpui-kit-assets/gpui-kit-assets-0.9.1.crate | downloads/gpui-kit-assets-0.9.1.crate | cb5abe0bbd8f9226170c8726e529f6574519e297e9ed1bde86d5fd4d3536079a |
| 200 | https://crates.io/api/v1/crates/gpui-component/0.9.1 | downloads/gpui-component-0.9.1-metadata.json | e0f69fc2375642a80594e8c844ace98f221279906cc77183b9dddc4318447405 |
| 200 | https://crates.io/api/v1/crates/gpui-component-macros/0.9.1 | downloads/gpui-component-macros-0.9.1-metadata.json | 20e4304538e0a6b363ee125cb6bb90dfab222cc74f8385e1941faf76c0304173 |
| 200 | https://static.crates.io/crates/gpui-component/gpui-component-0.9.1.crate | downloads/gpui-component-0.9.1.crate | e155c4914bd809d966660610d596f7b57c5cd38979ca2c132215057a91f23f03 |
| 200 | https://static.crates.io/crates/gpui-base/gpui-base-0.9.1.crate | downloads/gpui-base-0.9.1.crate | f3e9ae5237737cfd110d0ff513fcd9c20f97d98ebabd0a73164068177f0aca4f |
| 200 | https://raw.githubusercontent.com/longbridge/gpui-kit/f697c3133d55c64fa8a5b67926147fb3dadd276d/Cargo.toml | downloads/upstream-root-0.10.0.toml | 27ae931f60f6ec2d265fe5bb81fadaf499c83d2500a6d9ae6abce88675ce6239 |
| 200 | https://crates.io/api/v1/crates/gpui-kit-assets/0.9.1 | downloads/gpui-kit-assets-0.9.1-metadata.json | 98992fd7e19e27d71b5bd9f3bed91ee6337671f7248466ae33a0fc3a88002e36 |
| 404 | https://raw.githubusercontent.com/longbridge/gpui-kit/f697c3133d55c64fa8a5b67926147fb3dadd276d/rust-toolchain.toml | 未生成文件，错误保留于回执 | N/A |
| 404 | https://raw.githubusercontent.com/longbridge/gpui-kit/39ab849a93b5f15507b969164d49891db8d5b470/rust-toolchain.toml | 未生成文件，错误保留于回执 | N/A |
| 200 | https://raw.githubusercontent.com/longbridge/gpui-kit/39ab849a93b5f15507b969164d49891db8d5b470/Cargo.toml | downloads/upstream-root-0.9.1.toml | a25113b29fcf44c05ea6296def215b79744a603b7e23b1a9647702b70b72b4b3 |
| 200 | https://api.github.com/repos/longbridge/gpui-kit/compare/39ab849a93b5f15507b969164d49891db8d5b470...f697c3133d55c64fa8a5b67926147fb3dadd276d | downloads/upstream-compare.json | 6c618ad8dee70b2a0226c334bda02207ce48edc972c71a27d272cba0f836ef86 |
| 200 | https://crates.io/api/v1/crates/sys-locale/0.3.2 | downloads/sys-locale-0.3.2-metadata.json | 2fe98e6a97bf47306b72bb4aa3017dd082f8e77fa814bef07b8f3a6d61ee567f |

共 28 请求，26 成功，2 个精确 commit 的 rust-toolchain.toml 路径为 HTTP 404。十个 crate 的下载与版本元数据全部成功；404 未被当成包获取失败，也未据此证明其他路径不存在工具链配置。

第三方全文留在 downloads/upstream/diffs 本地阅读；报告不复制完整源码。
