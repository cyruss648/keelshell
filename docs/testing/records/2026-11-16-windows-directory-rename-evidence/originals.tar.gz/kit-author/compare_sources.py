#!/usr/bin/env python3
"""Record source/package evidence without invoking Cargo or touching its cache."""

import collections
import difflib
import hashlib
import json
from pathlib import Path
import tarfile
import tomllib

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent
REGISTRY = Path("/Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837")
PACKAGES = [
    "gpui-kit",
    "gpui-base",
    "gpui-component",
    "gpui-component-macros",
    "gpui-kit-assets",
]


def sha(content):
    return hashlib.sha256(content).hexdigest()


def save(name, value):
    destination = ROOT / "analysis" / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def files(directory):
    return {
        str(p.relative_to(directory)): p
        for p in directory.rglob("*")
        if p.is_file() and p.name not in {".cargo-checksum.json", ".cargo-ok"}
    }


if __name__ == "__main__":
    lock = tomllib.loads((REPO / "Cargo.lock").read_text())
    locked = {p["name"]: p for p in lock["package"] if p["name"] in PACKAGES}
    verification = []
    for archive in sorted((ROOT / "downloads").glob("*.crate")):
        package_version = archive.name.removesuffix(".crate")
        if package_version.endswith("-0.10.0"):
            package = package_version.removesuffix("-0.10.0")
            metadata_path = ROOT / "downloads" / (
                "gpui-kit-metadata.json"
                if package == "gpui-kit"
                else f"{package}-0.10.0-metadata.json"
            )
            metadata = json.loads(metadata_path.read_text())
            version = (
                next(v for v in metadata["versions"] if v["num"] == "0.10.0")
                if package == "gpui-kit"
                else metadata["version"]
            )
            expected = version["checksum"]
        else:
            metadata = json.loads(
                (ROOT / "downloads" / f"{package_version}-metadata.json").read_text()
            )
            expected = metadata["version"]["checksum"]
        actual = sha(archive.read_bytes())
        if actual != expected:
            raise ValueError(f"Official checksum mismatch: {archive.name}")
        verification.append(
            {"archive": str(archive.relative_to(ROOT)), "sha256": actual,
             "official_checksum": expected, "match": actual == expected}
        )
        with tarfile.open(archive) as source:
            for member in source.getmembers():
                if not (member.isfile() or member.isdir()):
                    raise ValueError(f"Unsupported archive member: {member.name}")
            source.extractall(ROOT / "upstream", filter="data")
    save("archive-verification.json", verification)
    summaries = []
    integrity = []
    manifest_comparison = []
    for package in PACKAGES:
        old = REGISTRY / f"{package}-0.9.1"
        new = ROOT / "upstream" / f"{package}-0.10.0"
        checksum_file = old / ".cargo-checksum.json"
        old_checksum = json.loads(checksum_file.read_text()) if checksum_file.exists() else None
        official = ROOT / "upstream" / f"{package}-0.9.1"
        official_files, local_files = files(official), files(old)
        failures = [
            name for name in official_files.keys() & local_files.keys()
            if official_files[name].read_bytes() != local_files[name].read_bytes()
        ]
        official_archive_sha = sha((ROOT / "downloads" / f"{package}-0.9.1.crate").read_bytes())
        integrity.append({
            "package": package, "version": "0.9.1", "path": str(old),
            "registry_checksum_file_present": checksum_file.exists(),
            "registry_package_checksum": old_checksum["package"] if old_checksum else None,
            "lock_checksum": locked[package]["checksum"],
            "official_archive_sha256": official_archive_sha,
            "package_checksum_matches_lock": official_archive_sha == locked[package]["checksum"],
            "official_files": len(official_files), "local_files": len(local_files),
            "path_difference": sorted(official_files.keys() ^ local_files.keys()),
            "file_failures": failures, "official_old_archive_compared": True,
        })
        old_files, new_files = files(old), files(new)
        rows, diff = [], []
        for name in sorted(old_files.keys() | new_files.keys()):
            before, after = old_files.get(name), new_files.get(name)
            a, b = before.read_bytes() if before else None, after.read_bytes() if after else None
            state = "unchanged" if a == b else "added" if a is None else "removed" if b is None else "changed"
            rows.append({
                "path": name, "state": state,
                "old_sha256": sha(a) if a is not None else None,
                "new_sha256": sha(b) if b is not None else None,
                "old_bytes": len(a) if a is not None else None,
                "new_bytes": len(b) if b is not None else None,
            })
            if state != "unchanged" and (
                name.startswith("src/") or name in {"Cargo.toml", "Cargo.toml.orig", "build.rs"}
            ):
                diff.extend(difflib.unified_diff(
                    (a or b"").decode(errors="replace").splitlines(keepends=True),
                    (b or b"").decode(errors="replace").splitlines(keepends=True),
                    fromfile=f"{package}-0.9.1/{name}",
                    tofile=f"{package}-0.10.0/{name}", n=4,
                ))
        save(f"{package}-files.json", rows)
        diff_dir = ROOT / "diffs"
        diff_dir.mkdir(exist_ok=True)
        (diff_dir / f"{package}.diff").write_text("".join(diff))
        before = tomllib.loads((old / "Cargo.toml").read_text())
        after = tomllib.loads((new / "Cargo.toml").read_text())
        manifest_comparison.append({
            "package": package,
            "old": {k: before.get(k) for k in ["package", "features", "dependencies", "target", "test", "build-dependencies"]},
            "new": {k: after.get(k) for k in ["package", "features", "dependencies", "target", "test", "build-dependencies"]},
        })
        counts = dict(collections.Counter(row["state"] for row in rows))
        changes = [row["path"] for row in rows if row["state"] != "unchanged" and row["path"].startswith("src/")]
        summary = {"package": package, "counts": counts, "source_changes": changes,
                   "diff_lines": len("".join(diff).splitlines())}
        summaries.append(summary)
        print(json.dumps(summary, ensure_ascii=False))
    old_official = files(ROOT / "upstream/gpui-kit-0.9.1")
    old_local = files(REGISTRY / "gpui-kit-0.9.1")
    save("old-kit-official-equivalence.json", {
        "official_files": len(old_official), "local_files": len(old_local),
        "path_difference": sorted(old_official.keys() ^ old_local.keys()),
        "content_difference": [
            name for name in old_official.keys() & old_local.keys()
            if old_official[name].read_bytes() != old_local[name].read_bytes()
        ],
    })
    save("source-summary.json", summaries)
    save("local-registry-integrity.json", integrity)
    save("manifest-comparison.json", manifest_comparison)
