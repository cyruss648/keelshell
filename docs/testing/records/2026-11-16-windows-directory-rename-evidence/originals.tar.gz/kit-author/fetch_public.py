#!/usr/bin/env python3
"""Fetch public upstream evidence into this candidate directory only."""

import concurrent.futures
import datetime
import hashlib
import json
from pathlib import Path
import sys
import time
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parent
PUBLIC_HOSTS = {
    "crates.io",
    "static.crates.io",
    "index.crates.io",
    "api.github.com",
    "raw.githubusercontent.com",
    "github.com",
    "codeload.github.com",
}


def fetch(spec):
    from urllib.parse import urlsplit

    url, relative_path = spec.split("=", 1)
    if urlsplit(url).hostname not in PUBLIC_HOSTS:
        raise ValueError("Only the explicitly listed public upstream hosts are allowed")
    destination = (ROOT / relative_path).resolve()
    if not destination.is_relative_to(ROOT):
        raise ValueError("Destination escapes the authorized candidate directory")
    if destination.exists():
        raise FileExistsError(destination)
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    tick = time.monotonic()
    receipt = {"url": url, "path": relative_path, "started_at_utc": started}
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": "KeelShell-dependency-review/1.0 (public read-only evidence)",
            "Accept": "application/json" if url.startswith("https://api.github.com/") else "*/*",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=45) as response:
            content = response.read()
            receipt.update(
                status=response.status,
                final_url=response.url,
                headers={
                    key: value
                    for key, value in response.headers.items()
                    if key.lower()
                    in {
                        "date", "content-type", "content-length", "etag", "last-modified",
                        "x-cache", "x-github-request-id", "content-encoding",
                    }
                },
                bytes=len(content),
                sha256=hashlib.sha256(content).hexdigest(),
            )
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(content)
    except (urllib.error.URLError, OSError) as error:
        receipt.update(error=str(error), status=getattr(error, "code", None))
    receipt.update(
        completed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        elapsed_seconds=round(time.monotonic() - tick, 3),
    )
    return receipt


if __name__ == "__main__":
    receipt_path = ROOT / "receipts" / "fetch.jsonl"
    receipt_path.parent.mkdir(parents=True, exist_ok=True)
    failed = False
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        futures = [pool.submit(fetch, spec) for spec in sys.argv[1:]]
        for future in concurrent.futures.as_completed(futures):
            receipt = future.result()
            with receipt_path.open("a") as stream:
                stream.write(json.dumps(receipt, ensure_ascii=False) + "\n")
            print(json.dumps(receipt, ensure_ascii=False))
            failed |= "error" in receipt
    sys.exit(1 if failed else 0)
