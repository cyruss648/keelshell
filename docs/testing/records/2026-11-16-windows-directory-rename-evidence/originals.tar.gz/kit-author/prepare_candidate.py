#!/usr/bin/env python3
"""Prepare unapplied, application-owned migration patches in this directory."""

import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent


def patch(path, before, after):
    return "".join(difflib.unified_diff(
        before.splitlines(keepends=True), after.splitlines(keepends=True),
        fromfile=f"a/{path}", tofile=f"b/{path}", n=4,
    ))


regression = r'''
    #[gpui_kit::test]
    fn app_languages_keep_plain_input_navigation_ltr_after_rtl_locale(cx: &mut TestAppContext) {
        use gpui_kit::{
            base::LayoutDirection,
            component::input::{Input, InputState},
        };

        struct DirectionInput {
            state: gpui_kit::Entity<InputState>,
        }

        impl Render for DirectionInput {
            fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
                div()
                    .w(gpui_kit::px(300.))
                    .p_4()
                    .child(Input::new(&self.state).id("locale-direction-input"))
            }
        }

        let (handle, view) = cx.update(|cx| {
            gpui_kit::init(cx);
            gpui_kit::open_window(WindowOptions::default(), cx, |window, cx| {
                cx.new(|cx| DirectionInput {
                    state: cx.new(|cx| InputState::new(window, cx)),
                })
            })
            .unwrap_or_else(|error| panic!("locale direction test window: {error}"))
        });
        for selected in [Language::ZhCn, Language::En] {
            cx.update_window(handle, |_, window, cx| {
                // The deterministic scheduler defaults to LTR, so seed the
                // direction that a real RTL desktop supplies during Kit init.
                LayoutDirection::Rtl.set_global(cx);
                set_language(selected, cx);
                let state = view.read(cx).state.clone();
                state.update(cx, |state, cx| {
                    state.set_value("", window, cx);
                    state.focus(window, cx);
                });
                window.render_frame(cx);
                window.input("ab", cx);
                window.press("left", cx);
                window.input("X", cx);
                assert_eq!(
                    state.read(cx).value().as_ref(),
                    "aXb",
                    "the app language must control plain-input arrow navigation"
                );
            })
            .unwrap_or_else(|error| panic!("locale direction keyboard interaction: {error}"));
        }
    }
'''

if __name__ == "__main__":
    patches = ROOT / "patches"
    patches.mkdir(exist_ok=True)
    manifest_path = "Cargo.toml"
    before_manifest = (REPO / manifest_path).read_text()
    old_requirement = 'gpui-kit = { version = "0.9", features = ['
    if before_manifest.count(old_requirement) != 1:
        raise ValueError("Manifest no longer matches the reviewed baseline")
    after_manifest = before_manifest.replace(old_requirement, old_requirement.replace('"0.9"', '"0.10"'))
    manifest_patch = patch(manifest_path, before_manifest, after_manifest)
    (patches / "01-gpui-kit-0.10-requirement.patch").write_text(manifest_patch)
    i18n_path = "crates/keelshell-app/src/i18n.rs"
    before_i18n = (REPO / i18n_path).read_text()
    needle = "    gpui_kit::component::set_locale(language.code());\n"
    if before_i18n.count(needle) != 1:
        raise ValueError("Language setter no longer matches the reviewed baseline")
    after_i18n = before_i18n.replace(
        needle,
        needle
        + "    // Component direction follows the selected app language, not the desktop locale.\n"
        + "    gpui_kit::base::LayoutDirection::from_locale(language.code()).set_global(cx);\n",
    )
    after_i18n = after_i18n.rstrip().removesuffix("}") + regression + "}\n"
    locale_patch = patch(i18n_path, before_i18n, after_i18n)
    (patches / "02-selected-language-direction-and-regression.patch").write_text(locale_patch)
    (patches / "migration-candidate.patch").write_text(manifest_patch + locale_patch)
    record = {
        "status": "STATIC_CANDIDATE_UNAPPLIED_UNCOMPILED",
        "target_files": [manifest_path, i18n_path],
        "additional_parent_owned_change": "Cargo.lock must be resolved by Cargo after integration",
        "direct_registry_requirement": "0.10",
        "theme_design_changes": 0,
        "production_api_change": "Synchronize Base layout direction to selected application language",
        "new_test": "i18n::tests::app_languages_keep_plain_input_navigation_ltr_after_rtl_locale",
        "compiled_tests": 0,
        "executed_tests": 0,
        "baseline_sha256": {
            manifest_path: hashlib.sha256(before_manifest.encode()).hexdigest(),
            i18n_path: hashlib.sha256(before_i18n.encode()).hexdigest(),
            "Cargo.lock": hashlib.sha256((REPO / "Cargo.lock").read_bytes()).hexdigest(),
        },
    }
    (ROOT / "analysis/candidate.json").write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(record, ensure_ascii=False))
