"""Seal completed delivery receipts; never include active logs or binaries."""

import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
DEST = ROOT / "docs/testing/records/2026-11-16-windows-fixture-publication-evidence/delivery"
assert not (DEST / "originals.tar.gz").exists()
selected = [
    f"{label}.{extension}"
    for label in (
        "commit-bind-r1", "source-push-r1", "prior-ci-evidence-verify-r1",
        "normal-build-r1", "package-r1", "native-package-inspect-r1",
        "evidence-verify-r1", "source-ci-runs-r1", "source-ci-snapshot-r3",
        "source-windows-active-log-r1",
    )
    for extension in ("json", "log")
]
selected += [
    "source-delivery-r1.json", "normal-package-binding-r1.json",
    "owned-cleanup-r1.json", "native-availability-r1.json",
]
files = [(f"batch/{name}", WORK / name) for name in selected]
files += [
    ("tools/verify.py", DEST / "verify.py"),
    ("package/package-manifest.json", WORK / "package-r1/package-manifest.json"),
]
entries = []
plain = io.BytesIO()
with tarfile.open(fileobj=plain, mode="w", format=tarfile.USTAR_FORMAT) as archive:
    for name, path in files:
        raw = path.read_bytes()
        member = tarfile.TarInfo(name)
        member.mode = 0o644
        member.size = len(raw)
        archive.addfile(member, io.BytesIO(raw))
        entries.append({
            "path": name, "source_path": str(path.relative_to(ROOT)),
            "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
        })
packed = gzip.compress(plain.getvalue(), mtime=0)
(DEST / "originals.tar.gz").write_bytes(packed)
manifest = {
    "schema": "keelshell.windows-fixture-delivery.v1",
    "source": "ee3ad7320e90f40c9d777c500543cc6e909d0484",
    "engineering_sha256": "1a516c0280487e62157ad3ee470206ef91c12a08501f12214ef7348c688cfc3a",
    "count": len(entries), "archive_bytes": len(packed),
    "archive_sha256": hashlib.sha256(packed).hexdigest(),
    "uncompressed_bytes": sum(row["bytes"] for row in entries),
    "entries": entries,
    "ci_at_seal": "IN_PROGRESS",
    "excluded": ["active watcher", "Cargo target", "app binaries", "other task resources"],
}
(DEST / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({key: manifest[key] for key in (
    "source", "count", "archive_bytes", "archive_sha256", "uncompressed_bytes",
)}))
