# 精确源码 CI 独立证据复核

**APPROVE，限定本次证据范围。P0=0、P1=0、P2=0、P3=0。**

工程 `ee3ad7320e90f40c9d777c500543cc6e909d0484`；开始时 docs HEAD `ebefc90e850a4843475da01587b771ab1d244f11` 是其直接子提交，差异仅文档及其证据。已读 AGENTS.md、RTK.md、HANDOFF.md；后者“CI 运行中”为旧状态。本次以指定终态原件复核，两个必要脚本与工程 Git 原文逐字节相等。

以下日志均在 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-fixture-publication-integration-20261116/`，行号为原件一基行号。14 输入的 bytes／SHA-256、机器可读计数、原文定位及全部命令账本见本报告同目录 receipt.json。

## 终态与计数

`source-ci-snapshot-r7.log:1`：Quality **43880245383 completed/success**，精确工程 headSha；macOS **133343901229**、Windows **133343901451**、Ubuntu **133343901650** 均 completed/success。三平台 packaging、quality gate success；Windows 三项 preflight success。macOS／Ubuntu OpenSSH 及 receipt 保存 success，Windows skipped；原日志分别 `source-macos-job-r2.log:5970`、`source-ubuntu-job-r1.log:6176` 明确 passed（35.073s／21.281s）。

| 平台 | 普通 Rust passed/failed/ignored | 套件 | app 声明=唯一逐名结果 | app passed/failed/ignored | 主 Python run/passed/skipped；秒 | rustdoc passed/failed/ignored |
|---|---:|---:|---:|---:|---:|---:|
| Windows | 3212/0/46 | 92 | 1332=1332 | 1330/0/2 | 293/259/34；6.529 | 14/0/0 |
| macOS | 3225/0/48 | 92 | 1343=1343 | 1341/0/2 | 293/291/2；15.207 | 14/0/0 |
| Ubuntu | 3218/0/49 | 92 | 1344=1344 | 1342/0/2 | 293/291/2；10.941 | 14/0/0 |

独立从原文按 running／逐名结果／summary 重算，逐套声明、唯一名字、结局与摘要相符；再与给定摘要全部逐名结果比较，差异 0。92 套件包含 app；两个 harness=false controller 单列，rustdoc 六个 subrun／五个 header 共 14 项另计，未被早到 stderr header 截断。

app 原文：Windows `:2556–3899`、macOS `:1502–2856`、Ubuntu `:1681–3041`。主 discovery 为各日志 `:1591–1596`、`:492–497`、`:681–686`。macOS `:4333`／Ubuntu `:4519` 后续 Rust 内 30 项 Python helper 未混入主 discovery；Windows 无该后续摘要。

**CI app 无独立 `--list`；主 Python 无独立 list、无逐名 `-v`。** app 仅证明运行声明数与唯一逐名结果相等；Python 为精确源码完整 discovery 的总数／skip／成功，不能说有逐名 CI 签署。

## Windows 实际工装

`source-windows-job-r1.log:453–546` filesystem 70/0/0；`:548–730` archive 独立库存 **41**，执行 41/0/0；`:733–1571` session 独立库存 **332**，执行 329/0/3 ignored。两组库存均唯一，分别与唯一逐名结果集合完全相等，差异 0；不重复计入完整 gate。

新增三例在 `scripts/test_windows_native_crash.py:832、843、853`：完成标记前不读记录、完成后 PermissionError 仍 fail closed、Windows exclusive 文件反例。前两例无 skip；第三例仅非 Windows skip，实际 `CreateFileW(share=0)` 并断言直接读触发 PermissionError、无标记时不打开记录、关句柄并发布后可读。只读 AST 核实本文件 72 test／8 类／无 load_tests 替换；结合 `scripts/check.py:73` 全 discovery、Windows 293／34skip／OK，支持 exclusive 新例覆盖。**它没有独立逐名运行行或单独回执。** 非 Windows 两个 skip 与 exclusive、native barrier 两处 Windows-only decorator 一致；其余 Windows skip 未逐名归属。

Windows `:1599` 七个 actual tree controls 全部 host=nt、保留原始句柄、父子 Job membership=true、identity_bound_before_ack=true，终态原始父子句柄均 TERMINAL。源码 `:497–525、636–706` 明确先绑定原始句柄及 Job／LIVE，再 ACK，返回后无新增 grace 查询原始句柄；重开 PID 只作附加观察，finally 关闭句柄。

| actual control | controller／observed exit | 边界 | elapsed 秒 |
|---|---|---|---:|
| delayed detached timeout | 124／null | delay 0.6；准备 0.612090 | 1.023300 |
| parent failure / inherited | 7／7 | timed_out=true 仍保留 exit7 | 0.455052 |
| parent success / detached | 0／0 | 正常退出仍清理子树 | 0.067262 |
| SIGINT | 130／null | 已发送／已中断 | 0.057553 |
| staged SIGINT | 130／null | empty、partial 均拒绝后 ACK | 0.076820 |
| inherited timeout | 124／null | 继承管道 | 0.454760 |
| detached timeout | 124／null | 分离管道 | 0.455507 |

七项均 reaped=true、active=0、pipes_drained=true、errors=[]；admission_closed、identities_bound 均 true，original_handles_checked=2 或 3，pending=0；身份后 0.011244–0.411432s，均小于源码 3s 限额。124／130／7 是受控预期结果，外层 discovery 成功。

Windows `:1597–1598` actual native nested Job：准备 helper finished、observer identity_bound、无准备错误；屏障前后原始父子句柄 **LIVE/LIVE → LIVE/LIVE**，成员 `[1956,7496]`、binding total=2。late CreateProcess **拒绝／1816**，nested membership=true、late marker=false；终态原始父子句柄均 TERMINAL。receipt observed/controller exit=0、无 timeout／interrupt／errors，reaped／active=0／pipes 齐全，original_handles_checked=3、pending=0。源码 `:1587–1606` 保证 before／after 采样在 ACK 前。

## 命令、计时与边界

四个历史 controller JSON 的 log bytes／SHA-256 均吻合；全部 observed/controller exit=0、无 timeout／interrupt／errors，reaped=true、active=0、pipes_drained=true。以下是**原件历史命令，本次未执行**：

| 历史命令 | exit | seconds |
|---|---:|---:|
| `gh run watch 43880245383 --exit-status --interval 20` | 0 | 1893.750633 |
| `gh api --allow-escape-sequences repos/cyruss648/keelshell/actions/jobs/133343901229/logs` | 0 | 3.592151 |
| 同上 job `133343901451` | 0 | 3.424882 |
| 同上 job `133343901650` | 0 | 3.402147 |

三平台 gate 均到 readiness、observer、small-stack 终点；Windows `:6365–6376、7041–7043` 记录 readiness passed、observer child reaped/scratch cleaned、small-stack controller end／all assertions passed。check.py 使用 check=True 且 step success，支持阶段成功；未另外打印每条命令数字 exit，不能声称有独立数字回执。

本复核实际命令账本如下；C02–C10 均为 `python3 -B -` 内联处理，嵌入 Git 的完整 argv／exit 见 receipt，未导入测试或运行给定摘要程序。

| 批次 | 实际动作／子命令 | exit | 记录秒 |
|---|---|---:|---:|
| C01 | pwd；限定 rg --files；cat AGENTS／RTK；memory rg | 0 | 无独立计时 |
| C02 | 交接／输入读取；git rev-parse 两次、log -1、diff --name-status | 0 | 0.045884 |
| C03 | 摘要源码读取；git show 两个必要脚本 | 0 | 0.030371 |
| C04 | 必要脚本／日志定位 | 0 | 0.066948 |
| C05 | 三平台原文独立解析／比对、AST | 0 | 0.046177 |
| C06 | 句柄／ACK／exclusive／barrier 源文 | 0 | 0.000303 |
| C07 | controller／预检／七树／barrier／OpenSSH | 0 | 0.062378 |
| C08 | controller 尾部、入口、14 输入哈希 | 0 | 0.014122 |
| C09 | 重新汇总、创建两产物、初次读回比较 | **1** | 工具 wall 0.0313 |
| C10 | JSON 规范化修正、最终读回／哈希复查 | 见 receipt | 见 receipt |

C02–C08 秒数为脚本已打印 perf_counter 区间；工具同期 wall 显示 0.0000s，不能作为可靠外层计时，未记录者不补造。C02／C03 过量 JSON 和 C04 长行输出被工具截断，已由有界原件解析补足。C09 在写入后比较 Python tuple 与 JSON array 而触发 AssertionError，原件未受影响；该 exit1 保留，本目录产物按 JSON 规范化完成最终读回。

唯一写入：本目录 REPORT.md、receipt.json。14 输入哈希复查一致；Cargo／测试／target 写入／网络或 CI 查询／项目修改／提交推送／清理均 0。未重复父任务封存及文档。

**未验：完整产品、三平台交互 native 桌面、客户环境、CDB 应用崩溃诊断、发行安装签名公证、上传 OpenSSH artifact 内件、Python 全部 skip 逐名归属。此 APPROVE 仅签署所列精确源码 CI 及真实 Windows 工装证据，不构成产品或桌面验收。**
