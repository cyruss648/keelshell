"""Preserve independent CI review and remaining derivation copies for cleanup."""

import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
REVIEW = ROOT / "work/windows-fixture-ci-review-20261116"
DEST = ROOT / "docs/testing/records/2026-11-16-windows-fixture-publication-evidence/ci-completion/independent-review"
DEST.mkdir()
receipt = json.loads((REVIEW / "receipt.json").read_bytes())
assert receipt["verdict"] == "APPROVE"
assert receipt["finding_counts"] == {"P0": 0, "P1": 0, "P2": 0, "P3": 0}
assert receipt["source_input_hashes_rechecked"]
assert receipt["readback"]["final"]["status"] == "passed"
assert hashlib.sha256((REVIEW / "REPORT.md").read_bytes()).hexdigest() == receipt["report_sha256"]
files = [(f"review/{name}", REVIEW / name) for name in ("REPORT.md", "receipt.json")]
files += [
    (f"derivation/{name}", WORK / name)
    for name in (
        "docs-check-r2.json", "prior-source-macos-summary-r4.json",
        "prior-source-ubuntu-summary-r4.json", "prior-source-windows-summary-r4.json",
        "seal_delivery.py",
    )
]
files.append(("tools/seal_ci_review.py", Path(__file__).resolve()))
entries = []
plain = io.BytesIO()
with tarfile.open(fileobj=plain, mode="w", format=tarfile.USTAR_FORMAT) as archive:
    for name, path in files:
        raw = path.read_bytes()
        member = tarfile.TarInfo(name)
        member.mode = 0o644
        member.size = len(raw)
        archive.addfile(member, io.BytesIO(raw))
        entries.append({
            "path": name, "source_path": str(path.relative_to(ROOT)),
            "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
        })
packed = gzip.compress(plain.getvalue(), mtime=0)
(DEST / "originals.tar.gz").write_bytes(packed)
manifest = {
    "schema": "keelshell.windows-fixture-ci-review.v1",
    "source": "ee3ad7320e90f40c9d777c500543cc6e909d0484",
    "run": 43880245383, "verdict": receipt["verdict"],
    "finding_counts": receipt["finding_counts"],
    "count": len(entries), "archive_bytes": len(packed),
    "archive_sha256": hashlib.sha256(packed).hexdigest(),
    "uncompressed_bytes": sum(row["bytes"] for row in entries),
    "entries": entries,
    "tests_replayed": 0, "native_desktop_acceptance": False,
}
(DEST / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({key: manifest[key] for key in (
    "count", "archive_bytes", "archive_sha256", "uncompressed_bytes",
)}))
