"""Seal the completed exact-source run, retaining earlier fetch diagnostics."""

import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
DEST = ROOT / "docs/testing/records/2026-11-16-windows-fixture-publication-evidence/ci-completion"
assert not (DEST / "originals.tar.gz").exists()
labels = [
    *(f"source-ci-snapshot-r{number}" for number in range(1, 8)),
    "source-ci-watch-r1", "source-macos-job-r1", "source-macos-job-r2",
    "source-windows-active-log-r1", "source-windows-job-r1", "source-ubuntu-job-r1",
]
names = [f"{label}.{extension}" for label in labels for extension in ("json", "log")]
names += [
    *(f"source-{key}-summary-r1.json" for key in ("macos", "windows", "ubuntu")),
    "source-parsing-r1.json", "parser-preparation-r1.json", "parser-preparation-r2.json",
]
files = [(f"ci/{name}", WORK / name) for name in names]
files += [
    ("tools/summarize_ci_r3.py", WORK / "summarize_ci_r3.py"),
    ("tools/summarize_source_ci.py", WORK / "summarize_source_ci.py"),
    ("tools/verify.py", DEST / "verify.py"),
    ("tools/seal_ci_completion.py", Path(__file__).resolve()),
]
entries = []
plain = io.BytesIO()
with tarfile.open(fileobj=plain, mode="w", format=tarfile.USTAR_FORMAT) as archive:
    for name, path in files:
        raw = path.read_bytes()
        member = tarfile.TarInfo(name)
        member.mode = 0o644
        member.size = len(raw)
        archive.addfile(member, io.BytesIO(raw))
        entries.append({
            "path": name, "source_path": str(path.relative_to(ROOT)),
            "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
        })
packed = gzip.compress(plain.getvalue(), mtime=0)
(DEST / "originals.tar.gz").write_bytes(packed)
manifest = {
    "schema": "keelshell.windows-fixture-ci-completion.v1",
    "source": "ee3ad7320e90f40c9d777c500543cc6e909d0484",
    "run": 43880245383, "status": "completed", "conclusion": "success",
    "engineering_sha256": "1a516c0280487e62157ad3ee470206ef91c12a08501f12214ef7348c688cfc3a",
    "count": len(entries), "archive_bytes": len(packed),
    "archive_sha256": hashlib.sha256(packed).hexdigest(),
    "uncompressed_bytes": sum(row["bytes"] for row in entries),
    "entries": entries,
    "native_desktop_acceptance": False,
    "tests_replayed_for_summary": 0,
    "excluded": ["Cargo target", "app binaries", "other task resources"],
}
(DEST / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({key: manifest[key] for key in (
    "source", "count", "archive_bytes", "archive_sha256", "uncompressed_bytes",
)}))
