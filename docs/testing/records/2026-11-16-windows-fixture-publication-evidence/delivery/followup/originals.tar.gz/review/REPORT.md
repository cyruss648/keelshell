当前交付补充的独立、限定只读复核 — 2026-11-16

**结论：APPROVE。P0 = 0，P1 = 0，P2 = 0，P3 = 0。**

批准仅覆盖指定文档及两个补充归档的成员、摘要、回执、精确 SHA、历史三方读回、计数、链接和验收边界。当前 CI `43880245383` 的终态未验、未批准；原生桌面与完整产品验收未批准。没有工程修订建议或合并阻断发现。

**复核基线与提交变化**

工作区：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`。起始 HEAD／工程源码：`ee3ad7320e90f40c9d777c500543cc6e909d0484`。结束观察到的纯文档提交：`ebefc90e850a4843475da01587b771ab1d244f11`，其直接父提交为起始 HEAD。父代理随后确认该 docs-only 提交并正在普通 push；本报告不签署该新 push 的结果。

复核期间只发生父代理的纯文档提交。13 个指定文件的当前字节、初始复核摘要和新 docs 提交内字节全部一致；精确提交差异也只包含这 13 个 docs 文件。HEAD 前移没有被误判为工程输入漂移。报告中的 719 输入校验分别绑定 ee3 与 958 的精确 Git 对象，不随当前 HEAD 移签。

13 文件范围总摘要（按排序的 repo-relative-path + NUL + SHA-256 + LF）：`cd70426213e4653efbd5b71949b748eda012cf2ce11eda9790cd80f26005307b`。逐文件字节数／摘要见 receipt.json 的 scoped_snapshot。复核测量与生成时间使用 UTC；本机为 Asia/Shanghai。报告生成检查开始：`2026-11-16T14:27:28.851749+00:00`。

**范围与文件行号**

- [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/ROADMAP.md:25](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/ROADMAP.md:25)：当前源码／新旧 run／计数／待终态边界；第 73 行起包结构与归档入口。
- [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/HANDOFF.md:28](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/HANDOFF.md:28)：SHA、历史回执及新 CI；第 97 行起正常包与 GUI 未验边界。
- [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/product/CAPABILITIES.md:3](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/product/CAPABILITIES.md:3)：本次新增能力／验收台账；第 15 行起 CI，21 行起结构检查与 native 分界。
- [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/testing/records/2026-11-16-windows-fixture-publication.md:77](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/testing/records/2026-11-16-windows-fixture-publication.md:77)：交付、三方读回、CI 快照、包和回收补充；第 54 行起的原始宿主 skipped／执行 0 保留为历史时点。
- [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/testing/records/2026-11-16-windows-zmodem-test-contract.md:131](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/testing/records/2026-11-16-windows-zmodem-test-contract.md:131)：958 精确终态；第 115 行的运行中描述属于此前快照，由追加终态接续。
- [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/testing/records/2026-11-16-windows-fixture-publication-evidence/delivery/README.md:3](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/testing/records/2026-11-16-windows-fixture-publication-evidence/delivery/README.md:3)：26 成员交付、源码、包与 IN_PROGRESS 边界。
- [/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/testing/records/2026-11-16-windows-zmodem-test-contract-evidence/ci-completion/README.md:3](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/testing/records/2026-11-16-windows-zmodem-test-contract-evidence/ci-completion/README.md:3)：21 成员的 958 终态、计数与解析说明。

**归档和回执的核实结果**

| 补充 | 成员 | 原文总字节 | gzip 字节 | gzip SHA-256 |
| --- | ---: | ---: | ---: | --- |
| delivery | 26 | 32,595 | 7,408 | `8ad5e7cb90e9eb7cc88df695aa50ffa6f8cffc7afb62067a7eea5bac674d2123` |
| ci-completion | 21 | 3,747,526 | 649,722 | `b3aa1c027aef7d7cca6eefa38731e41d43275266c41103349d97e88a157e2f75` |

47 个成员逐项字节数与 SHA-256、总原文大小、压缩包大小／摘要均匹配。重复成员、非普通文件、稀疏文件、绝对路径及父目录穿越均为 0。tar 只在内存读取，未解包落盘。两份外部 verify.py 与各自归档内 tools/verify.py 字节一致。

15 组回执／原日志独立核对匹配：delivery 10 组（9 个退出 0，活动 Windows 日志请求退出 1）；ci-completion 5 组（4 个退出 0，失败 run 的 watch 退出 1）。均未 timeout/interruption，direct_reaped=true、active_processes=0、pipes_drained=true。原 404/BlobNotFound 与失败 watch 的退出 1 均按原语义保留，没有改签为测试结果或成功。

源码 push 原日志是普通 `95813a7..ee3ad73` 更新；归档内 local、tracking、remote 四十位 SHA 均为 ee3ad7320e90f40c9d777c500543cc6e909d0484，三次读取和 status 都退出 0，status stdout 为空。“干净”限定为该归档读回时点；不声称最初带补充修改的工作副本本来干净。没有重新联网读 remote。

清理清单四项大小 15,835 + 18,645 + 14,760 + 16,855 = 66,095 字节，数量与记录一致；原记录声明精确 Git 核对和 Ramanujan／Boyle 关闭，复核未重复清理或 agent 操作。

主体 25／93 成员归档、manifest 和 verifier 共六文件与指定源码 Git 原件字节一致；两个授权 verifier 的递归只读校验均通过。主体封存未重写。

**精确 CI 和计数**

958 的最终归档 API 身份为 `43873806902 / 95813a76f0ec9b59fd043cd982e33cdc01dd69f8 / completed / failure`。三个 Job ID、gate/OpenSSH step 与文档一致。独立从原日志重新核对，结果如下（表中 Rust 为 passed / failed / ignored）。

| 958 范围 | 核对结果 |
| --- | --- |
| Windows filesystem | `70 / 0 / 0`；running 70 与 70 个唯一结果一致；未声称另有独立 --list。 |
| Windows core archive | `41 / 0 / 0`；41 个 --list 名字、41 个唯一执行结果逐项相等。 |
| Windows session | `329 / 0 / 3`；332 个 --list 名字、332 个唯一执行结果逐项及顺序一致。 |
| Windows 本批 Zmodem local | `43 / 0 / 2`，45 名；两个新祖先重命名断言与空父目录替换例均逐名 ok。选择范围为 zmodem::local::，另有 8 项 zmodem::tests 不混计。 |
| Windows 完整 gate | Python 290 run / 1 failure / 34 skipped；reading_publication PermissionError；workspace Rust NOT_RUN。 |
| macOS | 92 个普通套件 `3225 / 0 / 48`，6 个 rustdoc 子运行合计 `14 / 0 / 0`；app `1341 / 0 / 2`、声明及唯一结果 1343；gate/OpenSSH success。 |
| Ubuntu | 92 个普通套件 `3218 / 0 / 49`，6 个 rustdoc 子运行合计 `14 / 0 / 0`；app `1342 / 0 / 2`、声明及唯一结果 1344；gate/OpenSSH success。 |

Unix 两平台各 98 个 libtest run 的声明、唯一逐名结果、摘要，与封存 r3 全部逐项匹配。r2 按第一个 Doc-tests 头分割的代码及拒绝诊断保留；r3 重派生由正式 verifier 完成，未重跑测试。macOS active-log 文件名对应的内容实际含完整 OpenSSH 和 post-job cleanup，终态 API 也为 success。CI app 是 running N 对唯一结果的核对；宿主独立 --list 是另一份证据，文档没有混称。

新 ee3 run `43880245383` 仅有封存的 in_progress 快照：Windows 133343901451 三项预检 step success，macOS 133343901229、Ubuntu 133343901650 和 Windows gate 均 in_progress，conclusion 为空。新 293 项 Python、exclusive file、Job barrier、完整 gate／OpenSSH 的精确终态继续未验。本次没有查询 CI，也没有因旧 run 通过或新 step success 而提前批准。

**正常包与 native 边界**

归档内 package binding 与 package-manifest 的 commit、719 冻结摘要、aarch64-apple-darwin target、rustc 1.100.0、六个包文件条目摘要均一致。原 build、package、inspect 回执分别为 `0/reaped/150.27404574999673s`、`0/reaped/0.1951076660043327s`、`0/reaped/0.17035141700034728s`，与文档的三位小数一致。inspect 原日志含 minos 15.0 和结构检查结果，声明 GUI 验收独立。

app 52,882,144 字节／`be1029bda1fe6afc8882d11cbf9a0be789ae32faa587028c3e7fccf2d77f494a`；MCP 2,904,560 字节／`5166352519c48c15f2d02db8986c4d9301ccd8e0d055c736cf9471bd88ce584b`。这里核对的是归档摘要相互一致，没有重新读取或重建被排除的二进制。锁屏错误／GUI 操作 0／截图 0、未启动／安装／签名／公证均保留；完整桌面矩阵和英文工具栏 P2 没有关闭。

**链接和目录摘要**

七份范围内 Markdown 共 268 个本地链接，其中 17 个新增或改动链接，路径和本地 Markdown anchor 全部可解析，坏链 0。CAPABILITIES.md 内三个历史外部 GitHub 链接未联网访问。新目录链接相对层级正确。

目录摘要算法：目录内文件相对路径排序，拼接 path + NUL + file SHA-256 + LF 后取 SHA-256（不包含目录前缀）。

- delivery：4 文件／21,448 字节，目录摘要 `4b5b21167f1d5d6d2a02e552b37acdd2556610459d76149f0c5fc0710aaf0f66`。
- ci-completion：4 文件／662,293 字节，目录摘要 `122fda34450fa2a8f599ccf0b57bb0c95d68087317e3fb862911a89245f1ac67`。

**实际执行、退出和时间**

两个授权 verifier 都设置 180 秒外层上限并实际等到终态，PYTHONDONTWRITEBYTECODE=1、GIT_OPTIONAL_LOCKS=0。二者在同一只读批次并行，均无 stderr、无 timeout，测试重放 0。

| 命令 | UTC 开始 | UTC 结束 | 实际退出 | 秒 |
| --- | --- | --- | ---: | ---: |
| python3 -B docs/testing/records/2026-11-16-windows-fixture-publication-evidence/delivery/verify.py | 14:18:19.635384 | 14:18:27.035047 | 0 | 7.399527 |
| python3 -B docs/testing/records/2026-11-16-windows-zmodem-test-contract-evidence/ci-completion/verify.py | 14:18:19.635597 | 14:18:27.059982 | 0 | 7.424355 |

本复核共 16 次 exec_command 调用（含本次报告落盘），14 次退出 0、2 次辅助解析退出 1；验证器异步会话另有 1 次 terminal poll。底层精确 Git 对象读取由 verifier／证据检查发起，不作为新的测试数。各检查批次、子命令的实测时间／退出及工具结果标识见 receipt.json 的 command_records 和 materialization。

辅助失败保留：T10 最初用 zmodem:: 前缀误把 53 项当作本文的 local 45 项，触发 AssertionError；T11 诊断把整数字段 zmodem_inventory 当列表切片，触发 TypeError。T12/T13 确定结构，T14 以 zmodem::local:: 修正后，原日志 45 项为 43 ok／2 ignored，全部与封存一致。这两次是复核脚本错误，未修改或污染项目证据，不能当成产品失败。两次工具均显示 wall 0.0000s，脚本未及时输出更高精度计时，回执明确保留该计时限制，不虚构精确秒数。T04 的显示截断也记录并通过后续限定读取补全。

**未验范围和写入约束**

没有运行 Cargo／任何测试套件或已有测试二进制，没有写 target，没有查询 CI／网络，没有提交、推送、清理或变更工程／文档。归档读取未解包。仅新建此报告和同目录 receipt.json。父代理的并行提交不归为本 reviewer 操作。

当前 CI 终态、父新 docs push 的远端读回、正常包二进制现场重哈希、真实 GUI／安装／签名／公证、Windows／Linux 桌面、完整产品与业务验收、历史台账全部能力真实性均未重新验收。旧 25／93 主体只通过授权 verifier 的依赖校验及字节保持检查，不扩大为源码二次评审。

**限定交付建议：可收取本报告并采纳本次文档／归档补充；当前 CI 和 native 的开放边界继续保留。**
