"""Preserve completed delivery/review records before retiring owned copies."""

import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
DEST = ROOT / "docs/testing/records/2026-11-16-windows-fixture-publication-evidence/delivery/followup"
DEST.mkdir()
files = []
for name in (
    "docs-commit-r1.json", "docs-commit-r1.log",
    "docs-push-r1.json", "docs-push-r1.log",
    "docs-delivery-r1.json", "docs-commit-binding-r1.json",
    "docs-index-check-r1.json", "docs-check-r1.json",
    "delivery-evidence-verify-r1.json", "delivery-evidence-verify-r1.log",
):
    files.append((f"delivery/{name}", WORK / name))
for name in ("REPORT.md", "receipt.json"):
    files.append((f"review/{name}", ROOT / "work/windows-fixture-delivery-review-20261116" / name))
for label in ("source-ci-snapshot-r2", "source-ci-snapshot-r3"):
    for extension in ("json", "log"):
        name = f"{label}.{extension}"
        files.append((f"retired-ci-snapshots/{name}", ROOT / "work/windows-zmodem-rename-integration-20261116" / name))
files.append(("tools/seal_followup.py", Path(__file__).resolve()))
plain = io.BytesIO()
entries = []
with tarfile.open(fileobj=plain, mode="w", format=tarfile.USTAR_FORMAT) as archive:
    for name, path in files:
        raw = path.read_bytes()
        member = tarfile.TarInfo(name)
        member.mode = 0o644
        member.size = len(raw)
        archive.addfile(member, io.BytesIO(raw))
        entries.append({
            "path": name, "source_path": str(path.relative_to(ROOT)),
            "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
        })
packed = gzip.compress(plain.getvalue(), mtime=0)
(DEST / "originals.tar.gz").write_bytes(packed)
manifest = {
    "schema": "keelshell.windows-fixture-delivery-followup.v1",
    "engineering_source": "ee3ad7320e90f40c9d777c500543cc6e909d0484",
    "docs_source": "ebefc90e850a4843475da01587b771ab1d244f11",
    "count": len(entries), "archive_bytes": len(packed),
    "archive_sha256": hashlib.sha256(packed).hexdigest(),
    "uncompressed_bytes": sum(row["bytes"] for row in entries),
    "entries": entries,
    "review": {"decision": "APPROVE", "P0": 0, "P1": 0, "P2": 0, "P3": 0},
    "ci_terminal_approved_by_review": False,
    "excluded": ["active CI watcher", "Cargo target", "binaries", "other task resources"],
}
(DEST / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({key: manifest[key] for key in (
    "count", "archive_bytes", "archive_sha256", "uncompressed_bytes",
)}))
