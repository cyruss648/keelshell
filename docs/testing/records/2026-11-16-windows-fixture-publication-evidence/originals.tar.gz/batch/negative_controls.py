"""Require both early-read and swallowed-error controls to fail exact regressions."""

import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
PRELUDE = """
import subprocess, sys, unittest
sys.path.insert(0, 'scripts')
import test_windows_native_crash as current
"""
controls = {
    "early-read": (
        PRELUDE + """
old = {'__name__': 'sealed_958_fixture'}
exec(compile(subprocess.check_output(['git', 'show', '95813a76f0ec9b59fd043cd982e33cdc01dd69f8:scripts/test_windows_native_crash.py']), '<sealed-958-fixture>', 'exec'), old)
current.ready_pids = lambda record, parent, published: old['ready_pids'](record, parent)
suite = unittest.TestSuite([current.FixtureIdentityTests('test_complete_record_is_not_read_before_writer_completion_marker')])
result = unittest.TextTestRunner(verbosity=2).run(suite)
sys.exit(not result.wasSuccessful())
""",
        "PermissionError: [Errno 13] controlled read denial",
    ),
    "swallowed-error": (
        PRELUDE + """
exact = current.ready_pids
def suppressed(record, parent, published):
    try:
        return exact(record, parent, published)
    except PermissionError:
        return None
current.ready_pids = suppressed
suite = unittest.TestSuite([current.FixtureIdentityTests('test_completed_publication_read_errors_still_fail_closed')])
result = unittest.TextTestRunner(verbosity=2).run(suite)
sys.exit(not result.wasSuccessful())
""",
        "AssertionError: PermissionError not raised",
    ),
}
results = []
for label, (code, marker) in controls.items():
    completed = subprocess.run(
        [sys.executable, "-c", code], cwd=ROOT, capture_output=True, text=True, timeout=20,
    )
    text = completed.stdout + completed.stderr
    with (BASE / f"negative-{label}-r1.log").open("x") as output:
        output.write(text)
    assert completed.returncode == 1 and marker in text, (label, completed.returncode, text)
    results.append({"control": label, "exit": completed.returncode, "exact_failure": marker})
with (BASE / "negative-summary-r1.json").open("x") as output:
    json.dump({"controls": results, "engineering_mutations": 0}, output, indent=2)
    output.write("\n")
print(json.dumps({"expected_failures": results, "engineering_mutations": 0}))
