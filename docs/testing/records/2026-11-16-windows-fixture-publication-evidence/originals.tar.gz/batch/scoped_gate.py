"""Validate the Python-only fixture change without repeating unchanged Rust tests."""

from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
for command in (
    [sys.executable, "scripts/check.py", "--policy-only"],
    ["cargo", "fmt", "--all", "--check"],
    ["cargo", "clippy", "--workspace", "--all-targets", "--locked", "--", "-D", "warnings"],
    [sys.executable, "-m", "unittest", "discover", "-s", "scripts", "-p", "test_*.py", "-v"],
    ["git", "diff", "--check"],
):
    print("Running: " + " ".join(command), flush=True)
    subprocess.run(command, cwd=ROOT, check=True)
