独立非作者代码评审与功能复核，2026-11-16，范围仅 Python 测试工装。

**推荐：APPROVE。P0=0、P1=0、P2=0、P3=0。** 可将该冻结候选交父任务继续集中门禁及精确源码 Windows CI；本结论不签署新候选的真实 Windows/native 验收。未发现吞掉读取错误、放宽身份或清理断言、增加重试或延长预算的改动。

评审工作区为 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`，基线 HEAD 实际读回 `95813a76f0ec9b59fd043cd982e33cdc01dd69f8`。已先读 AGENTS.md、`/Users/hdh/.codex/RTK.md`、docs/HANDOFF.md、docs/testing/SHARED_TARGET.md。工作区已有父任务的文档改动；这些文档不在本次代码候选范围，也未由评审者编辑。

冻结核对：719 项工程输入逐项 SHA-256 与工作区相等，零 mismatch；按 `path + NUL + sha256 + LF` 拼接独立重算候选摘要为 `1a516c0280487e62157ad3ee470206ef91c12a08501f12214ef7348c688cfc3a`。再用固定 HEAD 的 Git blob 逐项重算旧摘要，得到 `96753dee615c9cd7711a48ad769ec5b14f49c45c581b0bb67323bb51ba508766`，718 项不变，唯一变化为 `scripts/test_windows_native_crash.py`。生产实现、Rust、清单及 Cargo.lock 均无工程输入变化。

| 绑定对象 | 独立核对结果 |
| --- | --- |
| 测试文件旧 SHA-256 | `77b09044196d604c02b78a8cc068c25f9497949cb318c80ae996f7d548c6744b`；baseline 副本与 HEAD blob 逐字节相等 |
| 测试文件候选 SHA-256 | `909ae16f90086c82a09dda8b366475d885146c3ea849d1900d781d79ca97b232`；工作区与 source-r1 副本逐字节相等 |
| candidate-r1.diff | 与实际 `git diff HEAD -- scripts/test_windows_native_crash.py` 逐字节相等；63 行增加、9 行删除 |
| 作者原始 Windows log | 184360 字节；SHA-256 `2dc66cd5ffca0b6c3a8a9c2fea01adef7e58afbf1d6381022b864176fd949c6b`，与下载回执及 summary 相等 |

核心检查及绝对路径证据如下；以下均为通过项，没有待修复的 P0–P3 finding。

| 检查 | 结论与证据 |
| --- | --- |
| 普通发布／读取竞态 | [ready_pids:470](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_windows_native_crash.py:470) 在 marker 不存在时直接返回，不打开 record。普通 helper 的 pending.write_text 已返回并关闭文件，随后 os.replace 返回，才 touch published，再等待 ACK，见 [helper:579](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_windows_native_crash.py:579)。目录由每次独立 TemporaryDirectory 创建，不继承旧 marker。这排除了本 fixture 自身尚在写入／rename 时发起身份读取的窗口。 |
| 错误及 PID 校验 | [reader:474](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_windows_native_crash.py:474) 仍仅把 FileNotFoundError、JSONDecodeError 当作未就绪；PermissionError 未被捕获。字典字段精确集合、非 bool 的 32 位正整数 PID、实际 parent PID、不同 child PID 均保留。[反例:832](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_windows_native_crash.py:832) 同时检查 marker 前 read_text 未调用和 marker 后可读取；[反例:843](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_windows_native_crash.py:843) 要求 marker 后 PermissionError 上抛。两项独立运行通过。 |
| staged 空／部分发布 | [staged producer:575](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_windows_native_crash.py:575) 分别等待 empty-observed、partial-observed，才执行最终发布。[staged observer:619](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_windows_native_crash.py:619) 的 marker 前直接读 record 是刻意确认空／部分内容的诊断分支，不授予身份或 ACK；read_text 返回、关闭后才 touch 对应 observed marker。partial-observed 已存在且 published 未出现时，后续 tick 直接返回，避免与最终 rename 竞争。真正绑定仍经 ready_pids 的 published 门槛。实际专项得到 `["empty","partial"]`，其后才绑定并 SIGINT；[清理及顺序断言:692](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_windows_native_crash.py:692) 保留。 |
| NativeJobBarrier 生成源码完整性 | [helper generator:1527](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_windows_native_crash.py:1527) 保留 nested Job 建立、成员验证、身份发布、ACK、late CreateProcess 反例和 late 结果发布。新增 published 的定义和引用完整；write_text → os.replace → published.touch → ACK wait 顺序见 [identity publication:1553](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_windows_native_crash.py:1553)。既有真实生成器编译回归 [compile control:1458](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_windows_native_crash.py:1458) 独立运行通过。另从实际生成表达式构造两组含 Windows 反斜线／空格及中文／引号的虚拟路径，各生成完整 49 行源码并仅 compile、检查 AST 与顺序；身份写入／replace／marker 为生成行 32／33／34，ACK wait 为 36，late 结果写入／replace／finished 为 47／48／49。未运行或模拟 Win32。 |
| 两个身份控制器、原始句柄和 ACK | [ordinary observer:625](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_windows_native_crash.py:625) 与 [native observer:1584](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_windows_native_crash.py:1584) 均传入同一个 published；ordinary 返回后复读亦接入。Windows 原始句柄 OpenProcess／Job membership／LIVE 校验及失败关句柄保留于 [NativeTreeHandles:497](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_windows_native_crash.py:497)。ordinary 先 bind、收紧 deadline 后 ACK；native 先 bind、barrier、比较原始 LIVE 状态及捕获成员后 ACK，见 [native barrier:1587](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_windows_native_crash.py:1587)。 |
| 时间与清理契约 | [budget:529](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_windows_native_crash.py:529) 仍为准备 5 秒、执行 0.4 秒；`min(original_end, now + cleanup_reserve + 0.4)` 不续期。准备总 cap、绑定后小于 3 秒（ACK 前即开始计时）、direct_reaped、active=0、pipes_drained、errors 为空及原对象终态断言全部保留。native 总 cap 仍为 8 秒。差异未增加 retry、sleep、grace 或错误兜底；生产 [run_owned:630](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_native_crash.py:630) 没有改动。 |
| Windows exclusive handle 反例 | [exclusive test:852](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_windows_native_crash.py:852) 使用实际 CreateFileW、share mode 0；先要求直接 read_text 产生 PermissionError，再要求 marker 前 ready_pids 不打开记录；finally 关闭原始 handle 后创建 marker 并验证准确 PID。宿主不是 Windows，正确跳过，不能计作已通过。 |

独立测试运行环境为 macOS 27.2.1 arm64、Python 3.15.2。已先用 rg 核实名称：本文件没有 `NativeBarrierControlTests`，实际类名为 `NativeJobBarrierTests`，跨宿主生成器回归在 `NativeBarrierProjectionTests`。仅运行这个文件的 discovery，一次，未运行父任务负责的全 scripts discovery。

实际子命令为 `PYTHONDONTWRITEBYTECODE=1 /opt/homebrew/opt/python@3.15/bin/python3.15 -B -m unittest discover -s scripts -p test_windows_native_crash.py -v`，外层 subprocess.run 的 timeout 为 55 秒，移除 KEEL_CONTROL_EVIDENCE_DIR，避免向作者目录保留测试证据。外层实际退出 0、已 wait；unittest 用时 6.134 秒，含启动外层计时 6.203172 秒。**72 run = 70 passed + 2 skipped，0 failures、0 errors。**

| 实际类名 | Run | Passed | Skipped |
| --- | ---: | ---: | ---: |
| FixtureIdentityTests | 8 | 7 | 1 |
| PreparationTreeTests | 10 | 10 | 0 |
| NativeBarrierProjectionTests | 6 | 6 | 0 |
| NativeJobBarrierTests | 1 | 0 | 1 |
| ParsingTests | 12 | 12 | 0 |
| ProjectionTests | 7 | 7 | 0 |
| JobTerminalModelTests | 16 | 16 | 0 |
| ProcessTests | 12 | 12 | 0 |
| 合计 | 72 | 70 | 2 |

实际 exit7 控制得到 observed_exit=7、controller_exit=7、timed_out=true、direct_reaped=true、active_processes=0、pipes_drained=true、errors=[]，总时长 0.493870 秒，身份绑定后观察 0.463003 秒。staged 控制得到 empty／partial 两阶段、controller_exit=130、interrupted=true、同样完整清理，总时长 0.526323 秒。它们是本机 POSIX 真实子进程／进程组结果，状态证据为 owned_group_pids，不能替代 Windows retained native handles 验收。文件中的 API model 用例亦只计为模型反例。

| 其他独立验证命令／过程 | 实际结果 |
| --- | --- |
| `git --no-optional-locks rev-parse HEAD`；只读 status/diff/numstat | 退出 0；固定基线，工程候选仅测试文件 |
| `git --no-optional-locks diff --quiet HEAD -- crates scripts/windows_native_crash.py Cargo.toml Cargo.lock` | 退出 0 |
| `git --no-optional-locks diff --check -- scripts/test_windows_native_crash.py` | 退出 0 |
| `python3 -B` 冻结逐项、摘要及 snapshot/diff 核对 | 退出 0；719 项、0 mismatch、基线及候选副本／diff 相等 |
| `python3 -B` + `git --no-optional-locks cat-file --batch` 固定 HEAD 核对 | 外层及 Git 子命令均退出 0；719 blobs，718 不变、1 测试文件变化 |
| `python3 -B` 实际 helper 表达式构造、compile 和 AST 顺序核对 | 退出 0；2 个完整生成源码，仅静态编译，非 unittest／native 执行 |
| `python3 -B` 原始 Windows log 哈希、库存及执行结果解析 | 退出 0；与现有 JSON 结果逐项相等，详情如下 |
| `python3 -B` 最后读回冻结及作者原件摘要 | 退出 0；输入及所核对原件无漂移 |

补充原件亦已只读核对，未重新执行作者门禁：[scoped-gate-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-fixture-publication-integration-20261116/scoped-gate-r1.json) 记录 controller_exit=0、direct_reaped=true、active_processes=0、pipes_drained=true、errors=[]，15.3685855 秒；[scoped-gate-r1.log:1](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-fixture-publication-integration-20261116/scoped-gate-r1.log:1) 的 x.y 政策、fmt、严格 workspace/all-target Clippy、全 Python discovery 和末尾 diff 检查均完成，[discovery:304](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-fixture-publication-integration-20261116/scoped-gate-r1.log:304) 为 293 run／291 passed／2 skipped、11.881 秒。日志 55460 字节，SHA-256 `03bfafdf60836da1bc3946bd404eb695ce702c03739aca974f1c150c97b1f1c8`。作者 [gate-summary-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-fixture-publication-integration-20261116/gate-summary-r1.json) 与 [scope-binding-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-fixture-publication-integration-20261116/scope-binding-r1.json) 与本次冻结及 718 项未变的独立核对相符；作者未重跑完整 Rust tests，新候选 Windows 执行仍为 0。

作者的 [negative_controls.py](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-fixture-publication-integration-20261116/negative_controls.py) 仅在子解释器内存中分别换回旧 ready_pids、注入吞掉 PermissionError 的变体。两个原始日志分别精确产生 `PermissionError: [Errno 13] controlled read denial`（1 test／1 error）和 `AssertionError: PermissionError not raised`（1 test／1 failure）；negative-summary 记录两子命令各 exit=1，negative-controls 控制器实际 exit=0／reaped／0.2321095 秒，符合预期失败契约。这是对作者原件和脚本逻辑的独立核对，不增加评审者自己的 72 项执行计数，也未改工程。

辅助诊断曾有一次外层退出 1：诊断脚本复用 Path 遍历变量，导致查询不存在的嵌套 baseline 路径；随后改用固定根目录的只读校验，退出 0。另一次外层退出 0 的检索组内，rg 报告猜测的 `scripts/batch_evidence.py` 不存在。两者如实保留为检查过程诊断，不计为项目测试失败；未修改工程来消除诊断。

原始 Windows 证据仅对应旧 HEAD。实际独立核对 [raw log:92](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-fixture-publication-integration-20261116/prior-source-windows-job-r1.log:92) 的 checkout SHA、[filesystem:470](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-fixture-publication-integration-20261116/prior-source-windows-job-r1.log:470) 的 70 个不同执行结果全 ok、[core:637](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-fixture-publication-integration-20261116/prior-source-windows-job-r1.log:637) 的 41 名编译／执行库存相等且 41 ok、[session:896](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-fixture-publication-integration-20261116/prior-source-windows-job-r1.log:896) 的 332 名编译／执行库存逐名相等且 329 ok／3 ignored。Zmodem local 子集为 45 名、43 ok／2 ignored；不能把整个 zmodem 命名空间的 53 名误算为该 local 子集。

该旧 Windows job 随后在 [Python failure:1590](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-fixture-publication-integration-20261116/prior-source-windows-job-r1.log:1590) 的 exit7 fixture 提前失败：[failure observation:1606](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-fixture-publication-integration-20261116/prior-source-windows-job-r1.log:1606) 为 reading_publication／PermissionError／errno=13／winerror=None、ACK=false、observed_exit=None、controller_exit=125、owned_preparation_failed；清理 terminal 本身成功。[discovery summary:1609](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-fixture-publication-integration-20261116/prior-source-windows-job-r1.log:1609) 为 290 run／1 failure／34 skipped，后续完整 Rust gate 未执行。原日志下载 JSON 的退出 0 只表示日志收取成功，不表示 Windows job 通过。

日志中的 published=true 是失败报告时的后续观察，并不能证明失败的 read 发生在 marker 之后；旧 ready_pids 本来不读取 marker。errno=13／winerror=None 和阶段信息也不能单独定位底层失败系统调用或排除其他读取拒绝原因。本修订建立了 fixture 自身发布完成在先、身份读取在后的因果约束；marker 后仍遇到拒绝时继续失败，未将未知原因伪装为已恢复。

本评审真实 Windows 执行 0、Win32 模拟验收 0、Cargo／target 写入 0、Rust 测试 0、CI 查询／等待／取消／重跑 0。未执行格式、Clippy、版本政策或其他父任务门禁；未提交、push、清理、创建 worktree/chat，未编辑工程、docs 或作者原件。仅创建本目录 REPORT.md 与 receipt.json；测试运行允许的隔离临时 fixture 随测试自身生命周期结束。新候选的 Windows exclusive handle、新 marker 的 Windows Job barrier、Windows staged／exit7 结果以及精确源码后续 CI 均仍待实际执行。
