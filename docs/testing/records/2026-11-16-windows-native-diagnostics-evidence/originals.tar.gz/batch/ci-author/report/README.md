# Windows native preflight CI 候选 — 2026-11-16

结论：候选可供父任务导入。唯一候选正式路径为 `.github/workflows/ci.yml`；本次仅创建本目录下的 originals、candidate、report 文件，未应用补丁。
这是 Windows 原生文件后端诊断与 CI 排序优化，不是 Windows 修复，也不是原生验收。

## 精确基线

- HEAD：`64ce892428ad67ea70c1377c21f6d361db36497d`。
- 实际本地分支：`feature/editor-unicode-codec-20261114`。独立远端分支已推送是任务提供的信息，本任务未联网复核。
- workflow Git blob：`b81facbba539f3dadece8a900823fe331272b6db`。
- workflow 原件：`originals/.github/workflows/ci.yml`，1796 bytes，SHA-256 `9a1093af5660890adb1eb5619d928205fa4207bf082777f88b05704a02f9dfb1`，与该 HEAD 中的原件逐字节相等。
- 候选：`candidate/.github/workflows/ci.yml`，2101 bytes，SHA-256 `02f483acb5b0d4ce02c44971d98e17e51e8d2da018d8db9672a4ea5516bc87db`。
- setup-build 仅只读核对，SHA-256 `fe9ee75aedf43f6679253202b43d608b502c1f1698518f2200ee42c4d5c92a95`；没有创建其候选。
- 详细元数据见 `originals/baseline.json`。

## 变更与失败语义

在现有 packaging 测试之后、完整 Rust quality gate 之前，加一个仅 `runner.os == 'Windows'` 执行的普通顺序步骤，命令精确为：

```text
cargo test --locked -p keelshell-platform --lib -- --test-threads=1
```

预检使用现有 native job、setup-build、runner 工具链、cache、工作目录及 Cargo target；不新建 job、action、依赖或缓存，不指定新 target，也不扩大现有 90 分钟 job timeout。
预检在真实 Windows runner 上执行现有 platform 库测试，包括 Windows 安全、枚举和发布测试；本任务只检查其源码接入，未执行 Windows 测试，未核对实际编译清单。

预检的 step id 为 `windows_native_preflight`。为严格满足“预检失败也不跳过原完整门禁”，原 Rust gate 只增加如下条件，原命令 `python scripts/check.py` 保持：

```yaml
if: ${{ !cancelled() && (success() || steps.windows_native_preflight.outcome == 'failure') }}
```

- Windows 预检成功：按原顺序执行完整门禁。
- Windows 预检失败：保留该步骤失败，随后仍串行执行完整门禁；无 `continue-on-error`，后续通过也不能使 job 变绿。
- macOS/Linux：跳过该 Windows 步骤，完整门禁保持原有成功前置语义。
- 原前序步骤失败：预检默认跳过，完整门禁仍不运行；取消 job 时也不强行继续。
- 后续 OpenSSH 和归档步骤的条件、顺序与内容均保持原样。完整门禁自身仍遵循 `scripts/check.py` 遇首个失败即退出的原有行为。

## 静态核对

`report/static-checks.json` 保存 15 项通过的检查：本机已有 Ruby Psych 解析 YAML；剔除新增步骤与 gate 条件后，workflow 数据结构与基线完整相等；额外核对命令、Windows 条件、顺序、矩阵、timeout、action 版本以及正式文件字节未变。

只读补丁检查退出 0：

```text
git apply --check --whitespace=error-all work/windows-native-preflight-ci-20261116/report/windows-native-preflight.patch
```

已静态检索 `scripts/test_*.py` 与 `packaging/test_*.py` 共 13 份测试源码中的 workflow 路径、步骤名称及 setup-build 引用，未发现对本 workflow 步骤的具体约束；仓库源码补充引用检索也未发现此类测试。无需测试改动，未扩大写集。未运行这些测试；未安装 YAML 解析依赖，未运行 actionlint。

## 可导入补丁

`report/windows-native-preflight.patch` 是以仓库根为基准的标准 unified diff，只包含 `.github/workflows/ci.yml`。父任务确认基线后可正常导入；本任务只执行 `git apply --check`，没有 apply、stage、commit、push、fetch 或其他 Git 写操作。

## 未运行与归属边界

已阅读 RTK、AGENTS、当前 HANDOFF 和 SHARED_TARGET。HANDOFF 的 run `43806549649` 状态早于本次任务说明；以任务提供的 completed/failure、macOS/Ubuntu success、Windows app 1320/8/2 与八项 io/suffix123 为背景，不将旧进行中快照当当前状态。本任务未联网读取或触发 CI。

未运行 Cargo、clean、rustfmt、完整 gate 或任何本机/Windows 原生测试；未构建或修改共享 target、修改正式文件或 Git 状态；未创建 chat、worktree 或其他 agent。Windows typed 底层阶段诊断由父任务负责，本候选不包含或代签其实现，也不改任何 app 断言。下一轮精确 Windows CI 仍待父任务集成后真实运行。
