# 父整合修订 r2

保留原作者 r1 候选与说明，不改写其检查。最终 workflow 只增加 Windows-only 的串行 platform lib 预检，删除 r1 新增的 step id 和强制继续条件。

预检失败时按现有 GitHub 顺序步骤的失败语义停止 job，保留失败和未运行范围；完整 Rust quality gate 定义和命令保留，预检成功后照常执行。macOS/Linux 保持原成功前置。没有 continue-on-error、重试、放宽断言、扩时或把未运行全量门禁签成成功。

理由：在已确认的 Windows 后端问题上，先用较小 platform 构建取得真实固定阶段/原始错误。失败后继续编译并执行 GPUI 测试只会推迟该 job 的终态和可下载日志。完整平台验收仍要求预检及后续原门禁都实际通过。
