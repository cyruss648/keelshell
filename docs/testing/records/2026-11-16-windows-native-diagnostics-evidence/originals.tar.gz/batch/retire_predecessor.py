"""Retire only exact owned duplicates after checking their persistent copies."""
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
EVIDENCE = ROOT / "docs/testing/records/2026-11-16-windows-archive-ci-evidence"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def contents(directory):
    assert directory.is_dir() and not directory.is_symlink()
    result = {}
    for path in directory.rglob("*"):
        assert not path.is_symlink(), str(path)
        if path.is_file():
            result[path.relative_to(directory).as_posix()] = path.read_bytes()
    return result


manifest = json.loads((EVIDENCE / "archive-manifest.json").read_text())
packed = (EVIDENCE / manifest["archive"]).read_bytes()
assert digest(packed) == manifest["archive_sha256"]
previous = ROOT / "work/windows-archive-diagnosis-followup-20261116"
originals = contents(previous)
assert len(originals) == manifest["count"]
assert set(originals) == {row["path"] for row in manifest["files"]}
with tarfile.open(fileobj=io.BytesIO(packed), mode="r:gz") as archive:
    for row in manifest["files"]:
        data = originals[row["path"]]
        assert len(data) == row["bytes"] and digest(data) == row["sha256"]
        assert data == archive.extractfile(row["path"]).read()

author = ROOT / "work/windows-native-preflight-ci-20261116"
author_files = contents(author)
author_manifest = json.loads((BASE / "ci-author-copy.json").read_text())
assert set(author_files) == {row["path"] for row in author_manifest["files"]}
for row in author_manifest["files"]:
    data = author_files[row["path"]]
    assert len(data) == row["bytes"] and digest(data) == row["sha256"]
    assert data == (BASE / "ci-author" / row["path"]).read_bytes()

receipt = {"checked_before_delete": True, "directories": []}
for directory, files in ((previous, originals), (author, author_files)):
    shutil.rmtree(directory)
    receipt["directories"].append({
        "path": directory.relative_to(ROOT).as_posix(),
        "files": len(files),
        "bytes": sum(map(len, files.values())),
        "absent_after": not directory.exists(),
    })
with (BASE / "predecessor-cleanup-r1.json").open("x") as output:
    json.dump(receipt, output, indent=2)
    output.write("\n")
print(json.dumps(receipt))
