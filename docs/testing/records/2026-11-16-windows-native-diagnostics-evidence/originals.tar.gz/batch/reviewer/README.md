**Windows native 文件后端诊断及 CI r2 独立只读复核 — 2026-11-16**

结论：**源码与 CI 配置复核 APPROVE；P0=0、P1=0、P2=0、P3=0，未发现必须修复项。** 建议接纳这四个工程文件组成的诊断候选。实际合并仍由父任务依据同一冻结输入的最终门禁回执决定；本报告不代签父唯一 `full-gate-r1`，也不签 Windows 修复或原生验收。

本 reviewer 未参与候选实现，独立完整读取四个工程文件及基线差异。已读取 RTK、适用 AGENTS、HANDOFF、SHARED_TARGET，并应用 `rust-best-practices` 的所有权、错误处理、测试、文档、性能及指针相关指导。用户当前只读要求优先：所有写入限于本 reviewer 目录；Cargo、clean、rustfmt、测试二进制、UI、Git 写操作、新 agent/chat/worktree 均为 0。没有读取、运行或改动共享 target。

**身份与冻结**

- checkout：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`。
- 固定基线 HEAD：`64ce892428ad67ea70c1377c21f6d361db36497d`。
- 开始及结束核对：719 项工程输入逐项一致，mismatch=0，aggregate SHA-256 均为 `774b46416b9c1ef424d89d7d3cb49799563d1c00237d1e52bcd4598677dd8f29`。算法与父 freeze 相同：Git 可见、排除 `docs/` 的普通文件，按路径排序，以 `path + NUL + sha256 + LF` 聚合。
- 结论绑定上述 HEAD 加下表未提交候选字节，不将 HEAD 本身称为包含候选的提交。父并行文档归档不扩大工程复核范围。

| 工程文件 | 当前完整 SHA-256 |
| --- | --- |
| `.github/workflows/ci.yml` | `4ea05107549aa3333c5cb6c1c9846c0e6b46131605c8d4e42f8d236d54dbfc32` |
| `crates/keelshell-platform/src/lib.rs` | `8cb4d4b72d6bc251bd38be1dbae4475951dc2b068cf0195c9e1db4caa5384c7b` |
| `crates/keelshell-platform/src/native_diagnostics.rs`（新增） | `f9a1066dec7ce6b7125809048d1bf56c670b67d947b8ea86371f4fea9c24c8e9` |
| `crates/keelshell-platform/src/windows/native.rs` | `1e439a8de27af7f8a46ea1d3fdcc454c7752cd7f50328b52f8532d7c519bd7d3` |

**错误对象、来源与输出**

1. [native_diagnostics.rs:42](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/native_diagnostics.rs:42) 的 `observe` 接收拥有的 `io::Error`，在末尾直接返回该变量。没有重新构造、包装、字符串化、取出或替换 payload；外层 `map_err` 同样只移动原错误。因此原 kind、raw OS code、自定义 payload 及其既有来源关系不因本候选被擦除。这里的“原对象”指返回同一个拥有的错误值，不要求 Rust 移动前后的栈地址相同。
2. [native_diagnostics.rs:43](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/native_diagnostics.rs:43) 的唯一新增打印受 `cfg(test)` 限制；`describe` 和固定标签格式化也仅在 test 配置存在。[lib.rs:15](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/lib.rs:15) 允许 Windows 正常库构建包含透传函数，但非 test 分支只忽略阶段参数并返回错误。正常 app/session 对 platform 的依赖构建不会因此输出新日志；app 自身处于单元测试配置也不会把依赖库自动变成 platform 单元测试目标。
3. [native_diagnostics.rs:51](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/native_diagnostics.rs:51) 仅读取 `error.kind()` 和 `error.raw_os_error()`，格式化固定 enum 标签及数字 NTSTATUS。没有格式化 `io::Error` 或 payload 的 Display/Debug，没有遍历 `Error::source`，也没有读路径、SID、安全观察字节、peer 文本或凭据。`kind={:?}` 格式化的是标准 `ErrorKind`。
4. [native_diagnostics.rs:90](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/native_diagnostics.rs:90) 的首项测试以 Display/Debug 均 panic 的 payload 检查格式化边界，并检查返回错误仍有同种自定义 payload；第二项检查 raw code 与原 kind 保留。`4321` 和 `0xe1234567` 是 synthetic 输入，不能用于解释真实 Windows 代码、NTSTATUS 或本轮根因。源码没有访问 source；现有测试并非对所有任意自定义错误行为的穷尽证明。

**NTSTATUS、GetLastError 与 FFI**

| 调用位置（绝对路径与行号） | 触发与审查结果 |
| --- | --- |
| [native.rs:172](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:172)、[206](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:206)、[311](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:311)、[400](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:400) | 各自原失败分支直接传入该次 `NtCreateFile`、`NtQueryVolumeInformationFile`、`NtQueryDirectoryFile`、`NtSetInformationFile(FileRenameInformation)` 的返回 status。没有从显示后缀、GetLastError 或另一调用推测 NTSTATUS。原成功/失败判定保持。 |
| [native.rs:407](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:407) | `RtlNtStatusToDosError(status)` 及 `from_raw_os_error(code as i32)` 与基线相同。`Some(status as u32)` 保留返回状态的 32 位位模式供旁路日志使用。返回的 Error 仍是原来的 DOS/Win32 code 表示；没有声称把 NTSTATUS 加进其 payload/source，也没有自创映射。 |
| [native.rs:224](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:224)、[337](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:337) | `GetFileInformationByHandleEx` 或 `ReOpenFile` 返回失败后，先在 `observe` 的实参中求值 `last_os_error()`。捕获前只有原有标量失败判断和 enum 值，没有新增日志、错误文本格式化或 Win32 调用。记录发生在 typed 错误捕获之后。三个信息 class、输出结构与阶段标签一一对应。 |
| [native.rs:239](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:239) | `check-disk-file` 表示原有磁盘文件类型约束失败，继续返回原 InvalidData；未伪称 GetFileType 的原生错误码，也未把缺少 raw code 改成猜测值。 |
| [native.rs:276](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:276)、[284](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:284) | `observe-security`、`open-directory-cursor` 是聚合阶段，准确对应安全观察和独立枚举 cursor 打开。前者并不声称精确到某个安全 API。嵌套失败可能先打印实际 NT/查询阶段、再打印外层阶段；外层 `nt_status=None` 不否定前一条记录，也不是第二个独立故障。 |

独立静态比较确认 native.rs **13 个 `unsafe` 区段与基线逐字节一致**，包括所有 FFI 参数和 owned handle 的接管。新代码未调整同步选项、访问权、share mask、create disposition、reparse 防护、安全描述符、对象枚举及 no-replace 行为。

具体生命周期保持：`open` 的 UTF-16、OBJECT_ATTRIBUTES、IOSB 与借用的 PrivateSecurity 覆盖原同步调用；volume query、三个 metadata query 的输出缓冲及借用 File 保持原作用域；枚举仍使用独立拥有的同步 cursor、对齐的 64 KiB 存储及已检查长度；rename 仍保留 source/parent、对齐的完整变长 buffer 和 IOSB 到原调用结束。未新增转移所有权、关闭句柄、异步等待、重试、删除 staging 或释放后访问。此处是对变化及不变量的源码判断，不是重新认证底层 Windows ABI 的运行结果。

**父 r2 CI：失败即停止，原完整 gate 定义保留**

[ci.yml:32](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/.github/workflows/ci.yml:32) 只插入三行：固定 `runner.os == 'Windows'` 条件，以及 `cargo test --locked -p keelshell-platform --lib -- --test-threads=1`。无 step id、强制继续条件、continue-on-error、重试、扩时、新 job、替代 target 或测试过滤。移除这三行后，整个 workflow 与基线逐字节相等，解析后的完整结构也相等。

下表是依据 GitHub 默认 `success()`、step 失败及矩阵语义对配置的静态推导，本 reviewer 执行 CI 次数为 0：

| 前提 | platform 预检 | 原 Rust quality gate | job / 其他平台影响 |
| --- | --- | --- | --- |
| Windows 前序成功，预检失败 | 实际失败 | **NOT_RUN / skipped** | 当前 job 保留 failure；后续未运行不计通过。 |
| Windows 前序成功，预检成功 | 实际成功 | 按原命令照常执行 | gate 若失败，job 仍失败；预检成功不替代 gate 成功。 |
| macOS/Linux 前序成功 | OS 条件为假，skipped | 按原成功前置照常执行 | 跳过 Windows 专属步骤不会新增其他平台的跳过条件。 |
| 任一平台前序失败或 job 取消 | 默认成功前置不满足或被取消 | 保持原有未运行界限 | 原失败/取消不会因本插入变绿。 |

[ci.yml:19](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/.github/workflows/ci.yml:19) 的矩阵 `fail-fast: false`、三项固定 runner、90 分钟 timeout 和现有并发取消配置均保留。因此单个 Windows job 的失败不通过矩阵 fail-fast 取消其他平台；既有新 push 并发取消行为不变。后续 OpenSSH 条件与 artifact 的 `always()` 也完全保留，不会把之前失败改为成功。

[ci.yml:35](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/.github/workflows/ci.yml:35) 仍只有原 `python scripts/check.py`，没有新增 if。[scripts/check.py:58](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/check.py:58) 与 HEAD 逐字节相等：依赖 x.y/无 Git policy、Python、fmt、严格 workspace all-targets Clippy、完整 workspace tests 和三组 controller 仍按原顺序定义，遇首个失败退出 1。预检失败后提前结束 job 是用户已接受的父 r2 调整，不代表删除这些定义或通过它们。

`ci-author/report/` 的 r1 原报告与检查未被 reviewer 修改。r1 关于“预检失败后仍运行 gate”的结论只适用于其原候选；当前结论来自对实际 r2 字节的独立检查以及父 `ci-parent-adjustment-r2.md`，未把 r1 的 15 项检查移签到 r2。

**真正执行数与已完成证据**

| 项目 | 本 reviewer 实际执行 / 核验 |
| --- | --- |
| Ruby/Psych YAML 与字节/结构校验 | 1 段静态校验，10/10 checks；无 GitHub workflow 执行、无 actionlint。 |
| Python 源码静态比较 | 1 段静态校验，12/12 checks；含 13 个 unsafe 区段比较。不是 Rust 编译或行为测试。 |
| 工程冻结 | 起止各 719 项逐项核验，均 0 mismatch。 |
| Rust、工程 Python 单元/集成测试、测试二进制、UI | **0**；无本 reviewer passed/failed/ignored 测试计数可签。 |
| Cargo / clean / rustfmt / 构建 / Git 写操作 / target 读取或写入 | **全部 0**。 |
| 父 host focused 原件 | 读取 `native-diagnostics-focused-r1.json/.log`，log 字节数及 SHA-256 匹配；原件报告 **2 passed / 0 failed / 0 ignored / 16 filtered out**，两个新测试名均出现。非本 reviewer 重跑。 |
| 父 Windows cross-Clippy 原件 | 读取 `windows-cross-clippy-r1.json/.log`，log 字节数及 SHA-256 匹配；`--all-targets --target x86_64-pc-windows-msvc -- -D warnings`，observed/controller exit 均 0。这是 cross 静态编译检查，**不是 Windows 执行**。 |
| 上述两份父命令终态 | 均 direct_reaped=true、active_processes=0、pipes_drained=true、无超时/中断/错误。未独立检查 target 中的 dep-info 或重放编译清单。 |
| 父唯一 `full-gate-r1` | **EXCLUDED / UNVERIFIED**：未打开其日志或终态文件，未引用或签署未来结果。父另行收取并绑定同一冻结。 |
| 新精确 Windows runner、原八项 app 回归、Windows GUI/native | **0 / 未验证**。 |

父 focused log SHA-256：`6140045f3ab9ea31b2ae0833718bca80ed46f34eb9498dee4041060835624459`；父 cross-Clippy log SHA-256：`4c5950a08f2fdce8e9a6a428fa5c5037a89da3ba34aaedc6dc4f3829c8792b4b`。完整原件路径、JSON 摘要、命令和回执字段见 `parent-completed-evidence.json`。

**限制与接续判断**

本候选不修文件行为。工程写集不含 app 测试、session、security、manifest、lock 或 gate 脚本；原八项 app 测试正文未因本候选调整。Windows platform 单元测试目标可走现有 `Directory::open_chain`、枚举、创建与发布路径，但实际 runner 上是否复现共同前置失败、打印何种真实阶段/原始数字，必须由后续运行给出。路径解析、部分 policy/安全构造、源文件读取等并非所有 I/O 失败都新增阶段；预检通过也不能反推原八项 app 测试或产品已修复。

历史 `76b8253acd9bfa62180563f482e851064bc1ea34` 的 `43806549649 / attempt 1` completed/failure、macOS/Ubuntu success、Windows app `1320/8/2` 与显示后缀 123，采用当前任务及已归档 `diagnosis.md` 的事实边界；本 reviewer 没有联网重取该 run，也没有重新审计父新增整包归档。`123` 不能据此命名某个 syscall、typed OS error 或 NTSTATUS。**根因继续 UNKNOWN。**

语义核对参考已读取的官方文档：GitHub Docs《Evaluate expressions in workflows and actions》的 Status check functions、《Workflow syntax》的默认 shell/exit status、continue-on-error 与 strategy.fail-fast；Microsoft Learn 的 GetLastError、GetFileInformationByHandleEx、ReOpenFile、RtlNtStatusToDosError；Rust std::io::Error 文档。它们仅支持接口/CI 规则判断，不构成本 checkout 的运行验收。

合并建议维持 **APPROVE（源码与 r2 CI 配置）**。父完整门禁的失败、未运行、成功应分别按原件登记，只有实际成功且输入一致才能另行补足工程门禁；后续 Windows 预检失败时记录 preflight=FAIL、fullgate=NOT_RUN。不得以本报告将未执行范围改写为通过，亦不得将诊断交付称为 Windows 修复。

**本 reviewer 交付文件清单**

- `README.md`：本报告。
- `candidate.diff`：固定 HEAD 到四个候选路径的完整文本差异，包含新增文件。
- `inputs-start.json`：起始 HEAD、Git 只读状态、719 项冻结核验及四文件摘要。
- `inputs-end.json`：结束身份、冻结及候选字节一致性。
- `ci-static-checks.json`：实际 r2 的 10 项静态结果。
- `source-static-checks.json`：12 项源码静态结果与 13 个 unsafe 区段数量。
- `parent-completed-evidence.json`：两份已完成父回执及日志摘要核验。
- `SHA256SUMS`：上述七个文件的完整 SHA-256；本清单文件自身摘要由最终回复给出。
