# Current CI parser and evidence scope

The final CI is bound to 95813a76f0ec9b59fd043cd982e33cdc01dd69f8, not the
later ee3ad73 Python fixture revision. macOS and Ubuntu passed full gates and
real OpenSSH; Windows passed all preflights and failed Python discovery before
workspace Rust tests. The original failure remains intact.

The macOS API request was labelled active after the last observed snapshot. Its
response contains the full job through OpenSSH upload and post-job cleanup; final
run metadata confirms success. The label is preserved, not evidence of partial
acceptance.

r2 rejected this macOS log because a Doc-tests stderr header arrived before the
previous ordinary suite's stdout results/summary. No r2 summary was written. r3
keeps the active ordinary run until its summary, and treats rustdoc headers as
metadata instead of slicing stdout at the first header. Rustdoc subruns remain
unassigned to individual crates. Both platforms' 92 ordinary runs and all doc
subruns match declared counts, unique result names, and summary counts.

The app_inventory field in the aggregate means unique executed result names,
checked against the declared running-N count. These CI app logs do not contain
a separate cargo --list. Only the host gate's explicit 1343-name --list and the
Windows preflight's 332-name --list are described as compiled inventories.

All parsers, diagnostics and raw logs are retained; no tests, CI runs or Cargo
cache were replayed or changed to derive these reports.
