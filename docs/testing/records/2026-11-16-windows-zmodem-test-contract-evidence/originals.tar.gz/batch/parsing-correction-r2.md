# CI derived-summary correction (r2)

Original macOS/Ubuntu logs and r1 summaries are preserved byte for byte. The
r1 parser required suite headers at the start of a line. A ZipWriter drop
diagnostic shared a line with the archive_pax header, so r1 attached both suites
to archive.rs, recorded 81 results, and overwrote its 41-case summary with the
PAX 40-case summary. This was a parser error, not stale Cargo output.

r2 accepts inline headers and associates summaries with the active libtest
run until its summary, even if a later stderr header arrives first. It excludes
the two known harness=false process-controller targets and lists doctest
summaries separately (rustdoc can emit several runs for one crate). All 92
ordinary libtest suites per platform now match declared counts, unique result
names, and summary counts. Both archive suites ran 41/0/0; PAX ran 40/0/0.
The new ZIP metadata case is explicitly present and ok on both platforms.

The first r2 draft rejected pending headers for custom controllers/doc-test
sub-runs. No output summary was written; scoping to workspace libtest and
recording those targets separately resolved that diagnostic. No product source,
Cargo artifacts, raw logs, CI runs, or tests were changed or rerun.
