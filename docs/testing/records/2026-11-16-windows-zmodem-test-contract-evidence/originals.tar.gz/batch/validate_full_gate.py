"""Bind the completed whole gate to its inventory and frozen engineering input."""

import hashlib
import json
from pathlib import Path
import re
import subprocess

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
SUMMARY = re.compile(
    r"^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;.*$",
    re.MULTILINE,
)
receipt = json.loads((BASE / "full-gate-r1.json").read_bytes())
raw = (BASE / "full-gate-r1.log").read_bytes()
assert receipt["observed_exit"] == receipt["controller_exit"] == 0
assert receipt["terminal"]["direct_reaped"] and not receipt["timed_out"]
assert receipt["log_bytes"] == len(raw)
assert receipt["log_sha256"] == hashlib.sha256(raw).hexdigest()
text = raw.decode()
workspace = text.split("Running: cargo test --workspace --locked -- --test-threads=4\n", 1)[1]
workspace = workspace.split("Running: cargo test -p keelshell-ai ", 1)[0]
boundary = workspace.find("Doc-tests ")
assert boundary >= 0
ordinary = SUMMARY.findall(workspace[:boundary])
doctests = SUMMARY.findall(workspace[boundary:])
assert ordinary and doctests and all(row[0] == "ok" and row[2] == "0" for row in ordinary + doctests)
start = re.search(r"Running unittests src/main.rs \([^\n]*keelshell_app[^\n]*\)", workspace)
assert start
app = workspace[start.end():]
end = re.search(r"Running (unittests|tests/)", app)
assert end
app = app[:end.start()]
listed = re.findall(
    r"^(\S+): test$", (BASE / "app-inventory-r1.log").read_text(), re.MULTILINE
)
executed = re.findall(
    r"\btest ([A-Za-z0-9_]+(?:::[A-Za-z0-9_]+)*) \.\.\. (ok|ignored|FAILED)(?:,.*)?$",
    app, re.MULTILINE,
)
assert len(listed) == len(set(listed)) == len(executed) == 1343
assert set(listed) == {name for name, _ in executed}
assert all(outcome != "FAILED" for _, outcome in executed)
freeze = json.loads((BASE / "inputs-freeze-r1.json").read_bytes())
names = sorted({
    name.decode()
    for name in subprocess.check_output(
        ["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"], cwd=ROOT
    ).split(b"\0")
    if name and not name.startswith(b"docs/")
})
assert names == [row["path"] for row in freeze["inputs"]]
assert all(
    hashlib.sha256((ROOT / row["path"]).read_bytes()).hexdigest() == row["sha256"]
    for row in freeze["inputs"]
)
report = {
    "engineering_sha256": freeze["aggregate_sha256"],
    "engineering_inputs": len(names),
    "source_mismatches": [],
    "ordinary_summaries": [list(row) for row in ordinary],
    "ordinary_counts": {
        label: sum(int(row[index]) for row in ordinary)
        for label, index in (("passed", 1), ("failed", 2), ("ignored", 3))
    },
    "doctest_counts": {
        label: sum(int(row[index]) for row in doctests)
        for label, index in (("passed", 1), ("failed", 2), ("ignored", 3))
    },
    "app_inventory": listed,
    "app_executed": executed,
    "app_inventory_count": len(listed),
    "python_main_summaries": re.findall(r"Ran (\d+) tests? in ([\d.]+)s", text),
    "controllers": [
        marker for marker in ("--readiness-error-tests", "--observer-io-error-tests", "--controller-small-stack")
        if marker in text
    ],
    "windows_candidate_execution": 0,
}
assert len(report["controllers"]) == 3
with (BASE / "full-gate-summary-r1.json").open("x") as output:
    json.dump(report, output, indent=2)
    output.write("\n")
print(json.dumps({
    key: value for key, value in report.items()
    if key not in ("ordinary_summaries", "app_inventory", "app_executed")
}))
