# Windows Zmodem 目录改名窄测试候选

结论：仅建议调整两个测试正文；第三个场景保持逐字节不变。候选未集成，
没有编译或真实 Windows 执行，没有取得新的 CI 失败或通过证据。

基线为精确提交 `f094de6ad2789d168f5a24bacb316c98b83608ac`。
测试及旁读实现均由 `git show <SHA>:<path>` 提取，未以当前工作区文件代替基线。
本报告行号均指 `baseline/` 中的原始文件。

已读取当前 `AGENTS.md`、`/Users/hdh/.codex/RTK.md`、`docs/HANDOFF.md`，
以及 `rust-best-practices` 的 SKILL.md 和 Chapter 5 Automated Testing。
本次最新用户限制覆盖历史交付步骤：只在本候选目录写入，不运行 Cargo、
Clippy、原生检查或工作区 fmt，不提交、推送或清理其他资源。

## 逐场景判断

| 基线位置（tests.rs） | 实际持有关系 | 判断及候选 |
| --- | --- | --- |
| 249–264，rename 257 | `plan.sources[0]` 同时持有 `reviewed/source.txt` 的 `descriptor: File` 和完整 `Parents.directories`；调用 rename 时尚未消费 plan，没有 drop 后代源文件。 | 根据用户已确认的 Windows open-descendant 规则，`reviewed` 外层改名不能作为成功前置条件。改为明确要求 `PermissionDenied` **且** `raw_os_error() == Some(5)`，核对 retained 不存在、全部祖先 stamps 相等、命名源文件 ID 相等、confirm 和路径 readback 均为原字节。 |
| 452–483，rename 464、466 | upload plan 持有 `outer/leaf/source.bin`；plan 和 destination 均持有 `leaf` 目录，且两套链都包含 outer。没有提前释放这些对象。 | 第一次 outer rename 就有 open 后代；原第二次移动 leaf 也仍有 open 源文件，不能机械地只处理第一行后保留第二次假定成功。候选只尝试第一次攻击并要求明确 raw 5；保持原源 ID、最后一级目录 stamp、字节 readback 和 leaf 项数断言，新增两套完整祖先 stamps 比较、destination revalidate、target/staging 不存在及 confirm 原字节。 |
| 604–621，rename 611 | `Destination::prepare` 保留到 `reviewed` 为止的祖先链；target/staging 均尚未创建，目录为空。这里只有被改名目录自身和它的祖先句柄，没有打开的后代。prepare 内部临时重开对象已在返回时释放。 | open-descendant 禁止条件不成立，不能仅因目录自身有 capability 就断定不可改名。原 rename、替换目录后 `SourceChanged`、mutated=false、两树为空断言全部逐字节保留。真实 Windows 能否完整通过仍待执行。 |

持有关系旁读证据（`baseline/.../local_windows.rs`）：

- 29–35：Source 保存 Parents 与实际源文件 descriptor。
- 46–52、122–135：Parents 保存整条目录链及 stamps。
- 156–161、205–222：read_source 打开源文件，返回时将文件和祖先链交给 Source。
- 227–248：UploadPlan 保存 Sources；260–293：confirm 消费 plan 前逐项重验。
- 309–326：Destination 保存祖先链和两个尚未创建的名称，没有持有目标或 staging 文件。

本次不重复平台生产实现或 CI 根因分析。MS-FSA 行为为用户已实际确认的任务输入，
不是本候选重新执行 Windows 得到的结论。

## 证明边界与最小改动

两处修订证明的是**祖先替换攻击在 rename 阶段被 OS 阻止，原审核对象仍有效**。
它们不再声称走过“祖先已成功替换后由 confirm/publish 拒绝”的路径。
因此两个不可达的 confirm `SourceChanged` 断言改为原字节确认；第二例不可达的
publish `SourceChanged` 调用及其 mutated 变量/断言移除，改为只读重验及实际名称
不存在断言。这里没有执行 publish，不能把其结果签成一次发布拒绝或发布成功。
可行的 replaced-parent 发布拒绝场景（原 611）完整保留。

叶文件替换可以覆盖源身份变化，却不能等价覆盖这两例的祖先替换攻击，尤其不能
保留第二例“源文件及 leaf 身份不变”的意图，因此不将它冒充等价替代。
原 193–207 的同字节叶文件替换、286–303 的路径重绑定、812–836 的释放 staging
后同字节替换等测试均逐字节保留；没有机械替换其 rename。

没有生产代码改动；两处正文中原有源 ID、leaf stamp、readback 字节及 leaf
项数断言保留，并增加完整祖先及明确错误断言。权限/DACL 测试及其他所有用例
逐字节保留。没有 skip、延时、重试、错误泛化或接受任意失败的成功分支。
`.err().ok_or(...)` 使意外 rename 成功立即失败，两个 assert_eq 同时收窄错误。

为了保持原源声明库存，45 个测试名称、顺序、属性（包括原有 2 个 ignore）
均不变。两个历史名称仍含 reject/replaced；正文注释和本报告明确解释其当前
证明为阻止攻击，不将名称当成已经发生替换的证据。未来若重命名，需另行审核
CI 库存映射；本候选没有这样做。

## 静态回执与产物

- `candidate.patch`：只有 `crates/keelshell-session/src/zmodem/local_windows/tests.rs`
  的两个正文变更。
- `baseline/`：精确 SHA 的测试原件与旁读实现原件。
- `candidate/`：单个完整测试源码候选副本。
- `test-declarations.txt`：45 项源声明名称，保持顺序；不是编译或执行库存。
- `source-receipt.json`：基线 Git blob ID、SHA-256、候选/patch 哈希、
  逐测试正文比较、只读 patch 检查及当前两个工程文件前后哈希。

静态检查结果：45 → 45 名、ignore 2 → 2；仅上述两个正文变化，其余 43 个
测试正文及所有 helper/module prefix 字节相同。611 场景单独核对相同。
当前工程 tests.rs/local_windows.rs 前后 SHA-256 相同。所有写操作仅落在本目录；
未写 Cargo target，也未读取其测试二进制作为库存证据。

只对候选副本执行 `rustfmt --edition 2024 --config skip_children=true <副本>`，
exit 0。`git apply --check --directory=<本目录>/baseline candidate.patch`
只读检查 exit 0，未应用到工程或基线副本。Python 静态断言 exit 0。
rustfmt 和 patch 检查不构成 Rust 类型检查或 Windows 验收。

Cargo、Clippy、工作区 fmt、原生 Windows 执行、提交和推送均为 0 次。
没有查询、等待、取消或重跑父的 CI。父提供的“完整 Windows session 尚未运行”
边界保持；本候选不新增实际 Windows 失败计数。

## 留给父的后续

只有父收取精确 CI 的真实失败证据后，才评估是否集成，并安排独立非作者评审。
若采用，真实 Windows 必须验证两处精确错误（kind 和 raw 5）、未变祖先/源身份、
只读重验和完整 readback；尤其要确认未改的 611 场景可成功进行外层改名并按原断言
拒绝替换后的发布。还需覆盖原叶文件替换、DACL、staging、安全断言和完整 session，
并遵守工程共享 target 合同与编译库存核对。此处未取得任何上述执行结果。
