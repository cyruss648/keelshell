"""Exercise the DOS-header regression, then restore exact frozen production bytes."""

import hashlib
import json
from pathlib import Path
import signal
import subprocess

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
SOURCE = ROOT / "crates/keelshell-core/src/archive.rs"
FROZEN = (BASE / "source-r2/crates/keelshell-core/src/archive.rs").read_bytes()
UNIX = b"let options = SimpleFileOptions::default().system(System::Unix);"
DOS = b"let options = SimpleFileOptions::default().system(System::Dos);"
assert FROZEN.count(UNIX) == 1 and SOURCE.read_bytes() == FROZEN
mutant = FROZEN.replace(UNIX, DOS)
outcomes = []


def interrupted(signum, _frame):
    raise InterruptedError(f"negative control interrupted by signal {signum}")


signal.signal(signal.SIGTERM, interrupted)
signal.signal(signal.SIGINT, interrupted)
try:
    SOURCE.write_bytes(mutant)
    for name in (
        "zip_records_private_file_and_directory_modes_in_unix_metadata",
        "reencoding_discards_dangerous_incoming_permissions_and_ownership",
    ):
        command = [
            "cargo", "test", "--locked", "-p", "keelshell-core", "--test", "archive",
            name, "--", "--exact",
        ]
        print(json.dumps({"negative_control": name, "command": command}), flush=True)
        result = subprocess.run(command, cwd=ROOT, timeout=90, check=False)
        outcomes.append({"name": name, "exit": result.returncode})
finally:
    assert SOURCE.read_bytes() == mutant, "unexpected concurrent source change; do not overwrite"
    SOURCE.write_bytes(FROZEN)
    assert SOURCE.read_bytes() == FROZEN
    print(json.dumps({
        "production_restored": True,
        "production_sha256": hashlib.sha256(FROZEN).hexdigest(),
        "negative_control_outcomes": outcomes,
    }), flush=True)

assert len(outcomes) == 2 and all(row["exit"] == 101 for row in outcomes)
