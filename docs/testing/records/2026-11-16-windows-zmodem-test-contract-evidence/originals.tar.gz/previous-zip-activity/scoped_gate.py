"""Run the affected suites serially in the current checkout's Cargo slot."""

import subprocess
import sys

commands = [
    ["cargo", "fmt", "--all", "--check"],
    [sys.executable, "scripts/check.py", "--policy-only"],
    ["cargo", "clippy", "--workspace", "--all-targets", "--locked", "--", "-D", "warnings"],
]
for package, selection in (
    ("keelshell-core", ["--test", "archive"]),
    ("keelshell-session", ["--lib"]),
    ("keelshell-app", ["files::transfer_tests::archive_tests::"]),
):
    test = ["cargo", "test", "--locked", "-p", package, *selection]
    threads = "1" if package == "keelshell-app" else "4"
    commands.extend([test + ["--", "--list"], test + ["--", f"--test-threads={threads}"]])

for command in commands:
    print("Running: " + " ".join(command), flush=True)
    subprocess.run(command, check=True)
