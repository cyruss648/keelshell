"""Summarize downloaded job logs without replaying tests or changing originals."""

import argparse
import hashlib
import json
from pathlib import Path
import re

ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
STAMP = re.compile(r"^\ufeff?\d{4}-\d{2}-\d{2}T[\d:.]+Z ?")
RESULT = re.compile(
    r"\btest ([A-Za-z0-9_]+(?:::[A-Za-z0-9_]+)*) \.\.\. "
    r"(ok|ignored|FAILED)(?:,.*)?$",
    re.MULTILINE,
)
SUMMARY = re.compile(
    r"^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; "
    r"(\d+) ignored; (\d+) measured; (\d+) filtered out; finished in ([\d.]+)s",
    re.MULTILINE,
)
APP_CASES = (
    "files::transfer_tests::archive_tests::"
    "archive_tar_gz_download_extract_reviews_empty_folders_and_publishes_new_tree",
    "files::transfer_tests::explicit_download_continuation_preserves_partial_bytes_until_confirmation",
    "files::transfer_tests::fixture_isolation_tests::"
    "held_existing_local_resume_excludes_other_fixture_sync_without_mutation",
    "files::transfer_tests::fixture_isolation_tests::"
    "retained_window_keeps_admission_after_normal_harness_drop",
)


def normalize(data):
    return "\n".join(
        STAMP.sub("", ANSI.sub("", line)).rstrip("\r")
        for line in data.decode("utf-8-sig").splitlines()
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("log", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--windows-inventory", type=Path)
    options = parser.parse_args()
    raw = options.log.read_bytes()
    text = normalize(raw)
    gate_marker = "##[group]Run python scripts/check.py"
    gate_offset = text.find(gate_marker)
    next_step = text.find("\n##[group]Run ", gate_offset + len(gate_marker))
    gate = text[gate_offset:next_step if next_step >= 0 else None] if gate_offset >= 0 else ""
    suites = []
    current = None
    for line in gate.splitlines():
        if re.match(r"^\s*(Running (unittests|tests[\\/])|Doc-tests )", line):
            current = {"suite": line.strip(), "results": []}
            suites.append(current)
        result = RESULT.search(line)
        if result and current is not None:
            current["results"].append(list(result.groups()))
        summary = SUMMARY.match(line)
        if summary and current is not None:
            state, passed, failed, ignored, measured, filtered, seconds = summary.groups()
            current["summary"] = {
                "state": state,
                "passed": int(passed),
                "failed": int(failed),
                "ignored": int(ignored),
                "measured": int(measured),
                "filtered": int(filtered),
                "seconds": float(seconds),
            }
    executed = RESULT.findall(gate)
    observed = {}
    for name, outcome in executed:
        observed.setdefault(name, []).append(outcome)
    report = {
        "log": options.log.name,
        "raw_bytes": len(raw),
        "raw_sha256": hashlib.sha256(raw).hexdigest(),
        "gate_command_present": gate_offset >= 0,
        "suites": suites,
        "summaries": [list(row) for row in SUMMARY.findall(gate)],
        "failed_results": [name for name, outcome in executed if outcome == "FAILED"],
        "prior_app_cases": {name: observed.get(name, []) for name in APP_CASES},
        "tests_replayed": 0,
    }
    if options.windows_inventory:
        assert gate_offset >= 0, "full gate has not run"
        preflight = text[:gate_offset]
        listed = re.findall(
            r"^(sftp::archive_transfer::local::tests::\S+): test$", preflight, re.MULTILINE
        )
        results = [
            row for row in RESULT.findall(preflight)
            if row[0].startswith("sftp::archive_transfer::local::tests::")
        ]
        expected = [
            line.removesuffix(": test")
            for line in options.windows_inventory.read_text().splitlines()
        ]
        assert len(listed) == len(set(listed)) == len(expected)
        assert set(expected) == set(listed) == {name for name, _ in results}
        assert len(results) == len(expected)
        report["archive_preflight"] = {
            "compiled": listed,
            "executed": results,
            "counts": {
                outcome: sum(value == outcome for _, value in results)
                for outcome in ("ok", "FAILED", "ignored")
            },
            "inventory_mismatches": [],
        }
    with options.output.open("x") as output:
        json.dump(report, output, indent=2)
        output.write("\n")
    print(json.dumps({
        "log": options.log.name,
        "suites": len(suites),
        "failed_results": report["failed_results"],
        "prior_app_cases": report["prior_app_cases"],
        "archive_preflight": report.get("archive_preflight", {}).get("counts"),
    }))


if __name__ == "__main__":
    main()
