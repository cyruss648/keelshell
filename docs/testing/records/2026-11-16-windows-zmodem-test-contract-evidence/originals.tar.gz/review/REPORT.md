# Windows Zmodem 祖先改名测试：独立非作者静态评审

**结论：APPROVE，仅覆盖本次两文件的静态代码／功能复核。P0=0、P1=0、P2=0、P3=0。** 当前两项名称与正文一致，原 Mencius 条件 HOLD 的名称误导 P2 已关闭。允许父任务继续既有集中门禁及后续精确 Windows CI；本意见不签署新候选 Windows 通过、完整三平台门禁、原生桌面或产品完成。

评审日期：2026-11-16（Asia/Shanghai）。评审者未编写或修改候选。依据独立 Git blob、字节比较、原始日志解析及生产调用链复核，不以作者或前次评审摘要代替本次检查。

**约束与精确输入。** 已读 AGENTS.md、/Users/hdh/.codex/RTK.md、docs/HANDOFF.md、docs/testing/SHARED_TARGET.md，以及 rust-best-practices 的第 1、2、4、5、8、9 章。用户本轮的严格只读边界优先，未执行技能中通用的 Clippy／编译建议。HANDOFF 保留旧执行中快照；当前历史 Windows 结果以指定原件为准。

- 工作区：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`。
- 基线工程源码：`01f6f6bd8272303fe049bc7b52976afefdb44c37`；HEAD：`b7d6e92a937b3ad994c13c37e19db0bd0d059c8f`。基线至 HEAD 的 13 个路径全部位于 docs/，工程输入相同。
- 当前 tracked 差异恰为 `crates/keelshell-session/src/zmodem/local_windows/tests.rs` 与 `.github/workflows/ci.yml`。从精确基线 Git tree 批量读出 719 个工程 blob，另 717 项逐字节相同；生产实现改动 0。
- 719 项冻结独立逐文件复算零 mismatch，聚合 SHA-256：`96753dee615c9cd7711a48ad769ec5b14f49c45c581b0bb67323bb51ba508766`。序列化为路径排序后每项 UTF-8 `path + NUL + sha256 + LF`。
- source-r1 两文件与当前字节相同；candidate-r1.diff 与当前只读 Git diff 字节相同。最终意见只绑定此冻结。

| 文件 | 基线 SHA-256 | 候选 SHA-256 |
| --- | --- | --- |
| `crates/keelshell-session/src/zmodem/local_windows/tests.rs` | `125a148b0ea76d8483411c30e9daa08566534c5152f193e39f62ddd2320d48e3` | `487f0b03530c66890d7d679cded3fae4d823472b5b6b1e45e37fd5f5726839cf` |
| `.github/workflows/ci.yml` | `d11a06dfd3862ac8a407b8729310e8399ae68e8b431a5ba28f4579e9bb22e753` | `22b7fc620bbb47592aa04fc57e4f6bbaffd5bffd571d74ddfea030e2c38c723b` |

**两例的名称和安全断言。**

第一例 [tests.rs:249](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/zmodem/local_windows/tests.rs:249) 改为 `zmodem_windows_retained_source_blocks_ancestor_rename_and_preserves_review`。`UploadPlan` 仍持有源文件 descriptor 与完整 Parents 链，rename 发生前没有 drop 或权限改变。rename 意外成功立即令测试返回错误；失败必须同时满足 kind=PermissionDenied 与 raw_os_error=Some(5)。随后要求 retained 名称缺席、重解析的完整祖先 stamps 等于原审核、命名源文件 ID 等于原 stamp，原 plan.confirm 成功释放相同字节，路径读回相同。它证明阻止本次攻击且原审核仍有效，不再把未发生的替换称为 SourceChanged 拒绝。

第二例 [tests.rs:460](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/zmodem/local_windows/tests.rs:460) 改为 `zmodem_windows_retained_reviews_block_grandparent_rename_and_preserve_namespace`。plan 与 destination 都持有 leaf／祖先链，plan 还持有 leaf 下实际源文件。正文严格要求 outer rename 返回相同 kind/raw 5，retained 缺席；重解析整链分别等于上传与目标审核，命名源 ID、leaf stamp、destination.revalidate 均通过；目标与 staging 仍缺席，confirm/readback 为原字节且 leaf 只有原源文件。原未调用 publish 的新正文不再声称“实际替换后 publish 被拒绝”。此组合用例没有分别证明 plan 与 destination 单独阻止 rename，也没有执行一次 publish；准确名称和本报告保留这一边界。

两正文与准备作者原件的函数 body 逐字节相同；与原件的差异只有两个名称及第二个函数声明的换行调整。错误断言没有放宽为任意失败，没有成功/失败任选分支、重试、延时、新 ignore 或提前释放句柄。

**第三例的可行条件与原断言。** [tests.rs:616](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/zmodem/local_windows/tests.rs:616) 的完整测试块（含属性及尾部空行）837 字节，SHA-256 `44b6b7d5062b6005a0d44554fae14181018fa39a60aee0af123a0077e988d882`，与精确基线和准备原件逐字节相同。仍要求 `std::fs::rename(...)?` 真正成功、创建新的同名目录，之后 publish 必须 SourceChanged、mutated=false，新旧两树均为空。

Destination::prepare 只保留目录自身及其祖先，并保留两个尚不存在的路径名称，见 [local_windows.rs:309](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/zmodem/local_windows.rs:309)。没有上传源或 staging/target 后代被打开；absence 枚举的临时 cursor 返回后释放。持有空目录自身与在该目录下面持有源文件不同。平台普通观察通过 [native.rs:94](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-platform/src/windows/native.rs:94) 的只读访问和 SHARE_ALL 打开，未为攻击步骤提前改变长期权限。因此该空目录 rename 的成功前置在当前持有关系下可行，而且旧精确 Windows 原日志实际把此测试记为 ok。该证据不延伸到新两例断言。

替换后的新目录具有不同身份；[local_windows.rs:138](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/zmodem/local_windows.rs:138) 比较重解析与原链 stamps，publish 在 [local_windows.rs:366](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/zmodem/local_windows.rs:366) 先重验，随后才进入设置 mutated 的 create_staging（349 行）。第三例保留了可达的“实际替换后软件拒绝且不写入”覆盖；没有把它也改成预期 raw 5。

**生产安全边界。** 全部 719 项与 Git 基线的字节比较确认生产实现、DACL、权限、holds、UNKNOWN／quarantine／mutation 处理均无改动。另静态追踪 Source.descriptor／Parents.directories 的保留、完整源元数据和字节复验（local_windows.rs:260）、先重验再创建、私有 DACL、no-replace 及发布后身份／字节／名称读回（372–458 行）。平台短期目录 DELETE lease（native.rs:359）不等同于这两例的 std::fs::rename 攻击步骤；未释放 Zmodem 审核对象来让攻击成立。未改 43 项仍保留真实叶文件替换、硬链接重绑定、私有 DACL、stage 身份与发布后不确定结果检查。本候选改变的是两项测试的证明目标，不声称与删除的 SourceChanged/publish 断言等价，也不提供“祖先已替换且原 leaf/source 保持时上传拒绝”的新运行覆盖。

**CI guard。** [ci.yml:56](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/.github/workflows/ci.yml:56) 仍先完整列出 Windows session library，list 非零直接退出；63／64 行精确使用两个新全名，65 行保留第三例。模块由 [zmodem.rs:24](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/zmodem.rs:24) 映射为 `zmodem::local::tests`，不是 local_windows。case-sensitive `-cnotcontains "${case}: test"` 缺名即 throw；随后完整执行 `--lib -- --test-threads=1`，传播 LASTEXITCODE。与精确基线相比只有两项字符串替换，三个 archive guard、第三例、执行命令及其余 workflow 字节全部保留。本次没有执行 PowerShell 或 CI。

**历史 Windows 原件独立解析。** 原日志 [prior-source-windows-job-r1.log](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-zmodem-rename-integration-20261116/prior-source-windows-job-r1.log)：172738 字节，SHA-256 `86d46a6833c820a4d438f92bacba2b3fbef8a6700d2daf04bb31d4893e520218`，匹配父任务的抓取 receipt。日志 checkout 读回 `01f6f6bd8272303fe049bc7b52976afefdb44c37`；本地 summary／抓取命令将其绑定 run 43867112056／job 133298403995。本评审没有查询远端状态或 attempt 元数据。

| 历史目标 | 原日志库存与执行逐名核对 | 结果 |
| --- | --- | --- |
| core archive | 41 个唯一名、编译清单／执行名相等 | 41 ok / 0 failed / 0 ignored |
| session library | 332 个唯一名，清单及执行顺序／状态与保存 summary 完全一致 | 327 ok / 2 FAILED / 3 ignored |
| 其中 zmodem::local::tests | 45 个唯一名，与基线 45 声明一一相等 | 41 ok / 2 FAILED / 2 ignored |
| 第三个空父目录替换案例 | 唯一匹配，未被 skip | ok |

两失败全名精确为改名前的两项；原日志 1573–1577 行分别打印 `Error: Os { code: 5, kind: PermissionDenied, message: "Access is denied." }`；1584–1587 行保留 327/2/3 与进程 exit 1。裸错误未提供失败 Rust 行号／系统调用。结合实际持有关系，祖先 rename 前置被拒绝是静态推断，不能声称日志单独精确定位了某次 rename 或某个内核拒绝分支。旧 full gate 在 session 失败后未运行。读取旧原件是历史结果分析，独立 Windows 执行计数仍为 0。

**45 项库存映射。** 下表按源码声明顺序。完整模块前缀均为 `zmodem::local::tests::`；“同名同字节”代表包含属性与完整正文的测试块相同。“旧结果”只来自上面的历史 Windows 源码，不是新候选结果。没有将“45 项静态声明”写成“新编译 45 项／45 通过”。

| # | 基线测试名 | 当前候选映射／字节 | 旧 Windows 结果 |
| --- | --- | --- | --- |
| 1 | `zmodem_upload_local_observation_keeps_complete_binary_and_empty_content` | 同名同字节 | ok |
| 2 | `zmodem_upload_local_observation_rejects_empty_and_excessive_batches_before_io` | 同名同字节 | ok |
| 3 | `zmodem_upload_local_observation_rejects_case_aliases` | 同名同字节 | ok |
| 4 | `zmodem_windows_upload_rejects_expanding_unicode_case_aliases` | 同名同字节 | ok |
| 5 | `zmodem_windows_upload_rejects_hardlink_aliases` | 同名同字节 | ok |
| 6 | `zmodem_upload_local_observation_rejects_size_excess_before_reading_sparse_content` | 同名同字节 | ok |
| 7 | `zmodem_windows_upload_enforces_the_remaining_batch_byte_budget_before_reading` | 同名同字节 | ok |
| 8 | `zmodem_windows_upload_rejects_total_byte_excess_before_reading_the_last_file` | 同名同字节 | ok |
| 9 | `zmodem_windows_upload_rejects_directories_without_reading_them_as_files` | 同名同字节 | ok |
| 10 | `zmodem_upload_local_confirmation_rejects_an_identical_replacement_inode` | 同名同字节 | ok |
| 11 | `zmodem_upload_local_confirmation_rejects_missing_and_changed_sources` | 同名同字节 | ok |
| 12 | `zmodem_windows_confirmation_rejects_metadata_only_changes` | 同名同字节 | ok |
| 13 | `zmodem_upload_local_confirmation_rejects_replaced_ancestor_even_with_same_bytes` | `zmodem_windows_retained_source_blocks_ancestor_rename_and_preserves_review`；正文修订 | FAILED |
| 14 | `zmodem_windows_confirmation_rejects_a_new_hardlink_after_review` | 同名同字节 | ok |
| 15 | `zmodem_windows_confirmation_rejects_reused_path_after_hardlink_rebinding` | 同名同字节 | ok |
| 16 | `zmodem_windows_confirmation_releases_no_batch_when_the_last_source_changed` | 同名同字节 | ok |
| 17 | `zmodem_windows_upload_cancellation_releases_no_review_or_sender_bytes` | 同名同字节 | ok |
| 18 | `zmodem_local_paths_reject_relative_traversal_and_reserved_source_names` | 同名同字节 | ok |
| 19 | `zmodem_review_paths_reject_invisible_or_line_breaking_ancestor_names` | 同名同字节 | ok |
| 20 | `zmodem_windows_paths_reject_unc_and_device_namespaces_before_io` | 同名同字节 | ok |
| 21 | `zmodem_windows_paths_reject_non_unicode_names_before_io` | 同名同字节 | ok |
| 22 | `zmodem_windows_reviews_retain_every_original_ancestor` | 同名同字节 | ok |
| 23 | `zmodem_windows_reviews_reject_replaced_grandparent_with_original_leaf_and_source` | `zmodem_windows_retained_reviews_block_grandparent_rename_and_preserve_namespace`；正文修订 | FAILED |
| 24 | `zmodem_windows_destination_rejects_existing_files_directories_and_unicode_aliases` | 同名同字节 | ok |
| 25 | `zmodem_local_destination_preparation_is_read_only_and_cancellation_creates_nothing` | 同名同字节 | ok |
| 26 | `zmodem_local_publication_preserves_a_target_created_after_preparation` | 同名同字节 | ok |
| 27 | `zmodem_windows_publication_preserves_a_unicode_alias_created_after_review` | 同名同字节 | ok |
| 28 | `zmodem_windows_publication_preserves_a_precreated_staging_name_before_mutation` | 同名同字节 | ok |
| 29 | `zmodem_windows_exclusive_create_marks_mutated_before_a_late_collision` | 同名同字节 | ok |
| 30 | `zmodem_local_publication_rejects_a_replaced_parent_without_writing_either_tree` | 同名同字节 | ok |
| 31 | `zmodem_windows_create_sets_private_dacl_before_any_content_is_written` | 同名同字节 | ok |
| 32 | `zmodem_windows_cancellation_after_create_retains_empty_private_staging_and_mutation` | 同名同字节 | ok |
| 33 | `zmodem_windows_cancellation_after_readback_retains_complete_private_staging` | 同名同字节 | ok |
| 34 | `zmodem_windows_target_race_after_staging_preserves_both_names_for_quarantine` | 同名同字节 | ok |
| 35 | `zmodem_windows_cancellation_after_rename_retains_the_published_target_for_quarantine` | 同名同字节 | ok |
| 36 | `zmodem_windows_final_readback_rejects_a_late_unicode_alias_and_retains_mutation` | 同名同字节 | ok |
| 37 | `zmodem_windows_final_readback_rejects_reappeared_staging_and_retains_both_paths` | 同名同字节 | ok |
| 38 | `zmodem_windows_retained_creation_handle_blocks_stage_replacement_and_other_writers` | 同名同字节 | ok |
| 39 | `zmodem_windows_publication_rejects_an_identical_staging_replacement_identity` | 同名同字节 | ok |
| 40 | `zmodem_windows_no_replace_primitive_preserves_existing_files_and_directories` | 同名同字节 | ok |
| 41 | `zmodem_windows_content_readback_rejects_same_length_corruption_short_and_long_files` | 同名同字节 | ok |
| 42 | `zmodem_windows_publication_verifies_binary_content_identity_private_dacl_and_new_target` | 同名同字节 | ok |
| 43 | `zmodem_windows_publication_verifies_an_empty_file_without_leaving_staging` | 同名同字节 | ok |
| 44 | `zmodem_windows_upload_rejects_real_file_and_ancestor_reparse_points` | 同名同字节 | ignored |
| 45 | `zmodem_windows_destination_preserves_a_dangling_reparse_point` | 同名同字节 | ignored |

两项原 ignored 的名称、原因及测试块均保持：`zmodem_windows_upload_rejects_real_file_and_ancestor_reparse_points` 与 `zmodem_windows_destination_preserves_a_dangling_reparse_point`，原因均为需要 Windows symbolic-link privilege 或 Developer Mode。session 的第 3 个 ignored 位于该 45 项模块之外，未混算。

**旧条件意见的复核。** 从 originals.tar.gz 的 `conditional-zmodem-review/REPORT.md` 与 `static-receipt.json` 在内存读取，没有解包到工程。旧 receipt 的候选 SHA-256 与仍保存的准备原件相同，旧 HOLD 明确含名称误导 P2。当前新名称与两个 CI guard 同步，改名映射及历史／新库存边界在此列明；该 P2 在当前冻结内已解决。当前静态结论来自上面的独立验证，不沿用旧签署，也未将旧 native 边界变为本轮通过。

**实际命令与限制。** 已完成 12 次 `functions.exec_command` 静态调用，11 次 exit 0、1 次 exit 1；包含最终读回。按顶层工具调用计数，内部 Git／rg 不重复计；第 3 次内部 rg 嵌套 AGENTS 搜索 exit 1 表示无匹配，随后显式祖先路径核对确认只有根 AGENTS。第 10 次为 53 项静态断言成立／0 失败，不是 Rust 测试数。命令索引及只读 Git argv 保存在 static-receipt.json。

独立 Rust 编译／Rust 测试（含预构建）／Cargo／fmt／rustfmt／Clippy／scripts/check.py／Windows／macOS／Linux native／GUI／PowerShell 执行均为 0。CI 查询、等待、取消、重跑、提交、推送、清理、worktree/chat 创建均为 0。共享 target 未读取、失效、编译或写入；父任务独占的完整 gate 不由本评审重复执行或代签。旧 macOS／Ubuntu 后续状态未查询。

仅写本目录 REPORT.md 和 static-receipt.json。未编辑工程、target、docs、作者候选或父任务原件。最终读回再次确认 HEAD、719 冻结输入、两份 source-r1 与 26 项稳定证据摘要全部相同；不要求并行父任务的其他文档或活动 gate 日志保持不变。后续精确 Windows CI 仍需实际编译新全名并执行两例的精确错误／身份／原审核断言，以及第三例成功替换后的 SourceChanged/mutated=false；本报告不关闭这些运行验收。

**读回异常原样保留。** 第 11 次静态调用 exit 1：扩展的证据摘要检查发现 `work/windows-zmodem-rename-integration-20261116/validate_full_gate.py` 在并行父任务活动期间发生变化。该未跟踪辅助脚本不属于 719 个冻结工程输入，也不是本次候选；本评审没有写入它。异常发生前 HEAD、719 输入与两份 source-r1 均已匹配，且第 11 次尚未写报告或 receipt。第 12 次保持工程／封存原件检查，单独记账此活动脚本的旧／新摘要后完成读回；没有回滚、清理或修改该脚本。这个静态 exit 1 不属于 Rust／Windows／CI 运行结果，也不掩盖为全命令成功。旧摘要与当前摘要均保留于 receipt，运行中的 full-gate 日志未纳入稳定性要求。
