**KeelShell UI 与 test-only 失败诊断：新非作者严格只读评审**

评审日期：2026-11-16（Asia/Shanghai）。结论：**APPROVE，仅批准冻结 r2 的五文件静态代码范围**。P0=0、P1=0、P2=0、P3=0，无需要作者修订的发现。父的专项及最终完整 gate 尚须串行验证；组合交付验收维持 **HOLD**，Windows 原四项失败保持未证实修复。此报告没有把源码审查或其他回执当成原生验收。

已读取本仓库 AGENTS.md、`/Users/hdh/.codex/RTK.md`、当前 docs/HANDOFF.md、共享 target 合同及两项 Rust 技能（rust-best-practices、rust-engineer）的相关所有权、错误、异步、测试章节。技能的 Cargo/fmt 建议受本次用户只读限制约束。本评审未参与实现，没有修改 Rust、文档源码、Git 状态或共享 target；显式写入仅在 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/workbench-fit-review-20261116/`。历史记忆仅用于复核评审报告惯例，当前事实均来自本次冻结、diff 与源码读取。

冻结基线为 `3c331c1cc3cc428c33c606b9af578057325871b9`，初读及写入报告前实读 HEAD 均相同。首次报告回读时，HEAD 已推进为 `67600170b4f92159135ca7573c094470b33cb3e0`；独立只读核对确认它是基线的直接子提交，已提交路径全部位于 docs/，719 项冻结工程字节与五文件 diff 仍完全相同。本评审继续绑定原 r2，不移签到新 HEAD。输入清单为 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/workbench-fit-20261116/inputs-freeze-r2.json`，清单文件 SHA-256 为 `e42e34726afa354035ee5fe8e7caf466c23127744eaf0213768188da1b9a8494`。719 个唯一、排序路径与 `git ls-files` 排除 docs/ 后完全一致，719 份现存字节长度和 SHA-256 全部匹配。aggregate 按每项 `path + NUL + sha256 + LF` 拼接后重算为 `1a647ee1fbdfde06a8e9e664dce17a82246644aa5f5ef5008c10fc66236d2495`，与用户给定值一致。首次审查及报告写入前再次核对均零漂移。

`source-r2/` 的五个快照逐一与 live 和 manifest 一致；`source-r2.diff` SHA-256 为 `af11356888187809402a59931ee76494ac11c93b6958f98ff0f18e2afd43dd0d`，与基线至当前五文件的只读 Git diff 逐字节相等。工程代码无额外改动。当前 docs/ 的修改只作交接背景，不在本次五文件签署范围。完整绑定在 [binding.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/workbench-fit-review-20261116/binding.json)。

| 冻结文件（本表路径相对于共享 cwd） | SHA-256 |
| --- | --- |
| `crates/keelshell-app/src/files/archive_tests.rs` | `b41d222aca93f1ed9f21955b598580c6c2c647b8720b27aeed7c339d76477fb8` |
| `crates/keelshell-app/src/files/fixture_isolation_tests.rs` | `617b7a72d4a6d5327d74b5829cb435bc00dae83f24b708d844ccd221005a5e78` |
| `crates/keelshell-app/src/files/transfer_tests.rs` | `1a6be63c495d6f3729c493db074da4822addf5e7363c7ca91d494008e70e0aa3` |
| `crates/keelshell-app/src/workspace/tests/workbench_layout.rs` | `f9aeec31aff3028db0398a74a630ddc8cb5365c75ff28cf38bb9246687db5ea0` |
| `crates/keelshell-app/src/workspace/view.rs` | `aa3827cbb53ec180e86d75b705defb524ccbf1bc6b9f0cab97d2bbbd8e4ae2db` |

本次审查重点及源码证据如下；表中行号属于当前 live 源码，也与冻结快照行号一致。

| 检查点 | 结论与证据 |
| --- | --- |
| 布局阈值与真实影响 | [workspace/view.rs:1762](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/workspace/view.rs:1762) 使用 `<=1800`，brand 独立使用 `>=1280`。1800 紧凑、1801 完整标签；1280 保留品牌。该共享参数也送入会话条（[workspace/view.rs:1803](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/workspace/view.rs:1803)），因此 1280–1800 范围还会隐藏新建窗口的可见文字并收紧会话组装饰；其独立 AX 名称和点击路由仍在 [workspace/view.rs:101](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/workspace/view.rs:101)。 |
| 顶栏回调安全 | diff 未修改监听器。追踪 [workspace/view.rs:966](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/workspace/view.rs:966)、[workspace/view.rs:992](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/workspace/view.rs:992)、[workspace/view.rs:1018](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/workspace/view.rs:1018) 的 pane generation/活动实体检查，以及 [workspace/view.rs:1039](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/workspace/view.rs:1039) 的 modal 条件。所有顶栏按钮仍通过 [workspace/modal_scope.rs:239](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/workspace/modal_scope.rs:239) 的稳定 id/focus 路径；设置入口保留既有审核与 disabled 条件。没有发现阈值改变导致授权绕过或新阻塞 I/O。此为静态追踪，没有重放旧帧回调。 |
| 9 场景几何与 AX | [workspace/tests/workbench_layout.rs:129](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/workspace/tests/workbench_layout.rs:129) 精确场景为 1440 中文，以及 1440/1600/1601/1800/1801/1920/1280/900 英文。每场景检查 8 个组/分隔符的可见、内含及顺序，13 个动作的可见/右边界；context 最小宽度同步到 1800，标题和值仍限制单行。[workspace/tests/workbench_layout.rs:218](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/workspace/tests/workbench_layout.rs:218) 精确核对 4 个动作 AX 名称，结束仍断言 peer writes 为空。9 场景不是 9×2 双语矩阵，也没有实际运行。 |
| 审核与 idle 顺序 | 新 `expect_resume_review`（[files/transfer_tests.rs:250](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/transfer_tests.rs:250)）明确要求 `ResumeFile`。`idle` 的原 12 秒等待在 [files/transfer_tests.rs:209](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/transfer_tests.rs:209)；生产结果处理在同一次不可交错的 entity update 内清 busy、发布 pending（[files.rs:1804](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files.rs:1804)、[files.rs:1999](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files.rs:1999)），因此新增审核断言不会在 pending 尚未发布时仅因 idle 而提前运行。准备失败会立即提供诊断，而不是继续误点确认。 |
| 确认后 busy 与等待谓词 | 确认按钮用审核 identity 校验（[files/review.rs:111](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/review.rs:111)），随后 `execute_pending` 同步调用 run（[files.rs:2290](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files.rs:2290)）。续传队列在返回点击回调前插入真实 job 并设置 busy=true（[files/parallel.rs:476](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/parallel.rs:476)）。两处新增 busy 断言 [files/fixture_isolation_tests.rs:95](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/fixture_isolation_tests.rs:95)、[files/fixture_isolation_tests.rs:305](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/fixture_isolation_tests.rs:305) 对应的是确认后已停止/被拒绝的操作，未要求 worker 立即进入 Running，也未缩短原 8 秒/5 秒等待。真实 READ hold、progress>4096 与后续暂停条件仍保留。 |
| Completed 断言时序 | [files/transfer_tests.rs:1441](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/transfer_tests.rs:1441) 在原 idle 后要求 Completed。队列处理先更新 phase（[files/parallel.rs:656](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/parallel.rs:656)），再同步选择状态并重算 busy（[files/parallel.rs:672](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/parallel.rs:672)），因此 idle 对本测试单 job 不会先于终态可见。原前缀字节断言、完整目标字节断言及原 Completed 断言均保留；新增断言没有只靠 byte count 推断成功。 |
| 归档诊断与安全断言 | [files/archive_tests.rs:486](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/archive_tests.rs:486) 的 target.exists 检查位于原 idle 后，仅提前给出目标缺失时的安全状态诊断。原准备阶段不创建目标、nested/data.bin 精确 `[1,0,254]`、empty 目录、close hold 和 Unix 权限断言均保留（[files/archive_tests.rs:480](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/archive_tests.rs:480)）。若根已存在而成员缺失，原读取/字节断言仍会失败；新增根存在断言并非完整成员诊断。未改生产归档/Windows 后端。 |
| fixture 隔离不被放宽 | [files/fixture_isolation_tests.rs:321](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/fixture_isolation_tests.rs:321) 仍检查竞争 sync 被真实 mutation owner 拒绝、无写入、READ hold 未超时、原前缀未追加，以及释放后完成字节；再次 sync 仍须新计划和独立确认。[files/fixture_isolation_tests.rs:111](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/fixture_isolation_tests.rs:111) 起保留原 retained window、真实 worker cleanup 与 admission 断言。未扩大等待、重试、ignore 或删除安全条件。 |
| 诊断编译边界 | `transfer_tests` 由 [files.rs:3613](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files.rs:3613) 的 cfg(test) 挂载，archive/fixture 模块均为其子模块（[files/transfer_tests.rs:24](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/transfer_tests.rs:24)、[files/transfer_tests.rs:40](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/transfer_tests.rs:40)）。新增 pub(super) 仅服务此测试子树，正常应用不含这些诊断入口。 |
| 诊断隐私与误归因 | [files/archive_tests.rs:93](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/archive_tests.rs:93) 只输出固定 Operation 分类；[files/archive_tests.rs:121](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/archive_tests.rs:121) 只输出固定 stage/kind/reason，未知文本丢弃。数字后缀严格为至多 10 位的 u32（[files/archive_tests.rs:109](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/archive_tests.rs:109)），不会拼回路径、peer 或 content。[files/transfer_tests.rs:225](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/transfer_tests.rs:225) 的 Debug 仅格式化 fieldless `TransferPhase`（[files/transfer.rs:5](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/transfer.rs:5)）和数字 tuple，没有格式化 TransferStatus/Operation 的私有 payload。display_os_error 明确是已有 Display 后缀，不能证明 typed io::Error、NTSTATUS 或 syscall。执行错误格式与 [files.rs:839](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files.rs:839) 实际消息一致。新增 3 个 execution-status 样例与原有溢出/换行拒绝样例是源码中的用例，本次均未执行。 |

共完成 16 项静态检查（4 项冻结绑定检查和 12 项代码/测试语义检查），全部通过；详情见 summary.json。这里的“静态检查通过”不计为 Rust 或 Python 测试执行。

命令账按每次 exec_command shell 批次计数，批内子命令不重复累计：交付共 31 批，其中 27 批是路径、指令、技能、源码、Git diff 和字节/摘要只读检查，2 批写入允许目录的报告并再次绑定，2 批仅回读核验报告。27 批 exit 0；4 批非零：批次 7 的尚不存在评审目录（exit 2）、批次 15 的 updates* glob 无匹配（exit 1）、批次 17 的 WORKBENCH* glob 无匹配（exit 1），之后均使用准确路径接续；批次 28 的首轮报告回读在第 34 行“HEAD 必须等于原基线”的附加断言失败（exit 1），当时此前的 719 项字节与快照检查已通过。批次 29/30 读回新 HEAD、确认 docs-only 直接子提交并重新核对全输入，原失败原样记入 binding.json 的 postwrite_readback_r1，不作为产品失败或 Windows 修复证据。其他批次中的不存在定位路径未用于结论。

主要只读命令包括 `GIT_OPTIONAL_LOCKS=0 git rev-parse HEAD`、基线 `git diff --stat`、`git -c core.fsmonitor=false diff --no-ext-diff --no-textconv --binary BASE -- <五文件>`、`git ls-files -z`、`cat/rg/nl/sed/head/pwd` 和 `PYTHONDONTWRITEBYTECODE=1 python3 -` 的标准库字节、路径、摘要及报告检查。实际完整命令已在本次工具调用中记录。未调用工程检查脚本。

**测试/门禁命令=0，独立产品或测试执行=0**；Cargo=0、rustc=0、Clippy=0、fmt=0、GUI=0、预编译测试二进制=0、网络=0、提交/推送=0、清理=0。独立测试 passed=0/failed=0/ignored=0，含义为 NOT_RUN。本次 Python 仅作只读冻结审计及允许目录内报告生成，不执行应用或测试。三份父已有回执只读取了元数据，没有采用其通过计数或认证其日志/构建身份。

未测边界保留：

- 父仍需对相同 aggregate 串行运行专项、完整 gate，核对实际编译库存与输入零漂移；本报告不认证尚未读取的父最终结果。
- Windows 四项 app 失败及真实 Windows 文件系统行为仍未验证，没有修复结论。测试诊断改动没有更改其生产执行路径。
- macOS、Windows、Linux 原生字体、缩放、真实裁切、鼠标/键盘、平台 AX 导出和辅助技术均未执行。1800/1801、1920 及较多窗口/更新状态下的实际字体预算不能用测试字体代签。
- 新 9 场景覆盖的是受控 GPUI tree 的源码断言，AX 精确校验只含 4 个动作；它不是全部主题、语言、字体、窗口计数与更新状态的乘积覆盖。既有 900/1280/1440 三主题/明暗/双语测试仍在源码，但本评审没有运行。

建议接受本批五文件静态改动并进入父串行门禁。代码发现 P0–P3 全部为零，不因预设执行边界凭空增列代码缺陷；组合交付与 Windows/native 验收继续按上述边界 HOLD/未验证。评审任务已完成，父可关闭 reviewer。

共享 HEAD 推进的已提交路径（均在本评审签署范围之外）：

- `docs/HANDOFF.md`
- `docs/ROADMAP.md`
- `docs/testing/records/2026-11-16-kit010-native-ci-evidence/README.md`
- `docs/testing/records/2026-11-16-kit010-native-ci-evidence/manifest.json`
- `docs/testing/records/2026-11-16-kit010-native-ci-evidence/originals.tar.gz`
- `docs/testing/records/2026-11-16-kit010-native-ci-evidence/seal-audit-r1.json`
- `docs/testing/records/2026-11-16-kit010-native-ci-evidence/seal-verification-r1.json`
- `docs/testing/records/2026-11-16-kit010-native-ci-evidence/verify.py`
- `docs/testing/records/2026-11-16-kit010-native-ci.md`
- `docs/testing/records/2026-11-16-windows-directory-rename.md`
