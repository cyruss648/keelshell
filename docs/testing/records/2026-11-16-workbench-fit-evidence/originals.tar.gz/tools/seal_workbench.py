"""Seal only the owned command evidence, source snapshots and review."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[2]
BATCH = Path(__file__).resolve().parent
EVIDENCE = ROOT / "docs/testing/records/2026-11-16-workbench-fit-evidence"
REVIEW = ROOT / "work/workbench-fit-review-20261116"

files = {}
for path in sorted(BATCH.iterdir()):
    if path.is_file() and path.suffix in (".json", ".log", ".diff"):
        files["batch/" + path.name] = path
for path in sorted((BATCH / "source-r2").rglob("*")):
    if path.is_file():
        files["batch/" + path.relative_to(BATCH).as_posix()] = path
for path in sorted(REVIEW.iterdir()):
    if path.is_file():
        files["review/" + path.name] = path
files["batch/run_command.py"] = BATCH / "run_command.py"
files["batch/package-manifest-r1.json"] = BATCH / "package-r1/package-manifest.json"
files["tools/seal_workbench.py"] = Path(__file__).resolve()
files["tools/verify.py"] = EVIDENCE / "verify.py"

data_by_name = {name: path.read_bytes() for name, path in sorted(files.items())}
rows = [
    {
        "path": name,
        "source_path": files[name].relative_to(ROOT).as_posix(),
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
    }
    for name, data in data_by_name.items()
]
output = io.BytesIO()
with gzip.GzipFile(fileobj=output, mode="wb", mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as archive:
        for name, data in data_by_name.items():
            entry = tarfile.TarInfo(name)
            entry.size = len(data)
            entry.mode = 0o644
            entry.mtime = 0
            archive.addfile(entry, io.BytesIO(data))
packed = output.getvalue()
manifest = {
    "schema": "keelshell.workbench-fit.evidence.v1",
    "baseline_source": "3c331c1cc3cc428c33c606b9af578057325871b9",
    "engineering_sha256": "1a647ee1fbdfde06a8e9e664dce17a82246644aa5f5ef5008c10fc66236d2495",
    "count": len(rows),
    "archive_bytes": len(packed),
    "archive_sha256": hashlib.sha256(packed).hexdigest(),
    "uncompressed_bytes": sum(row["bytes"] for row in rows),
    "entries": rows,
    "excluded": ["runtime", "application and MCP binaries", "icon", "unrelated native seal helper"],
    "native_ui": "BLOCKED_MAC_LOCKED",
    "windows_old_failures": "UNRESOLVED_PENDING_NEW_CI",
}
for name in ("originals.tar.gz", "manifest.json"):
    assert not (EVIDENCE / name).exists()
(EVIDENCE / "originals.tar.gz").write_bytes(packed)
(EVIDENCE / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({key: value for key, value in manifest.items() if key != "entries"}))
