"""Remove only this batch's copies after matching their committed evidence."""

from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
SOURCE = "bd198a8ef2578ea9b96e0a603cd705bb2eadca13"
NEW = "docs/testing/records/2026-11-17-darwin-tcp-listeners-evidence"
OLD = "docs/testing/records/2026-11-16-tunnel-configuration-reload-evidence"


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(path):
    return subprocess.check_output(
        ["git", "show", f"{SOURCE}:{path}"], cwd=ROOT, timeout=30
    )


def package_snapshot(directory):
    return {
        path.relative_to(directory).as_posix(): digest(path.read_bytes())
        for path in sorted(directory.rglob("*")) if path.is_file()
    }


def main():
    target = ROOT / "work/recovery-batch-integration-20261115/target"
    identity = [target.stat().st_dev, target.stat().st_ino]
    protected = [
        BASE / "package-r1",
        ROOT / "work/tunnel-configuration-reload-20261116/package-r1",
    ]
    before = [package_snapshot(path) for path in protected]
    catalog = {}
    originals = {}
    for prefix in (NEW, OLD + "/ci-completion"):
        manifest = json.loads(blob(prefix + "/manifest.json"))
        packed = blob(prefix + "/originals.tar.gz")
        assert len(packed) == manifest["archive_bytes"]
        assert digest(packed) == manifest["archive_sha256"]
        with tarfile.open(fileobj=io.BytesIO(packed), mode="r:gz") as archive:
            members = {member.name: archive.extractfile(member).read()
                       for member in archive.getmembers() if member.isfile()}
        assert len(members) == manifest["count"]
        for row in manifest["entries"]:
            raw = members[row["path"]]
            assert len(raw) == row["bytes"] and digest(raw) == row["sha256"]
            catalog.setdefault(
                (len(raw), digest(raw)),
                f"{SOURCE}:{prefix}/originals.tar.gz#{row['path']}",
            )
        if prefix == NEW:
            originals = members
    names = subprocess.check_output(
        ["git", "ls-tree", "-rz", "--name-only", SOURCE, "--", OLD],
        cwd=ROOT, timeout=30,
    ).split(b"\0")
    for entry in names:
        if not entry or entry.endswith(b".tar.gz"):
            continue
        name = entry.decode()
        raw = blob(name)
        catalog.setdefault((len(raw), digest(raw)), f"{SOURCE}:{name}")

    selected = {}
    retained = []
    for directory in (BASE, ROOT / "work/tunnel-configuration-reload-20261116"):
        for path in sorted(directory.rglob("*")):
            if not path.is_file():
                continue
            name = path.relative_to(directory).as_posix()
            if name.startswith(("package-r1/", "package-candidate-r1/", "delivery-review/")):
                continue
            if directory == BASE and name in (
                "run_command.py", "cleanup_owned.py",
                "cleanup-execution-r1.log", "cleanup-execution-r1.json",
            ):
                continue
            assert not path.is_symlink(), str(path)
            raw = path.read_bytes()
            key = (len(raw), digest(raw))
            proof = catalog.get(key)
            if proof:
                selected[path] = {"bytes": len(raw), "sha256": key[1], "git_evidence": proof}
            else:
                retained.append(path.relative_to(ROOT).as_posix())

    binary = json.loads(originals["test-binaries-r4.json"])["binaries"]["linux_recovery"]
    path = BASE / "monitor-interop-r4"
    assert path.is_file() and not path.is_symlink()
    raw = path.read_bytes()
    assert len(raw) == binary["bytes"] and digest(raw) == binary["sha256"]
    selected[path] = {
        "bytes": len(raw), "sha256": digest(raw),
        "git_evidence": f"{SOURCE}:{NEW}/originals.tar.gz#test-binaries-r4.json",
        "reason": "Completed test binary; its size and digest are sealed",
    }
    retained.remove(path.relative_to(ROOT).as_posix())

    candidate = BASE / "package-candidate-r1"
    manifest_raw = originals["normal-package-candidate-manifest-r1.json"]
    manifest = json.loads(manifest_raw)
    assert (candidate / "package-manifest.json").read_bytes() == manifest_raw
    assert manifest["files"] == json.loads(
        (BASE / "package-r1/package-manifest.json").read_bytes()
    )["files"]
    assert {path.relative_to(candidate).as_posix() for path in candidate.rglob("*")
            if path.is_file()} == set(manifest["files"]) | {"package-manifest.json"}
    for path in sorted(candidate.rglob("*")):
        if not path.is_file():
            continue
        assert not path.is_symlink()
        raw = path.read_bytes()
        expected = (
            digest(manifest_raw) if path.name == "package-manifest.json" else
            manifest["files"][path.relative_to(candidate).as_posix()]
        )
        assert digest(raw) == expected
        selected[path] = {
            "bytes": len(raw), "sha256": expected,
            "git_evidence": f"{SOURCE}:{NEW}/originals.tar.gz#normal-package-candidate-manifest-r1.json",
            "reason": "Precommit duplicate replaced by the exact-commit normal package",
        }

    receipt = {
        "source": SOURCE, "observed_at_utc": datetime.now(timezone.utc).isoformat(),
        "files_removed": len(selected),
        "bytes_removed": sum(row["bytes"] for row in selected.values()),
        "files": [
            {"path": path.relative_to(ROOT).as_posix(), **row}
            for path, row in sorted(selected.items())
        ],
        "unmatched_retained": retained,
        "protected_normal_packages": [
            {"path": path.relative_to(ROOT).as_posix(), "before": snapshot}
            for path, snapshot in zip(protected, before)
        ],
        "target_before": identity,
    }
    parents = set()
    for path, row in selected.items():
        assert path.is_file() and not path.is_symlink()
        raw = path.read_bytes()
        assert len(raw) == row["bytes"] and digest(raw) == row["sha256"], str(path)
    for path in selected:
        path.unlink()
        parents.update(parent for parent in path.parents if parent not in (BASE, ROOT)
                       and (parent.is_relative_to(BASE) or
                            parent.is_relative_to(ROOT / "work/tunnel-configuration-reload-20261116")))
    for directory in sorted(parents, key=lambda value: len(value.parts), reverse=True):
        try:
            directory.rmdir()
        except OSError:
            pass
    after = [package_snapshot(path) for path in protected]
    assert before == after
    identity_after = [target.stat().st_dev, target.stat().st_ino]
    assert identity == identity_after
    receipt.update(
        protected_normal_packages_unchanged=True, target_after=identity_after,
        shared_target_directory_unchanged=True,
        current_package_files=len(before[0]), previous_package_files=len(before[1]),
        all_selected_absent=all(not path.exists() for path in selected),
    )
    (BASE / "owned-cleanup-r1.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({key: value for key, value in receipt.items()
                      if key not in ("files", "protected_normal_packages")}))


if __name__ == "__main__":
    main()
