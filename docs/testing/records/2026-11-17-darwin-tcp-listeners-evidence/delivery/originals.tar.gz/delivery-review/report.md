# 2026-11-17 限定交付证据非作者复核

**APPROVE；P0=0、P1=0、P2=0、P3=0。**

结论绑定 `bd198a8ef2578ea9b96e0a603cd705bb2eadca13` 时点、已完成 before/after 核对的指定文档。未发现这些交付说明与证据之间需要修改的问题。父级此后补记提交、CI 进行中和资源清理的事实不在本次签署范围，也不要求重验已冻结的源码与封存。

## 范围与身份

已读取 AGENTS.md、其引入的 RTK.md 与 docs/HANDOFF.md。只核对以下范围：

- `docs/testing/records/2026-11-17-darwin-tcp-listeners.md`；
- 同名 `-evidence/{README.md,manifest.json,verify.py,originals.tar.gz}`；
- `2026-11-16-tunnel-configuration-reload-evidence/ci-completion/` 及验证器为绑定旧来源而调用的只读父级验证器；
- HANDOFF、ROADMAP 中这两批的相关状态。

工程基线是 `8d95d71cfa08181d5d44b689c108edcad7d995c4`；r4 冻结是 724 项输入，aggregate 为 `baae8aaab5903ad60509c23341b91a23553fac47ea7d1b0ff9ac993031c2e6ef`。独立补算将这 724 项本地文件与 `bd198a8` 的 Git blob 逐项比较，零差异。指定 11 份文档／封存的 before/after 长度与 SHA-256 相等，见 `scope-before-r1.json`、`scope-after-r1.json`。

未重复 Ohm/Hegel 的 Rust 源码评审或功能测试；源码读取仅用于冻结摘要与 Git blob 身份比较。

## 实际执行与关键计数

两项文档验证器均实际退出 0、direct reaped、无 timeout、stderr 为空；完整命令、解释器、日志摘要与耗时见 `verification-commands-r1.json` 及各自 receipt。

| 本次命令 | exit / reaped | 实测秒数 |
| --- | --- | --- |
| `python3 -B docs/testing/records/2026-11-17-darwin-tcp-listeners-evidence/verify.py` | 0 / true | 0.094828 |
| `python3 -B docs/testing/records/2026-11-16-tunnel-configuration-reload-evidence/ci-completion/verify.py` | 0 / true | 7.331875 |
| `python3 -B -` 独立计数、摘要和 Git blob 比较 | 0 / 已返回 | 0.076315 |

实际解释器是 `/opt/homebrew/opt/python@3.15/bin/python3.15`。设置 `PYTHONDONTWRITEBYTECODE=1`，CI 验证器临时派生的 TMPDIR 位于本 delivery-review 下。未写入 target。

本批 255 成员归档、成员集合、长度与摘要核对通过；原文总计 3,791,780 字节、压缩 817,934 字节，归档 SHA-256 为 `eeea5237cf74e05c65ff4f7b286ecf84e2378355d77fe1b5fb920cb56a2c7330`。

| 范围 | 核对结果 |
| --- | --- |
| 普通 Rust | 92 suites；3272 passed / 0 failed / 51 ignored |
| rustdoc | 14 passed / 0 failed / 0 ignored，另列 |
| app | 1367 passed / 0 failed / 2 ignored；准确 gate 二进制的 1369 唯一库存名与执行集合相等 |
| 新用例 | app 5 + session 21，共 26 个具体名全部 ok，包含在上述总数内 |
| Python 主 discovery | 293 run / 2 skipped，OK |
| Rust 调用的 archive helper Python | 另列 30 run |
| workspace 无 libtest harness controller | 两个独立成功终态，不填普通测试数 |
| Hegel 父预编译执行 | app 75、session 102，共 177 passed / 0 failed / 0 ignored |
| Hegel 库存 | app 1369、session 313 唯一名；库存不是执行通过数 |

独立重算保存在 `independent-recompute-r3.json`：包括 92 套件各自声明、唯一逐名结果与各状态计数、26 个具体新名、完整帧结果、产物身份。`engineering-snapshot-r1.json` 保存 724 项输入长度和摘要。配合两个 verify 的 stdout 可独立复算关键计数，无需重放测试。

## 重点边界

完整帧新例的具体名为：

`monitor::darwin_sockets::tests::ssh_socket_dispatch_requires_platform_frame_and_preserves_framed_linux_empty`

该名确实在最终 session 21 个 required_new_tests 内。验证器 `verify.py:189-195` 取该列表并要求这些名在准确完整 gate 中全部 ok。独立补算也分别确认该名在修前 `missing-frame-negative-r1.log` 中 FAILED，在 `session-monitor-r4.log`、Hegel 的 `session-monitor.log`、`full-gate-r1.log` 中逐名 ok。原缺帧 P2、REQUEST_CHANGES、mapped 6/2、零命中过滤、静态断言失败与 ZipWriter 派生诊断均保留。

Python 主计数只归属 fmt 前的 discovery 段；全日志另外出现的 30 项 helper 没有混入 293。app 的单包父预编译与 workspace feature 产物 SHA-256 不同，文档未将二者身份混同。本复核读取 Hegel 原始 inventory／monitor 日志重算，但未执行这些二进制；Hegel 的 177 项也不等于独立编译或 native 验收。

Linux `--source-sha` 是旧基线参数，另有 r4 aggregate 与测试产物 SHA-256 `b739c1028679af5718f6c87e312bb533675cf6712d9024fefb728c8214e3247a` 的 WIP 绑定。文档对此区分准确。

正常 release build／包结构证据通过，提交前包 `build.commit=null` 如实保留。最新 native 可用性原件明确锁屏、NOT_RUN、GUI actions=0、screenshots=0。真实 Darwin SSH 9/0/0、Linux 恢复 2/0/0、预编译执行、arm64／minos 15.0 包检查均未被提升为 GPUI 桌面或完整产品／发行验收。

上一隧道 CI `43901863960` 的原件明确绑定 `6f28f5c424752a221746fbfb621e319c20ff38b9`，completed/success，watch 0/reaped/1258.244s。25 成员归档验证器从原始 job 日志重建派生结果，并从精确旧 Git blob 核对 721 输入。

| 平台 / job | 普通 Rust passed/failed/ignored | app passed/failed/ignored | Python run/skipped | rustdoc |
| --- | --- | --- | --- | --- |
| Windows / 133420285732 | 3233/0/46 | 1351/0/2 | 293/34 | 14 |
| macOS / 133420286347 | 3246/0/48 | 1362/0/2 | 293/2 | 14 |
| Ubuntu / 133420286130 | 3239/0/49 | 1363/0/2 | 293/2 | 14 |

三平台 quality gate success，macOS／Ubuntu OpenSSH step success，Windows skipped。CI 无独立 app --list、Python 无逐名 -v，文档未补造这些证据，也没有用旧 CI 代签当前 724 输入。父级告知新 CI `43916079699` 进行中；本复核未查询、跟踪或签署该 CI。

## 命令范围、诊断与限制

除两个文档验证器外，执行过只读 `pwd`、`rg --files`、`rg -n`、`cat`、`wc -l`、`sed -n`、`nl -ba`、`git rev-parse HEAD`、`git ls-tree -rz bd198a8ef2578ea9b96e0a603cd705bb2eadca13`，以及 `python3 -B -` 内存读取 tar、摘要和计数。没有执行 git diff／暂存／提交／推送、Cargo、源码功能测试或资源回收命令。

额外独立派生的两个失败诊断保存为 `recompute-diagnostic-r1.json`、`recompute-diagnostic-r2.json`：首次假设当前 HEAD 仍等于开发基线，被并行提交打破；第二次泛化 running 分块器未满足单摘要假设。二者均 exit 1，未修改原件或重放测试。最终 r3 使用明确 suite 边界重算退出 0。报告首次字符串插值的诊断也保留，不作为项目缺陷。

本次 Cargo=0、Rust/GPUI/SSH/Podman/Python unittest 功能测试=0、native 操作=0、target 写入=0、源／项目文档修改=0、Git 修改=0、主动资源清理命令=0。仅新增本 delivery-review 的报告与回执；不审核父级随后新增的交付或清理回执。完整 native、安装、签名、公证、外部 AI、独立 peer、远端 Windows、新 CI 及全项目审计均不在范围。
