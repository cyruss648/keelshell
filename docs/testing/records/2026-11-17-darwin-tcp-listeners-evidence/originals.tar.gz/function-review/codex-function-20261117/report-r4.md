# Darwin TCP listeners：r4 独立非作者功能复核

**结论：APPROVE（仅限本文明确的冻结源码、父级预编译产物和功能回归范围）。P0=0，P1=0，P2=0，P3=0。**

最终 r4 未发现需要请求修改的功能缺陷。此前由独立源码审查报告的缺帧 P2，已在 r4 的公开 SSH 入口回归中关闭：缺前缀的 empty stdout/exit 0、空白、未封装 ss 行、不完整结束帧与带警告响应均被拒绝，能力不会成为 Available；完整 Linux 空帧仍可用。修前 exit 101 属于父级保留的历史复现，本复核者未重跑或重签旧版本。

## 冻结和产物身份

- 工作树：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`。HEAD/base 为 `8d95d71cfa08181d5d44b689c108edcad7d995c4`；审查对象是该基线之上的 724 项冻结工作树输入，不把未提交实现称为该 HEAD 已提交内容。
- r4 输入：724 项、724 个唯一路径，全部逐文件字节数与 SHA-256 匹配，aggregate 为 `baae8aaab5903ad60509c23341b91a23553fac47ea7d1b0ff9ac993031c2e6ef`。聚合方式：按清单顺序连接 `path + NUL + sha256 + LF` 后 SHA-256。
- 执行前、执行后以及签结论时重新读取源码、ADR 和两个产物，均无漂移；父级 manifest 与独立读取的 app 库存集合完全一致。

| 产物 | 字节数 | SHA-256 |
| --- | ---: | --- |
| app（父级预编译） | 273628912 | `3ad7781081bd3b3389a9f795a0bfdd4513f49cb88c28aee61139fc25d4dc643a` |
| session（父级预编译） | 41271104 | `2180819289d3a0efcc95112b817ed09502ac567bf36013e7147cddad70bf7393` |

精确产物路径：

- app: `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/recovery-batch-integration-20261115/target/debug/build/keelshell-app/e9828e40142b11cd/out/keelshell_app-e9828e40142b11cd`
- session: `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/recovery-batch-integration-20261115/target/debug/build/keelshell-session/fef4cb1cabbdcb2d/out/keelshell_session-fef4cb1cabbdcb2d`

## 实际执行与逐名对账

| 命令 | 完整库存唯一名 | passed | failed | ignored | filtered out | 外层实际秒数 | 硬截止秒数 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| app `monitor:: --test-threads=2 --color never` | 1369 | 75 | 0 | 0 | 1294 | 39.864213 | 300 |
| session `monitor:: --test-threads=2 --color never` | 313 | 102 | 0 | 0 | 211 | 0.353629 | 180 |

本复核者实际执行两次完整 `--list --color never` 与两次 `monitor:: --test-threads=2 --color never`。完整库存为 session 313、app 1369 个唯一测试名；这不是全库测试通过数。两组实际回归共 177 passed / 0 failed / 0 ignored，26 个新增例已包含在 177 中，不重复累加。

所有执行均设置硬截止，直接子进程实际 wait/reap，结束时自有进程组不存在、日志已关闭；未发生超时或清理错误。库存、逐行实际结果、声明运行数、汇总数和过滤数相互一致；无重复、漏项或意外测试名。新例必须各出现一次实际 `ok`，不以 exit 0 或总数代替。

## r4 P2 与关键功能核查

- 缺帧 P2：[`monitor.rs:786`](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor.rs:786)、[`monitor.rs:804`](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor.rs:804) 先验证总预算和 SSH 完成状态，再要求完整 Darwin 或 Linux 帧；[`tests.rs:632`](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/darwin_sockets/tests.rs:632) 从 `LinuxMonitor::listening_sockets` 经受控真实 SSH 连接逐项核对错误与能力状态，并以完整 Linux 空帧作正向控制。实际结果见 [`session-monitor.log:84`](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117/session-monitor.log:84)。
- mapped IPv6：[`darwin_sockets.rs:186`](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/darwin_sockets.rs:186) 仅额外接受标准数字 IPv4 字面量，保留观察到的地址；新正例、`[127.0.0.1]` 与无效 IPv4 拒绝项均在 session 21 个新增例中实际通过。
- Python 缺失：[`darwin_sockets.rs:87`](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_tests/darwin_sockets.rs:87) 验证资源能力 CommandMissing 且没有 snapshot 时，独立端口读取仍成功；同时 probe 不发命令。
- 暂停 ABA／迟到：[`monitor.rs:233`](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor.rs:233) 同步推进 sample generation 与 capability generation；新增挂起 socket 例和既有 recheck ABA／retirement 例均通过，迟到列表和能力不回填。
- 负缓存／重新检测：新 app missing-lsof 例、session warnings／missing-tool／reset 例，以及既有 SSH timeout transport 可重试例均通过；负缓存仅显式重新检测清除，SSH 故障不误报命令缺失。
- Linux probe／SIGTERM：既有显式 probe、端点安全与变化拒绝、连接绑定／61 秒过期审核／受保护 PID 拒绝、暂停后已发 SIGTERM 单次回执保留例均实际通过。Darwin/unknown 的 UI 与分派拒绝 probe/进程动作；端口可读不新增动作权限。
- 三主题双语：[`registry.rs:255`](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/design/registry.rs:255) 枚举 Frost、Graphite、Lavender；既有 Darwin 标签与能力重绘测试遍历 3 主题 × 2 明暗模式 × 2 语言，并断言命令计数不变，均实际 `ok`。这是 GPUI 测试上下文验证。

## 5 个新增 app 用例：逐名实际 ok

| 编译及执行名 | 原日志行 | 实际结果 |
| --- | --- | --- |
| `monitor::tests::darwin_sockets::darwin_missing_lsof_stays_cached_until_explicit_recheck` | [app-monitor.log:62](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117/app-monitor.log:62) | ok |
| `monitor::tests::darwin_sockets::darwin_pausing_pending_socket_read_discards_late_list_and_capability` | [app-monitor.log:63](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117/app-monitor.log:63) | ok |
| `monitor::tests::darwin_sockets::darwin_socket_button_reads_tcp_without_offering_linux_actions` | [app-monitor.log:64](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117/app-monitor.log:64) | ok |
| `monitor::tests::darwin_sockets::darwin_socket_read_does_not_depend_on_python_resource_collection` | [app-monitor.log:65](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117/app-monitor.log:65) | ok |
| `monitor::tests::darwin_sockets::unknown_platform_rejects_probe_even_with_a_displayed_tcp_row` | [app-monitor.log:66](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117/app-monitor.log:66) | ok |

## 21 个新增 session 用例：逐名实际 ok

| 编译及执行名 | 原日志行 | 实际结果 |
| --- | --- | --- |
| `monitor::darwin_sockets::tests::darwin_socket_empty_requires_quiet_exit_one_and_complete_wrapper` | [session-monitor.log:53](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117/session-monitor.log:53) | ok |
| `monitor::darwin_sockets::tests::darwin_socket_parser_accepts_ipv4_ipv6_wildcards_and_scoped_ipv6` | [session-monitor.log:54](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117/session-monitor.log:54) | ok |
| `monitor::darwin_sockets::tests::darwin_socket_parser_accepts_multiple_files_processes_and_field_order` | [session-monitor.log:55](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117/session-monitor.log:55) | ok |
| `monitor::darwin_sockets::tests::darwin_socket_parser_bounds_command_endpoint_set_and_total_bytes` | [session-monitor.log:56](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117/session-monitor.log:56) | ok |
| `monitor::darwin_sockets::tests::darwin_socket_parser_enforces_socket_count_without_truncation` | [session-monitor.log:70](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117/session-monitor.log:70) | ok |
| `monitor::darwin_sockets::tests::darwin_socket_parser_preserves_ipv4_literal_of_ipv4_mapped_ipv6_listener` | [session-monitor.log:58](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117/session-monitor.log:58) | ok |
| `monitor::darwin_sockets::tests::darwin_socket_parser_rejects_hostnames_family_mismatch_and_invalid_scopes` | [session-monitor.log:59](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117/session-monitor.log:59) | ok |
| `monitor::darwin_sockets::tests::darwin_socket_parser_rejects_invalid_encoding_and_wrapper_status` | [session-monitor.log:60](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117/session-monitor.log:60) | ok |
| `monitor::darwin_sockets::tests::darwin_socket_parser_rejects_invalid_pid_descriptor_and_port_numbers` | [session-monitor.log:61](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117/session-monitor.log:61) | ok |
| `monitor::darwin_sockets::tests::darwin_socket_parser_rejects_missing_duplicate_and_unselected_fields` | [session-monitor.log:62](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117/session-monitor.log:62) | ok |
| `monitor::darwin_sockets::tests::darwin_socket_parser_rejects_truncated_nul_and_set_boundaries` | [session-monitor.log:63](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117/session-monitor.log:63) | ok |
| `monitor::darwin_sockets::tests::darwin_socket_parser_rejects_udp_connected_and_non_listening_records` | [session-monitor.log:64](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117/session-monitor.log:64) | ok |
| `monitor::darwin_sockets::tests::darwin_socket_remote_failure_or_missing_exit_never_publishes_rows` | [session-monitor.log:65](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117/session-monitor.log:65) | ok |
| `monitor::darwin_sockets::tests::darwin_socket_stderr_rejects_partial_success_and_empty_failure_without_echo` | [session-monitor.log:66](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117/session-monitor.log:66) | ok |
| `monitor::darwin_sockets::tests::darwin_tcp_listen_preserves_account_visible_command_pid_and_peer` | [session-monitor.log:67](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117/session-monitor.log:67) | ok |
| `monitor::darwin_sockets::tests::socket_command_keeps_linux_ss_and_absolute_read_only_darwin_selection` | [session-monitor.log:68](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117/session-monitor.log:68) | ok |
| `monitor::darwin_sockets::tests::ssh_darwin_socket_incomplete_exit_and_overflow_never_become_empty_success` | [session-monitor.log:69](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117/session-monitor.log:69) | ok |
| `monitor::darwin_sockets::tests::ssh_darwin_socket_quiet_empty_is_available_and_missing_tool_is_not` | [session-monitor.log:71](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117/session-monitor.log:71) | ok |
| `monitor::darwin_sockets::tests::ssh_darwin_socket_reset_rejects_a_late_capability_observation` | [session-monitor.log:73](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117/session-monitor.log:73) | ok |
| `monitor::darwin_sockets::tests::ssh_darwin_socket_warnings_are_cached_until_reset_then_recover` | [session-monitor.log:72](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117/session-monitor.log:72) | ok |
| `monitor::darwin_sockets::tests::ssh_socket_dispatch_requires_platform_frame_and_preserves_framed_linux_empty` | [session-monitor.log:84](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117/session-monitor.log:84) | ok |

## 范围限制与原始事实

- 本次是全新非作者功能复核，只使用父级编译的两个现有测试二进制；独立编译 0、Cargo 0、target 写入 0。未运行格式化、Clippy、完整工作区门禁、供应商 CLI、真实模型或桌面 native 验收。
- 本复核者真实本机 OpenSSH 执行 0；父级报告最终 r4 全帧 OpenSSH 9/0/0 与清理通过，属于父级独立证据，不计入本复核者的 177 例，也不由本报告代签。另一个 linux_recovery 产物不在本次执行或 SHA 签结论范围。
- 未访问客户主机，未采集或持久化全机进程／端口数据。运行仅使用测试自有 loopback SSH 夹具和合成响应。测试临时目录、缓存、报告、工装与日志均限定在本复核者目录内；没有清理操作。
- r1/r2/r3 测试二进制由本复核者执行均为 0。r2-source-preflight.json 只证明当时 r2 源码的冻结核对，旧 scope-updates.json 保持等待当时事实。父级 r1 错过滤 0 tests、真实 OpenSSH r1 6/2 与旧 r3 脚本断言失败均保持历史，不算覆盖，不挪签到 r4。
- 父级最终完整 gate 与三平台桌面／发行验收仍由各自实际证据决定；本次 APPROVE 限定在本报告范围。

## 可复核文件

- 聚合回执：[receipt-r4.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117/receipt-r4.json)。
- 逐名解析与原命令：[codex-function-20261117](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117) 下的 `app-monitor.analysis.json`、`session-monitor.analysis.json`、两份 inventory、各 `.receipt.json`／`.log`。
- 执行前后及签结论冻结：`freeze-before.json`、`freeze-after.json`、`freeze-at-signoff-r4-r2.json`。
- 保留等待事实：[`scope-updates.json`](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117/scope-updates.json)；r1 至 r4 差量：[`r1-to-current-delta.json`](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/function-review/codex-function-20261117/r1-to-current-delta.json)。

报告工装诊断：首次整理因内存 tuple 与已保存 JSON list 的直接比较触发断言失败。后续规范 JSON 比较后仅重新整理证据，未重跑测试；finalize-r4-report.log 与原回执保留。
