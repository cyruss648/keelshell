"""Read frozen inputs and run only explicitly supplied parent-built test binaries."""

import argparse
from collections import Counter
from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time


OUT = Path(__file__).resolve().parent
ROOT = Path(__file__).resolve().parents[4]
BATCH = OUT.parent.parent
EXPECTED_R1_AGGREGATE = (
    "3c4fcec2301199183af991316fd62e39ab4b769ea184cfb910513ffea7da8bb3"
)
EXPECTED_R4_AGGREGATE = (
    "baae8aaab5903ad60509c23341b91a23553fac47ea7d1b0ff9ac993031c2e6ef"
)


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(1024 * 1024):
            digest.update(block)
    return digest.hexdigest()


def write_json(name, value):
    path = OUT / name
    with path.open("x") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def utc():
    return datetime.now(timezone.utc).isoformat()


def expected_tests():
    session_source = ROOT / "crates/keelshell-session/src/monitor/darwin_sockets/tests.rs"
    app_source = ROOT / "crates/keelshell-app/src/monitor_tests/darwin_sockets.rs"
    expression = r"#\[(?:tokio::|gpui_kit::)?test(?:\([^\]]*\))?\]\s*(?:async\s+)?fn\s+(\w+)"
    session = [
        "monitor::darwin_sockets::tests::" + name
        for name in re.findall(expression, session_source.read_text())
    ]
    app = [
        "monitor::tests::darwin_sockets::" + name
        for name in re.findall(expression, app_source.read_text())
    ]
    return {"session": sorted(session), "app": sorted(app)}


def verify(freeze_path, binaries_path):
    started = time.monotonic()
    frozen = json.loads(freeze_path.read_text())
    metadata = json.loads(binaries_path.read_text())
    rows = frozen["inputs"]
    actual = []
    mismatches = []
    paths = [row["path"] for row in rows]
    for row in rows:
        path = ROOT / row["path"]
        if not path.resolve().is_relative_to(ROOT):
            raise ValueError("Frozen input escapes checkout")
        stat = path.stat()
        observed = {
            "path": row["path"],
            "bytes": stat.st_size,
            "sha256": sha(path),
        }
        actual.append(observed)
        if observed != row:
            mismatches.append({"expected": row, "observed": observed})
    aggregate = hashlib.sha256(
        "".join(f'{row["path"]}\0{row["sha256"]}\n' for row in actual).encode()
    ).hexdigest()
    binaries = {}
    for role in ("app", "session"):
        expected = metadata["binaries"][role]
        path = Path(expected["path"])
        observed = {
            "path": str(path),
            "bytes": path.stat().st_size,
            "sha256": sha(path),
        }
        binaries[role] = {
            "expected": expected,
            "observed": observed,
            "matches": observed == expected,
        }
    adr = ROOT / "docs/adr/0152-darwin-tcp-listeners.md"
    result = {
        "observed_at_utc": utc(),
        "freeze": str(freeze_path),
        "freeze_sha256": sha(freeze_path),
        "metadata": str(binaries_path),
        "metadata_sha256": sha(binaries_path),
        "base": frozen.get("base"),
        "declared_count": frozen["count"],
        "actual_count": len(actual),
        "unique_paths": len(set(paths)),
        "paths_sorted": paths == sorted(paths),
        "expected_aggregate": frozen["aggregate_sha256"],
        "actual_aggregate": aggregate,
        "aggregate_formula": "sha256(concat(path + NUL + sha256 + LF), manifest order)",
        "metadata_source_aggregate": metadata.get("source_aggregate"),
        "parent_prebuilt": metadata.get("prebuilt_by_parent"),
        "independent_compilation": False,
        "mismatches": mismatches,
        "binaries": binaries,
        "adr": {"path": str(adr), "bytes": adr.stat().st_size, "sha256": sha(adr)},
        "source_derived_new_test_names": expected_tests(),
        "observed_inputs": actual,
        "seconds": time.monotonic() - started,
    }
    result["valid"] = (
        not mismatches
        and len(actual) == frozen["count"] == len(set(paths))
        and aggregate == frozen["aggregate_sha256"] == metadata.get("source_aggregate")
        and all(item["matches"] for item in binaries.values())
        and metadata.get("prebuilt_by_parent") is True
        and metadata.get("independent_compilation") is False
    )
    return result


def group_exists(pgid):
    try:
        os.killpg(pgid, 0)
    except ProcessLookupError:
        return False
    return True


def bounded(label, command, seconds, binary=None):
    log_path = OUT / (label + ".log")
    receipt_path = OUT / (label + ".receipt.json")
    if log_path.exists() or receipt_path.exists():
        raise FileExistsError(label)
    runtime = OUT / "runtime" / label
    for child in ("tmp", "data", "cache", "config"):
        (runtime / child).mkdir(parents=True, exist_ok=False)
    environment = {
        **os.environ,
        "PYTHONDONTWRITEBYTECODE": "1",
        "GIT_OPTIONAL_LOCKS": "0",
        "TMPDIR": str(runtime / "tmp"),
        "KEELSHELL_DATA_DIR": str(runtime / "data"),
        "XDG_CACHE_HOME": str(runtime / "cache"),
        "XDG_CONFIG_HOME": str(runtime / "config"),
        "RUST_BACKTRACE": "0",
    }
    if binary is not None and sha(Path(command[0])) != binary["sha256"]:
        raise ValueError("Binary changed immediately before execution")
    start = time.monotonic()
    started_utc = datetime.now(timezone.utc)
    timed_out = False
    interrupted = False
    cleanup_errors = []
    with log_path.open("xb", buffering=0) as output:
        process = subprocess.Popen(
            command,
            cwd=ROOT,
            env=environment,
            stdin=subprocess.DEVNULL,
            stdout=output,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        try:
            process.wait(timeout=max(1.0, seconds - 5.0))
        except subprocess.TimeoutExpired:
            timed_out = True
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait(timeout=3)
        except BaseException:
            interrupted = True
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait(timeout=3)
            raise
        finally:
            if group_exists(process.pid):
                cleanup_errors.append("Owned process group survived direct child exit")
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                until = min(start + seconds, time.monotonic() + 1.0)
                while group_exists(process.pid) and time.monotonic() < until:
                    time.sleep(0.02)
            direct_reaped = process.returncode is not None
            group_absent = not group_exists(process.pid)
    receipt = {
        "label": label,
        "command": command,
        "cwd": str(ROOT),
        "started_at_utc": started_utc.isoformat(),
        "hard_deadline_utc": (started_utc + timedelta(seconds=seconds)).isoformat(),
        "hard_budget_seconds": seconds,
        "timeout_kill_reserve_seconds": 5,
        "seconds": time.monotonic() - start,
        "pid": process.pid,
        "observed_exit": process.returncode,
        "timed_out": timed_out,
        "interrupted": interrupted,
        "terminal": {
            "direct_reaped": direct_reaped,
            "owned_process_group_absent": group_absent,
            "log_file_closed": True,
            "errors": cleanup_errors,
        },
        "binary": binary,
        "log": str(log_path),
        "log_bytes": log_path.stat().st_size,
        "log_sha256": sha(log_path),
        "writes_isolated_to": str(OUT),
        "independent_compilation": False,
        "native_acceptance": False,
    }
    write_json(receipt_path.name, receipt)
    print(json.dumps({key: receipt[key] for key in (
        "label", "observed_exit", "seconds", "timed_out", "terminal"
    )}), flush=True)
    if (
        receipt["observed_exit"] != 0
        or timed_out
        or interrupted
        or cleanup_errors
        or not direct_reaped
        or not group_absent
        or receipt["seconds"] >= seconds
    ):
        raise RuntimeError("Bounded command did not complete cleanly: " + label)
    return log_path.read_text(errors="replace")


def inventory(text):
    names = re.findall(r"^(\S+): test$", text, re.MULTILINE)
    summary = re.findall(r"^(\d+) tests?, (\d+) benchmarks?$", text, re.MULTILINE)
    if len(summary) != 1 or len(names) != int(summary[0][0]) or int(summary[0][1]):
        raise ValueError("Inventory declared count differs from per-name inventory")
    if len(set(names)) != len(names):
        raise ValueError("Duplicate inventory test names")
    return names


def analyze_run(text, names, required):
    entries = re.findall(
        r"^test (\S+) \.\.\. (ok|FAILED|ignored)(?:,.*)?$", text, re.MULTILINE
    )
    totals = re.findall(
        r"^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; "
        r"(\d+) measured; (\d+) filtered out; finished in (.+)$",
        text, re.MULTILINE,
    )
    declared = re.findall(r"^running (\d+) tests?$", text, re.MULTILINE)
    expected = [name for name in names if "monitor::" in name]
    counts = Counter(status for _, status in entries)
    duplicates = [name for name, count in Counter(name for name, _ in entries).items() if count > 1]
    missing = sorted(set(expected) - {name for name, _ in entries})
    unexpected = sorted({name for name, _ in entries} - set(expected))
    result = {
        "inventory_total": len(names),
        "filter": "monitor::",
        "expected_filtered": len(expected),
        "declared_running": declared,
        "actual_passed": counts["ok"],
        "actual_failed": counts["FAILED"],
        "actual_ignored": counts["ignored"],
        "duplicates": duplicates,
        "missing": missing,
        "unexpected": unexpected,
        "required_new_tests": {
            name: [status for actual, status in entries if actual == name]
            for name in required
        },
        "per_name_results": [{"name": name, "status": status} for name, status in entries],
        "summary_fields": totals,
    }
    result["valid"] = (
        len(totals) == len(declared) == 1
        and int(declared[0]) == len(entries) == len(expected)
        and not duplicates and not missing and not unexpected
        and all(statuses == ["ok"] for statuses in result["required_new_tests"].values())
        and totals[0][0] == "ok"
        and [int(value) for value in totals[0][1:6]]
        == [counts["ok"], counts["FAILED"], counts["ignored"], 0, len(names) - len(expected)]
        and counts["FAILED"] == 0
    )
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--freeze", required=True)
    parser.add_argument("--binaries", required=True)
    args = parser.parse_args()
    freeze_path = (BATCH / args.freeze).resolve()
    binaries_path = (BATCH / args.binaries).resolve()
    if not all(path.is_relative_to(BATCH) for path in (freeze_path, binaries_path)):
        raise ValueError("Metadata must be within the authorized batch")
    if any(
        re.search(r"-r[12]\.json$", path.name)
        for path in (freeze_path, binaries_path)
    ):
        raise ValueError("r1 and r2 execution revoked before any reviewer binary run")
    before = verify(freeze_path, binaries_path)
    write_json("freeze-before.json", before)
    if not before["valid"]:
        raise ValueError("Inputs or binary identity did not match")
    if before["actual_count"] != 724 or before["actual_aggregate"] != EXPECTED_R4_AGGREGATE:
        raise ValueError("Inputs differ from the user's final r4 freeze")
    if {role: len(names) for role, names in expected_tests().items()} != {
        "session": 21, "app": 5,
    }:
        raise ValueError("Source no longer contains all 21 session and 5 app tests")
    print(json.dumps({
        "freeze_valid": True,
        "count": before["actual_count"],
        "aggregate": before["actual_aggregate"],
        "new_test_counts": {role: len(names) for role, names in expected_tests().items()},
    }), flush=True)
    metadata = json.loads(binaries_path.read_text())
    git_head = bounded("head", ["git", "-c", "core.fsmonitor=false", "rev-parse", "HEAD"], 15)
    bounded("source-diff", [
        "git", "-c", "core.fsmonitor=false", "diff", "--no-ext-diff",
        "--unified=4", before["base"], "--", "crates/keelshell-app/src/monitor.rs",
        "crates/keelshell-app/src/monitor_capabilities.rs",
        "crates/keelshell-app/src/monitor_tests.rs",
        "crates/keelshell-app/src/monitor_tests/capabilities.rs",
        "crates/keelshell-app/src/monitor_tests/darwin.rs",
        "crates/keelshell-session/src/monitor.rs",
        "crates/keelshell-session/src/monitor/capabilities.rs",
        "crates/keelshell-session/tests/darwin_monitor_interop.rs",
    ], 20)
    inventories = {}
    for role in ("session", "app"):
        binary = metadata["binaries"][role]
        text = bounded(role + "-inventory", [
            binary["path"], "--list", "--color", "never",
        ], 30, binary)
        inventories[role] = inventory(text)
        write_json(role + "-inventory.json", {
            "names": inventories[role],
            "unique_count": len(inventories[role]),
            "binary": binary,
        })
    manifest_app_names = metadata.get("app_inventory_names")
    if manifest_app_names is not None and set(inventories["app"]) != set(manifest_app_names):
        raise ValueError("Fresh app inventory differs from parent metadata")
    if len(inventories["app"]) != 1369:
        raise ValueError("App inventory differs from the final r4 1369-name contract")
    if sorted(metadata["new_app_names"]) != expected_tests()["app"]:
        raise ValueError("New app names differ between source and binary metadata")
    runs = {}
    required = expected_tests()
    for role, seconds in (("app", 300), ("session", 180)):
        binary = metadata["binaries"][role]
        text = bounded(role + "-monitor", [
            binary["path"], "monitor::", "--test-threads=2", "--color", "never",
        ], seconds, binary)
        result = analyze_run(text, inventories[role], required[role])
        runs[role] = result
        write_json(role + "-monitor.analysis.json", result)
        print(json.dumps({
            "role": role,
            "valid_per_name": result["valid"],
            "passed": result["actual_passed"],
            "failed": result["actual_failed"],
            "ignored": result["actual_ignored"],
            "new_tests_ok": len(result["required_new_tests"]),
        }), flush=True)
        if not result["valid"]:
            raise ValueError("Per-name execution analysis failed: " + role)
    after = verify(freeze_path, binaries_path)
    write_json("freeze-after.json", after)
    stable = (
        before["actual_aggregate"] == after["actual_aggregate"]
        and before["adr"] == after["adr"]
        and before["freeze_sha256"] == after["freeze_sha256"]
        and before["metadata_sha256"] == after["metadata_sha256"]
        and before["binaries"] == after["binaries"]
    )
    r1_path = BATCH / "inputs-freeze-r1.json"
    r1 = json.loads(r1_path.read_text())
    old = {row["path"]: row for row in r1["inputs"]}
    new = {row["path"]: row for row in after["observed_inputs"]}
    delta = {
        "r1_aggregate": r1["aggregate_sha256"],
        "r1_expected_aggregate_matches_user": r1["aggregate_sha256"] == EXPECTED_R1_AGGREGATE,
        "current_aggregate": after["actual_aggregate"],
        "r1_binaries_executed_by_reviewer": 0,
        "r2_binaries_executed_by_reviewer": 0,
        "added": sorted(new.keys() - old.keys()),
        "removed": sorted(old.keys() - new.keys()),
        "changed": [
            {"path": path, "r1": old[path], "current": new[path]}
            for path in sorted(old.keys() & new.keys()) if old[path] != new[path]
        ],
    }
    write_json("r1-to-current-delta.json", delta)
    summary = {
        "observed_at_utc": utc(),
        "head": git_head.strip(),
        "aggregate": after["actual_aggregate"],
        "count": after["actual_count"],
        "freeze_before_after_valid": before["valid"] and after["valid"],
        "inputs_binaries_adr_metadata_unchanged_during_review": stable,
        "binaries": {role: metadata["binaries"][role] for role in ("app", "session")},
        "inventory_counts": {role: len(names) for role, names in inventories.items()},
        "runs": runs,
        "parent_prebuilt": True,
        "independent_compilation": False,
        "native_acceptance": False,
        "real_openssh_executions_by_reviewer": 0,
        "r1_executions_by_reviewer": 0,
        "r2_executions_by_reviewer": 0,
        "cargo_invocations": 0,
        "target_writes": 0,
        "scope": "Direct parent-prebuilt monitor module tests and read-only source/ADR review",
        "valid": after["valid"] and stable and all(run["valid"] for run in runs.values()),
    }
    write_json("execution-summary.json", summary)
    if not summary["valid"]:
        raise ValueError("Review inputs drifted")
    print("ALL_INVENTORY_AND_PER_NAME_CHECKS_PASSED", flush=True)


if __name__ == "__main__":
    main()
