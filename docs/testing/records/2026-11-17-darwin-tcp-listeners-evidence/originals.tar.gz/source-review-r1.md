**r2 最终源码结论：REQUEST_CHANGES。**

| P0 | P1 | P2 | P3 |
|---:|---:|---:|---:|
| 0 | 0 | **1** | 0 |

基线及 HEAD 均为 `8d95d71cfa08181d5d44b689c108edcad7d995c4`。r2 的 **724 个唯一路径、字节数、SHA-256 全部匹配，mismatch 0**，aggregate 重算为 `e480418560b3079aa08c32ca367d9238dc505a765b9e41ee718b0f73c9dc8bc0`。相对 r1 确实仅声明的 3 文件变化，三个新增 Rust 文件均已审阅。

**P2：缺失 Darwin 帧会回落至 Linux 解析器，错误发布 Available 空集合。**

位置：[crates/keelshell-session/src/monitor.rs:645](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor.rs:645)。

- **触发条件：** Darwin 采集响应整帧缺失，stdout 为空或仅空白，但 SSH 返回 `Some(0)`；即使 stderr 带警告，也存在相同路径。
- **原因：** 只有完整 START 前缀才进入 `darwin_sockets::parse()`。否则进入 `command_text()` → `checked_text()`，后者在 exit 0 时忽略 stderr；随后 `parse_sockets("")` 返回 `Ok([])`，并在 [monitor.rs:652](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor.rs:652) 记录为 Available。
- **影响：** 未经完整帧、lsof 真实状态及 stderr 校验的响应，被展示为“当前账户未观察到监听端口”，违反 ADR 的失败关闭合同。这是源码路径推导，本轮没有运行该负例。
- **现有测试缺口：** [darwin_sockets/tests.rs:97](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/darwin_sockets/tests.rs:97) 的无帧负例直接调用私有解析器；[tests.rs:596](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/darwin_sockets/tests.rs:596) 的公开入口测试未包含“空 stdout＋exit 0”，所以没有覆盖上述分派绕过。
- **建议：** 给 Linux、Darwin 返回增加明确的平台帧，再分派解析；为公开 `listening_sockets()` 补上无帧、stderr-only 成功退出负例，同时保留合法 Linux 空结果及 Darwin 完整帧 quiet-exit-1 空结果的正例。

r2 的 mapped 地址修订在源码层面可接受：只额外接受严格 `Ipv4Addr`，保留观察到的数字地址；括号内 IPv4、非法数字地址和非法 scope 仍被拒绝。新增 mapped listener 联调检查真实端点、TCP LISTEN 和完整 `(pid=…)`，具有行为意义。除上述 P2 外，指定差量中的 NUL／集合边界、状态与 stderr 校验、资源预算、负缓存／reset／迟到结果、暂停取消、Linux 原路径、未知平台 Probe 拒绝及 Darwin 无 Python 只读入口，未发现其他可报告问题。依赖、lock 和工具链策略差量为空。

**验证证据来自父级原件，我没有重跑测试：**

| 原件 | 实际结果 |
|---|---|
| r1 session 专项 | 19 passed / 0 failed / 0 ignored |
| 此前 app 专项 `app-darwin-r2` | 9 passed / 0 failed / 0 ignored，逐名与 inventory 相等 |
| r2 session 专项 | **20 passed / 0 failed / 0 ignored** |
| [r1 真实 OpenSSH](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/openssh-darwin-r1/tests.log:28) | **6 passed / 2 failed**，原失败保持 |
| [r2 真实 OpenSSH](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/openssh-darwin-r2/tests.log) | **9 passed / 0 failed / 0 ignored**，含新增 mapped listener |

上述专项日志的绑定哈希已核对；r2 OpenSSH wrapper 为 exit 0、reaped、active 0、pipes drained。历史 `app-darwin-r1` 实际筛选到 0 项；9 项通过对应的是修正过滤器后的 `app-darwin-r2`，不混写两者。

本轮实际执行了 `git --no-optional-locks rev-parse HEAD`、`status --short --untracked-files=all`、基线限定文件的 `diff --stat`／`diff --name-status`／`diff --no-ext-diff`／`diff --check`，以及 `rg`、`nl -ba`、`sed` 只读检索和 `python3 -B` 冻结、哈希、成员及回执核对。限定差量的 `git diff --check` 返回 0。

**我执行的 Cargo、Rust／GPUI／SSH 测试均为 0；没有编辑文件、格式化、写共享 target、commit、push 或清理。** 本结论覆盖指定源码范围；父级完整门禁、三平台原生桌面、安装与发行验收不在本次签署范围内。r2 真实 SSH 通过不消除上述未覆盖的帧分派缺陷。

<oai-mem-citation>
<citation_entries>
MEMORY.md:450-451|note=[strict read-only review and evidence reporting boundaries]
rollout_summaries/2026-11-04T08-34-45-IgTq-keelshell_workspace_window_switcher_verification.md:42-45|note=[distinguish source review from gates and native acceptance]
</citation_entries>
<rollout_ids>
01a1a5b2-40b8-7cb1-8de1-07ec8f4efa6c
</rollout_ids>
</oai-mem-citation>
