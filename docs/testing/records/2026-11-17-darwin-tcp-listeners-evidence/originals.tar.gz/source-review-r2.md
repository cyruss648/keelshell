**r4 最终限定源码结论：APPROVE。原 P2 已关闭，无新增可报告问题。**

| 当前 P0 | 当前 P1 | 当前 P2 | 当前 P3 |
|---:|---:|---:|---:|
| 0 | 0 | 0 | 0 |

这是同一非作者评审的修后窄差量复核。当前结论绑定 r4，不覆盖历史失败，也不代表完整产品、三平台原生桌面或发行验收。

基线及本次观察的 HEAD 均为 `8d95d71cfa08181d5d44b689c108edcad7d995c4`。冻结文件为 [inputs-freeze-r4.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/inputs-freeze-r4.json)，724 个唯一路径的成员、字节数和 SHA-256 全部匹配，missing 0、extra 0、mismatch 0。aggregate 独立重算为 `baae8aaab5903ad60509c23341b91a23553fac47ea7d1b0ff9ac993031c2e6ef`；冻结文件本身 SHA-256 为 `015e3b9e20b7dbb871fea260ac332be253b87091928673daa8399ae0775ff149`。

相对 r2，r3 只改变以下四文件；r4 相对 r3 仅改变第三项中的静态脚本断言。冻结清单的实际差量与声明一致，没有增删输入：

- [crates/keelshell-session/src/monitor.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor.rs)
- [crates/keelshell-app/src/monitor_tests.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_tests.rs)
- [crates/keelshell-session/src/monitor/darwin_sockets/tests.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/darwin_sockets/tests.rs)
- [scripts/monitor_recovery/fixture.py](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/monitor_recovery/fixture.py)

此前已经审阅的三个新增 Rust 文件及其余限定源码通过冻结差量保持绑定；本轮没有将未修改的历史欠账扩展为新发现。Cargo manifests、Cargo.lock、mise.toml 和工具链文件相对基线的差量为空。

**原 P2 的关闭依据。**

公开入口 [monitor.rs:635](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor.rs:635) 统一调用 `parse_socket_collection()`，原来“没有 Darwin START 就直接按 ss 解析”的路径已删除。

[monitor.rs:786](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor.rs:786) 先检查 combined stdout/stderr 的 2 MiB 预算与 SSH 退出状态；随后只有完整 Darwin START 可以进入既有严格 lsof 解析器，其余响应必须具有明确的 Linux START、ss-status 和结束标记。空 stdout、空白、stderr-only 或裸 ss 行不能到达纯 `parse_sockets()`。

[monitor.rs:809](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor.rs:809) 要求状态为有界十进制整数且结束帧完整；ss 非零状态或任意 stderr 均返回固定类型的不可用原因，原始远端诊断不进入错误文本。只有状态 0、无 stderr 的完整 Linux 帧才解析行数据，因此保留合法的 Linux 空集合。

[monitor.rs:103](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor.rs:103) 的 Linux 生产脚本在工具存在性检查后输出 START，执行固定 `ss -H -lntupn`，紧接着保存 `$?`，再输出独立的 ss-status/end。Darwin 固定 lsof 选择及其真实状态帧保持；完整、安静的 lsof exit 1 空集合仍由既有专用解析器处理。

[darwin_sockets/tests.rs:632](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/darwin_sockets/tests.rs:632) 从受控 SSH 调用公开 `listening_sockets()`：覆盖 empty、whitespace、stderr-only、unframed row、truncated Linux frame 和 Linux framed warning；每种情况均断言返回错误且能力不能成为 Available。最后用同一 SSH 夹具证明完整 Linux 空帧仍返回空集合并成为 Available。每次检查前 reset，避免前一个负缓存使后续负例空过；同一夹具的成功正例也防止所有请求均失败时产生假通过。

该公开入口用例已经在修前真实失败，修后 r3、r4 实际通过；不是仅调用私有解析器的断言。既有 Darwin quiet-exit-1 公开入口正例保留。r4 的 [tests.rs:338](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/darwin_sockets/tests.rs:338) 要求完整 ss 命令行、紧邻的 `ks_ss_status=$?`、Linux START/status/end，同时保留 Darwin 绝对 lsof 路径及禁止 sudo/kill/nc/UDP 等断言；行为断言没有放宽。

**受控响应和 Python ForceCommand 的检查。**

session 的 [monitor.rs:1479](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor.rs:1479) 与 app 的 [monitor_tests.rs:142](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_tests.rs:142) 已给成功 Linux 响应补齐平台、状态和结束帧；Darwin app 响应仍使用原严格帧。外层非零 SSH/命令失败继续走已有类型化错误路径。

通过 Python AST 仅重建常量表达式，独立确认 [fixture.py:87](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/monitor_recovery/fixture.py:87) 的 `SOCKETS` 与生产 Rust `SOCKETS_SCRIPT` 逐字节相等。该检查未执行 fixture runtime、远端命令或测试套件。

[fixture.py:106](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/monitor_recovery/fixture.py:106) 仍为四个固定 collector 字符串映射，包含资源采集的缓存变体。`collector_command()` 对 SOCKETS 只接受精确字典键；既有资源 wrapper 特例只返回精确已知 Linux body。`forced()` 在 [fixture.py:202](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/monitor_recovery/fixture.py:202) 先完成此校验，再查询固定映射和执行已接受的脚本。本次修改没有引入任意命令通道。既有 [test_monitor_recovery_lab.py:257](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_monitor_recovery_lab.py:257) 对生产常量做精确比较，并测试任意命令和变造 Linux body 被拒绝。

缓存 begin/record/reset、暂停/迟到结果的身份边界以及 app 的 Linux 动作门控均未在此次窄差量中改动。Darwin 账户可见 TCP LISTEN、无 Python 列表读取、未知平台不允许 Probe，以及不启用 Darwin UDP/nc/SIGTERM 的已审合同保持。

**父级实际验证原件。以下命令由父级执行，本评审只读取和核对回执，没有重跑。**

| 原件 | 实际结果 | 本次核对 |
|---|---|---|
| [missing-frame-negative-r1.log](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/missing-frame-negative-r1.log) | 0 passed / 1 failed / 0 ignored；exit 101 | 修前公开入口负例真实失败；日志字节数和绑定哈希匹配 |
| [session-monitor-r3.log](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/session-monitor-r3.log) | 101 passed / 1 failed / 0 ignored；exit 101 | P2 公开入口用例通过，唯一失败为旧静态 `ss ... || exit 65` 断言；原失败保持 |
| [forcecommand-contract-r3.log](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/forcecommand-contract-r3.log) | 27 run / 0 failed；exit 0 | 日志字节数和绑定哈希匹配；r4 未修改这些 Python 输入 |
| [session-monitor-r4.log](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/session-monitor-r4.log) | 102 passed / 0 failed / 0 ignored；exit 0 | 运行声明 102、逐名结果 102、唯一名称 102 相等，包含公开入口修复用例 |
| [openssh-darwin-r4/tests.log](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/openssh-darwin-r4/tests.log) | 9 passed / 0 failed / 0 ignored | 最终 frame 版本真实 Darwin OpenSSH，含 IPv4、IPv6、mapped listener 和已连接端点排除 |
| [darwin-openssh-r4.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/darwin-openssh-r4.json) | exit 0；controller 0 | wrapper 日志字节数和绑定哈希匹配；result 为 passed，清理报告 owned processes stopped |
| [format-r4.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/format-r4.json) | exit 0 | 父级格式化回执；本评审没有运行格式化 |

以上读取的命令回执均已 direct_reaped，active_processes 0，pipes_drained true，无 timeout/interruption。r4 session monitor 外层耗时 2.428s、测试摘要 0.16s；r4 Darwin OpenSSH 外层 4.582s、测试摘要 2.15s；Python 合同外层 1.780s、unittest 1.620s。没有将普通过滤计数冒充独立编译库存；本次没有获得 r4 monitor 的单独 `--list` 原件。Python 合同原日志无逐名输出，不补写逐名库存。

关键原件 SHA-256：

| 原件 | SHA-256 |
|---|---|
| missing-frame-negative-r1.log | `22f6b279d22dfe9d3994c815f64cb7fe45abafb53149e9cc115f210454b8f309` |
| session-monitor-r3.log | `6d2f6fac758625dbae2137ea6f8bdf5449a912b99128230d6892405fa81ff2b1` |
| forcecommand-contract-r3.log | `614897bada0655075e7fc6246ac15fe4145820bcea52c78c030323695b58fd9d` |
| session-monitor-r4.log | `e5ba24137bcbe6b54560905ed5119e55a5f222ea874505451d44e4903f04a80c` |
| openssh-darwin-r4/tests.log | `4ffd7f57af8e5508345bf87d82931eb176ec5196dcfabc28f9809cb17c2a0bf7` |

r3 的 101/1 结论按冻结补正记录为旧静态脚本断言失败；审阅期间关于“编译内容不一致”的初步判断不作为本报告结论，也不认定缓存缺陷。

**评审实际执行的命令与边界。**

本评审读取了 `/Users/hdh/.codex/RTK.md`、AGENTS.md、docs/HANDOFF.md、ADR 0152，以及四文件差量、必要调用上下文、测试与上述原始回执；使用 `cat`、`rg`、`nl -ba`、`sed` 和 `python3 -B` 进行只读检索、冻结/成员/哈希核对、常量重建和测试日志计数。

实际执行的 Git 差量命令为：

```sh
git --no-optional-locks rev-parse HEAD
git --no-optional-locks diff --no-ext-diff 8d95d71cfa08181d5d44b689c108edcad7d995c4 -- crates/keelshell-session/src/monitor.rs crates/keelshell-app/src/monitor_tests.rs scripts/monitor_recovery/fixture.py
git --no-optional-locks diff --check 8d95d71cfa08181d5d44b689c108edcad7d995c4 -- crates/keelshell-session/src/monitor.rs crates/keelshell-app/src/monitor_tests.rs scripts/monitor_recovery/fixture.py
git --no-optional-locks diff --name-only 8d95d71cfa08181d5d44b689c108edcad7d995c4 -- Cargo.lock Cargo.toml '**/Cargo.toml' mise.toml rust-toolchain rust-toolchain.toml
git --no-optional-locks ls-files -z --cached --others --exclude-standard -- .gitattributes .github .gitignore AGENTS.md CHANGELOG.md CONTRIBUTING.md Cargo.lock Cargo.toml README.en.md README.md assets crates mise.toml packaging scripts
```

限定 tracked 差量的 `git diff --check` 返回 0。新增 untracked Rust 测试文件通过冻结哈希和带行号全文审阅纳入，未声称 tracked diff 包含它。一次 `rg --files --hidden -g AGENTS.md scripts` 返回 1，表示未找到下级 AGENTS；一次检索使用了不存在的 `scripts/test_monitor_recovery.py`，随后通过 `rg --files` 定位并读取真实的 `scripts/test_monitor_recovery_lab.py`，未将该检索诊断当作测试结果。

本轮由评审执行的 Cargo、Rust/GPUI/SSH/Python unittest 测试、格式化、共享 target 写入、commit、push、清理均为 0。只新增用户指定的本报告；原 [source-review-r1.md](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-tcp-listeners-20261117/source-review-r1.md) 的 REQUEST_CHANGES、P2=1、r1 原生 SSH 6/2 和 r2 当时观察完整保留，其 SHA-256 仍为 `37fe844c71a3d8b501e3d02e3800a6e1347f5ec736c5ec6993f8d67f990e0148`。

本次 APPROVE 仅签署 r4 指定源码及纳入的 Python ForceCommand 窄差量。父级全量门禁、最终 frame 版本的 app 全量执行、真实 Linux ForceCommand 容器联调、三平台原生桌面、生产环境、安装与发行验收均不由本报告代签；Darwin localhost SSH 9/0 是传输/采集互操作证据，不等同原生桌面验收。
