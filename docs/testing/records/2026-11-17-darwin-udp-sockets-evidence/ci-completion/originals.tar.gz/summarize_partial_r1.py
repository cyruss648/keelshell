"""Keep completed prefixes and observed aborted-app results distinct."""
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import re

BASE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("strict_ci_parser", BASE / "summarize_tests.py")
parser = importlib.util.module_from_spec(spec)
spec.loader.exec_module(parser)


def summarize_failure(raw):
    text = parser.normalize(raw)
    header = re.search(
        r"^.*Running unittests src/main\.rs \([^\n]*keelshell_app[^\n]*\)$", text, re.M,
    )
    assert header is not None
    # The unchanged strict parser still validates every completed prefix suite.
    prefix = parser.summarize(text[:header.start()].encode())
    tail = text[header.start():]
    declared = re.search(r"^running (\d+) tests$", tail, re.M)
    assert declared is not None
    assert not re.search(r"^test result:", tail, re.M)
    outcomes = re.findall(r"^test (\S+) \.\.\. (ok|FAILED|ignored)(?:,.*)?$", tail, re.M)
    assert len(outcomes) == len({name for name, _ in outcomes})
    overflow = re.findall(r"thread '([^']+)' .*has overflowed its stack", tail)
    assert len(overflow) == 1
    observed = Counter(result for _, result in outcomes)
    assert int(declared[1]) > len(outcomes)
    return {
        "raw_bytes": len(raw), "raw_sha256": hashlib.sha256(raw).hexdigest(),
        "completed_prefix": prefix,
        "aborted_app": {
            "header": header.group(), "declared": int(declared[1]),
            "observed_result_count": len(outcomes), "observed_counts": dict(observed),
            "unreported_count": int(declared[1]) - len(outcomes),
            "results": outcomes, "stack_overflow_test": overflow[0],
            "complete_summary_present": False, "full_app_passed": False,
        },
        "workspace_gate_passed": False, "tests_replayed": 0,
    }


def main():
    summary = {"source": "16703293012d798f885e1590f02c348c47e81a10",
               "run": 43945988599, "jobs": [], "tests_replayed": 0}
    for job in (133575666946, 133575666982):
        source = BASE / f"job-{job}-failure-r1.log"
        result = summarize_failure(source.read_bytes())
        output = BASE / f"job-{job}-partial-r1.json"
        with output.open("x") as stream:
            json.dump(result, stream, indent=2)
            stream.write("\n")
        summary["jobs"].append({
            "job": job, "file": source.name, "sha256": result["raw_sha256"],
            "completed_prefix_suites": len(result["completed_prefix"]["suites"]),
            "aborted_app": {key: value for key, value in result["aborted_app"].items()
                            if key != "results"},
        })
    with (BASE / "partial-summary-r1.json").open("x") as stream:
        json.dump(summary, stream, indent=2)
        stream.write("\n")
    print(json.dumps(summary))


if __name__ == "__main__":
    main()
