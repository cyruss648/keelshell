"""Seal a fixed completed delivery subset while the separate CI watch runs."""
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

base = Path(__file__).resolve().parent
root = base.parents[1]
destination = root / "docs/testing/records/2026-11-17-darwin-udp-sockets-evidence/delivery"
labels = (
    "feature-commit-r1", "feature-push-r1", "feature-git-binding-r1",
    "package-r1", "package-inspect-r1", "ci-initial-r1", "ci-current-r1",
    "rust-environment-r1", "sealed-verify-r2",
)
names = [
    *(label + suffix for label in labels for suffix in (".json", ".log")),
    "feature-readback-r1.json", "normal-package-r1.json",
    "package-manifest-r1.json", "cleanup-r1.json",
    "commit-inputs-before-r1.json", "run_command.py", "seal_delivery_r1.py",
]
payloads = {name: (base / name).read_bytes() for name in sorted(names)}
assert len(payloads) == len(names)
rows = [
    {"path": name, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
    for name, raw in payloads.items()
]
buffer = io.BytesIO()
with gzip.GzipFile(fileobj=buffer, mode="wb", filename="", mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as archive:
        for row in rows:
            member = tarfile.TarInfo(row["path"])
            member.size = row["bytes"]
            member.mode = 0o644
            archive.addfile(member, io.BytesIO(payloads[row["path"]]))
raw = buffer.getvalue()
manifest = {
    "sealed_utc": datetime.now(timezone.utc).isoformat(),
    "count": len(rows), "archive_bytes": len(raw),
    "archive_sha256": hashlib.sha256(raw).hexdigest(), "entries": rows,
    "excluded": ["Active CI watch", "Application packages and binaries"],
}
for name, data in payloads.items():
    assert (base / name).read_bytes() == data
with (destination / "originals.tar.gz").open("xb") as output:
    output.write(raw)
with (destination / "manifest.json").open("x") as output:
    json.dump(manifest, output, indent=2)
    output.write("\n")
print(json.dumps({key: value for key, value in manifest.items() if key != "entries"}))
