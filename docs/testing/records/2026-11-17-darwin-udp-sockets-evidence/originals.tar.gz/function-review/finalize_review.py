"""Write the bounded functional review using only observed local evidence."""
from datetime import datetime, timezone
import json
from pathlib import Path

from review_runner import BASE, BATCH, OUT, ROOT, digest, run, write_json

before = json.loads((OUT / "integrity-before.json").read_text())
after = json.loads((OUT / "integrity-after.json").read_text())
evidence = json.loads((OUT / "evidence-verification.json").read_text())
assert before["inputs"] == after["inputs"]
assert before["binaries"] == after["binaries"]
assert before["aggregate_sha256"] == after["aggregate_sha256"]
assert not before["mismatches"] and not after["mismatches"]
doc_changes = [
    p for p, value in before["documents_outside_engineering_freeze"].items()
    if value != after["documents_outside_engineering_freeze"][p]
]
assert doc_changes == ["docs/HANDOFF.md"], doc_changes
receipt, _, _ = run("concurrent-handoff-diff", [
    "git", "diff", "--no-ext-diff", BASE, "--", "docs/HANDOFF.md",
])
assert receipt["exit"] == 0
commands = [json.loads(line) for line in (OUT / "commands.jsonl").read_text().splitlines()]
assert all(c["exit"] == 0 and c["waited"] and not c["timed_out"] for c in commands)
assert all(c["elapsed_seconds"] < 180 for c in commands)
coverage = evidence["new_test_coverage"]
assert sum(c["passed"] for c in coverage.values()) == 69
gate_r2_exists = (BATCH / "full-gate-r2.json").exists()


def location(path, line):
    return {"path": str(ROOT / path), "line": line}


reviewed_paths = [
    {
        "topic": "固定只读命令和独立帧",
        "trigger": "Darwin TCP LISTEN 与 UDP 混合读取，Linux 原有读取",
        "assessment": "Darwin 使用 frame2 和绝对系统 lsof；Linux 的 ss 与 frame1 保持。没有主动探测、提权或终止命令。",
        "locations": [location("crates/keelshell-session/src/monitor.rs", 85),
                      location("crates/keelshell-session/src/monitor/darwin_sockets/tests.rs", 340)],
    },
    {
        "topic": "UDP 语义、严格输入与过滤预算",
        "trigger": "bound、peer、双栈、scope、wildcard、未绑定、重复身份、警告、截断和超量输出",
        "assessment": "TCP 五字段并限定 LISTEN；UDP 四字段且无 T。未绑定只过滤精确 *:*，先验证进程/FD并计入10000全局预算。完整帧、SSH exit、lsof status、stderr和2MiB总输出共同决定可用性。",
        "locations": [location("crates/keelshell-session/src/monitor/darwin_sockets.rs", 25),
                      location("crates/keelshell-session/src/monitor/darwin_sockets.rs", 63),
                      location("crates/keelshell-session/src/monitor/darwin_sockets.rs", 130),
                      location("crates/keelshell-session/src/monitor/darwin_sockets.rs", 207)],
    },
    {
        "topic": "负缓存、reset 与迟到",
        "trigger": "工具缺失/权限/格式失败后重试、SSH故障、reset、暂停ABA、retire与过期报告",
        "assessment": "非Transport负项仅显式reset重试；Transport保留可重试。连接身份与generation/revision撤销旧能力报告；UI另拒绝旧sample generation和过期结果。相应既有回归在本次33和36组内执行ok。",
        "locations": [location("crates/keelshell-session/src/monitor/capabilities.rs", 148),
                      location("crates/keelshell-session/src/monitor/capabilities.rs", 162),
                      location("crates/keelshell-session/src/monitor/capabilities.rs", 214),
                      location("crates/keelshell-app/src/monitor.rs", 277),
                      location("crates/keelshell-app/src/monitor_capabilities.rs", 25)],
    },
    {
        "topic": "三主题、明暗、双语与 AX",
        "trigger": "Frost/Graphite/Lavender、Light/Dark、ZhCn/En切换及显示端点截断",
        "assessment": "BOUND/PEER使用中英文形状标签和账户可见/不代表健康说明，未套用成功色或连通承诺。完整端点/进程进入行Group AX名称，显示行分层并截断；切换只重绘缓存。新用例遍历3×2×2矩阵，无额外SSH命令。长文本原生朗读和视觉效果未验。",
        "locations": [location("crates/keelshell-app/src/monitor.rs", 1351),
                      location("crates/keelshell-app/src/monitor.rs", 1402),
                      location("crates/keelshell-app/src/monitor_tests/darwin_sockets.rs", 217)],
    },
    {
        "topic": "分页、可达性与刷新夹紧",
        "trigger": "25行按12/12/1浏览、末页、上一页、切换英文、刷新为3行或失败空列表",
        "assessment": "全局行ID由enumerate后skip/take保留，前后页只修改缓存页码；next使用当前长度检查。replace_sockets夹紧到合法页并清空探测结果，成功与失败两类接收路径均调用。测试逐名包含0..24全部行，实际滚到pager视区后click，并验证按钮边界、返回和刷新夹紧。失败为空的夹紧由源码审查覆盖；新增分页用例使用480×900受控窗口，未扩称三平台或所有尺寸原生验收。",
        "locations": [location("crates/keelshell-app/src/monitor.rs", 396),
                      location("crates/keelshell-app/src/monitor.rs", 431),
                      location("crates/keelshell-app/src/monitor.rs", 533),
                      location("crates/keelshell-app/src/monitor.rs", 1394),
                      location("crates/keelshell-app/src/monitor.rs", 1512),
                      location("crates/keelshell-app/src/monitor.rs", 1781),
                      location("crates/keelshell-app/src/monitor_tests/darwin_sockets.rs", 28),
                      location("crates/keelshell-app/src/monitor_tests/darwin_sockets.rs", 313)],
    },
    {
        "topic": "Darwin 主动动作边界",
        "trigger": "有/无资源采样的UDP行、Darwin TCP行、未知平台、直接Job分派",
        "assessment": "UI只在Linux资源采样下提供TCP探测/进程核对与终止；run入口对三类动作再次拒绝。Darwin和未知平台无按钮和动作命令；session的UDP probe先拒绝非TCP，Darwin TCP/进程动作保留远端Linux守卫。未授予UDP任何主动动作。",
        "locations": [location("crates/keelshell-app/src/monitor.rs", 548),
                      location("crates/keelshell-app/src/monitor.rs", 658),
                      location("crates/keelshell-app/src/monitor.rs", 1474),
                      location("crates/keelshell-app/src/monitor_tests/darwin_sockets.rs", 285),
                      location("crates/keelshell-session/src/monitor.rs", 670)],
    },
    {
        "topic": "真实自有 UDP 和 TCP 排除的证据",
        "trigger": "IPv4/IPv6 bound、wildcard、精确peer、保持未绑定FD存活的子工装、TCP client",
        "assessment": "对照源码与既存tests.log核对全部15个唯一名字。断言绑定自有PID及精确local/peer；未绑定子工装有有界启动/退出和Drop兜底；组合用例排除自有TCP客户端。result.json与外层回执证明已回收和fixture清理；复核员未启动标准OpenSSH或访问其密钥。",
        "locations": [location("crates/keelshell-session/tests/darwin_monitor_interop/udp.rs", 17),
                      location("crates/keelshell-session/tests/darwin_monitor_interop/udp.rs", 58),
                      location("crates/keelshell-session/tests/darwin_monitor_interop/udp.rs", 148),
                      location("crates/keelshell-session/tests/darwin_monitor_interop/udp.rs", 235),
                      location("crates/keelshell-session/tests/darwin_monitor_interop/udp.rs", 262)],
    },
]

result = {
    "schema": 1,
    "review_kind": "independent_non_author_read_only_functional",
    "review_date_local": "2026-11-17",
    "completed_utc": datetime.now(timezone.utc).isoformat(),
    "recommendation": "APPROVE",
    "approval_scope": "Darwin UDP and cached socket pagination increment at r3; parent-produced private test copies, independent execution and source/evidence review",
    "severity_counts": {"P0": 0, "P1": 0, "P2": 0, "P3": 0},
    "findings": [],
    "source": {
        "checkout": str(ROOT), "base": BASE, "head_before": before["head"],
        "head_after": after["head"], "frozen_revision": "r3",
        "frozen_input_count": 729, "aggregate_sha256": after["aggregate_sha256"],
        "freeze_r2": str(BATCH / "inputs-freeze-r2.json"),
        "freeze_r3": str(BATCH / "inputs-freeze-r3.json"),
        "inputs_before_after_identical": True, "input_mismatches": 0,
        "r2_to_r3": evidence["r2_to_r3"],
        "documentation_excluded_by_freeze_algorithm": True,
        "concurrent_documentation_changes": doc_changes,
        "concurrent_handoff_changes_reviewed_for_scope_only": True,
        "later_handoff_ci_claims_signed_by_this_review": False,
    },
    "prebuilt": {
        "produced_by_parent": True, "independent_compilations": 0,
        "cargo_commands": 0, "shared_target_accesses": 0,
        "source_artifacts_independently_opened": False,
        "before_after_identical_including_device_inode_mtime": True,
        "copies": after["binaries"],
        "linkage_inspected_on_private_copies_only": True,
        "source_to_binary_provenance_limit": "Parent-reported build/source artifact provenance; copied bytes and all expected new inventory/result names independently verified. No independent compilation.",
    },
    "commands": {
        "prebuilt_command_count": 4, "inventory_commands": 2,
        "test_execution_commands": 2, "repeated_test_execution_commands": 0,
        "recorded_subprocess_commands": len(commands),
        "recorded_subprocesses_waited": len(commands),
        "recorded_subprocess_nonzero": 0,
        "recorded_subprocess_timeouts": 0,
        "all_recorded_elapsed_seconds_less_than_180": True,
        "app_test_budget_seconds": 90,
        "session_test_budget_seconds": 170,
        "log": str(OUT / "commands.jsonl"),
        "counting_note": "Recorded subprocess invocations include inventory, execution, otool, read-only Git commands and the successful evidence-verifier wrapper with its nested commands. Shell/source reading tool calls are not counted as test commands. One initial reviewer-helper failure is retained separately.",
        "initial_reviewer_helper_failures": 1,
        "diagnostics": str(OUT / "reviewer-diagnostics.json"),
    },
    "independent_tests": {
        "passed": 69, "failed": 0, "ignored": 0,
        "app": coverage["app"], "session": coverage["session"],
        "all_inventory_selected_names_equal_executed_names": True,
        "all_18_required_new_names_present_and_ok": True,
    },
    "parent_ssh_evidence": evidence["ssh_parent_evidence"],
    "preserved_parent_failures": evidence["preserved_failures"],
    "reviewed_paths_and_triggers": reviewed_paths,
    "boundaries": {
        "independent_native_desktop_actions": 0,
        "independent_native_screenshots": 0,
        "independent_native_app_launches": 0,
        "independent_openssh_fixture_reruns": 0,
        "existing_fixture_credentials_read_or_used": False,
        "controller_tests_are_native_desktop_acceptance": False,
        "windows_or_linux_runtime_tested": False,
        "whole_product_or_release_acceptance": False,
        "parent_full_gate_r2_receipt_exists_at_finalization": gate_r2_exists,
        "parent_full_gate_r2_signed_or_assumed_success": False,
        "dependency_latest_version_status": "UNKNOWN retained from parent; no independent online recheck; manifest and lock unchanged",
        "forbidden_mutations": {
            "source_edits": 0, "format_commands": 0, "cargo": 0,
            "commits": 0, "pushes": 0, "cleanup_commands": 0,
            "shared_target_reads": 0, "shared_target_writes": 0,
        },
        "writes_confined_to": str(OUT),
    },
    "artifacts": {
        "report": str(OUT / "review.md"),
        "integrity_before": str(OUT / "integrity-before.json"),
        "integrity_after": str(OUT / "integrity-after.json"),
        "evidence_verification": str(OUT / "evidence-verification.json"),
        "app_inventory": str(OUT / "app-inventory.json"),
        "session_inventory": str(OUT / "session-inventory.json"),
        "app_results": str(OUT / "app-monitor.results.json"),
        "session_results": str(OUT / "session-darwin-sockets.results.json"),
        "parent_original_copies": str(OUT / "parent-originals"),
    },
}
write_json("summary.json", result)

lines = [
    "**KeelShell Darwin UDP＋端口分页：独立非作者只读功能复核（2026-11-17）**",
    "",
    "**结论：APPROVE，限本次 r3 功能增量。P0=0、P1=0、P2=0、P3=0。** 未发现需要修复的可复现缺陷；问题列表为空，因此无缺陷触发／影响条目。下面列出实际审查的触发条件、实现位置与验证边界。",
    "",
    f"checkout：`{ROOT}`；base、前后 HEAD 均为 `{BASE}`，审查对象包含工作差分和本片新增源文件。先读取 AGENTS、RTK、HANDOFF、SHARED_TARGET 与 ADR0154。使用 Rust 审查指引；当前用户的禁 Cargo／共享 target 约束优先。",
    "",
    f"最终冻结为 `{BATCH / 'inputs-freeze-r3.json'}`，729 输入，aggregate `{after['aggregate_sha256']}`。r2 和 r3 冻结自身均独立重算一致；当前729输入逐项／字节数／SHA在执行前后均相等，零 mismatch。记录时点为 `{before['captured_utc']}` 至 `{after['captured_utc']}`。",
    "",
    "r2 aggregate 为 `ad6a7b3d3bf471c833301373b3d89b768e48258b4afda15ae6f561059da2ab09`；r2→r3 只有 `scripts/monitor_recovery/fixture.py:92`、`:93` 两行静态镜像同步：frame1→frame2、增加 `-iUDP`。先用 base Git blob 证明旧 fixture 与r2 SHA相同，再验证当前内容仅含这两个替换，并用受限 AST 字符串提取证明 Python SOCKETS 与 Rust SOCKETS_SCRIPT 完全相同，未导入或运行 fixture。其余728输入（含全部Rust、manifest、lock）不变，不重跑已完成Rust测试。",
    "",
    "729输入的原冻结算法排除了 docs/ 与 .hallmark/，不能声称所有文档都冻结。额外记录了六份约束／设计文档摘要；期间仅 HANDOFF 由父级补写了当前批次和前批CI状态，已补读其diff并保存在 concurrent-handoff-diff.stdout.log。本报告不签署该CI／后续交付叙述；ADR0154、SHARED_TARGET、产品能力和设计文档摘要未变。",
    "",
    "**私有 prebuilt 来源与完整性**",
    "",
    "两文件由父级复制，本复核没有独立编译。source_artifact 路径只从 review-prebuilt-r1.json 作为父级来源声明读取，未访问该目标。独立核对副本字节数、SHA，以及前后 device／inode／mtime；otool仅检查私有副本，动态依赖为系统库。",
    "",
    "| 副本 | 字节数 | 前后 SHA-256 |",
    "| --- | ---: | --- |",
]
for key, row in after["binaries"].items():
    lines.append(f"| `{row['path']}` | {row['bytes']} | `{row['sha256']}` |")
lines += [
    "",
    "库存和新增名字核对提高本次副本的可审查性，但来源仍是父级构建声明，不能将其写成复核员新编译。独立编译0，Cargo0，共享target读写0。",
    "",
    "**独立执行及命令数**",
    "",
    f"prebuilt命令共4条：独立 `--list` 2条、测试执行2条，无重试或重复测试。另有只读Git／系统链接检查／证据脚本等，commands.jsonl共{len(commands)}条子进程记录，全部真实wait、stdout/stderr排空、exit0、无超时；嵌套脚本与子命令按各自进程计数，常规源码读取不计入测试命令。最初证据辅助脚本一次ValueError退出1，单独保存在reviewer-diagnostics.json；修订的是报告目录内的提取器，测试未重跑。",
    "",
    "| 命令（均使用 package-review-prebuilt 的绝对路径） | 预算 | 外层实耗 | exit | 库存/结果 |",
    "| --- | ---: | ---: | ---: | --- |",
]
for label in ("app-inventory", "session-inventory", "app-monitor", "session-darwin-sockets"):
    r = json.loads((OUT / f"{label}.exit.json").read_text())
    args = " ".join(r["argv"][1:])
    key = "app" if label.startswith("app") else "session"
    desc = f"{coverage[key]['inventory_total']}名库存" if "inventory" in label else f"{coverage[key]['passed']}/0/0 passed/failed/ignored"
    lines.append(f"| `{key} {args}` | {r['timeout_seconds']}s | {r['elapsed_seconds']:.6f}s | {r['exit']} | {desc} |")
lines += [
    "",
    "**实际独立测试合计69 passed／0 failed／0 ignored**：app `monitor::tests` 全33项在90s内完成（未缩组），session `monitor::darwin_sockets::tests` 全36项。两组筛选库存与逐名执行结果完全相等；全局库存分别1377／358名。所有命令的argv、cwd、时间、stdout/stderr字节与SHA、exit、耗时、wait状态见各 `*.exit.json`、`*.stdout.log`、`*.stderr.log`；名字与统计另见两个 `*.results.json`。",
    "",
    "下面18个新增用例从当前源文件函数名独立提取，再与父级expected参考、独立库存及实际ok结果交叉核对；全部在库存中且执行ok。原有app TCP按钮用例有一次改名，单独记为既有用例，未计入新增3项。",
    "",
]
for key in ("app", "session"):
    lines.append(f"**{key}新增{coverage[key]['new_count']}项**")
    lines.append("")
    for item in coverage[key]["required_new_tests"]:
        lines.append(f"- `{item['name']}` — inventory存在，执行ok。")
    lines.append("")
lines += ["**实现与行为审查**", ""]
for item in reviewed_paths:
    refs = "；".join(
        f"[{Path(loc['path']).name}:{loc['line']}]({loc['path']}:{loc['line']})"
        for loc in item["locations"]
    )
    lines += [
        f"- **{item['topic']}**：触发为{item['trigger']}。{item['assessment']} 证据：{refs}。",
    ]
lines += [
    "",
    "**真实SSH既存原件与清理**",
    "",
    f"独立读取 `{BATCH / 'darwin-ssh-r1/result.json'}`、`tests.log` 和外层 `{BATCH / 'darwin-ssh-r1.json'}`，没有启动标准OpenSSH fixture或读取其密钥。15个唯一名字与当前9个原测试＋6个UDP新测试完全相等，全部ok，汇总真实15/0/0。result的tests步骤exit0、日志1500字节及passed_tests=15一致；外层日志字节/SHA独立匹配，exit0，实耗4.931470s，direct_reaped=true、active_processes=0、pipes_drained=true、errors=[]。源码覆盖自有双栈bound/wildcard/peer/unbound及TCP客户端排除。",
    "",
    "result.json:67的cleanup为observed_processes_stopped=true、owned_processes_stopped=true、ancestry_unverified=[]、tracked_process_identities=77、temporary_directory_removed=true；另只检查该workspace内临时目录当前不存在。保留其累计祖先观测／kernel birth identity边界，不推演为对所有未观察到后代的无限保证。记录属于父级真实SSH执行，本复核真实SSH执行0；与独立69项分开，不合并成84项独立测试。",
    "",
    "**原失败和未验收边界**",
    "",
    "- 父focused r1：session36/0/0；app11/1/0、exit101，真实触发是pager未在视区内，Kit拒绝点击。r1→r2只增加生产monitor-scroll上的有界滚动及可见性断言，再执行click；父app r2为12/0/0。本次相应用例也独立ok，原失败保留在parent-originals，不补签r1通过。",
    "- 父full-gate-r1：exit1/reaped/12.072717s；Python293 run、290 passed、1 failed、2 skipped，未到Rust。失败是fixture精确命令镜像仍为frame1／TCP-only；r3两行修订和字面相等已静态核对。full-gate-r2仍由父级负责，本报告不宣告其成功，也未等待或重放完整gate。",
    "- 本次所有GPUI结果为受控窗口／控制器、布局和AX属性测试。新增分页例为480×900窗口，测试证明滚动后pager可点和每页行集合完整；未对每行另做原生指针点击，也未把它扩成所有尺寸的键盘／辅助技术或原生桌面验收。长端点／进程完整AX拼接由源码确认，真实VoiceOver朗读未验。",
    "- 原生桌面操作／截图／启动／安装均0；Windows、Linux运行0；正常包、三平台桌面、发行和完整产品未验。父级依赖在线最新版本UNKNOWN保持，manifest／lock未变；本次未进行在线重查。",
    "- 本复核只写function-review中的报告、脚本、日志及私有临时测试目录；源码修改、format、commit、push、清理和共享target读写均0。prebuilt内部使用自有受控测试peer，不接入外部机器或复用标准OpenSSH凭据。",
    "",
    f"机器摘要：[{OUT / 'summary.json'}]({OUT / 'summary.json'})。完整执行台账：[{OUT / 'commands.jsonl'}]({OUT / 'commands.jsonl'})。前后输入／副本摘要、逐名结果及父级失败和SSH原件副本均保存在同一目录。功能复核完成，结论APPROVE限上述r3增量与证据边界。",
]
(OUT / "review.md").write_text("\n".join(lines) + "\n")
write_json("report-digests.json", {
    "review": digest(OUT / "review.md"),
    "summary": digest(OUT / "summary.json"),
    "commands": digest(OUT / "commands.jsonl"),
})
print(json.dumps({
    "recommendation": result["recommendation"],
    "severity_counts": result["severity_counts"],
    "independent_tests": {"passed": 69, "failed": 0, "ignored": 0},
    "prebuilt_commands": 4,
    "recorded_subprocess_commands": len(commands),
    "report": str(OUT / "review.md"),
    "summary": str(OUT / "summary.json"),
}, ensure_ascii=False), flush=True)
