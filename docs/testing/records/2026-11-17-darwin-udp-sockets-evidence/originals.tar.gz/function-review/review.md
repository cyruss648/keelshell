**KeelShell Darwin UDP＋端口分页：独立非作者只读功能复核（2026-11-17）**

**结论：APPROVE，限本次 r3 功能增量。P0=0、P1=0、P2=0、P3=0。** 未发现需要修复的可复现缺陷；问题列表为空，因此无缺陷触发／影响条目。下面列出实际审查的触发条件、实现位置与验证边界。

checkout：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`；base、前后 HEAD 均为 `e1f7359a975726dc6cf110fb12edcbb8a582cd95`，审查对象包含工作差分和本片新增源文件。先读取 AGENTS、RTK、HANDOFF、SHARED_TARGET 与 ADR0154。使用 Rust 审查指引；当前用户的禁 Cargo／共享 target 约束优先。

最终冻结为 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-udp-20261117/inputs-freeze-r3.json`，729 输入，aggregate `e94405c2858d9796d9256dfd44eb277914c18fedd14e258e8025c747528e9a0e`。r2 和 r3 冻结自身均独立重算一致；当前729输入逐项／字节数／SHA在执行前后均相等，零 mismatch。记录时点为 `2026-11-16T19:41:25.828733+00:00` 至 `2026-11-16T19:46:05.645895+00:00`。

r2 aggregate 为 `ad6a7b3d3bf471c833301373b3d89b768e48258b4afda15ae6f561059da2ab09`；r2→r3 只有 `scripts/monitor_recovery/fixture.py:92`、`:93` 两行静态镜像同步：frame1→frame2、增加 `-iUDP`。先用 base Git blob 证明旧 fixture 与r2 SHA相同，再验证当前内容仅含这两个替换，并用受限 AST 字符串提取证明 Python SOCKETS 与 Rust SOCKETS_SCRIPT 完全相同，未导入或运行 fixture。其余728输入（含全部Rust、manifest、lock）不变，不重跑已完成Rust测试。

729输入的原冻结算法排除了 docs/ 与 .hallmark/，不能声称所有文档都冻结。额外记录了六份约束／设计文档摘要；期间仅 HANDOFF 由父级补写了当前批次和前批CI状态，已补读其diff并保存在 concurrent-handoff-diff.stdout.log。本报告不签署该CI／后续交付叙述；ADR0154、SHARED_TARGET、产品能力和设计文档摘要未变。

**私有 prebuilt 来源与完整性**

两文件由父级复制，本复核没有独立编译。source_artifact 路径只从 review-prebuilt-r1.json 作为父级来源声明读取，未访问该目标。独立核对副本字节数、SHA，以及前后 device／inode／mtime；otool仅检查私有副本，动态依赖为系统库。

| 副本 | 字节数 | 前后 SHA-256 |
| --- | ---: | --- |
| `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-udp-20261117/package-review-prebuilt/app` | 274016496 | `1ac9094c489f26eba5d38d98fe257ac5a1cce22b3802b091bf43fa232a9db576` |
| `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-udp-20261117/package-review-prebuilt/session` | 42815840 | `770a3873fa1be7832d1cac9efd4051f8229f7070005f9c075d6fff538fb4f0d5` |

库存和新增名字核对提高本次副本的可审查性，但来源仍是父级构建声明，不能将其写成复核员新编译。独立编译0，Cargo0，共享target读写0。

**独立执行及命令数**

prebuilt命令共4条：独立 `--list` 2条、测试执行2条，无重试或重复测试。另有只读Git／系统链接检查／证据脚本等，commands.jsonl共19条子进程记录，全部真实wait、stdout/stderr排空、exit0、无超时；嵌套脚本与子命令按各自进程计数，常规源码读取不计入测试命令。最初证据辅助脚本一次ValueError退出1，单独保存在reviewer-diagnostics.json；修订的是报告目录内的提取器，测试未重跑。

| 命令（均使用 package-review-prebuilt 的绝对路径） | 预算 | 外层实耗 | exit | 库存/结果 |
| --- | ---: | ---: | ---: | --- |
| `app --list` | 30s | 1.575633s | 0 | 1377名库存 |
| `session --list` | 30s | 0.509005s | 0 | 358名库存 |
| `app monitor::tests --test-threads=1 --nocapture` | 90s | 30.967500s | 0 | 33/0/0 passed/failed/ignored |
| `session monitor::darwin_sockets::tests --test-threads=1 --nocapture` | 170s | 0.186809s | 0 | 36/0/0 passed/failed/ignored |

**实际独立测试合计69 passed／0 failed／0 ignored**：app `monitor::tests` 全33项在90s内完成（未缩组），session `monitor::darwin_sockets::tests` 全36项。两组筛选库存与逐名执行结果完全相等；全局库存分别1377／358名。所有命令的argv、cwd、时间、stdout/stderr字节与SHA、exit、耗时、wait状态见各 `*.exit.json`、`*.stdout.log`、`*.stderr.log`；名字与统计另见两个 `*.results.json`。

下面18个新增用例从当前源文件函数名独立提取，再与父级expected参考、独立库存及实际ok结果交叉核对；全部在库存中且执行ok。原有app TCP按钮用例有一次改名，单独记为既有用例，未计入新增3项。

**app新增3项**

- `monitor::tests::darwin_sockets::darwin_udp_probe_dispatch_stays_read_only_with_and_without_resource_sample` — inventory存在，执行ok。
- `monitor::tests::darwin_sockets::darwin_udp_rows_retain_endpoints_across_themes_and_languages_without_io` — inventory存在，执行ok。
- `monitor::tests::darwin_sockets::socket_pagination_reaches_every_cached_row_without_ssh_and_clamps_on_refresh` — inventory存在，执行ok。

**session新增15项**

- `monitor::darwin_sockets::tests::udp::darwin_udp_and_tcp_share_pid_and_accept_udp_field_order` — inventory存在，执行ok。
- `monitor::darwin_sockets::tests::udp::darwin_udp_bound_addresses_preserve_families_and_normalize_wildcards` — inventory存在，执行ok。
- `monitor::darwin_sockets::tests::udp::darwin_udp_descriptor_budget_includes_filtered_objects_across_processes` — inventory存在，执行ok。
- `monitor::darwin_sockets::tests::udp::darwin_udp_nonempty_all_unbound_exit_zero_is_a_valid_empty_collection` — inventory存在，执行ok。
- `monitor::darwin_sockets::tests::udp::darwin_udp_peer_address_shape_preserves_both_endpoints_without_kernel_state` — inventory存在，执行ok。
- `monitor::darwin_sockets::tests::udp::darwin_udp_protocol_and_family_are_exact_even_for_unbound_objects` — inventory存在，执行ok。
- `monitor::darwin_sockets::tests::udp::darwin_udp_rejects_malformed_endpoints_arrows_wildcard_peers_and_ports` — inventory存在，执行ok。
- `monitor::darwin_sockets::tests::udp::darwin_udp_requires_each_of_four_fields_once_and_forbids_tcp_state` — inventory存在，执行ok。
- `monitor::darwin_sockets::tests::udp::darwin_udp_truncation_encoding_and_failed_status_never_become_empty_success` — inventory存在，执行ok。
- `monitor::darwin_sockets::tests::udp::darwin_udp_unbound_filter_never_silently_discards_invalid_mixed_records` — inventory存在，执行ok。
- `monitor::darwin_sockets::tests::udp::darwin_udp_unbound_filter_still_validates_process_and_descriptor` — inventory存在，执行ok。
- `monitor::darwin_sockets::tests::udp::darwin_udp_unbound_objects_do_not_hide_duplicate_pid_or_descriptor` — inventory存在，执行ok。
- `monitor::darwin_sockets::tests::udp::ssh_darwin_udp_combined_output_overflow_is_transport_and_retries_without_reset` — inventory存在，执行ok。
- `monitor::darwin_sockets::tests::udp::ssh_darwin_udp_mixed_and_all_unbound_results_are_available_and_refetched` — inventory存在，执行ok。
- `monitor::darwin_sockets::tests::udp::ssh_darwin_udp_parser_and_command_failures_are_cached_until_reset` — inventory存在，执行ok。

**实现与行为审查**

- **固定只读命令和独立帧**：触发为Darwin TCP LISTEN 与 UDP 混合读取，Linux 原有读取。Darwin 使用 frame2 和绝对系统 lsof；Linux 的 ss 与 frame1 保持。没有主动探测、提权或终止命令。 证据：[monitor.rs:85](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor.rs:85)；[tests.rs:340](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/darwin_sockets/tests.rs:340)。
- **UDP 语义、严格输入与过滤预算**：触发为bound、peer、双栈、scope、wildcard、未绑定、重复身份、警告、截断和超量输出。TCP 五字段并限定 LISTEN；UDP 四字段且无 T。未绑定只过滤精确 *:*，先验证进程/FD并计入10000全局预算。完整帧、SSH exit、lsof status、stderr和2MiB总输出共同决定可用性。 证据：[darwin_sockets.rs:25](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/darwin_sockets.rs:25)；[darwin_sockets.rs:63](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/darwin_sockets.rs:63)；[darwin_sockets.rs:130](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/darwin_sockets.rs:130)；[darwin_sockets.rs:207](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/darwin_sockets.rs:207)。
- **负缓存、reset 与迟到**：触发为工具缺失/权限/格式失败后重试、SSH故障、reset、暂停ABA、retire与过期报告。非Transport负项仅显式reset重试；Transport保留可重试。连接身份与generation/revision撤销旧能力报告；UI另拒绝旧sample generation和过期结果。相应既有回归在本次33和36组内执行ok。 证据：[capabilities.rs:148](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/capabilities.rs:148)；[capabilities.rs:162](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/capabilities.rs:162)；[capabilities.rs:214](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/capabilities.rs:214)；[monitor.rs:277](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor.rs:277)；[monitor_capabilities.rs:25](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_capabilities.rs:25)。
- **三主题、明暗、双语与 AX**：触发为Frost/Graphite/Lavender、Light/Dark、ZhCn/En切换及显示端点截断。BOUND/PEER使用中英文形状标签和账户可见/不代表健康说明，未套用成功色或连通承诺。完整端点/进程进入行Group AX名称，显示行分层并截断；切换只重绘缓存。新用例遍历3×2×2矩阵，无额外SSH命令。长文本原生朗读和视觉效果未验。 证据：[monitor.rs:1351](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor.rs:1351)；[monitor.rs:1402](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor.rs:1402)；[darwin_sockets.rs:217](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_tests/darwin_sockets.rs:217)。
- **分页、可达性与刷新夹紧**：触发为25行按12/12/1浏览、末页、上一页、切换英文、刷新为3行或失败空列表。全局行ID由enumerate后skip/take保留，前后页只修改缓存页码；next使用当前长度检查。replace_sockets夹紧到合法页并清空探测结果，成功与失败两类接收路径均调用。测试逐名包含0..24全部行，实际滚到pager视区后click，并验证按钮边界、返回和刷新夹紧。失败为空的夹紧由源码审查覆盖；新增分页用例使用480×900受控窗口，未扩称三平台或所有尺寸原生验收。 证据：[monitor.rs:396](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor.rs:396)；[monitor.rs:431](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor.rs:431)；[monitor.rs:533](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor.rs:533)；[monitor.rs:1394](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor.rs:1394)；[monitor.rs:1512](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor.rs:1512)；[monitor.rs:1781](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor.rs:1781)；[darwin_sockets.rs:28](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_tests/darwin_sockets.rs:28)；[darwin_sockets.rs:313](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_tests/darwin_sockets.rs:313)。
- **Darwin 主动动作边界**：触发为有/无资源采样的UDP行、Darwin TCP行、未知平台、直接Job分派。UI只在Linux资源采样下提供TCP探测/进程核对与终止；run入口对三类动作再次拒绝。Darwin和未知平台无按钮和动作命令；session的UDP probe先拒绝非TCP，Darwin TCP/进程动作保留远端Linux守卫。未授予UDP任何主动动作。 证据：[monitor.rs:548](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor.rs:548)；[monitor.rs:658](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor.rs:658)；[monitor.rs:1474](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor.rs:1474)；[darwin_sockets.rs:285](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_tests/darwin_sockets.rs:285)；[monitor.rs:670](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor.rs:670)。
- **真实自有 UDP 和 TCP 排除的证据**：触发为IPv4/IPv6 bound、wildcard、精确peer、保持未绑定FD存活的子工装、TCP client。对照源码与既存tests.log核对全部15个唯一名字。断言绑定自有PID及精确local/peer；未绑定子工装有有界启动/退出和Drop兜底；组合用例排除自有TCP客户端。result.json与外层回执证明已回收和fixture清理；复核员未启动标准OpenSSH或访问其密钥。 证据：[udp.rs:17](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/darwin_monitor_interop/udp.rs:17)；[udp.rs:58](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/darwin_monitor_interop/udp.rs:58)；[udp.rs:148](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/darwin_monitor_interop/udp.rs:148)；[udp.rs:235](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/darwin_monitor_interop/udp.rs:235)；[udp.rs:262](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/darwin_monitor_interop/udp.rs:262)。

**真实SSH既存原件与清理**

独立读取 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-udp-20261117/darwin-ssh-r1/result.json`、`tests.log` 和外层 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-udp-20261117/darwin-ssh-r1.json`，没有启动标准OpenSSH fixture或读取其密钥。15个唯一名字与当前9个原测试＋6个UDP新测试完全相等，全部ok，汇总真实15/0/0。result的tests步骤exit0、日志1500字节及passed_tests=15一致；外层日志字节/SHA独立匹配，exit0，实耗4.931470s，direct_reaped=true、active_processes=0、pipes_drained=true、errors=[]。源码覆盖自有双栈bound/wildcard/peer/unbound及TCP客户端排除。

result.json:67的cleanup为observed_processes_stopped=true、owned_processes_stopped=true、ancestry_unverified=[]、tracked_process_identities=77、temporary_directory_removed=true；另只检查该workspace内临时目录当前不存在。保留其累计祖先观测／kernel birth identity边界，不推演为对所有未观察到后代的无限保证。记录属于父级真实SSH执行，本复核真实SSH执行0；与独立69项分开，不合并成84项独立测试。

**原失败和未验收边界**

- 父focused r1：session36/0/0；app11/1/0、exit101，真实触发是pager未在视区内，Kit拒绝点击。r1→r2只增加生产monitor-scroll上的有界滚动及可见性断言，再执行click；父app r2为12/0/0。本次相应用例也独立ok，原失败保留在parent-originals，不补签r1通过。
- 父full-gate-r1：exit1/reaped/12.072717s；Python293 run、290 passed、1 failed、2 skipped，未到Rust。失败是fixture精确命令镜像仍为frame1／TCP-only；r3两行修订和字面相等已静态核对。full-gate-r2仍由父级负责，本报告不宣告其成功，也未等待或重放完整gate。
- 本次所有GPUI结果为受控窗口／控制器、布局和AX属性测试。新增分页例为480×900窗口，测试证明滚动后pager可点和每页行集合完整；未对每行另做原生指针点击，也未把它扩成所有尺寸的键盘／辅助技术或原生桌面验收。长端点／进程完整AX拼接由源码确认，真实VoiceOver朗读未验。
- 原生桌面操作／截图／启动／安装均0；Windows、Linux运行0；正常包、三平台桌面、发行和完整产品未验。父级依赖在线最新版本UNKNOWN保持，manifest／lock未变；本次未进行在线重查。
- 本复核只写function-review中的报告、脚本、日志及私有临时测试目录；源码修改、format、commit、push、清理和共享target读写均0。prebuilt内部使用自有受控测试peer，不接入外部机器或复用标准OpenSSH凭据。

机器摘要：[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-udp-20261117/function-review/summary.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-udp-20261117/function-review/summary.json)。完整执行台账：[/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-udp-20261117/function-review/commands.jsonl](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-udp-20261117/function-review/commands.jsonl)。前后输入／副本摘要、逐名结果及父级失败和SSH原件副本均保存在同一目录。功能复核完成，结论APPROVE限上述r3增量与证据边界。
