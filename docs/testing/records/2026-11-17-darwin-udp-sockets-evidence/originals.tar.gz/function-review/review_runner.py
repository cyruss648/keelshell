"""Read-only source checks and bounded execution of the two authorized copies."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
BATCH = OUT.parent
BASE = "e1f7359a975726dc6cf110fb12edcbb8a582cd95"
EXPECTED = {
    "r2": "ad6a7b3d3bf471c833301373b3d89b768e48258b4afda15ae6f561059da2ab09",
    "r3": "e94405c2858d9796d9256dfd44eb277914c18fedd14e258e8025c747528e9a0e",
}
BINS = {
    "app": "1ac9094c489f26eba5d38d98fe257ac5a1cce22b3802b091bf43fa232a9db576",
    "session": "770a3873fa1be7832d1cac9efd4051f8229f7070005f9c075d6fff538fb4f0d5",
}


def write_json(name, data):
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def digest(path):
    h = hashlib.sha256()
    size = 0
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
            size += len(chunk)
    return {"path": str(path), "bytes": size, "sha256": h.hexdigest()}


def run(label, argv, timeout=30, cwd=ROOT):
    assert 0 < timeout <= 170
    env = os.environ.copy()
    env["GIT_OPTIONAL_LOCKS"] = "0"
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    for key in (
        "CARGO_TARGET_DIR", "CARGO_BUILD_TARGET_DIR", "DYLD_LIBRARY_PATH",
        "DYLD_FALLBACK_LIBRARY_PATH", "LD_LIBRARY_PATH",
    ):
        env.pop(key, None)
    env["TMPDIR"] = str(OUT / "runtime-tmp") + "/"
    env["KEELSHELL_DATA_DIR"] = str(OUT / "runtime-data")
    (OUT / "runtime-tmp").mkdir(exist_ok=True)
    started = datetime.now(timezone.utc).isoformat()
    begin = time.monotonic()
    proc = subprocess.Popen(
        argv, cwd=cwd, env=env, stdout=subprocess.PIPE,
        stderr=subprocess.PIPE, start_new_session=True,
    )
    timed_out = False
    try:
        stdout, stderr = proc.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(proc.pid, signal.SIGTERM)
        try:
            stdout, stderr = proc.communicate(timeout=4)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGKILL)
            stdout, stderr = proc.communicate(timeout=4)
    elapsed = time.monotonic() - begin
    (OUT / f"{label}.stdout.log").write_bytes(stdout)
    (OUT / f"{label}.stderr.log").write_bytes(stderr)
    receipt = {
        "label": label, "argv": argv, "cwd": str(cwd),
        "started_utc": started, "timeout_seconds": timeout,
        "elapsed_seconds": elapsed, "exit": proc.returncode,
        "timed_out": timed_out, "waited": True,
        "pid": proc.pid, "pipes_drained": True,
        "stdout": digest(OUT / f"{label}.stdout.log"),
        "stderr": digest(OUT / f"{label}.stderr.log"),
    }
    write_json(f"{label}.exit.json", receipt)
    with (OUT / "commands.jsonl").open("a") as log:
        log.write(json.dumps(receipt, ensure_ascii=False) + "\n")
    print(json.dumps({k: receipt[k] for k in (
        "label", "exit", "timed_out", "waited", "elapsed_seconds",
    )}), flush=True)
    return receipt, stdout, stderr


def aggregate(rows):
    return hashlib.sha256("".join(
        f"{row['path']}\0{row['sha256']}\n" for row in rows
    ).encode()).hexdigest()


def integrity(label):
    freezes = {}
    for revision in ("r2", "r3"):
        value = json.loads((BATCH / f"inputs-freeze-{revision}.json").read_text())
        assert value["count"] == len(value["inputs"]) == 729
        assert value["head"] == BASE
        assert value["aggregate_sha256"] == aggregate(value["inputs"]) == EXPECTED[revision]
        freezes[revision] = value
    a = {r["path"]: r for r in freezes["r2"]["inputs"]}
    b = {r["path"]: r for r in freezes["r3"]["inputs"]}
    delta = [p for p in sorted(a.keys() | b.keys()) if a.get(p) != b.get(p)]
    assert delta == ["scripts/monitor_recovery/fixture.py"], delta
    result, raw, _ = run(f"{label}-git-input-names", [
        "git", "ls-files", "--cached", "--others", "--exclude-standard", "-z",
    ])
    assert result["exit"] == 0
    names = sorted({
        p.decode() for p in raw.split(b"\0") if p and not p.startswith((b"docs/", b".hallmark/"))
    })
    assert not any("target" in Path(p).parts or p.startswith("work/") for p in names)
    actual = []
    for name in names:
        row = digest(ROOT / name)
        row["path"] = name
        actual.append(row)
    mismatches = [p for p in sorted(set(names) | b.keys())
                  if next((r for r in actual if r["path"] == p), None) != b.get(p)]
    result, raw, _ = run(f"{label}-head", ["git", "rev-parse", "HEAD"])
    head = raw.decode().strip()
    metadata = json.loads((BATCH / "review-prebuilt-r1.json").read_text())
    binary_rows = {}
    for key, expected_sha in BINS.items():
        # Deliberately never stat, open or resolve source_artifact in the shared target.
        copied = BATCH / "package-review-prebuilt" / key
        assert not copied.is_symlink()
        observed = digest(copied)
        assert observed["path"] == metadata[key]["path"]
        assert observed["sha256"] == metadata[key]["sha256"] == expected_sha
        assert observed["bytes"] == metadata[key]["bytes"]
        observed["parent_reported_source_artifact"] = metadata[key]["source_artifact"]
        observed["source_artifact_accessed"] = False
        observed["stat"] = {
            "device": copied.stat().st_dev, "inode": copied.stat().st_ino,
            "mtime_ns": copied.stat().st_mtime_ns,
        }
        binary_rows[key] = observed
    docs = [
        "AGENTS.md", "docs/HANDOFF.md", "docs/testing/SHARED_TARGET.md",
        "docs/adr/0154-darwin-udp-sockets.md",
        "docs/design/HALLMARK_NATIVE.md", "docs/product/MONITOR_CAPABILITIES.md",
    ]
    report = {
        "captured_utc": datetime.now(timezone.utc).isoformat(),
        "head": head, "expected_head": BASE, "count": len(actual),
        "aggregate_sha256": aggregate(actual), "expected_r3": EXPECTED["r3"],
        "inputs": actual, "mismatches": mismatches,
        "r2_freeze_self_consistent": True, "r3_freeze_self_consistent": True,
        "r2_to_r3_changed_paths": delta,
        "rust_manifest_lock_unchanged_between_r2_r3": True,
        "binaries": binary_rows,
        "documents_outside_engineering_freeze": {
            p: digest(ROOT / p) for p in docs
        },
    }
    write_json(f"integrity-{label}.json", report)
    assert head == BASE
    assert not mismatches
    assert len(actual) == 729 and aggregate(actual) == EXPECTED["r3"]
    print(json.dumps({
        "integrity": label, "count": len(actual),
        "aggregate_sha256": aggregate(actual), "mismatches": len(mismatches),
        "r2_to_r3_changed_paths": delta,
    }), flush=True)


def inventory(key):
    binary = str(BATCH / "package-review-prebuilt" / key)
    receipt, stdout, stderr = run(f"{key}-inventory", [binary, "--list"], cwd=OUT)
    assert receipt["exit"] == 0 and not receipt["timed_out"]
    names = re.findall(r"^(.+): test$", stdout.decode(), re.M)
    assert len(names) == len(set(names)) > 0
    write_json(f"{key}-inventory.json", {
        "count": len(names), "names": names,
        "monitor_names": [n for n in names if n.startswith("monitor::")],
    })
    print(json.dumps({
        "inventory": key, "count": len(names),
        "monitor_count": sum(n.startswith("monitor::") for n in names),
    }), flush=True)


def execute(key, filter_text, label, timeout):
    names = json.loads((OUT / f"{key}-inventory.json").read_text())["names"]
    selected = sorted(n for n in names if filter_text in n)
    receipt, stdout, stderr = run(label, [
        str(BATCH / "package-review-prebuilt" / key),
        filter_text, "--test-threads=1", "--nocapture",
    ], timeout=timeout, cwd=OUT)
    text = stdout.decode(errors="replace") + "\n" + stderr.decode(errors="replace")
    results = re.findall(r"^test ([^\r\n ]+) \.\.\. (ok|FAILED|ignored)(?:[ :].*)?$", text, re.M)
    summary = re.findall(
        r"test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; "
        r"(\d+) measured; (\d+) filtered out; finished in ([0-9.]+)s", text,
    )
    record = {
        "filter": filter_text, "selected_count": len(selected),
        "selected_names": selected,
        "results": [{"name": name, "result": outcome} for name, outcome in results],
        "counts": {s: sum(v == s for _, v in results) for s in ("ok", "FAILED", "ignored")},
        "summary": summary, "receipt": receipt,
        "inventory_equals_results": selected == sorted(n for n, _ in results),
    }
    write_json(f"{label}.results.json", record)
    print(json.dumps({
        "execution": label, "counts": record["counts"],
        "inventory_equals_results": record["inventory_equals_results"],
        "summary": summary,
    }), flush=True)
    return record


if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "before":
        integrity("before")
        for name in BINS:
            receipt, raw, _ = run(f"{name}-dylibs", [
                "/usr/bin/otool", "-L", str(BATCH / "package-review-prebuilt" / name),
            ])
            assert receipt["exit"] == 0
            assert b"/target/" not in raw
            inventory(name)
    elif mode == "execute":
        execute("app", "monitor::tests", "app-monitor", 90)
        execute("session", "monitor::darwin_sockets::tests", "session-darwin-sockets", 170)
    elif mode == "after":
        integrity("after")
    else:
        raise SystemExit("before | execute | after")
