"""Independently reconcile source names, private inventories and parent originals."""
import ast
import hashlib
import json
from pathlib import Path
import re

from review_runner import BASE, BATCH, OUT, ROOT, digest, run, write_json


def read_json(path):
    return json.loads(path.read_text())


def save_original(name):
    source = BATCH / name
    raw = source.read_bytes()
    destination = OUT / "parent-originals" / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(raw)
    return digest(source)


def test_names(source, kind):
    if kind == "gpui":
        return re.findall(r"#\[gpui_kit::test\]\s+async fn (\w+)", source)
    return re.findall(r"#\[(?:tokio::)?test\]\s+(?:#\[[^\n]+\]\s+)*(?:async )?fn (\w+)", source)


summary = read_json(BATCH / "focused-summary-r2.json")
app_source = ROOT / "crates/keelshell-app/src/monitor_tests/darwin_sockets.rs"
receipt, old_app, _ = run("evidence-r2-base-app-socket-tests", [
    "git", "show", f"{BASE}:crates/keelshell-app/src/monitor_tests/darwin_sockets.rs",
])
assert receipt["exit"] == 0
old_names = set(test_names(old_app.decode(), "gpui"))
current_names = set(test_names(app_source.read_text(), "gpui"))
renamed_old = "darwin_socket_button_reads_tcp_without_offering_linux_actions"
renamed_new = "darwin_socket_button_reads_tcp_and_udp_without_offering_linux_actions"
assert old_names - current_names == {renamed_old}
added_app = sorted(current_names - old_names - {renamed_new})
assert len(added_app) == 3
new_session_source = ROOT / "crates/keelshell-session/src/monitor/darwin_sockets/tests/udp.rs"
added_session = sorted(test_names(new_session_source.read_text(), "rust"))
assert len(added_session) == 15
coverage = {}
for key, source_names, prefix, label in [
    ("app", added_app, "monitor::tests::darwin_sockets::", "app-monitor"),
    ("session", added_session, "monitor::darwin_sockets::tests::udp::", "session-darwin-sockets"),
]:
    expected = sorted(prefix + name for name in source_names)
    assert expected == sorted(summary[key]["required_new_tests"])
    inventory = read_json(OUT / f"{key}-inventory.json")
    execution = read_json(OUT / f"{label}.results.json")
    results = {r["name"]: r["result"] for r in execution["results"]}
    assert execution["inventory_equals_results"]
    assert execution["receipt"]["exit"] == 0
    assert execution["receipt"]["waited"] and not execution["receipt"]["timed_out"]
    assert all(name in inventory["names"] and results.get(name) == "ok" for name in expected)
    assert len(execution["summary"]) == 1
    declared = execution["summary"][0]
    assert int(declared[1]) == execution["counts"]["ok"]
    assert int(declared[2]) == execution["counts"]["FAILED"] == 0
    assert int(declared[3]) == execution["counts"]["ignored"] == 0
    coverage[key] = {
        "source_derived_names_equal_parent_reference": True,
        "inventory_total": inventory["count"],
        "selected_count": execution["selected_count"],
        "new_count": len(expected),
        "required_new_tests": [
            {"name": name, "in_inventory": True, "executed": "ok"} for name in expected
        ],
        "passed": execution["counts"]["ok"], "failed": 0, "ignored": 0,
        "inventory_equals_execution": True,
        "elapsed_seconds": execution["receipt"]["elapsed_seconds"],
        "exit": execution["receipt"]["exit"],
    }

parent_paths = [
    "darwin-ssh-r1/result.json", "darwin-ssh-r1/tests.log",
    "darwin-ssh-r1.json", "darwin-ssh-r1.log",
    "app-focused-r1.log", "app-focused-r1-exit.json",
    "session-focused-r1.log", "session-focused-r1-exit.json",
    "app-focused-r2.log", "app-focused-r2-exit.json",
    "focused-r1.json", "focused-r2.json",
    "full-gate-r1.json", "full-gate-r1.log",
    "review-prebuilt-r1.json", "source-review/r1-to-r2.diff",
]
parent_hashes = {p: save_original(p) for p in parent_paths}

ssh_result = read_json(BATCH / "darwin-ssh-r1/result.json")
outer = read_json(BATCH / "darwin-ssh-r1.json")
ssh_log = (BATCH / "darwin-ssh-r1/tests.log").read_text()
ssh_names = re.findall(r"^test (\S+) \.\.\. (ok|FAILED|ignored)$", ssh_log, re.M)
assert len(ssh_names) == len(set(n for n, _ in ssh_names)) == 15
assert all(status == "ok" for _, status in ssh_names)
assert "15 passed; 0 failed; 0 ignored;" in ssh_log
assert ssh_result["passed_tests"] == 15 and ssh_result["outcome"] == "passed"
assert ssh_result["platform"] == "Darwin"
assert all(step["returncode"] == 0 for step in ssh_result["steps"])
assert ssh_result["logs"]["tests.log"] == parent_hashes["darwin-ssh-r1/tests.log"]["bytes"]
assert outer["observed_exit"] == outer["controller_exit"] == 0
assert not outer["timed_out"] and not outer["interrupted"] and not outer["errors"]
assert outer["terminal"] == {
    "direct_reaped": True, "active_processes": 0, "pipes_drained": True, "errors": [],
}
assert outer["log_bytes"] == parent_hashes["darwin-ssh-r1.log"]["bytes"]
assert outer["log_sha256"] == parent_hashes["darwin-ssh-r1.log"]["sha256"]
interop_main = test_names((ROOT / "crates/keelshell-session/tests/darwin_monitor_interop.rs").read_text(), "rust")
interop_udp = [
    "udp::" + name for name in test_names(
        (ROOT / "crates/keelshell-session/tests/darwin_monitor_interop/udp.rs").read_text(), "rust"
    )
]
assert sorted(n for n, _ in ssh_names) == sorted(interop_main + interop_udp)
assert sorted(interop_udp) == sorted(summary["interop"]["required_new_tests"])
cleanup = ssh_result["cleanup"]
assert cleanup["observed_processes_stopped"] and cleanup["owned_processes_stopped"]
assert cleanup["temporary_directory_removed"] and not cleanup["ancestry_unverified"]
removed = Path(ssh_result["temporary_directory"])
assert removed.is_relative_to(ROOT / "work") and not removed.exists()

gate_receipt = read_json(BATCH / "full-gate-r1.json")
gate_log = (BATCH / "full-gate-r1.log").read_text()
assert gate_receipt["observed_exit"] == gate_receipt["controller_exit"] == 1
assert gate_receipt["terminal"]["direct_reaped"]
assert gate_receipt["log_sha256"] == parent_hashes["full-gate-r1.log"]["sha256"]
assert "Ran 293 tests" in gate_log and "FAILED (failures=1, skipped=2)" in gate_log
assert "test_forcecommand_collectors_exactly_match_linux_api_including_df_cache" in gate_log
old_failed = (BATCH / "app-focused-r1.log").read_text()
assert "ElementId Name(\"socket-page-next\") is not visible" in old_failed
assert "11 passed; 1 failed; 0 ignored;" in old_failed
assert read_json(BATCH / "app-focused-r1-exit.json")["exit"] == 101
assert "12 passed; 0 failed; 0 ignored;" in (BATCH / "app-focused-r2.log").read_text()
assert read_json(BATCH / "app-focused-r2-exit.json")["exit"] == 0
assert "36 passed; 0 failed; 0 ignored;" in (BATCH / "session-focused-r1.log").read_text()

receipt, old_fixture, _ = run("evidence-r2-base-python-fixture", [
    "git", "show", f"{BASE}:scripts/monitor_recovery/fixture.py",
])
assert receipt["exit"] == 0
old_fixture_text = old_fixture.decode()
new_fixture_text = (ROOT / "scripts/monitor_recovery/fixture.py").read_text()
r2 = read_json(BATCH / "inputs-freeze-r2.json")
r2_fixture = next(row for row in r2["inputs"] if row["path"] == "scripts/monitor_recovery/fixture.py")
assert hashlib.sha256(old_fixture).hexdigest() == r2_fixture["sha256"]
assert new_fixture_text == old_fixture_text.replace(
    "@@KS:darwin-sockets:1@@", "@@KS:darwin-sockets:2@@",
).replace(
    "/usr/sbin/lsof -nP -a -iTCP -sTCP:LISTEN -F0pcftPnT -Ts",
    "/usr/sbin/lsof -nP -a -iTCP -sTCP:LISTEN -iUDP -F0pcftPnT -Ts",
)
# Interpret only string constants, previously assigned strings and their
# concatenation; never import or execute the fixture.
module = ast.parse(new_fixture_text)
constant_strings = {}


def string_value(node):
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    if isinstance(node, ast.Name):
        return constant_strings[node.id]
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        return string_value(node.left) + string_value(node.right)
    raise ValueError("expression is not a static string")


for node in module.body:
    if isinstance(node, ast.Assign):
        try:
            value = string_value(node.value)
        except (KeyError, ValueError):
            continue
        for target in node.targets:
            if isinstance(target, ast.Name):
                constant_strings[target.id] = value
socket_literal = constant_strings["SOCKETS"]
rust_monitor = (ROOT / "crates/keelshell-session/src/monitor.rs").read_text()
rust_literal = re.search(r'const SOCKETS_SCRIPT: &str = r#"(.*?)"#;', rust_monitor, re.S).group(1)
assert socket_literal == rust_literal

for label, args in [
    ("source-diff", ["git", "diff", "--no-ext-diff", BASE, "--", "crates", "scripts/monitor_recovery/fixture.py", "docs/adr/0154-darwin-udp-sockets.md", "docs/design/HALLMARK_NATIVE.md", "docs/product/MONITOR_CAPABILITIES.md"]),
    ("untracked-source", ["git", "ls-files", "--others", "--exclude-standard", "crates", "docs", "scripts"]),
    ("working-diff-check", ["git", "diff", "--check", BASE, "--", "crates", "scripts/monitor_recovery/fixture.py", "docs"]),
]:
    receipt, _, _ = run(label, args)
    assert receipt["exit"] == 0

evidence = {
    "new_test_coverage": coverage,
    "renamed_existing_app_test": {"old": renamed_old, "new": renamed_new},
    "ssh_parent_evidence": {
        "rerun_by_reviewer": False,
        "result_json": parent_hashes["darwin-ssh-r1/result.json"],
        "tests_log": parent_hashes["darwin-ssh-r1/tests.log"],
        "outer_receipt": parent_hashes["darwin-ssh-r1.json"],
        "passed": 15, "failed": 0, "ignored": 0,
        "names": [{"name": name, "result": status} for name, status in ssh_names],
        "source_names_equal_log_names": True,
        "udp_new_tests": interop_udp,
        "outer_exit": outer["observed_exit"],
        "outer_elapsed_seconds": outer["seconds"],
        "outer_terminal": outer["terminal"],
        "cleanup": cleanup,
        "temporary_directory_currently_absent": True,
    },
    "preserved_failures": {
        "parent_app_focused_r1": {
            "exit": 101, "passed": 11, "failed": 1, "ignored": 0,
            "trigger": "pager was clicked while outside the viewport; Kit rejected invisible click",
            "r2_change": "test-only bounded scroll through production monitor-scroll before each click",
        },
        "parent_session_focused_r1": {"exit": 0, "passed": 36, "failed": 0, "ignored": 0},
        "parent_app_focused_r2": {"exit": 0, "passed": 12, "failed": 0, "ignored": 0},
        "parent_full_gate_r1": {
            "exit": 1, "reaped": True, "seconds": gate_receipt["seconds"],
            "python_run": 293, "python_passed": 290, "python_failed": 1,
            "python_skipped": 2, "rust_reached": False,
            "trigger": "fixture.py retained frame1 and TCP-only exact-command mirror",
        },
    },
    "r2_to_r3": {
        "only_changed_path": "scripts/monitor_recovery/fixture.py",
        "base_fixture_hash_equals_r2": True,
        "two_literal_line_substitutions_only": True,
        "python_sockets_literal_equals_rust_sockets_script": True,
        "fixture_imported_or_executed": False,
        "rust_tests_repeated": False,
    },
    "parent_originals": parent_hashes,
    "parent_full_gate_r2_completed_receipt_available_at_evidence_read": (BATCH / "full-gate-r2.json").exists(),
    "claims_full_gate_r2_passed": False,
}
write_json("evidence-verification.json", evidence)
print(json.dumps({
    "app": coverage["app"]["passed"], "session": coverage["session"]["passed"],
    "new_app": len(added_app), "new_session": len(added_session),
    "ssh_parent": "15/0/0; receipts and source names independently reconciled",
    "original_failures_preserved": True, "python_exact_command_mirror_matches": True,
}, ensure_ascii=False), flush=True)
