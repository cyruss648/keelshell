"""Inspect only this process's owned sockets; close all of them on exit."""
from contextlib import ExitStack
import json
import os
from pathlib import Path
import socket
import subprocess

base = Path(__file__).resolve().parent
result_path = base / "owned-socket-probe-r1.json"
assert not result_path.exists()
with ExitStack() as stack:
    sockets = {}

    def keep(name, family, kind, bind=None, peer=None):
        value = stack.enter_context(socket.socket(family, kind))
        if bind is not None:
            value.bind(bind)
        if peer is not None:
            value.connect(peer)
        sockets[name] = {
            "fd": value.fileno(),
            "family": family.name,
            "local": value.getsockname(),
            "peer": value.getpeername() if peer is not None else None,
        }
        return value

    listener = keep("tcp_listener", socket.AF_INET, socket.SOCK_STREAM, ("127.0.0.1", 0))
    listener.listen()
    keep("tcp_client", socket.AF_INET, socket.SOCK_STREAM, peer=listener.getsockname())
    accepted, _ = listener.accept()
    stack.enter_context(accepted)
    sockets["tcp_accepted"] = {
        "fd": accepted.fileno(),
        "local": accepted.getsockname(),
        "peer": accepted.getpeername(),
    }
    peer = keep("udp_peer", socket.AF_INET, socket.SOCK_DGRAM, ("127.0.0.1", 0))
    keep("udp_bound", socket.AF_INET, socket.SOCK_DGRAM, ("127.0.0.1", 0))
    keep("udp_wildcard", socket.AF_INET, socket.SOCK_DGRAM, ("0.0.0.0", 0))
    keep("udp_connected", socket.AF_INET, socket.SOCK_DGRAM, peer=peer.getsockname())
    keep("udp_unbound", socket.AF_INET, socket.SOCK_DGRAM)
    keep("udp6_bound", socket.AF_INET6, socket.SOCK_DGRAM, ("::1", 0))
    keep("udp6_wildcard", socket.AF_INET6, socket.SOCK_DGRAM, ("::", 0))
    keep("udp6_connected", socket.AF_INET6, socket.SOCK_DGRAM, peer=("::1", peer.getsockname()[1]))
    keep("udp6_unbound", socket.AF_INET6, socket.SOCK_DGRAM)
    selections = {
        "tcp": ["-iTCP", "-sTCP:LISTEN"],
        "udp": ["-iUDP"],
        "combined": ["-iTCP", "-sTCP:LISTEN", "-iUDP"],
        "reversed": ["-iUDP", "-iTCP", "-sTCP:LISTEN"],
    }
    observations = {}
    for name, selection in selections.items():
        command = ["/usr/sbin/lsof", "-nP", "-a", "-p", str(os.getpid()), *selection, "-F0pcftPnT", "-Ts"]
        completed = subprocess.run(command, capture_output=True, timeout=15, check=False)
        observations[name] = {
            "command": command,
            "returncode": completed.returncode,
            "stdout": completed.stdout.decode(),
            "stderr": completed.stderr.decode(),
        }
    result_path.write_text(json.dumps({"sockets": sockets, "observations": observations}, indent=2) + "\n")
print(result_path.read_text())
