"""Retry transient official GET failures without changing dependency policy."""
import json
from pathlib import Path
import sys
import threading

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "scripts"))
import check_dependencies as check

attempts = []
lock = threading.Lock()


def fetch(url, timeout):
    for attempt in range(1, 4):
        try:
            result = check.fetch_json(url, timeout)
        except check.CheckFailure:
            with lock:
                attempts.append({"package": url.removeprefix(check.API_ROOT),
                                 "attempt": attempt, "success": False})
            if attempt == 3:
                raise
        else:
            with lock:
                attempts.append({"package": url.removeprefix(check.API_ROOT),
                                 "attempt": attempt, "success": True})
            return result


status = check.main(
    ["--timeout", "20", "--jobs", "6",
     "--json-report", str(BASE / "dependencies-report-r3.json")],
    fetch=fetch,
)
with (BASE / "dependencies-attempts-r3.json").open("x") as output:
    json.dump(attempts, output, indent=2)
    output.write("\n")
sys.exit(status)
