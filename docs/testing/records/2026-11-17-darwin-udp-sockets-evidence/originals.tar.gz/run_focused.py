"""Resolve actual Cargo artifacts, inventory them, and run the completed slice."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
REV = sys.argv[1]
assert REV == "r2"


def artifact(log, name):
    candidates = []
    for line in (BASE / log).read_text().splitlines():
        try:
            row = json.loads(line)
        except ValueError:
            continue
        if (row.get("reason") == "compiler-artifact" and row.get("executable")
                and row["profile"]["test"] and row["target"]["name"] == name):
            assert row["manifest_path"].startswith(str(ROOT / "crates") + "/")
            candidates.append(row)
    assert len(candidates) == 1, name
    row = candidates[0]
    path = Path(row["executable"])
    raw = path.read_bytes()
    return {
        "path": str(path), "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw), "cargo_log": log,
        "source_path": row["target"]["src_path"], "fresh": row["fresh"],
    }


def run(label, command):
    with (BASE / f"{label}.log").open("xb") as output:
        completed = subprocess.run(command, cwd=ROOT, stdout=output,
                                   stderr=subprocess.STDOUT, timeout=140)
    raw = (BASE / f"{label}.log").read_bytes()
    record = {"command": command, "exit": completed.returncode,
              "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
    with (BASE / f"{label}-exit.json").open("x") as output:
        json.dump(record, output, indent=2)
        output.write("\n")
    assert completed.returncode == 0, label
    return raw.decode()


report = {
    "app": artifact("compile-app-r2.log", "keelshell-app"),
    "session": artifact("compile-session-r1.log", "keelshell_session"),
    "interop": artifact("compile-session-r1.log", "darwin_monitor_interop"),
}
for kind, row in report.items():
    text = run(f"{kind}-inventory-{REV}", [row["path"], "--list"])
    names = re.findall(r"^(\S+): test$", text, re.M)
    assert names and len(names) == len(set(names))
    row["inventory"] = names
    row["inventory_count"] = len(names)
required = {
    "app": [
        "monitor::tests::darwin_sockets::" + name
        for name in (
            "darwin_udp_rows_retain_endpoints_across_themes_and_languages_without_io",
            "darwin_udp_probe_dispatch_stays_read_only_with_and_without_resource_sample",
            "socket_pagination_reaches_every_cached_row_without_ssh_and_clamps_on_refresh",
        )
    ],
    "session": [
        "monitor::darwin_sockets::tests::udp::" + name
        for name in re.findall(
            r"^(?:async )?fn (\w+)\(",
            (ROOT / "crates/keelshell-session/src/monitor/darwin_sockets/tests/udp.rs").read_text(),
            re.M,
        ) if name.startswith(("darwin_", "ssh_"))
    ],
    "interop": ["udp::" + name for name in re.findall(
        r"^async fn (\w+)\(",
        (ROOT / "crates/keelshell-session/tests/darwin_monitor_interop/udp.rs").read_text(),
        re.M,
    ) if name.startswith("darwin_")],
}
assert [len(required[key]) for key in ("app", "session", "interop")] == [3, 15, 6]
for kind, names in required.items():
    assert set(names) <= set(report[kind]["inventory"]), kind
    report[kind]["required_new_tests"] = names
with (BASE / f"binaries-{REV}.json").open("x") as output:
    json.dump(report, output, indent=2)
    output.write("\n")
for kind, prefix in (
    ("session", "monitor::darwin_sockets::tests"),
    ("app", "monitor::tests::darwin"),
):
    text = run(f"{kind}-focused-{REV}", [
        report[kind]["path"], prefix, "--test-threads=1", "--nocapture",
    ])
    outcomes = dict(re.findall(r"^test (\S+) \.\.\. (ok|FAILED|ignored)", text, re.M))
    expected = [name for name in report[kind]["inventory"] if name.startswith(prefix)]
    assert set(outcomes) == set(expected), kind
    assert all(value == "ok" for value in outcomes.values()), kind
    assert all(outcomes[name] == "ok" for name in required[kind]), kind
    report[kind]["focused_passed"] = len(outcomes)
with (BASE / f"focused-summary-{REV}.json").open("x") as output:
    json.dump(report, output, indent=2)
    output.write("\n")
print(json.dumps({kind: {key: value for key, value in row.items()
                        if key not in ("inventory", "required_new_tests")}
                  for kind, row in report.items()}))
