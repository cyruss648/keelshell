**KeelShell UDP 独立非作者源码复核，最终 r3**

结论为 **APPROVE（限定冻结r3的静态源码）**，**P0=0、P1=0、P2=0、P3=0**。没有发现具备具体触发和影响证据的未关闭差分缺陷，因此不存在需要列出的问题文件/行号；下列路径行号为实际审阅证据。静态批准不代签完整gate、跨平台编译、真实传输或原生桌面。

复核时点：2026-11-16T19:48:42.896397+00:00（UTC，本地日期2026-11-17/Asia/Shanghai）。工作根 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`，独立读回HEAD为 `e1f7359a975726dc6cf110fb12edcbb8a582cd95`，与用户base相同。签署对象是base加当前r3工程工作差分，共13个工程差分文件；另读4份UDP相关文档快照。先读RTK、AGENTS、HANDOFF、SHARED_TARGET、ADR0154、rust-best-practices/rust-engineer及相关所有权、错误、测试、异步、文档章节；通过实际代码形成结论，未使用作者或其他reviewer结论代替本轮源码检查。

**冻结与范围**

| 冻结 | 输入数 | aggregate SHA-256 | 冻结原文件bytes / SHA-256 |
| --- | ---: | --- | --- |
| r1 |729|`bde93925a50a4cd9d5291c058f038bf03c1761be1b396591cb57628352fe3434`|134249 / `d92b7c3868943c0d8eb7e81715c4bd7d3c6726f7792bda4f072aeef7ec034650`|
| r2 |729|`ad6a7b3d3bf471c833301373b3d89b768e48258b4afda15ae6f561059da2ab09`|134249 / `2c30afbdf075834090fe4209876e4620c16ae5316dffdd8c92f39a0e7ffcea2b`|
| **最终r3** |**729**|**`e94405c2858d9796d9256dfd44eb277914c18fedd14e258e8025c747528e9a0e`**|134249 / `8c92ef5f4d15b8e2a3842a4726aba694f7e2f52536904c8a1d816e253db8b8df`|

r1首次核验的729个实际原文件bytes/SHA全部匹配；r2和r3也分别独立重算全部输入。r1→r2仅`crates/keelshell-app/src/monitor_tests/darwin_sockets.rs`：14362 bytes / `8fa1b882584fd91006834033a6393f6308e7a973fe2989abd97e324c488579c5` →15289 bytes / `b74037d87cfdfbd2c53886714fdc2b3220257562b068a39b159d55f05f64d69a`。去除新增helper和三次调用可精确重建r1原字节/SHA。

r2→r3仅`scripts/monitor_recovery/fixture.py`两行：14422 bytes / `25ff6172b2f1e36a94fd2655fe3227ac7b662ac99bf6d91f687ca81ddd987f0c` →14428 bytes / `e31b1321b415d60427086b3e1cda50f9fe65126332368b96f96e9fb2f672b7af`。反向重建命中r2原字节/SHA。两次追加均未改生产Rust，其余727个输入在三份冻结间一致。追加diff原件见 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-udp-20261117/source-review/r1-to-r2.diff` 和 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-udp-20261117/source-review/r2-to-r3.diff`。

最终729个实际原文件、aggregate及输入路径集合与r3全部相同、零mismatch，r3审前审后相同；三份freeze原文件前后bytes/SHA不变，未修改任何freeze。完整原件是`integrity-before.json`、`integrity-r2-before.json`、`integrity-r3-before.json`、`integrity-r3-after.json`；中途`integrity-after.json`仅代表当时r2，最终使用明确r3命名的原件。

工程冻结排除docs。原4份文档另存初始/最终bytes/SHA：其中`docs/testing/records/2026-11-17-darwin-udp-sockets.md`由父级从1663 bytes / `db4b4f0459f5ff08b610cb430f3e1cd10557b21d7f325e05bee7294a45000c5a`补写为本次读回的3891 bytes / `796c8b578a8b651baf1eb08abe1a7011fb539d1ee78e066cd589da24cbaa8847`，新增失败/专项/SSH/依赖UNKNOWN等状态；已读回，未要求其属于工程aggregate或伪称前后不变。其他当前HANDOFF/ROADMAP、上一a1 CI封存等新增文档不在本签署范围；清单和快照时点留在`integrity-r3-after.json`。不签署本报告后父级继续补写的文档。

**源码证据**

- **生产组合命令/TCP边界**：[crates/keelshell-session/src/monitor.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor.rs:87)。固定lsof命令使用frame2、TCP LISTEN及UDP；Linux ss正文不变，不提权、不安装。parser TCP仍要求五字段与TST=LISTEN，已连接TCP不被作为可用LISTEN行接受。

- **严格字段、未绑定过滤、身份和预算**：[crates/keelshell-session/src/monitor/darwin_sockets.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/darwin_sockets.rs:63)。进程PID/command和数字fd校验、规范数值身份去重、全局file_count计数先于过滤。UDP恰四字段且无T；合法族上只有精确n*:*被过滤。10000预算包含被过滤对象；畸形混合或超量集合整体失败。

- **数值端点和BOUND/PEER**：[crates/keelshell-session/src/monitor/darwin_sockets.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/darwin_sockets.rs:130)。两端复用207行端点校验，端口为1..65535；保留IPv4-mapped的观察数字地址和IPv6 scope。PEER拒绝wildcard；重复/错误箭头、族冲突、非法地址/端口/scope均无法形成有效行。BOUND/PEER仅为端点形状，无健康/握手含义。

- **帧、warning、truncation和空集合**：[crates/keelshell-session/src/monitor/darwin_sockets.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/darwin_sockets.rs:25)。SSH exit、完整frame2、独立lsof status、NUL/换行及合计2MiB预算保持。非空stderr一律不可用。安静exit1空体或完整all-unbound exit0可为空；空成功帧和截断帧不成为成功空列表。

- **负缓存、迟到与权限**：[crates/keelshell-session/src/monitor/capabilities.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/capabilities.rs:148)。报告仍校验连接Arc及generation/revision；214行仅Transport允许不reset重试。UI 277行的generation/响应年龄/suspend边界先于采用；资源/进程和独立端口能力不混同。Darwin/未知平台动作仍被run分派拒绝，UDP不授予probe/inspect/terminate。

- **所有缓存行分页及刷新夹紧**：[crates/keelshell-app/src/monitor.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor.rs:533)。成功/失败结果统一replace_sockets，按新长度夹紧页码并清probe。1394行按全缓存enumerate/skip/take每页12条，1512行据总数呈现页码；翻页只改缓存页码与notify，不发SSH。25条分页测试保留三个页面、上一页、零额外命令和实际刷新缩短断言。

- **完整AX、三主题双语**：[crates/keelshell-app/src/monitor.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor.rs:1351)。账户范围及非健康语义为双语；1412行Group完整AX名保留协议/状态/本地/对端/进程，视觉truncate不缩短AX字符串。状态使用中性Palette，复用registry/Kit，无主题ID业务分支。测试遍历registry的主题、明暗及中英文并核对无额外SSH。

- **parser与受控SSH测试**：[crates/keelshell-session/src/monitor/darwin_sockets/tests/udp.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/darwin_sockets/tests/udp.rs:58)。实际阅读双栈/mapped/peer/wildcard、缺失或重复四字段、PID/fd身份、截断、帧版本、非法混合、10000含过滤预算、负缓存和Transport重试测试；父tests.rs的TCP LISTEN负例和固定命令断言保持。只审源码，未执行。

- **r2真实滚动修正**：[crates/keelshell-app/src/monitor_tests/darwin_sockets.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_tests/darwin_sockets.rs:28)。helper最多100轮，观察生产monitor-scroll与pager边界，完整进入视口且visible后才返回，再交Kit click。Kit scroll_target实际派发滚轮并在事件前后重绘。未用控制器调用代替点击，也未放宽原行覆盖/零SSH/刷新夹紧断言。

- **真实SSH unbound Python fixture及清理**：[crates/keelshell-session/tests/darwin_monitor_interop/udp.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/darwin_monitor_interop/udp.rs:118)。Python stdlib持有两个真正未绑定UDP及一个绑定marker；就绪验证子PID/marker端口。连接3秒、控制读90秒、就绪轮询5秒、read超时2秒；close等3秒，Drop关闭control、kill并至多2秒轮询回收。错误/展开路径也落在Drop；无孙进程和新增依赖。

- **跨平台静态边界**：[crates/keelshell-session/tests/darwin_monitor_interop.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/darwin_monitor_interop.rs:14)。新模块显式挂接，opt-in测试ignore，新增代码使用跨平台std接口；没有新平台专属导入。ignore仍需编译，静态阅读不证明Windows/Linux/macOS实际编译。

- **r3 exact-command镜像**：[scripts/monitor_recovery/fixture.py](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/monitor_recovery/fixture.py:87)。仅92/93两行同步frame2与-iUDP；反向重建命中r2原文件bytes/SHA，Linux命令及其余内容不变。安全AST字符串求值的SOCKETS与Rust SOCKETS_SCRIPT 728字节完全相等，SHA 41e0cc82186c6599511d9f836df576fdc74cb1fcfe450e3cca9df21ab5c3718e。scripts/test_monitor_recovery_lab.py全文件与base相等，264行assertEqual未放宽。

lsof选择集合及Darwin无UDP状态的语义，另参阅现存上游手册副本`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-udp-20261117/lsof-upstream.8`183–191、1615–1643行；外部抓取未取得可用正文，没有把网络检索结果作为本轮验收。生产/parser/UI/worker/分页与测试的调用链均实际阅读；端点和能力缓存的未改部分只用于检查本差分语义。

**原失败与父级证据保留**

| 对象 | 原结果 | 本复核观察/边界 |
| --- | --- | --- |
| 父专项r1 session Darwin |36 passed /0 failed /0 ignored，exit0|原日志bytes/SHA与退出回执独立相等；不是本复核执行|
| 父专项r1 app Darwin |**11 passed /1 failed /0 ignored，exit101**|`app-focused-r1.log:14-15`保留Kit对不可见`socket-page-next`的拒点。r2只修有界真实滚动，原覆盖断言保持；原失败不改写为成功|
| 完整gate r1 |**1/reaped/12.072717s，Python293 run /1 fail /2 skip**|`full-gate-r1.log:6-18`保留`test_forcecommand_collectors_exactly_match_linux_api_including_df_cache`的`SOCKETS_SCRIPT`完全相等失败，镜像仍为frame1/TCP-only。**该次Rust gate未开始**；r3修镜像不放宽断言|
| 真实Darwin SSH |父级15 passed /0 failed /0 ignored，tests returncode0|真实receipt为`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-udp-20261117/darwin-ssh-r1/result.json`，不是外层同名运行器JSON。已读回15项tests.log和cleanup，不是本复核启动的测试；这批为r2 Rust输入，不扩大为r3全gate或native通过|
| 完整gate r2 |用户告知已启动|没有采用成功终态，不干预父级统一Cargo槽|
| 上一a1三平台CI |用户告知全部success、另有封存|未将上一提交CI移签本次UDP，也未签署其封存|

父专项原日志及回执bytes/SHA见`parent-r1-evidence.json`。失败gate原日志7667 bytes / SHA `9aa297dfb94599d6052660da89ade218aa5ca738fe53f592f48b45bc8297bb93`与回执相同；回执`direct_reaped=true`、`active_processes=0`、`pipes_drained=true`。真实SSH receipt2092 bytes / SHA `1d78e14a175a3a87d9852d32809020c9d84ab563963f56d7e9d8ce0d5cd2c262`；tests.log1500 bytes / SHA `5a49a75c57fb8027ab7fce5772f435e3b7c1f6d7d2138040afaa8fb012a195f1`，15/0/0且无filtered项。cleanup记录自有/已观察进程停止、77个身份、祖先未确认列表空、临时目录移除；保留累计观察/内核出生身份的原归属边界，不保证观察间完全脱离的未知后代。该证据不证明桌面或完整平台验收。完整摘录及哈希见`parent-gate-and-ssh-evidence.json`、`supplementary-evidence.json`。

没有把父级原执行算为我新跑的测试，也没有独立认证其完整编译库存/二进制来源。本轮没有读取任何r3全量成功终态，没有重放原失败或改写任何父日志。

**独立执行、计数与未验范围**

独立执行只读Git/源码/材料读取、全输入bytes/SHA、嵌入Python AST、`/bin/sh -n`、fixture AST和安全字符串字面比较、两次`git diff --check`。AST不import fixture、不启动SSH/子进程服务；shell仅检查语法。**29次exec_command，以每个shell block记一条：27条block exit0、2条exit1**；嵌套子命令不重计。逐条清单和诊断见`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-udp-20261117/source-review/commands.json`。

两次非零均为本轮校验器：C23反向重建用了不正确的反斜杠字面匹配，C24修正检查方法后命中r2原bytes/SHA；C27过严要求工程freeze之外docs不变，父级正在补记导致断言，C28读回并在C29记录独立文档快照。另C25有一次zsh未匹配glob，导致该rg未执行，C26改读实际测试文件并核验其与base逐字相等；C25最后的diff检查exit0。这些诊断均保留，未当作产品测试结果，也没有隐瞒在成功计数里。

独立Cargo/rustc/rustfmt/Clippy/测试套件/prebuilt执行/真实SSH/完整gate/GUI操作/源码或Cargo编辑/target写入/Git写操作/新用户chat均为**0**。所有显式文件写入均在`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-udp-20261117/source-review`内。共享target由父级使用，我没有运行旧binary、失效或清理其产物。

未独立运行r3分页/GPUI测试、Python discovery、全gate、真实SSH、macOS/Windows/Linux编译、正常包或native键盘/读屏/截图/完整三主题双语桌面矩阵。静态找到接口和断言只说明代码覆盖意图，不能代替这些执行。建议：源码静态范围**APPROVE**；父级fresh全gate、跨平台与native仍按各自证据独立验收。
