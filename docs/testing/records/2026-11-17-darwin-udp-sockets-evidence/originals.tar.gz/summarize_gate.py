"""Check the final gate against its actual binaries and the named new tests."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
spec = importlib.util.spec_from_file_location("gate_parser", BASE / "summarize_tests.py")
parser = importlib.util.module_from_spec(spec)
spec.loader.exec_module(parser)
receipt = json.loads((BASE / "full-gate-r2.json").read_text())
assert receipt["observed_exit"] == receipt["controller_exit"] == 0
assert receipt["terminal"]["direct_reaped"] and receipt["terminal"]["pipes_drained"]
assert receipt["terminal"]["active_processes"] == 0
raw = (BASE / "full-gate-r2.log").read_bytes()
assert hashlib.sha256(raw).hexdigest() == receipt["log_sha256"]
report = parser.summarize(b"##[group]Run python scripts/check.py\n" + raw)
suites, docs = report["suites"], report["doctest_runs_unassigned"]
assert len(suites) == 92 and not report["inventory_result_summary_mismatches"]
assert all(row["summary"]["state"] == "ok" and row["summary"]["failed"] == 0
           for row in suites + docs)
focused = json.loads((BASE / "focused-summary-r2.json").read_text())
binaries = {}
for kind, stem, expected_count in (
    ("app", "keelshell_app", 1377), ("session", "keelshell_session", 358),
):
    rows = [row for row in suites if stem in row["suite"] and "unittests" in row["suite"]]
    assert len(rows) == 1
    row = rows[0]
    path = Path(row["suite"].rsplit("(", 1)[1].removesuffix(")"))
    if not path.is_absolute():
        path = ROOT / path
    assert path.is_file()
    with (BASE / f"gate-{kind}-inventory-r1.log").open("xb") as output:
        completed = subprocess.run([str(path), "--list"], cwd=ROOT, stdout=output,
                                   stderr=subprocess.STDOUT, timeout=30)
    assert completed.returncode == 0
    names = re.findall(r"^(\S+): test$",
                       (BASE / f"gate-{kind}-inventory-r1.log").read_text(), re.M)
    outcomes = dict(row["results"])
    assert len(names) == len(set(names)) == expected_count
    assert set(names) == set(outcomes)
    assert all(outcomes[name] == "ok" for name in focused[kind]["required_new_tests"])
    binaries[kind] = {
        "path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "inventory_count": len(names), "inventory_matches_execution": True,
        "required_new_tests": focused[kind]["required_new_tests"],
        "required_new_tests_passed": len(focused[kind]["required_new_tests"]),
        "summary": row["summary"],
    }
interop = [row for row in suites if "tests/darwin_monitor_interop.rs " in row["suite"]]
assert len(interop) == 1 and interop[0]["summary"]["ignored"] == 15
assert all(dict(interop[0]["results"])[name] == "ignored"
           for name in focused["interop"]["required_new_tests"])
text = raw.decode()
discovery = text.split(" -m unittest discover -s scripts -p test_*.py", 1)[1].split(
    "Running: cargo fmt", 1,
)[0]
assert re.findall(r"Ran (\d+) tests? in", discovery) == ["293"]
assert "OK (skipped=2)" in discovery
assert re.findall(r"Ran (\d+) tests? in", text) == ["293", "30"]
assert "Dependency version policy: passed" in text
for marker in ("readiness-error-tests", "observer-io-error-tests", "controller-small-stack"):
    assert marker in text
result = {
    "ordinary_suites": len(suites),
    "ordinary_rust": {key: sum(row["summary"][key] for row in suites)
                      for key in ("passed", "failed", "ignored")},
    "rustdoc": {key: sum(row["summary"][key] for row in docs)
                for key in ("passed", "failed", "ignored")},
    "binaries": binaries, "python_run": 293, "python_skipped": 2,
    "archive_helper_python_run": 30, "new_real_tests_default_ignored": 6,
    "tests_replayed_for_derivation": 0,
}
for name, value in (("gate-summary-r1.json", result), ("gate-suites-r1.json", report)):
    with (BASE / name).open("x") as output:
        json.dump(value, output, indent=2)
        output.write("\n")
print(json.dumps(result))
