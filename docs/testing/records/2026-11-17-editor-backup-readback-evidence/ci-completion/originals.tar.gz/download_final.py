"""Preserve exact completed job logs without printing remote ANSI output."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import subprocess

BASE = Path(__file__).resolve().parent
state = json.loads((BASE / "ci-current-r3.log").read_text())
assert state["status"] == "completed" and state["conclusion"] == "success"
assert state["headSha"] == "a1a97b3b2ee0f0ccf91ea53ca96623aa8867fe8d"
jobs = state["jobs"]
assert len(jobs) == 3 and all(job["conclusion"] == "success" for job in jobs)


def download(job):
    target = BASE / f"job-{job['databaseId']}.log"
    with target.open("xb") as output:
        result = subprocess.run(
            ["gh", "api", "--allow-escape-sequences",
             f"repos/cyruss648/keelshell/actions/jobs/{job['databaseId']}/logs"],
            stdout=output, stderr=subprocess.PIPE, timeout=90,
        )
    assert result.returncode == 0, ("job log download failed", job["databaseId"])
    raw = target.read_bytes()
    return {
        "id": job["databaseId"], "name": job["name"], "status": job["status"],
        "conclusion": job["conclusion"], "file": target.name,
        "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
        "download_exit": result.returncode,
    }


with ThreadPoolExecutor(max_workers=3) as pool:
    report = {"source": state["headSha"], "run": 43934041540,
              "jobs": list(pool.map(download, jobs))}
with (BASE / "job-logs-r1.json").open("x") as output:
    json.dump(report, output, indent=2)
    output.write("\n")
print(json.dumps(report))
