"""Derive exact completed CI counts from archived job logs, without test replay."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
with tarfile.open(ROOT / "docs/testing/records/2026-11-17-editor-backup-readback-evidence/originals.tar.gz") as archive:
    parser_path = BASE / "summarize_tests.py"
    with parser_path.open("xb") as output:
        output.write(archive.extractfile("summarize_tests.py").read())
spec = importlib.util.spec_from_file_location("ci_parser", parser_path)
parser = importlib.util.module_from_spec(spec)
spec.loader.exec_module(parser)
jobs = json.loads((BASE / "job-logs-r1.json").read_text())
result = {"source": jobs["source"], "run": jobs["run"], "platforms": [],
          "tests_replayed": 0, "independent_ci_app_inventory_present": False}
for job in jobs["jobs"]:
    raw = (BASE / job["file"]).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == job["sha256"]
    parsed = parser.summarize(raw)
    suites = parsed["suites"]
    docs = parsed["doctest_runs_unassigned"]
    assert len(suites) == 92 and not parsed["inventory_result_summary_mismatches"]
    assert all(row["summary"]["state"] == "ok" and row["summary"]["failed"] == 0
               for row in suites + docs)
    app = [row for row in suites if "keelshell_app" in row["suite"]]
    assert len(app) == 1
    normalized = parser.normalize(raw)
    discovery = normalized.split(" -m unittest discover -s scripts -p test_*.py", 1)[1].split(
        "Running: cargo fmt", 1,
    )[0]
    counts = re.findall(r"Ran (\d+) tests? in", discovery)
    skipped = re.findall(r"OK \(skipped=(\d+)\)", discovery)
    assert counts == ["293"] and len(skipped) == 1
    record = {
        **job,
        "ordinary_suites": len(suites),
        "ordinary_rust": {key: sum(row["summary"][key] for row in suites)
                          for key in ("passed", "failed", "ignored")},
        "app": app[0]["summary"],
        "rustdoc": {key: sum(row["summary"][key] for row in docs)
                    for key in ("passed", "failed", "ignored")},
        "python_run": int(counts[0]), "python_skipped": int(skipped[0]),
        "declared_unique_results_and_summaries_equal": True,
    }
    result["platforms"].append(record)
    with (BASE / f"job-{job['id']}-suites.json").open("x") as output:
        json.dump(parsed, output, indent=2)
        output.write("\n")
with (BASE / "ci-summary-r1.json").open("x") as output:
    json.dump(result, output, indent=2)
    output.write("\n")
print(json.dumps(result))
