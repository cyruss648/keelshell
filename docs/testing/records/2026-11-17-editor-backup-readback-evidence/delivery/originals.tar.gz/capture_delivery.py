"""Read back this checkout, its tracking ref and the actual remote branch."""
from datetime import datetime, timezone
import json
import re
import subprocess
import sys

expected = sys.argv[1]
assert re.fullmatch(r"[0-9a-f]{40}", expected)


def git(*args):
    return subprocess.check_output(["git", *args], text=True, timeout=60).strip()


branch = git("branch", "--show-current")
local = git("rev-parse", "HEAD")
tracking = git("rev-parse", "@{upstream}")
remote_line = git("ls-remote", "--heads", "origin", f"refs/heads/{branch}")
assert remote_line.split() == [expected, f"refs/heads/{branch}"], remote_line
status = git("status", "--porcelain=v1")
assert local == tracking == expected
assert not status, status
print(json.dumps({
    "observed_utc": datetime.now(timezone.utc).isoformat(),
    "branch": branch,
    "local": local,
    "tracking": tracking,
    "remote": expected,
    "equal": True,
    "working_tree_clean": True,
    "forced_push": False,
}))
