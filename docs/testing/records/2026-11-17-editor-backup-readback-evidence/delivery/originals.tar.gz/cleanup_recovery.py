"""Reconcile the completed file removals and finish bounded directory cleanup."""
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
SOURCE = "f810f674c57b2c25dac5b987d77bf38656e3af56"
MAIN = "docs/testing/records/2026-11-17-editor-backup-readback-evidence"
PREVIOUS = "docs/testing/records/2026-11-17-darwin-tcp-listeners-evidence/ci-completion"


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def sealed(directory):
    manifest = json.loads(subprocess.check_output(
        ["git", "show", f"{SOURCE}:{directory}/manifest.json"], cwd=ROOT, timeout=30,
    ))
    raw = subprocess.check_output(
        ["git", "show", f"{SOURCE}:{directory}/originals.tar.gz"], cwd=ROOT, timeout=30,
    )
    assert len(raw) == manifest["archive_bytes"] and digest(raw) == manifest["archive_sha256"]
    with tarfile.open(fileobj=io.BytesIO(raw), mode="r:gz") as archive:
        files = {row.name: archive.extractfile(row).read() for row in archive}
    assert set(files) == {row["path"] for row in manifest["entries"]}
    for row in manifest["entries"]:
        assert len(files[row["path"]]) == row["bytes"]
        assert digest(files[row["path"]]) == row["sha256"]
    return files


failed = json.loads((BASE / "cleanup-command-r1.json").read_text())
failed_log = (BASE / "cleanup-command-r1.log").read_bytes()
assert failed["controller_exit"] == failed["observed_exit"] == 1
assert failed["terminal"]["direct_reaped"] and failed["terminal"]["active_processes"] == 0
assert digest(failed_log) == failed["log_sha256"]
assert b"Directory not empty" in failed_log and b"previous-ci" in failed_log
main = sealed(MAIN)
previous = sealed(PREVIOUS)
plan = []
for directory, files in ((MAIN, main), (PREVIOUS, previous)):
    for name, raw in files.items():
        if name != "run_command.py":
            plan.append({
                "path": name, "bytes": len(raw), "sha256": digest(raw),
                "durable_original": f"{SOURCE}:{directory}/originals.tar.gz::{name}",
            })
for row in json.loads(main["normal-package-r1.json"])["files"]:
    plan.append({
        **row, "path": "package-precommit-r1/" + row["path"],
        "durable_original": f"{SOURCE}:{MAIN}/originals.tar.gz::normal-package-r1.json",
    })
assert len(plan) == len({row["path"] for row in plan}) == 242
assert all(not (BASE / row["path"]).exists() for row in plan)
normal = json.loads((BASE / "normal-package-committed-r1.json").read_text())
for row in normal["files"]:
    raw = (BASE / "package-r1" / row["path"]).read_bytes()
    assert len(raw) == row["bytes"] and digest(raw) == row["sha256"]
target = ROOT / "work/recovery-batch-integration-20261115/target"
before = (target.stat().st_dev, target.stat().st_ino)
extra = BASE / "previous-ci/summarize_source_ci.py"
extra_raw = extra.read_bytes()
pending = {
    "path": extra.relative_to(BASE).as_posix(), "bytes": len(extra_raw),
    "sha256": digest(extra_raw), "action": "retained for delivery sealing",
}
with (BASE / "cleanup-plan-r2.json").open("x") as output:
    json.dump({"r1_removed_and_now_absent": plan, "retained_unsealed_helper": pending},
              output, indent=2)
    output.write("\n")
removed_directories = []
for name in ("openssh-r1", "package-precommit-r1"):
    path = BASE / name
    for child in sorted(path.rglob("*"), key=lambda item: len(item.parts), reverse=True):
        assert child.is_dir()
        child.rmdir()
        removed_directories.append(child.relative_to(BASE).as_posix())
    path.rmdir()
    removed_directories.append(name)
assert before == (target.stat().st_dev, target.stat().st_ino)
result = {
    "observed_utc": datetime.now(timezone.utc).isoformat(), "source": SOURCE,
    "prior_r1_exit": 1,
    "prior_r1_failure": "Directory removal met one unsealed helper; no helper deletion",
    "prior_r1_verified_files_now_absent": len(plan),
    "prior_r1_removed_bytes": sum(row["bytes"] for row in plan),
    "r2_removed_files": 0, "r2_removed_directories": removed_directories,
    "retained_unsealed_helper": pending,
    "current_normal_package_six_files_equal_committed_provenance_receipt": True,
    "shared_target_directory_identity_unchanged_during_recovery": True,
    "shared_target_directory_identity": list(before),
    "r1_before_after_target_comparison_available": False,
    "created_user_chats": 0, "created_worktrees": 0,
    "created_branches": 0, "created_containers": 0,
}
with (BASE / "cleanup-r2.json").open("x") as output:
    json.dump(result, output, indent=2)
    output.write("\n")
print(json.dumps(result))
