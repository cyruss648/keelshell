"""Remove only owned copies that equal durable originals in the pushed commit."""
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import stat
import subprocess
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
SOURCE = "f810f674c57b2c25dac5b987d77bf38656e3af56"
MAIN = "docs/testing/records/2026-11-17-editor-backup-readback-evidence"
PREVIOUS = "docs/testing/records/2026-11-17-darwin-tcp-listeners-evidence/ci-completion"


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def sealed(directory):
    manifest = json.loads(subprocess.check_output(
        ["git", "show", f"{SOURCE}:{directory}/manifest.json"], cwd=ROOT, timeout=30,
    ))
    raw = subprocess.check_output(
        ["git", "show", f"{SOURCE}:{directory}/originals.tar.gz"], cwd=ROOT, timeout=30,
    )
    assert len(raw) == manifest["archive_bytes"] and digest(raw) == manifest["archive_sha256"]
    files = {}
    with tarfile.open(fileobj=io.BytesIO(raw), mode="r:gz") as archive:
        for member in archive:
            name = PurePosixPath(member.name)
            assert member.isfile() and not name.is_absolute() and ".." not in name.parts
            assert member.name not in files
            files[member.name] = archive.extractfile(member).read()
    assert set(files) == {row["path"] for row in manifest["entries"]}
    for row in manifest["entries"]:
        assert len(files[row["path"]]) == row["bytes"]
        assert digest(files[row["path"]]) == row["sha256"]
    return files


def package_rows(stage):
    return [
        {"path": path.relative_to(stage).as_posix(), "bytes": path.stat().st_size,
         "sha256": digest(path.read_bytes())}
        for path in sorted(stage.rglob("*")) if path.is_file()
    ]


main = sealed(MAIN)
previous = sealed(PREVIOUS)
assert len(main) == 206 and len(previous) == 31
packages = [
    BASE / "package-r1",
    ROOT / "work/darwin-tcp-listeners-20261117/package-r1",
]
before = {str(stage.relative_to(ROOT)): package_rows(stage) for stage in packages}
assert all(len(rows) == 6 for rows in before.values())
target = ROOT / "work/recovery-batch-integration-20261115/target"
target_before = (target.stat().st_dev, target.stat().st_ino)
plan = []


def candidate(name, expected, provenance):
    relative = PurePosixPath(name)
    assert not relative.is_absolute() and ".." not in relative.parts
    path = BASE / name
    assert path.is_relative_to(BASE)
    assert not path.is_symlink() and stat.S_ISREG(path.stat().st_mode)
    raw = path.read_bytes()
    assert len(raw) == expected["bytes"] and digest(raw) == expected["sha256"], name
    plan.append({
        "path": name, "bytes": len(raw), "sha256": digest(raw),
        "durable_original": provenance,
    })


for directory, files in ((MAIN, main), (PREVIOUS, previous)):
    for name, raw in files.items():
        if name == "run_command.py":
            continue
        candidate(name, {"bytes": len(raw), "sha256": digest(raw)},
                  f"{SOURCE}:{directory}/originals.tar.gz::{name}")
precommit = json.loads(main["normal-package-r1.json"])
for row in precommit["files"]:
    candidate("package-precommit-r1/" + row["path"], row,
              f"{SOURCE}:{MAIN}/originals.tar.gz::normal-package-r1.json")
assert len({row["path"] for row in plan}) == len(plan)
for row in plan:
    (BASE / row["path"]).unlink()
for name in ("source-review", "function-review", "previous-ci", "openssh-r1", "package-precommit-r1"):
    path = BASE / name
    for child in sorted(path.rglob("*"), key=lambda item: len(item.parts), reverse=True):
        if child.is_dir():
            child.rmdir()
    path.rmdir()
after = {str(stage.relative_to(ROOT)): package_rows(stage) for stage in packages}
assert before == after
assert target_before == (target.stat().st_dev, target.stat().st_ino)
result = {
    "observed_utc": datetime.now(timezone.utc).isoformat(),
    "source": SOURCE,
    "removed_files": len(plan),
    "removed_bytes": sum(row["bytes"] for row in plan),
    "source_originals_verified_from_git": True,
    "preserved_normal_packages_before": before,
    "preserved_normal_packages_after": after,
    "package_files_unchanged": True,
    "shared_target_directory_identity_unchanged": True,
    "shared_target_directory_identity": list(target_before),
    "removed": plan,
    "created_user_chats": 0, "created_worktrees": 0,
    "created_branches": 0, "created_containers": 0,
}
with (BASE / "cleanup-r1.json").open("x") as output:
    json.dump(result, output, indent=2)
    output.write("\n")
print(json.dumps({
    key: value for key, value in result.items()
    if key not in ("removed", "preserved_normal_packages_before", "preserved_normal_packages_after")
}))
