"""Stage already-verified release binaries with their committed source provenance."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
SOURCE = "f810f674c57b2c25dac5b987d77bf38656e3af56"
assert subprocess.check_output(
    ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True, timeout=10,
).strip() == SOURCE
old = json.loads((BASE / "package-precommit-manifest-r1.json").read_text())
release = ROOT / "work/recovery-batch-integration-20261115/target/release"
for name, key in (("keelshell-app", "binary_sha256"), ("keelshell-mcp", "mcp_binary_sha256")):
    assert hashlib.sha256((release / name).read_bytes()).hexdigest() == old[key]


def run(label, *args):
    subprocess.run(
        [sys.executable, "-B", str(BASE / "run_command.py"), label, "120", *map(str, args)],
        cwd=ROOT, check=True,
    )


stage = BASE / "package-r1"
run("package-r1", "env", "-u", "GITHUB_RUN_ID", f"KEELSHELL_BUILD_COMMIT={SOURCE}",
    sys.executable, "-B", ROOT / "packaging/package.py", "macos",
    "--binary", release / "keelshell-app", "--mcp-binary", release / "keelshell-mcp",
    "--target", "aarch64-apple-darwin", "--output", stage)
run("package-final-inspect-r1", sys.executable, "-B", ROOT / "packaging/inspect_native.py",
    "--platform", "macos", "--target", "aarch64-apple-darwin", "--stage", stage)
manifest = json.loads((stage / "package-manifest.json").read_text())
assert manifest["build"]["commit"] == SOURCE
assert manifest["build"]["workflow_run"] is None
assert manifest["files"] == old["files"]
assert manifest["binary_sha256"] == old["binary_sha256"]
assert manifest["mcp_binary_sha256"] == old["mcp_binary_sha256"]
assert not manifest["installed"] and not manifest["signed_by_packaging_script"]
rows = []
for path in sorted(stage.rglob("*")):
    if path.is_file():
        raw = path.read_bytes()
        name = path.relative_to(stage).as_posix()
        row = {"path": name, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
        if name != "package-manifest.json":
            assert row["sha256"] == manifest["files"][name]
            assert raw == (BASE / "package-precommit-r1" / name).read_bytes()
        rows.append(row)
result = {
    "source": SOURCE,
    "freeze": "inputs-freeze-r4.json",
    "gui_sha256": manifest["binary_sha256"],
    "mcp_sha256": manifest["mcp_binary_sha256"],
    "all_application_files_equal_precommit": True,
    "only_manifest_build_provenance_changed": True,
    "release_binaries_recompiled": False,
    "installed": False, "signed": False, "native_desktop_acceptance": False,
    "files": rows,
}
with (BASE / "normal-package-committed-r1.json").open("x") as output:
    json.dump(result, output, indent=2)
    output.write("\n")
with (BASE / "package-committed-manifest-r1.json").open("x") as output:
    json.dump(manifest, output, indent=2)
    output.write("\n")
print(json.dumps({key: value for key, value in result.items() if key != "files"}))
