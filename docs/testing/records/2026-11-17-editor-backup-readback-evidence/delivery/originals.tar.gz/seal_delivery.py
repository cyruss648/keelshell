"""Seal post-push delivery, diagnostics and the isolated Windows test fix."""
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
DEST = ROOT / "docs/testing/records/2026-11-17-editor-backup-readback-evidence/delivery"
assert not (DEST / "manifest.json").exists() and not (DEST / "originals.tar.gz").exists()
assert (BASE / "windows-review-r1/receipt.json").is_file()
assert (BASE / "windows-review-closed-r1.json").is_file()
assert (BASE / "windows-fix-gate-r1.json").is_file()
files = {}
entries = []
for path in sorted(BASE.rglob("*")):
    name = path.relative_to(BASE)
    if not path.is_file() or "package-r1" in name.parts or "__pycache__" in name.parts:
        continue
    assert path.suffix in (".json", ".log", ".py", ".md"), name
    raw = path.read_bytes()
    files[name.as_posix()] = raw
    entries.append({
        "path": name.as_posix(), "bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
    })
packed = io.BytesIO()
with gzip.GzipFile(fileobj=packed, mode="wb", filename="", mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as archive:
        for row in entries:
            info = tarfile.TarInfo(row["path"])
            info.size = row["bytes"]
            info.mode = 0o644
            archive.addfile(info, io.BytesIO(files[row["path"]]))
for name, raw in files.items():
    assert (BASE / name).read_bytes() == raw, name
raw = packed.getvalue()
freeze = json.loads(files["inputs-freeze-r5.json"])
manifest = {
    "sealed_utc": datetime.now(timezone.utc).isoformat(),
    "delivered_source": "f810f674c57b2c25dac5b987d77bf38656e3af56",
    "followup_includes_working_diff": True,
    "engineering_inputs": 727, "aggregate_sha256": freeze["aggregate_sha256"],
    "count": len(entries), "archive_bytes": len(raw),
    "archive_sha256": hashlib.sha256(raw).hexdigest(), "entries": entries,
}
with (DEST / "originals.tar.gz").open("xb") as output:
    output.write(raw)
with (DEST / "manifest.json").open("x") as output:
    json.dump(manifest, output, indent=2)
    output.write("\n")
print(json.dumps({key: value for key, value in manifest.items() if key != "entries"}))
