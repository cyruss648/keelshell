"""Derive the limited host gate and preserve its exact compiled inventory."""
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]


def derive(raw, old_inventory, new_names):
    text = raw.decode()
    inventory_part, execution = text.split(
        "Running: cargo test -p keelshell-session --lib --locked -- --test-threads=4\n", 1,
    )
    inventory_part = inventory_part.split(
        "Running: cargo test -p keelshell-session --lib --locked -- --list\n", 1,
    )[1]
    inventory = re.findall(r"^(\S+): test$", inventory_part, re.M)
    old = re.findall(r"^(\S+): test$", old_inventory.decode(), re.M)
    outcomes = re.findall(r"^test (\S+) \.\.\. (ok|ignored[^\n]*|FAILED)$", execution, re.M)
    statuses = {name: ("ignored" if status.startswith("ignored") else status)
                for name, status in outcomes}
    assert len(inventory) == len(set(inventory)) == 343
    assert len(outcomes) == len(statuses) == 343
    assert sorted(inventory) == sorted(old) == sorted(statuses)
    assert all(status in ("ok", "ignored") for status in statuses.values())
    assert re.findall(r"^running (\d+) tests$", execution, re.M) == ["343"]
    assert re.findall(
        r"^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;", execution, re.M,
    ) == [("339", "0", "4")]
    assert len(new_names) == 30 and all(statuses[name] == "ok" for name in new_names)
    return {
        "log_sha256": hashlib.sha256(raw).hexdigest(), "inventory": 343,
        "inventory_equals_r4_and_execution": True,
        "session": {"passed": 339, "failed": 0, "ignored": 4},
        "new_backup_tests_passed": 30,
        "fmt": "passed", "strict_clippy": "passed", "dependency_policy": "passed",
        "diff_check": "passed", "tests_replayed_for_derivation": 0,
        "windows_compilation_or_execution": False,
        "results": sorted(statuses.items()),
    }


if __name__ == "__main__":
    source = "f810f674c57b2c25dac5b987d77bf38656e3af56"
    raw = subprocess.check_output([
        "git", "show",
        f"{source}:docs/testing/records/2026-11-17-editor-backup-readback-evidence/originals.tar.gz",
    ], cwd=ROOT, timeout=30)
    with tarfile.open(fileobj=io.BytesIO(raw), mode="r:gz") as archive:
        old_inventory = archive.extractfile("session-inventory-r4.log").read()
        new_names = json.loads(archive.extractfile("author-handoff.json").read())["new_tests"]
    gate = (BASE / "windows-fix-gate-r1.log").read_bytes()
    receipt = json.loads((BASE / "windows-fix-gate-r1.json").read_text())
    assert receipt["observed_exit"] == receipt["controller_exit"] == 0
    assert hashlib.sha256(gate).hexdigest() == receipt["log_sha256"]
    result = derive(gate, old_inventory, new_names)
    paths = set(re.findall(r"^\s+Running unittests[^\n]*\(([^)\n]+)\)$", gate.decode(), re.M))
    assert len(paths) == 1
    path = (ROOT / paths.pop()).resolve(strict=True)
    data = path.read_bytes()
    result["binary"] = {
        "path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
    }
    with (BASE / "windows-fix-summary-r1.json").open("x") as output:
        json.dump(result, output, indent=2)
        output.write("\n")
    print(json.dumps({key: value for key, value in result.items() if key != "results"}))
