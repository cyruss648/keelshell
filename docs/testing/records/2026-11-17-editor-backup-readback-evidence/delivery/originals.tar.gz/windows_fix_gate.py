"""Validate a Windows-test-only match-arm fix without repeating the full host gate."""
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
SOURCE = "f810f674c57b2c25dac5b987d77bf38656e3af56"
EVIDENCE = "docs/testing/records/2026-11-17-editor-backup-readback-evidence"
CHANGED = "crates/keelshell-session/src/sftp/archive_transfer/local_windows/tests.rs"
raw = subprocess.check_output(
    ["git", "show", f"{SOURCE}:{EVIDENCE}/originals.tar.gz"], cwd=ROOT, timeout=30,
)
manifest = json.loads(subprocess.check_output(
    ["git", "show", f"{SOURCE}:{EVIDENCE}/manifest.json"], cwd=ROOT, timeout=30,
))
assert hashlib.sha256(raw).hexdigest() == manifest["archive_sha256"]
with tarfile.open(fileobj=io.BytesIO(raw), mode="r:gz") as archive:
    baseline = json.loads(archive.extractfile("inputs-freeze-r4.json").read())


def snapshot(label, expected=None):
    names = sorted({
        name.decode() for name in subprocess.check_output(
            ["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"],
            cwd=ROOT, timeout=30,
        ).split(b"\0") if name and not name.startswith((b"docs/", b".hallmark/"))
    })
    rows = []
    for name in names:
        data = (ROOT / name).read_bytes()
        rows.append({
            "path": name, "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest(),
        })
    assert [row["path"] for row in rows] == [row["path"] for row in baseline["inputs"]]
    changes = [row["path"] for row, old in zip(rows, baseline["inputs"]) if row != old]
    assert changes == [CHANGED], changes
    if expected is not None:
        assert rows == expected
    result = {
        "captured_utc": datetime.now(timezone.utc).isoformat(), "head": SOURCE,
        "count": len(rows),
        "aggregate_sha256": hashlib.sha256("".join(
            f"{row['path']}\0{row['sha256']}\n" for row in rows
        ).encode()).hexdigest(),
        "changed_from_r4": changes, "inputs": rows,
    }
    with (BASE / label).open("x") as output:
        json.dump(result, output, indent=2)
        output.write("\n")
    print(json.dumps({key: value for key, value in result.items() if key != "inputs"}),
          flush=True)
    return rows


assert os.environ["CARGO_TARGET_DIR"] == str(
    ROOT / "work/recovery-batch-integration-20261115/target"
)
assert subprocess.check_output(
    ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True, timeout=10,
).strip() == SOURCE
rows = snapshot("inputs-freeze-r5.json")
for command in (
    ["python3", "-B", "scripts/check.py", "--policy-only"],
    ["cargo", "fmt", "--all", "--check"],
    ["cargo", "clippy", "--workspace", "--all-targets", "--locked", "--", "-D", "warnings"],
    ["cargo", "test", "-p", "keelshell-session", "--lib", "--locked", "--", "--list"],
    ["cargo", "test", "-p", "keelshell-session", "--lib", "--locked", "--", "--test-threads=4"],
    ["git", "diff", "--check"],
):
    print("Running: " + " ".join(command), flush=True)
    subprocess.run(command, cwd=ROOT, check=True)
snapshot("windows-inputs-after-r1.json", rows)
print("Windows-only fix scoped host gate passed; Windows compilation/execution pending CI.",
      flush=True)
