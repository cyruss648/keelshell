"""Publish the independent r3 execution result with the still-open tooltip P2."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

import verify_prebuilt as verification

BASE = Path(__file__).resolve().parent
ROOT = verification.ROOT


def file_row(path):
    path = Path(path)
    return {
        "path": str(path),
        "bytes": path.stat().st_size,
        "sha256": verification.sha(path),
    }


def link(path, line):
    return f"[{path}:{line}]({ROOT / path}:{line})"


def main():
    summary = json.loads((BASE / "execution-summary.json").read_text())
    commands = {}
    for label in ["session-list", "app-list", "openssh-list", "session-editor", "app-editor"]:
        commands[label] = json.loads((BASE / f"{label}.json").read_text())
    source_comparisons = {}
    for label, path, prefix in [
        ("session", "crates/keelshell-session/src/sftp/editor_backup_tests.rs", "sftp::editor_backup_tests::"),
        ("app", "crates/keelshell-app/src/files/editor_backup_tests.rs", "files::transfer_tests::editor_backup_tests::"),
    ]:
        names = [prefix + name for name in re.findall(
            r"^async fn (editor_backup_\w+)\(", (ROOT / path).read_text(), re.M
        )]
        required = summary[label]["inventory"]["required_new_tests"]
        assert sorted(names) == sorted(required)
        source_comparisons[label] = {
            "source": file_row(ROOT / path), "count": len(names),
            "source_names_equal_required_names": True,
            "required_names_all_in_independent_inventory": True,
            "required_names_all_executed_ok": True,
            "names": names,
        }
    dependency = Path("/Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837/gpui-pre-0.3.12/src/elements/div.rs")
    finding = {
        "id": "P2-UI-001",
        "priority": "P2",
        "status": "OPEN_IN_R3",
        "title": "状态详情使用普通 tooltip，长消息无法移入滚动读取",
        "file": str(ROOT / "crates/keelshell-app/src/files/view.rs"),
        "line": 921,
        "additional_lines": [932, 933, 934],
        "trigger": "完整状态换行后超过 220px，用户将指针从状态行移入详情并尝试滚轮读取尾部。",
        "impact": "普通 tooltip 不保留 tooltip 内部悬停；完整 AX 名称仍存在，但指针用户无法读取被裁切的可视尾部，不能支持完整详情可滚动读取的声称。",
        "origin": "Parent relayed Arendt's source-review P2 during this review.",
        "independent_corroboration": {
            "method": "Local source inspection of pinned dependency and current view/test.",
            "gpui_dependency": file_row(dependency),
            "ordinary_tooltip_sets_hoverable_false_line": 732,
            "hoverable_tooltip_sets_hoverable_true_line": 751,
            "hover_check_branch_lines": [3914, 3917, 3918],
            "existing_test_file": str(ROOT / "crates/keelshell-app/src/files/editor_backup_tests.rs"),
            "existing_test_hover_line": 109,
            "existing_test_matrix_line": 115,
            "current_test_moves_pointer_into_tooltip_or_scrolls_it": False,
            "independent_native_reproduction": False,
        },
        "required_followup": "Parent fixes hover behavior and adds real move-into-tooltip/wheel assertions; verify new r4 freeze and binaries independently without Cargo. No r4 closure is claimed here.",
    }
    snapshots = {
        p.name: json.loads(p.read_text()) for p in sorted(BASE.glob("*.snapshot.json"))
    }
    initial_docs = snapshots["session-list-before.snapshot.json"]["document_sha256"]
    for row in snapshots.values():
        assert row["document_sha256"] == initial_docs
        assert row["aggregate_sha256"] == verification.EXPECTED_AGGREGATE
        assert row["inputs_match_freeze"]
    final_snapshot = verification.snapshot("review-r3-final")
    assert final_snapshot["document_sha256"] == initial_docs
    parent_list_equal = {
        label: (BASE / f"{label}-list.log").read_bytes()
        == (BASE.parent / f"{label}-inventory-r3.log").read_bytes()
        for label in ["session", "app", "openssh"]
    }
    assert all(parent_list_equal.values())
    receipt = {
        "schema_version": 1,
        "review": "Independent non-author editor backup functional verification, r3",
        "completed_utc": datetime.now(timezone.utc).isoformat(),
        "workspace": str(ROOT),
        "verdict": "REQUEST_CHANGES",
        "finding_counts": {"P0": 0, "P1": 0, "P2": 1, "P3": 0},
        "findings": [finding],
        "r4_status": "NOT_REVIEWED; await parent-provided freeze and binary metadata",
        "binding": {
            "head": verification.EXPECTED_HEAD,
            "working_diff_included": True,
            "freeze": file_row(verification.FREEZE),
            "freeze_count": 727,
            "aggregate_sha256": verification.EXPECTED_AGGREGATE,
            "parent_prebuilt_metadata": file_row(verification.METADATA),
            "independent_compilation": False,
            "parent_prebuilt": True,
            "binaries": final_snapshot["binaries"],
            "all_5_executions_have_before_and_after_freeze_and_all_binary_hashes": True,
            "all_snapshot_inputs_equal_freeze": True,
            "monitored_document_hashes_unchanged": True,
            "final_snapshot": str(BASE / "review-r3-final.snapshot.json"),
            "independent_list_logs_byte_equal_parent_r3_lists": parent_list_equal,
            "wrapper_provenance": str(BASE / "wrapper-provenance.json"),
            "snapshot_files": [*snapshots, "review-r3-final.snapshot.json"],
        },
        "commands": commands,
        "execution_totals": {
            "owned_commands": 5, "independent_list_commands": 3, "test_commands": 2,
            "passed": 153, "failed": 0, "ignored": 0,
            "session": {
                **summary["session"]["execution"],
                "full_inventory": summary["session"]["inventory"]["test_count"],
                "new_tests_count": 30,
            },
            "app": {
                **summary["app"]["execution"],
                "full_inventory": summary["app"]["inventory"]["test_count"],
                "new_tests_count": 4,
            },
            "openssh": {
                "full_inventory": 18, "independently_executed": 0,
                "new_test_in_independent_list": summary["openssh"]["inventory"]["required_new_tests"][0],
            },
        },
        "source_to_compiled_inventory": source_comparisons,
        "evidence_assessment": {
            "bytes_and_stages": "Supported within controlled TCP/SSH/SFTP observation; complete original bytes, EOF, metadata, readonly CLOSE precede target staging.",
            "revocation_cancellation_and_unknown": "Controlled regressions pass; Closed/cancel and MutationUncertain/quarantine retain distinct outcomes; cancellation is not rollback.",
            "three_theme_bilingual_matrix": {
                "families": ["frost", "graphite", "lavender"],
                "modes": ["Light", "Dark"], "languages": ["ZhCn", "En"],
                "combinations": 12,
                "supported": "Live complete labels, tooltip visibility/bounds, language/theme redraw without additional SFTP requests.",
                "unsupported": "Pointer entry and scroll-to-tail were absent from r3 tests; P2 remains open.",
            },
            "openssh_new_positive_source_review": {
                "test_file": file_row(ROOT / "crates/keelshell-session/tests/support/openssh_editor_backup.rs"),
                "initial_cases": ["UTF-8 Unicode/CRLF and quoted shell-metacharacter filename", "BOM UTF-16 BE", "explicit GBK", "empty UTF-8"],
                "saves_per_case": 2, "unique_backups": 8,
                "assertions": ["Exact prior backup bytes", "Exact backup size and 0100600 mode", "Exact target bytes and retained mode", "Unique backup paths", "All eight backups rechecked after all saves", "SSH connection remains usable", "Success-path cleanup"],
                "bounded_timeout_seconds": 75,
                "native_or_real_server_execution_by_reviewer": False,
                "scope_limit": "Positive standard-server compatibility only; does not inject server faults, prove transport order on OpenSSH, or cover every supported encoding there.",
            },
        },
        "parent_reported_only": {
            "source": "User's steering message during this review; not independently collected or signed by this reviewer.",
            "current_r3_dependency_check": "37 packages / 113 declarations passed",
            "current_openssh": "18 passed",
            "previous_bd198a8_ci": "All three platforms success; not the current working diff",
            "planned_tooltip_fix": "hoverable_tooltip plus pointer-entry/wheel regression after parent's release build exits",
        },
        "boundaries": {
            "cargo_commands": 0, "format_commands": 0,
            "intentional_target_writes": 0,
            "source_or_repository_document_edits": 0,
            "git_commits_pushes_cleanups": 0,
            "reviewer_outputs_directory": str(BASE),
            "temporary_test_data_directory": str(BASE / "tmp"),
            "not_verified": [
                "Independent compilation or source-to-machine-code reconstruction",
                "Full Cargo/Clippy/fmt/dependency gate for current candidate",
                "Reviewer-owned real OpenSSH service execution or independent parent evidence collection",
                "r4 inputs, binaries, tooltip fix or new interaction regression",
                "Current exact-source three-platform CI",
                "Native macOS/Windows/Linux visual, pointer, keyboard, IME or assistive-technology acceptance",
                "CAS, continuous remote identity, crash durability, transaction rollback, owner/ACL/special-mode retention",
                "Normal release package build/installation/signing/notarization",
            ],
        },
    }
    report = [
        "**REQUEST_CHANGES — r3 编辑器备份功能复核。P0=0、P1=0、P2=1、P3=0。**",
        "",
        "独立执行的 153 项用例全部通过，新增 session 30 项与 app 4 项逐名存在且实际为 ok。"
        "这些结果保留为 r3 的有效专项证据；状态详情无法移入滚动的 P2 仍开放，不能声明本批交互验收完成或缺陷已关闭。",
        "",
        f"复核目录：`{ROOT}`。HEAD `{verification.EXPECTED_HEAD}` 加 working diff；冻结为 "
        f"`{verification.FREEZE}`，727 项，aggregate `{verification.EXPECTED_AGGREGATE}`。"
        "已先读 AGENTS、HANDOFF、ADR 0153、REMOTE_TEXT_FORMAT、当前测试记录及 SHARED_TARGET 合同。",
        "",
        "本次使用父级预编译二进制，未独立编译。session/app/OpenSSH 的独立 `--list` 为 343/1373/18，"
        "与父级 r3 库存日志逐字节相等。本次按宽过滤器 `editor --test-threads=2` 运行，不只运行新增模块；"
        "源码新增名字与独立库存、逐名执行结果三方相等。下表的 filtered out 是当前二进制中本次未执行的其他用例。",
        "",
        "| 二进制 | 独立全名库存 | 实际 passed / failed / ignored | filtered out | 新增实际 ok | libtest 秒 / owned 秒 |",
        "| --- | ---: | --- | ---: | ---: | --- |",
    ]
    for label, count in [("session", 30), ("app", 4)]:
        run = summary[label]["execution"]
        report.append(
            f"| {label} | {summary[label]['inventory']['test_count']} | "
            f"{run['passed']} / {run['failed']} / {run['ignored']} | {run['filtered_out']} | {count} | "
            f"{run['seconds_reported_by_harness']} / {commands[label + '-editor']['seconds']:.6f} |"
        )
    report.extend([
        "| openssh_interop | 18 | 本审未执行 | — | 新正例仅核库存与源码 | — |",
        "",
        "五次命令均由项目 owned/bounded `run_command.py` 的自有副本执行；副本 ROOT 已固定为项目根，"
        "关闭 Python bytecode 写入并将 TMPDIR 指向本审目录。每次命令前后均重新计算全部 727 输入及三个二进制 SHA；"
        "10 份命令边界 snapshot 和额外收口 snapshot 均保持 r3。所有回执均 observed_exit=controller_exit=0，"
        "direct_reaped=true、active_processes=0、pipes_drained=true、errors=[]，无超时或中断。",
        "",
        "| 二进制 | SHA-256（执行前后及收口均一致） |",
        "| --- | --- |",
    ])
    report.extend(f"| {row['target']} | `{row['actual_sha256']}` |" for row in final_snapshot["binaries"])
    report.extend([
        "",
        "**开放发现 P2-UI-001：长状态详情无法移入滚动读取。**",
        "",
        f"位置：{link('crates/keelshell-app/src/files/view.rs', 921)}，详情在 932–935 行使用 "
        "`max_w(480)`、`max_h(220)` 与 `overflow_y_scroll()`，但触发器使用普通 `.tooltip(...)`。"
        "当长消息换行后超过 220px，指针离开状态行移入详情会失去普通 tooltip 的悬停保持，"
        "滚动尾部不可达；完整 AX label 并不能提供指针交互保证。该问题由父级转述 Arendt 发现，"
        "本审已独立核对当前 view 与精确本地依赖的实现机制，没有声称完成独立原生复现。",
        "",
        f"依赖证据：`{dependency}:722–751`，普通 tooltip 设置 `hoverable: false`（732），"
        "`hoverable_tooltip` 设置 true（751）；3914–3918 的鼠标检查仅为可悬停 tooltip 保留内部悬停。"
        f"现有回归 {link('crates/keelshell-app/src/files/editor_backup_tests.rs', 109)} "
        "只 hover 状态行，随后检查可见性、标签、边界及主题语言更新；没有移入详情或滚轮读取断言。"
        "因此即使现有四项通过，也不能关闭该 P2。父级计划的修复和新回归须绑定新 r4 freeze/binary 后独立补验；"
        "本报告不预签 r4。",
        "",
        "**字节、阶段、取消和 UNKNOWN 的可支持范围。**",
        "",
        f"生产链 {link('crates/keelshell-session/src/sftp.rs', 734)} 先完成备份 helper，再进入原目标替换。"
        "742–800 在原备份 deadline 与同一 reservation 内读回，检查读前后授权、全部原始字节、精确大小和 "
        "`0100600`；使用既有 checked reader，目标替换前仍保留完整旧 snapshot 再核验。"
        f"{link('crates/keelshell-session/src/sftp/inspection.rs', 58)} 的父链、leaf、opened FSTAT、"
        "完整 EOF、结束 FSTAT/leaf 和 CLOSE ACK 检查支持这一有界观察合同；"
        f"{link('crates/keelshell-session/src/sftp/mutation.rs', 94)} "
        "保留 pending、失效 reservation、未知 cleanup 的 MutationUncertain 优先级。",
        "",
        "30 项新 session 回归通过真实隔离 loopback TCP/SSH/SFTP 调用 production public API。"
        "事件日志断言备份发布、完整 READ/EOF、只读 CLOSE 早于 TargetStaged/TargetPublished；"
        "空源、100000 字节 Unicode、多块尾字节损坏、UTF-16 LE BOM 和五种显式旧编码均有覆盖。"
        "ACK 后损坏、截断、缺失、链接、目录、缺失类型/大小、错误权限、超大、读错误、早 EOF、"
        "三个元数据变化阶段和 CLOSE 失败均阻止目标 staging，保留可检查备份且不自动重试/删除。"
        "撤权、2 秒读回 deadline、共享 reservation busy、未知发布的隔离和同长竞争者目标再核验分别通过。",
        "",
        f"app 保存链 {link('crates/keelshell-app/src/files/worker.rs', 863)} "
        "只把 stop 已置位的 Closed 映射成取消，不把 MutationUncertain 映成普通读回错误。"
        "备份读回失败与目标发布后读回失败分别显示；目标完整字节相等才采用新基线。"
        "四项新 GPUI 回归验证已 ACK 备份失败时目标/草稿/旧基线保留、只读 CLOSE 前不发目标写入、"
        "较新 UTF-16 草稿不被迟到结果覆盖、实际取消按钮，以及目标已发布后的错误不误报为未发起。"
        "取消与断连仍不构成回滚。",
        "",
        f"三主题双语回归 {link('crates/keelshell-app/src/files/editor_backup_tests.rs', 115)} "
        "遍历当前 registry 的 Frost/Graphite/Lavender × Light/Dark × 中文/英文共 12 组合，"
        "核对完整当前 AX 名称、已打开 tooltip 的实时文本、可见边界与 SFTP 请求数不增加。"
        "可以支持这些组件和状态语义断言；不能支持尚缺的移入/滚轮读取、原生像素观感或完整辅助技术验收。",
        "",
        "**新 OpenSSH 正例：源码与库存通过审查，真实服务执行由父级持有。**",
        "",
        f"{link('crates/keelshell-session/tests/support/openssh_editor_backup.rs', 7)} "
        "存在于本审独立 18 名库存中。它在 75 秒预算内，用 pinned loopback Fixture 的 production API "
        "处理 Unicode UTF-8/CRLF（含引号与 shell 元字符文件名）、BOM UTF-16 BE、显式 GBK 和空 UTF-8；"
        "每个场景连续保存两次，第二次保存空正文，共八个唯一备份。"
        "逐次核对全部旧备份字节、精确大小/0600、完整新目标字节/原 mode，全部保存后再次读取八份备份，"
        "检查 SSH 仍可用，并在成功路径清理测试资源。该正例支持正常标准服务端兼容性；"
        "OpenSSH 上的故障注入、协议时序和所有编码组合不由这个正例单独建立。",
        "",
        "父级在本审进行中报告：当前 OpenSSH 18 项通过、依赖官方 37 包/113 声明通过、上一 bd198a8 "
        "三平台 CI success。本审未独立采集或重签这些原件；上一提交 CI 也不代签当前 working diff。"
        "真实 OpenSSH 本审执行数为 0。",
        "",
        "**新增 30 + 4 逐名结果（本审实际执行）。**",
        "",
        "```text",
    ])
    for label in ["session", "app"]:
        report.extend(f"{row['name']} ... {row['result']}" for row in summary[label]["execution"]["new_tests"])
    report.extend([
        "```",
        "",
        "**原始命令与回执。**",
        "",
        "```text",
    ])
    for command in commands.values():
        report.append(" ".join(command["command"]))
    report.extend([
        "```",
        "",
        f"逐名全量结果和全名库存见 [execution-summary.json]({BASE / 'execution-summary.json'})；"
        f"结构化签署见 [receipt.json]({BASE / 'receipt.json'})。"
        "各命令的原始 `*.log`、owned `*.json`、执行前后 `*.snapshot.json` 和 `*-parsed.json` 均在同目录。"
        "receipt 记录全部命令参数、真实退出、准确结果、全部 34 新名以及证据 SHA；不覆盖父级 r3 原件。",
        "",
        "本审没有运行 Cargo/fmt/Clippy、写 target、修改源码/项目文档、Git 提交/推送或清理。"
        "所有自有脚本、临时数据、报告和回执只在指定 function-review 目录。"
        "独立编译、集中完整门禁、当前源码精确三平台 CI、r4 修复、真实原生三平台桌面、IME/辅助技术、"
        "正常包安装签名发行均未验。完整读回是一轮有界字节/元数据观察，不是 CAS、持续身份锁、"
        "崩溃耐久性、自动恢复、事务回滚或 owner/ACL/特殊 mode 保留承诺。",
        "",
        "合并建议：等待 P2-UI-001 修复与 r4 交互补验；保留本次 r3 的冻结、库存、153 项成功和开放缺陷，"
        "后续使用新编号追加，不能把本轮结果改写成 r4 已通过。",
        "",
    ])
    with (BASE / "report.md").open("x") as output:
        output.write("\n".join(report))
    receipt["report"] = file_row(BASE / "report.md")
    receipt["evidence_files"] = [
        file_row(path) for path in sorted(BASE.iterdir())
        if path.is_file() and path.name != "receipt.json"
    ]
    verification.save("receipt.json", receipt)
    print(json.dumps({
        "verdict": receipt["verdict"], "finding_counts": receipt["finding_counts"],
        "passed": 153, "new_tests_passed": 34, "report": receipt["report"],
        "receipt": file_row(BASE / "receipt.json"),
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
