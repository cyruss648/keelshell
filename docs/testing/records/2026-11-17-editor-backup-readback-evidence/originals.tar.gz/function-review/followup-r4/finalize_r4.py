"""Finalize existing r4 results without replay after a document-only guard drift."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

import verify_r4

V = verify_r4.verifier
BASE = verify_r4.BASE
ROOT = verify_r4.ROOT
PARENT = verify_r4.PARENT
R3 = verify_r4.R3


def row(path):
    path = Path(path)
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": V.sha(path)}


def link(path, line):
    return f"[{path}:{line}]({ROOT / path}:{line})"


def frozen_rows(path):
    data = json.loads(path.read_text())
    aggregate = hashlib.sha256("".join(
        f"{item['path']}\0{item['sha256']}\n" for item in data["inputs"]
    ).encode()).hexdigest()
    assert aggregate == data["aggregate_sha256"]
    assert len(data["inputs"]) == data["count"] == 727
    return data


def main():
    required = json.loads((BASE / "required-new-tests.json").read_text())["names"]
    inventory = V.parse("app-list", "list", required)
    execution = V.parse("app-editor", "run", {
        "inventory": inventory["names"], "new_tests": required,
    })
    assert inventory["test_count"] == 1374
    assert execution["passed"] == 88 and execution["failed"] == execution["ignored"] == 0
    V.save("app-editor-parsed.json", execution)
    snapshots = {
        path.name: json.loads(path.read_text()) for path in sorted(BASE.glob("*.snapshot.json"))
    }
    assert len(snapshots) == 4
    initial = snapshots["app-list-before.snapshot.json"]
    document_drift = []
    for name, snapshot in snapshots.items():
        assert snapshot["head"] == V.EXPECTED_HEAD
        assert snapshot["aggregate_sha256"] == V.EXPECTED_AGGREGATE
        assert snapshot["inputs_match_freeze"]
        assert snapshot["binaries"] == initial["binaries"]
        for path, digest in snapshot["document_sha256"].items():
            if digest != initial["document_sha256"][path]:
                document_drift.append({
                    "snapshot": name, "path": path,
                    "before_sha256": initial["document_sha256"][path],
                    "after_sha256": digest,
                })
    assert document_drift
    assert all(item["path"].startswith("docs/") for item in document_drift)
    V.save("controller-postrun-diagnostic.json", {
        "script": str(BASE / "verify_r4.py"),
        "outer_observed_exit": 1,
        "failure": 'AssertionError at verify_r4.py:91: after["document_sha256"] == initial_docs',
        "stage": "After successful owned app test execution and after all engineering/binary hashes had matched.",
        "document_drift": document_drift,
        "app_test_observed_exit": 0,
        "app_test_controller_exit": 0,
        "engineering_inputs_unchanged": True,
        "binary_hashes_unchanged": True,
        "disposition": "Preserved the diagnostic; independently parsed the existing successful raw log and owned receipt. No tests replayed. Documentation is outside the parent's engineering freeze.",
    })
    V.save("execution-summary.json", {
        "inventory": inventory, "execution": execution,
        "completed_utc": datetime.now(timezone.utc).isoformat(),
        "tests_replayed": False,
        "postrun_document_guard_diagnostic": "controller-postrun-diagnostic.json",
    })
    history = []
    reasons = {
        1: "Initial long-message trigger/layout diagnostic; tooltip not found before validated pointer entry. Not the decisive hover-loss negative.",
        2: "Wrong old feature-unification binary: running 0 tests; exit zero is not a test pass or a valid negative reproduction.",
        3: "Initial long-message trigger/layout diagnostic on the actual negative binary; backtrace at first detail lookup, historical test source line 301.",
        4: "Truncate/line-clamp layout attempt still failed trigger-height assertion at historical line 293 (<=24px); not the hover-loss negative.",
        5: "Decisive ordinary-tooltip negative: real overflow and pointer entry completed; detail disappeared, find failed at historical line 324 after entry.",
    }
    for number in range(1, 6):
        label = f"tooltip-negative-r{number}"
        receipt_path, log_path = PARENT / f"{label}.json", PARENT / f"{label}.log"
        receipt = json.loads(receipt_path.read_text())
        raw = log_path.read_text()
        assert V.sha(log_path) == receipt["log_sha256"]
        match = re.search(
            r"test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; "
            r"(\d+) measured; (\d+) filtered out; finished in ([0-9.]+)s", raw,
        )
        assert match
        running = int(re.search(r"running (\d+) tests?", raw)[1])
        counts = dict(zip(
            ["passed", "failed", "ignored", "measured", "filtered_out"],
            map(int, match.group(2, 3, 4, 5, 6)),
        ))
        assert running == (0 if number == 2 else 1)
        assert counts["failed"] == (0 if number == 2 else 1)
        assert receipt["observed_exit"] == receipt["controller_exit"] == (0 if number == 2 else 101)
        if number == 5:
            assert "editor_backup_tests.rs:324:24" in raw
            assert 'missing ElementId Name("file-operation-status-detail")' in raw
        history.append({
            "label": label, "running": running, **counts,
            "observed_exit": receipt["observed_exit"],
            "controller_exit": receipt["controller_exit"],
            "terminal": receipt["terminal"],
            "interpretation": reasons[number],
            "used_as_decisive_hover_loss_negative": number == 5,
            "replayed_by_reviewer": False,
            "receipt": row(receipt_path), "log": row(log_path),
        })
    negative = frozen_rows(PARENT / "inputs-tooltip-negative-r5.json")
    current = frozen_rows(V.FREEZE)
    prior = frozen_rows(PARENT / "inputs-freeze-r3.json")
    def deltas(a, b):
        old = {item["path"]: item["sha256"] for item in a["inputs"]}
        new = {item["path"]: item["sha256"] for item in b["inputs"]}
        return [
            {"path": path, "before_sha256": old.get(path), "after_sha256": new.get(path)}
            for path in sorted(old.keys() | new.keys()) if old.get(path) != new.get(path)
        ]
    negative_to_r4 = deltas(negative, current)
    r3_to_r4 = deltas(prior, current)
    assert [item["path"] for item in negative_to_r4] == ["crates/keelshell-app/src/files/view.rs"]
    assert [item["path"] for item in r3_to_r4] == [
        "crates/keelshell-app/src/files/editor_backup_tests.rs",
        "crates/keelshell-app/src/files/view.rs",
    ]
    V.save("negative-history.json", {
        "source": "Read-only independent verification of parent's preserved logs/receipts; no negative test replay.",
        "runs": history,
        "negative_r5_freeze": row(PARENT / "inputs-tooltip-negative-r5.json"),
        "negative_r5_aggregate": negative["aggregate_sha256"],
        "negative_r5_binary_metadata": row(PARENT / "tooltip-negative-binary-r5.json"),
        "negative_r5_to_r4": negative_to_r4,
        "negative_r5_test_source_identical_to_r4": True,
        "r3_to_r4": r3_to_r4,
    })
    original_hashes = json.loads((BASE / "r3-originals-before.json").read_text())
    assert verify_r4.r3_hashes() == original_hashes
    V.save("r3-originals-after.json", original_hashes)
    final = V.snapshot("review-r4-final")
    assert final["binaries"] == initial["binaries"]
    assert (BASE / "app-list.log").read_bytes() == (PARENT / "app-inventory-r4.log").read_bytes()
    commands = {
        name: json.loads((BASE / f"{name}.json").read_text())
        for name in ["app-list", "app-editor"]
    }
    receipt = {
        "schema_version": 1, "review": "Independent r4 follow-up of r3 P2-UI-001",
        "completed_utc": datetime.now(timezone.utc).isoformat(),
        "verdict": "APPROVE",
        "finding_counts": {"P0": 0, "P1": 0, "P2": 0, "P3": 0},
        "resolved_findings": [{
            "id": "P2-UI-001", "previous_status": "OPEN_IN_R3",
            "current_status": "CLOSED_IN_R4_SCOPED_GPUI_VERIFICATION",
            "source": str(ROOT / "crates/keelshell-app/src/files/view.rs"),
            "fix_lines": [917, 918, 919, 923, 942],
            "new_regression": required[-1],
            "regression_file": str(ROOT / "crates/keelshell-app/src/files/editor_backup_tests.rs"),
            "regression_line": 275,
            "decisive_negative": "tooltip-negative-r5; running 1 / failed 1 / exit 101; pointer-entry-following find at historical line 324",
            "negative_log_verified_not_replayed": True,
            "independent_r4_regression_result": "ok",
        }],
        "binding": {
            "head": V.EXPECTED_HEAD, "working_diff_included": True,
            "freeze": row(V.FREEZE), "count": 727, "aggregate_sha256": V.EXPECTED_AGGREGATE,
            "prebuilt_metadata": row(V.METADATA),
            "independent_compilation": False, "parent_prebuilt": True,
            "binaries": final["binaries"],
            "before_after_snapshot_count": 4,
            "all_engineering_inputs_and_all_three_binary_hashes_unchanged": True,
            "final_snapshot": str(BASE / "review-r4-final.snapshot.json"),
            "independent_list_equals_parent_r4_list": True,
            "r3_to_r4_changed_inputs": r3_to_r4,
            "documentation_changed_during_test": True,
            "document_drift": document_drift,
            "document_changes_are_outside_engineering_freeze": True,
        },
        "commands": commands,
        "execution": {
            "full_inventory": 1374, **execution, "new_tests_count": 5,
            "owned_commands": 2, "test_commands": 1,
            "session_test_commands": 0, "openssh_test_commands": 0,
        },
        "interaction_evidence": {
            "long_message_lines": 82,
            "trigger": "Actual bounds bounded by theme chrome status_bar_height; max_h + truncate + line_clamp(1)",
            "pointer": "Popup center proved outside trigger; real GPUI pointer dispatch enters popup and it remains visible after 100ms",
            "overflow": "Real production child bounds exceed viewport by more than 400px",
            "wheel": "-200px moves child origin by >100px; -20000px reaches tail within 1px; +20000px returns to start within 1px",
            "live_language": "Complete English end label then Chinese end label on the open popup",
            "network": "No new SFTP request and zero atomic writes",
            "existing_matrix": "Existing regression retains three families x light/dark x Chinese/English label, visibility and bounds checks",
            "long_scroll_test_is_full_theme_matrix": False,
            "native_desktop_acceptance": False,
            "test_dispatch_implementation": row(Path("/Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837/gpui-kit-0.10.0/src/test.rs")),
            "test_dispatch_lines": [289, 295, 305, 384, 387],
        },
        "negative_history": str(BASE / "negative-history.json"),
        "execution_diagnostics": {
            "outer_verify_script_exit": 1,
            "cause": "Additional documentation-equality assertion, after successful test command and successful engineering/binary snapshots",
            "test_observed_exit": 0, "owned_controller_exit": 0,
            "recovery": "Parsed original logs/receipts; no test replay",
            "preserved_diagnostic": str(BASE / "controller-postrun-diagnostic.json"),
        },
        "prior_review": {
            "report": row(R3 / "report.md"), "receipt": row(R3 / "receipt.json"),
            "verdict_still": "REQUEST_CHANGES", "all_r3_evidence_files_unchanged": True,
            "hashes_before": str(BASE / "r3-originals-before.json"),
            "hashes_after": str(BASE / "r3-originals-after.json"),
        },
        "unchanged_not_repeated": json.loads((BASE / "unchanged-session-openssh.json").read_text()),
        "limits": {
            "cargo_commands": 0, "fmt_commands": 0, "intentional_target_writes": 0,
            "source_or_repository_document_edits": 0,
            "git_commits_pushes_cleanups": 0,
            "outputs_only": str(BASE),
            "not_verified": [
                "Independent compilation/source-to-binary reconstruction",
                "Full gate or current exact-source three-platform CI",
                "Native macOS/Windows/Linux visual, physical-pointer or assistive-technology acceptance",
                "Normal release build/package/install/signing/notarization",
                "Session or real OpenSSH replay, intentionally excluded because hashes and related inputs are unchanged",
                "Endorsement of all concurrently updated documentation",
            ],
        },
    }
    report = [
        "**APPROVE — r4 限定功能补验。P0=0、P1=0、P2=0、P3=0；r3 P2-UI-001 在本次 GPUI 补验范围内关闭。**",
        "",
        "r3 的 REQUEST_CHANGES 原报告、receipt、日志及原件未覆盖；本次为追加签署。"
        "独立 app 宽 editor 用例 88/0/0，新增五项逐名存在并实际 ok。"
        "实际 wait 已完成，可释放本审使用的预编译 app test binary，父级可继续完整 gate。",
        "",
        f"绑定 `{V.EXPECTED_HEAD}` + working diff；`{V.FREEZE}`，727 输入，"
        f"aggregate `{V.EXPECTED_AGGREGATE}`。使用父级 prebuilt，未独立编译。"
        f"app SHA-256 `{next(item['actual_sha256'] for item in final['binaries'] if item['target'] == 'keelshell-app')}`。"
        "每次命令前后重算全部工程输入及 app/session/OpenSSH 三个 binary SHA；四份边界快照和最终快照全部相符。",
        "",
        "| 命令 | 独立库存 | passed / failed / ignored | filtered out | owned 秒 |",
        "| --- | ---: | --- | ---: | ---: |",
        f"| app `--list` | 1374 | 不执行测试 | — | {commands['app-list']['seconds']:.6f} |",
        f"| app `editor --test-threads=2` | 88 个名称与库存过滤集合精确相等 | 88 / 0 / 0 | 1286 | {commands['app-editor']['seconds']:.6f} |",
        "",
        f"libtest 报告 {execution['seconds_reported_by_harness']} 秒。两次 owned 命令均 observed_exit=controller_exit=0；"
        "direct_reaped=true、active_processes=0、pipes_drained=true、errors=[]，无超时/中断。"
        "独立全名库存日志还与父级 r4 库存逐字节相等。",
        "",
        "**P2 关闭证据。**",
        "",
        f"{link('crates/keelshell-app/src/files/view.rs', 917)} "
        "使用当前 chrome token 的 max_h、truncate 和 line_clamp(1)，保留完整 AX label，避免长状态撑高 trigger。"
        f"{link('crates/keelshell-app/src/files/view.rs', 923)} 改为 hoverable_tooltip；"
        "详情维持 480px 宽、220px 高和滚动，其实际内容 child 有独立观测节点。",
        "",
        f"新回归 {link('crates/keelshell-app/src/files/editor_backup_tests.rs', 275)} "
        "生成 80 行诊断加首尾，测量实际 trigger 高度/窗口边界，测量真实 child 比详情高出超过 400px；"
        "先证明详情中心位于 trigger 之外，再经 GPUI 鼠标事件把指针移入详情，等待 100ms 后确认仍可见。"
        "滚轮 -200px 后 child origin 确认移动超过 100px；继续 -20000px 后 child 尾部在视口尾端 1px 内；"
        "切换中文后检查当前完整消息尾部，+20000px 后实际 child 回到开头 1px 内。"
        "SFTP 请求数不增加，原子写数为零。依赖 TestWindowExt 的 hover/scroll 实际 dispatch pointer/ScrollEvent，"
        "断言使用布局观测而非直接改滚动偏移或合成“已到尾部”状态。",
        "",
        "原四项回归也全部通过，包括失败保留、CLOSE 阶段/较新 UTF-16 草稿、取消、发布后失败分类，"
        "以及既有三主题 × 明暗 × 双语共 12 组合的完整标签、tooltip 可见/边界和零网络请求。"
        "新增长消息滚动例是独立的一个交互例，不把它扩大成全部 12 组合的长滚动验收。",
        "",
        "**负例历史保持各自含义。**",
        "",
        "| 父级原件 | running / failed；exit | 本审核对的意义 |",
        "| --- | --- | --- |",
        "| tooltip-negative-r1 | 1 / 1；101 | 初始长 trigger/布局诊断，尚未建立移入阶段；不作为决定性悬停负例 |",
        "| tooltip-negative-r2 | 0 / 0；0 | 错取旧 binary、零用例；不能当作通过或负例复现 |",
        "| tooltip-negative-r3 | 1 / 1；101 | 初始布局诊断；回溯是首次详情 find，历史源码行 301 |",
        "| tooltip-negative-r4 | 1 / 1；101 | line-clamp/truncate 仍触发历史行 293 的 <=24px 高度断言，仍需 max_h |",
        "| tooltip-negative-r5 | 1 / 1；101 | 完成真实溢出与移入后，详情消失，回溯在历史行 324 的 find；本次关闭对应的决定性负例 |",
        "",
        "上述日志 SHA 均与各自 owned receipt 重算相符；本审只读核对，没有重放父级 Cargo 负例。"
        f"r5 负例冻结 aggregate `{negative['aggregate_sha256']}`；"
        "与正例 r4 比较只有 view.rs 的工程摘要改变，新交互测试源文件摘要完全相等。"
        "完整来源、计数、阶段和摘要见 negative-history.json；各旧失败和 r2 零用例事实均保留。",
        "",
        "**收尾诊断与原件。**",
        "",
        "verify_r4.py 在测试实际成功并完成工程/binary after 快照后，额外的文档一致性断言返回 1："
        "父级在测试期间更新了 ADR 0153、当前测试记录和 HALLMARK_NATIVE。"
        "这三项 docs 不在父级 727 工程输入冻结集合内，工程 aggregate 和三个 binary SHA 全部未变。"
        "已单独保存 controller-postrun-diagnostic.json，明确外层收尾脚本 exit 1 与实际测试/owned exit 0；"
        "本 finalizer 重新核对并解析原始成功日志及回执，没有重放用例，也不改写旧诊断。",
        "",
        "```text",
        *[" ".join(command["command"]) for command in commands.values()],
        "```",
        "",
        "```text",
        *[f"{item['name']} ... {item['result']}" for item in execution["new_tests"]],
        "```",
        "",
        f"结构化原件：[receipt.json]({BASE / 'receipt.json'})；"
        f"完整逐名结果：[execution-summary.json]({BASE / 'execution-summary.json'})；"
        f"负例分类：[negative-history.json]({BASE / 'negative-history.json'})。"
        "同目录保留两组原始 owned 回执/日志、前后与最终快照、五个新名源码对应表，以及 r3 原件前后摘要。",
        "",
        "session 和 OpenSSH 的源码输入及 binary SHA 与 r3 相等，本次各运行 0 次；不把 r3 成绩写成 r4 重跑。"
        "本审没有 Cargo/fmt、target 写入、源码/项目文档修改、提交推送或清理；输出和 TMPDIR 都在本 followup-r4 目录。"
        "签署仅覆盖本批源码修复及预编译 GPUI 功能复核。完整门禁、精确三平台 CI、"
        "真实原生桌面/物理鼠标/辅助技术，以及父级正常 release build 与包结构均分别验收。",
        "",
    ]
    with (BASE / "report.md").open("x") as output:
        output.write("\n".join(report))
    receipt["report"] = row(BASE / "report.md")
    receipt["evidence_files"] = [
        row(path) for path in sorted(BASE.iterdir())
        if path.is_file() and path.name != "receipt.json"
    ]
    V.save("receipt.json", receipt)
    print(json.dumps({
        "verdict": "APPROVE", "r3_p2": "closed within scoped r4 GPUI verification",
        "passed": 88, "failed": 0, "ignored": 0, "new_tests_passed": 5,
        "report": row(BASE / "report.md"), "receipt": row(BASE / "receipt.json"),
        "r3_artifacts_unchanged": True, "prebuilt_binary_released": True,
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
