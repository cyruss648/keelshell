**APPROVE — r4 限定功能补验。P0=0、P1=0、P2=0、P3=0；r3 P2-UI-001 在本次 GPUI 补验范围内关闭。**

r3 的 REQUEST_CHANGES 原报告、receipt、日志及原件未覆盖；本次为追加签署。独立 app 宽 editor 用例 88/0/0，新增五项逐名存在并实际 ok。实际 wait 已完成，可释放本审使用的预编译 app test binary，父级可继续完整 gate。

绑定 `7058925330b96161a25142fb5bee94fa24aa5117` + working diff；`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-backup-verification-20261117/inputs-freeze-r4.json`，727 输入，aggregate `78d8a0c0000ce0afb661d8af0c6712a266cd44fa168b801d37c1672c39ddc4c2`。使用父级 prebuilt，未独立编译。app SHA-256 `8356537b85bec4c1091c710404c361f894e12d045f1b28ff79e1030bb156a2df`。每次命令前后重算全部工程输入及 app/session/OpenSSH 三个 binary SHA；四份边界快照和最终快照全部相符。

| 命令 | 独立库存 | passed / failed / ignored | filtered out | owned 秒 |
| --- | ---: | --- | ---: | ---: |
| app `--list` | 1374 | 不执行测试 | — | 0.088716 |
| app `editor --test-threads=2` | 88 个名称与库存过滤集合精确相等 | 88 / 0 / 0 | 1286 | 80.554407 |

libtest 报告 80.47 秒。两次 owned 命令均 observed_exit=controller_exit=0；direct_reaped=true、active_processes=0、pipes_drained=true、errors=[]，无超时/中断。独立全名库存日志还与父级 r4 库存逐字节相等。

**P2 关闭证据。**

[crates/keelshell-app/src/files/view.rs:917](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/view.rs:917) 使用当前 chrome token 的 max_h、truncate 和 line_clamp(1)，保留完整 AX label，避免长状态撑高 trigger。[crates/keelshell-app/src/files/view.rs:923](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/view.rs:923) 改为 hoverable_tooltip；详情维持 480px 宽、220px 高和滚动，其实际内容 child 有独立观测节点。

新回归 [crates/keelshell-app/src/files/editor_backup_tests.rs:275](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/editor_backup_tests.rs:275) 生成 80 行诊断加首尾，测量实际 trigger 高度/窗口边界，测量真实 child 比详情高出超过 400px；先证明详情中心位于 trigger 之外，再经 GPUI 鼠标事件把指针移入详情，等待 100ms 后确认仍可见。滚轮 -200px 后 child origin 确认移动超过 100px；继续 -20000px 后 child 尾部在视口尾端 1px 内；切换中文后检查当前完整消息尾部，+20000px 后实际 child 回到开头 1px 内。SFTP 请求数不增加，原子写数为零。依赖 TestWindowExt 的 hover/scroll 实际 dispatch pointer/ScrollEvent，断言使用布局观测而非直接改滚动偏移或合成“已到尾部”状态。

原四项回归也全部通过，包括失败保留、CLOSE 阶段/较新 UTF-16 草稿、取消、发布后失败分类，以及既有三主题 × 明暗 × 双语共 12 组合的完整标签、tooltip 可见/边界和零网络请求。新增长消息滚动例是独立的一个交互例，不把它扩大成全部 12 组合的长滚动验收。

**负例历史保持各自含义。**

| 父级原件 | running / failed；exit | 本审核对的意义 |
| --- | --- | --- |
| tooltip-negative-r1 | 1 / 1；101 | 初始长 trigger/布局诊断，尚未建立移入阶段；不作为决定性悬停负例 |
| tooltip-negative-r2 | 0 / 0；0 | 错取旧 binary、零用例；不能当作通过或负例复现 |
| tooltip-negative-r3 | 1 / 1；101 | 初始布局诊断；回溯是首次详情 find，历史源码行 301 |
| tooltip-negative-r4 | 1 / 1；101 | line-clamp/truncate 仍触发历史行 293 的 <=24px 高度断言，仍需 max_h |
| tooltip-negative-r5 | 1 / 1；101 | 完成真实溢出与移入后，详情消失，回溯在历史行 324 的 find；本次关闭对应的决定性负例 |

上述日志 SHA 均与各自 owned receipt 重算相符；本审只读核对，没有重放父级 Cargo 负例。r5 负例冻结 aggregate `dd892487f222d0ca200e10ca73b3c5d1ede88dd6b69a28cc5e04e97c8614021e`；与正例 r4 比较只有 view.rs 的工程摘要改变，新交互测试源文件摘要完全相等。完整来源、计数、阶段和摘要见 negative-history.json；各旧失败和 r2 零用例事实均保留。

**收尾诊断与原件。**

verify_r4.py 在测试实际成功并完成工程/binary after 快照后，额外的文档一致性断言返回 1：父级在测试期间更新了 ADR 0153、当前测试记录和 HALLMARK_NATIVE。这三项 docs 不在父级 727 工程输入冻结集合内，工程 aggregate 和三个 binary SHA 全部未变。已单独保存 controller-postrun-diagnostic.json，明确外层收尾脚本 exit 1 与实际测试/owned exit 0；本 finalizer 重新核对并解析原始成功日志及回执，没有重放用例，也不改写旧诊断。

```text
/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/recovery-batch-integration-20261115/target/debug/build/keelshell-app/5af0070f054a4f84/out/keelshell_app-5af0070f054a4f84 --list
/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/recovery-batch-integration-20261115/target/debug/build/keelshell-app/5af0070f054a4f84/out/keelshell_app-5af0070f054a4f84 editor --test-threads=2
```

```text
files::transfer_tests::editor_backup_tests::editor_backup_failed_readback_preserves_target_draft_and_bilingual_status ... ok
files::transfer_tests::editor_backup_tests::editor_backup_readback_close_precedes_publication_and_keeps_newer_utf16_draft ... ok
files::transfer_tests::editor_backup_tests::editor_backup_cancelled_readback_does_not_start_target_replacement ... ok
files::transfer_tests::editor_backup_tests::editor_backup_verified_but_target_readback_failed_keeps_publication_unknown_message ... ok
files::transfer_tests::editor_backup_tests::editor_status_detail_long_message_accepts_hover_and_wheel ... ok
```

结构化原件：[receipt.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-backup-verification-20261117/function-review/followup-r4/receipt.json)；完整逐名结果：[execution-summary.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-backup-verification-20261117/function-review/followup-r4/execution-summary.json)；负例分类：[negative-history.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-backup-verification-20261117/function-review/followup-r4/negative-history.json)。同目录保留两组原始 owned 回执/日志、前后与最终快照、五个新名源码对应表，以及 r3 原件前后摘要。

session 和 OpenSSH 的源码输入及 binary SHA 与 r3 相等，本次各运行 0 次；不把 r3 成绩写成 r4 重跑。本审没有 Cargo/fmt、target 写入、源码/项目文档修改、提交推送或清理；输出和 TMPDIR 都在本 followup-r4 目录。签署仅覆盖本批源码修复及预编译 GPUI 功能复核。完整门禁、精确三平台 CI、真实原生桌面/物理鼠标/辅助技术，以及父级正常 release build 与包结构均分别验收。
