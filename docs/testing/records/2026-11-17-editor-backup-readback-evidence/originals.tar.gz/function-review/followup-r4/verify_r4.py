"""Independent r4 app verification; preserve all prior r3 evidence."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import subprocess
import sys

BASE = Path(__file__).resolve().parent
R3 = BASE.parent
PARENT = R3.parent
ROOT = PARENT.parents[1]
sys.path.insert(0, str(R3))
import verify_prebuilt as verifier

verifier.BASE = BASE
verifier.PARENT = PARENT
verifier.FREEZE = PARENT / "inputs-freeze-r4.json"
verifier.METADATA = PARENT / "test-binaries-r4.json"
verifier.EXPECTED_AGGREGATE = "78d8a0c0000ce0afb661d8af0c6712a266cd44fa168b801d37c1672c39ddc4c2"


def r3_hashes():
    receipt = json.loads((R3 / "receipt.json").read_text())
    paths = [Path(row["path"]) for row in receipt["evidence_files"]]
    paths.append(R3 / "receipt.json")
    return {str(path): verifier.sha(path) for path in paths}


def main():
    verifier.save("r3-originals-before.json", r3_hashes())
    r3_receipt = json.loads((R3 / "receipt.json").read_text())
    metadata = json.loads(verifier.METADATA.read_text())
    unchanged = {}
    for target in ["keelshell_session", "openssh_interop"]:
        original = next(row for row in r3_receipt["binding"]["binaries"] if row["target"] == target)
        current = next(row for row in metadata["binaries"] if row["target"] == target)
        assert original["actual_sha256"] == current["sha256"] == verifier.sha(current["path"])
        unchanged[target] = {
            "sha256": current["sha256"], "path": current["path"],
            "matches_r3_binary": True, "executed_by_r4_reviewer": False,
        }
    verifier.save("unchanged-session-openssh.json", unchanged)
    source = ROOT / "crates/keelshell-app/src/files/editor_backup_tests.rs"
    new_tests = [
        "files::transfer_tests::editor_backup_tests::" + name
        for name in re.findall(r"^async fn (editor_\w+)\(", source.read_text(), re.M)
    ]
    assert len(new_tests) == len(set(new_tests)) == 5
    verifier.save("required-new-tests.json", {
        "source": str(source), "source_sha256": verifier.sha(source), "names": new_tests,
    })
    original_wrapper = PARENT / "run_command.py"
    wrapper = original_wrapper.read_text().replace(
        "ROOT = Path(__file__).resolve().parents[2]", f"ROOT = Path({str(ROOT)!r})",
    ).replace(
        '    CARGO_TERM_COLOR="never",',
        '    CARGO_TERM_COLOR="never",\n'
        '    PYTHONDONTWRITEBYTECODE="1",\n'
        '    TMPDIR=str(base / "tmp"),',
    )
    copied = BASE / "run_command.py"
    with copied.open("x") as output:
        output.write(wrapper)
    (BASE / "tmp").mkdir()
    verifier.save("wrapper-provenance.json", {
        "source": str(original_wrapper), "source_sha256": verifier.sha(original_wrapper),
        "copy": str(copied), "copy_sha256": verifier.sha(copied),
        "root_fixed_to": str(ROOT), "bytecode_disabled": True,
        "temporary_directory": str(BASE / "tmp"),
        "reused_snapshot_parser": str(R3 / "verify_prebuilt.py"),
        "reused_snapshot_parser_sha256": verifier.sha(R3 / "verify_prebuilt.py"),
    })
    app = next(row for row in metadata["binaries"] if row["target"] == "keelshell-app")
    initial_docs = None
    inventory = None
    result = {}
    for label, arguments, mode, seconds in [
        ("app-list", ["--list"], "list", 90),
        ("app-editor", ["editor", "--test-threads=2"], "run", 240),
    ]:
        before = verifier.snapshot(f"{label}-before")
        initial_docs = initial_docs or before["document_sha256"]
        assert before["document_sha256"] == initial_docs
        completed = subprocess.run(
            [sys.executable, "-B", str(copied), label, str(seconds), app["path"], *arguments],
            cwd=ROOT, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"),
        )
        after = verifier.snapshot(f"{label}-after")
        assert after["document_sha256"] == initial_docs
        assert completed.returncode == 0
        if mode == "list":
            inventory = verifier.parse(label, mode, new_tests)
            assert inventory["test_count"] == 1374
            assert len([name for name in inventory["names"] if "editor" in name]) == 88
            result["inventory"] = inventory
        else:
            result["execution"] = verifier.parse(label, mode, {
                "inventory": inventory["names"], "new_tests": new_tests,
            })
            assert result["execution"]["passed"] == 88
            assert result["execution"]["ignored"] == 0
        verifier.save(f"{label}-parsed.json", result["inventory" if mode == "list" else "execution"])
    final_r3 = r3_hashes()
    assert final_r3 == json.loads((BASE / "r3-originals-before.json").read_text())
    verifier.save("r3-originals-after.json", final_r3)
    result.update(
        completed_utc=datetime.now(timezone.utc).isoformat(),
        r3_original_artifacts_unchanged=True,
        session_and_openssh_not_repeated=True,
    )
    verifier.save("execution-summary.json", result)
    print(json.dumps({
        "inventory": result["inventory"]["test_count"],
        "passed": result["execution"]["passed"],
        "failed": result["execution"]["failed"],
        "ignored": result["execution"]["ignored"],
        "new_tests_passed": result["execution"]["new_tests"],
        "r3_original_artifacts_unchanged": True,
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
