**REQUEST_CHANGES — r3 编辑器备份功能复核。P0=0、P1=0、P2=1、P3=0。**

独立执行的 153 项用例全部通过，新增 session 30 项与 app 4 项逐名存在且实际为 ok。这些结果保留为 r3 的有效专项证据；状态详情无法移入滚动的 P2 仍开放，不能声明本批交互验收完成或缺陷已关闭。

复核目录：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`。HEAD `7058925330b96161a25142fb5bee94fa24aa5117` 加 working diff；冻结为 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-backup-verification-20261117/inputs-freeze-r3.json`，727 项，aggregate `bbe90528db8e2d0fced73848f585d149a425253bc6595a9939397643e7b9e970`。已先读 AGENTS、HANDOFF、ADR 0153、REMOTE_TEXT_FORMAT、当前测试记录及 SHARED_TARGET 合同。

本次使用父级预编译二进制，未独立编译。session/app/OpenSSH 的独立 `--list` 为 343/1373/18，与父级 r3 库存日志逐字节相等。本次按宽过滤器 `editor --test-threads=2` 运行，不只运行新增模块；源码新增名字与独立库存、逐名执行结果三方相等。下表的 filtered out 是当前二进制中本次未执行的其他用例。

| 二进制 | 独立全名库存 | 实际 passed / failed / ignored | filtered out | 新增实际 ok | libtest 秒 / owned 秒 |
| --- | ---: | --- | ---: | ---: | --- |
| session | 343 | 66 / 0 / 0 | 277 | 30 | 2.66 / 2.727926 |
| app | 1373 | 87 / 0 / 0 | 1286 | 4 | 81.6 / 81.686153 |
| openssh_interop | 18 | 本审未执行 | — | 新正例仅核库存与源码 | — |

五次命令均由项目 owned/bounded `run_command.py` 的自有副本执行；副本 ROOT 已固定为项目根，关闭 Python bytecode 写入并将 TMPDIR 指向本审目录。每次命令前后均重新计算全部 727 输入及三个二进制 SHA；10 份命令边界 snapshot 和额外收口 snapshot 均保持 r3。所有回执均 observed_exit=controller_exit=0，direct_reaped=true、active_processes=0、pipes_drained=true、errors=[]，无超时或中断。

| 二进制 | SHA-256（执行前后及收口均一致） |
| --- | --- |
| keelshell_session | `7b0fab3721858e7a8fbc40a22712b878bd7e6e5d023bc9a70f268413e6184f89` |
| keelshell-app | `fb618df37eb5ca5fd0cf00828abcc455b6af0e7aad773cace3e2510ef80363dc` |
| openssh_interop | `caad4e77eb92aa6642f558afeb3978cf2647c969ef56484b654be4a0813b2d2f` |

**开放发现 P2-UI-001：长状态详情无法移入滚动读取。**

位置：[crates/keelshell-app/src/files/view.rs:921](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/view.rs:921)，详情在 932–935 行使用 `max_w(480)`、`max_h(220)` 与 `overflow_y_scroll()`，但触发器使用普通 `.tooltip(...)`。当长消息换行后超过 220px，指针离开状态行移入详情会失去普通 tooltip 的悬停保持，滚动尾部不可达；完整 AX label 并不能提供指针交互保证。该问题由父级转述 Arendt 发现，本审已独立核对当前 view 与精确本地依赖的实现机制，没有声称完成独立原生复现。

依赖证据：`/Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837/gpui-pre-0.3.12/src/elements/div.rs:722–751`，普通 tooltip 设置 `hoverable: false`（732），`hoverable_tooltip` 设置 true（751）；3914–3918 的鼠标检查仅为可悬停 tooltip 保留内部悬停。现有回归 [crates/keelshell-app/src/files/editor_backup_tests.rs:109](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/editor_backup_tests.rs:109) 只 hover 状态行，随后检查可见性、标签、边界及主题语言更新；没有移入详情或滚轮读取断言。因此即使现有四项通过，也不能关闭该 P2。父级计划的修复和新回归须绑定新 r4 freeze/binary 后独立补验；本报告不预签 r4。

**字节、阶段、取消和 UNKNOWN 的可支持范围。**

生产链 [crates/keelshell-session/src/sftp.rs:734](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:734) 先完成备份 helper，再进入原目标替换。742–800 在原备份 deadline 与同一 reservation 内读回，检查读前后授权、全部原始字节、精确大小和 `0100600`；使用既有 checked reader，目标替换前仍保留完整旧 snapshot 再核验。[crates/keelshell-session/src/sftp/inspection.rs:58](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/inspection.rs:58) 的父链、leaf、opened FSTAT、完整 EOF、结束 FSTAT/leaf 和 CLOSE ACK 检查支持这一有界观察合同；[crates/keelshell-session/src/sftp/mutation.rs:94](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/mutation.rs:94) 保留 pending、失效 reservation、未知 cleanup 的 MutationUncertain 优先级。

30 项新 session 回归通过真实隔离 loopback TCP/SSH/SFTP 调用 production public API。事件日志断言备份发布、完整 READ/EOF、只读 CLOSE 早于 TargetStaged/TargetPublished；空源、100000 字节 Unicode、多块尾字节损坏、UTF-16 LE BOM 和五种显式旧编码均有覆盖。ACK 后损坏、截断、缺失、链接、目录、缺失类型/大小、错误权限、超大、读错误、早 EOF、三个元数据变化阶段和 CLOSE 失败均阻止目标 staging，保留可检查备份且不自动重试/删除。撤权、2 秒读回 deadline、共享 reservation busy、未知发布的隔离和同长竞争者目标再核验分别通过。

app 保存链 [crates/keelshell-app/src/files/worker.rs:863](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/worker.rs:863) 只把 stop 已置位的 Closed 映射成取消，不把 MutationUncertain 映成普通读回错误。备份读回失败与目标发布后读回失败分别显示；目标完整字节相等才采用新基线。四项新 GPUI 回归验证已 ACK 备份失败时目标/草稿/旧基线保留、只读 CLOSE 前不发目标写入、较新 UTF-16 草稿不被迟到结果覆盖、实际取消按钮，以及目标已发布后的错误不误报为未发起。取消与断连仍不构成回滚。

三主题双语回归 [crates/keelshell-app/src/files/editor_backup_tests.rs:115](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/editor_backup_tests.rs:115) 遍历当前 registry 的 Frost/Graphite/Lavender × Light/Dark × 中文/英文共 12 组合，核对完整当前 AX 名称、已打开 tooltip 的实时文本、可见边界与 SFTP 请求数不增加。可以支持这些组件和状态语义断言；不能支持尚缺的移入/滚轮读取、原生像素观感或完整辅助技术验收。

**新 OpenSSH 正例：源码与库存通过审查，真实服务执行由父级持有。**

[crates/keelshell-session/tests/support/openssh_editor_backup.rs:7](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/support/openssh_editor_backup.rs:7) 存在于本审独立 18 名库存中。它在 75 秒预算内，用 pinned loopback Fixture 的 production API 处理 Unicode UTF-8/CRLF（含引号与 shell 元字符文件名）、BOM UTF-16 BE、显式 GBK 和空 UTF-8；每个场景连续保存两次，第二次保存空正文，共八个唯一备份。逐次核对全部旧备份字节、精确大小/0600、完整新目标字节/原 mode，全部保存后再次读取八份备份，检查 SSH 仍可用，并在成功路径清理测试资源。该正例支持正常标准服务端兼容性；OpenSSH 上的故障注入、协议时序和所有编码组合不由这个正例单独建立。

父级在本审进行中报告：当前 OpenSSH 18 项通过、依赖官方 37 包/113 声明通过、上一 bd198a8 三平台 CI success。本审未独立采集或重签这些原件；上一提交 CI 也不代签当前 working diff。真实 OpenSSH 本审执行数为 0。

**新增 30 + 4 逐名结果（本审实际执行）。**

```text
sftp::editor_backup_tests::editor_backup_empty_source_requires_checked_eof_and_close_before_target ... ok
sftp::editor_backup_tests::editor_backup_unicode_multichunk_readback_precedes_target_staging ... ok
sftp::editor_backup_tests::editor_backup_utf16_keeps_bom_and_raw_bytes_in_checked_readback ... ok
sftp::editor_backup_tests::editor_backup_explicit_legacy_formats_read_back_original_raw_bytes ... ok
sftp::editor_backup_tests::editor_backup_explicit_legacy_corruption_blocks_target ... ok
sftp::editor_backup_tests::editor_backup_acknowledged_tail_corruption_blocks_target ... ok
sftp::editor_backup_tests::editor_backup_acknowledged_truncation_blocks_target ... ok
sftp::editor_backup_tests::editor_backup_acknowledged_missing_leaf_blocks_target ... ok
sftp::editor_backup_tests::editor_backup_acknowledged_symlink_blocks_target ... ok
sftp::editor_backup_tests::editor_backup_acknowledged_directory_blocks_target ... ok
sftp::editor_backup_tests::editor_backup_acknowledged_missing_type_blocks_target ... ok
sftp::editor_backup_tests::editor_backup_acknowledged_missing_size_blocks_target ... ok
sftp::editor_backup_tests::editor_backup_acknowledged_wrong_mode_blocks_target ... ok
sftp::editor_backup_tests::editor_backup_acknowledged_oversized_content_blocks_target ... ok
sftp::editor_backup_tests::editor_backup_acknowledged_read_failure_blocks_target ... ok
sftp::editor_backup_tests::editor_backup_acknowledged_early_eof_blocks_target ... ok
sftp::editor_backup_tests::editor_backup_opened_handle_metadata_change_blocks_target ... ok
sftp::editor_backup_tests::editor_backup_metadata_change_during_read_blocks_target ... ok
sftp::editor_backup_tests::editor_backup_leaf_metadata_change_after_handle_check_blocks_target ... ok
sftp::editor_backup_tests::editor_backup_readonly_close_failure_blocks_target ... ok
sftp::editor_backup_tests::editor_backup_readback_keeps_shared_mutation_reservation ... ok
sftp::editor_backup_tests::editor_backup_revoked_after_publication_keeps_closed_error_and_original ... ok
sftp::editor_backup_tests::editor_backup_revoked_during_read_blocks_target ... ok
sftp::editor_backup_tests::editor_backup_revoked_during_readonly_close_blocks_target ... ok
sftp::editor_backup_tests::editor_backup_revoked_during_failed_read_keeps_closed_error ... ok
sftp::editor_backup_tests::editor_backup_revoked_on_final_close_ack_blocks_target ... ok
sftp::editor_backup_tests::editor_backup_readback_timeout_is_unverified_without_target_quarantine ... ok
sftp::editor_backup_tests::editor_backup_revoked_during_readback_timeout_keeps_closed_error ... ok
sftp::editor_backup_tests::editor_backup_unknown_publication_keeps_shared_quarantine_and_original ... ok
sftp::editor_backup_tests::editor_backup_readback_does_not_skip_original_target_revalidation ... ok
files::transfer_tests::editor_backup_tests::editor_backup_failed_readback_preserves_target_draft_and_bilingual_status ... ok
files::transfer_tests::editor_backup_tests::editor_backup_readback_close_precedes_publication_and_keeps_newer_utf16_draft ... ok
files::transfer_tests::editor_backup_tests::editor_backup_cancelled_readback_does_not_start_target_replacement ... ok
files::transfer_tests::editor_backup_tests::editor_backup_verified_but_target_readback_failed_keeps_publication_unknown_message ... ok
```

**原始命令与回执。**

```text
/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/recovery-batch-integration-20261115/target/debug/build/keelshell-session/88ec7f3d009e04d0/out/keelshell_session-88ec7f3d009e04d0 --list
/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/recovery-batch-integration-20261115/target/debug/build/keelshell-app/5af0070f054a4f84/out/keelshell_app-5af0070f054a4f84 --list
/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/recovery-batch-integration-20261115/target/debug/build/keelshell-session/57ae8ea542a5f582/out/openssh_interop-57ae8ea542a5f582 --list
/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/recovery-batch-integration-20261115/target/debug/build/keelshell-session/88ec7f3d009e04d0/out/keelshell_session-88ec7f3d009e04d0 editor --test-threads=2
/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/recovery-batch-integration-20261115/target/debug/build/keelshell-app/5af0070f054a4f84/out/keelshell_app-5af0070f054a4f84 editor --test-threads=2
```

逐名全量结果和全名库存见 [execution-summary.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-backup-verification-20261117/function-review/execution-summary.json)；结构化签署见 [receipt.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-backup-verification-20261117/function-review/receipt.json)。各命令的原始 `*.log`、owned `*.json`、执行前后 `*.snapshot.json` 和 `*-parsed.json` 均在同目录。receipt 记录全部命令参数、真实退出、准确结果、全部 34 新名以及证据 SHA；不覆盖父级 r3 原件。

本审没有运行 Cargo/fmt/Clippy、写 target、修改源码/项目文档、Git 提交/推送或清理。所有自有脚本、临时数据、报告和回执只在指定 function-review 目录。独立编译、集中完整门禁、当前源码精确三平台 CI、r4 修复、真实原生三平台桌面、IME/辅助技术、正常包安装签名发行均未验。完整读回是一轮有界字节/元数据观察，不是 CAS、持续身份锁、崩溃耐久性、自动恢复、事务回滚或 owner/ACL/特殊 mode 保留承诺。

合并建议：等待 P2-UI-001 修复与 r4 交互补验；保留本次 r3 的冻结、库存、153 项成功和开放缺陷，后续使用新编号追加，不能把本轮结果改写成 r4 已通过。
