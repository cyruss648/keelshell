"""Read-only r3 verification; all reviewer output stays beside this controller."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parent
PARENT = BASE.parent
EXPECTED_HEAD = "7058925330b96161a25142fb5bee94fa24aa5117"
EXPECTED_AGGREGATE = "bbe90528db8e2d0fced73848f585d149a425253bc6595a9939397643e7b9e970"
METADATA = PARENT / "test-binaries-r3.json"
FREEZE = PARENT / "inputs-freeze-r3.json"
DOCS = [
    "AGENTS.md", "docs/HANDOFF.md", "docs/testing/SHARED_TARGET.md",
    "docs/adr/0153-editor-backup-readback.md",
    "docs/product/REMOTE_TEXT_FORMAT.md",
    "docs/testing/records/2026-11-17-editor-backup-readback.md",
    "docs/design/HALLMARK_NATIVE.md", "docs/product/CAPABILITIES.md",
]


def sha(path):
    return hashlib.file_digest(Path(path).open("rb"), "sha256").hexdigest()


def save(name, value):
    with (BASE / name).open("x") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write("\n")


def git(*args):
    return subprocess.check_output(
        ["git", "-c", "core.fsmonitor=false", *args],
        cwd=ROOT, timeout=30,
        env=dict(os.environ, GIT_OPTIONAL_LOCKS="0"),
    )


def snapshot(label):
    frozen = json.loads(FREEZE.read_text())
    names = sorted({
        name.decode() for name in git(
            "ls-files", "--cached", "--others", "--exclude-standard", "-z"
        ).split(b"\0")
        if name and not name.startswith((b"docs/", b".hallmark/"))
    })
    rows = [
        {"path": name, "bytes": (ROOT / name).stat().st_size, "sha256": sha(ROOT / name)}
        for name in names
    ]
    aggregate = hashlib.sha256("".join(
        f"{row['path']}\0{row['sha256']}\n" for row in rows
    ).encode()).hexdigest()
    metadata = json.loads(METADATA.read_text())
    binaries = []
    for target in ["keelshell_session", "keelshell-app", "openssh_interop"]:
        row = next(item for item in metadata["binaries"] if item["target"] == target)
        binaries.append({
            "target": target, "path": row["path"],
            "bytes": Path(row["path"]).stat().st_size,
            "expected_sha256": row["sha256"],
            "actual_sha256": sha(row["path"]),
            "parent_fresh_flag": row.get("fresh"),
        })
    result = {
        "captured_utc": datetime.now(timezone.utc).isoformat(),
        "head": git("rev-parse", "HEAD").decode().strip(),
        "count": len(rows), "aggregate_sha256": aggregate,
        "freeze_file_sha256": sha(FREEZE), "metadata_file_sha256": sha(METADATA),
        "inputs_match_freeze": rows == frozen["inputs"],
        "frozen_count": frozen["count"],
        "frozen_aggregate_sha256": frozen["aggregate_sha256"],
        "binaries": binaries,
        "document_sha256": {name: sha(ROOT / name) for name in DOCS},
    }
    save(f"{label}.snapshot.json", result)
    assert result["head"] == EXPECTED_HEAD
    assert result["count"] == frozen["count"] == 727
    assert aggregate == frozen["aggregate_sha256"] == EXPECTED_AGGREGATE
    assert result["inputs_match_freeze"]
    assert all(row["actual_sha256"] == row["expected_sha256"] for row in binaries)
    return result


def parse(label, mode, required):
    raw = (BASE / f"{label}.log").read_text()
    receipt = json.loads((BASE / f"{label}.json").read_text())
    assert receipt["observed_exit"] == receipt["controller_exit"] == 0
    assert not receipt["timed_out"] and not receipt["interrupted"] and not receipt["errors"]
    assert receipt["terminal"] == {
        "direct_reaped": True, "active_processes": 0,
        "pipes_drained": True, "errors": [],
    }
    if mode == "list":
        names = re.findall(r"^(\S+): test$", raw, re.M)
        assert len(names) == len(set(names))
        assert all(name in names for name in required)
        return {"test_count": len(names), "names": names, "required_new_tests": required}
    pairs = re.findall(r"^test (\S+) \.\.\. (ok|FAILED|ignored)(?:,.*)?$", raw, re.M)
    names = [name for name, _ in pairs]
    summary = re.search(
        r"test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; "
        r"(\d+) measured; (\d+) filtered out; finished in ([0-9.]+)s", raw,
    )
    assert summary and summary[1] == "ok"
    counts = dict(zip(
        ["passed", "failed", "ignored", "measured", "filtered_out"],
        map(int, summary.group(2, 3, 4, 5, 6)),
    ))
    assert len(names) == len(set(names)) == sum(counts[k] for k in ["passed", "failed", "ignored"])
    assert counts["failed"] == 0
    assert set(names) == set(expected for expected in required["inventory"] if "editor" in expected)
    outcomes = dict(pairs)
    assert all(outcomes.get(name) == "ok" for name in required["new_tests"])
    return {
        **counts, "seconds_reported_by_harness": float(summary[7]),
        "actual_test_count": len(names), "results": pairs,
        "filter_equals_inventory": True,
        "new_tests": [{"name": name, "result": outcomes[name]} for name in required["new_tests"]],
    }


def main():
    original = PARENT / "run_command.py"
    copied = BASE / "run_command.py"
    wrapper = original.read_text().replace(
        "ROOT = Path(__file__).resolve().parents[2]",
        f"ROOT = Path({str(ROOT)!r})",
    ).replace(
        '    CARGO_TERM_COLOR="never",',
        '    CARGO_TERM_COLOR="never",\n'
        '    PYTHONDONTWRITEBYTECODE="1",\n'
        '    TMPDIR=str(base / "tmp"),',
    )
    with copied.open("x") as stream:
        stream.write(wrapper)
    (BASE / "tmp").mkdir()
    save("wrapper-provenance.json", {
        "source": str(original), "source_sha256": sha(original),
        "copy": str(copied), "copy_sha256": sha(copied),
        "root_fixed_to": str(ROOT),
        "changes": ["Fixed ROOT", "Disabled bytecode writes", "Redirected temporary files into reviewer directory"],
    })
    handoff = json.loads((PARENT / "author-handoff.json").read_text())
    required = {
        "keelshell_session": handoff["new_tests"],
        "keelshell-app": [
            "files::transfer_tests::editor_backup_tests::" + name for name in [
                "editor_backup_failed_readback_preserves_target_draft_and_bilingual_status",
                "editor_backup_readback_close_precedes_publication_and_keeps_newer_utf16_draft",
                "editor_backup_cancelled_readback_does_not_start_target_replacement",
                "editor_backup_verified_but_target_readback_failed_keeps_publication_unknown_message",
            ]
        ],
        "openssh_interop": [
            "editor_backup::openssh_editor_verified_backups_preserve_unicode_legacy_empty_and_repeated_bytes",
        ],
    }
    metadata = json.loads(METADATA.read_text())
    outcomes = {}
    for target, label in [
        ("keelshell_session", "session"), ("keelshell-app", "app"), ("openssh_interop", "openssh"),
    ]:
        binary = next(row["path"] for row in metadata["binaries"] if row["target"] == target)
        name = f"{label}-list"
        before = snapshot(f"{name}-before")
        execution = subprocess.run([
            sys.executable, "-B", str(copied), name, "90", binary, "--list",
        ], cwd=ROOT, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))
        after = snapshot(f"{name}-after")
        assert before["document_sha256"] == after["document_sha256"]
        assert execution.returncode == 0
        outcomes[label] = {"inventory": parse(name, "list", required[target])}
        save(f"{name}-parsed.json", outcomes[label]["inventory"])
    for target, label in [("keelshell_session", "session"), ("keelshell-app", "app")]:
        binary = next(row["path"] for row in metadata["binaries"] if row["target"] == target)
        name = f"{label}-editor"
        before = snapshot(f"{name}-before")
        execution = subprocess.run([
            sys.executable, "-B", str(copied), name, "240", binary,
            "editor", "--test-threads=2",
        ], cwd=ROOT, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"))
        after = snapshot(f"{name}-after")
        assert before["document_sha256"] == after["document_sha256"]
        assert execution.returncode == 0
        outcomes[label]["execution"] = parse(name, "run", {
            "inventory": outcomes[label]["inventory"]["names"], "new_tests": required[target],
        })
        save(f"{name}-parsed.json", outcomes[label]["execution"])
    save("execution-summary.json", outcomes)
    print(json.dumps({
        label: {
            "inventory": row["inventory"]["test_count"],
            "execution": {k: v for k, v in row.get("execution", {}).items() if k not in ["results", "new_tests"]},
        } for label, row in outcomes.items()
    }, indent=2))


if __name__ == "__main__":
    main()
