"""Check actual binary inventory, then run the new SFTP and GPUI regressions."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
metadata = json.loads((BASE / "test-binaries-r3.json").read_text())
handoff = json.loads((BASE / "author-handoff.json").read_text())
outcomes = {}
for target, label, prefix, required in [
    ("keelshell_session", "session", "sftp::editor_backup_tests::", handoff["new_tests"]),
    ("keelshell-app", "app", "files::transfer_tests::editor_backup_tests::", [
        "files::transfer_tests::editor_backup_tests::" + name for name in [
            "editor_backup_failed_readback_preserves_target_draft_and_bilingual_status",
            "editor_backup_readback_close_precedes_publication_and_keeps_newer_utf16_draft",
            "editor_backup_cancelled_readback_does_not_start_target_replacement",
            "editor_backup_verified_but_target_readback_failed_keeps_publication_unknown_message",
        ]
    ]),
    ("openssh_interop", "openssh", "editor_backup::", [
        "editor_backup::openssh_editor_verified_backups_preserve_unicode_legacy_empty_and_repeated_bytes",
    ]),
]:
    binary = next(row for row in metadata["binaries"] if row["target"] == target)
    assert hashlib.sha256(Path(binary["path"]).read_bytes()).hexdigest() == binary["sha256"]
    subprocess.run([
        sys.executable, "-B", str(BASE / "run_command.py"),
        f"{label}-inventory-r3", "90", binary["path"], "--list",
    ], cwd=ROOT, check=True)
    raw = (BASE / f"{label}-inventory-r3.log").read_text()
    inventory = re.findall(r"^(\S+): test$", raw, re.M)
    assert len(inventory) == len(set(inventory)) and inventory
    assert sorted(name for name in inventory if name.startswith(prefix)) == sorted(required)
    row = {"inventory": len(inventory), "required_new_tests": required}
    if label != "openssh":
        result = subprocess.run([
            sys.executable, "-B", str(BASE / "run_command.py"),
            f"{label}-backup-r3", "150", binary["path"], prefix, "--test-threads=2",
        ], cwd=ROOT)
        raw = (BASE / f"{label}-backup-r3.log").read_text()
        matches = re.findall(r"^test (\S+) \.\.\. (ok|FAILED|ignored)(?:,.*)?$", raw, re.M)
        row.update(
            observed_exit=result.returncode, executed=matches,
            passed=sum(value == "ok" for _, value in matches),
            failed=sum(value == "FAILED" for _, value in matches),
            ignored=sum(value == "ignored" for _, value in matches),
        )
        row["names_equal"] = sorted(name for name, _ in matches) == sorted(required)
        outcomes[label] = row
        (BASE / "focused-summary-r3.json").write_text(json.dumps(outcomes, indent=2) + "\n")
        assert row["names_equal"]
        assert result.returncode == 0 and row["passed"] == len(required)
    else:
        outcomes[label] = row
with (BASE / "focused-summary-r3.json").open("w") as output:
    json.dump(outcomes, output, indent=2)
    output.write("\n")
print(json.dumps({key: {name: row[name] for name in ("inventory", "passed") if name in row}
                  for key, row in outcomes.items()}))
