"""Seal this batch's bounded receipts without binaries or duplicate prior CI."""
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
DEST = ROOT / "docs/testing/records/2026-11-17-editor-backup-readback-evidence"
archive_path = DEST / "originals.tar.gz"
manifest_path = DEST / "manifest.json"
assert not archive_path.exists() and not manifest_path.exists()
assert (BASE / "full-gate-r1.json").is_file()
entries = []
payloads = {}
for path in sorted(BASE.rglob("*")):
    relative = path.relative_to(BASE)
    if not path.is_file():
        continue
    if any(part in ("package-precommit-r1", "previous-ci", "__pycache__")
           for part in relative.parts):
        continue
    if relative.parts[0].startswith("ci-previous-"):
        continue
    assert path.suffix in (".json", ".log", ".py", ".md"), relative
    raw = path.read_bytes()
    name = relative.as_posix()
    payloads[name] = raw
    entries.append({
        "path": name, "bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
    })

packed = io.BytesIO()
with gzip.GzipFile(fileobj=packed, mode="wb", filename="", mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as archive:
        for row in entries:
            member = tarfile.TarInfo(row["path"])
            member.size = row["bytes"]
            member.mode = 0o644
            archive.addfile(member, io.BytesIO(payloads[row["path"]]))
for row in entries:
    assert (BASE / row["path"]).read_bytes() == payloads[row["path"]], row["path"]
raw = packed.getvalue()
freeze = json.loads(payloads["inputs-freeze-r4.json"])
manifest = {
    "sealed_utc": datetime.now(timezone.utc).isoformat(),
    "source_base": freeze["head"],
    "source_includes_working_diff": True,
    "engineering_inputs": freeze["count"],
    "aggregate_sha256": freeze["aggregate_sha256"],
    "count": len(entries),
    "archive_bytes": len(raw),
    "archive_sha256": hashlib.sha256(raw).hexdigest(),
    "excluded": [
        "Normal application package and all binaries",
        "Previous CI originals sealed separately in darwin-tcp-listeners evidence",
        "Python bytecode cache",
    ],
    "entries": entries,
}
with archive_path.open("xb") as output:
    output.write(raw)
with manifest_path.open("x") as output:
    json.dump(manifest, output, indent=2)
    output.write("\n")
print(json.dumps({key: value for key, value in manifest.items() if key != "entries"}))
