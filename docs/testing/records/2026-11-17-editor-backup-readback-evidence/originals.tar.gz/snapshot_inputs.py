"""Capture or compare this checkout's engineering inputs without using Cargo."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent


def snapshot():
    names = sorted({
        name.decode() for name in subprocess.check_output(
            ["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"],
            cwd=ROOT, timeout=30,
        ).split(b"\0")
        if name and not name.startswith((b"docs/", b".hallmark/"))
    })
    rows = []
    for name in names:
        raw = (ROOT / name).read_bytes()
        rows.append({
            "path": name, "bytes": len(raw),
            "sha256": hashlib.sha256(raw).hexdigest(),
        })
    aggregate = hashlib.sha256("".join(
        f"{row['path']}\0{row['sha256']}\n" for row in rows
    ).encode()).hexdigest()
    return {
        "captured_utc": datetime.now(timezone.utc).isoformat(),
        "head": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True, timeout=10,
        ).strip(),
        "count": len(rows), "aggregate_sha256": aggregate, "inputs": rows,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("label")
    parser.add_argument("--compare")
    args = parser.parse_args()
    result = snapshot()
    if args.compare:
        prior = json.loads((BASE / args.compare).read_text())
        result["compared_with"] = args.compare
        result["unchanged"] = result["inputs"] == prior["inputs"]
    with (BASE / args.label).open("x") as output:
        json.dump(result, output, indent=2)
        output.write("\n")
    print(json.dumps({key: value for key, value in result.items() if key != "inputs"}))
    if args.compare:
        assert result["unchanged"], "engineering inputs changed"


if __name__ == "__main__":
    main()
