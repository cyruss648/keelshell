"""Capture r4 follow-up evidence; write only this directory's followup-receipt.json."""

from datetime import datetime, timezone
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tarfile
import tomllib


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
BASE = HERE.parent
EXPECTED_HEAD = "7058925330b96161a25142fb5bee94fa24aa5117"
EXPECTED_AGGREGATE = "78d8a0c0000ce0afb661d8af0c6712a266cd44fa168b801d37c1672c39ddc4c2"
ORIGINAL_DIGESTS = {
    "report.md": "b79ea4769505a08e49bb05e1d94870e59527e3f893d6f03ec6a6039543c34356",
    "receipt.json": "74ce143f490a0b9f8f116ec2fa7c286dd4a82253210d796f7bf0a6ad64b8ffca",
}
VIEW = "crates/keelshell-app/src/files/view.rs"
APP_TESTS = "crates/keelshell-app/src/files/editor_backup_tests.rs"
SESSION_TESTS = "crates/keelshell-session/src/sftp/editor_backup_tests.rs"
PRODUCTION = [
    "crates/keelshell-session/src/error.rs",
    "crates/keelshell-session/src/sftp.rs",
    "crates/keelshell-app/src/files.rs",
    VIEW,
    "crates/keelshell-app/src/files/worker.rs",
]
ENV = {**os.environ, "GIT_OPTIONAL_LOCKS": "0", "PYTHONDONTWRITEBYTECODE": "1"}
COMMANDS = []


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(path):
    path = Path(path)
    data = path.read_bytes()
    return {
        "path": str(path), "bytes": len(data), "sha256": sha(data), "observed_utc": utc()
    }


def read_command(argv):
    started = utc()
    result = subprocess.run(
        argv, cwd=ROOT, env=ENV, capture_output=True, check=False, timeout=30
    )
    COMMANDS.append({
        "argv": argv, "cwd": str(ROOT), "started_utc": started, "finished_utc": utc(),
        "exit_code": result.returncode, "stdout_bytes": len(result.stdout),
        "stdout_sha256": sha(result.stdout), "stderr": result.stderr.decode(errors="replace"),
    })
    if result.returncode:
        raise RuntimeError(f"Read-only command failed: {argv}: {result.returncode}")
    return result.stdout


def snapshot(expected):
    head = read_command(["git", "--no-optional-locks", "rev-parse", "HEAD"]).decode().strip()
    raw_names = read_command([
        "git", "--no-optional-locks", "ls-files",
        "--cached", "--others", "--exclude-standard", "-z",
    ])
    names = sorted({
        name.decode() for name in raw_names.split(b"\0")
        if name and not name.startswith((b"docs/", b".hallmark/"))
    })
    rows = []
    for name in names:
        data = (ROOT / name).read_bytes()
        rows.append({"path": name, "bytes": len(data), "sha256": sha(data)})
    aggregate = sha("".join(f"{r['path']}\0{r['sha256']}\n" for r in rows).encode())
    frozen = {r["path"]: r for r in expected["inputs"]}
    live = {r["path"]: r for r in rows}
    result = {
        "observed_utc": utc(), "head": head, "count": len(rows),
        "aggregate_sha256": aggregate, "rows_equal": rows == expected["inputs"],
        "changed": sorted(p for p in frozen.keys() & live.keys() if frozen[p] != live[p]),
        "added": sorted(live.keys() - frozen.keys()),
        "removed": sorted(frozen.keys() - live.keys()),
    }
    assert head == expected["head"] == EXPECTED_HEAD
    assert len(rows) == expected["count"] == 727
    assert aggregate == expected["aggregate_sha256"] == EXPECTED_AGGREGATE
    assert result["rows_equal"]
    return result


def changes(old, new):
    old_rows = {r["path"]: r for r in old["inputs"]}
    new_rows = {r["path"]: r for r in new["inputs"]}
    return [
        {"path": name, "old": old_rows.get(name), "new": new_rows.get(name)}
        for name in sorted(old_rows.keys() | new_rows.keys())
        if old_rows.get(name) != new_rows.get(name)
    ]


def parent_run(name):
    receipt_path, log_path = BASE / f"{name}.json", BASE / f"{name}.log"
    receipt = json.loads(receipt_path.read_bytes())
    data = log_path.read_bytes()
    matches = len(data) == receipt["log_bytes"] and sha(data) == receipt["log_sha256"]
    assert matches, name
    text = data.decode()
    executed = re.findall(r"^test (\S+) \.\.\. (\S+)$", text, re.M)
    return {
        "receipt_file": digest(receipt_path), "log_file": digest(log_path),
        "log_matches_parent_receipt": matches,
        "parent_command_not_executed_by_reviewer": receipt["command"],
        "observed_exit": receipt["observed_exit"], "controller_exit": receipt["controller_exit"],
        "timed_out": receipt["timed_out"], "interrupted": receipt["interrupted"],
        "terminal": receipt["terminal"], "errors": receipt.get("errors", []),
        "executed_names_and_status": executed,
        "result_lines": re.findall(r"^test result:.*$", text, re.M),
        "running_lines": re.findall(r"^running \d+ tests?$", text, re.M),
        "independent_execution": False,
    }


def main():
    started = utc()
    original = {name: digest(HERE / name) for name in ORIGINAL_DIGESTS}
    assert all(original[name]["sha256"] == value for name, value in ORIGINAL_DIGESTS.items())
    paths = {
        "r3": BASE / "inputs-freeze-r3.json",
        "r4": BASE / "inputs-freeze-r4.json",
        "tooltip_negative_r5": BASE / "inputs-tooltip-negative-r5.json",
    }
    freezes = {key: json.loads(path.read_bytes()) for key, path in paths.items()}
    initial = snapshot(freezes["r4"])
    r3_to_r4 = changes(freezes["r3"], freezes["r4"])
    assert {r["path"] for r in r3_to_r4} == {VIEW, APP_TESTS}
    negative_to_r4 = changes(freezes["tooltip_negative_r5"], freezes["r4"])
    assert [r["path"] for r in negative_to_r4] == [VIEW]
    r3_rows = {r["path"]: r for r in freezes["r3"]["inputs"]}

    view = (ROOT / VIEW).read_text()
    old_view = (
        view.replace("                            .max_h(px(crate::design::chrome(cx).status_bar_height))\n", "")
        .replace("                            .truncate()\n                            .line_clamp(1)", "                            .text_ellipsis()")
        .replace(".hoverable_tooltip({", ".tooltip({")
        .replace(
            '                                            .child(\n'
            '                                                div()\n'
            '                                                    .id("file-operation-status-detail-content")\n'
            '                                                    .child(text)\n'
            '                                                    .test_support(),\n'
            '                                            )',
            "                                            .child(text)",
        )
    )
    tests = (ROOT / APP_TESTS).read_text()
    old_tests = tests.split(
        "\n#[gpui_kit::test]\nasync fn editor_status_detail_long_message_accepts_hover_and_wheel", 1
    )[0].rstrip() + "\n"
    old_tests = old_tests.replace(
        "    AppContext, ScrollDelta, TestAppContext, point, px,",
        "    AppContext, TestAppContext,",
    )
    reconstructions = []
    for path, old, current in [(VIEW, old_view, view), (APP_TESTS, old_tests, tests)]:
        assert sha(old.encode()) == r3_rows[path]["sha256"]
        assert len(old.encode()) == r3_rows[path]["bytes"]
        reconstructions.append({
            "path": str(ROOT / path), "old_bytes": len(old.encode()),
            "old_sha256": sha(old.encode()), "matches_r3": True,
            "method": "In-memory reverse of the reviewed changes; never wrote historical source",
            "unified_diff": "".join(difflib.unified_diff(
                old.splitlines(keepends=True), current.splitlines(keepends=True),
                fromfile=f"{ROOT / path} [r3 reconstructed; SHA verified]",
                tofile=f"{ROOT / path} [r4]",
            )),
        })
    negative_view = view.replace(".hoverable_tooltip({", ".tooltip({").encode()
    assert view.count(".hoverable_tooltip({") == 1
    assert sha(negative_view) == negative_to_r4[0]["old"]["sha256"]
    assert len(negative_view) == negative_to_r4[0]["old"]["bytes"]

    lock = tomllib.loads((ROOT / "Cargo.lock").read_text())
    registry = Path("/Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837")
    cache = registry.parent.parent / "cache" / registry.name
    locked_sources = []
    for name, version, rel in [
        ("gpui-pre", "0.3.12", "src/elements/div.rs"),
        ("gpui-pre", "0.3.12", "src/styled.rs"),
        ("gpui-kit", "0.10.0", "src/test.rs"),
        ("gpui-kit", "0.10.0", "src/lib.rs"),
        ("gpui-component", "0.10.0", "src/tooltip.rs"),
    ]:
        package = next(p for p in lock["package"] if p["name"] == name and p["version"] == version)
        archive = cache / f"{name}-{version}.crate"
        source = registry / f"{name}-{version}" / rel
        with tarfile.open(archive, "r:gz") as tar:
            member = tar.extractfile(f"{name}-{version}/{rel}").read()
        archive_info, source_info = digest(archive), digest(source)
        assert archive_info["sha256"] == package["checksum"]
        assert member == source.read_bytes()
        locked_sources.append({
            "name": name, "version": version, "source": source_info, "archive": archive_info,
            "lock_checksum": package["checksum"],
            "archive_matches_lock": True, "source_matches_archive_member": True,
        })

    parent = {name: parent_run(name) for name in [
        "tooltip-negative-r5", "app-backup-r4", "session-backup-r4",
        "build-test-inventory-r4", "app-inventory-r4",
        "session-inventory-r4", "openssh-inventory-r4",
    ]}
    inventories = {}
    for name, expected_count in [("app", 1374), ("session", 343), ("openssh", 18)]:
        inventory_names = re.findall(
            r"^(\S+): test$", (BASE / f"{name}-inventory-r4.log").read_text(), re.M
        )
        assert len(inventory_names) == expected_count
        inventories[name] = {"parent_recorded_count": len(inventory_names), "independently_executed": False}
        if name in ("app", "session"):
            source_path = APP_TESTS if name == "app" else SESSION_TESTS
            declared = re.findall(r"^async fn (\w+)\(", (ROOT / source_path).read_text(), re.M)
            # Session helpers are also async; only annotated tests count.
            declared = re.findall(
                r"#\[(?:tokio|gpui_kit)::test\](?:\s*#\[[^\n]*\])*\s*async fn (\w+)",
                (ROOT / source_path).read_text(),
            )
            prefix = "files::transfer_tests::editor_backup_tests::" if name == "app" else "sftp::editor_backup_tests::"
            required = [prefix + n for n in declared]
            executed = parent[f"{name}-backup-r4"]["executed_names_and_status"]
            assert set(required) <= set(inventory_names)
            assert set(required) == {n for n, status in executed}
            assert all(status == "ok" for n, status in executed)
            assert len(required) == (5 if name == "app" else 30)
            inventories[name].update({
                "source": digest(ROOT / source_path), "source_declared_count": len(required),
                "required_names": required, "names_equal_parent_log": True,
                "parent_passed": len(executed), "parent_failed": 0, "parent_ignored": 0,
            })

    assert parent["tooltip-negative-r5"]["executed_names_and_status"] == [
        ("files::transfer_tests::editor_backup_tests::editor_status_detail_long_message_accepts_hover_and_wheel", "FAILED")
    ]
    negative_text = (BASE / "tooltip-negative-r5.log").read_text()
    assert "./src/files/editor_backup_tests.rs:324:24" in negative_text
    binary_manifest = json.loads((BASE / "test-binaries-r4.json").read_bytes())
    app_binary = next(b for b in binary_manifest["binaries"] if b["target"] == "keelshell-app")
    build_records = []
    for line in (BASE / "build-test-inventory-r4.log").read_text().splitlines():
        try:
            record = json.loads(line)
        except json.JSONDecodeError:
            continue
        if (record.get("reason") == "compiler-artifact"
                and record.get("target", {}).get("name") == "keelshell-app"
                and record.get("profile", {}).get("test")):
            build_records.append(record)
    assert len(build_records) == 1
    assert app_binary["path"] == build_records[0]["executable"]
    assert app_binary["path"] == parent["app-backup-r4"]["parent_command_not_executed_by_reviewer"][0]
    assert binary_manifest["freeze"] == "inputs-freeze-r4.json"
    working_diff = read_command([
        "git", "--no-optional-locks", "diff", "--no-ext-diff", "--no-textconv",
        "--binary", "HEAD", "--", *PRODUCTION,
    ])
    documents = [
        ROOT / "AGENTS.md", ROOT / "docs/HANDOFF.md",
        ROOT / "docs/adr/0153-editor-backup-readback.md",
        ROOT / "docs/product/REMOTE_TEXT_FORMAT.md",
        Path("/Users/hdh/.codex/RTK.md"),
        Path("/Users/hdh/.agents/skills/rust-best-practices/SKILL.md"),
    ]
    final = snapshot(freezes["r4"])
    original_after = {name: digest(HERE / name) for name in ORIGINAL_DIGESTS}
    assert all(original_after[name]["sha256"] == value for name, value in ORIGINAL_DIGESTS.items())
    receipt = {
        "schema": "keelshell-independent-read-only-source-followup-v1",
        "started_utc": started, "finished_utc": utc(),
        "workspace": str(ROOT), "reviewer": "Codex independent non-author source reviewer",
        "recommendation": "APPROVE", "recommendation_scope": "r4 static delta follow-up for P2-01",
        "open_severity_counts": {"P0": 0, "P1": 0, "P2": 0, "P3": 0},
        "new_findings": [],
        "closed_findings": [{
            "id": "P2-01", "status": "CLOSED_AT_SOURCE_LEVEL",
            "path": str(ROOT / VIEW), "line_start": 917, "line_end": 923,
            "detail_content_id_line": 942,
            "test_path": str(ROOT / APP_TESTS), "test_line_start": 274, "test_line_end": 368,
            "basis": "Fixed source plus checksum-bound GPUI implementation; examined parent execution logs separately",
        }],
        "original_review": {
            "recommendation_preserved": "REQUEST_CHANGES",
            "before": original, "after": original_after, "both_original_files_unchanged": True,
        },
        "fixed_inputs": {
            "head": EXPECTED_HEAD, "freeze": digest(paths["r4"]),
            "expected_count": 727, "expected_aggregate_sha256": EXPECTED_AGGREGATE,
            "before_capture": initial, "after_capture": final,
            "enumeration": "Git cached/others/exclude-standard; sorted unique; excludes docs/ and .hallmark/",
            "aggregate_algorithm": "sha256(UTF8(concat(sorted path + NUL + file_sha256 + LF)))",
            "all_rows_equal_before_and_after": True,
            "production_inputs": [digest(ROOT / name) for name in PRODUCTION],
            "head_production_working_diff": {"bytes": len(working_diff), "sha256": sha(working_diff)},
        },
        "r3_to_r4": {
            "r3_freeze": digest(paths["r3"]), "changed_count": 2,
            "unchanged_count": 725, "changes": r3_to_r4, "in_memory_diffs": reconstructions,
            "session_worker_and_manifests_unchanged": True,
        },
        "controlled_negative": {
            "freeze": digest(paths["tooltip_negative_r5"]),
            "aggregate_sha256": freezes["tooltip_negative_r5"]["aggregate_sha256"],
            "changes_to_r4": negative_to_r4,
            "test_input_identical_to_r4": True,
            "only_view_change_is_tooltip_to_hoverable_tooltip": True,
            "negative_view_reconstructed_in_memory_sha256": sha(negative_view),
            "parent_backtrace_location": "./src/files/editor_backup_tests.rs:324:24",
            "initial_overflow_and_pointer_move_precede_failure": True,
            "earlier_precondition_failures_and_zero_test_run_counted_as_reproduction": False,
        },
        "locked_dependency_evidence": locked_sources,
        "documents_observed_separately_not_part_of_r4_freeze": [digest(p) for p in documents],
        "parent_evidence_examined_not_independent_execution": {
            "runs": parent, "inventories": inventories,
            "focused_summary": digest(BASE / "focused-summary-r4.json"),
            "binary_manifest": digest(BASE / "test-binaries-r4.json"),
            "parent_app_binary_record_only": app_binary,
            "app_build_artifact_record": build_records[0],
            "build_manifest_and_run_paths_equal": True,
            "reviewer_read_or_hashed_target_binary": False,
            "native_acceptance_inferred": False,
        },
        "execution": {
            "cargo_invocations": 0, "rustc_invocations": 0, "fmt_invocations": 0,
            "clippy_invocations": 0, "test_executions": 0, "prebuilt_test_executions": 0,
            "independent_passed": None, "independent_failed": None, "independent_ignored": None,
            "ssh_or_openssh_functional_invocations": 0, "gui_actions": 0, "screenshots": 0,
            "native_acceptance": "NOT_PERFORMED",
        },
        "write_boundary": {
            "allowed_directory": str(HERE),
            "new_artifacts": ["followup.md", "followup-receipt.json", "capture_followup.py"],
            "original_report_or_receipt_writes": 0, "source_edits": 0,
            "docs_edits_outside_review_directory": 0, "target_writes": 0,
            "git_metadata_mutations": 0, "commit_push_cleanup": 0, "dependency_downloads": 0,
        },
        "actual_capture_command": f"python3 {HERE / 'capture_followup.py'}",
        "capture_script": digest(Path(__file__)),
        "followup_report": digest(HERE / "followup.md"),
        "actual_read_only_git_subcommand_count_for_this_capture": len(COMMANDS),
        "read_only_subcommands": COMMANDS,
        "exploration": {
            "operations": [
                "Read original report and selectively parse receipt, freeze and parent run JSON files",
                "Python line-numbered reads of view.rs:900-955 and editor_backup_tests.rs:274-369",
                "Python and rg reads of locked GPUI test helper, styled and tooltip implementation",
                "In-memory SHA-256 comparison of r3/r4/negative-r5 inputs; no historical source writes",
                "Read-only local .crate archive member comparison and Cargo.lock checksum binding",
                "Parse and hash parent logs, inventory logs, build JSON and binary manifest; no target access",
            ],
            "exact_exploratory_commands": [
                "rg -n 'fn (hover|scroll)|dispatch_event|fn truncate|fn line_clamp' /Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837/gpui-kit-0.10.0/src/test.rs /Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837/gpui-pre-0.3.12/src/style.rs /Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837/gpui-pre-0.3.12/src/styled.rs",
                "rg -n -C 2 '严格只读|read.only|independent' /Users/hdh/.codex/memories/MEMORY.md",
            ],
            "ledger_scope": "Inline Python exploration commands remain in the tool transcript; this saved capture reproduces the decisive checks and records every subprocess argv and exit",
            "display_diagnostics": "Some broad combined reads were display-truncated; JSON was reparsed and decisive source/log ranges reread narrowly. No truncated display was used as the complete freeze or inventory.",
        },
        "limitations": [
            "No independent compilation, binary inventory execution, functional or native verification",
            "APPROVE applies to the r4 static delta; original r3 REQUEST_CHANGES remains unchanged",
            "Examined parent headless GPUI input/geometry logs do not establish native platform acceptance",
            "Parent binary SHA is a manifest record, not an independently hashed binary",
            "Docs are excluded by the freeze algorithm and remain separately observed mutable inputs",
            "Original transport timing-test and bounded SFTP-observation evidence limits remain unchanged",
            "No conclusion on parent full gates, releases, installation or later revisions",
        ],
    }
    assert len(COMMANDS) == 5
    output = HERE / "followup-receipt.json"
    with output.open("x") as file:
        json.dump(receipt, file, ensure_ascii=False, indent=2)
        file.write("\n")
    print(json.dumps({
        "recommendation": receipt["recommendation"],
        "closed": "P2-01 at source level",
        "head": EXPECTED_HEAD, "count": final["count"],
        "aggregate_sha256": final["aggregate_sha256"],
        "original_report_and_receipt_unchanged": True,
        "parent_app_passed": inventories["app"]["parent_passed"],
        "parent_session_passed": inventories["session"]["parent_passed"],
        "independent_test_executions": 0,
        "read_only_git_commands": len(COMMANDS),
        "output": digest(output),
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
