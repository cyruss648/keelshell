"""Capture fixed source-review evidence; write only this review's receipt.json."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import tomllib


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
EXPECTED_HEAD = "7058925330b96161a25142fb5bee94fa24aa5117"
EXPECTED_AGGREGATE = "bbe90528db8e2d0fced73848f585d149a425253bc6595a9939397643e7b9e970"
ENV = {**os.environ, "GIT_OPTIONAL_LOCKS": "0", "PYTHONDONTWRITEBYTECODE": "1"}
COMMANDS = []


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read_digest(path):
    path = Path(path)
    raw = path.read_bytes()
    return {"path": str(path), "bytes": len(raw), "sha256": sha(raw), "observed_utc": utc()}


def command(argv):
    started = utc()
    result = subprocess.run(
        argv, cwd=ROOT, env=ENV, capture_output=True, check=False, timeout=30
    )
    COMMANDS.append({
        "argv": argv,
        "cwd": str(ROOT),
        "started_utc": started,
        "finished_utc": utc(),
        "exit_code": result.returncode,
        "stdout_bytes": len(result.stdout),
        "stdout_sha256": sha(result.stdout),
        "stderr": result.stderr.decode(errors="replace"),
    })
    if result.returncode:
        raise RuntimeError(f"Read-only command failed: {argv}: {result.returncode}")
    return result.stdout


def main():
    started = utc()
    freezes = {}
    for revision in (1, 2, 3):
        path = HERE.parent / f"inputs-freeze-r{revision}.json"
        raw = path.read_bytes()
        freezes[revision] = json.loads(raw)
        freezes[revision]["freeze_file"] = read_digest(path)

    head = command(["git", "--no-optional-locks", "rev-parse", "HEAD"]).decode().strip()
    names = sorted({
        name.decode()
        for name in command([
            "git", "--no-optional-locks", "ls-files",
            "--cached", "--others", "--exclude-standard", "-z",
        ]).split(b"\0")
        if name and not name.startswith((b"docs/", b".hallmark/"))
    })
    rows = []
    for name in names:
        raw = (ROOT / name).read_bytes()
        rows.append({"path": name, "bytes": len(raw), "sha256": sha(raw)})
    aggregate = sha("".join(
        f"{row['path']}\0{row['sha256']}\n" for row in rows
    ).encode())
    expected = freezes[3]
    actual_by_path = {row["path"]: row for row in rows}
    frozen_by_path = {row["path"]: row for row in expected["inputs"]}
    changed = [
        name for name in sorted(actual_by_path.keys() & frozen_by_path.keys())
        if actual_by_path[name] != frozen_by_path[name]
    ]
    added = sorted(actual_by_path.keys() - frozen_by_path.keys())
    removed = sorted(frozen_by_path.keys() - actual_by_path.keys())
    freeze_ok = (
        head == EXPECTED_HEAD == expected["head"]
        and len(rows) == 727 == expected["count"]
        and aggregate == EXPECTED_AGGREGATE == expected["aggregate_sha256"]
        and rows == expected["inputs"]
    )

    production = [
        "crates/keelshell-session/src/error.rs",
        "crates/keelshell-session/src/sftp.rs",
        "crates/keelshell-app/src/files.rs",
        "crates/keelshell-app/src/files/view.rs",
        "crates/keelshell-app/src/files/worker.rs",
    ]
    supporting = [
        "crates/keelshell-session/src/sftp/inspection.rs",
        "crates/keelshell-session/src/sftp/mutation.rs",
        "crates/keelshell-session/src/sftp/queue.rs",
        "crates/keelshell-session/src/sftp/queue/reservations.rs",
        "crates/keelshell-session/src/sftp/directory.rs",
        "crates/keelshell-session/src/ssh.rs",
        "crates/keelshell-app/src/i18n.rs",
        "crates/keelshell-app/src/files/transfer_tests.rs",
        "crates/keelshell-app/src/files/test_server.rs",
        "crates/keelshell-session/tests/fixtures/sftp.rs",
        "crates/keelshell-session/tests/openssh_interop.rs",
        "scripts/openssh_interop.py",
        "Cargo.toml",
        "Cargo.lock",
    ]
    diff = command([
        "git", "--no-optional-locks", "diff", "--no-ext-diff", "--no-textconv",
        "--binary", "HEAD", "--", *production,
    ])
    status = command([
        "git", "--no-optional-locks", "status", "--porcelain=v1",
        "--untracked-files=all", "-z",
    ]).decode().split("\0")
    documents = [
        "AGENTS.md",
        "docs/HANDOFF.md",
        "docs/adr/0153-editor-backup-readback.md",
        "docs/product/REMOTE_TEXT_FORMAT.md",
        "docs/design/HALLMARK_NATIVE.md",
        "docs/testing/records/2026-11-17-editor-backup-readback.md",
    ]
    test_files = [
        "crates/keelshell-session/src/sftp/editor_backup_tests.rs",
        "crates/keelshell-app/src/files/editor_backup_tests.rs",
        "crates/keelshell-session/tests/support/openssh_editor_backup.rs",
    ]
    inventories = []
    pattern = re.compile(
        r"#\[(?:tokio|gpui_kit)::test\](?:\s*#\[[^\n]*\])*\s*async fn (\w+)"
    )
    for name in test_files:
        content = (ROOT / name).read_text()
        tests = [
            {
                "name": match.group(1),
                "attribute_line": content[:match.start()].count("\n") + 1,
            }
            for match in pattern.finditer(content)
        ]
        inventories.append({
            **read_digest(ROOT / name),
            "source_declared_test_count": len(tests),
            "tests": tests,
            "independently_compiled_inventory": False,
            "independently_executed": 0,
            "ignore_attribute_present": "#[ignore" in content,
        })

    registry = Path("/Users/hdh/.cargo/registry")
    lock = tomllib.loads((ROOT / "Cargo.lock").read_text())
    dependencies = []
    for name, version, relative in [
        ("gpui-pre", "0.3.12", "src/elements/div.rs"),
        ("gpui-component", "0.10.0", "src/tooltip.rs"),
        ("gpui-kit", "0.10.0", "src/lib.rs"),
    ]:
        source = registry / "src/rsproxy.cn-e3de039b2554c837" / f"{name}-{version}" / relative
        locked_checksum = next(
            package["checksum"] for package in lock["package"]
            if package["name"] == name and package["version"] == version
        )
        archive = registry / "cache/rsproxy.cn-e3de039b2554c837" / f"{name}-{version}.crate"
        archive_raw = archive.read_bytes()
        with tarfile.open(archive, "r:gz") as package:
            reader = package.extractfile(f"{name}-{version}/{relative}")
            if reader is None:
                raise RuntimeError(f"Missing archive member: {relative}")
            archive_member = reader.read()
        dependencies.append({
            "name": name,
            "version": version,
            "source": read_digest(source),
            "archive": read_digest(archive),
            "locked_package_checksum": locked_checksum,
            "archive_matches_lock": sha(archive_raw) == locked_checksum,
            "source_matches_original_package": source.read_bytes() == archive_member,
        })

    deltas = []
    for before, after in ((1, 2), (2, 3)):
        old = {row["path"]: row for row in freezes[before]["inputs"]}
        new = {row["path"]: row for row in freezes[after]["inputs"]}
        deltas.append({
            "before": f"r{before}",
            "after": f"r{after}",
            "changed": [
                {"path": name, "before": old[name], "after": new[name]}
                for name in sorted(old.keys() & new.keys()) if old[name] != new[name]
            ],
            "added": sorted(new.keys() - old.keys()),
            "removed": sorted(old.keys() - new.keys()),
        })

    receipt = {
        "schema": "keelshell-independent-read-only-source-review-v1",
        "started_utc": started,
        "finished_utc": utc(),
        "reviewer": "Codex independent non-author source reviewer",
        "workspace": str(ROOT),
        "recommendation": "REQUEST_CHANGES",
        "recommendation_scope": "r3 production source and test-design review only",
        "severity_counts": {"P0": 0, "P1": 0, "P2": 1, "P3": 0},
        "findings": [{
            "id": "P2-01",
            "priority": 2,
            "title": "Non-hoverable status tooltip prevents scrolling overflowing details",
            "path": str(ROOT / "crates/keelshell-app/src/files/view.rs"),
            "line_start": 921,
            "line_end": 921,
            "supporting_lines": [932, 933, 934],
            "basis": "Static source path plus locked dependency implementation; not executed",
            "test_gap": {
                "path": str(ROOT / test_files[1]),
                "line_start": 106,
                "line_end": 150,
                "missing": "Move pointer into overflowing tooltip and scroll actual contents",
            },
        }],
        "fixed_inputs": {
            "head": head,
            "freeze": freezes[3]["freeze_file"],
            "expected_count": expected["count"],
            "actual_count": len(rows),
            "expected_aggregate_sha256": expected["aggregate_sha256"],
            "actual_aggregate_sha256": aggregate,
            "rows_equal": rows == expected["inputs"],
            "matches_requested_revision": freeze_ok,
            "changed": changed,
            "added": added,
            "removed": removed,
            "algorithm": "sha256(UTF8(concat(sorted path + NUL + file_sha256 + LF)))",
            "enumeration_exclusions": ["docs/", ".hallmark/", "Git ignored paths"],
            "production_inputs": [read_digest(ROOT / name) for name in production],
            "supporting_inputs": [read_digest(ROOT / name) for name in supporting],
            "production_tracked_diff_bytes": len(diff),
            "production_tracked_diff_sha256": sha(diff),
            "status_at_capture": [row for row in status if row],
        },
        "freeze_history": [
            {
                "revision": f"r{revision}",
                "freeze": freezes[revision]["freeze_file"],
                "count": freezes[revision]["count"],
                "aggregate_sha256": freezes[revision]["aggregate_sha256"],
            }
            for revision in (1, 2, 3)
        ],
        "freeze_deltas": deltas,
        "documents": {
            "inside_engineering_freeze": False,
            "later_parent_document_edits_not_signed": True,
            "files": [read_digest(ROOT / name) for name in documents],
        },
        "locked_dependency_evidence": dependencies,
        "source_test_inventory": inventories,
        "execution": {
            "status": "NOT_RUN_USER_PROHIBITED",
            "cargo_invocations": 0,
            "rustc_invocations": 0,
            "fmt_invocations": 0,
            "clippy_invocations": 0,
            "test_executions": 0,
            "prebuilt_test_executions": 0,
            "independent_tests_passed": None,
            "independent_tests_failed": None,
            "independent_tests_ignored": None,
            "ssh_or_openssh_functional_invocations": 0,
            "gui_actions": 0,
            "screenshots": 0,
            "native_acceptance": "NOT_PERFORMED",
        },
        "parent_reported_only": {
            "source": "User messages in this review conversation; not independent execution",
            "historical_failures_preserved": [
                "Original compilation borrow error",
                "r1 session30:29 passed / 1 failed (oversized competing-write fault)",
                "app4:2 passed / 2 failed (writable staging prefix and cancellation race)",
                "Online dependency query r1 timeout / r2 registry failures",
            ],
            "latest_reported_r3_session": {"passed": 30, "failed": 0},
            "latest_reported_r3_app": {"passed": 4, "failed": 0},
            "reported_binary_inventories": {"session": 343, "app": 1373, "openssh": 18},
            "pasteur_prebuilt_review": "IN_PROGRESS_AT_LAST_USER_UPDATE",
            "standard_openssh18": "IN_PROGRESS_AT_LAST_USER_UPDATE",
            "native": "LOCKED_SCREEN_REPORTED_BY_PARENT",
        },
        "write_boundary": {
            "allowed_output_directory": str(HERE),
            "created_by_reviewer": ["report.md", "capture_receipt.py", "receipt.json"],
            "production_source_edits": 0,
            "document_edits_outside_review_directory": 0,
            "git_metadata_mutations": 0,
            "target_writes": 0,
            "commits_pushes_cleanup": 0,
            "dependency_downloads": 0,
        },
        "actual_receipt_command": "python3 work/editor-backup-verification-20261117/source-review/capture_receipt.py",
        "capture_script": read_digest(Path(__file__)),
        "report": read_digest(HERE / "report.md"),
        "read_only_subcommands": COMMANDS,
        "exploration_commands": [
            'pwd',
            'rg -n "KeelShell|keelshell|严格只读|shared.target|SHARED_TARGET" /Users/hdh/.codex/memories/MEMORY.md',
            'cat /Users/hdh/.codex/RTK.md',
            'cat AGENTS.md',
            'cat docs/HANDOFF.md',
            'cat docs/adr/0153-editor-backup-readback.md',
            'cat docs/product/REMOTE_TEXT_FORMAT.md',
            'cat docs/testing/records/2026-11-17-editor-backup-readback.md',
            'cat /Users/hdh/.agents/skills/rust-best-practices/SKILL.md',
            'sed -n \'413,464p\' /Users/hdh/.codex/memories/MEMORY.md',
            'GIT_OPTIONAL_LOCKS=0 git --no-optional-locks rev-parse HEAD',
            'GIT_OPTIONAL_LOCKS=0 git --no-optional-locks diff --no-ext-diff --no-textconv --stat',
            'GIT_OPTIONAL_LOCKS=0 git --no-optional-locks status --short --untracked-files=all',
            'GIT_OPTIONAL_LOCKS=0 git --no-optional-locks diff --no-ext-diff --no-textconv --numstat',
            'cat work/editor-backup-verification-20261117/snapshot_inputs.py',
            'nl -ba crates/keelshell-session/src/sftp.rs | sed -n \'470,840p\'',
            'nl -ba crates/keelshell-session/src/sftp.rs | sed -n \'834,1100p\'',
            'nl -ba crates/keelshell-session/src/sftp/editor_backup_tests.rs | sed -n \'1,410p\'',
            'nl -ba crates/keelshell-session/src/sftp/editor_backup_tests.rs | sed -n \'390,835p\'',
            'nl -ba crates/keelshell-session/src/sftp/editor_backup_tests.rs | sed -n \'835,1235p\'',
            'nl -ba crates/keelshell-app/src/files/editor_backup_tests.rs',
            'nl -ba crates/keelshell-session/tests/support/openssh_editor_backup.rs',
            'nl -ba crates/keelshell-session/src/sftp/mutation.rs | sed -n \'1,290p\'',
            'nl -ba crates/keelshell-session/src/sftp/inspection.rs | sed -n \'1,345p\'',
            'nl -ba crates/keelshell-session/src/error.rs | sed -n \'1,150p\'',
            'nl -ba crates/keelshell-app/src/files/view.rs | sed -n \'840,980p\'',
            'nl -ba crates/keelshell-app/src/files/worker.rs | sed -n \'838,915p\'',
            'nl -ba /Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837/gpui-pre-0.3.12/src/elements/div.rs | sed -n \'700,765p;1710,1765p;3910,4105p\'',
            'GIT_OPTIONAL_LOCKS=0 git --no-optional-locks diff --no-ext-diff --no-textconv -- crates/keelshell-app/src/files/worker.rs crates/keelshell-app/src/files/view.rs',
        ],
        "exploration_ledger_scope": "Representative exact shell commands above; other rg/nl/cat reads and inline Python hash scripts are preserved in the tool transcript. Final authoritative reproducible capture uses read_only_subcommands and this script.",
        "exploratory_diagnostics": [
            "Initial ls of source-review: absent; directory created only for own artifacts",
            "zsh unmatched mutation* and test_server* path globs: no operation executed for those rg commands; resolved using discovered exact paths",
            "Initial guessed gpui-pre/gpui-fast 0.10 source paths absent; actual gpui-pre 0.3.12 confirmed from lock",
            "Attempt to read .cargo-checksum.json: absent; replaced by read-only .crate archive checksum and member comparison, all three matched",
            "Oversized display output of freeze and combined skill references was truncated; freeze later parsed in full and relevant reference chapters reread separately",
        ],
        "limitations": [
            "No independent compilation, binary inventory verification, functional execution, headless test execution, native UI or release validation",
            "P2-01 is a source-proven interaction defect, not a separately executed reproduction",
            "Single stalled read timeout test does not independently discriminate a deadline reset after a slow publication",
            "Ordinary SFTP readback is a bounded observation, not remote CAS, continuous identity lock, rollback or crash durability",
            "Current parent document edits and later code revisions are outside this r3 signature",
        ],
    }
    (HERE / "receipt.json").write_text(
        json.dumps(receipt, ensure_ascii=False, indent=2) + "\n"
    )
    print(json.dumps({
        "head": head,
        "count": len(rows),
        "aggregate_sha256": aggregate,
        "matches_r3": freeze_ok,
        "recommendation": receipt["recommendation"],
        "severity_counts": receipt["severity_counts"],
        "source_declared_test_counts": [
            row["source_declared_test_count"] for row in inventories
        ],
        "read_only_subcommands": len(COMMANDS),
        "all_subcommands_exit_zero": all(row["exit_code"] == 0 for row in COMMANDS),
        "all_dependency_archives_match_lock": all(
            row["archive_matches_lock"] and row["source_matches_original_package"]
            for row in dependencies
        ),
        "report_sha256": receipt["report"]["sha256"],
        "receipt": str(HERE / "receipt.json"),
    }, ensure_ascii=False, indent=2))
    if not freeze_ok:
        raise SystemExit("Frozen inputs drifted; receipt records mismatch.")


if __name__ == "__main__":
    main()
