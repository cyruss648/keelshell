# 编辑器备份状态详情：r4 独立只读差分复核

**结论：APPROVE，范围为 r4 静态源码差分。P2-01 在源码层面关闭。当前未关闭发现：P0=0、P1=0、P2=0、P3=0；本轮新增发现各级均为 0。**

本 followup 继续原独立、非作者审查，只复核父级对 P2-01 的修订。原
[report.md](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-backup-verification-20261117/source-review/report.md)
和
[receipt.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-backup-verification-20261117/source-review/receipt.json)
保持原有 **r3 REQUEST_CHANGES**，没有覆盖或回写。二者 SHA-256 分别仍为
`b79ea4769505a08e49bb05e1d94870e59527e3f893d6f03ec6a6039543c34356`、
`74ce143f490a0b9f8f116ec2fa7c286dd4a82253210d796f7bf0a6ad64b8ffca`。

本轮固定输入是 HEAD `7058925330b96161a25142fb5bee94fa24aa5117` 加
[inputs-freeze-r4.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-backup-verification-20261117/inputs-freeze-r4.json)：
**727 输入，aggregate SHA-256
`78d8a0c0000ce0afb661d8af0c6712a266cd44fa168b801d37c1672c39ddc4c2`**。
freeze 文件自身 SHA-256 为
`b94b07a24c0a8e4264b3f295796f10a4c657b359d9675cb323fe048ca96389c6`。
已逐项重算完整路径集合、字节数和内容哈希；落盘回执前后再次核对，均与 r4 相等。
详细观测时间、实际命令、原件保全、依赖及父级日志哈希见
[followup-receipt.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-backup-verification-20261117/source-review/followup-receipt.json)。

**实际差分只有两处输入。** r3→r4 的其余 725 输入相同，包括 session 的 error／sftp／reader／mutation、
app files.rs／worker.rs，以及 Cargo.toml／Cargo.lock。原审 ACK 后读回的 scope、deadline、authority、
UNKNOWN 优先、无自动重放／删除已发布备份、target untouched 分类和 worker 取消精确映射均不受本次差分改变。
原报告对这些路径的审查结论及证据边界继续保留。

| 输入 | r3 SHA-256 | r4 SHA-256 |
| --- | --- | --- |
| [view.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/view.rs) | `f4afbf63c91a7c1f618ac5e20a07d8643cc4efbd55f2f2e89ea66db9a49baead` | `07038945320a1e6cce900815b8634840a22d96e6b3a2ab5786e6d487d9814472` |
| [editor_backup_tests.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/editor_backup_tests.rs) | `b969397800c405383c880bc3b266757f652c2696884d0e64bfe629ad22ae4b08` | `93bb00d54dba9e6f8f545d68524a78e3d9b25ac26febd3c8a8e15728276b275f` |

评审在内存中逆向移除这两份文件的本轮改动，分别得到与 r3 freeze 完全一致的字节数和 SHA-256，
再生成准确的 r3→r4 diff 写入本评审回执；未恢复或写入历史源码。
因此已验证原四个 app 用例主体没有随本轮修订改变，测试文件只扩展 import 并新增第 5 例。

**P2-01 关闭依据。** 原触发是长状态超过 220px 详情视口，指针离开状态行进入详情后，
普通 tooltip 立即隐藏，导致滚动阅读尾部不可达。r4 的对应修订如下。

| 绝对文件及行 | 修订与影响 |
| --- | --- |
| [view.rs:917](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/view.rs:917) | `max_h(chrome.status_bar_height)`、`truncate()`、`line_clamp(1)` 约束紧凑触发行，避免 80 行诊断把触发行撑高、移出可见区域。 |
| [view.rs:923](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/view.rs:923) | 改为 public `hoverable_tooltip`。锁定 GPUI 实现把 hoverable 置 true，并将 popup 自身 bounds 纳入悬停判断，直接修复原先的 Hide 路径。 |
| [view.rs:928](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/view.rs:928) | 每次内容 render 通过 weak owner 读取当前 status／locale；保留当前语义主题色、完整 AX label，没有固定捕获首次翻译或引入实体强引用环。 |
| [view.rs:932](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/view.rs:932) | 详情保留 480px 最大宽度、220px 最大高度、换行、纵向滚动及完整 Tooltip label；内层 `file-operation-status-detail-content` ID 在第 942 行标识真实内容容器，允许比较实际滚动几何。 |

依赖实现重新通过本地 `.crate` 包 checksum 与 Cargo.lock 绑定，且源文件逐字节等于包内成员；无下载或依赖执行：

- [gpui-pre div.rs:736](/Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837/gpui-pre-0.3.12/src/elements/div.rs:736)
  定义可悬停 API；[同文件第 4039 行](/Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837/gpui-pre-0.3.12/src/elements/div.rs:4039)
  将 hoverable popup bounds 纳入可见性。
- [gpui-pre styled.rs:139](/Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837/gpui-pre-0.3.12/src/styled.rs:139)
  的 `truncate` 设置 overflow hidden／nowrap／ellipsis；第 145 行的 `line_clamp` 限制显示行数。
- [gpui-kit test.rs:174](/Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837/gpui-kit-0.10.0/src/test.rs:174)
  和[第 289 行](/Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837/gpui-kit-0.10.0/src/test.rs:289)：
  `hover` 实际分发 MouseMoveEvent，`scroll` 实际分发 ScrollEvent，并渲染 frame；
  不是仅改写测试观察快照。

**新增回归具备区分修复前后的行为断言。**
[editor_backup_tests.rs:274](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/editor_backup_tests.rs:274)
新增 `editor_status_detail_long_message_accepts_hover_and_wheel`：

1. 第 278–307 行构造 80 行诊断，先验证触发行高度／可见位置，再验证真实内容高度大于详情视口至少 400px，
   且底部确实在视口外，排除了“消息根本没有溢出”的空通过。
2. 第 308–324 行确认 popup 中心不在触发行内，实际将指针移入 popup，经有界时钟推进和重绘后仍能找到可见详情；
   直接覆盖原 P2-01 的触发。
3. 第 325–340 行实际发出滚轮事件，先要求内容 y 坐标向上移动超过 100px，再滚到底；
   要求内容末端落在视口内。断言依赖真实内容几何，超过仅检查完整 label 的证明力。
4. 第 341–364 行检查完整英文末尾，现场切换中文并重绘检查中文末尾，再向上滚动使内容起点回到视口顶。
   第 367–368 行同时要求 SFTP 请求数不增加且没有原子写入。

原第 1 例
[editor_backup_tests.rs:115](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/editor_backup_tests.rs:115)
继续遍历主题 registry 的三种主题族、Light／Dark 和中英文，检查当前完整状态／详情 AX label、
语义文案及窗口右／下边界；这些断言与新增长内容交互例互补。第 5 例的长诊断由测试直接设入真实
FilesPanel status，针对 popup 行为；前四例才经实际审核保存／取消和 SFTP packets 验证文件操作语义。
不能把第 5 例单独说成完整保存流程或 native 输入验收。

**父级动态证据：只读核对，未由本评审执行。** 在核对期间父级 r4 专项已产出完成日志，
所以这里记录观测到的完成结果，并保持它们与上述静态结论分开。

| 父级记录 | 已核对的事实 |
| --- | --- |
| [tooltip-negative-r5.log](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-backup-verification-20261117/tooltip-negative-r5.log:10) | running 1，0 passed／1 failed／0 ignored，exit 101。回溯定位测试第 324 行的移入后 `find`；初始 overflow 断言及第 315 行的移入动作已经执行。 |
| [app-backup-r4.log](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-backup-verification-20261117/app-backup-r4.log:2) | running 5，五个具名用例逐一 ok；5 passed／0 failed／0 ignored，exit 0，1369 filtered。包含新增 pointer／wheel 长状态例。 |
| [session-backup-r4.log](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-backup-verification-20261117/session-backup-r4.log:2) | running 30，30 个具名用例逐一 ok；30 passed／0 failed／0 ignored，exit 0，313 filtered。生产 session 未随 r4 改变。 |
| [test-binaries-r4.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-backup-verification-20261117/test-binaries-r4.json) 及父级库存日志 | 记录绑定 r4，库存 session343／app1374／OpenSSH18；源码声明与父级专项 executed 名称集合相等。app 的实际 Cargo compiler-artifact 路径、binary manifest 路径和专项运行路径一致。仅审阅这些记录，未独立运行 inventory，也未读取／哈希 target binary。 |

分别重算上述负例／app／session 日志 SHA-256，均与父级运行回执一致：

```text
tooltip-negative-r5.log  fa50a41972e010c236b6b4231aeaa858cc3f25bd1ceb49f5f1f7c39640ba51be
app-backup-r4.log        56ff8138937f13cfefc5ba8cbae9ad2f81020b528674f3dfc6121fc816156914
session-backup-r4.log    8550b2a3ce7f0cf51a835c738530ccbaeb593209d5bfe3839be21043dca12c35
```

父级回执均记载 direct_reaped=true、active_processes=0、pipes_drained=true、未超时／中断及无 controller errors。
负例 exit 101 是保留的预期失败，不改记为通过。

负例的
[inputs-tooltip-negative-r5.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-backup-verification-20261117/inputs-tooltip-negative-r5.json)
同为 727 输入，aggregate 为
`dd892487f222d0ca200e10ca73b3c5d1ede88dd6b69a28cc5e04e97c8614021e`。
与 r4 比较只有 view.rs 一份输入不同；在内存中把 r4 唯一的 `.hoverable_tooltip({` 换回 `.tooltip({`，
得到与该负例冻结完全相等的 43930 字节和 SHA-256
`b94bf57e6becb0179a8fabbdbafe810d9564fe32f8f739182e6de1945a48388d`。
触发行约束和第 5 例在这一正负对照中相同，因此 r5 提供了针对可悬停修复的有效负例证据。
父级先前披露的“触发行撑高、初始 popup 未打开”负例，以及手动挑旧二进制运行 0 tests 的 guard 失败，
均不计作已复现移入后关闭，也不计作有效回归通过；本 followup 没有改写这些历史失败。

**实际命令与边界。** 继续采用已读 AGENTS／RTK／HANDOFF／ADR0153／REMOTE_TEXT_FORMAT
及 rust-best-practices 的所有权、类型化状态、异步边界和有意义行为测试原则。
本轮使用 Python 标准库读取／哈希／比较 JSON、源码与包内成员，使用 `rg` 定位依赖实现；
未执行任何父级 runner。实际最终捕获命令：

```text
python3 /Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-backup-verification-20261117/source-review/capture_followup.py
```

[capture_followup.py](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-backup-verification-20261117/source-review/capture_followup.py)
仅写自己的 `followup-receipt.json`。它先后两次执行以下只读 Git 查询，并在两次查询之间读取生产 working diff，
合计 5 个只读 Git 子命令，均 exit 0；环境设 `GIT_OPTIONAL_LOCKS=0`，具体 argv、时间和输出摘要入回执：

```text
git --no-optional-locks rev-parse HEAD
git --no-optional-locks ls-files --cached --others --exclude-standard -z
git --no-optional-locks diff --no-ext-diff --no-textconv --binary HEAD -- crates/keelshell-session/src/error.rs crates/keelshell-session/src/sftp.rs crates/keelshell-app/src/files.rs crates/keelshell-app/src/files/view.rs crates/keelshell-app/src/files/worker.rs
```

freeze 沿用父级算法：只枚举 Git cached／others／exclude-standard，排除 `docs/`、`.hallmark/` 和被忽略路径，
按路径排序，再对 `path + NUL + sha256 + LF` 聚合。故 727 输入不包含正在编辑的文档；
实际读取的合同／技能文件只另记观测时间与 SHA-256，不声称其受 r4 冻结覆盖。
没有执行会改写父级文件的 `snapshot_inputs.py`，也没有重跑会覆盖原 receipt 的 `capture_receipt.py`。

**本评审独立执行数：Cargo 0、rustc 0、fmt 0、Clippy 0、测试／prebuilt 0、SSH／OpenSSH 功能调用 0、
GUI 操作／截图 0。独立 passed／failed／ignored 为未执行。target 写入、源码／项目文档／Git 修改、
提交／清理及依赖下载均为 0。** 仅新增本目录 followup、回执和捕获脚本。
未把父级 headless GPUI 输入／几何测试、编译或日志审阅写作 native 验收；没有独立编译或功能执行。
父级完整门禁、native／跨平台、发布／安装及后续输入仍由各自证据判断。
原报告关于 deadline 专项证明范围和 SFTP 读回只是有界观测的限制也继续保留。
