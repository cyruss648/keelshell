# 编辑器备份完整读回：独立、非作者、严格只读源码评审

**结论：REQUEST_CHANGES。P0：0，P1：0，P2：1，P3：0。**

本结论绑定 HEAD `7058925330b96161a25142fb5bee94fa24aa5117` 加 r3 working inputs：
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-backup-verification-20261117/inputs-freeze-r3.json`，
727 输入，aggregate SHA-256
`bbe90528db8e2d0fced73848f585d149a425253bc6595a9939397643e7b9e970`。
已独立逐项重算，相等；最终落盘核对结果见同目录 `receipt.json`。
这是源码审查意见，不是编译、功能执行、完整门禁或 native 验收。

## P2-01：状态详情不能保持悬停，超高消息无法进入滚动阅读

**位置：**
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/view.rs:921`
使用 `.tooltip(...)`；同文件 `:932`—`:935` 将内容限制为 480 × 220 像素并设置
`overflow_y_scroll()`。

**触发：** 状态文字换行后超过 220 像素，例如成功消息带有较长远端目录／备份路径，
或文件操作带有较长诊断。用户先悬停紧凑状态行，再把指针移进弹出的详情以滚动查看尾部。

**源码证据：** 当前 Cargo.lock 锁定 `gpui-kit 0.10.0`、`gpui-component 0.10.0`、
`gpui-pre 0.3.12`。实际使用的 public GPUI `.tooltip()` 将 `hoverable` 设为 `false`；
只有 `.hoverable_tooltip()` 设为 `true`。指针离开触发行后，不可悬停 tooltip 的
visibility 路径直接 Hide，不把 tooltip 自身的 bounds 算作仍悬停。

- `/Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837/gpui-pre-0.3.12/src/elements/div.rs:720`—`:752`：
  两种 API 的定义与 `hoverable` 取值。
- 同文件 `:4039`—`:4050`：只有 hoverable 才接受 tooltip bounds；否则立即 Hide。
- `/Users/hdh/.cargo/registry/src/rsproxy.cn-e3de039b2554c837/gpui-kit-0.10.0/src/lib.rs:100`—`:103`：
  默认后端 public GPUI facade。
- `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/Cargo.toml:11`—`:18`：
  本项目未选择 `gpui-fast` feature。

上述三个相关 GPUI 文件均与本地 `.crate` 原始包内相同文件逐字节一致，
且三个 `.crate` 整包 SHA-256 均等于 Cargo.lock checksum；没有下载或运行依赖。
`receipt.json` 保存该绑定，结论没有依赖“本机缓存版本大概相同”的推测。

**影响：** 可视详情的下半段无法按所实现的滚动方式读取，违背 ADR0153
“允许换行与有界滚动”的交互合同。完整 AX label 仍存在，因此这里不声称无障碍名称丢失，
也不声称文件保存或备份字节受到破坏。

**现有回归为何漏检：**
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/editor_backup_tests.rs:106`—`:150`
只把指针悬停在 `file-operation-status`，随后检查 detail 可见、完整 label、
语言／主题变化及右／下边界；没有将指针移入 detail，没有生成溢出内容并滚动。
短消息的这些断言可以成立，同时保留本缺陷。

**要求修改：** 给需要滚动的内容使用 public `.hoverable_tooltip()` 或等效可交互详情。
增加真实 GPUI 输入回归：消息高度确实溢出，指针从状态行移入 detail 后仍保持显示，
滚轮实际改变内容位置并能读到尾部；保持当前实时双语、主题与无网络请求的断言。
本评审未改源码，也未独立执行复现；以上是已锁定依赖实现支持的确定性静态路径分析。

## 其余生产路径的审查结果

评审按 rust-best-practices 的所有权、类型化错误、异步状态、不变量注释、
有意义行为测试和 public rustdoc 原则进行。未运行技能中建议的 Cargo、fmt 或 Clippy，
用户的只读与 Cargo 槽约束优先。

| 关注点 | 所审证据与结论 |
| --- | --- |
| ACK 后才读回 | `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp.rs:750`—`:767`：先完成原 snapshot 复核和原子备份发布，写者成功返回后才置 `published=true`、revalidate 并读回。`:980`—`:992` 保持 POSIX rename STATUS 成功边界。 |
| 同一 scope，不嵌套抢占 | 同文件 `:748`、`:763`、`:778`、`:800` 保留同一备份 reservation 直到 complete。读回 API 不自行 reserve。`:734`—`:738` 在备份函数成功返回后另取目标 scope；未提前触发目标 staging。 |
| 整个备份 deadline | 同文件 `:750`—`:787` 的原外层 deadline 覆盖初始复核、发布、scope 复核和全部读回；读回内部 deadline 无法延长外层。`:790`—`:799` 仅对发布已经确认后的 Timeout 分类，撤权／关闭仍归 Closed。admission、既有 cleanup completion 预算仍是独立边界。 |
| 完整字节和元数据 | `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/inspection.rs:55`—`:125` 检查父链、显式普通文件／大小、原句柄前后 metadata、最终 leaf、EOF、精确读取大小及只读 CLOSE ACK。`sftp.rs:779`—`:783` 再要求全部原字节相等和精确 `0o100600`。 |
| 当前 authority | `sftp.rs:763`、`:768`—`:778` 及 Timeout 分支检查；`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/mutation.rs:106`—`:131` 保持授权在 resolve awaits 两侧复查。撤权时不进入下一目标写入。 |
| UNKNOWN 优先级 | `sftp.rs:771`—`:777` 不把 Closed、Busy、Quarantined、Uncertain 重包为备份验证失败。`mutation.rs:94`—`:104` 的 complete 在 pending、reservation 失效或 cleanup 未知时优先给 MutationUncertain；发布没有有效 ACK 时 `published` 不置 true，原 quarantine 保留。 |
| 无自动重放／无删除已发布备份 | `sftp.rs:718`—`:800` 没有重试或删除已发布备份。发布成功 `:991` 清除临时路径的 guard ownership，失败读回不调用原子临时清理；未知发布仍保留原 pending/quarantine 处理。已有未发布 staging 的拥有者清理与删除已发布备份是不同对象，不把二者混同。 |
| target untouched 的准确分类 | `sftp.rs:734`—`:739` 使 `EditorBackupUnverified` 只出现在目标替换尚未调用的路径；`error.rs:76`—`:79`、`:109` 为无远端内容／诊断的不可重试类型。其含义是“本次替换未发起”，不是声称独立远端写者没有修改目标。 |
| 目标二次复核仍在 | `sftp.rs:737`、`:817`—`:827`、`:843`—`:846`、`:949`—`:951` 保持目标完整初检及发布前复核；r2 已将竞争写入改成同长 `external`，新断言精确要求 `Invalid("reviewed file content or metadata changed")`。 |
| app 区分两个读回失败 | `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files.rs:751`—`:758`、`:883`—`:890` 独立映射备份失败和已发布目标读回失败。`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/worker.rs:881`—`:899` 必须完整目标字节相等才产生 Saved。错误 UI 分支不写入编辑基线或草稿。 |
| r3 worker 取消精确映射 | `worker.rs:870`—`:880` 仅转换 `SessionError::Closed && stop.load(Acquire)` 为 Cancelled；其余使用原 FileFailure::from，MutationUncertain 仍为 OutcomeUncertain，quarantine／busy／备份验证失败也保持各自类型。映射没有发起网络、重放或清理。它修复 action 在外层 10ms cancellation timer 前观察到 stop 的路径。 |
| 较新草稿与实时语言 | `files.rs:1921`—`:1957` 保留较新草稿，只在完整 Saved 结果后采用对应基线；`files/view.rs:925`—`:938` 每次 tooltip 内容 render 都读取 owner 当前 status 与 locale。`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/i18n.rs:94`—`:109` 按当前语言渲染并 refresh windows。实时双语路径本身未发现新缺陷；可滚动可达性仍受 P2-01 阻断。 |

除 P2-01 外，未发现本批需修订的 P0—P3 生产缺陷；这不把没有执行的检查写成通过。

## 新测试能证明的内容及边界

静态逐名统计与模块注册共 **30 session + 4 app + 1 opt-in OpenSSH**。
这里是源码声明数量，不是本评审编译出的 test inventory。

- Session 测试路径：
  `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/sftp/editor_backup_tests.rs`。
  30 个具名 tokio 测试，调用生产 public editor APIs，经真实 loopback TCP／SSH／SFTP
  packet handler。4 个正向函数覆盖空内容、多 chunk Unicode、UTF-16 与 5 种显式旧编码；
  16 个拒绝函数覆盖原字节损坏、截断、缺失、链接、目录、类型／大小／mode 缺失或异常、
  oversized、读错误、提前 EOF、句柄／leaf metadata 变化与 CLOSE 失败；
  其余覆盖共享 reservation、5 个撤权场景、2 个超时场景、未知发布和目标二次复核。
  `:648`—`:663` 的共同断言同时检查目标全部字节及 metadata 不变、
  没有 TargetStaged／TargetPublished、没有删除已发布备份；
  `:666`—`:722` 比较全部读回 chunk，并要求 EOF／CLOSE 先于目标 staging。
  未知发布例 `:1158`—`:1191` 使用无有效 STATUS 的实际协议响应，检查共享 quarantine
  和 sibling 写入被拒绝；不是仅对一个错误 enum 做自我验证。
- App 测试路径：
  `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/files/editor_backup_tests.rs`。
  4 个具名 GPUI 测试通过真实保存审核／确认／取消动作进入生产 worker：
  备份失败保留目标、草稿和基线；只读 CLOSE 阻止提前写目标并保留较新 UTF-16 草稿；
  取消不发起目标替换；目标已发布后失败使用另一类状态。
  r3 `:90` 的 writable staging hold 使用双点 `/..backup-...`，
  符合 `sftp.rs:878`—`:879` 给已经以点开头的备份 basename 再加 staging 前缀的命名；
  只读 leaf 的单点前缀保持正确。4 例具备实际行为断言；P2-01 的移入／滚动交互未覆盖。
- OpenSSH 测试路径：
  `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/support/openssh_editor_backup.rs`。
  `openssh_interop.rs:18`—`:19` 注册新模块；新测试 `:5`—`:9` 显式 ignored，
  75s 上界。4 类内容各连续保存两次，检查 8 个唯一备份的完整原字节、size、
  0600，目标字节和权限，随后重读所有历史备份；使用带引号及 shell 元字符的文件名。
  `scripts/openssh_interop.py:29`—`:33` 的标准 runner 使用 `--ignored`，
  因此新例可被标准独立服务端运行覆盖。该正向用例不能独自证明备份读回在目标替换之前，
  顺序证据来自受控 session 测试的 packet events 及生产源码；也不覆盖恶意服务端 fault、
  Windows/Linux 原生 UI 或真实客户 SSH。

超时例 `session/editor_backup_tests.rs:1120`—`:1156` 证明设计上要求超时分类、
撤权优先与目标不变，但没有先消耗大部分发布预算、再让读回持续进展的时间场景；
因此“没有重置整个 deadline”当前还依靠外层源码结构，不能单凭该超时用例声称已动态实证。
这属于证据边界，未另列生产缺陷。

**本评审实际执行：** Cargo 0、rustc 0、fmt 0、Clippy 0、测试／prebuilt 测试 0、
SSH／OpenSSH 功能调用 0、GUI 操作 0、截图 0、target 写入 0。
独立 passed／failed／ignored 数为“未执行”，不是 35 项通过或 0 项失败。

**父级在对话中提供的进展，未作为本评审独立执行结果：**
原 session 首轮 29 pass／1 fail，原 app 2 pass／2 fail，失败日志与原 build 失败均保留。
相继修正同长竞争 fault／精确诊断、writable staging hold 和 worker 取消映射。
最新父级报告 r3 session30/app4 已逐名通过，库存 session343／app1373／OpenSSH18、
binary 与 source 归属已核；Pasteur prebuilt 功能复核与父级标准 OpenSSH18 正在进行。
线上依赖查询原超时／registry 失败不改写为成功，native 仍为父级报告的锁屏。
本评审不重复功能执行、不代签父级运行、不从 headless 或编译推导 native。

## 输入、命令和只读回执

已先读项目 AGENTS、`/Users/hdh/.codex/RTK.md`、HANDOFF、ADR0153、
REMOTE_TEXT_FORMAT，再读 rust-best-practices 与相关章节。以 HEAD、完整 working inputs、
真实 public API 调用者、协议 reader／writer／mutation／reservation 与锁定依赖互相核对。
没有作者身份下的生产修改；本评审只写自己的
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/editor-backup-verification-20261117/source-review/`。

初次 r1 重算为 727／`218dd458955798402bd2c573712e8f99a2d0a315698d6b874f57a4948824c8ed`。
r2 为 727／`864a0dd9b27ce0107283eb279aa00d54f904b845b581197cd63781f0c24b74d8`，
只改变 session 测试文件。
r3 只再改变 app 新测试和 worker，生产 session、error、files.rs、view.rs 未变。
所有变更均为父级通知后的独立读取，没有把较晚输入冒充 r1 原件。

freeze 的真实算法排除 `docs/` 和 `.hallmark/`，并且只枚举 Git
cached／others／exclude-standard；因此不能声称这 727 输入冻结了文档。
`receipt.json` 为实际读取的文档另记 SHA-256 和观测时间；
CAPABILITIES／设计／测试记录仍在由父级编辑，当前静态签署不包括其后续改写。

实际主命令包括：

```text
pwd
rg -n "KeelShell|keelshell|严格只读|shared.target|SHARED_TARGET" /Users/hdh/.codex/memories/MEMORY.md
cat /Users/hdh/.codex/RTK.md
cat AGENTS.md
cat docs/HANDOFF.md
cat docs/adr/0153-editor-backup-readback.md
cat docs/product/REMOTE_TEXT_FORMAT.md
cat /Users/hdh/.agents/skills/rust-best-practices/SKILL.md
GIT_OPTIONAL_LOCKS=0 git --no-optional-locks rev-parse HEAD
GIT_OPTIONAL_LOCKS=0 git --no-optional-locks status --short --untracked-files=all
GIT_OPTIONAL_LOCKS=0 git --no-optional-locks diff --no-ext-diff --no-textconv --stat
GIT_OPTIONAL_LOCKS=0 git --no-optional-locks diff --no-ext-diff --no-textconv --numstat
```

另用 `rg`、`nl -ba ... | sed -n ...` 读取上文证据范围；用标准库 Python
内联脚本逐项哈希、统计源码测试声明及只读检查 `.crate` 归属。
没有执行父级 `snapshot_inputs.py`，因为它会向父级活动目录写入；只读其算法后独立重算。
用于最终重复核验与生成回执的实际命令为：

```text
python3 work/editor-backup-verification-20261117/source-review/capture_receipt.py
```

该脚本完整保存于本目录，仅执行只读 Git 命令、文件读取／哈希、包内成员读取，
输出限定为本目录的 receipt.json。其子命令完整 argv、exit code、stdout／stderr 摘要和
输入摘要均入 receipt；既有探索性诊断也保留说明，不把检索失败写成通过。

未独立编译或验证 test binary 库存；未运行测试、fmt、Clippy、依赖门禁；
未触碰 target、源码、文档或 Git 元数据；未提交、清理、下载依赖、启动应用或安装。
最终意见仍是 **REQUEST_CHANGES**，要求关闭 P2-01 后按新的明确冻结差分复核。
