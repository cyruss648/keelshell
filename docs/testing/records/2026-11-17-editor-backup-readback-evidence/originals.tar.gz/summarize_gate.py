"""Validate the complete gate and its exact compiled application inventory."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re

BASE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("gate_test_parser", BASE / "summarize_tests.py")
parser = importlib.util.module_from_spec(spec)
spec.loader.exec_module(parser)


def derive(raw, inventory_raw, focused, handoff):
    summary = parser.summarize(b"##[group]Run python scripts/check.py\n" + raw)
    suites = summary["suites"]
    docs = summary["doctest_runs_unassigned"]
    assert len(suites) == 92 and not summary["inventory_result_summary_mismatches"]
    assert all(row["summary"]["state"] == "ok" and row["summary"]["failed"] == 0
               for row in suites + docs)
    inventory = re.findall(r"^(\S+): test$", inventory_raw.decode(), re.M)
    assert len(inventory) == len(set(inventory)) == 1374
    app = [row for row in suites if "keelshell_app" in row["suite"]]
    session = [row for row in suites if "keelshell_session" in row["suite"]]
    interop = [row for row in suites if "tests/openssh_interop.rs " in row["suite"]]
    assert len(app) == len(session) == len(interop) == 1
    app_outcomes = dict(app[0]["results"])
    session_outcomes = dict(session[0]["results"])
    assert sorted(app_outcomes) == sorted(inventory)
    new_app = focused["app"]["required_new_tests"]
    new_session = handoff["new_tests"]
    assert len(new_app) == 5 and len(new_session) == 30
    assert all(app_outcomes[name] == "ok" for name in new_app)
    assert all(session_outcomes[name] == "ok" for name in new_session)
    assert interop[0]["summary"]["ignored"] == 18
    assert dict(interop[0]["results"])[
        "editor_backup::openssh_editor_verified_backups_preserve_unicode_legacy_empty_and_repeated_bytes"
    ] == "ignored"
    text = raw.decode()
    discovery = text.split(" -m unittest discover -s scripts -p test_*.py", 1)[1].split(
        "Running: cargo fmt", 1,
    )[0]
    assert re.findall(r"Ran (\d+) tests? in", discovery) == ["293"]
    assert "OK (skipped=2)" in discovery
    assert re.findall(r"Ran (\d+) tests? in", text) == ["293", "30"]
    for marker in ("readiness-error-tests", "observer-io-error-tests", "controller-small-stack"):
        assert marker in text
    result = {
        "full_log_sha256": hashlib.sha256(raw).hexdigest(),
        "ordinary_suites": len(suites),
        "ordinary_rust": {key: sum(row["summary"][key] for row in suites)
                          for key in ("passed", "failed", "ignored")},
        "rustdoc": {key: sum(row["summary"][key] for row in docs)
                    for key in ("passed", "failed", "ignored")},
        "app": app[0]["summary"],
        "app_inventory": len(inventory),
        "app_inventory_matches_execution": True,
        "new_app_passed": len(new_app), "new_session_passed": len(new_session),
        "new_openssh_default_ignored": 1,
        "python_run": 293, "python_skipped": 2, "archive_helper_python_run": 30,
        "workspace_harness_free_controllers": summary["custom_harness_headers"],
        "tests_replayed_for_derivation": 0,
    }
    assert len(result["workspace_harness_free_controllers"]) == 2
    return result, summary


if __name__ == "__main__":
    result, suites = derive(
        (BASE / "full-gate-r1.log").read_bytes(),
        (BASE / "gate-app-inventory-r1.log").read_bytes(),
        json.loads((BASE / "focused-summary-r4.json").read_text()),
        json.loads((BASE / "author-handoff.json").read_text()),
    )
    for name, value in [("gate-summary-r1.json", result), ("gate-suites-r1.json", suites)]:
        with (BASE / name).open("x") as output:
            json.dump(value, output, indent=2)
            output.write("\n")
    print(json.dumps(result))
