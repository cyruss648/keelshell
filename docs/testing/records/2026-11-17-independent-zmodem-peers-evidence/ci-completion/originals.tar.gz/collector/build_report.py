"""Describe saved API responses and ZIPs without replaying any CI or tests."""
import argparse
import collections
import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import runpy
import zipfile

import collect as c

BASE = Path(__file__).resolve().parent
PLATFORMS = ("windows-2025", "macos-26", "ubuntu-24.04")


def relative(path):
    return str(path.relative_to(BASE))


def record(path):
    return {"path": relative(path), "bytes": path.stat().st_size, "sha256": c.sha(path)}


def download_record(path, digest=None, advertised_bytes=None):
    result = {
        "path": relative(path),
        "status": "not_downloaded",
        "github_digest": digest,
    }
    if not path.exists():
        return result
    result.update(record(path))
    receipt_path = BASE / "receipts" / (path.stem + ".json")
    receipt = json.loads(receipt_path.read_bytes()) if receipt_path.exists() else {}
    result["fetch_exit_code"] = receipt.get("exit_code")
    result["fetch_reaped"] = receipt.get("reaped")
    result["fetch_timed_out"] = receipt.get("timed_out")
    try:
        with zipfile.ZipFile(path) as archive:
            members = []
            seen = set()
            for info in archive.infolist():
                if info.is_dir():
                    continue
                if info.filename in seen:
                    raise ValueError("Duplicate ZIP member")
                seen.add(info.filename)
                content = archive.read(info)
                members.append({
                    "path": info.filename,
                    "bytes": len(content),
                    "sha256": hashlib.sha256(content).hexdigest(),
                })
        result["status"] = "downloaded_verified" if receipt.get("exit_code") == 0 else "fetch_failed"
        result["member_count"] = len(members)
        result["crc_checked"] = True
        result["members"] = members
        if digest is not None:
            result["github_digest_match"] = digest == "sha256:" + result["sha256"]
            if not result["github_digest_match"]:
                result["status"] = "digest_mismatch"
        if advertised_bytes is not None:
            result["advertised_size_match"] = advertised_bytes == result["bytes"]
            if not result["advertised_size_match"]:
                result["status"] = "size_mismatch"
    except Exception as error:
        result["status"] = "invalid_zip"
        result["error"] = f"{type(error).__name__}: {error}"
    return result


def compact(download):
    return {key: value for key, value in download.items() if key != "members"}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--label", required=True)
    parser.add_argument("--final", action="store_true")
    args = parser.parse_args()
    derived = BASE / "derived"
    derived.mkdir(exist_ok=True)
    snapshots = {}
    downloads = []
    errors = []
    for name, rid in c.CONTEXT["runs"].items():
        run_path, run = c.latest(name, "run")
        jobs_path, jobs = c.latest(name, "jobs")
        artifacts_path, artifacts = c.latest(name, "artifacts")
        exact = run.get("id") == rid and run.get("head_sha") == c.EXPECTED
        job_rows = jobs.get("jobs", [])
        attempt_jobs = [row for row in job_rows if row.get("run_attempt") == run["run_attempt"]]
        if not exact:
            errors.append(f"{name}: run/head mismatch")
        if jobs.get("total_count") != len(job_rows):
            errors.append(f"{name}: incomplete jobs pagination")
        if artifacts.get("total_count") != len(artifacts.get("artifacts", [])):
            errors.append(f"{name}: incomplete artifacts pagination")
        run_row = {
            "id": rid,
            "head_sha": run.get("head_sha"),
            "exact_head_match": exact,
            "attempt": run.get("run_attempt"),
            "event": run.get("event"),
            "status": run.get("status"),
            "conclusion": run.get("conclusion"),
            "created_at": run.get("created_at"),
            "updated_at": run.get("updated_at"),
            "raw": {
                "run": relative(run_path),
                "jobs": relative(jobs_path),
                "artifacts": relative(artifacts_path),
            },
            "jobs": [
                {
                    "id": row["id"],
                    "name": row["name"],
                    "run_attempt": row.get("run_attempt"),
                    "head_sha": row.get("head_sha"),
                    "status": row["status"],
                    "conclusion": row["conclusion"],
                    "active_steps": [
                        step["name"] for step in row.get("steps", [])
                        if step["status"] == "in_progress"
                    ],
                    "failed_steps": [
                        {"name": step["name"], "conclusion": step["conclusion"]}
                        for step in row.get("steps", [])
                        if step.get("conclusion") in ("failure", "cancelled", "timed_out")
                    ],
                    "skipped_steps": [
                        step["name"] for step in row.get("steps", [])
                        if step.get("conclusion") == "skipped"
                    ],
                }
                for row in attempt_jobs
            ],
        }
        for row in attempt_jobs:
            if row.get("head_sha") != c.EXPECTED:
                errors.append(f"{name}: job {row['id']} head mismatch")
        log_path = BASE / "originals" / f"{name}-attempt{run['run_attempt']}-logs.zip"
        log = download_record(log_path)
        if not log_path.exists() and run["status"] != "completed":
            log["status"] = "unavailable_until_run_completed"
        log.update({"kind": "raw_logs", "run_id": rid})
        downloads.append(log)
        run_row["logs_zip"] = compact(log)
        run_row["artifacts"] = []
        for artifact in artifacts.get("artifacts", []):
            aid = artifact["id"]
            artifact_head_match = artifact.get("workflow_run", {}).get("head_sha") == c.EXPECTED
            artifact_run_match = artifact.get("workflow_run", {}).get("id") == rid
            path = BASE / "originals" / f"{name}-artifact-{aid}-archive.zip"
            data = download_record(path, artifact.get("digest"), artifact.get("size_in_bytes"))
            data.update({
                "kind": "artifact",
                "run_id": rid,
                "id": aid,
                "name": artifact["name"],
                "expired": artifact["expired"],
                "artifact_head_match": artifact_head_match,
                "artifact_run_match": artifact_run_match,
            })
            if not artifact_head_match or not artifact_run_match:
                errors.append(f"artifact {aid}: head/run mismatch")
            if data["status"] == "downloaded_verified":
                with zipfile.ZipFile(path) as archive:
                    if "receipt.json" in archive.namelist():
                        receipt = json.loads(archive.read("receipt.json"))
                        data["receipt"] = {
                            key: receipt[key]
                            for key in ("status", "source", "windows_api", "ssh", "native_gui")
                            if key in receipt
                        }
                    if "ssh-debug-cleanup.json" in archive.namelist():
                        cleanup = json.loads(archive.read("ssh-debug-cleanup.json"))
                        data["reported_original_process_cleanup"] = {
                            key: cleanup[key]
                            for key in (
                                "terminal_proven", "closed", "job_active_processes",
                                "complete_original_object_census", "pending_process_objects",
                                "pending_debug_event", "owned_handles_remaining",
                            )
                            if key in cleanup
                        }
                    for member in archive.namelist():
                        if member.endswith("/result.json"):
                            outcome = json.loads(archive.read(member))
                            data["interop"] = {
                                key: outcome[key]
                                for key in ("outcome", "platform", "passed_tests", "cleanup")
                                if key in outcome
                            }
            downloads.append(data)
            run_row["artifacts"].append(compact(data))
        snapshots[name] = run_row

    quality = snapshots["quality"]
    platform_rows = []
    parser_functions = runpy.run_path(str(BASE / "originals/source-summary-parser.py"))
    log_path = BASE / quality["logs_zip"]["path"]
    for platform in PLATFORMS:
        job = next((job for job in quality["jobs"] if job["name"] == f"native ({platform})"), None)
        row = {
            "platform": platform,
            "job_id": job["id"] if job else None,
            "status": job["status"] if job else "not_observed",
            "conclusion": job["conclusion"] if job else None,
            "tests": None,
        }
        job_logs = []
        for candidate in sorted(
            (BASE / "originals").glob(f"quality-job-{row['job_id']}-logs*.txt")
        ):
            receipt_path = BASE / "receipts" / (candidate.stem + ".json")
            if receipt_path.exists():
                receipt = json.loads(receipt_path.read_bytes())
                if receipt.get("exit_code") == 0 and candidate.stat().st_size:
                    job_logs.append(candidate)
        job_log = job_logs[-1] if job_logs else None
        available_run_log = (
            log_path.exists() and quality["logs_zip"]["status"] == "downloaded_verified"
        )
        if available_run_log or job_log is not None:
            try:
                if available_run_log:
                    with zipfile.ZipFile(log_path) as archive:
                        candidates = [
                            member for member in archive.namelist()
                            if member.startswith(f"native ({platform})/")
                            and member.endswith("_Rust quality gate.txt")
                        ]
                        if len(candidates) != 1:
                            raise ValueError("Expected one exact quality-gate log member")
                        raw = archive.read(candidates[0])
                    log_reference = candidates[0]
                else:
                    raw = job_log.read_bytes()
                    log_reference = relative(job_log)
                summary = parser_functions["summarize"](raw)
                totals = {
                    key: sum(suite["summary"][key] for suite in summary["suites"])
                    for key in ("passed", "failed", "ignored")
                }
                docs = {
                    key: sum(suite["summary"][key] for suite in summary["doctest_runs_unassigned"])
                    for key in ("passed", "failed", "ignored")
                }
                section = parser_functions["normalize"](raw)
                marker = "##[group]Run python scripts/check.py"
                if marker in section:
                    section = section.split(marker, 1)[1]
                section = section.split("Running: cargo fmt --all --check", 1)[0]
                counts = list(re.finditer(r"^Ran (\d+) tests in [\d.]+s$", section, re.MULTILINE))
                outcomes = list(re.finditer(r"^OK(?: \(skipped=(\d+)\))?$", section, re.MULTILINE))
                if len(counts) != 1 or len(outcomes) != 1 or outcomes[0].start() <= counts[0].end():
                    raise ValueError("Python discovery count/outcome not uniquely paired")
                row["tests"] = {
                    "ordinary_rust": totals,
                    "ordinary_suites": len(summary["suites"]),
                    "rustdoc": docs,
                    "rustdoc_subruns": len(summary["doctest_runs_unassigned"]),
                    "python_main": {
                        "run": int(counts[0][1]),
                        "skipped": int(outcomes[0][1] or 0),
                        "outcome": "OK",
                    },
                    "inventory_result_summary_mismatches": summary["inventory_result_summary_mismatches"],
                    "tests_replayed": 0,
                    "log_member": log_reference,
                }
                c.write_new(derived / f"{args.label}-quality-{platform}-tests.json", summary)
            except Exception as error:
                row["test_count_error"] = f"{type(error).__name__}: {error}"
                errors.append(f"{platform}: {row['test_count_error']}")
        platform_rows.append(row)

    terminal = sum(run["status"] == "completed" for run in snapshots.values())
    successful = sum(run["status"] == "completed" and run["conclusion"] == "success"
                     for run in snapshots.values())
    complete_downloads = all(
        item["status"] == "downloaded_verified" for item in downloads
    )
    quality_jobs_complete = (
        len(quality["jobs"]) == 3
        and {row["name"] for row in quality["jobs"]} == {
            f"native ({platform})" for platform in PLATFORMS
        }
        and all(
            row["status"] == "completed" and row["conclusion"] == "success"
            for row in quality["jobs"]
        )
    )
    full_success = (
        terminal == 3 and successful == 3 and quality_jobs_complete
        and complete_downloads and not errors
    )
    unverified = [
        "Native GUI, IME/accessibility, installation, signing/notarization, six-target releases and full product acceptance.",
        "Windows monitor's separate isolated-SSH prerequisite job is skipped; its direct-API artifact records ssh=UNRUN.",
        "This task collects natural CI results and reads saved evidence; no new product tests or independent semantic audit were executed.",
        "Historical failed runs and independent-peer empty-file/missing-OO boundaries are outside these three runs.",
    ]
    if terminal != 3:
        unverified.insert(0, "Quality is still running; unfinished platform outcomes, final logs, artifacts and test counts remain pending.")
    elif not complete_downloads:
        unverified.insert(0, "One or more final ZIP downloads or validations remain incomplete; see each download status.")
    receipts = [
        json.loads(path.read_bytes()) for path in sorted((BASE / "receipts").glob("*.json"))
    ]
    counts = collections.Counter(run["conclusion"] or run["status"] for run in snapshots.values())
    report = {
        "generated_at": c.now(),
        "started_at": c.CONTEXT["started_at"],
        "elapsed_seconds": round(
            (
                dt.datetime.now(dt.timezone.utc)
                - dt.datetime.fromisoformat(c.CONTEXT["started_at"])
            ).total_seconds(),
            3,
        ),
        "repo": c.REPO,
        "exact_head": c.EXPECTED,
        "all_run_heads_match": all(run["exact_head_match"] for run in snapshots.values()),
        "status": "completed_success" if full_success else (
            "in_progress" if terminal != 3 else "completed_with_failures_or_holds"
        ),
        "natural_outcomes": {"runs": 3, "terminal": terminal, **dict(counts)},
        "platform_count": {
            "expected": 3,
            "observed": sum(row["job_id"] is not None for row in platform_rows),
            "completed": sum(row["status"] == "completed" for row in platform_rows),
            "success": sum(row["conclusion"] == "success" for row in platform_rows),
            "failure": sum(row["conclusion"] == "failure" for row in platform_rows),
            "note": "Quality runner jobs; job names containing native do not establish desktop acceptance.",
        },
        "platforms": platform_rows,
        "runs": snapshots,
        "unverified": unverified,
        "collection_errors": errors,
        "execution": {
            "gh_api_method": "GET only",
            "recorded_subprocess_count": len(receipts),
            "all_recorded_children_reaped": all(item.get("reaped") for item in receipts),
            "timed_out_count": sum(bool(item.get("timed_out")) for item in receipts),
            "nonzero_exit_count": sum(item.get("exit_code") != 0 for item in receipts),
            "network_timeout_seconds": {"json": 45, "logs_zip": 90, "artifact_zip": 90},
            "cargo_invocations": 0,
            "workflow_reruns": 0,
            "commits": 0,
            "pushes": 0,
            "cleanup_performed": False,
            "cleanup_owner": "parent after handoff",
        },
    }
    for key in ("head", "tracked-status", "tracked-diff"):
        initial = BASE / f"originals/initial-{key}.txt"
        final = BASE / f"originals/final-{key}.txt"
        if initial.exists() and final.exists():
            report.setdefault("checkout_observations", {})[key] = {
                "initial": initial.read_text().strip(),
                "final": final.read_text().strip(),
                "equal": initial.read_bytes() == final.read_bytes(),
            }
    zip_manifest = BASE / f"zip-manifests-{args.label}.json"
    c.write_new(zip_manifest, {"generated_at": c.now(), "archives": downloads})
    report["zip_manifest"] = zip_manifest.name
    output = BASE / ("report.json" if args.final else f"report-{args.label}.json")
    c.write_new(output, report)
    print(json.dumps({
        "report": str(output),
        "status": report["status"],
        "outcomes": report["natural_outcomes"],
        "platform_count": report["platform_count"],
        "zip_count_downloaded": sum(item["status"] == "downloaded_verified" for item in downloads),
        "errors": errors,
    }, separators=(",", ":")))


if __name__ == "__main__":
    main()
