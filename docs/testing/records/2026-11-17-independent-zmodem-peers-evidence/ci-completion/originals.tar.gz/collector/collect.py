"""Read-only, bounded GitHub evidence collection. Never execute product tests."""
import argparse
import concurrent.futures
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time
import zipfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent.parent
CONTEXT = json.loads((BASE / "collection-context.json").read_bytes())
REPO = CONTEXT["repo"]
EXPECTED = CONTEXT["expected_head"]
ENV = {
    **os.environ,
    "GH_PROMPT_DISABLED": "1",
    "GIT_OPTIONAL_LOCKS": "0",
    "PAGER": "cat",
    "PYTHONDONTWRITEBYTECODE": "1",
}


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_new(path, obj):
    with path.open("x") as stream:
        json.dump(obj, stream, indent=2, ensure_ascii=False)
        stream.write("\n")


def call(label, args, relative, timeout=45):
    path = BASE / relative
    stderr_path = BASE / "receipts" / (label + ".stderr")
    started = now()
    tick = time.monotonic()
    timed_out = False
    escalation = []
    with path.open("xb") as stdout, stderr_path.open("xb") as stderr:
        process = subprocess.Popen(
            args,
            stdout=stdout,
            stderr=stderr,
            cwd=ROOT,
            env=ENV,
            start_new_session=True,
        )
        try:
            code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            for sig, wait in ((signal.SIGTERM, 3), (signal.SIGKILL, 3)):
                try:
                    os.killpg(process.pid, sig)
                    escalation.append(sig.name)
                except ProcessLookupError:
                    pass
                try:
                    code = process.wait(timeout=wait)
                    break
                except subprocess.TimeoutExpired:
                    continue
            else:
                raise RuntimeError("Child did not reap after SIGKILL")
    receipt = {
        "label": label,
        "argv": args,
        "output": relative,
        "started_at": started,
        "finished_at": now(),
        "timeout_seconds": timeout,
        "duration_seconds": round(time.monotonic() - tick, 3),
        "exit_code": code,
        "timed_out": timed_out,
        "signals": escalation,
        "reaped": process.returncode is not None,
        "bytes": path.stat().st_size,
        "sha256": sha(path),
    }
    write_new(BASE / "receipts" / (label + ".json"), receipt)
    return receipt


def api(label, endpoint, relative, timeout=45):
    return call(
        label,
        [
            "gh", "api", "--allow-escape-sequences", "--method", "GET",
            "-H", "Accept: application/vnd.github+json",
            "-H", "X-GitHub-Api-Version: 2022-11-28",
            endpoint,
        ],
        relative,
        timeout,
    )


def parallel(tasks):
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=9) as pool:
        futures = [pool.submit(api, *task) for task in tasks]
        for future in concurrent.futures.as_completed(futures):
            result = future.result()
            results.append(result)
            print(json.dumps(result, separators=(",", ":")), flush=True)
    return results


def latest(name, kind):
    paths = sorted((BASE / "originals").glob(f"obs*-{name}-{kind}.json"))
    if not paths:
        return None, None
    path = paths[-1]
    return path, json.loads(path.read_bytes())


def snapshot(prefix, names):
    tasks = []
    for name in names:
        rid = CONTEXT["runs"][name]
        for kind, suffix in (
            ("run", ""),
            ("jobs", "/jobs?filter=all&per_page=100"),
            ("artifacts", "/artifacts?per_page=100"),
        ):
            label = f"{prefix}-{name}-{kind}"
            tasks.append((
                label,
                f"repos/{REPO}/actions/runs/{rid}{suffix}",
                f"originals/{label}.json",
            ))
    results = parallel(tasks)
    for name in names:
        run_path, run = latest(name, "run")
        _, jobs = latest(name, "jobs")
        _, artifacts = latest(name, "artifacts")
        print(json.dumps({
            "name": name,
            "snapshot": str(run_path.relative_to(BASE)),
            "status": run.get("status"),
            "conclusion": run.get("conclusion"),
            "head_sha": run.get("head_sha"),
            "attempt": run.get("run_attempt"),
            "jobs_total": jobs.get("total_count"),
            "jobs": [
                {
                    "id": row["id"],
                    "name": row["name"],
                    "status": row["status"],
                    "conclusion": row["conclusion"],
                    "active_steps": [
                        item["name"]
                        for item in row.get("steps", [])
                        if item["status"] == "in_progress"
                    ],
                }
                for row in jobs.get("jobs", [])
            ],
            "artifact_count": artifacts.get("total_count"),
        }, separators=(",", ":")), flush=True)
        if jobs.get("total_count", 0) > len(jobs.get("jobs", [])):
            raise RuntimeError("Job pagination required; do not assume completeness")
        if artifacts.get("total_count", 0) > len(artifacts.get("artifacts", [])):
            raise RuntimeError("Artifact pagination required; do not assume completeness")
    return results


def download():
    tasks = []
    for name, rid in CONTEXT["runs"].items():
        _, run = latest(name, "run")
        _, jobs = latest(name, "jobs")
        _, artifacts = latest(name, "artifacts")
        if run["id"] != rid or run["head_sha"] != EXPECTED:
            raise RuntimeError(f"Exact run/head mismatch: {name}")
        attempt = run["run_attempt"]
        label = f"{name}-attempt{attempt}-logs"
        destination = f"originals/{label}.zip"
        if run["status"] == "completed" and not (BASE / destination).exists():
            tasks.append((
                label,
                f"repos/{REPO}/actions/runs/{rid}/attempts/{attempt}/logs",
                destination,
                90,
            ))
        if run["status"] != "completed":
            for job in jobs.get("jobs", []):
                if job["status"] != "completed" or job["conclusion"] == "skipped":
                    continue
                label = f"{name}-job-{job['id']}-logs"
                destination = f"originals/{label}.txt"
                if not (BASE / destination).exists():
                    tasks.append((
                        label,
                        f"repos/{REPO}/actions/jobs/{job['id']}/logs",
                        destination,
                        60,
                    ))
        for artifact in artifacts.get("artifacts", []):
            aid = artifact["id"]
            if artifact.get("workflow_run", {}).get("head_sha") != EXPECTED:
                raise RuntimeError(f"Artifact head mismatch: {aid}")
            if artifact.get("workflow_run", {}).get("id") != rid:
                raise RuntimeError(f"Artifact run mismatch: {aid}")
            if artifact.get("expired"):
                continue
            for kind, suffix, extension in (
                ("metadata", "", "json"),
                ("archive", "/zip", "zip"),
            ):
                label = f"{name}-artifact-{aid}-{kind}"
                destination = f"originals/{label}.{extension}"
                if not (BASE / destination).exists():
                    tasks.append((
                        label,
                        f"repos/{REPO}/actions/artifacts/{aid}{suffix}",
                        destination,
                        90 if extension == "zip" else 45,
                    ))
    return parallel(tasks)


def inspect_zips(label):
    archives = []
    for path in sorted((BASE / "originals").glob("*.zip")):
        row = {
            "path": str(path.relative_to(BASE)),
            "bytes": path.stat().st_size,
            "sha256": sha(path),
            "valid_zip": False,
            "members": [],
        }
        try:
            with zipfile.ZipFile(path) as archive:
                names = set()
                for info in archive.infolist():
                    if info.is_dir():
                        continue
                    if info.filename in names:
                        raise ValueError("Duplicate ZIP member")
                    names.add(info.filename)
                    content = archive.read(info)
                    row["members"].append({
                        "path": info.filename,
                        "bytes": len(content),
                        "sha256": hashlib.sha256(content).hexdigest(),
                    })
                row["valid_zip"] = True
                row["crc_status"] = "all_members_read_and_checked"
                row["member_count"] = len(row["members"])
        except Exception as error:
            row["error"] = f"{type(error).__name__}: {error}"
        archives.append(row)
        print(json.dumps({key: value for key, value in row.items() if key != "members"},
                         separators=(",", ":")), flush=True)
    write_new(BASE / f"zip-manifests-{label}.json", {
        "generated_at": now(), "archives": archives,
    })


def main():
    parser = argparse.ArgumentParser()
    commands = parser.add_subparsers(dest="action", required=True)
    snap = commands.add_parser("snapshot")
    snap.add_argument("--prefix", required=True)
    snap.add_argument("--runs", nargs="+", default=list(CONTEXT["runs"]))
    commands.add_parser("download")
    inspect = commands.add_parser("inspect")
    inspect.add_argument("--label", required=True)
    args = parser.parse_args()
    if args.action == "snapshot":
        snapshot(args.prefix, args.runs)
    elif args.action == "download":
        download()
    elif args.action == "inspect":
        inspect_zips(args.label)


if __name__ == "__main__":
    main()
