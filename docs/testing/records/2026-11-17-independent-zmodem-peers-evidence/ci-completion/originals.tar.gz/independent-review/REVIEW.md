**结论：限定批准（APPROVE，旧工程 CI 原件与三个指定运行）。P0 = 0，P1 = 0，P2 = 0，P3 = 0。**

复核日期：2026-11-17（Asia/Shanghai）。本复核由本次新接手的非作者独立完成，仅签署 `de9768c183c22f1051baabd529600667697247a1` 对应的 Quality `44013808155`、Windows monitor API `44013808184`、Windows OpenSSH `44013808220` 这三个 CI 运行的保存原件及下述精确范围。建议接纳这份 CI 终态证据，接续原件归档；新本地转发 candidate 769、父级完整 gate、原生桌面、发行与完整产品验收均不在签署范围。无须等待父级 gate。

工作目录是 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`。输入目录为 `work/zmodem-peer-ci-completion-20261117/`，以下简称 `E/`；本报告所在目录为 `work/zmodem-peer-ci-review-20261117/`，以下简称 `R/`。所有新增文件均在 `R/`；未对受控文件或 target 发起写操作，未执行网络、GUI、Cargo、项目测试、提交、推送或清理命令，未读取 target。原 ZIP、API 和 623 成员源码证据归档均就地读取，未复制完整大原件。

**独立性与离线检查结果。**

独立脚本为 [review.py](review.py)，仅使用 Python 标准库和只读 Git 对象命令。未执行、导入或复用作者的 `collect.py`、`build_report.py`、`originals/source-summary-parser.py` 或项目 parser。作者脚本只作为文件清单中的字节输入计算摘要；保存的旧 parser 只与指定 Git blob 比较原字节。首先自行计算原 ZIP、JSON、日志和源码绑定，再比较作者 `report.json`、`handoff.json`、`originals-list.json`、`files-manifest.json`、`zip-manifests-final.json`、`verification.json` 的对应声明。

最终完整执行为 `attempt-3`：exit 0，stderr 0 字节，约 0.272 秒；**5,091 / 5,091 项离线断言通过，失败 0**。检查包含 152 个不同标签的 JSON 文档解析、765 项工程输入逐项绑定、302 个 libtest 结果块、156 个 ZIP 成员和采集回执等。断言数是审查脚本中的结构、计数、摘要、来源及终态检查数，不是新增产品测试数；不累计前两次脚本适配执行中的重复检查。逐项断言位于 [checks.jsonl](checks.jsonl)，每行一项，汇总位于 [results.json](results.json)。

| 检查类别 | 断言数 |
| --- | ---: |
| 765 输入的长度／SHA-256、manifest aggregate、Git blob 对象标识与两个归档结构／来源检查 | 2,301 |
| 每个 libtest 块的声明／逐名行数／名称唯一性／状态汇总／成功终态 | 1,510 |
| ZIP 文件及全部成员的 CRC、长度、摘要、清单、artifact digest／身份／列表 | 346 |
| Collector 输出、自然退出／回收字段、时间字段、只读命令、首次失败、成功重取一致性 | 338 |
| 原文件清单与 originals-list 的完整性及逐项字节摘要 | 359 |
| run／job／step API 与时间线、checkout 日志 | 96 |
| Quality 汇总、macOS／Linux OpenSSH | 18 |
| Windows 命令来源／direct API／SSH 原对象与终态 | 102 |
| 四份精确源码副本与报告对照、复核 Git 命令退出、原件不变 | 21 |
| **总计** | **5,091** |

**三 run 的自然成功与精确来源。**

三个最终保存的 run API 均为 `completed/success`、`run_attempt=1`、`event=push`、同一 `head_sha=de9768c183c22f1051baabd529600667697247a1`。11 份 run 快照中，Quality 的 obs01–obs06 均是原 attempt 1 的 `in_progress`，obs07 为 `completed/success`；另两 run 在 obs01 和 obs07 均已成功。未将人工 rerun、重试 attempt 或取消改写为自然成功。

| 运行 | run ID | 最终 API updated_at（UTC） | 最终 job |
| --- | ---: | --- | --- |
| Quality | 44013808155 | 2026-11-17 04:25:10 | Windows 133806808619、macOS 133806809036、Ubuntu 133806809062 均 success |
| Windows monitor API | 44013808184 | 2026-11-17 03:59:46 | 133806808607 success；133806810226 **skipped** |
| Windows OpenSSH | 44013808220 | 2026-11-17 03:59:59 | 133806808315 success |

精确证据：`E/originals/obs07-{quality,windows_monitor,windows_ssh}-run.json:1` 的 `/id`、`/head_sha`、`/run_attempt`、`/event`、`/status`、`/conclusion`；对应 `*-jobs.json:1` 的 `/jobs/*/{run_id,head_sha,run_attempt,status,conclusion,steps}`。三平台及另两个工作流合计五份 checkout step 日志均包含该完整提交 SHA。

Windows monitor 的 `133806810226` 名称为 `Isolated OpenSSH prerequisites (HOLD until terminal proof)`，保存的真实状态为 `completed/skipped`、无 steps；原 direct API artifact 的 `receipt.json` 同时保持 `ssh=UNRUN`、`native_gui=UNRUN`。独立 Windows OpenSSH 工作流成功不抹掉这项 skipped，也不把 API 运行改签为 SSH。

作者原采集时的 `initial-head.txt` 和 `final-head.txt` 实际均为 `660645fbe77cee2b8af2740f3277a70e9f968048`；`final-tracked-status.txt` 和 `final-tracked-diff.txt` 保留并发开发改动。它们没有被当作旧 CI 来源。本复核不把当下 HEAD、正在开发的 769 输入、这些工作树差异或当前本地测试二进制绑定给 `de9768c`。

**三平台普通 Rust、rustdoc 与 Python。**

从 `quality-attempt1-logs.zip` 的三个 `native (<platform>)/8_Rust quality gate.txt` 原始成员自行逐行解析。每个 `running N tests` 块独立核对：实际逐名结果行数量、同套件内名称唯一性、逐名状态数量、汇总中的 passed/failed/ignored/measured 和声明 N。每个平台恰好 94 个普通 suite；每个平台的 6 个 rustdoc 子运行另计。未声称取得普通 suite 的独立 `--list` 库存；这里的逐名一致性是运行日志内的逐名结果与声明及汇总一致。

| 平台 | 普通 Rust passed / failed / ignored | 普通 suite／逐名行 | rustdoc passed / failed / ignored | Python 主 run / skip / outcome |
| --- | --- | --- | --- | --- |
| Windows 2025 | 3406 / 0 / 60 | 94 / 3466 | 14 / 0 / 0 | 523 / 50 / OK |
| macOS 26 | 3419 / 0 / 62 | 94 / 3481 | 14 / 0 / 0 | 523 / 3 / OK |
| Ubuntu 24.04 | 3412 / 0 / 63 | 94 / 3475 | 14 / 0 / 0 | 523 / 3 / OK |

Python 的 523 是执行总数，包含 skipped；分别对应 473、520、520 个非 skipped 成功项。macOS 和 Ubuntu 普通 Rust 内嵌的独立 Python 子输出各为 `Ran 30 tests` / `OK`，未再次加入 Python 主 523；Windows 未出现这段内嵌输出。包装测试处于独立 step，未混入主 Python 计数。普通 Rust 总计 10,422 个逐名结果行，三个平台各 14 个 rustdoc 合计 42 个，另有后述 OpenSSH 36 个逐名结果；没有执行任何一个测试。

精确 ZIP 成员行号如下，行号对应成员原文，未删去 ANSI／时间戳行；脚本仅在逐行匹配时去除其前缀。

| 平台成员前缀 | 普通 Rust 首个 running 至最后摘要 | rustdoc 首个 running 至最后摘要 | Python 主摘要／终态 |
| --- | --- | --- | --- |
| `native (windows-2025)/8_Rust quality gate.txt` | 60–4813 | 4817–4865 | 23、25 |
| `native (macos-26)/8_Rust quality gate.txt` | 62–4872 | 4876–4924 | 21、23 |
| `native (ubuntu-24.04)/8_Rust quality gate.txt` | 58–4865 | 4868–4916 | 22、24 |

Ubuntu 原文第 4861 行的 `Doc-tests keelshell_ai` 标题先于普通 Zmodem suite 的最后两项及第 4865 行摘要到达。脚本保留当前活动 suite，直到该摘要结束，再将下一 `running` 绑定到待处理 doc 标题。该交错没有误计入 doc 或遗漏普通 suite。所有 300 个 Quality 结果块及每个套件的名称／状态摘要、原文行号保存在 [suites-recomputed.json](suites-recomputed.json)；主计数断言见 `checks.jsonl:3950–3953`、`:4455–4458`、`:4960–4963`。

**macOS／Linux 真实 OpenSSH。**

两份 Quality artifact 中的原 `tests.log` 均有 18 个唯一测试名，声明 18、摘要 18 passed / 0 failed / 0 ignored，逐名一致。两个平台的名称／结果规范化摘要均为 `46b6dd264eb974d5701c7b8d095af3caf8dfd82753d945480d261693fc766bdc`。

| 平台 | artifact | result／tests 原成员 |
| --- | ---: | --- |
| Linux | 14298698102 | `20261117T042232Z-f15e0aac17/result.json`；同目录 `tests.log:6–26` |
| Darwin | 14299297187 | `20261117T042445Z-3bca4a331b/result.json`；同目录 `tests.log:6–26` |

原 result 的 `passed_tests=18`、`outcome=passed` 与日志复算相同，5 个命令 step 的 returncode 均 0；清理字段显示 observed／owned processes stopped、temporary directory removed，`ancestry_unverified=[]`。保留原件对累计 ancestry 观察和 kernel birth identity 的边界说明；不由这些字段推定观察间隙中任意脱离后代都已证明回收。该场景是 disposable localhost OpenSSH transport interop，未扩大为产品原生桌面验收。

**7 个 ZIP、156 成员、4 个 GitHub artifact digest。**

全部 ZIP 就地读出每一个成员；同时使用 ZIP 库验证和独立 `binascii.crc32` 计算，逐成员核对解压长度、SHA-256、CRC32、唯一名称及最终作者清单。7 个原 ZIP 共 156 个成员，全部一致。4 个 artifact 的 ZIP SHA-256 与保存的 GitHub metadata `/digest`、`/size_in_bytes`、最终 artifacts list、`/workflow_run/{id,head_sha}` 全部一致。三个 run logs ZIP 没有 GitHub artifact digest 字段，只签其原 ZIP／回执／清单摘要及 CRC。

| 原 ZIP 文件名（位于 E/originals/） | 字节数 | 成员 | 独立 SHA-256 |
| --- | ---: | ---: | --- |
| quality-attempt1-logs.zip | 1022192 | 38 | `fe3492b3e06709f21cbbc47879c8a6d7c51afd1aa4d9b99f6d94f5eb3ac55fc5` |
| quality-artifact-14298698102-archive.zip | 2949 | 7 | `a35224434805e8fc0751e21118aa3f09513ac5c2d485b82a510d80e4571473d5` |
| quality-artifact-14299297187-archive.zip | 3020 | 7 | `e3ceeafa607b3d8984d3333e8fcedf262b024acf06680de64aed66fa29d48b2e` |
| windows_monitor-attempt1-logs.zip | 31964 | 12 | `7a0c9c0f7c01ae25bad4312eda6b191a58c959e6ed875e099796ba0a8e24078d` |
| windows_monitor-artifact-14297134286-archive.zip | 46759 | 34 | `b4bbfd8b1dad5c422d828838a62967ddf3d8bc4643bfb134ac5fe63c0be260ec` |
| windows_ssh-attempt1-logs.zip | 32063 | 12 | `6ef7b34d28ab7313fcb422505386fb8243e0e49637968951ffe23ffa92af6923` |
| windows_ssh-artifact-14297682987-archive.zip | 54124 | 46 | `57137eb39a25f0fd7887ec7ccbe09f1901e7f68f09f98fc8d88b64d363528920` |

逐成员复算见 [zip-recomputed.json](zip-recomputed.json)；4 项 digest 断言见 `checks.jsonl:810`、`:829`、`:981`、`:1105`，完整 ZIP 总量见 `:1134`。

**Collector 56 命令、失败保留与回收证据。**

独立枚举 56 个 stdout payload、56 个 stderr、56 份 request receipt，验证每份回执所指输出的长度及 SHA-256，并检查 originals-list 与整个文件清单的路径集合和摘要。作者目录共 186 个文件，4,238,107 逻辑字节；其中 files-manifest 正文列举其余 185 文件、4,206,116 字节，自身明确排除。所有路径集合及摘要一致，最终与本复核首次快照逐项一致。

56 份回执均记录 `reaped=true`、`timed_out=false`、非负 exit_code；55 份 exit 0，1 份 exit 1，唯一非零就是首次转义下载保护失败。44 份还记录 `signals=[]`、timeout budget 和 finished_at；12 份早期格式没有这三个可选字段。本复核没有补造缺失字段：这 12 份的终态依据限于所存 exit_code、timed_out、reaped 和 duration，不声称它们原本具有显式 signals／timeout budget／finished_at。具体列表保存在 `results.json` 的 `/collector/legacy_receipts_without_optional_signal_budget_finish_fields`。

首次失败的精确原件是：

- `E/receipts/quality-job-133806809062-logs.json`：exit 1，reaped true，timed_out false，signals 空，stdout 0 字节。
- `E/receipts/quality-job-133806809062-logs.stderr:1`：99 字节，说明 response contains terminal escape sequences 并要求 `--allow-escape-sequences`。
- `E/originals/quality-job-133806809062-logs.txt`：保持 0 字节。
- 新文件 `E/originals/quality-job-133806809062-logs-retry2.txt`：901,506 字节，独立 SHA-256 `d8d5e60602f1de25074b4f7f2a47cc380e5234f075c4c15c7403864014c59b12`，与最终 Quality ZIP 中 `1_native (ubuntu-24.04).txt` **逐字节相等**；对应 retry2 回执自然 exit 0／reaped，参数新增 `--allow-escape-sequences`。

56 份保存命令均是 Git 只读查询或 `gh api --method GET`；本次把它们作为 JSON 数据检查，没有执行这些旧命令。没有将初次下载失败当作 CI job 失败，也没有用 retry2 覆盖初次原件。`report-obs06.json` 的早期 Python 计数歧义原件继续保留，最终复算明确隔开主 523 与内嵌 30。

**765 工程输入和旧 Git 提交的绑定。**

唯一输入清单来源是 `docs/testing/records/2026-11-17-independent-zmodem-peers-evidence/originals.tar.gz#parent/candidate-inputs-r7.json`。623 个归档成员名称唯一；该归档的当前保存原字节与 `de9768c183c22f1051baabd529600667697247a1:<同一归档路径>` 的 Git blob **逐字节相等**，SHA-256 为 `9eca3013dbd8424c0f2fa2613a0d7aae58df24d6267e40848d8a8bb45154c888`。所读 manifest 成员本身 SHA-256 为 `6de10fcfc063f144d368d7b0bc031c9a80c3a4967cf93a64cb50a32d7cacfbed`。

manifest `/inputs` 有 765 个唯一相对路径。使用带 `GIT_NO_LAZY_FETCH=1` 的 `git --no-optional-locks --no-replace-objects cat-file --batch` 一次读出所有精确 `de9768c:path` 的完整 blob 字节，逐项计算长度、SHA-256，并以 Git blob header + 内容复算 SHA-1 对象 ID。765 项长度及 SHA-256 全部匹配 manifest。它与对每个路径执行 `git show de9768c:path` 读取相同 blob；没有从当前源码目录读取这 765 项来作绑定。

manifest 只保存长度／SHA-256，没有存每个源码文件的明文字节。本结论是读取每个指定 Git blob 完整字节后，与封存 r7 指纹逐项相等；不把清单误说成一份已展开的 765 文件明文快照。规范化 `json.dumps(inputs, sort_keys=True, separators=(',', ':')).encode()` 的独立 aggregate 为：

`7ae00377c1eb95929710c7d8170d444ea293f8c27a3c8690cb83aa79bde3ede6`

另用 4 次精确 `git show`，逐字节比较保存的三份 workflow 和一份旧 summary parser 与其指定 Git blob，均相同。清单与比较结果见 [source-recomputed.json](source-recomputed.json)；aggregate／623 成员／归档 Git 绑定分别见 `checks.jsonl:1138`、`:1136`、`:3437`。

**Windows 原对象终态与命令来源的补充核对。**

direct API artifact 的 5 个 PowerShell collector 和 fixture 共 6 个 child 回执均记录 observed exit 0、direct reaped、active processes 0、pipes drained、无 errors、身份绑定及 pending original objects 0；逐份 child 与独立 receipt 相等，stdout／stderr 长度相等。

从精确旧 Git blobs 中读取 `common.ps1` 及各 operation 的 `.ps1` 完整字节，独立核对 assembly 中每个 part 的 SHA-256，用原 prefix／suffix 拼装，计算 UTF-16LE + base64 的完整 PowerShell wire command。5 组 `probe/resources/processes/sockets/resources-skipped` 的 script SHA-256、wire SHA-256、长度、direct wire 原字节及实际 shell argv 均一致；direct 与 SSH artifact 的 5 份 assembly 原字节也一致。四个 SSH operation 还分别核对原始 PowerShell 进程 command_line 中的 EncodedCommand 与重建值、wire digest、pid／creation_time 绑定，均一致。只重建数据，未运行 PowerShell。

Windows SSH artifact `14297682987` 内：

- `source-head.stdout` 是精确 `de9768c`，`source-status.stdout` 空；`test-binary.json` 的单项 inventory、`live-test-inventory.stdout` 与 rust-client 实际测试名相等。
- `ssh-debug-originals.json` 保存 **21** 个唯一 `(pid, creation_time)` 原对象和完整 census；清理前状态 **HOLD**、job active **1**、仅 master PID 880 存活，pending **1**。20 个非 master 均在清理前自然终态并收到／继续 exit event；它们并非全部 exit 0，平台探测等原非零码按原件保留。
- 其中四个 PowerShell 原对象自然 exit 0：probe PID 8220、resources PID 8400、processes PID 676、sockets PID 6232。四个 `ssh-production-binding.json` operation 的身份分别匹配这些原对象和重建命令。
- `ssh-debug-cleanup.json` 的原对象集合仍是同一 21 个，最终 **PASS**、terminal proven true，job active／pending objects／owned handles 均 **0**，debug connections／fallback detaches 均 **0**，received／continued debug events 均 **1353**，closed true、errors 空。master 清理退出码 **125**，natural_terminal_before_cleanup false；没有把它改写为自然成功。
- `ssh-cleanup.json` 的 temporary directory removed true、private config uploaded false、keys uploaded false；Rust 原结果包含 22 项 passed assertion，native_gui 仍 **UNRUN**。

这里核对的是保存的身份、回执、命令字节和终态链。没有重新执行 Windows 或重新实现／签署全部业务指标算法。Windows direct 的独立 API 数值比较及 Rust 断言结果保留原运行事实，不能扩大为本次重新运行或新的业务验收。

**执行命令与复核过程留痕。**

可复现的最终离线命令（仅在本 review 目录写结果）：

```sh
python3 -B work/zmodem-peer-ci-review-20261117/review.py
```

最终成功执行的 5 个 Git 子进程精确 argv、退出、输出摘要与回收记录在 [git-commands.json](git-commands.json)：1 次 `cat-file --batch`，4 次 `show`；均 exit 0／reaped，设置 `GIT_NO_LAZY_FETCH=1` 防止缺对象时自动联网。所有查询都绑定上述完整旧 SHA。

本次共 20 次 shell 工具命令调用，其中 3 次运行自有离线复核脚本，其余为读取约束／记忆／原件结构、查看自有结果及最终交付检查。前两次脚本执行不会执行项目代码：attempt-1 因 12 份早期回执缺可选 signals 字段触发本复核脚本 KeyError，exit 1；attempt-2 的 5,061 项检查有 4 项命令分类假阴性，原因是本复核脚本未跳过 Git 的 `--no-optional-locks` 全局选项，exit 1。相关 stdout／stderr 原样留在 R/；适配脚本后 attempt-3 最终通过 5,091 项。它们是本复核器的适配记录，不是 CI 失败或产品测试重跑。两次完整脚本累计执行 10 个只读 Git 子进程，均 exit 0／reaped；首个未完成脚本未执行 Git。

20 次 shell 命令与这些子进程分别计数；原采集 56 命令没有被再次执行。命令清单及最终交付检查见 [commands.json](commands.json)、[delivery-verification.json](delivery-verification.json)。网络调用 0、GUI 0、Cargo 0、项目测试重跑 0、target 访问 0、受控文件写操作 0、提交／推送 0。

**未验界限与建议。**

本次是保存原件的离线一致性复核，没有重新访问 GitHub，因此成功、attempt、artifact metadata 和 digest 的来源均是所存 API／ZIP／命令回执；不声称完成新的远端实时查询、服务器侧认证证明或独立操作系统进程观测。普通 Rust 的逐名核对限定于已执行结果，不声称完整独立 `--list`；没有运行缓存测试二进制或更改共享 target。未重新执行 peer 矩阵、Windows 原对象采集或全部指标算法。

原生 GUI、IME／辅助技术、安装覆盖、签名／公证、六目标发行、完整 FILE-05／M4 和完整产品均未签。独立 peer 的空文件／缺 OO 既有失败及 OPEN／HOLD、其他历史失败继续保留；这三个 run 的自然成功不关闭它们。Windows isolated preflight skipped、API ssh UNRUN、SSH 清理前 HOLD、master 清理 exit 125 和首次转义下载 exit 1 均在上述证据中明确保留。

建议仅接纳 `de9768c` 与三个指定 run 的本次限定 CI 原件复核结论。当前本地转发 candidate 769 和父级 gate 应使用各自冻结、原件与非作者复核，本报告不代签。可以直接归还本次复核结果，无需等待父级完整 gate。
