#!/usr/bin/env python3
"""Independent offline evidence review; never imports or runs project code."""

import base64
import binascii
import collections
import datetime
import hashlib
import io
import json
import os
import pathlib
import re
import subprocess
import sys
import tarfile
import time
import zipfile


OUT = pathlib.Path(__file__).resolve().parent
ROOT = OUT.parent.parent
EVIDENCE = ROOT / "work/zmodem-peer-ci-completion-20261117"
ARCHIVE = "docs/testing/records/2026-11-17-independent-zmodem-peers-evidence/originals.tar.gz"
HEAD = "de9768c183c22f1051baabd529600667697247a1"
RUNS = {"quality": 44013808155, "windows_monitor": 44013808184, "windows_ssh": 44013808220}
EXPECTED = {
    "windows-2025": (3406, 0, 60, 50),
    "macos-26": (3419, 0, 62, 3),
    "ubuntu-24.04": (3412, 0, 63, 3),
}
CHECKS = []
COMMANDS = []
JSON_DOCUMENTS = {}
START = time.monotonic()
ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
TIMESTAMP = re.compile(r"^\d{4}-\d\d-\d\dT\S+Z ?")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def check(category, subject, condition, detail=None):
    row = {"category": category, "subject": subject, "ok": bool(condition)}
    if detail is not None:
        row["detail"] = detail
    CHECKS.append(row)
    return bool(condition)


def pairs_unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def parse_json(data, label):
    obj = json.loads(data.decode("utf-8-sig"), object_pairs_hook=pairs_unique)
    JSON_DOCUMENTS[label] = digest(data)
    return obj


def load(relative):
    return parse_json((EVIDENCE / relative).read_bytes(), relative)


def save(name, data):
    # This is the only output location used by the reviewer.
    path = OUT / name
    if path.parent != OUT:
        raise ValueError("Review outputs must be direct children of the review directory")
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def snapshot():
    return [
        {"path": p.relative_to(EVIDENCE).as_posix(), "bytes": p.stat().st_size,
         "sha256": digest(p.read_bytes())}
        for p in sorted(EVIDENCE.rglob("*")) if p.is_file()
    ]


def git(arguments, data=None):
    argv = ["git", "--no-optional-locks", "--no-replace-objects", *arguments]
    env = dict(os.environ, GIT_OPTIONAL_LOCKS="0", GIT_NO_LAZY_FETCH="1", GIT_PAGER="cat")
    before = time.monotonic()
    cp = subprocess.run(argv, input=data, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                        cwd=ROOT, env=env, timeout=45, check=False)
    COMMANDS.append({
        "argv": argv, "exit_code": cp.returncode, "reaped": True,
        "duration_seconds": round(time.monotonic() - before, 6),
        "stdout_bytes": len(cp.stdout), "stdout_sha256": digest(cp.stdout),
        "stderr_bytes": len(cp.stderr), "stderr_sha256": digest(cp.stderr),
    })
    check("review_git", " ".join(arguments), cp.returncode == 0)
    if cp.returncode:
        raise RuntimeError(cp.stderr.decode(errors="replace"))
    return cp.stdout


def clean_lines(data):
    return [ANSI.sub("", TIMESTAMP.sub("", line))
            for line in data.decode("utf-8-sig").splitlines()]


def rust_suites(data, label):
    """Pair completed libtest blocks, retaining pending interleaved cargo headings."""
    lines = clean_lines(data)
    pending = None
    active = None
    suites = []
    name_pattern = re.compile(r"^test (.+) \.\.\. (ok|FAILED|ignored)(?:,.*)?$")
    summary_pattern = re.compile(
        r"^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; "
        r"(\d+) ignored; (\d+) measured; (\d+) filtered out;"
    )
    for number, line in enumerate(lines, 1):
        heading = re.match(r"^\s*(Running|Doc-tests)\s+(.+)$", line)
        if heading:
            pending = ("doc" if heading[1] == "Doc-tests" else "ordinary", heading[2])
        declaration = re.fullmatch(r"running (\d+) tests?", line)
        if declaration:
            if active is not None or pending is None:
                raise ValueError(f"Unpaired running declaration at {label}:{number}")
            active = {
                "kind": pending[0], "heading": pending[1], "start_line": number,
                "declared": int(declaration[1]), "names": [], "statuses": [],
            }
        result = name_pattern.fullmatch(line)
        if result and active is not None:
            active["names"].append(result[1])
            active["statuses"].append({"ok": "passed", "FAILED": "failed", "ignored": "ignored"}[result[2]])
        summary = summary_pattern.match(line)
        if summary:
            if active is None:
                raise ValueError(f"Summary without running declaration at {label}:{number}")
            counts = {k: int(v) for k, v in zip(
                ["passed", "failed", "ignored", "measured", "filtered_out"], summary.groups()[1:])}
            statuses = active.pop("statuses")
            observed = collections.Counter(statuses)
            names = active.pop("names")
            subject = f"{label}:{active['start_line']}-{number}"
            check("suite", subject + ":declared_vs_rows", active["declared"] == len(names))
            check("suite", subject + ":unique_names", len(set(names)) == len(names))
            check("suite", subject + ":rows_vs_summary",
                  all(observed[k] == counts[k] for k in ["passed", "failed", "ignored"]))
            check("suite", subject + ":declared_vs_summary",
                  active["declared"] == sum(counts[k] for k in ["passed", "failed", "ignored", "measured"]))
            check("suite", subject + ":successful_terminal",
                  summary[1] == "ok" and counts["failed"] == counts["measured"] == 0)
            active.update(
                end_line=number, counts=counts, observed=dict(observed),
                unique_names=len(set(names)),
                name_results_sha256=digest(json.dumps(
                    sorted(zip(names, statuses)), ensure_ascii=False, separators=(",", ":")).encode()),
            )
            suites.append(active)
            active = None
    if active is not None:
        raise ValueError(f"Unfinished libtest block: {label}:{active['start_line']}")
    python = []
    for number, line in enumerate(lines, 1):
        found = re.fullmatch(r"Ran (\d+) tests? in ([0-9.]+)s", line)
        if not found:
            continue
        terminal = next(((n + 1, lines[n]) for n in range(number, min(number + 5, len(lines)))
                         if re.fullmatch(r"OK(?: \(skipped=\d+\))?|FAILED.*", lines[n])), None)
        if terminal is None:
            raise ValueError(f"Missing unittest outcome at {label}:{number}")
        skipped = re.search(r"skipped=(\d+)", terminal[1])
        python.append({"run": int(found[1]), "skipped": int(skipped[1]) if skipped else 0,
                       "outcome": terminal[1], "start_line": number, "end_line": terminal[0]})
    return {"suites": suites, "python_blocks": python, "line_count": len(lines)}


def main():
    initial = snapshot()
    if (OUT / "input-snapshot.json").exists():
        check("immutability", "author_evidence_equal_first_review_snapshot",
              json.loads((OUT / "input-snapshot.json").read_bytes()) == initial)
    else:
        save("input-snapshot.json", initial)
    original_tar = (ROOT / ARCHIVE).read_bytes()
    result = {"exact_head": HEAD, "independent_parser": True, "product_tests_replayed": 0,
              "network_commands": 0, "gui_operations": 0, "cargo_commands": 0,
              "target_accesses": 0}

    # Hash every file ourselves; the author manifests are comparison data only.
    manifest = load("files-manifest.json")
    actual = {x["path"]: x for x in initial}
    check("file_manifest", "complete_path_set",
          set(actual) - {"files-manifest.json"} == {x["path"] for x in manifest["entries"]})
    check("file_manifest", "declared_count", manifest["count"] == len(manifest["entries"]) == 185)
    check("file_manifest", "logical_bytes",
          sum(actual[x["path"]]["bytes"] for x in manifest["entries"]) == manifest["logical_bytes"])
    for entry in manifest["entries"]:
        check("file_manifest", entry["path"], actual.get(entry["path"]) == entry)
    originals_list = load("originals-list.json")
    for key, folder, suffix in [("originals", "originals", None),
                                ("stderr_originals", "receipts", ".stderr"),
                                ("request_receipts", "receipts", ".json")]:
        entries = originals_list[key]
        paths = {e["path"] for e in entries}
        expected_paths = {p.relative_to(EVIDENCE).as_posix()
                          for p in (EVIDENCE / folder).iterdir()
                          if p.is_file() and (suffix is None or p.suffix == suffix)}
        check("originals_list", key + ":inventory", paths == expected_paths and len(entries) == 56)
        for entry in entries:
            check("originals_list", entry["path"], actual.get(entry["path"]) == entry)

    # Collector commands are evidence, never commands to replay.
    receipts = []
    for path in sorted((EVIDENCE / "receipts").glob("*.json")):
        relative = path.relative_to(EVIDENCE).as_posix()
        receipt = load(relative)
        out = (EVIDENCE / receipt["output"]).read_bytes()
        stderr = path.with_suffix(".stderr").read_bytes()
        check("collector", relative + ":bytes_hash",
              (len(out), digest(out)) == (receipt["bytes"], receipt["sha256"]))
        check("collector", relative + ":natural_reaped",
              receipt["reaped"] is True and receipt["timed_out"] is False
              and receipt["exit_code"] >= 0 and receipt.get("signals", []) == [])
        check("collector", relative + ":bounded_time",
              receipt["duration_seconds"] >= 0
              and ("timeout_seconds" not in receipt
                   or receipt["duration_seconds"] <= receipt["timeout_seconds"] + 1)
              and ("finished_at" not in receipt
                   or datetime.datetime.fromisoformat(receipt["finished_at"])
                   >= datetime.datetime.fromisoformat(receipt["started_at"])))
        argv = receipt["argv"]
        git_args = [v for v in argv[1:] if v != "--no-optional-locks"]
        allowed = (argv[:2] == ["gh", "api"] and "--method" in argv
                   and argv[argv.index("--method") + 1] == "GET") or (
                       argv[0] == "git" and git_args[0] in {"show", "rev-parse", "status", "diff"})
        check("collector", relative + ":read_only_command", allowed)
        failed_download = path.name == "quality-job-133806809062-logs.json"
        check("collector", relative + ":expected_exit",
              receipt["exit_code"] == (1 if failed_download else 0))
        if failed_download:
            check("collector", relative + ":preserved_first_failure",
                  not out and b"terminal escape sequences" in stderr
                  and "--allow-escape-sequences" not in argv)
        else:
            check("collector", relative + ":empty_stderr", not stderr)
        receipts.append({**receipt, "receipt": relative, "stderr_bytes": len(stderr)})
    check("collector", "56_unique_receipts_outputs",
          len(receipts) == len({x["output"] for x in receipts}) == 56)
    result["collector"] = {
        "count": len(receipts), "natural_reaped": sum(x["reaped"] and not x["timed_out"]
                                                    and not x.get("signals", []) for x in receipts),
        "exit_zero": sum(x["exit_code"] == 0 for x in receipts),
        "exit_nonzero": [x["receipt"] for x in receipts if x["exit_code"] != 0],
        "explicit_signal_and_timeout_budget_fields": sum("signals" in x and "timeout_seconds" in x
                                                        for x in receipts),
        "legacy_receipts_without_optional_signal_budget_finish_fields": [
            x["receipt"] for x in receipts if "signals" not in x],
    }
    save("collector-recomputed.json", receipts)

    # Independently inspect final and earlier raw API snapshots.
    result["runs"] = {}
    timeline = []
    for key, run_id in RUNS.items():
        for path in sorted((EVIDENCE / "originals").glob(f"obs*-{key}-run.json")):
            raw = load(path.relative_to(EVIDENCE).as_posix())
            check("api_timeline", path.name,
                  raw["id"] == run_id and raw["head_sha"] == HEAD
                  and raw["run_attempt"] == 1 and raw["event"] == "push"
                  and raw["status"] in {"in_progress", "completed"}
                  and raw["conclusion"] in {None, "success"})
            timeline.append({"file": path.name, "status": raw["status"],
                             "conclusion": raw["conclusion"], "attempt": raw["run_attempt"]})
        raw = load(f"originals/obs07-{key}-run.json")
        jobs = load(f"originals/obs07-{key}-jobs.json")
        artifacts = load(f"originals/obs07-{key}-artifacts.json")
        check("api_final", key + ":run", raw["status"] == "completed" and raw["conclusion"] == "success")
        check("api_final", key + ":job_count", jobs["total_count"] == len(jobs["jobs"]))
        job_results = []
        for job in jobs["jobs"]:
            subject = f"{key}:job:{job['id']}"
            check("api_job", subject + ":identity",
                  job["run_id"] == run_id and job["head_sha"] == HEAD and job["run_attempt"] == 1)
            skipped = job["id"] == 133806810226
            check("api_job", subject + ":terminal",
                  job["status"] == "completed" and job["conclusion"] == ("skipped" if skipped else "success"))
            for step in job["steps"]:
                check("api_step", subject + ":" + str(step["number"]),
                      step["status"] == "completed" and step["conclusion"] in {"success", "skipped"})
            job_results.append({"id": job["id"], "name": job["name"], "conclusion": job["conclusion"],
                                "skipped_steps": [s["name"] for s in job["steps"] if s["conclusion"] == "skipped"]})
        result["runs"][key] = {
            "id": run_id, "head_sha": raw["head_sha"], "attempt": raw["run_attempt"],
            "status": raw["status"], "conclusion": raw["conclusion"],
            "updated_at": raw["updated_at"], "jobs": job_results,
        }
        check("artifact_list", key + ":count",
              artifacts["total_count"] == len(artifacts["artifacts"]) == (2 if key == "quality" else 1))
    result["timeline"] = timeline

    # Read all ZIP members, explicitly recompute CRC32, hashes and artifact digests.
    zip_claims = load("zip-manifests-final.json")
    claims = {row["path"]: row for row in zip_claims["archives"]}
    check("zip", "complete_zip_inventory",
          set(claims) == {p.relative_to(EVIDENCE).as_posix() for p in (EVIDENCE / "originals").glob("*.zip")})
    zips = []
    payloads = {}
    for path in sorted((EVIDENCE / "originals").glob("*.zip")):
        relative = path.relative_to(EVIDENCE).as_posix()
        claim = claims[relative]
        raw_zip = path.read_bytes()
        members = []
        payload = {}
        with zipfile.ZipFile(io.BytesIO(raw_zip)) as zf:
            names = [i.filename for i in zf.infolist()]
            check("zip", relative + ":unique_safe_names",
                  len(names) == len(set(names)) and all(
                      not pathlib.PurePosixPath(n).is_absolute()
                      and ".." not in pathlib.PurePosixPath(n).parts for n in names))
            claimed_members = {m["path"]: m for m in claim["members"]}
            check("zip", relative + ":member_inventory",
                  set(names) == set(claimed_members) and len(names) == claim["member_count"])
            for info in zf.infolist():
                data = zf.read(info)  # zipfile's CRC validation, followed by our own CRC computation.
                crc = binascii.crc32(data) & 0xffffffff
                row = {"path": info.filename, "bytes": len(data), "sha256": digest(data)}
                check("zip_member", relative + "#" + info.filename + ":crc_size",
                      crc == info.CRC and len(data) == info.file_size)
                check("zip_member", relative + "#" + info.filename + ":manifest",
                      row == claimed_members.get(info.filename))
                members.append({**row, "crc32": f"{crc:08x}"})
                payload[info.filename] = data
                if info.filename.endswith(".json"):
                    parse_json(data, relative + "#" + info.filename)
        check("zip", relative + ":archive_hash_size",
              (len(raw_zip), digest(raw_zip)) == (claim["bytes"], claim["sha256"]))
        row = {"path": relative, "bytes": len(raw_zip), "sha256": digest(raw_zip),
               "member_count": len(members), "members": members}
        if "-artifact-" in path.name:
            meta_name = relative.replace("-archive.zip", "-metadata.json")
            meta = load(meta_name)
            key = path.name.split("-artifact-")[0]
            final_list = load(f"originals/obs07-{key}-artifacts.json")
            listed = [x for x in final_list["artifacts"] if x["id"] == meta["id"]]
            check("artifact_digest", relative,
                  meta["digest"] == "sha256:" + digest(raw_zip) and meta["size_in_bytes"] == len(raw_zip))
            check("artifact_identity", relative,
                  meta["workflow_run"]["head_sha"] == HEAD
                  and meta["workflow_run"]["id"] == RUNS[key] and meta["expired"] is False
                  and listed == [meta])
            row["github_digest"] = meta["digest"]
            row["artifact_id"] = meta["id"]
        zips.append(row)
        payloads[path.name] = payload
    check("zip", "7_archives_156_members",
          len(zips) == 7 and sum(x["member_count"] for x in zips) == 156)
    result["zip_count"] = len(zips)
    result["zip_members"] = sum(x["member_count"] for x in zips)
    result["artifact_digests"] = sum("github_digest" in x for x in zips)
    save("zip-recomputed.json", zips)
    quality = payloads["quality-attempt1-logs.zip"]
    retry = (EVIDENCE / "originals/quality-job-133806809062-logs-retry2.txt").read_bytes()
    check("collector", "ubuntu_retry_equals_final_whole_job_zip_member",
          retry == quality["1_native (ubuntu-24.04).txt"])

    # Resolve the archived manifest, and every source blob, from the exact old commit.
    with tarfile.open(fileobj=io.BytesIO(original_tar), mode="r:gz") as tf:
        members = tf.getmembers()
        check("source_archive", "623_unique_members", len(members) == len({m.name for m in members}) == 623)
        manifest_bytes = tf.extractfile("parent/candidate-inputs-r7.json").read()
        frozen = parse_json(manifest_bytes, ARCHIVE + "#parent/candidate-inputs-r7.json")
    inputs = frozen["inputs"]
    check("source", "765_unique_safe_inputs",
          len(inputs) == frozen["count"] == len({e["path"] for e in inputs}) == 765
          and all(not pathlib.PurePosixPath(e["path"]).is_absolute()
                  and ".." not in pathlib.PurePosixPath(e["path"]).parts for e in inputs))
    canonical = json.dumps(inputs, sort_keys=True, separators=(",", ":")).encode()
    check("source", "r7_aggregate",
          digest(canonical) == frozen["aggregate_sha256"]
          == "7ae00377c1eb95929710c7d8170d444ea293f8c27a3c8690cb83aa79bde3ede6")
    paths = [e["path"] for e in inputs] + [ARCHIVE]
    # cat-file reads exactly the same blob bytes as `git show de9768c:path`.
    data = git(["cat-file", "--batch"], "".join(f"{HEAD}:{p}\n" for p in paths).encode())
    stream = io.BytesIO(data)
    blobs = {}
    source_rows = []
    for path in paths:
        header = stream.readline().decode().strip().split()
        if len(header) != 3 or header[1] != "blob":
            raise ValueError(f"Missing exact-commit blob: {path}: {header}")
        oid, _, size = header
        blob = stream.read(int(size))
        if stream.read(1) != b"\n":
            raise ValueError(f"Malformed cat-file batch response: {path}")
        check("git_blob", path,
              hashlib.sha1(b"blob " + str(len(blob)).encode() + b"\0" + blob).hexdigest() == oid)
        blobs[path] = blob
    check("git_blob", "batch_fully_consumed", stream.read() == b"")
    for entry in inputs:
        blob = blobs[entry["path"]]
        check("source", entry["path"] + ":byte_count", len(blob) == entry["bytes"])
        check("source", entry["path"] + ":sha256", digest(blob) == entry["sha256"])
        source_rows.append({"path": entry["path"], "bytes": len(blob), "sha256": digest(blob)})
    check("source_archive", "local_archive_equals_exact_commit_blob", blobs[ARCHIVE] == original_tar)
    for path in sorted((EVIDENCE / "receipts").glob("exact-source-*.json")):
        receipt = load(path.relative_to(EVIDENCE).as_posix())
        spec = receipt["argv"][2]
        check("exact_source", path.name + ":pinned_head", spec.startswith(HEAD + ":"))
        blob = git(["show", spec])
        check("exact_source", receipt["output"],
              blob == (EVIDENCE / receipt["output"]).read_bytes())
    result["source"] = {"input_count": len(source_rows), "input_aggregate": digest(canonical),
                        "archive_members": len(members), "archive_sha256": digest(original_tar),
                        "manifest_member_sha256": digest(manifest_bytes),
                        "binding": "all 765 exact-commit blob bytes hashed and sized against archived r7 manifest",
                        "current_checkout_used_as_ci_source": False}
    save("source-recomputed.json", {"summary": result["source"], "inputs": source_rows})

    # Cargo headings may precede the previous suite's final stdout; preserve active blocks.
    result["platforms"] = []
    suites_result = {}
    for platform, expected in EXPECTED.items():
        member = f"native ({platform})/8_Rust quality gate.txt"
        parsed = rust_suites(quality[member], "quality-attempt1-logs.zip#" + member)
        ordinary = [x for x in parsed["suites"] if x["kind"] == "ordinary"]
        docs = [x for x in parsed["suites"] if x["kind"] == "doc"]
        totals = {k: sum(x["counts"][k] for x in ordinary) for k in ["passed", "failed", "ignored"]}
        doc_totals = {k: sum(x["counts"][k] for x in docs) for k in ["passed", "failed", "ignored"]}
        check("quality_totals", platform + ":ordinary",
              tuple(totals.values()) == expected[:3] and len(ordinary) == 94)
        check("quality_totals", platform + ":rustdoc",
              doc_totals == {"passed": 14, "failed": 0, "ignored": 0} and len(docs) == 6)
        main_python = [p for p in parsed["python_blocks"] if p["start_line"] < parsed["suites"][0]["start_line"]]
        check("quality_totals", platform + ":main_python",
              len(main_python) == 1 and main_python[0]["run"] == 523
              and main_python[0]["skipped"] == expected[3]
              and main_python[0]["outcome"].startswith("OK"))
        embedded = [p for p in parsed["python_blocks"] if p not in main_python]
        check("quality_totals", platform + ":embedded_python_separate",
              all(p["run"] == 30 and p["skipped"] == 0 and p["outcome"] == "OK" for p in embedded)
              and len(embedded) == (0 if platform == "windows-2025" else 1))
        checkout = next(n for n in quality if n.startswith(f"native ({platform})/2_"))
        check("checkout_log", platform, HEAD in quality[checkout].decode())
        row = {"platform": platform, "ordinary_rust": totals, "ordinary_suites": len(ordinary),
               "ordinary_named_rows": sum(x["declared"] for x in ordinary),
               "rustdoc": doc_totals, "rustdoc_subruns": len(docs),
               "python_main": main_python[0], "embedded_python": embedded,
               "ordinary_independent_list_claimed": False}
        result["platforms"].append(row)
        suites_result[platform] = parsed
    save("suites-recomputed.json", suites_result)

    # macOS/Linux real OpenSSH: original result, per-name test log, process and cleanup receipts.
    result["openssh_interop"] = []
    for artifact, platform in [(14298698102, "Linux"), (14299297187, "Darwin")]:
        filename = f"quality-artifact-{artifact}-archive.zip"
        payload = payloads[filename]
        result_name = next(n for n in payload if n.endswith("/result.json"))
        interop = parse_json(payload[result_name], filename + "#" + result_name)
        tests_name = next(n for n in payload if n.endswith("/tests.log"))
        parsed = rust_suites(payload[tests_name], filename + "#" + tests_name)
        passed = sum(s["counts"]["passed"] for s in parsed["suites"])
        check("interop", platform + ":18_named_passed",
              passed == interop["passed_tests"] == 18 and interop["outcome"] == "passed"
              and interop["platform"] == platform)
        cleanup = interop["cleanup"]
        check("interop", platform + ":cleanup",
              cleanup["observed_processes_stopped"] is True
              and cleanup["owned_processes_stopped"] is True
              and cleanup["temporary_directory_removed"] is True
              and cleanup["ancestry_unverified"] == [])
        check("interop", platform + ":successful_commands",
              all(p.get("returncode") == 0 and not p.get("timed_out", False)
                  for p in interop["steps"]))
        result["openssh_interop"].append({
            "platform": platform, "artifact_id": artifact, "passed_tests": passed,
            "result_member": result_name, "tests_member": tests_name,
            "cleanup": cleanup, "suites": parsed["suites"],
        })

    # Retain Windows API skipped/UNRUN boundaries; inspect original object evidence separately.
    direct = payloads["windows_monitor-artifact-14297134286-archive.zip"]
    direct_receipt = parse_json(direct["receipt.json"], "direct#receipt.json")
    check("windows_direct", "PASS_with_explicit_UNRUN",
          direct_receipt["status"] == direct_receipt["windows_api"] == "PASS"
          and direct_receipt["ssh"] == direct_receipt["native_gui"] == "UNRUN")
    for child in direct_receipt["children"]:
        terminal = child["terminal"]
        objects = terminal["native_process_objects"]
        label = child["label"]
        check("windows_direct", label + ":natural_terminal",
              child["observed_exit"] == 0 and terminal["direct_reaped"] is True
              and terminal["active_processes"] == 0 and terminal["pipes_drained"] is True
              and child["errors"] == terminal["errors"] == []
              and objects["admission_closed"] is True and objects["identities_bound"] is True
              and objects["pending_process_objects"] == 0)
        check("windows_direct", label + ":separate_receipt",
              parse_json(direct[label + ".receipt.json"], "direct#" + label + ".receipt.json")
              == {k: v for k, v in child.items() if k != "label"})
        check("windows_direct", label + ":stdout_stderr_sizes",
              len(direct[label + ".stdout"]) == child["stdout_bytes"]
              and len(direct[label + ".stderr"]) == child["stderr_bytes"])
    ssh = payloads["windows_ssh-artifact-14297682987-archive.zip"]
    ssh_receipt = parse_json(ssh["receipt.json"], "ssh#receipt.json")
    original = parse_json(ssh["ssh-debug-originals.json"], "ssh#ssh-debug-originals.json")
    final = parse_json(ssh["ssh-debug-cleanup.json"], "ssh#ssh-debug-cleanup.json")
    binding = parse_json(ssh["ssh-production-binding.json"], "ssh#ssh-production-binding.json")
    rust = parse_json(ssh["rust-client.json"], "ssh#rust-client.json")
    test_binary = parse_json(ssh["test-binary.json"], "ssh#test-binary.json")
    command_bindings = []
    for operation in ["probe", "resources", "processes", "sockets", "resources-skipped"]:
        assembly_name = operation + ".assembly.json"
        assembly = parse_json(direct[assembly_name], "direct#" + assembly_name)
        check("windows_command_source", operation + ":ssh_direct_assembly_equal",
              direct[assembly_name] == ssh[assembly_name])
        parts = []
        for part in assembly["parts"]:
            matches = [p for p in blobs if p.endswith("/" + part["file"])]
            check("windows_command_source", operation + ":" + part["file"],
                  len(matches) == 1 and digest(blobs[matches[0]]) == part["sha256"])
            parts.append(blobs[matches[0]].decode())
        script = assembly["literal_prefix"] + "".join(parts) + assembly["literal_suffix"]
        encoded = base64.b64encode(script.encode("utf-16-le")).decode()
        wire = ("powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand " + encoded).encode()
        check("windows_command_source", operation + ":script_and_wire",
              assembly["join"] == "verbatim"
              and digest(script.encode()) == assembly["script_sha256"]
              and digest(wire) == assembly["wire_command_sha256"]
              and len(wire) == assembly["wire_command_ascii_bytes"]
              and wire == direct[operation + ".wire.txt"])
        child = next(c for c in direct_receipt["children"] if c["label"] == operation)
        check("windows_command_source", operation + ":executed_direct_shell_command",
              child["shell_execution"]["argv"][-1].encode() == wire)
        if operation != "resources-skipped":
            bound = next(b for b in binding["operations"] if b["operation"] == operation)
            process = next(p for p in original["admissions"]
                           if (p["pid"], p["creation_time"]) == (bound["pid"], bound["creation_time"]))
            command = re.search(r"-EncodedCommand\s+([A-Za-z0-9+/=]+)", process["command_line"])
            check("windows_command_source", operation + ":original_process_command_and_binding",
                  command is not None and command[1] == encoded
                  and bound["wire_sha256"] == digest(wire))
        command_bindings.append({
            "operation": operation, "parts": [m["file"] for m in assembly["parts"]],
            "script_sha256": digest(script.encode()), "wire_sha256": digest(wire),
            "wire_bytes": len(wire),
        })
    result["windows_command_bindings"] = command_bindings
    check("windows_ssh", "source_and_scope",
          ssh_receipt["source"] == HEAD and ssh_receipt["status"] == ssh_receipt["ssh"] == "PASS"
          and ssh_receipt["native_gui"] == "UNRUN"
          and ssh["source-head.stdout"].decode().strip() == HEAD and not ssh["source-status.stdout"])
    for key, filename in [("windows_monitor", "windows_monitor-attempt1-logs.zip"),
                          ("windows_ssh", "windows_ssh-attempt1-logs.zip")]:
        payload = payloads[filename]
        checkout = next(n for n in payload if "/2_Run actions_checkout" in n)
        check("checkout_log", key, HEAD in payload[checkout].decode())
    identities = {(x["pid"], x["creation_time"]) for x in original["admissions"]}
    check("windows_ssh", "21_original_identities_and_complete_census",
          len(identities) == len(original["admissions"]) == original["job_total_processes"] == 21
          and original["complete_original_object_census"] is True
          and original["last_census_observation"]["complete"] is True
          and original["last_census_observation"]["unknown_pids"] == []
          and original["last_census_observation"]["unbound_originals"] == 0)
    master = [x for x in original["admissions"] if x["is_master"]]
    check("windows_ssh", "precleanup_HOLD_only_master_alive",
          original["state"] == "HOLD" and original["terminal_proven"] is False
          and len(master) == 1 and original["job_active_processes"] == 1
          and original["last_census_observation"]["current_pids"] == [master[0]["pid"]]
          and master[0]["natural_terminal_before_cleanup"] is False)
    for process in original["admissions"]:
        subject = f"{process['pid']}:{process['creation_time']}"
        check("windows_ssh_process", subject + ":retained_bound",
              process["retained_before_first_instruction"] is True
              and process["identity_bound_before_first_continue"] is True)
        if not process["is_master"]:
            check("windows_ssh_process", subject + ":natural_terminal",
                  process["natural_terminal_before_cleanup"] is True and process["original_signaled"] is True
                  and process["exit_event_received"] is True and process["exit_event_continued"] is True
                  and process["exit_event_code"] == process["exit_code"])
    powershell = [x for x in original["admissions"] if x["image"].lower().endswith("\\powershell.exe")]
    check("windows_ssh", "four_powershell_natural_exit_zero",
          len(powershell) == 4 and all(x["exit_code"] == 0 for x in powershell))
    by_identity = {(x["pid"], x["creation_time"]): x for x in original["admissions"]}
    check("windows_ssh", "four_operation_identity_bindings",
          {x["operation"] for x in binding["operations"]} == {"probe", "resources", "processes", "sockets"}
          and len(binding["operations"]) == 4 and binding["source_exact"] is True
          and binding["original_processes_naturally_terminal"] is True)
    for operation in binding["operations"]:
        process = by_identity[(operation["pid"], operation["creation_time"])]
        check("windows_ssh", operation["operation"] + ":original_powershell",
              process in powershell and process["exit_code"] == operation["exit_code"] == 0)
    check("windows_ssh", "cleanup_same_21_objects_zero_job_handles",
          {(x["pid"], x["creation_time"]) for x in final["admissions"]} == identities
          and final["state"] == "PASS" and final["terminal_proven"] is True
          and final["job_active_processes"] == final["pending_process_objects"] == final["owned_handles_remaining"] == 0
          and final["debug_connections"] == final["fallback_detaches"] == 0
          and final["closed"] is True and final["errors"] == []
          and final["debug_events_received"] == final["debug_events_continued"]
          and final["complete_original_object_census"] is True)
    cleanup = parse_json(ssh["ssh-cleanup.json"], "ssh#ssh-cleanup.json")
    check("windows_ssh", "private_directory_cleaned_keys_not_uploaded",
          cleanup["temporary_directory_removed"] is True
          and cleanup["private_config_uploaded"] is False and cleanup["keys_uploaded"] is False)
    check("windows_ssh", "rust_public_route_assertions",
          rust["status"] == "PASS" and rust["errors"] == []
          and all(x["passed"] is True for x in rust["assertion_evidence"])
          and rust["identity"]["platform"] == "Windows"
          and rust["identity"]["runtime"] == "WindowsPowerShell")
    check("windows_ssh", "single_test_inventory",
          test_binary["inventory"] == [test_binary["executed"]] == [rust["test"]]
          and ssh["live-test-inventory.stdout"].decode().splitlines()[0] == rust["test"] + ": test")
    result["windows"] = {
        "direct_api": "PASS", "direct_api_ssh": direct_receipt["ssh"],
        "isolated_prerequisite_job": "skipped", "ssh_original_identities": len(identities),
        "ssh_precleanup_state": original["state"], "ssh_nonmaster_natural_terminal": 20,
        "ssh_powershell_natural_exit_zero": len(powershell),
        "ssh_final_state": final["state"], "ssh_master_cleanup_exit":
            next(x["exit_code"] for x in final["admissions"] if x["is_master"]),
        "native_gui": "UNRUN", "rust_assertions": len(rust["assertion_evidence"]),
    }

    # Only now compare author-derived conclusions with independently computed values.
    report = load("report.json")
    handoff = load("handoff.json")
    verification = load("verification.json")
    check("report_comparison", "head_and_status",
          report["exact_head"] == handoff["exact_head"] == HEAD
          and report["status"] == handoff["status"] == "completed_success")
    for row in result["platforms"]:
        author = next(x["tests"] for x in report["platforms"] if x["platform"] == row["platform"])
        check("report_comparison", row["platform"],
              author["ordinary_rust"] == row["ordinary_rust"]
              and author["ordinary_suites"] == row["ordinary_suites"]
              and author["rustdoc"] == row["rustdoc"]
              and author["python_main"]["run"] == row["python_main"]["run"]
              and author["python_main"]["skipped"] == row["python_main"]["skipped"])
    check("report_comparison", "verification_totals",
          verification["saved_subprocess_outputs"] == 56 and verification["zip_count"] == 7
          and verification["zip_members"] == 156 and verification["artifact_digest_matches"] == 4)
    check("immutability", "entire_author_evidence_directory_unchanged", snapshot() == initial)
    check("immutability", "source_archive_unchanged", (ROOT / ARCHIVE).read_bytes() == original_tar)
    result["json_documents_parsed"] = len(JSON_DOCUMENTS)
    result["checks"] = {
        "total": len(CHECKS), "passed": sum(c["ok"] for c in CHECKS),
        "failed": sum(not c["ok"] for c in CHECKS),
        "by_category": dict(sorted(collections.Counter(c["category"] for c in CHECKS).items())),
    }
    result["review_git_commands"] = len(COMMANDS)
    result["elapsed_seconds"] = round(time.monotonic() - START, 6)
    save("results.json", result)
    save("git-commands.json", COMMANDS)
    save("json-documents.json", JSON_DOCUMENTS)
    (OUT / "checks.jsonl").write_text("".join(json.dumps(c, ensure_ascii=False) + "\n" for c in CHECKS))
    print(json.dumps({k: result[k] for k in
                      ["exact_head", "checks", "zip_count", "zip_members", "artifact_digests",
                       "source", "windows", "review_git_commands", "elapsed_seconds"]},
                     ensure_ascii=False, indent=2))
    if result["checks"]["failed"]:
        print("FAILED_CHECKS", json.dumps([x for x in CHECKS if not x["ok"]], ensure_ascii=False))
        return 1
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:
        save("reviewer-parser-error.json", {"type": type(exc).__name__, "message": str(exc),
                                           "checks_so_far": len(CHECKS)})
        save("git-commands.json", COMMANDS)
        print(f"REVIEWER_PARSER_ERROR {type(exc).__name__}: {exc}", file=sys.stderr)
        raise
