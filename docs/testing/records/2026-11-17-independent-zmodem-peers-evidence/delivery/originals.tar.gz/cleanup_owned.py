"""Reclaim this batch's sealed work copies, preserving the target and app."""
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
PARENT = ROOT / "work/zmodem-independent-peer-20261117"
SOURCE = "de9768c183c22f1051baabd529600667697247a1"
assert not (BASE / "cleanup-result.json").exists()
binding = json.loads((PARENT / "feature-git-binding-result-r1.json").read_text())
readback = json.loads((PARENT / "feature-readback-result-r1.json").read_text())
assert binding["commit"] == SOURCE and binding["all_exact_git_blobs_verified"]
assert readback["expected_source"] == SOURCE and readback["three_shas_match"]
assert readback["working_tree_clean"]
delivery = ROOT / "work/zmodem-independent-delivery-20261117"
archive = ROOT / "docs/testing/records/2026-11-17-independent-zmodem-peers-evidence/originals.tar.gz"
with tarfile.open(archive, "r:gz") as sealed:
    selection_bytes = sealed.extractfile("selection.json").read()
assert selection_bytes == (delivery / "selection.json").read_bytes()
selection = json.loads(selection_bytes)


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as content:
        for chunk in iter(lambda: content.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


assert digest(archive) == binding["archive_sha256"]
for row in selection["selected"]:
    path = ROOT / row["source"]
    assert path.is_file() and not path.is_symlink()
    assert path.stat().st_size == row["bytes"] and digest(path) == row["sha256"], row["source"]

receipts = BASE / "receipts"
receipts.mkdir()
selected = {row["source"] for row in selection["selected"]}
extra = []
for path in sorted(PARENT.rglob("*")):
    if not path.is_file() or "__pycache__" in path.parts:
        continue
    if str(path.relative_to(ROOT)) not in selected:
        target = receipts / path.relative_to(PARENT)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
        extra.append({
            "path": str(target.relative_to(BASE)),
            "bytes": target.stat().st_size, "sha256": digest(target),
        })
for name in ("run_command.py", "readback_git.py", "verify_git_binding.py",
             "seal_directory.py", "candidate-inputs-r7.json"):
    shutil.copyfile(PARENT / name, BASE / name)

target = ROOT / "work/recovery-batch-integration-20261115/target"
normal = ROOT / "work/windows-monitor-delivery-20261117/package-r2/KeelShell.app"
target_identity = (target.stat().st_dev, target.stat().st_ino)
assert target_identity == (16777231, 269342313)
package = {str(path.relative_to(normal)): digest(path)
           for path in normal.rglob("*") if path.is_file()}
assert package
roots = [
    PARENT,
    ROOT / "work/zmodem-independent-source-review-20261117",
    ROOT / "work/zmodem-core-peer-review-20261117",
    ROOT / "work/zmodem-sexyz-peer-20261117",
    ROOT / "work/zmodem-lrzsz0131-peer-20261117",
    delivery,
]
reclaimed = []
for path in roots:
    assert path.parent == ROOT / "work" and path.is_dir() and not path.is_symlink()
    assert not target.is_relative_to(path) and not normal.is_relative_to(path)
    files = [child for child in path.rglob("*") if child.is_file()]
    row = {
        "path": str(path.relative_to(ROOT)), "files": len(files),
        "bytes": sum(child.stat().st_size for child in files),
    }
    shutil.rmtree(path)
    assert not path.exists()
    reclaimed.append(row)
assert (target.stat().st_dev, target.stat().st_ino) == target_identity
assert package == {str(path.relative_to(normal)): digest(path)
                   for path in normal.rglob("*") if path.is_file()}
record = {
    "source_commit": SOURCE, "sealed_source_files_verified": len(selection["selected"]),
    "sealed_archive_git_bound": True, "reclaimed": reclaimed,
    "reclaimed_files": sum(row["files"] for row in reclaimed),
    "reclaimed_bytes": sum(row["bytes"] for row in reclaimed),
    "preserved_unsealed_delivery_receipts": extra,
    "target_identity_unchanged": True,
    "normal_package_files": package, "normal_package_unchanged": True,
    "new_user_chats": 0, "new_worktrees": 0, "new_containers": 0,
    "owned_agents_closed": 5,
}
(BASE / "cleanup-result.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({key: value for key, value in record.items()
                  if key not in {"normal_package_files", "preserved_unsealed_delivery_receipts"}}))
