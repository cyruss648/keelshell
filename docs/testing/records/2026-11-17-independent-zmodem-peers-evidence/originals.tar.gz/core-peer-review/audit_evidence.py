"""Independently verify immutable review inputs and saved peer receipts.

Only this review directory is writable. External peer sources are checksummed
as opaque bytes for provenance; no external protocol implementation is read as
code, imported, executed, or copied into the product.
"""

import ast
import binascii
from collections import Counter
import datetime
import hashlib
import json
from pathlib import Path
import re
import tarfile

OUTPUT = Path(__file__).resolve().parent
ROOT = OUTPUT.parents[1]
PARENT = ROOT / "work/zmodem-independent-peer-20261117"
PEER = ROOT / "work/zmodem-sexyz-peer-20261117"
CHECKS = []
EVIDENCE = {}


def check(name, condition, detail=None):
    CHECKS.append({"name": name, "passed": bool(condition), "detail": detail})
    if not condition:
        raise AssertionError(f"{name}: {detail}")


def digest(path):
    result = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()


def read_json(path):
    EVIDENCE[str(path.relative_to(ROOT))] = {
        "bytes": path.stat().st_size, "sha256": digest(path),
    }
    return json.loads(path.read_bytes())


def mark(path):
    EVIDENCE[str(path.relative_to(ROOT))] = {
        "bytes": path.stat().st_size, "sha256": digest(path),
    }


def canonical_hash(rows):
    return hashlib.sha256(
        json.dumps(rows, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()


def verify_receipt(label, exit_code, expected_summary=None):
    receipt = read_json(PARENT / (label + ".json"))
    log = PARENT / (label + ".log")
    mark(log)
    check(label + "/log-bytes", receipt["log_bytes"] == log.stat().st_size)
    check(label + "/log-digest", receipt["log_sha256"] == digest(log))
    check(label + "/exit", receipt["observed_exit"] == exit_code
          and receipt["controller_exit"] == exit_code)
    terminal = receipt["terminal"]
    check(label + "/terminal",
          not receipt["timed_out"] and not receipt["interrupted"]
          and terminal["direct_reaped"] and terminal["active_processes"] == 0
          and terminal["pipes_drained"] and not terminal["errors"]
          and not receipt["errors"])
    if expected_summary:
        check(label + "/summary", expected_summary in log.read_text())
    return receipt


def unescape(wire, position, count):
    output = bytearray()
    while len(output) < count:
        value = wire[position]
        position += 1
        if value == 0x18:
            value = wire[position]
            position += 1
            value = {0x6C: 0x7F, 0x6D: 0xFF}.get(value, value ^ 0x40)
        output.append(value)
    return bytes(output), position


def audit_capture():
    source_path = ROOT / "crates/keelshell-core/tests/zmodem.rs"
    source = source_path.read_text()
    match = re.search(r'let captured = (b"(?:[^"\\]|\\.)*")', source, re.S)
    literal = re.sub(r"\\\n[ \t]*", "", match.group(1))
    captured = ast.literal_eval(literal)
    original = (PARENT / "mac-sexyz-r1/tests.log").read_text()
    hex_vectors = re.findall(
        r"(?<![0-9a-f])([0-9a-f]{40,})(?![0-9a-f])", original
    )
    check("capture/exact-r1-wire",
          captured in [bytes.fromhex(value) for value in hex_vectors])
    check("capture/binary32-prefix", captured.startswith(b"**\x18C"))
    header, position = unescape(captured, 4, 9)
    check("capture/header-crc32",
          binascii.crc32(header[:5]) == int.from_bytes(header[5:], "little"))
    check("capture/file-header", header[:5] == b"\x04\x00\x00\x02\x01")
    end = captured.index(b"\x18k", position)
    payload, payload_end = unescape(
        captured, position,
        len(b"first.bin\x0019 15276741714 0 0 2 41 0\x00"),
    )
    check("capture/payload-exact-end", payload_end == end)
    checksum, tail = unescape(captured, end + 2, 4)
    check("capture/data-crc32",
          binascii.crc32(payload + b"k") == int.from_bytes(checksum, "little"))
    check("capture/trailer", captured[tail:] == b"\x11")
    name, metadata, trailing = payload.split(b"\x00")
    check("capture/name-size-and-seven-fields",
          name == b"first.bin" and metadata.split() == [
              b"19", b"15276741714", b"0", b"0", b"2", b"41", b"0",
          ] and trailing == b"")
    return {
        "wire_bytes": len(captured),
        "wire_sha256": hashlib.sha256(captured).hexdigest(),
        "all_two_chunk_split_positions_in_product_test": len(captured) + 1,
        "header_crc32": header[5:].hex(),
        "data_crc32": checksum.hex(),
        "metadata": metadata.decode(),
        "method": "Python binascii.crc32 over independently unescaped bytes",
    }


def audit_peer_provenance():
    peer = read_json(PEER / "peer.json")
    executable = Path(peer["executable"])
    check("peer/binary-digest", digest(executable) == peer["binary_sha256"])
    check("peer/binary-size", executable.stat().st_size == peer["binary_bytes"])
    archive = PEER / "downloads" / (
        "sbbs-" + peer["upstream_git_sha"] + ".tar.gz"
    )
    check("peer/archive-digest", digest(archive) == peer["archive_sha256"])
    commit = read_json(
        PEER / "downloads" / ("commit-" + peer["upstream_git_sha"] + ".json")
    )
    check("peer/commit-identity", commit["sha"] == peer["upstream_git_sha"])
    sources = read_json(PEER / "evidence/source-baseline.json")
    inputs = read_json(PEER / "evidence/build-inputs.json")
    source_by_name = {row["path"]: row for row in sources}
    check("peer/source-count", len(source_by_name) == len(sources) == 1452)
    for row in sources:
        path = PEER / "source" / row["path"]
        check("peer/source/" + row["path"],
              not path.is_symlink() and path.stat().st_size == row["bytes"]
              and digest(path) == row["sha256"])
    check("peer/build-input-count", len(inputs) == 160)
    for row in inputs:
        path = PEER / row["build_path"]
        check("peer/build/" + row["build_path"],
              not path.is_symlink() and digest(path) == row["sha256"])
        if "source" in row:
            check("peer/build-origin/" + row["build_path"],
                  row["sha256"] == digest(PEER / row["source"]))
        elif row.get("generated_build_metadata"):
            check("peer/generated/" + row["build_path"],
                  path.read_text() == row["content"])
    # Compare extracted source and standalone input hashes to the pinned archive,
    # without emitting or inspecting any implementation text.
    archive_names = set(source_by_name)
    archive_only_inputs = {
        row["archive_member"]: row for row in inputs if "archive_member" in row
    }
    found = set()
    with tarfile.open(archive, "r|gz") as package:
        for member in package:
            if member.name not in archive_names | set(archive_only_inputs):
                continue
            stream = package.extractfile(member)
            result = hashlib.sha256()
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                result.update(chunk)
            expected = source_by_name.get(
                member.name, archive_only_inputs.get(member.name)
            )
            check("peer/archive-member/" + member.name,
                  result.hexdigest() == expected["sha256"])
            found.add(member.name)
    check("peer/archive-members-complete",
          found == archive_names | set(archive_only_inputs))
    final = read_json(PEER / "evidence/final-audit.json")
    check("peer/original-audit-preserved",
          final["status"] == "PASS" and not final["mismatches"]
          and final["binary_sha256"] == peer["binary_sha256"])
    for label in ("native-arm64-build-r1", "final-audit-r1"):
        receipt = read_json(PEER / "logs" / (label + ".json"))
        check("peer/" + label + "/terminal",
              receipt["returncode"] == 0 and not receipt["timed_out"]
              and not receipt["interrupted"] and receipt["direct_child_reaped"]
              and receipt["process_group_absent"]
              and not receipt["remaining_group_members"])
        for suffix in (".stdout.log", ".stderr.log"):
            mark(PEER / "logs" / (label + suffix))
    check("peer/no-ini-default-overrides",
          not list((PEER / "build-standalone").glob("sexyz*.ini")))
    return {
        "upstream_sha": peer["upstream_git_sha"],
        "archive_sha256": peer["archive_sha256"],
        "binary_sha256": peer["binary_sha256"],
        "binary_bytes": peer["binary_bytes"],
        "source_files_verified": len(sources),
        "build_inputs_verified": len(inputs),
        "archive_members_verified": len(found),
        "implementation_text_inspected_or_imported": False,
        "independent_peer_rebuild": False,
    }


def audit_run(number, freeze, peer):
    label = "mac-sexyz-r" + str(number)
    result = read_json(PARENT / label / "result.json")
    binding = read_json(PARENT / (label + "-binding.json"))
    outer = verify_receipt("mac-sexyz-test-r" + str(number), 1)
    log_path = PARENT / label / "tests.log"
    log = log_path.read_text()
    check(label + "/result-failed", result["outcome"] == "failed")
    check(label + "/steps", result["steps"][-1] == {
        "name": "tests", "returncode": 101,
    } and all(row["returncode"] == 0 for row in result["steps"][:-1]))
    for name, size in result["logs"].items():
        path = PARENT / label / name
        mark(path)
        check(label + "/log-size/" + name, path.stat().st_size == size)
    rows = re.findall(r"^test (real_\w+) \.\.\. (ok|FAILED)$", log, re.M)
    check(label + "/ten-unique-tests",
          len(rows) == len({name for name, _ in rows}) == 10)
    passed = [name for name, outcome in rows if outcome == "ok"]
    failed = [name for name, outcome in rows if outcome == "FAILED"]
    expected_counts = (3, 7) if number == 1 else (8, 2)
    check(label + "/counts", (len(passed), len(failed)) == expected_counts)
    check(label + "/summary",
          f"{len(passed)} passed; {len(failed)} failed; 0 ignored;" in log)
    check(label + "/binding-stable",
          binding["source_inputs_before"] == binding["source_inputs_after"]
          and binding["unchanged"] and binding["runner_exit"] == 1)
    frozen = {row["path"]: row["sha256"] for row in freeze["inputs"]}
    for path, sha256 in binding["source_inputs_before"].items():
        check(label + "/source-binding/" + path, frozen[path] == sha256)
    check(label + "/baseline",
          binding["source"] == freeze["baseline_source"])
    check(label + "/upstream-and-binary",
          binding["upstream_source"] == peer["upstream_sha"]
          and binding["peer_sha256_before"] == peer["binary_sha256"]
          and binding["peer_sha256_after"] == peer["binary_sha256"])
    for direction, arguments in (
        ("rz", ["-raw", "-e", "rz", "./"]), ("sz", ["-raw", "sz"])
    ):
        row = result["zmodem_peers"][direction]
        check(label + "/peer/" + direction,
              row["args"] == arguments
              and row["sha256"] == peer["binary_sha256"]
              and row["bytes"] == peer["binary_bytes"])
    cleanup = result["cleanup"]
    check(label + "/cleanup-receipt",
          cleanup["observed_processes_stopped"]
          and cleanup["owned_processes_stopped"]
          and not cleanup["ancestry_unverified"]
          and cleanup["temporary_directory_removed"])
    temporary = Path(result["temporary_directory"])
    check(label + "/temporary-directory-absent",
          temporary.is_relative_to(ROOT / "work/.openssh-private")
          and not temporary.exists())
    if number >= 2:
        check(label + "/only-two-empty-file-failures", set(failed) == {
            "real_sz_download_batch_requires_a_separate_review_and_save_for_each_file",
            "real_sz_sends_an_individually_reviewed_empty_file",
        })
        for name in failed:
            error = re.search(
                r"^---- " + name + r" stdout ----\n(Error:.*)$", log, re.M
            ).group(1)
            check(label + "/invalid-zero-position/" + name,
                  "Received INVALID ZRPOS offset: 0" in error
                  and "empty.bin" in error and "size: 0" in error)
    receipts = {}
    if number == 3:
        pattern = (
            r"^---- (real_\w+) stdout ----\n"
            r"peer receipt: incoming_binary16=(true|false); "
            r"incoming_binary32=(true|false); strict_OO=(\d+); "
            r"missing_OO=(\d+); saved=(\d+); shell_end=(.+)$"
        )
        for name, crc16, crc32, strict, missing, saved, end in re.findall(
            pattern, log, re.M
        ):
            receipts[name] = {
                "incoming_binary16": crc16 == "true",
                "incoming_binary32": crc32 == "true",
                "strict_OO": int(strict), "missing_OO": int(missing),
                "saved": int(saved), "shell_end": end,
            }
        check(label + "/all-eight-success-receipts",
              set(receipts) == set(passed) and len(receipts) == 8)
        for name, expected in (
            ("real_sz_sends_binary_content_over_crc16", (True, False)),
            ("real_sz_sends_binary_unicode_content_over_crc32", (False, True)),
        ):
            row = receipts[name]
            check(label + "/wire-and-strict/" + name,
                  (row["incoming_binary16"], row["incoming_binary32"]) == expected
                  and row["strict_OO"] == 1 and row["missing_OO"] == 0
                  and row["saved"] == 1
                  and row["shell_end"] == "Exited { code: 0 }")
        row = receipts[
            "real_sz_returns_to_the_same_shell_after_a_bounded_receive_farewell"
        ]
        check(label + "/interactive-strict",
              row["strict_OO"] == 1 and row["missing_OO"] == 0
              and row["saved"] == 1
              and row["shell_end"] == "Exited { code: 0 }"
              and "interactive receive outcome: strict_OO=1; "
              "missing_optional_OO=0; same_shell_continued=true" in log)
        for name, row in receipts.items():
            check(label + "/no-missing-OO/" + name, row["missing_OO"] == 0)
            if row["strict_OO"]:
                check(label + "/strict-also-exit-zero/" + name,
                      row["shell_end"] == "Exited { code: 0 }")
    return {
        "label": label, "outcome": result["outcome"],
        "passed": passed, "failed": failed, "receipts": receipts,
        "tests_exit": 101, "outer_exit": 1,
        "outer_elapsed_seconds": outer["seconds"],
        "runner_elapsed_seconds": result["elapsed_seconds"],
        "outer_direct_reaped": outer["terminal"]["direct_reaped"],
        "binding_unchanged": binding["unchanged"],
        "source_freeze": "candidate-inputs-r" + str(number) + ".json",
        "cleanup": cleanup,
        "temporary_directory_currently_absent": True,
    }


def main():
    freezes = {}
    for number in (1, 2, 3):
        row = read_json(PARENT / ("candidate-inputs-r" + str(number) + ".json"))
        if number >= 2:
            check("freeze/r" + str(number) + "/canonical",
                  canonical_hash(row["inputs"]) == row["aggregate_sha256"])
        check("freeze/r" + str(number) + "/count",
              row["count"] == len(row["inputs"]) == 765
              and len({entry["path"] for entry in row["inputs"]}) == 765)
        freezes[number] = row
    r2 = {row["path"]: row for row in freezes[2]["inputs"]}
    r3 = {row["path"]: row for row in freezes[3]["inputs"]}
    changed = sorted(path for path in r2 if r2[path] != r3[path])
    check("freeze/r2-r3/only-Fermat-files-changed", changed == sorted([
        "crates/keelshell-session/tests/zmodem_openssh.rs",
        "scripts/openssh_interop.py", "scripts/test_openssh_interop.py",
    ]))
    current_drift = []
    for row in freezes[3]["inputs"]:
        path = ROOT / row["path"]
        actual = {
            "path": row["path"], "bytes": path.stat().st_size,
            "sha256": digest(path),
        }
        check("current/not-symlink/" + row["path"], not path.is_symlink())
        if actual != row:
            current_drift.append({"frozen_r3": row, "current": actual})
        if row["path"] in (
            "crates/keelshell-core/src/zmodem.rs",
            "crates/keelshell-core/tests/zmodem.rs",
        ):
            check("current/core-unchanged/" + row["path"], actual == row)
    check("current/drift-confined-to-other-reviewer",
          all(row["current"]["path"] in changed for row in current_drift))
    verify_receipt("core-captured-red-r1", 101, "0 passed; 1 failed;")
    check("core/red-invalid-metadata",
          "Err` value: InvalidMetadata" in
          (PARENT / "core-captured-red-r1.log").read_text())
    verify_receipt("core-zmodem-green-r1", 0,
                   "106 passed; 0 failed; 0 ignored;")
    capture = audit_capture()
    peer = audit_peer_provenance()
    runs = [audit_run(number, freezes[number], peer) for number in (1, 2, 3)]
    dependency1 = read_json(PARENT / "dependency-freshness-r1.json")
    dependency2 = read_json(PARENT / "dependency-freshness-r2.json")
    check("dependencies/r1-failure-preserved",
          dependency1["controller_exit"] == 1)
    check("dependencies/r2-timeout-preserved",
          dependency2["controller_exit"] == 124
          and dependency2["observed_exit"] is None
          and dependency2["timed_out"]
          and dependency2["terminal"]["direct_reaped"]
          and dependency2["terminal"]["active_processes"] == 0
          and not (PARENT / "dependency-freshness-report-r2.json").exists())
    for label in ("dependency-freshness-r1", "dependency-freshness-r2"):
        mark(PARENT / (label + ".log"))
    result = {
        "status": "PASS",
        "checks": len(CHECKS),
        "failed_checks": 0,
        "capture": capture,
        "peer_provenance": peer,
        "runs": runs,
        "freeze_r3_aggregate": freezes[3]["aggregate_sha256"],
        "r2_to_r3_changes": changed,
        "current_tree_matches_r3": not current_drift,
        "current_tree_drift_from_r3": current_drift,
        "drift_boundary": (
            "Current changes in the three Fermat-owned files do not inherit "
            "r3 observations. Two core files remain byte-identical. The r3 "
            "receipts are checked against their historical r3 manifest."
        ),
        "r1_aggregate_limit": (
            "r1 does not declare aggregate_algorithm. Its aggregate is retained "
            "without claiming a canonical-hash recomputation. All r1 bound "
            "source-input hashes are checked individually against its rows."
        ),
        "dependency_latest_full_freshness": "UNKNOWN",
        "fresh_SSH_or_peer_execution_by_reviewer": 0,
        "cleanup_limit": (
            "Checked original cleanup flags, outer reaping and current absence "
            "of all three owned private directories. Saved result.json does "
            "not expose the full historical birth-identity census; detached "
            "descendants between observations cannot be reconstructed here."
        ),
    }
    for filename, value in (
        ("offline-checks.json", CHECKS), ("evidence-manifest.json", EVIDENCE),
        ("offline-audit.json", result),
    ):
        with (OUTPUT / filename).open("x") as destination:
            json.dump(value, destination, indent=2)
            destination.write("\n")
    print(json.dumps({
        "status": result["status"], "checks": len(CHECKS),
        "failed_checks": 0, "capture": capture, "peer_provenance": peer,
        "run_counts": [
            {"label": row["label"], "passed": len(row["passed"]),
             "failed": len(row["failed"])} for row in runs
        ],
    }, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        filename = (
            "audit-failure-" +
            datetime.datetime.now(datetime.timezone.utc).strftime(
                "%Y%m%dT%H%M%S%f"
            ) + ".json"
        )
        with (OUTPUT / filename).open("x") as destination:
            json.dump({
                "exception": repr(error), "checks": CHECKS,
                "product_or_target_mutation": False,
            }, destination, indent=2)
            destination.write("\n")
        raise
