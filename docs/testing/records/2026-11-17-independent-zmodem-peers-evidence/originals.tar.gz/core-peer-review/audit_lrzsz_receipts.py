"""Audit a saved lrzsz run without running SSH or the peer."""

import argparse
import hashlib
import json
from pathlib import Path
import re
import tarfile

import audit_evidence as common

OUTPUT = common.OUTPUT
ROOT = common.ROOT
PARENT = common.PARENT
PEER = ROOT / "work/zmodem-lrzsz0131-peer-20261117"
check = common.check
read_json = common.read_json
digest = common.digest
mark = common.mark


def provenance():
    metadata = read_json(PEER / "peer.json")
    official = metadata["official_source"]
    archive = PEER / official["archive_path"]
    check("lrzsz/archive",
          archive.stat().st_size == official["archive_bytes"]
          and digest(archive) == official["archive_sha256"])
    page = PEER / official["official_page_local_path"]
    check("lrzsz/official-page", digest(page) == official["official_page_sha256"])
    manifest = read_json(PEER / "evidence/source-manifest.json")
    files = {
        row["path"]: row for row in manifest["entries"] if row["kind"] == "file"
    }
    check("lrzsz/source-count", len(files) == manifest["file_count"] == 95)
    for path, row in files.items():
        source = PEER / "source" / path
        check("lrzsz/source/" + path,
              not source.is_symlink() and source.stat().st_size == row["bytes"]
              and digest(source) == row["sha256"])
    found = set()
    with tarfile.open(archive, "r|gz") as package:
        for member in package:
            if member.name not in files:
                continue
            stream = package.extractfile(member)
            hasher = hashlib.sha256()
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                hasher.update(chunk)
            check("lrzsz/archive-member/" + member.name,
                  member.size == files[member.name]["bytes"]
                  and hasher.hexdigest() == files[member.name]["sha256"])
            found.add(member.name)
    check("lrzsz/archive-complete", found == set(files))
    integrity = read_json(PEER / "evidence/source-integrity.json")
    check("lrzsz/original-source-integrity", integrity["unchanged_after_build"])
    for row in integrity["post_build_snapshot"]["files"]:
        original = files[row["path"].removeprefix("source/")]
        check("lrzsz/post-build-source/" + row["path"],
              row["bytes"] == original["bytes"]
              and row["sha256"] == original["sha256"])
    build = read_json(PEER / "evidence/build-manifest.json")
    check("lrzsz/build-count", build["file_count"] == len(build["files"]) == 34)
    for row in build["files"]:
        path = PEER / row["path"]
        check("lrzsz/build/" + row["path"],
              not path.is_symlink() and path.stat().st_size == row["bytes"]
              and digest(path) == row["sha256"])
    for label in ("configure", "make", "download-official-archive"):
        receipt = read_json(PEER / "commands" / label / "command.json")
        check("lrzsz/" + label + "/terminal",
              receipt["exit_code"] == 0 and not receipt["timed_out"]
              and receipt["direct_child_reaped"]
              and not receipt["process_group_alive_after_cleanup"]
              and receipt["spawn_error"] is None)
    for direction, row in metadata["executables"].items():
        path = Path(row["path"])
        check("lrzsz/binary/" + direction,
              path.stat().st_size == row["bytes"]
              and digest(path) == row["sha256"])
    return {
        "official_version": official["release"],
        "archive_sha256": official["archive_sha256"],
        "source_files_verified": len(files),
        "archive_members_verified": len(found),
        "build_files_verified": len(build["files"]),
        "executables": metadata["executables"],
        "digest_assurance": official["digest_assurance"],
        "GPL_implementation_logic_inspected_imported_or_executed": False,
        "fresh_peer_build_or_run": False,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("revision", type=int, choices=[5, 6])
    options = parser.parse_args()
    revision = options.revision
    label = f"mac-lrzsz-r{revision}"
    freeze = read_json(PARENT / f"candidate-inputs-r{revision}.json")
    check(label + "/freeze-canonical",
          common.canonical_hash(freeze["inputs"]) == freeze["aggregate_sha256"])
    check(label + "/freeze-count", len(freeze["inputs"]) == freeze["count"] == 765)
    frozen = {row["path"]: row["sha256"] for row in freeze["inputs"]}
    initial = json.loads((OUTPUT / "initial-binding.json").read_bytes())
    r2 = json.loads((PARENT / "candidate-inputs-r2.json").read_bytes())
    for row in r2["inputs"]:
        if row["path"].startswith("crates/keelshell-core/"):
            check(label + "/core-frozen/" + row["path"],
                  frozen[row["path"]] == row["sha256"]
                  and digest(ROOT / row["path"]) == row["sha256"])
    peer = provenance()
    result = read_json(PARENT / label / "result.json")
    binding = read_json(PARENT / (label + "-binding.json"))
    expected_exit = 1 if revision == 5 else 0
    outer = common.verify_receipt(f"mac-lrzsz-test-r{revision}", expected_exit)
    check(label + "/full-input-binding",
          binding["source_inputs_before"] == binding["source_inputs_after"]
          == frozen and binding["unchanged"])
    check(label + "/baseline",
          binding["source"] == freeze["baseline_source"]
          == "ac7ec43e6a42329417a99b5933bc171faa19caf6")
    check(label + "/archive-binding",
          binding["source_archive_sha256"] == peer["archive_sha256"])
    binaries = {
        "RZ": peer["executables"]["receiver"]["sha256"],
        "SZ": peer["executables"]["sender"]["sha256"],
    }
    check(label + "/dual-peer-binding",
          binding["peer_sha256_before"] == binding["peer_sha256_after"]
          == binaries)
    for name, direction in (("rz", "receiver"), ("sz", "sender")):
        actual = result["zmodem_peers"][name]
        expected = peer["executables"][direction]
        check(label + "/peer-recipe/" + name,
              actual["sha256"] == expected["sha256"]
              and actual["bytes"] == expected["bytes"]
              and actual["path"] == expected["path"]
              and actual["args"] == ["-b", "-vv"])
    check(label + "/outcome-preserved",
          result["outcome"] == ("failed" if revision == 5 else "passed")
          and binding["runner_exit"] == expected_exit
          and result["steps"][-1] == {
              "name": "tests", "returncode": 101 if revision == 5 else 0,
          })
    for filename, size in result["logs"].items():
        path = PARENT / label / filename
        mark(path)
        check(label + "/log-size/" + filename, path.stat().st_size == size)
    cleanup = result["cleanup"]
    check(label + "/cleanup",
          cleanup["owned_processes_stopped"]
          and cleanup["observed_processes_stopped"]
          and not cleanup["ancestry_unverified"]
          and cleanup["temporary_directory_removed"])
    temporary = Path(result["temporary_directory"])
    check(label + "/private-directory-absent",
          temporary.is_relative_to(ROOT / "work/.openssh-private")
          and not temporary.exists())
    log = (PARENT / label / "tests.log").read_text()
    statuses = re.findall(r"^test (real_\w+) \.\.\. (ok|FAILED)$", log, re.M)
    check(label + "/unique-ten-tests",
          len(statuses) == len({name for name, _ in statuses}) == 10)
    passed = [name for name, status in statuses if status == "ok"]
    failed = [name for name, status in statuses if status == "FAILED"]
    expected_passed, expected_failed = (8, 2) if revision == 5 else (10, 0)
    check(label + "/test-counts",
          len(passed) == expected_passed and len(failed) == expected_failed
          and f"{expected_passed} passed; {expected_failed} failed; 0 ignored;" in log)
    receipts = {}
    current = None
    pattern = re.compile(
        r"peer receipt: incoming_binary16=(true|false); "
        r"incoming_binary32=(true|false); strict_OO=(\d+); "
        r"missing_OO=(\d+); saved=(\d+); shell_end=(.+)"
    )
    for line in log.splitlines():
        heading = re.fullmatch(r"---- (real_\w+) stdout ----", line)
        if heading:
            current = heading.group(1)
        match = pattern.fullmatch(line)
        if match:
            crc16, crc32, strict, missing, saved, end = match.groups()
            check(label + "/no-duplicate-receipt/" + current,
                  current not in receipts)
            receipts[current] = {
                "incoming_binary16": crc16 == "true",
                "incoming_binary32": crc32 == "true",
                "strict_OO": int(strict), "missing_OO": int(missing),
                "saved": int(saved), "shell_end": end,
            }
    check(label + "/all-ten-receipts",
          set(receipts) == {name for name, _ in statuses})
    batch = "real_sz_download_batch_requires_a_separate_review_and_save_for_each_file"
    crc32 = "real_sz_sends_binary_unicode_content_over_crc32"
    if revision == 5:
        check(label + "/missing-OO-only-failures", set(failed) == {batch, crc32})
        for name, saved in ((batch, 3), (crc32, 1)):
            row = receipts[name]
            check(label + "/no-exit-zero-substitution/" + name,
                  row["strict_OO"] == 0 and row["missing_OO"] == 1
                  and row["saved"] == saved
                  and row["shell_end"] == "Exited { code: 0 }"
                  and row["incoming_binary32"] and not row["incoming_binary16"])
        check(label + "/strict-assertion-still-fails",
              log.count("assertion failed: report.events.iter().any("
                        "|event| matches!(event, Ui::Finished { .. }))") == 2)
    else:
        for name, saved in ((batch, 3), (crc32, 1)):
            row = receipts[name]
            check(label + "/actual-strict-OO/" + name,
                  row["strict_OO"] == 1 and row["missing_OO"] == 0
                  and row["saved"] == saved
                  and row["shell_end"] == "Exited { code: 0 }"
                  and row["incoming_binary32"] and not row["incoming_binary16"])
        check(label + "/no-missing-OO-observed",
              all(row["missing_OO"] == 0 for row in receipts.values()))
    empty = receipts["real_sz_sends_an_individually_reviewed_empty_file"]
    check(label + "/empty-file-strict-success",
          empty["strict_OO"] == 1 and empty["missing_OO"] == 0
          and empty["saved"] == 1
          and empty["shell_end"] == "Exited { code: 0 }")
    row = receipts["real_sz_sends_binary_content_over_crc16"]
    check(label + "/crc16-observed-mutually-exclusive",
          row["incoming_binary16"] and not row["incoming_binary32"]
          and row["strict_OO"] == 1 and row["missing_OO"] == 0)
    record = {
        "status": "PASS",
        "checks": len(common.CHECKS),
        "failed_checks": 0,
        "run": label,
        "candidate_aggregate": freeze["aggregate_sha256"],
        "engineering_input_count": 765,
        "full_source_and_dual_peer_binding_verified": True,
        "passed": passed, "failed": failed,
        "strict_completed_cases": sum(
            row["strict_OO"] == 1 for row in receipts.values()
        ),
        "receipts": receipts,
        "tests_exit": 101 if revision == 5 else 0, "outer_exit": expected_exit,
        "outer_seconds": outer["seconds"],
        "outer_direct_reaped": outer["terminal"]["direct_reaped"],
        "private_directory_currently_absent": True,
        "peer_provenance": peer,
        "FILE05_closed": False,
        "postcondition_limit": (
            "r5 receipts show saved counts; they do not substitute for r6 "
            "postcondition-before-completed content and per-file checks."
            if revision == 5 else
            "r6 passed every test including content/postcondition assertions. "
            "Its observed missing_OO count is zero; this run does not "
            "exercise missing-OO postcondition reporting. Source order and "
            "current fixture implementation remain Fermat's review scope."
        ),
        "fresh_SSH_executions": 0,
        "cleanup_limit": "Receipt checks and directory absence; no independent historical kernel census",
    }
    for name, value in (
        (f"lrzsz-r{revision}-audit.json", record),
        (f"lrzsz-r{revision}-checks.json", common.CHECKS),
        (f"lrzsz-r{revision}-evidence.json", common.EVIDENCE),
    ):
        with (OUTPUT / name).open("x") as destination:
            json.dump(value, destination, indent=2)
            destination.write("\n")
    print(json.dumps({
        "run": label, "status": "PASS", "checks": len(common.CHECKS),
        "passed": len(passed), "failed": len(failed),
        "strict_completed_cases": record["strict_completed_cases"],
        "candidate_aggregate": freeze["aggregate_sha256"],
        "outer_seconds": outer["seconds"], "FILE05_closed": False,
    }, indent=2))


if __name__ == "__main__":
    main()
