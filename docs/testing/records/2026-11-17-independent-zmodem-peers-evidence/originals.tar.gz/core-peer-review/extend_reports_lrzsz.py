"""Extend the saved core decision with separately bound lrzsz r5/r6 evidence."""

import datetime
import json
from pathlib import Path

OUTPUT = Path(__file__).resolve().parent
ROOT = OUTPUT.parents[1]


def load(name):
    return json.loads((OUTPUT / name).read_bytes())


decision = load("decision.json")
summary = load("summary.json")
r5 = load("lrzsz-r5-audit.json")
r6 = load("lrzsz-r6-audit.json")
binding = load("final-binding-r6.json")
assert r5["status"] == r6["status"] == "PASS"
assert binding["core_unchanged_from_r2"]
for name in ("decision", "summary"):
    original = (OUTPUT / (name + ".json")).read_bytes()
    with (OUTPUT / (name + "-through-sexyz-r3.json")).open("xb") as destination:
        destination.write(original)

new_boundaries = [
    "Core source approval covers exactly the two unchanged core files; Fermat owns source review of the three fixture/runner files and later postcondition changes.",
    "r3, r5 and r6 peer observations bind to their respective frozen inputs only. They do not retrospectively or prospectively sign other revisions.",
    "Current zmodem_openssh.rs differs from frozen r6. Its later changes need Fermat's review and their own input/run binding; the two core files remain unchanged.",
    "lrzsz r5's missing-OO failures remain FAILED even though peer exit was 0 and saved counts were 3/1.",
    "lrzsz r6 is one actual 10/10 strict run. No missing-OO event was observed in r6, so it does not itself exercise postcondition reporting on a missing-OO failure.",
    "r5 missing OO followed by r6 actual OO is not proof that the old nondeterministic direct-PTY boundary is fixed or that later runs will pass.",
    "Saved-file counts alone do not establish all file postconditions. The exact frozen test's passing assertions and reviewed source define each run's content/review guarantee.",
    "lrzsz source provenance was checked as opaque file/archive hashes. Official HTTPS provenance is retained; an independently published signed checksum was not verified.",
    "No lrzsz/SSH execution, independent peer rebuild, native desktop, Linux/Windows, production, installation or release was performed by this reviewer.",
]
old_boundaries = [
    text for text in decision["unverified_boundaries"]
    if not text.startswith((
        "Only two core files", "Current engineering inputs",
        "r1/r2 cannot", "No lrzsz new matrix",
    ))
]
boundaries = new_boundaries + old_boundaries
counts = dict(decision["validation_command_counts"])
counts.update({
    "offline_python": 13,
    "total_including_driver_and_child_binary_invocations": 15,
    "exit_zero": 11,
    "exit_nonzero": 4,
})
extra_commands = [
    {
        "id": "V11", "kind": "offline_python", "exit": 0, "checks": r5["checks"],
        "command": ["python3", "-B", str(OUTPUT / "audit_lrzsz_receipts.py"), "5"],
    },
    {
        "id": "V12", "kind": "offline_python", "exit": 0, "checks": r6["checks"],
        "command": ["python3", "-B", str(OUTPUT / "audit_lrzsz_receipts.py"), "6"],
    },
    {
        "id": "V13", "kind": "offline_python", "exit": 0,
        "purpose": "Final r6 canonical/current/core/binary/target/Git binding",
    },
]
decision.update({
    "updated_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "latest_reviewed_peer_freeze": {
        "name": "candidate-inputs-r6.json", "count": 765,
        "aggregate_sha256": r6["candidate_aggregate"],
        "canonical_and_full_run_binding_verified": True,
        "current_full_engineering_binding": binding["current_matches_r6"],
    },
    "current_binding": binding,
    "unverified_boundaries": boundaries,
    "validation_command_counts": counts,
    "validation_commands": decision["validation_commands"] + extra_commands,
    "additional_real_peer_evidence": [r5, r6],
    "offline_audit": {
        "successful_check_executions": 4138 + r5["checks"] + r6["checks"],
        "unique_check_count_claimed": False,
        "checks_by_audit": {
            "initial_sexyz_core_and_provenance": 4138,
            "lrzsz_r5": r5["checks"], "lrzsz_r6": r6["checks"],
        },
        "note": "Includes repeated lrzsz source/build provenance checks in r5 and r6.",
        "failed_checks_in_successful_audits": 0,
    },
})
decision["known_interoperability_failures"].append({
    "status": "OPEN / HISTORICAL_FAILURE_PRESERVED",
    "classification": "lrzsz direct-PTY strict-farewell limitation; not a new core-source finding",
    "run": "mac-lrzsz-r5",
    "trigger": "Three-file batch and CRC32 single download end with missing_OO=1",
    "observed": "saved=3/1, strict_OO=0, peer exit 0; strict Finished assertions fail",
    "impact": "r5 matrix remains 8 passed / 2 failed, exit 101; exit 0 does not establish strict completion",
    "later_observation": "r6 is independently bound 10/10 with actual OO; r5 failure and broad OPEN boundary remain",
    "evidence": [{
        "file": str(ROOT / "work/zmodem-independent-peer-20261117/mac-lrzsz-r5/tests.log"),
        "start_line": 56, "end_line": 74,
    }],
})
summary.update({
    "updated_utc": decision["updated_utc"],
    "latest_reviewed_peer_freeze": decision["latest_reviewed_peer_freeze"],
    "current_binding": binding,
    "additional_peer_runs": [r5, r6],
    "lrzsz_conclusions": {
        "r5": "8 passed / 2 failed; batch saved=3 and CRC32 saved=1 both missing_OO=1 with peer exit 0. Strict Finished assertion failures preserved.",
        "r6": "10 passed / 0 failed; 7 strict completed cases, 3 cancel/preserve cases; all missing_OO=0; outer 0/reaped/10.603835624991916s.",
        "empty_file": "lrzsz r5/r6 individually reviewed empty download strict_OO=1, saved=1. SexyZ's empty-file rejection cannot be generalized to all core receivers.",
        "old_OO_boundary": "OPEN. One later strict pass does not overwrite the earlier missing-OO failure or prove deterministic reliability.",
        "postcondition_boundary": r6["postcondition_limit"],
        "latest_source_boundary": "Current fixture differs from frozen r6; Fermat review and the next freeze/run remain separate.",
        "evidence_locations": [
            {"file": str(ROOT / "work/zmodem-independent-peer-20261117/mac-lrzsz-r5/tests.log"), "start_line": 56, "end_line": 74},
            {"file": str(ROOT / "work/zmodem-independent-peer-20261117/mac-lrzsz-r6/tests.log"), "start_line": 19, "end_line": 63},
        ],
    },
    "offline_check_executions": decision["offline_audit"],
    "validation_command_counts": counts,
    "unverified_boundaries": boundaries,
})
summary["artifacts"].extend([
    "decision-through-sexyz-r3.json", "summary-through-sexyz-r3.json",
    "lrzsz-r5-audit.json", "lrzsz-r5-checks.json", "lrzsz-r5-evidence.json",
    "lrzsz-r6-audit.json", "lrzsz-r6-checks.json", "lrzsz-r6-evidence.json",
    "final-binding-r6.json",
])
for name, value in (("decision.json", decision), ("summary.json", summary)):
    (OUTPUT / name).write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n"
    )
print(json.dumps({
    "decision": decision["decision"], "severity_counts": decision["severity_counts"],
    "core_rerun": "106/0/0", "offline_check_executions": 5091,
    "lrzsz_r5": "8 passed / 2 failed", "lrzsz_r6": "10 passed / 0 failed",
    "current_matches_frozen_r6": binding["current_matches_r6"],
    "bounded_delivery_allowed": True, "FILE05_closed": False,
}, indent=2))
