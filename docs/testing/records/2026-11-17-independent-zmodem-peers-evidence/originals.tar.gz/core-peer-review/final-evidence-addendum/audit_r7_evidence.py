"""Read saved r7 receipts and hash inputs; never run Cargo, SSH, or peers."""

import ast
import binascii
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
REVIEW = OUT.parent
ROOT = REVIEW.parents[1]
PARENT = ROOT / "work/zmodem-independent-peer-20261117"
HEAD = "ac7ec43e6a42329417a99b5933bc171faa19caf6"
AGGREGATE = "7ae00377c1eb95929710c7d8170d444ea293f8c27a3c8690cb83aa79bde3ede6"
CORE = {
    "crates/keelshell-core/src/zmodem.rs":
        "02d9e100a8353ba8badb04093579cfa3fe1313b5a25b080d01971435360a4a7a",
    "crates/keelshell-core/tests/zmodem.rs":
        "255be4b0ada57b68505f896a70146adb6db6f371f00a4791c16c15857e4e6f70",
}
CASES = [
    "real_rz_cancel_before_source_review_does_not_create_files",
    "real_rz_receives_a_reviewed_empty_file",
    "real_rz_receives_reviewed_binary_and_unicode_batch",
    "real_sz_cancel_after_one_saved_file_does_not_accept_the_next_offer",
    "real_sz_download_batch_requires_a_separate_review_and_save_for_each_file",
    "real_sz_existing_local_destination_is_preserved_and_peer_cancelled",
    "real_sz_returns_to_the_same_shell_after_a_bounded_receive_farewell",
    "real_sz_sends_an_individually_reviewed_empty_file",
    "real_sz_sends_binary_content_over_crc16",
    "real_sz_sends_binary_unicode_content_over_crc32",
]
CHECKS = []
EVIDENCE = {}


def check(name, condition, detail=None):
    CHECKS.append({"name": name, "passed": bool(condition), "detail": detail})
    if not condition:
        raise AssertionError(f"{name}: {detail}")


def digest_bytes(data):
    return hashlib.sha256(data).hexdigest()


def mark(path):
    path = Path(path)
    data = path.read_bytes()
    EVIDENCE[str(path.relative_to(ROOT))] = {
        "bytes": len(data), "sha256": digest_bytes(data)
    }
    return data


def read_json(path):
    return json.loads(mark(path))


def location(path, line, end=None):
    result = {"file": str(path), "start_line": line}
    if end is not None:
        result["end_line"] = end
    return result


def write_new(name, value):
    path = OUT / name
    with path.open("x") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def canonical(inputs):
    return digest_bytes(
        json.dumps(inputs, sort_keys=True, separators=(",", ":")).encode()
    )


def outer_receipt(label, expected_exit):
    outer = read_json(PARENT / f"{label}.json")
    data = mark(PARENT / f"{label}.log")
    check(label + "/log-binding",
          outer["log_bytes"] == len(data)
          and outer["log_sha256"] == digest_bytes(data))
    check(label + "/exit",
          outer["observed_exit"] == outer["controller_exit"] == expected_exit)
    terminal = outer["terminal"]
    check(label + "/actual-terminal",
          terminal["direct_reaped"] and terminal["active_processes"] == 0
          and terminal["pipes_drained"] and not terminal["errors"]
          and not outer["errors"] and not outer["timed_out"]
          and not outer["interrupted"])
    check(label + "/checkout-and-target",
          outer["cwd"] == str(ROOT)
          and outer["cargo_target"] == str(
              ROOT / "work/recovery-batch-integration-20261115/target")
          and outer["cargo_owner_checkout_unchanged"])
    return outer, data.decode()


def sections(text):
    result = {}
    for match in re.finditer(
        r"^---- (real_\w+) stdout ----\n(.*?)(?=^---- real_|^\nfailures:\n|\Z)",
        text, re.M | re.S,
    ):
        name, body = match.groups()
        check("log/no-duplicate-section/" + name, name not in result)
        start = text[:match.start()].count("\n") + 1
        result[name] = {
            "text": body, "heading_line": start,
            "end_line": start + match.group(0).count("\n"),
        }
    return result


def audit_run(peer, frozen):
    label = f"mac-{peer}-r7"
    folder = PARENT / label
    result = read_json(folder / "result.json")
    binding = read_json(PARENT / f"{label}-binding.json")
    outer, outer_text = outer_receipt(f"mac-{peer}-test-r7", 1)
    check(label + "/outer-command",
          outer["command"] == [
              "python3", "-B",
              f"work/zmodem-independent-peer-20261117/run_{peer}_mac.py", label,
          ])
    outer_lines = outer_text.splitlines()
    check(label + "/embedded-binding-summary-is-exact",
          json.loads(outer_lines[-1]) == {
              key: value for key, value in binding.items()
              if key not in ("source_inputs_before", "source_inputs_after")
          })
    check(label + "/full-765-input-before-after-binding",
          binding["source_inputs_before"] == binding["source_inputs_after"]
          == frozen and binding["unchanged"])
    check(label + "/head", binding["source"] == HEAD)
    check(label + "/no-new-chats-or-worktrees",
          binding["new_user_chats"] == binding["new_worktrees"] == 0)
    check(label + "/no-relay-declared-recipe",
          binding["pipeline"] ==
          "Peer fd0/fd1 directly on the SSH raw PTY; stderr on an owned regular file")
    check(label + "/failed-status-preserved",
          result["outcome"] == "failed" and binding["runner_exit"] == 1
          and result["steps"][-1] == {"name": "tests", "returncode": 101})
    check(label + "/setup-step-statuses",
          [r["name"] for r in result["steps"][:-1]] == [
              "openssh-version", "generate-host-key", "generate-client-key",
              "validate-sshd-config",
          ] and all(r["returncode"] == 0 for r in result["steps"][:-1]))
    check(label + "/platform-and-argv",
          result["platform"] == "Darwin" and result["command"] == [
              "cargo", "test", "-p", "keelshell-session", "--test",
              "zmodem_openssh", "--locked", "--", "--ignored",
              "--test-threads=1", "--show-output",
          ])
    for name, size in result["logs"].items():
        data = mark(folder / name)
        check(label + "/log-bytes/" + name, len(data) == size)
    cleanup = result["cleanup"]
    check(label + "/cleanup-receipt",
          cleanup["observed_processes_stopped"]
          and cleanup["owned_processes_stopped"]
          and cleanup["temporary_directory_removed"]
          and cleanup["ancestry_unverified"] == [])
    temporary = Path(result["temporary_directory"])
    check(label + "/owned-private-directory-currently-absent",
          temporary.is_relative_to(ROOT / "work/.openssh-private")
          and not temporary.exists() and not temporary.is_symlink())
    for direction in ("rz", "sz"):
        row = result["zmodem_peers"][direction]
        executable = Path(row["path"])
        check(label + "/peer-binary/" + direction,
              digest_bytes(mark(executable)) == row["sha256"]
              and executable.stat().st_size == row["bytes"])
        if peer == "lrzsz":
            upper = direction.upper()
            check(label + "/dual-peer-before-after/" + direction,
                  binding["peer_sha256_before"][upper]
                  == binding["peer_sha256_after"][upper] == row["sha256"])
            check(label + "/peer-argv/" + direction, row["args"] == ["-b", "-vv"])
        else:
            check(label + "/peer-before-after/" + direction,
                  binding["peer_sha256_before"] == binding["peer_sha256_after"]
                  == row["sha256"])
            check(label + "/peer-argv/" + direction,
                  row["args"] == (
                      ["-raw", "-e", "rz", "./"] if direction == "rz"
                      else ["-raw", "sz"]))
    log = mark(folder / "tests.log").decode()
    statuses = re.findall(r"^test (real_\w+) \.\.\. (ok|FAILED)$", log, re.M)
    check(label + "/exact-ten-case-names",
          [name for name, _ in statuses] == CASES)
    passed = [name for name, status in statuses if status == "ok"]
    failed = [name for name, status in statuses if status == "FAILED"]
    expected_failed = {CASES[7]} if peer == "lrzsz" else {CASES[4], CASES[7]}
    expected_passes = 9 if peer == "lrzsz" else 8
    check(label + "/actual-passed-failed-counts",
          set(failed) == expected_failed and len(passed) == expected_passes
          and f"{expected_passes} passed; {len(expected_failed)} failed; "
          "0 ignored; 0 measured; 8 filtered out;" in log)
    blocks = sections(log)
    check(label + "/every-case-has-original-output", set(blocks) == set(CASES))
    receipts = {}
    pattern = re.compile(
        r"^peer receipt: first_data_header=(None|Some\(Binary(?:16|32)\)); "
        r"strict_OO=(\d+); missing_OO=(\d+); saved=(\d+); shell_end=(.+)$",
        re.M,
    )
    for name, block in blocks.items():
        matches = list(pattern.finditer(block["text"]))
        check(label + "/at-most-one-receipt/" + name, len(matches) <= 1)
        if matches:
            match = matches[0]
            fmt, strict, missing, saved, end = match.groups()
            receipts[name] = {
                "first_data_header": fmt, "strict_OO": int(strict),
                "missing_OO": int(missing), "saved": int(saved), "shell_end": end,
                "evidence": location(
                    folder / "tests.log",
                    block["heading_line"] + 1
                    + block["text"][:match.start()].count("\n"),
                ),
            }
    expected_receipt_names = set(CASES) if peer == "lrzsz" else set(passed)
    check(label + "/receipt-completeness",
          set(receipts) == expected_receipt_names)
    for name in passed:
        if name not in {CASES[0], CASES[3], CASES[5]}:
            row = receipts[name]
            check(label + "/actual-OO/" + name,
                  row["strict_OO"] == 1 and row["missing_OO"] == 0
                  and row["shell_end"] == "Exited { code: 0 }")
    for name, fmt in ((CASES[8], "Some(Binary16)"), (CASES[9], "Some(Binary32)")):
        row = receipts[name]
        check(label + "/first-ZDATA-vector-classification/" + name,
              row["first_data_header"] == fmt and row["saved"] == 1
              and row["strict_OO"] == 1 and row["missing_OO"] == 0)
    shell = receipts[CASES[6]]
    check(label + "/same-shell-actual-OO-and-one-save",
          shell["strict_OO"] == 1 and shell["missing_OO"] == 0
          and shell["saved"] == 1
          and "interactive receive outcome: strict_OO=1; "
          "missing_optional_OO=0; same_shell_continued=true"
          in blocks[CASES[6]]["text"])
    if peer == "lrzsz":
        batch = receipts[CASES[4]]
        check(label + "/complete-batch-saved-three-and-OO",
              batch["saved"] == 3 and batch["strict_OO"] == 1
              and batch["missing_OO"] == 0)
        empty = receipts[CASES[7]]
        check(label + "/exit-zero-never-substitutes-for-OO",
              empty["strict_OO"] == 0 and empty["missing_OO"] == 1
              and empty["saved"] == 1
              and empty["shell_end"] == "Exited { code: 0 }")
        check(label + "/empty-failure-is-final-Finished-assertion",
              "crates/keelshell-session/tests/zmodem_openssh.rs:499:5"
              in blocks[CASES[7]]["text"]
              and "assertion failed: report.events.iter().any("
              "|event| matches!(event, Ui::Finished { .. }))"
              in blocks[CASES[7]]["text"])
    else:
        for name in expected_failed:
            check(label + "/empty-ZRPOS0-rejection/" + name,
                  "Received INVALID ZRPOS offset: 0" in blocks[name]["text"]
                  and "real peer transfer rejected: Failed" in blocks[name]["text"]
                  and 'name: \\"empty.bin\\", size: 0' in blocks[name]["text"])
    failure_evidence = [
        {
            "case": name,
            "evidence": location(
                folder / "tests.log",
                blocks[name]["heading_line"],
                blocks[name]["end_line"],
            ),
        }
        for name in failed
    ]
    return {
        "label": label, "passed": passed, "failed": failed,
        "passed_count": len(passed), "failed_count": len(failed),
        "ignored": 0, "filtered_out": 8, "tests_exit": 101,
        "runner_exit": 1, "outer_exit": outer["observed_exit"],
        "outer_controller_exit": outer["controller_exit"],
        "outer_seconds": outer["seconds"], "outer_terminal": outer["terminal"],
        "runner_elapsed_seconds": result["elapsed_seconds"],
        "source_before_after_matches_r7": True,
        "peer_before_after_matches_binary": True,
        "baseline_head": binding["source"], "peer_recipes": result["zmodem_peers"],
        "receipts": receipts,
        "strict_completed_cases": sum(row["strict_OO"] for row in receipts.values()),
        "missing_OO_cases": sum(row["missing_OO"] for row in receipts.values()),
        "cleanup_receipt": cleanup,
        "private_directory": str(temporary),
        "private_directory_currently_absent": True,
        "failure_evidence": failure_evidence,
        "evidence_scope": (
            "Original parent execution receipts audited offline; reviewer ran no "
            "SSH or peer. Header classifications are frozen fixture observations, "
            "not independently re-decoded success packet captures."
        ),
    }


def main():
    start = time.monotonic()
    preserved = read_json(OUT / "preserved-base-and-scope.json")
    for row in preserved["existing_files_to_preserve"]:
        data = mark(row["path"])
        check("preserve/" + Path(row["path"]).name,
              len(data) == row["bytes"] and digest_bytes(data) == row["sha256"])
    freeze = read_json(PARENT / "candidate-inputs-r7.json")
    check("freeze/algorithm", freeze["aggregate_algorithm"] ==
          "sha256(json.dumps(inputs, sort_keys=True, separators=(',', ':')).encode())")
    check("freeze/canonical-aggregate",
          canonical(freeze["inputs"]) == freeze["aggregate_sha256"] == AGGREGATE)
    frozen = {row["path"]: row["sha256"] for row in freeze["inputs"]}
    check("freeze/exact-765-unique-paths",
          freeze["count"] == len(freeze["inputs"]) == len(frozen) == 765)
    check("freeze/baseline", freeze["baseline_source"] == HEAD)
    for row in freeze["inputs"]:
        path = ROOT / row["path"]
        check("freeze/contained-regular/" + row["path"],
              not path.is_symlink() and path.resolve().is_relative_to(ROOT))
        data = mark(path)
        check("freeze/current/" + row["path"],
              len(data) == row["bytes"] and digest_bytes(data) == row["sha256"])
    for path, expected in CORE.items():
        check("core/unchanged/" + path, frozen[path] == expected)
    git = subprocess.run(
        ["git", "--no-optional-locks", "rev-parse", "HEAD"],
        cwd=ROOT, capture_output=True, text=True, check=False,
    )
    check("git/read-only-HEAD",
          git.returncode == 0 and git.stdout.strip() == HEAD and not git.stderr)
    initial = read_json(REVIEW / "initial-binding.json")
    target = Path(initial["target_identity"]["path"])
    stat = target.stat()
    check("target/directory-identity-only",
          stat.st_dev == initial["target_identity"]["device"]
          and stat.st_ino == initial["target_identity"]["inode"])
    binary = initial["precompiled_core_binary"]
    path = Path(binary["path"])
    stat = path.stat()
    check("core/precompiled-binary-identity-and-digest",
          stat.st_dev == binary["device"] and stat.st_ino == binary["inode"]
          and stat.st_size == binary["bytes"]
          and digest_bytes(mark(path)) == binary["sha256"])
    provenance_references = {}
    for peer, prior_name, selected in [
        ("sexyz", "evidence-manifest.json", [
            "peer.json", "evidence/source-baseline.json",
            "evidence/build-inputs.json",
        ]),
        ("lrzsz0131", "lrzsz-r6-evidence.json", [
            "peer.json", "evidence/source-manifest.json",
            "evidence/source-integrity.json", "evidence/build-manifest.json",
        ]),
    ]:
        prior = read_json(REVIEW / prior_name)
        for suffix in selected:
            path = ROOT / f"work/zmodem-{peer}-peer-20261117" / suffix
            key = str(path.relative_to(ROOT))
            data = mark(path)
            check("prior-provenance-manifest/" + key,
                  EVIDENCE[key] == prior[key])
            provenance_references[key] = EVIDENCE[key]
    sexyz = read_json(ROOT / "work/zmodem-sexyz-peer-20261117/peer.json")
    lrzsz = read_json(ROOT / "work/zmodem-lrzsz0131-peer-20261117/peer.json")
    for path, expected in [
        (ROOT / "work/zmodem-sexyz-peer-20261117/downloads"
         / f"sbbs-{sexyz['upstream_git_sha']}.tar.gz", sexyz["archive_sha256"]),
        (ROOT / "work/zmodem-lrzsz0131-peer-20261117"
         / lrzsz["official_source"]["archive_path"],
         lrzsz["official_source"]["archive_sha256"]),
    ]:
        check("peer/source-archive-binding/" + path.name,
              digest_bytes(mark(path)) == expected)
    runs = [audit_run(peer, frozen) for peer in ("lrzsz", "sexyz")]
    lrz_binding = read_json(PARENT / "mac-lrzsz-r7-binding.json")
    sexy_binding = read_json(PARENT / "mac-sexyz-r7-binding.json")
    check("lrzsz/archive-provenance",
          lrz_binding["source_archive_sha256"]
          == lrzsz["official_source"]["archive_sha256"])
    check("sexyz/upstream-provenance",
          sexy_binding["upstream_source"] == sexyz["upstream_git_sha"])
    source = mark(ROOT / "crates/keelshell-session/tests/zmodem_openssh.rs").decode()
    golden = {}
    for bits in (16, 32):
        literal = re.search(rf"const DATA{bits}: &\[u8\] = (b\"[^\n]+\");", source)
        check(f"header/golden-constant-present/{bits}", literal is not None)
        wire = ast.literal_eval(literal.group(1))
        data = bytearray()
        offset = 3
        while offset < len(wire):
            byte = wire[offset]
            offset += 1
            if byte == 0x18:
                byte = wire[offset] ^ 0x40
                offset += 1
            data.append(byte)
        check(f"header/ZDATA-offset-zero/{bits}",
              bytes(data[:5]) == b"\x0a\0\0\0\0")
        if bits == 16:
            checksum = binascii.crc_hqx(bytes(data[:5]), 0)
            expected = int.from_bytes(data[5:], "big")
        else:
            checksum = binascii.crc32(bytes(data[:5]))
            expected = int.from_bytes(data[5:], "little")
        check(f"header/independent-vector-CRC/{bits}", checksum == expected)
        golden[str(bits)] = {
            "wire_hex": wire.hex(), "unescaped_header_hex": data.hex(),
            "computed_crc": hex(checksum), "method": (
                "binascii.crc_hqx(init=0), big-endian" if bits == 16
                else "binascii.crc32, little-endian"
            ),
        }
    controls, controls_text = outer_receipt("peer-rust-controls-r7", 0)
    controls_statuses = re.findall(
        r"^test (\w+) \.\.\. (ok|ignored[^\n]*)$", controls_text, re.M)
    check("controls/exact-eighteen-names",
          len(controls_statuses) == len({n for n, _ in controls_statuses}) == 18)
    controls_pass = [n for n, status in controls_statuses if status == "ok"]
    controls_ignore = [n for n, status in controls_statuses if status.startswith("ignored")]
    check("controls/actual-eight-passed-ten-ignored",
          len(controls_pass) == 8 and set(controls_ignore) == set(CASES)
          and "8 passed; 0 failed; 10 ignored;" in controls_text)
    check("controls/both-new-observer-cases-actually-pass", {
        "first_data_header_survives_every_split_and_ignores_opposite_payload_markers",
        "first_data_header_rejects_bad_crc_payload_noise_and_over_budget_prefixes",
    }.issubset(controls_pass))
    historical = []
    for revision, expected_passed, expected_failed in [(5, 8, 2), (6, 10, 0)]:
        previous = read_json(REVIEW / f"lrzsz-r{revision}-audit.json")
        check(f"history/lrzsz-r{revision}-distinct-result",
              len(previous["passed"]) == expected_passed
              and len(previous["failed"]) == expected_failed)
        historical.append({
            "run": f"mac-lrzsz-r{revision}", "passed": expected_passed,
            "failed": expected_failed, "outer_exit": previous["outer_exit"],
            "outer_seconds": previous["outer_seconds"],
            "strict_completed_cases": previous["strict_completed_cases"],
            "candidate_aggregate": previous["candidate_aggregate"],
            "receipts": {
                name: {k: v for k, v in row.items()
                       if k not in ("incoming_binary16", "incoming_binary32")}
                for name, row in previous["receipts"].items()
            },
            "source": str(REVIEW / f"lrzsz-r{revision}-audit.json"),
        })
    for row in preserved["existing_files_to_preserve"]:
        data = mark(row["path"])
        check("preserve-end/" + Path(row["path"]).name,
              len(data) == row["bytes"] and digest_bytes(data) == row["sha256"])
    report = {
        "schema": 1, "status": "PASS",
        "created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "checks": len(CHECKS), "failed_checks": 0,
        "candidate_r7": {
            "path": str(PARENT / "candidate-inputs-r7.json"),
            "count": 765, "aggregate_sha256": AGGREGATE,
            "algorithm": freeze["aggregate_algorithm"],
            "all_current_inputs_match": True,
        },
        "baseline_and_observed_head": HEAD,
        "core_unchanged_sha256": CORE,
        "core_test_binary_currently_unchanged": True,
        "target_directory_identity_unchanged": True,
        "target_whole_tree_snapshot_claimed": False,
        "prior_reports_byte_preserved": preserved["existing_files_to_preserve"],
        "runs": runs, "historical_lrzsz_results": historical,
        "r7_header_golden_CRC_recomputation": golden,
        "parent_default_controls": {
            "passed": controls_pass, "ignored": controls_ignore, "failed": [],
            "exit": 0, "direct_reaped": True, "outer_seconds": controls["seconds"],
            "fresh_execution_by_reviewer": False,
        },
        "prior_provenance_manifests_unchanged": provenance_references,
        "provenance_limit": (
            "Reused previous full opaque-source/build/archive audits; this "
            "addendum checks retained provenance-manifest, archive and executable "
            "digests, not another full source-tree audit or independent build. "
            "No GPL implementation logic was inspected, imported or executed."
        ),
        "readonly_limit": (
            "Read-only product/Git/target; only addendum output files written. "
            "Target directory and core binary identity checks are not a whole "
            "target content snapshot. No historical descriptor/census reconstruction."
        ),
        "seconds": time.monotonic() - start,
    }
    write_new("r7-audit.json", report)
    write_new("r7-checks.json", CHECKS)
    write_new("r7-evidence-manifest.json", EVIDENCE)
    write_new("r7-command.json", {
        "command": ["python3", "-B", str(Path(__file__).resolve())],
        "cwd": str(ROOT), "exit": 0,
        "kind": "offline_python_audit", "checks": len(CHECKS),
        "fresh_SSH": 0, "Cargo": 0, "peer_executions": 0,
    })
    print(json.dumps({
        "status": "PASS", "checks": len(CHECKS), "aggregate": AGGREGATE,
        "runs": [{
            "run": row["label"], "passed": row["passed_count"],
            "failed": row["failed_count"],
            "strict_OO_cases": row["strict_completed_cases"],
            "missing_OO_cases": row["missing_OO_cases"],
            "outer_seconds": row["outer_seconds"],
        } for row in runs],
        "old_decision_and_summary_unchanged": True,
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    try:
        main()
    except BaseException as error:
        failure = OUT / "audit-failure-r1.json"
        if not failure.exists():
            write_new(failure.name, {
                "error": f"{type(error).__name__}: {error}", "checks": CHECKS,
                "classification": "Reviewer audit failure; not a product test",
            })
        raise
