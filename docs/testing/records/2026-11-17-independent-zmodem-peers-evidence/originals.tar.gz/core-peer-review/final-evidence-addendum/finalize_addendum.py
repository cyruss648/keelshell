"""Seal the targeted offline audit and create new, separate review reports."""

import datetime
import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
REVIEW = OUT.parent
ROOT = REVIEW.parents[1]
PARENT = ROOT / "work/zmodem-independent-peer-20261117"
CHECKS = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def check(name, condition):
    CHECKS.append({"name": name, "passed": bool(condition)})
    if not condition:
        raise AssertionError(name)


def write_new(name, value):
    with (OUT / name).open("x") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def loc(path, start, end=None):
    row = {"file": str(ROOT / path), "start_line": start}
    if end is not None:
        row["end_line"] = end
    return row


def main():
    audit = read(OUT / "r7-audit.json")
    checks = read(OUT / "r7-checks.json")
    evidence = read(OUT / "r7-evidence-manifest.json")
    preserved = read(OUT / "preserved-base-and-scope.json")
    check("audit/all-checks-pass",
          audit["status"] == "PASS" and audit["checks"] == len(checks)
          and audit["failed_checks"] == 0 and all(r["passed"] for r in checks))
    stale = []
    for path, expected in evidence.items():
        data = (ROOT / path).read_bytes()
        if len(data) != expected["bytes"] or sha(data) != expected["sha256"]:
            stale.append(path)
    check("seal/all-audited-evidence-and-current-inputs-still-match", not stale)
    for row in preserved["existing_files_to_preserve"]:
        data = Path(row["path"]).read_bytes()
        check("seal/preserved/" + Path(row["path"]).name,
              len(data) == row["bytes"] and sha(data) == row["sha256"])
    git = subprocess.run(
        ["git", "--no-optional-locks", "rev-parse", "HEAD"], cwd=ROOT,
        capture_output=True, text=True, check=False,
    )
    check("seal/read-only-HEAD",
          git.returncode == 0
          and git.stdout.strip() == audit["baseline_and_observed_head"]
          and not git.stderr)
    initial = read(REVIEW / "initial-binding.json")
    stat = Path(initial["target_identity"]["path"]).stat()
    check("seal/target-directory-identity",
          stat.st_dev == initial["target_identity"]["device"]
          and stat.st_ino == initial["target_identity"]["inode"])
    binary = initial["precompiled_core_binary"]
    stat = Path(binary["path"]).stat()
    check("seal/precompiled-core-binary-identity",
          stat.st_dev == binary["device"] and stat.st_ino == binary["inode"]
          and stat.st_size == binary["bytes"])
    for row in audit["runs"]:
        check("seal/private-directory-absent/" + row["label"],
              not Path(row["private_directory"]).exists()
              and not Path(row["private_directory"]).is_symlink())
    check("seal/exact-peer-counts",
          [(r["passed_count"], r["failed_count"]) for r in audit["runs"]]
          == [(9, 1), (8, 2)])
    for name in ("decision.json", "summary.json", "binding.json",
                 "validation-summary.json", "final-verification.json"):
        check("seal/new-output-only/" + name, not (OUT / name).exists())
    failed_attempt = read(OUT / "audit-failure-r1.json")
    old_decision = read(REVIEW / "decision.json")
    new_checks = audit["checks"] + len(CHECKS)
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    command_counts = {
        "addendum": {
            "offline_python_validation_commands": 3,
            "exit_zero": 2, "exit_nonzero": 1,
            "successful_check_executions": new_checks,
            "r7_audit_successful_checks": audit["checks"],
            "final_seal_successful_checks": len(CHECKS),
            "failed_attempt_checks_before_stop": len(failed_attempt["checks"]),
            "failed_attempt_passed_checks": sum(
                r["passed"] for r in failed_attempt["checks"]),
            "failed_attempt_failed_checks": sum(
                not r["passed"] for r in failed_attempt["checks"]),
            "failed_attempt_classification": (
                "Reviewer initially compared outer summarized binding with the "
                "full 765-map JSON. Corrected to compare the exact summary, and "
                "checked full maps separately. Original failure retained; no "
                "product failure or relaxed protocol assertion."
            ),
        },
        "including_preserved_review": {
            "offline_python": 16, "direct_precompiled_core_binary": 2,
            "total": 18, "exit_zero": 13, "exit_nonzero": 5,
            "reviewer_tooling_assumption_failures": 4,
            "correct_noncore_source_drift_guard_stop": 1,
            "successful_offline_check_executions": 5091 + new_checks,
        },
        "counting_rule": (
            "Validation commands only; excludes exploratory reads/Git/hash "
            "inventory commands and report writes. Check executions are not "
            "unique test cases and include repeated provenance/binding checks. "
            "Failed-attempt partial checks are reported separately, not added "
            "to successful-audit totals."
        ),
        "Cargo": 0, "fmt": 0, "Clippy": 0, "SSH_product_tests": 0,
        "peer_build_or_execution": 0,
        "core_binary_executions_this_addendum": 0,
    }
    retraction = {
        "status": "EXPLICITLY_RETRACTED_AND_SUPERSEDED",
        "origin": "Fermat raw-marker/payload finding reported by parent",
        "affected_revisions": ["SexyZ r3", "lrzsz r5", "lrzsz r6"],
        "affected_fields": ["incoming_binary16", "incoming_binary32"],
        "withdrawn_claim": (
            "Those raw-marker booleans or their mutually exclusive values "
            "prove actual incoming CRC16/CRC32 header format."
        ),
        "corrected_meaning": (
            "Marker occurrence only. File payload may contain the same bytes. "
            "All stronger format interpretations in preserved review artifacts "
            "and old audit check labels are withdrawn."
        ),
        "unaffected": [
            "Actual strict_OO / missing_OO classification, saved counts and exits",
            "Independently recomputed core captured ZFILE header/data CRCs",
            "Previously executed 106 core tests and the core source approval",
        ],
        "preservation": (
            "Original decision.json and summary.json remain byte-identical "
            "as requested; this addendum takes precedence for evidence meaning."
        ),
    }
    header_scope = {
        "revision": "r7 only",
        "claim": (
            "Each peer's CRC16 and CRC32 nonempty single-download test passed "
            "the expected first-ZDATA format assertion, exact content assertion "
            "and strict completion assertion; receipts independently expose "
            "Some(Binary16)/Some(Binary32) with strict_OO=1/missing_OO=0."
        ),
        "observer_contract": (
            "Armed after the single-file Review; bounded to 96 prefix bytes. "
            "Skips only leading flow-control/CR/LF bytes and accepts 1-2 pads, "
            "then matches the entire offset-zero ZDATA header vector including "
            "CRC at the first header position. No payload marker search."
        ),
        "source_evidence": [
            loc("crates/keelshell-session/tests/zmodem_openssh.rs", 78, 108),
            loc("crates/keelshell-session/tests/zmodem_openssh.rs", 332, 338),
            loc("crates/keelshell-session/tests/zmodem_openssh.rs", 577, 594),
        ],
        "golden_vector_independent_CRC": audit["r7_header_golden_CRC_recomputation"],
        "parent_default_controls": audit["parent_default_controls"],
        "limits": [
            "Source correctness of these other three files remains Fermat's scope.",
            "Success logs expose fixture classifications, not complete raw success packet captures for independent re-decoding.",
            "First-ZDATA observation is not a claim about every later frame, all uploads, empty-file ZDATA, or all batch files.",
            "first_data_header=None means not observed/armed here; it is not proof that the peer used no binary header.",
            "No previous revision inherits r7 observations, and r7 does not inherit old raw-marker format evidence.",
        ],
    }
    open_limits = [
        {
            "id": "LRZSZ_STRICT_OO_REPEATABILITY",
            "status": "OPEN",
            "classification": "Observed interoperability boundary; no new core-diff finding",
            "trigger": "lrzsz r7 individual empty download completes file content but lacks observed OO",
            "observed": "saved=1, strict_OO=0, missing_OO=1, peer exit 0",
            "impact": "Strict Finished assertion fails; r7 suite remains FAILED with 9/10 passes",
            "evidence": [
                loc("work/zmodem-independent-peer-20261117/mac-lrzsz-r7/tests.log", 60, 71),
                loc("crates/keelshell-session/tests/zmodem_openssh.rs", 497, 512),
                loc("crates/keelshell-session/tests/zmodem_openssh.rs", 593, 594),
            ],
            "content_scope": (
                "The frozen receive helper's content assertion precedes completed; "
                "the failure at completed's Finished assertion shows that exact "
                "empty content assertion was reached and passed in this run. "
                "Saved1 or peer exit0 alone would not establish this."
            ),
            "history": "Keep r5 8/10, r6 10/10, r7 9/10 separately bound; no deterministic compatibility claim.",
            "root_cause": "Not established; no GPL implementation logic inspected or independent runtime trace",
        },
        {
            "id": "SEXYZ_EMPTY_ZRPOS0",
            "status": "OPEN",
            "classification": "Observed interoperability boundary; no new core-diff finding",
            "trigger": "SexyZ sends an individual empty file or the empty third batch file",
            "observed": "Both diagnostics explicitly report Received INVALID ZRPOS offset: 0",
            "impact": "Individual empty download and full three-file batch fail; r7 suite remains FAILED with 8/10 passes",
            "evidence": [
                loc("work/zmodem-independent-peer-20261117/mac-sexyz-r7/tests.log", 56, 60),
                loc("work/zmodem-independent-peer-20261117/mac-sexyz-r7/tests.log", 63, 67),
            ],
            "limits": (
                "No synthetic receipt for the two failed transfers. The batch's "
                "prior events show partial progress, not successful saving or "
                "review validation of the entire batch. lrzsz r5/r6 empty "
                "success prevents universal attribution to core empty-file handling."
            ),
            "root_cause": "Peer rejection observed; complete ownership not established",
        },
    ]
    boundaries = [
        "This source approval covers exactly two byte-identical core files. Fermat owns the current three-file source review; this addendum does not replace it.",
        "No independent clean Rust build, Cargo/fmt/Clippy, SSH/peer execution, native desktop, Linux/Windows, production, installation, signing or release validation by this reviewer.",
        "Previously rerun 106 core tests used a parent-precompiled binary with matching source names, binary inventory and hashes; it was not a clean independent build. No repeat in this addendum.",
        "r5, r6 and r7 freeze aggregates differ in fixture inputs; core remains unchanged. Preserve each run against its own input set; these are not identical full-input repetitions.",
        "lrzsz r6's 10/10 result is real and retained; r7's missing-OO failure shows the overall compatibility/farewell boundary remains OPEN.",
        "Full batch per-file review/save/content claims rely on the frozen test assertions and its actual passed result, not saved count alone. r7 lrzsz reaches and passes all per-file checks before completed.",
        "No independent complete historical kernel birth-identity census or detached-descendant reconstruction. Verified saved cleanup flags, outer reaped/active0 and present private-directory absence.",
        "Direct raw PTY/no-relay is the recorded recipe and existing reviewed fixture, not a separately observed historical fd table.",
        "Provenance reuses previous full opaque source/build/archive verification; new checks cover retained provenance manifests, archives, actual executables and both runs' before/after hashes. No independent peer rebuild or GPL logic inspection/import.",
        "Official lrzsz archive provenance is retained HTTPS evidence; no independently published signed checksum was verified.",
        "Target directory/core-binary identities remained equal; no whole target-tree content snapshot claimed. Reviewer wrote only this permitted addendum directory.",
        "Latest full dependency freshness remains UNKNOWN: r1 partial 42/113 pass and 71 failures remain; r2 timeout124/reaped with null observed child exit and no report cannot replace it.",
        "Parent owns documentation, final gate, CI and delivery; this review is complete without waiting for those separate results.",
    ]
    binding = {
        "schema": 1, "created_utc": now,
        "candidate_r7": audit["candidate_r7"],
        "baseline_and_final_observed_head": audit["baseline_and_observed_head"],
        "core_unchanged_sha256": audit["core_unchanged_sha256"],
        "both_peer_source_before_after_match": True,
        "both_peer_binary_before_after_match": True,
        "prior_reports": audit["prior_reports_byte_preserved"],
        "prior_reports_preserved": True,
        "all_evidence_still_matches_at_seal": True,
        "target_directory_identity_unchanged": True,
        "core_test_binary_identity_unchanged": True,
        "target_whole_tree_snapshot_claimed": False,
        "evidence_manifest": str(OUT / "r7-evidence-manifest.json"),
        "reviewer_write_scope": str(OUT),
    }
    decision = {
        "schema": 1, "created_utc": now,
        "reviewer_role": "Independent non-author core / peer evidence reviewer",
        "review_complete": True, "parent_may_close_reviewer": True,
        "decision": "APPROVE_WITH_BOUNDARIES",
        "source_decision": "UNCHANGED_TWO_CORE_FILES_APPROVED",
        "evidence_decision": "ACCEPT_SCOPED_R7_ORIGINALS_WITH_FAILURES_PRESERVED",
        "findings": [], "severity_counts": {"P0": 0, "P1": 0, "P2": 0, "P3": 0},
        "finding_scope": "New findings in the two reviewed core files; known peer limitations listed separately",
        "source_scope": audit["core_unchanged_sha256"],
        "source_checks": old_decision["source_checks"],
        "binding": binding, "superseding_evidence_correction": retraction,
        "r7_header_evidence_scope": header_scope,
        "r7_peer_runs": audit["runs"],
        "historical_lrzsz_results": audit["historical_lrzsz_results"],
        "known_interoperability_boundaries": open_limits,
        "bounded_delivery_allowed": True,
        "bounded_delivery_scope": (
            "The frozen metadata compatibility fix and an honest, limited "
            "macOS raw-PTY peer-evidence package. Keep both matrices' failures, "
            "old missing-OO failures, retraction and unverified boundaries explicit."
        ),
        "merge_recommendation": (
            "Approve exactly these unchanged core files and this bounded evidence. "
            "Parent separately consumes Fermat's source review and performs final "
            "gate/CI/delivery. Do not sign broad deterministic peer compatibility."
        ),
        "FILE05_closed": False, "FILE05_status": "OPEN / PARTIAL",
        "latest_full_dependency_freshness": "UNKNOWN",
        "validation": command_counts,
        "unverified_boundaries": boundaries,
        "original_decision_preserved": str(REVIEW / "decision.json"),
        "original_summary_preserved": str(REVIEW / "summary.json"),
    }
    summary = {
        "schema": 1, "created_utc": now, "review_complete": True,
        "decision": decision["decision"], "severity_counts": decision["severity_counts"],
        "candidate_r7": audit["candidate_r7"],
        "core_unchanged_sha256": audit["core_unchanged_sha256"],
        "core_validation_retained": {
            "passed": 106, "failed": 0, "ignored": 0,
            "fresh_execution_in_addendum": False,
            "origin": "Earlier independent execution of parent-precompiled core binary",
            "independent_clean_build": False,
        },
        "superseding_evidence_correction": retraction,
        "peer_runs": [{
            key: row[key] for key in [
                "label", "passed_count", "failed_count", "ignored", "filtered_out",
                "tests_exit", "runner_exit", "outer_exit", "outer_seconds",
                "outer_terminal", "strict_completed_cases", "missing_OO_cases",
                "failed", "failure_evidence",
            ]
        } for row in audit["runs"]],
        "r7_header_evidence_scope": header_scope,
        "lrzsz_repeatability": {
            "r5": {"passed": 8, "failed": 2, "outer_exit": 1},
            "r6": {"passed": 10, "failed": 0, "outer_exit": 0},
            "r7": {"passed": 9, "failed": 1, "outer_exit": 1},
            "status": "OPEN / NOT_ESTABLISHED_DETERMINISTIC",
            "interpretation": "Distinct freezes with unchanged core; retain all actual outcomes",
        },
        "postconditions": {
            "lrzsz_r7_batch": (
                "Passed all 3 per-file distinct offer/review IDs, transfer/path/name/"
                "size/direction/order, FileSaved SHA-256 and exact file content "
                "assertions before strict completed; saved3/strictOO1."
            ),
            "lrzsz_r7_empty": "Exact empty-content assertion passed before strict Finished failed; saved1/missingOO1/exit0 remains FAILED.",
            "sexyz_r7_batch": "Rejected at empty third file; no complete three-file postcondition acceptance.",
            "source_locations": [
                loc("crates/keelshell-session/tests/zmodem_openssh.rs", 735, 821),
                loc("crates/keelshell-session/tests/zmodem_openssh.rs", 593, 594),
            ],
        },
        "known_interoperability_boundaries": open_limits,
        "validation": command_counts,
        "bounded_delivery_allowed": True,
        "FILE05_closed": False, "FILE05_status": "OPEN / PARTIAL",
        "latest_full_dependency_freshness": "UNKNOWN",
        "unverified_boundaries": boundaries,
        "preserved_base_report_hashes": audit["prior_reports_byte_preserved"],
        "artifacts": {
            "decision": str(OUT / "decision.json"), "binding": str(OUT / "binding.json"),
            "audit": str(OUT / "r7-audit.json"), "checks": str(OUT / "r7-checks.json"),
            "manifest": str(OUT / "r7-evidence-manifest.json"),
            "original_decision": str(REVIEW / "decision.json"),
            "original_summary": str(REVIEW / "summary.json"),
        },
    }
    write_new("decision.json", decision)
    write_new("summary.json", summary)
    write_new("binding.json", binding)
    write_new("validation-summary.json", command_counts)
    created = {
        name: {"bytes": len((OUT / name).read_bytes()),
               "sha256": sha((OUT / name).read_bytes())}
        for name in ("decision.json", "summary.json", "binding.json",
                     "validation-summary.json", "r7-audit.json",
                     "r7-checks.json", "r7-evidence-manifest.json")
    }
    write_new("final-verification.json", {
        "status": "PASS", "created_utc": now, "exit": 0,
        "command": ["python3", "-B", str(Path(__file__).resolve())],
        "checks": CHECKS, "successful_checks": len(CHECKS), "failed_checks": 0,
        "created_report_hashes": created,
        "all_audited_evidence_unchanged": True,
        "preserved_base_reports_unchanged": True,
        "review_complete": True,
    })
    print(json.dumps({
        "decision": decision["decision"], "review_complete": True,
        "severity_counts": decision["severity_counts"],
        "r7_aggregate": audit["candidate_r7"]["aggregate_sha256"],
        "new_successful_offline_checks": new_checks,
        "new_validation_commands": 3,
        "new_validation_exit_zero": 2, "new_validation_exit_nonzero": 1,
        "retained_decision_and_summary_unchanged": True,
        "FILE05_closed": False,
        "reports": [str(OUT / "decision.json"), str(OUT / "summary.json")],
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
