"""Read-only rerun of the parent's already compiled core integration binary."""

import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time

OUTPUT = Path(__file__).resolve().parent
ROOT = OUTPUT.parents[1]
BINARY = ROOT / (
    "work/recovery-batch-integration-20261115/target/debug/build/"
    "keelshell-core/d94a23b1305857e7/out/zmodem-d94a23b1305857e7"
)
SOURCE = ROOT / "crates/keelshell-core/tests/zmodem.rs"


def identity(path):
    stat = path.stat()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "bytes": stat.st_size,
        "device": stat.st_dev,
        "inode": stat.st_ino,
        "mtime_ns": stat.st_mtime_ns,
    }


def run(label, arguments):
    before = identity(BINARY)
    started = time.monotonic()
    log = OUTPUT / (label + ".log")
    environment = dict(os.environ)
    environment.update({
        "TMPDIR": str(OUTPUT / "tmp"),
        "PYTHONDONTWRITEBYTECODE": "1",
        "RUST_BACKTRACE": "0",
    })
    timed_out = False
    with log.open("xb") as destination:
        process = subprocess.Popen(
            [str(BINARY), *arguments],
            cwd=OUTPUT,
            env=environment,
            stdout=destination,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )
        try:
            exit_code = process.wait(timeout=45)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGKILL)
            exit_code = process.wait(timeout=5)
    try:
        os.killpg(process.pid, 0)
        process_group_absent = False
    except ProcessLookupError:
        process_group_absent = True
    after = identity(BINARY)
    record = {
        "label": label,
        "command": [str(BINARY), *arguments],
        "cwd": str(OUTPUT),
        "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "elapsed_seconds": round(time.monotonic() - started, 6),
        "observed_exit": exit_code,
        "timed_out": timed_out,
        "direct_reaped": process.returncode is not None,
        "process_group_absent": process_group_absent,
        "binary_before": before,
        "binary_after": after,
        "binary_unchanged": before == after,
        "log": identity(log),
    }
    with (OUTPUT / (label + ".json")).open("x") as destination:
        json.dump(record, destination, indent=2)
        destination.write("\n")
    assert exit_code == 0 and not timed_out and process_group_absent
    assert before == after
    return record, log.read_text()


def main():
    (OUTPUT / "tmp").mkdir(exist_ok=False)
    source_before = identity(SOURCE)
    inventory_record, inventory = run("precompiled-core-inventory", ["--list"])
    source_names = set(re.findall(r"#\[test\]\s*\nfn (\w+)\(", SOURCE.read_text()))
    binary_names = set(re.findall(r"^(\w+): test$", inventory, re.MULTILINE))
    assert source_names == binary_names and len(source_names) == 106
    suite_record, suite = run("precompiled-core-suite", ["--test-threads=4"])
    passed_names = set(re.findall(r"^test (\w+) \.\.\. ok$", suite, re.MULTILINE))
    assert passed_names == source_names
    assert "106 passed; 0 failed; 0 ignored" in suite
    source_after = identity(SOURCE)
    assert source_before == source_after
    record = {
        "commands_executed": 2,
        "test_executions": 106,
        "passed": 106,
        "failed": 0,
        "ignored": 0,
        "source_inventory_count": len(source_names),
        "binary_inventory_count": len(binary_names),
        "exact_source_inventory_matches": source_names == binary_names,
        "exact_passed_inventory_matches": passed_names == source_names,
        "source_before": source_before,
        "source_after": source_after,
        "binary_sha256": inventory_record["binary_before"]["sha256"],
        "inventory_receipt": "precompiled-core-inventory.json",
        "suite_receipt": "precompiled-core-suite.json",
        "limitation": (
            "No compilation, Cargo, fmt, Clippy, package invalidation or SSH "
            "tests were run. This reruns a parent-built binary. Parent compile "
            "logs, unchanged source hashes and exact test names support its "
            "binding; this is not an independent clean rebuild."
        ),
    }
    with (OUTPUT / "precompiled-core-summary.json").open("x") as destination:
        json.dump(record, destination, indent=2)
        destination.write("\n")
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()
