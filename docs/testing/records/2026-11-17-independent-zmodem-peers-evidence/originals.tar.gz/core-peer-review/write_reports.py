"""Write the scoped review decision from this review's verified evidence."""

import datetime
import json
from pathlib import Path

OUTPUT = Path(__file__).resolve().parent
ROOT = OUTPUT.parents[1]
PARENT = ROOT / "work/zmodem-independent-peer-20261117"


def load(name):
    return json.loads((OUTPUT / name).read_bytes())


def location(path, start, end=None):
    return {"file": str(ROOT / path), "start_line": start,
            "end_line": start if end is None else end}


initial = load("initial-binding.json")
final = load("final-binding.json")
audit = load("offline-audit.json")
tests = load("precompiled-core-summary.json")
protocol = load("protocol-verification.json")
assert audit["status"] == "PASS" and audit["failed_checks"] == 0
assert tests["passed"] == 106 and tests["exact_passed_inventory_matches"]
assert final["core_files_unchanged_from_r2_r3"]
assert final["core_binary_identity_unchanged"]
assert protocol["matches_parent_reference"]

source_checks = [
    {
        "property": "At most seven numeric metadata fields",
        "location": location("crates/keelshell-core/src/zmodem.rs", 410, 414),
        "trigger": "A peer appends the deprecated seventh decimal file-type field",
        "impact": "The captured valid offer is admitted; an eighth field is rejected",
        "finding": None,
    },
    {
        "property": "All optional values require unsigned ASCII digits",
        "location": location("crates/keelshell-core/src/zmodem.rs", 415, 420),
        "trigger": "Signed, non-ASCII, nonnumeric or overflowing optional values",
        "impact": "InvalidMetadata; mtime/mode remain octal, other fields decimal u64",
        "finding": None,
    },
    {
        "property": "The seventh field has no type authority",
        "location": location("crates/keelshell-core/src/zmodem.rs", 419, 427),
        "trigger": "Legacy type claims a different type from the third field",
        "impact": "Mode validation still rejects nonregular types; legacy value cannot override it",
        "finding": None,
    },
    {
        "property": "Path, metadata, length and hidden-data controls remain in force",
        "location": location("crates/keelshell-core/src/zmodem.rs", 377, 409),
        "trigger": "Unsafe basename, oversized metadata/file or nonzero data after NUL",
        "impact": "Offer fails closed before acceptance or publication",
        "finding": None,
    },
    {
        "property": "Independent raw wire regression exercises every two-chunk split",
        "location": location("crates/keelshell-core/tests/zmodem.rs", 153, 170),
        "trigger": "The captured 65-byte CRC32 ZFILE arrives at any of 66 split positions",
        "impact": "Exactly one unchanged FileOffer and pending offer; independent CRC recomputation also passes",
        "finding": None,
    },
    {
        "property": "Invalid, excess-field, path, mode, size and type controls are tested",
        "location": location("crates/keelshell-core/tests/zmodem.rs", 644, 762),
        "trigger": "Malformed legacy field or existing security-policy boundary",
        "impact": "Rejects malformed offers and retains mode/name/length policy; valid seventh type stays inert",
        "finding": None,
    },
]

known_failures = [{
    "status": "OPEN",
    "classification": "Observed peer interoperability limitation; not a new core-source finding",
    "tests": audit["runs"][2]["failed"],
    "trigger": "SexyZ sends an empty file, individually or after two nonempty batch files",
    "observed": "Peer diagnostics explicitly report Received INVALID ZRPOS offset: 0",
    "impact": "Individual empty download and complete three-file batch do not finish; suite remains FAILED",
    "evidence": [
        location("work/zmodem-independent-peer-20261117/mac-sexyz-r2/tests.log", 20, 31),
        location("work/zmodem-independent-peer-20261117/mac-sexyz-r3/tests.log", 57, 68),
    ],
    "attribution_limit": "Did not inspect GPL implementation behavior; peer message alone does not establish complete root-cause ownership",
}]

boundaries = [
    "Only two core files are source-approved. Fermat owns review of the other three engineering files and their later increments.",
    "Current engineering inputs differ from r3 in those three files. r3 wire observations bind only to frozen r3 source, not current or later source.",
    "No Cargo, fmt, Clippy, dependency refresh, independent core build, SSH/product peer test or native application was executed by this reviewer.",
    "Core tests are a fresh execution of a parent-precompiled binary. Parent compilation logs, source hashes and exact 106-name inventory support binding; this is not an independent clean rebuild.",
    "Core red regression is original evidence with verified log digest and exit 101; it was not independently rebuilt or rerun against the old source.",
    "Peer binary and archive/source/build-input hashes were independently checked; the peer was not independently rebuilt or run.",
    "r1/r2 cannot attest r3 raw-header observation or --show-output functionality. Only r3's own saved success receipts support those observations.",
    "r1's manifest has no aggregate_algorithm. Its stored aggregate is retained without claiming recomputation; its run's bound source hashes were checked individually.",
    audit["cleanup_limit"],
    "No fresh historical kernel birth-identity census, detached-process proof, private-key content inspection or credential access was attempted.",
    "No lrzsz new matrix, Linux/Windows peer acceptance, native desktop, production, installation, release or FILE-05 completion is signed here.",
    "Parent's documentation, final complete gate, latest freeze, delivery and Git push remain separate work.",
    "Latest full dependency freshness remains UNKNOWN: r1 partial failure stays; r2 outer timeout 124/reaped produced no report.",
]

commands = [
    {"id": "V01", "kind": "offline_python", "purpose": "Initial 765-input r2 binding", "exit": 0},
    {"id": "V02", "kind": "offline_python_with_readonly_protocol_fetch", "purpose": "Official-maintainer protocol digest and field semantics", "exit": 0},
    {"id": "V03", "kind": "offline_python", "command": ["python3", "-B", str(OUTPUT / "run_precompiled.py")], "exit": 0},
    {"id": "V03a", "kind": "precompiled_core_binary", "arguments": ["--list"], "exit": 0},
    {"id": "V03b", "kind": "precompiled_core_binary", "arguments": ["--test-threads=4"], "exit": 0, "passed": 106, "failed": 0, "ignored": 0},
    {"id": "V04", "kind": "offline_python", "purpose": "First evidence audit", "exit": 1, "classification": "Reviewer assumed r1 used r2 canonical encoding"},
    {"id": "V05", "kind": "offline_python", "purpose": "Historical freeze encoding diagnostic", "exit": 1, "classification": "Reviewer assumed baseline.json had inputs rather than engineering_inputs"},
    {"id": "V06", "kind": "offline_python", "purpose": "Second evidence audit", "exit": 1, "classification": "Correctly stopped on later non-core engineering drift from r3"},
    {"id": "V07", "kind": "offline_python", "purpose": "Pin the three non-core input differences", "exit": 0},
    {"id": "V08", "kind": "offline_python", "purpose": "Third evidence audit", "exit": 1, "classification": "Reviewer regex did not account for JSON-escaped quotes around captured hex"},
    {"id": "V09", "kind": "offline_python", "command": ["python3", "-B", str(OUTPUT / "audit_evidence.py")], "exit": 0, "checks": 4138},
    {"id": "V10", "kind": "offline_python", "purpose": "Final 765-input/core/binary/target/Git binding", "exit": 0},
]

decision = {
    "schema": 1,
    "created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "reviewer_role": "New non-author core fix and real-interoperability evidence reviewer",
    "decision": "APPROVE_WITH_BOUNDARIES",
    "source_decision": "APPROVE",
    "evidence_decision": "ACCEPT_SCOPED_ORIGINAL_RECEIPTS_WITH_FAILURES_PRESERVED",
    "baseline_head": "ac7ec43e6a42329417a99b5933bc171faa19caf6",
    "final_observed_head": final["git_readbacks"][0]["output"].strip(),
    "scope_files": final["core_files"],
    "candidate_r2": {
        "count": initial["count"], "aggregate_sha256": initial["aggregate"],
        "verified_current_at_review_start": initial["matches"],
    },
    "candidate_r3": {
        "count": 765, "aggregate_sha256": audit["freeze_r3_aggregate"],
        "canonical_verified": True, "core_identical_to_r2": True,
        "current_full_engineering_binding": False,
    },
    "source_checks": source_checks,
    "findings": [],
    "severity_counts": {"P0": 0, "P1": 0, "P2": 0, "P3": 0},
    "known_interoperability_failures": known_failures,
    "bounded_delivery_allowed": True,
    "bounded_delivery_scope": "Seven-field core compatibility fix and explicitly classified macOS peer subset evidence",
    "merge_recommendation": "Approve these two frozen core files. Overall delivery follows the parent's final freeze/gate and Fermat's current three-file review.",
    "FILE05_closed": False,
    "FILE05_status": "OPEN / PARTIAL / HOLD",
    "latest_full_dependency_freshness": "UNKNOWN",
    "unverified_boundaries": boundaries,
    "fresh_core_binary_execution": tests,
    "offline_audit": {"checks": audit["checks"], "failed": 0, "receipt": "offline-audit.json"},
    "validation_command_counts": {
        "offline_python": 10, "direct_precompiled_core_binary": 2,
        "total_including_driver_and_child_binary_invocations": 12,
        "exit_zero": 8, "exit_nonzero": 4,
        "reviewer_tooling_assumption_failures": 3,
        "correct_noncore_source_drift_guard_stop": 1,
        "Cargo": 0, "fmt": 0, "Clippy": 0, "SSH_peer_product_test": 0,
        "note": "Counts exclude exploratory read-only reads/Git/hash inventory commands and report writing; driver and its two binary children are separately counted.",
    },
    "validation_commands": commands,
    "readonly_boundary": {
        "allowed_output_directory": str(OUTPUT),
        "reviewer_mutations_outside_allowed_directory": 0,
        "core_binary_identity_unchanged": final["core_binary_identity_unchanged"],
        "target_directory_identity_unchanged": final["target_directory_identity_unchanged"],
        "target_whole_tree_snapshot_claimed": False,
        "Git_mutating_commands": 0,
    },
}

summary = {
    "schema": 1,
    "decision": decision["decision"],
    "severity_counts": decision["severity_counts"],
    "source_summary": "Seven fields maximum; all optional numeric fields unsigned ASCII; octal mtime/mode; inert decimal legacy seventh field; existing ordinary-file, path, length, review and bounds policy retained.",
    "core_tests": {
        "execution": "independent rerun of parent-precompiled binary",
        "passed": 106, "failed": 0, "ignored": 0,
        "inventory_source_binary_passed_names_exactly_equal": True,
        "binary_sha256": tests["binary_sha256"],
        "fresh_compilation": False,
        "original_red": "101/reaped, 0 passed / 1 failed, InvalidMetadata",
        "original_green": "0/reaped, 106 passed / 0 failed",
        "capture": audit["capture"],
        "timestamp_note": "In the two precompiled command receipts, started_utc was recorded after wait and represents receipt-recording time; elapsed_seconds uses a monotonic timer.",
    },
    "peer_runs": [
        {
            "run": row["label"], "passed": len(row["passed"]),
            "failed": len(row["failed"]), "tests_exit": row["tests_exit"],
            "outer_exit": row["outer_exit"],
            "outer_elapsed_seconds": row["outer_elapsed_seconds"],
            "outer_direct_reaped": row["outer_direct_reaped"],
            "binding_unchanged": row["binding_unchanged"],
            "outcome": row["outcome"],
            "success_receipts": row["receipts"],
            "temporary_directory_currently_absent": True,
        } for row in audit["runs"]
    ],
    "r3_classification": {
        "strict_completed_test_cases": 5,
        "cancel_or_preserve_test_cases": 3,
        "empty_download_or_batch_failures": 2,
        "same_shell": "strict_OO=1, missing_OO=0, saved=1, same_shell_continued=true",
        "crc16": "incoming_binary16=true, incoming_binary32=false, strict_OO=1",
        "crc32": "incoming_binary16=false, incoming_binary32=true, strict_OO=1",
        "scope": "r3-only observations; not retroactive to r1/r2 or forward to later source",
        "evidence_locations": [
            location("work/zmodem-independent-peer-20261117/mac-sexyz-r3/tests.log", 19, 42),
            location("work/zmodem-independent-peer-20261117/mac-sexyz-r3/tests.log", 57, 68),
        ],
    },
    "peer_provenance": audit["peer_provenance"],
    "no_pipe_relay": {
        "basis": "Frozen fixture uses start_shell and stty raw; peer fd0/fd1 stay on that SSH PTY, fd2 redirects directly to an owned regular file. Binding and original failures show this recipe.",
        "reviewer_SSH_execution": 0,
        "Fermat_source_review_is_separate": True,
        "peer_exit_zero_alone_is_not_strict_OO": True,
    },
    "protocol_reference": {
        "bytes": protocol["bytes"], "sha256": protocol["sha256"],
        "independent_readonly_fetch_matches_parent": True,
        "local_copy": str(OUTPUT / "protocol-reference.txt"),
        "relevant_lines": [[679, 728], [1127, 1130]],
        "GPL_implementation_logic_read_or_imported": False,
    },
    "cleanup_boundary": audit["cleanup_limit"],
    "dependency_status": {
        "latest_full": "UNKNOWN",
        "r1": "Partial failure retained, 42 passed / 71 failed declarations/usages",
        "r2": "outer timeout 124/reaped, observed_exit=null, no generated report",
    },
    "current_binding": final,
    "validation_command_counts": decision["validation_command_counts"],
    "tooling_failure_note": "Three reviewer script assumptions were corrected; one audit correctly stopped for non-core source drift. Failures are retained separately and do not alter original test outcomes.",
    "bounded_delivery_allowed": True,
    "FILE05_closed": False,
    "unverified_boundaries": boundaries,
    "artifacts": [
        "decision.json", "summary.json", "core-source-decision.json",
        "initial-binding.json", "final-binding.json",
        "precompiled-core-inventory.json", "precompiled-core-inventory.log",
        "precompiled-core-suite.json", "precompiled-core-suite.log",
        "precompiled-core-summary.json", "offline-audit.json",
        "offline-checks.json", "evidence-manifest.json",
        "protocol-verification.json", "protocol-reference.txt",
        "reviewer-tooling-failures.json", "current-drift-after-r3.json",
    ],
}

failure_addendum = {
    "attempt": "V08", "observed_exit": 1,
    "first_failed_check": "capture/exact-r1-wire",
    "reason": "Reviewer regex required unescaped quotation marks in a JSON-rendered error string; corrected to delimit hex by non-hex boundaries.",
    "product_test_failure": False,
    "verification_after_correction": "offline-audit.json, 4138 checks passed",
}

for name, value in (
    ("reviewer-tooling-capture-failure.json", failure_addendum),
    ("decision.json", decision), ("summary.json", summary),
):
    with (OUTPUT / name).open("x") as destination:
        json.dump(value, destination, ensure_ascii=False, indent=2)
        destination.write("\n")
print(json.dumps({
    "decision": decision["decision"], "severity_counts": decision["severity_counts"],
    "core_tests_passed": 106, "offline_checks_passed": audit["checks"],
    "bounded_delivery_allowed": True, "FILE05_closed": False,
    "decision_path": str(OUTPUT / "decision.json"),
    "summary_path": str(OUTPUT / "summary.json"),
}, ensure_ascii=False, indent=2))
