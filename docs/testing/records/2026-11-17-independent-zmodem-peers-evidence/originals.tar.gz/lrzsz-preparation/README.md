# lrzsz 0.13.1 外部 peer

状态：PREPARED_NOT_ACCEPTED。2026-11-17，macOS arm64。本任务真实传输用例数为 0；父任务自行执行当前源码十项真实 PTY 矩阵。

用户已明确授权子 agent 与本地联调。本任务先读 AGENTS.md、RTK.md、docs/HANDOFF.md，仅写本目录。未运行 Cargo、SSH、容器、Git 或安装命令，未创建 chat/worktree，未修改产品源码、docs、共享 target 或上游协议。

## 供父任务直接调用

receiver：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/zmodem-lrzsz0131-peer-20261117/build/src/lrz`

SHA-256：`5cfd57bcc24698caaa784e01a643f1437bea759efab606e8d7b4503c2e589369`，121440 bytes。

sender：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/zmodem-lrzsz0131-peer-20261117/build/src/lsz`

SHA-256：`2802e822a1514a45fb22e869b587789418b8de137ae758f3432000eb0570d5d0`，122816 bytes。

默认 flags 均为 JSON `["-b","-vv"]`；完整字面 argv 与 KEELSHELL_ZMODEM_RZ/SZ/ARGS 接口见 peer.json。发送文件由父任务在 flags 后逐项追加字面文件名，接收目录由父任务选择 cwd。

## 来源与构建

官方页面：`https://www.ohse.de/uwe/software/lrzsz.html`。当日标示最新 0.13.1、2026 年 10 月；相对下载链接 `../releases/lrzsz-0.13.1.tar.gz`，固定下载 URL：`https://www.ohse.de/uwe/releases/lrzsz-0.13.1.tar.gz`。

压缩原归档 `downloads/lrzsz-0.13.1.tar.gz`：483782 bytes，SHA-256 `112f91059fbd118e016d800c1a5c5a1702e965d8b9bfbda6015e44e20bfb93c9`。这是从官方 HTTPS 下载计算的内容摘要，未验证独立发布的签名摘要。完整 HTML 和上游手册只留本地，不纳入产品 Git。

本机 `/opt/homebrew/bin/rz` 与 `/opt/homebrew/bin/sz` 均不存在（evidence/intake.json），因此从原归档构建。原版 configure exit 0 / 4.694313s；make -j2 exit 0 / 0.69194s。CC=/usr/bin/clang，CFLAGS=-O2 -arch arm64，LDFLAGS=-arch arm64，MACOSX_DEPLOYMENT_TARGET=15.0；禁用 NLS/依赖跟踪，安装 prefix 指向本目录但未运行 install。所有构建和临时路径在自有目录内。

两个 --version 都是 0.13.1；file 确认两者均为 Mach-O arm64；otool 仅列系统 libSystem。没有运行 make check 或协议自测。构建成功、版本与 --help 不属于传输验收。

下载压缩输入上限 8 MiB；有界解包 tar 与文件总量分别上限 64 MiB、5000 成员、单文件 16 MiB、路径 1024 bytes/32 层、提取 30 秒。只接受固定顶层下的普通文件/目录，拒绝链接、设备、稀疏、穿越、重复。实际 101 成员、95 文件、1740579 文件字节；构建前后上游文件逐个相同。原归档与展开源码保留。

源码成员树 SHA-256：`812d4473871ea52f20defdd6d0addbc963430851ff8324df7e32282777b79a88`；构建树 SHA-256：`e5bb1e06588dd959157cf762cc8a3014af0c16cd9afe5451d9d810b55102c37b`。原始/构建逐文件清单、各自相对路径摘要规则及构建后源树一致性见 evidence/source-manifest.json、source-integrity.json、build-manifest.json。

官方声明 GPL；包内 COPYING 为 GNU GPL v2 文本，路径/摘要见 peer.json。此 peer 仅供独立本地测试，不安装系统、不捆绑产品。只阅读公开构建/使用说明、公开协议文档及 --help；未查看或转述 GPL 协议实现。

## 参数、PTY 与限制

默认 `-b -vv` 保持文件字节并把进度写 stderr。显式 ZMODEM 为大写 `-Z`；--help 未列小写 `-z`，不要假设 `-bz` 可用。0.13 详细协议日志使用 `--debug=protocol`，增加 -v 不替代该选项。

接收端未列 ZMODEM 目标目录参数，位置式 filename 属于 XMODEM；在新建接收 cwd 启动 lrz。该建议不证明路径隔离。stdin/stdout 直连同一 raw 8-bit PTY：关闭 canonical、echo、CR/LF 转换、ISTRIP、OPOST、软件 XON/XOFF。stderr 单独写入用例自有日志，不用 2>&1 混进协议，不增加协议 pipe/relay。

环境建议 LC_ALL=C、LANG=C、TERM=dumb、TMPDIR 指向本目录 tmp。父任务记录实际 SHELL 与 ZMODEM_RESTRICTED，它们可能影响 restricted mode。环境建议未替父任务注入，locale 也不证明 Unicode 内容传输。

可选显式参数 `["-b","-vv","-Z","--syslog=off"]` 两端均与 --help 共同调用并成功解析，可关闭上游可选系统日志；父任务应明确记录该参数选择，基线默认仍是 `["-b","-vv"]`。

CRC16：发送端 lsz 的 -o/--16-bit-crc；lrz 的 -c/--with-crc 仅适用 XMODEM，没有已列出的 ZMODEM 接收端强制 CRC16 参数。CRC32 默认依 CANFC32 协商；实际头及数据 CRC 覆盖由父任务观察。

OO：包内公开规范描述 ZFIN→ZFIN→OO，接收端短暂等待后也可以缺 OO 退出。没有已列出的保证 OO 到达参数；大写 -O 是禁用超时，不适合有界测试。严格 Finished 仍必须看到实际 OO，exit 0 不能代签。

旧 macOS lrzsz 0.13.1 八项通过、旧 Linux 0.12.21rc strict-OO 失败，以及当前 SexyZ 8/10、空下载拒绝 ZRPOS0 均保持。此次准备不宣称升级修复旧失败，不证明当前十项、空文件、取消、普通终端尾部或同 shell 新输入已通过。

## 生命周期与安全封存

commands.jsonl 与 commands/<label>/command.json 记录每个受监督外部命令的 argv/cwd/环境覆盖/timeout/exit/PID/PGID/reap/组收尾；所有外部子进程已 wait/reap，无超时。组已消失则不发送收尾信号，仅必要时 TERM/KILL。最终仅自有 PID/PGID 的读回与剩余进程见 resources.json。

首次 zsh 在启动 curl 前的展开失败，以及封存脚本执行前的 Python 解析失败均另存 evidence/*failure.json；原工具回执保留，不伪造为成功。只对下载成功响应和全机 census 做最小化：原全机内容已移除，仅保留本任务 PID/PGID 行；下载响应仅留 URL/HTTP/TLS/大小/耗时，headers 仅公共内容元数据。原内容只留摘要和字节数，不持久保存其他任务进程及多余下载信息，详见 evidence/output-minimization.json。

封存仅使用 resources.json 的 safe_archive_allowlist，逐文件选择摘要、命令生命周期与无实现片段的来源/构建原件。downloads/、source/、build/、tmp/、完整 HTML/手册、上游源码与 peer 二进制全部仅在本地保留，禁止整目录纳入产品 Git。README/peer.json 的本地路径引用不构成归档授权。
