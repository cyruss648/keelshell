"""Bind this batch's engineering inputs without changing Cargo artifacts."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
label = sys.argv[1]
assert label.replace("-", "").isalnum()
destination = BASE / (label + ".json")
assert not destination.exists()
original = json.loads((BASE / "candidate-inputs-r1.json").read_text())
rows = []
for entry in original["inputs"]:
    path = ROOT / entry["path"]
    assert path.is_file() and not path.is_symlink(), path
    raw = path.read_bytes()
    rows.append({
        "path": entry["path"], "bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
    })
assert len({row["path"] for row in rows}) == len(rows)
canonical = json.dumps(rows, sort_keys=True, separators=(",", ":")).encode()
changed = subprocess.check_output(
    ["git", "diff", "--name-only", "HEAD"], cwd=ROOT, text=True
).splitlines()
paths = {row["path"] for row in rows}
record = {
    "baseline_source": subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
    ).strip(),
    "count": len(rows), "inputs": rows,
    "changed_engineering_inputs": [path for path in changed if path in paths],
    "aggregate_algorithm": "sha256(json.dumps(inputs, sort_keys=True, separators=(',', ':')).encode())",
    "aggregate_sha256": hashlib.sha256(canonical).hexdigest(),
    "cargo_owner_checkout_unchanged": True,
}
with destination.open("x") as output:
    json.dump(record, output, indent=2)
    output.write("\n")
print(json.dumps({key: value for key, value in record.items() if key != "inputs"}))
