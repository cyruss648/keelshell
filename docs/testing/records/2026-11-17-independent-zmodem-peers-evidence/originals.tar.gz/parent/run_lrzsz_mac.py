"""Run the fixed official lrzsz build on the current real SSH PTY fixture."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
label = sys.argv[1]
assert label.replace("-", "").isalnum()
output = BASE / label
binding = BASE / (label + "-binding.json")
assert not output.exists() and not binding.exists()
paths = {
    "RZ": (ROOT / "work/zmodem-lrzsz0131-peer-20261117/build/src/lrz",
           "5cfd57bcc24698caaa784e01a643f1437bea759efab606e8d7b4503c2e589369"),
    "SZ": (ROOT / "work/zmodem-lrzsz0131-peer-20261117/build/src/lsz",
           "2802e822a1514a45fb22e869b587789418b8de137ae758f3432000eb0570d5d0"),
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inputs():
    freeze = json.loads((BASE / "candidate-inputs-r7.json").read_text())
    actual = {entry["path"]: digest(ROOT / entry["path"])
              for entry in freeze["inputs"]}
    assert actual == {entry["path"]: entry["sha256"] for entry in freeze["inputs"]}
    return actual


environment = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", LC_ALL="C")
environment.pop("DSZLOG", None)
for role, (path, expected) in paths.items():
    assert path.is_file() and digest(path) == expected
    environment["KEELSHELL_ZMODEM_" + role] = str(path)
    environment.pop("KEELSHELL_ZMODEM_" + role + "_ARGS", None)
before = inputs()
started = datetime.now(timezone.utc).isoformat()
result = subprocess.run([
    sys.executable, "-B", "scripts/openssh_interop.py", "--zmodem",
    "--timeout", "300", "--output", str(output),
], cwd=ROOT, env=environment, timeout=330, check=False)
after = inputs()
record = {
    "started_utc": started, "finished_utc": datetime.now(timezone.utc).isoformat(),
    "source": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
    "peer_version": "lrzsz 0.13.1",
    "source_archive_sha256": "112f91059fbd118e016d800c1a5c5a1702e965d8b9bfbda6015e44e20bfb93c9",
    "peer_sha256_before": {role: expected for role, (_, expected) in paths.items()},
    "peer_sha256_after": {role: digest(path) for role, (path, _) in paths.items()},
    "source_inputs_before": before, "source_inputs_after": after,
    "unchanged": before == after and all(digest(path) == expected
                                       for path, expected in paths.values()),
    "runner_exit": result.returncode,
    "pipeline": "Peer fd0/fd1 directly on the SSH raw PTY; stderr on an owned regular file",
    "new_user_chats": 0, "new_worktrees": 0,
}
with binding.open("x") as target:
    json.dump(record, target, indent=2)
    target.write("\n")
print(json.dumps({key: value for key, value in record.items()
                  if not key.startswith("source_inputs_")}))
assert record["unchanged"]
raise SystemExit(result.returncode)
