"""Run an unchanged, fixed-source external peer on actual OpenSSH raw PTYs."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
label = sys.argv[1]
assert label.replace("-", "").isalnum()
binding = BASE / (label + "-binding.json")
output = BASE / label
assert not binding.exists() and not output.exists()
peer = ROOT / "work/zmodem-sexyz-peer-20261117/build-standalone/sexyz"
expected = "4311ba9bbe5cccca936ccb73c74ac581735af309f5c9c379380b4c11126c4994"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inputs():
    freeze = json.loads((BASE / "candidate-inputs-r7.json").read_text())
    actual = {entry["path"]: digest(ROOT / entry["path"])
              for entry in freeze["inputs"]}
    assert actual == {entry["path"]: entry["sha256"] for entry in freeze["inputs"]}
    return actual


assert digest(peer) == expected and peer.stat().st_size == 253304
before = inputs()
environment = dict(os.environ)
environment.pop("DSZLOG", None)
environment.update({
    "KEELSHELL_ZMODEM_RZ": str(peer),
    "KEELSHELL_ZMODEM_SZ": str(peer),
    "KEELSHELL_ZMODEM_RZ_ARGS": json.dumps(["-raw", "-e", "rz", "./"]),
    "KEELSHELL_ZMODEM_SZ_ARGS": json.dumps(["-raw", "sz"]),
    "PYTHONDONTWRITEBYTECODE": "1",
})
started = datetime.now(timezone.utc).isoformat()
result = subprocess.run([
    sys.executable, "-B", "scripts/openssh_interop.py",
    "--zmodem", "--timeout", "300", "--output", str(output),
], cwd=ROOT, env=environment, timeout=330, check=False)
after = inputs()
record = {
    "started_utc": started, "finished_utc": datetime.now(timezone.utc).isoformat(),
    "source": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
    "upstream_source": "acce09a1778dc2c61a996a3407ff6ddcaf70acb3",
    "peer_sha256_before": expected, "peer_sha256_after": digest(peer),
    "source_inputs_before": before, "source_inputs_after": after,
    "unchanged": before == after and digest(peer) == expected,
    "runner_exit": result.returncode,
    "pipeline": "Peer fd0/fd1 directly on the SSH raw PTY; stderr on an owned regular file",
    "new_user_chats": 0, "new_worktrees": 0,
}
with binding.open("x") as target:
    json.dump(record, target, indent=2)
    target.write("\n")
print(json.dumps({key: value for key, value in record.items()
                  if not key.startswith("source_inputs_")}))
assert record["unchanged"]
raise SystemExit(result.returncode)
