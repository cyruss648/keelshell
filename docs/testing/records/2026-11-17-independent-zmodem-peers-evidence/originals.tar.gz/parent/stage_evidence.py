"""Select owned receipts, excluding third-party implementations and binaries."""
import hashlib
import json
from pathlib import Path
import shutil

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
delivery = ROOT / "work/zmodem-independent-delivery-20261117"
stage = delivery / "stage"
stage.mkdir(parents=True, exist_ok=False)
mapping = []


def copy(base, path, prefix):
    assert path.is_file() and not path.is_symlink()
    relative = path.relative_to(base)
    destination = stage / prefix / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    raw = path.read_bytes()
    destination.write_bytes(raw)
    assert destination.read_bytes() == raw
    mapping.append({
        "source": str(path.relative_to(ROOT)),
        "archive": (Path(prefix) / relative).as_posix(),
        "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
    })


for prefix, base in [
    ("parent", BASE),
    ("source-review", ROOT / "work/zmodem-independent-source-review-20261117"),
    ("core-peer-review", ROOT / "work/zmodem-core-peer-review-20261117"),
]:
    for path in sorted(base.rglob("*")):
        relative = path.relative_to(base)
        if any(part in {"tmp", "__pycache__", "runtime-tmp"} for part in relative.parts):
            continue
        if path.name == "protocol-reference.txt":
            continue
        if path.is_file():
            copy(base, path, prefix)

sexyz = ROOT / "work/zmodem-sexyz-peer-20261117"
for path in sorted(sexyz.rglob("*")):
    relative = path.relative_to(sexyz)
    if (relative.as_posix() in {"README.md", "peer.json", "resources.json"}
            or relative.parts[0] in {"logs", "evidence"} and path.suffix == ".json"):
        if path.is_file():
            copy(sexyz, path, "sexyz-preparation")

lrzsz = ROOT / "work/zmodem-lrzsz0131-peer-20261117"
allowlist = json.loads((lrzsz / "resources.json").read_text())["safe_archive_allowlist"]
for name in allowlist:
    path = lrzsz / name
    assert path.resolve().is_relative_to(lrzsz.resolve())
    copy(lrzsz, path, "lrzsz-preparation")

record = {
    "count": len(mapping), "bytes": sum(row["bytes"] for row in mapping),
    "selected": mapping,
    "excluded": [
        "Upstream source trees, build trees, peer binaries and tar downloads",
        "Whole upstream HTML/manuals and unrelated process census",
        "Python caches, temporary fixture data and credentials",
    ],
}
(delivery / "selection.json").write_text(json.dumps(record, indent=2) + "\n")
shutil.copyfile(delivery / "selection.json", stage / "selection.json")
print(json.dumps({key: value for key, value in record.items() if key != "selected"}))
