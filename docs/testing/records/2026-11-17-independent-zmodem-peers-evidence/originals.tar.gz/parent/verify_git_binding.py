"""Verify frozen engineering inputs and sealed originals in an exact commit."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
commit, label = sys.argv[1:]
assert len(commit) == 40 and all(char in "0123456789abcdef" for char in commit)
freeze = json.loads((BASE / "candidate-inputs-r7.json").read_text())
evidence = "docs/testing/records/2026-11-17-independent-zmodem-peers-evidence"
names = [entry["path"] for entry in freeze["inputs"]]
names += [evidence + "/manifest.json", evidence + "/originals.tar.gz"]
assert all("\n" not in name for name in names)
result = subprocess.run(
    ["git", "cat-file", "--batch"], cwd=ROOT,
    input="".join(f"{commit}:{name}\n" for name in names).encode(),
    capture_output=True, timeout=90, check=False,
)
assert result.returncode == 0, result.stderr.decode(errors="replace")
stream = io.BytesIO(result.stdout)
blobs = {}
for name in names:
    header = stream.readline().strip().split()
    assert len(header) == 3 and header[1] == b"blob", (name, header)
    raw = stream.read(int(header[2]))
    assert len(raw) == int(header[2]) and stream.read(1) == b"\n"
    blobs[name] = raw
assert stream.read() == b""
for entry in freeze["inputs"]:
    raw = blobs[entry["path"]]
    assert len(raw) == entry["bytes"]
    assert hashlib.sha256(raw).hexdigest() == entry["sha256"], entry["path"]
manifest = json.loads(blobs[evidence + "/manifest.json"])
archive = blobs[evidence + "/originals.tar.gz"]
assert len(archive) == manifest["archive_bytes"]
assert hashlib.sha256(archive).hexdigest() == manifest["archive_sha256"]
with tarfile.open(fileobj=io.BytesIO(archive), mode="r:gz") as sealed:
    members = sealed.getmembers()
    assert len(members) == manifest["count"] == len(manifest["entries"])
    expected = {entry["path"]: entry for entry in manifest["entries"]}
    assert {member.name for member in members} == set(expected)
    for member in members:
        assert member.isfile() and not member.name.startswith("/")
        assert ".." not in Path(member.name).parts
        raw = sealed.extractfile(member).read()
        entry = expected[member.name]
        assert len(raw) == entry["bytes"] and hashlib.sha256(raw).hexdigest() == entry["sha256"]
receipt = {
    "commit": commit, "engineering_inputs": len(freeze["inputs"]),
    "engineering_aggregate": freeze["aggregate_sha256"],
    "archive_members": manifest["count"],
    "archive_sha256": manifest["archive_sha256"],
    "all_exact_git_blobs_verified": True,
}
with (BASE / (label + ".json")).open("x") as output:
    json.dump(receipt, output, indent=2)
    output.write("\n")
print(json.dumps(receipt))
