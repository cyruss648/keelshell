# Synchronet SexyZ 独立 peer 准备记录 — 2026-11-17

已在宿主 macOS arm64 成功构建**未修改的上游 SexyZ 3.7**，Zmodem 模块为
2.7。状态是 `BUILT_AND_SOURCE_VERIFIED / REAL_SSH_RAW_PTY_NOT_RUN`。
这是供父级随后联调的外部进程；本记录不代表真实 SSH 传输、取消、终态或
KeelShell 产品验收。父级的文件、夹具和断言均未读取或修改。

## 可执行文件与固定来源

可执行文件：

```text
/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/zmodem-sexyz-peer-20261117/build-standalone/sexyz
```

- 二进制：253,304 字节，Mach-O 64-bit arm64，最低 macOS 15.0。
- 二进制 SHA-256：
  `4311ba9bbe5cccca936ccb73c74ac581735af309f5c9c379380b4c11126c4994`。
- 官方仓库：[SynchronetBBS/sbbs](https://github.com/SynchronetBBS/sbbs)。
- 固定提交：[acce09a1778dc2c61a996a3407ff6ddcaf70acb3](https://github.com/SynchronetBBS/sbbs/commit/acce09a1778dc2c61a996a3407ff6ddcaf70acb3)。
  获取时 `HEAD` 与 `refs/heads/master` 都指向该 SHA；以后继续使用这个固定 SHA。
- Git tree：`a8e4745dfcacf369d1a55e3f7703a75d1f456fed`。
- 固定归档：[GitHub codeload](https://codeload.github.com/SynchronetBBS/sbbs/tar.gz/acce09a1778dc2c61a996a3407ff6ddcaf70acb3)。
- 归档：178,014,659 字节；SHA-256：
  `b7dffb423eaa7a4ed4e4b28f346fce4a2399bff6029a74aa6883c712037118ea`。
  这是本次下载字节的本地摘要，不声称为上游签名或独立发布的摘要。
- 归档与 GitHub commit API 原件保存在 `downloads/`。
- 上游源文件完整性基线为 `evidence/source-baseline.json`；
  编译输入逐文件来源与摘要为 `evidence/build-inputs.json`。

独立性依据：`zmodem.c:1-39` 的版权、BSD 许可与原始 zmtx/zmrx 作者声明，
以及 `sexyz.c:22-43` 的来源说明。实际编译使用 Synchronet 自己的 22 个 C 文件、
xpdev/hash 配套代码和原版 standalone Makefile；没有链接或执行 lrzsz。
源码中的兼容性比较不改变这个编译来源说明。

## 构建与本机检查

使用固定提交中的
`src/sbbs3/sexyz_release/GNUmakefile` 原文，按其 `SRCS` 复制 22 个 C 文件；
头文件按官方 `mksexyzsrc.sh:14-20` 的查找优先级复制全部 129 个候选头文件，
未更改任何源文件或 Makefile。保留比实际 include closure 更多的候选头文件，
不增加编译单元。

只有 `git_branch.h` / `git_hash.h` 是标准构建元数据，按官方打包脚本
`mksexyzsrc.sh:36-41` 从已固定 SHA 及 author 时间生成；时间明确使用 UTC。
没有对协议、CLI、传输或取消代码应用补丁。源归档抽取目录不参与生成文件，
其 1,452 个文件另有前后摘要核对。

实际构建 argv：

```json
["/usr/bin/make", "-j2", "CC=/usr/bin/clang"]
```

cwd 为本目录下 `build-standalone/`；显式清空 `MAKEFLAGS`、`MFLAGS`，
设置 `MACOSX_DEPLOYMENT_TARGET=15.0`。TMPDIR、缓存目录都位于本任务目录。
本机 Apple clang 21.0.0、GNU Make 3.81；无 Cargo、无容器、无全局安装。
`make -j2` 编译全部 22 个 C 文件并链接，exit 0，耗时约 0.80 秒。

编译保留了上游警告：Apple SDK 的 `snprintf` 宏重定义、一个 `uint64_t`
printf 格式警告和链接器 section alignment 警告。没有为了压掉警告改源码。
完整原始 stdout/stderr 在 `logs/native-arm64-build-r1.*.log`。

`sexyz v` exit 0，输出：

```text
Synchronet External X/Y/ZMODEM v3.7 master/acce09a177
sexyz.c  3.7
xmodem.c 2.0
zmodem.c 2.7
Compiled master/acce09a177 Nov 15 2026 23:28 with Clang 21.0.0
```

该日期是官方版本头中的 commit author 时间，不是本次构建时间。
真实执行时间在 JSON 回执中。`file`、`otool -L/-l` 确认 arm64、
minos 15.0、sdk 27.2，唯一动态库是 `/usr/lib/libSystem.B.dylib`。
本次只运行版本、usage 与结构检查，没有启动协议传输。

## raw PTY 调用合同与精确 argv

`peer.json` 提供带完整可执行路径的 JSON argv、fd 布局、预条件和每个 recipe
的独立 stderr 文件路径。以下命令中的 `SEXYZ` 代表上文的完整可执行路径，
`RECV_DIR/` 是已存在且带末尾 `/` 的接收目录，`SEND_FILE` 是实际文件的绝对路径。
示例接收目录已创建于 `runtime/`；机器可读下载示例使用现有上游
`build-standalone/FILE_ID.DIZ`，父级可以将单个文件参数换成自己的夹具。

| 方向 / 要求 | argv（各列出的字符串都是独立参数） | 准确语义 |
| --- | --- | --- |
| 上传：peer 接收，CRC16 | `SEXYZ -raw -o rz RECV_DIR/` | `-o` 清除接收方 `CANFC32` 宣告，要求发送方选择 CRC16 |
| 上传：接收且请求 control escaping | `SEXYZ -raw -o -e rz RECV_DIR/` | 同上，并宣告 `ESCCTL` |
| 上传：peer 接收，允许 CRC32 | `SEXYZ -raw rz RECV_DIR/` | 默认宣告 `CANFC32`，发送方须实际选择 CRC32 |
| 上传：允许 CRC32 且请求 escaping | `SEXYZ -raw -e rz RECV_DIR/` | 默认 `CANFC32`，同时宣告 `ESCCTL` |
| 下载：peer 发送，强制发送 CRC16 | `SEXYZ -raw -o sz SEND_FILE` | 二进制 header 与 data subpacket 使用 CRC16 |
| 下载：peer 发送，选择 CRC32 | `SEXYZ -raw sz SEND_FILE` | 只有接收方宣告 `CANFC32` 才使用 CRC32 |
| 下载：要求 control escaping | 与对应 CRC 行相同 | 真正的接收方必须在 `ZRINIT` 设置 `ESCCTL` |

**CRC32 没有严格强制参数。** 默认 `[ZMODEM] CRC32=true` 只是允许/宣告；
发送端没有“接收方不支持则失败而不降级”的 CLI 开关。接收端 `-o` 也不是
拒绝解码 CRC32 frame 的校验器。因此 CRC32 以及接收方向的 CRC16 覆盖须由
父级实际握手和 wire frame 断言证明，不能仅据 recipe 名称认定。
源码：`sexyz.c:1766,1912-1914`，
`zmodem.c:572-576,668-684,1555-1574,1598-1637`。
控制报文使用 hex/CRC16 是正常协议行为，不表示数据 CRC32 模式未生效。

调用时必须满足：

1. **省略数字 socket 参数**，直接 exec 二进制，使 fd 0/1 连接同一个真实 SSH
   raw PTY。`-raw` / `-ssh` / `-rlogin` 都只关闭 Telnet 模式。
   `init_stdio()` 另外清除 canonical、echo、ISIG、OPOST、IXON 等 termios 标志；
   它没有显式重设 VMIN/VTIME，父级仍须建立真实 raw PTY 前置条件。
   源码：`sexyz.c:1634-1653,1807-1810,1879-1882,2039-2064`。
2. **fd 2 直接重定向至独立普通文件**。Unix 的启动横幅、状态与错误写 fd 2，
   且部分横幅出现在 `init_stdio()` 之前；若合并到 PTY 会出现协议外文本。
   `isatty(2)` 时 `init_stdio()` 还会 `fclose(stderr)`。
   使用文件重定向不添加 pipe、relay 或 interposer。
   源码：`sexyz.c:1638-1639,1686-1697,2047-2050`。
3. 所有选项放在 `rz` / `sz` 之前；**分开写 `-o -e`，不要合成 `-oe`**。
   解析器在识别命令之后把后续参数作为路径；一个 option 参数只检查首字符。
   不要靠未识别的 `--32` 等参数声明模式。源码：`sexyz.c:1812-1994`。
4. 接收目录须预先存在并带 `/`。实现按 `directory + basename` 直接拼接，
   补分隔符代码处于禁用注释中。源码：
   `sexyz.c:1973-1992,2068-2070,1333-1334`。
5. 默认不覆盖现存接收文件；存在、超出大小限制或无法创建时发送 `ZSKIP`。
   `-y` 会允许覆盖；本交接没有在 recipe 中启用它。使用全新接收目录。
   源码：`sexyz.c:1924-1928,1372-1404`。
6. 本次没有任何 `sexyz*.ini`。程序会按可执行文件旁的 host、platform、
   `.local`、普通 `.ini` 顺序查找配置；父级若复制二进制，应核对其目录配置。
   配置可改变 CRC、escaping、timeout、pause。取消继承的 `DSZLOG`，或明确让它
   指向该次测试自有文件；不启用 syslog。源码：
   `sexyz.c:1705-1777,2136-2142`，`ini_file.c:2298-2345`。

与预先建立的 raw PTY 配合的 shell 例子（这里只展示，不执行传输）：

```sh
SEXYZ='/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/zmodem-sexyz-peer-20261117/build-standalone/sexyz'
TASK='/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/zmodem-sexyz-peer-20261117'
unset DSZLOG
exec "$SEXYZ" -raw -o -e rz "$TASK/runtime/receive-crc16-escape/" 2>"$TASK/runtime/logs/upload-crc16-escape.stderr.log"
```

以上是宿主 Darwin 二进制；Linux/Windows SSH 端不能直接执行这个 Mach-O。
如果真实 SSH 服务运行于当前 macOS 宿主，可直接使用该路径；其他 OS 须从同一
固定来源另行构建。此次没有创建 SSH 服务、容器或远端安装。

## escaping、取消、终态：源码核实与待验证边界

下列为固定源码的静态结论，未伪装成本次 wire/native 接受测试：

- `-e` 在接收方向设置 `ZRINIT.ZF0_ESCCTL`。SexyZ 发送方向解析对端 `ZRINIT`
  时会覆盖自己的 `escape_ctrl_chars`，因此 `sexyz -e sz ...` 不能强制对端
  未请求的 escaping。来源：`sexyz.c:1936-1938`；
  `zmodem.c:108-130,1555-1566,1598-1621`。
- 常规模式仍转义 ZDLE 和流控相关字节（发送表中 `10 11 13 18 90 91 93 98`）；
  ESCCTL 扩展到控制字符。`-raw` 关闭 Telnet IAC 专用 escaping；不是关闭
  Zmodem escaping。此实现从不宣告 ESC8，也不会按对端 ESC8 请求转义第八位。
  来源：`sexyz.c:2063-2064`；
  `zmodem.c:326-399,1555-1566,1623-1629`。
- 发送启动可先产生字面 `rz\r` 再发送 `ZRQINIT`。
  接收启动会 purge 已排队输入；父级应等首个 `ZRINIT` 后推进，避免启动前预塞
  协议数据。来源：`zmodem.c:1581-1595`；`sexyz.c:1244-1246`。
- Zmodem 输入中连续 **5 个 CAN / 0x18** 设置 remote cancelled。来源：
  `zmodem.c:769-802`。不要把单个编码后的 ZDLE 当作取消序列。
- 外部 SIGINT、SIGQUIT、SIGTERM 由 handler 设置 local_abort/cancelled；
  **SIGTERM 不等价于立即退出**，SIGHUP 与 SIGPIPE 被忽略。ISIG 已关闭时，向
  PTY 写 Ctrl-C 字节也不等价于外部 SIGINT。来源：
  `sexyz.c:236-246,1647,2145-2156`。
- local abort 路径可以发送 CAN 序列，接收方向还发送 `ZABORT`；
  `xmodem_cancel()` 在条件允许时发 8 CAN 和 10 backspace。来源：
  `sexyz.c:1174-1177,1532-1538`；`xmodem.c:157-174`。
- 接收方收到会话 `ZFIN` 时回 `ZFIN`，之后 CLI 接收函数返回；
  **没有另行等待/消费 `OO` 的步骤**。来源：
  `zmodem.c:2375-2377`；`sexyz.c:1302-1320`。
- 发送方 `zmodem_get_zfin()` 交替尝试 `ZFIN` / `ZABORT`，收到对端 `ZFIN`
  后发送 `OO`。**调用者忽略这个函数的返回值**，所以最后握手失败也可能与
  file success、exit 0 并存。不能删去父级终态断言。来源：
  `zmodem.c:1640-1676`；`sexyz.c:1184-1191,1216`。
- `sz` 的常见失败返回 `-1`，进程 exit status 为 255；接收取消路径返回 1，
  初始化/其他路径可能返回 -1。`rz` 尚未成功收到文件便遇到结束报文时返回
  `!success`，即 1；不能把空批次一概期待为 exit 0。来源：
  `sexyz.c:1187-1191,1230,1304-1320,1554,1557-1564,2188-2189`。
- 接收文件直接创建/截断并写入，失败或取消后没有在 CLI 路径自动移除部分文件
  的步骤；后续重试可能触发现存文件 `ZSKIP`。来源：
  `sexyz.c:1372-1404,1420-1426,1487-1538`。不要用库中另一个
  `zmodem_recv_files()` 的清理行为替代实际 CLI 的 `receive_files()`。
- 内部默认 init/send/recv timeout 为 10 秒，CRC query timeout 为 120 秒，
  max_errors 为 9；收尾还有 producer/ring/output drain 等等待。
  **这些不是整个会话的总 timeout**。父级须保留自己的有界 wait、身份绑定和
  实际 reap；本准备使用的管理脚本不插入后续通信链路。
  来源：`zmodem.c:2602-2613`；`sexyz.c:2168-2188`。
- 正常 `exit()` 的 atexit 恢复原 termios；SIGKILL 无法执行恢复。
  来源：`sexyz.c:1629-1652,1564`。

## 依赖与许可边界

官方 standalone `COMPILING.md:16-20` 说明 Unix 需要 GNU make、C 编译器、
libc/pthreads；此次实际 `otool -L` 只发现系统 libSystem。
没有 SDK crate、Rust/Cargo、Homebrew 安装、专有 SSH 库或外部传输进程依赖。

按该固定提交 `COMPILING.md:130-143` 与源文件头：

- `zmodem.c/h` 为 2-clause BSD；
- SexyZ 入口、Xmodem、ringbuf、nopen、date_str、telnet 等为 GPL v2-or-later；
- xpdev/hash 相关文件为 LGPL v2-or-later；
- 上游明确把组合后可执行文件的有效许可记作 GPL。

保留原源码、版权和许可声明。此次仅将它留作外部联调 peer，没有全局安装、
复制进 KeelShell.app 或发布包。未来若发布此二进制或集成/链接，需要单独落实
相应分发许可要求；此次准备不代签应用分发的授权。

## 记录、失败与资源归属

`logs/<label>.json` 含精确 argv、cwd、timeout、时间、原始 returncode、
timeout/interruption、直接子进程 reap、剩余进程组成员与 process-group-absent。
同 label 的 stdout/stderr 分开保存，不覆盖原件。

| 独立 label | 上限 | 结果 |
| --- | --- | --- |
| `upstream-head-r1` | 45s | exit 0；固定 master/HEAD SHA |
| `toolchain-versions-r1` | 20s | exit 0；clang/make/git/curl/SDK |
| `upstream-archive-fetch-r1` | 120s（curl 110s） | exit 0；归档完整，约 90.03s |
| `upstream-commit-fetch-r1` | 45s（curl 35s） | exit 0；GitHub 原件 |
| `upstream-archive-inspect-r1` | 45s | exit 0；摘要/成员数 |
| `upstream-source-extract-r1` | 45s | exit 0；选定源文件抽取与基线 |
| `standalone-prepare-r1` | 30s | **exit 1**；本地 helper 对续行反斜杠的解析错误 |
| `standalone-prepare-r2` | 30s | exit 0；修正 helper 后逐字节复制 |
| `native-arm64-build-r1` | 180s | exit 0；`make -j2` |
| `sexyz-version-r1` | 10s | exit 0 |
| `sexyz-usage-r1` | 10s | **exit 1**；无 command 的上游预期 usage 行为 |
| `native-linkage-inspect-r1` | 15s | exit 0；摘要/架构/动态库/minos |
| `final-audit-r1` | 30s | 见回执；重新核对源码、编译输入、归档、二进制、收口 |

首次准备失败的原脚本在 `evidence/prepare_standalone-r1-failed.py`，
当时已复制的 7 个文件在 `failed-standalone-prepare-r1/`，日志完整保留。
这不是上游编译失败；唯一一次正式 native build 成功。usage exit 1 也原样保留。
没有因失败切换 peer 或降低父级验收条件。

所有创建资源仅在本目录：

- `downloads/`：固定官方归档、commit 元数据。
- `source/`：上游未改源码子集与构建文件。
- `build-standalone/`：原版源码/Makefile、标准版本头、22 个对象与可执行文件。
- `failed-standalone-prepare-r1/`：首次准备失败时的源文件副本。
- `logs/`：全部有界进程的原始 stdout/stderr/JSON 回执。
- `evidence/`：归档摘要、源基线、编译输入映射、原失败脚本、最终核对。
- `runtime/`：四个空接收目录及空日志目录，供父级选择使用。
- `tmp/`、`cache/`：仅本任务的临时/缓存位置。
- 根目录：本 README、`peer.json`、`resources.json`、
  `run_bounded.py`、`prepare_standalone.py`、`final_audit.py`。

完整逐文件路径、大小、权限和摘要以 `resources.json` 为准（清单自身不自哈希）。
无持续运行进程、容器、监听端口、SSH 服务、用户 chat 或 worktree。
全部有界命令均已等待直接子进程退出，并记录自有进程组消失。
没有运行 Cargo、触碰其他任务 target/容器、改 tracked 文件、提交或推送。
只读必需 AGENTS/HANDOFF 后，后续读取限定在本任务源文件与系统工具/元数据。
任务交付后停止，等待父级回收；源码与构建资源未自行删除。
