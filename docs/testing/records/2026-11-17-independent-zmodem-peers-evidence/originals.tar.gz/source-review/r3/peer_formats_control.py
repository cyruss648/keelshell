"""Offline source-derived r3 observer controls; no Rust or peer execution."""

import binascii
import io
import json
from pathlib import Path
import sys
import unittest
import zlib

OUTPUT = Path(__file__).resolve().parent
SOURCE = (OUTPUT / "reviewed-source/crates/keelshell-session/tests/zmodem_openssh.rs").read_text()


def escaped(data):
    result = bytearray()
    for byte in data:
        if byte == 0x7F:
            result.extend((0x18, ord("l")))
        elif byte == 0xFF:
            result.extend((0x18, ord("m")))
        elif byte & 0x60 == 0:
            result.extend((0x18, byte ^ 0x40))
        else:
            result.append(byte)
    return bytes(result)


def checksum(data, binary32):
    if binary32:
        return zlib.crc32(data).to_bytes(4, "little")
    return binascii.crc_hqx(data, 0).to_bytes(2, "big")


def source_observer(chunks):
    suffix = [0, 0]
    binary16 = False
    binary32 = False
    for chunk in chunks:
        for byte in chunk:
            if suffix == [ord("*"), 0x18]:
                binary16 |= byte == ord("A")
                binary32 |= byte == ord("C")
            suffix = [suffix[1], byte]
    return {"binary16": binary16, "binary32": binary32}


class PeerFormatsDeltaTests(unittest.TestCase):
    def test_fixed_state_and_observation_before_controller_feed(self):
        definition = SOURCE[SOURCE.index("struct PeerFormats {"):SOURCE.index("\nimpl Fixture {")]
        self.assertIn("suffix: [u8; 2]", definition)
        self.assertNotIn("Vec", definition)
        self.assertIn("self.suffix == [b'*', 0x18]", definition)
        self.assertIn("self.binary16 |= byte == b'A'", definition)
        self.assertIn("self.binary32 |= byte == b'C'", definition)
        self.assertLess(SOURCE.index("formats.observe(bytes)"), SOURCE.index("controller.feed("))

    def test_actual_header_markers_are_recognized_across_all_single_split_boundaries(self):
        for marker, expected in (
            (b"*\x18A", {"binary16": True, "binary32": False}),
            (b"*\x18C", {"binary16": False, "binary32": True}),
        ):
            for index in range(len(marker) + 1):
                with self.subTest(marker=marker.hex(), split=index):
                    self.assertEqual(source_observer([marker[:index], marker[index:]]), expected)

    def test_valid_escaped_data_does_not_claim_the_opposite_header_format(self):
        observations = []
        for binary32 in (False, True):
            # A ZDATA header followed by a complete CRC-valid data subpacket.
            # Only its actual header uses A or C as a format marker. The data
            # has legitimate escaped 0x01 and 0x03 after a literal '*'.
            payload = b"*\x01*\x03"
            raw_header = b"\x0a\0\0\0\0"
            header_crc = checksum(raw_header, binary32)
            data_crc = checksum(payload + b"h", binary32)
            header = b"*\x18" + (b"C" if binary32 else b"A") + escaped(raw_header + header_crc)
            data = escaped(payload) + b"\x18h" + escaped(data_crc)
            self.assertEqual(header_crc, checksum(raw_header, binary32))
            self.assertEqual(data_crc, checksum(payload + b"h", binary32))
            wire = header + data
            observed = source_observer([wire])
            expected = {"binary16": not binary32, "binary32": binary32}
            observations.append({
                "actual_header_format": "Binary32" if binary32 else "Binary16",
                "payload_hex": payload.hex(), "wire_hex": wire.hex(),
                "header_crc_hex": header_crc.hex(), "data_crc_hex": data_crc.hex(),
                "source_observer": observed, "expected": expected,
                "boundary": "Source-derived observer and CRC-valid wire construction; no Rust, SSH or peer execution",
            })
            with self.subTest(binary32=binary32):
                self.assertEqual(
                    observed, expected,
                    "Valid escaped payload is misclassified as an opposite-format binary header",
                )
        (OUTPUT / "escaped-data-counterexamples.json").write_text(
            json.dumps(observations, indent=2) + "\n"
        )


if __name__ == "__main__":
    stream = io.StringIO()
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(PeerFormatsDeltaTests)
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    text = stream.getvalue()
    (OUTPUT / "peer-formats-control.test-output.txt").write_text(text)
    (OUTPUT / "peer-formats-control.result.json").write_text(json.dumps({
        "tests_run": result.testsRun, "unique_tests": 3,
        "passed_unique_tests": 2, "failed_unique_tests": 1,
        "failure_records": len(result.failures), "errors": len(result.errors),
        "skipped": len(result.skipped),
        "test_ids": [
            "__main__.PeerFormatsDeltaTests." + name
            for name in unittest.defaultTestLoader.getTestCaseNames(PeerFormatsDeltaTests)
        ],
        "rust_executed": False, "cargo_executed": False, "ssh_executed": False,
        "success": result.wasSuccessful(),
    }, indent=2) + "\n")
    sys.stderr.write(text)
    sys.exit(0 if result.wasSuccessful() else 1)
