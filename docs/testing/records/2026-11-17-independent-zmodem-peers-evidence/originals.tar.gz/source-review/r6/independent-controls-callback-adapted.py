"""Independent source and offline failure controls; no Cargo or SSH execution."""
import ast
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import random
import signal
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
import openssh_interop as interop
OUTPUT = Path(__file__).resolve().parent
ROOT = OUTPUT.parents[1]
RUST = (ROOT / 'crates/keelshell-session/tests/zmodem_openssh.rs').read_text()
PYTHON = (ROOT / 'scripts/openssh_interop.py').read_text()
BASE_RUST = (OUTPUT / 'baseline-zmodem_openssh.rs.stdout').read_text()
BASE_PYTHON = (OUTPUT / 'baseline-openssh_interop.py.stdout').read_text()

def record(name, value):
    (OUTPUT / (name + '.json')).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def node(text, name):
    return next((item for item in ast.parse(text).body if getattr(item, 'name', '') == name))

def quote(value):
    return "'" + value.replace("'", "'\\''") + "'"

class StaticContractTests(unittest.TestCase):

    def test_all_eight_legacy_peer_bodies_and_strict_completed_helper_are_byte_identical(self):
        suffix = BASE_RUST[BASE_RUST.index('fn completed('):]
        self.assertIn(suffix, RUST)
        self.assertEqual(suffix.count('#[ignore = '), 8)
        self.assertEqual(RUST.count('#[ignore = '), 10)
        self.assertEqual(RUST.count('\n#[test]'), 6)
        self.assertIn('Ui::Finished', suffix)
        self.assertIn('ShellEnd::Exited { code: 0 }', suffix)
        record('rust-static-inventory', {'baseline_real_peer_test_count': 8, 'candidate_real_peer_test_count': 10, 'candidate_argument_test_count': 6, 'all_six_argument_tests_and_ten_peer_tests_executed_here': False, 'legacy_peer_bodies_and_completed_helper_byte_identical': True})

    def test_runner_ownership_deadline_and_cleanup_functions_are_ast_identical(self):
        names = ['executable', 'process_info', 'process_table', 'same_process', 'remember_owned', 'signal_owned', 'stop_owned', 'Runner', 'wait_for_server', 'create_output']
        for name in names:
            with self.subTest(name=name):
                self.assertEqual(ast.dump(node(PYTHON, name), include_attributes=False), ast.dump(node(BASE_PYTHON, name), include_attributes=False))
        old = BASE_PYTHON[BASE_PYTHON.index('            finally:\n'):]
        self.assertIn(old, PYTHON)
        record('python-static-preservation', {'ast_identical_definitions': names, 'main_cleanup_and_receipt_tail_byte_identical': True})

    def test_existing_eight_python_inventory_controls_are_unchanged(self):
        old = (OUTPUT / 'baseline-test_openssh_interop.py.stdout').read_text()
        current = (ROOT / 'scripts/test_openssh_interop.py').read_text()
        self.assertEqual(ast.dump(node(current, 'ProcessInventoryTests'), include_attributes=False), ast.dump(node(old, 'ProcessInventoryTests'), include_attributes=False))

    def test_rust_and_python_argument_limits_and_order_match_the_adr(self):
        parser = RUST[RUST.index('fn peer_arguments('):RUST.index('\nfn quote(')]
        for literal in ('16_384', '> 32', '> 2048', '> 8192', 'byte < 32', 'byte == 127'):
            self.assertIn(literal, parser)
        self.assertEqual((interop.ZMODEM_ARGS_JSON_BYTES, interop.ZMODEM_MAX_ARGS, interop.ZMODEM_ARG_BYTES, interop.ZMODEM_ARGS_BYTES), (16384, 32, 2048, 8192))
        order = '.copied()\n            .chain(args.iter().map(String::as_str))\n            .chain(names.iter().copied())\n            .map(quote)'
        self.assertIn(order, RUST)

    def test_actual_posix_shell_keeps_source_quoted_arguments_literal_and_options_first(self):
        directory = OUTPUT / 'shell-probes'
        directory.mkdir(exist_ok=True)
        marker = directory / 'expanded-marker'
        marker2 = directory / 'backtick-marker'
        arguments = ['-raw', 'sz', '', '逐项 😀', '\x85', "a'b", 'a"b', 'a b', '$HOME', '$(touch ' + str(marker) + ')', '`touch ' + str(marker2) + '`', '*;|&<>', 'a\\b']
        expected = ['-o', *arguments, '源文件.bin', 'empty.bin']
        snippet = 'import json, sys; print(json.dumps(sys.argv[1:], ensure_ascii=False))'
        command = 'exec ' + ' '.join((quote(value) for value in [sys.executable, '-c', snippet, *expected])) + '\n'
        script = directory / 'literal-argv.sh'
        script.write_text(command)
        argv = ['/bin/sh', str(script)]
        result = subprocess.run(argv, cwd=directory, capture_output=True, text=True, timeout=10, env={'PATH': '/usr/bin:/bin', 'HOME': str(directory)})
        record('local-shell-probe', {'argv': argv, 'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr, 'expected_arguments': expected, 'boundary': 'POSIX shell plus source-derived quoting; no Rust, SSH or PTY'})
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), expected)
        self.assertFalse(marker.exists())
        self.assertFalse(marker2.exists())

    def test_multi_file_assertions_reject_wrong_review_metadata_and_save_receipts(self):
        body = RUST[RUST.index('async fn real_sz_download_batch_requires_a_separate_review'):RUST.index('async fn real_sz_cancel_after_one_saved_file')]
        self.assertIn('Some((review, files))', body)
        self.assertIn('files.len() == 1', body)
        self.assertNotIn('sha256', body)
        self.assertNotIn('Ui::FileSaved { path', body)
        names = ['binary.bin', '逐项审核.txt', 'empty.bin']
        contents = [bytes(range(256)) * 1024 + bytes(range(12)), '独立文件审核\r\n'.encode(), b'']
        reviews = [{'review': str(index), 'files': [{'path': names[0], 'name': names[0], 'size': 1}]} for index in range(3)]
        saves = [{'path': 'unrelated.bin', 'bytes': 1, 'sha256': 'wrong'}] * 3
        actual_files = dict(zip(names, contents))
        accepted_by_current_postconditions = len(saves) == 3 and len(reviews) == 3 and all((len(review['files']) == 1 for review in reviews)) and (len({review['review'] for review in reviews}) == 3) and all((actual_files[name] == content for name, content in zip(names, contents)))
        record('multi-file-assertion-counterexample', {'reviews': reviews, 'save_receipts': saves, 'end': {'Exited': {'code': 0}}, 'has_finished': True, 'physical_files_correct': True, 'accepted_by_current_postconditions': accepted_by_current_postconditions, 'boundary': 'Static predicate counterexample, not a Rust or real-peer execution'})
        self.assertFalse(accepted_by_current_postconditions, 'The current Rust postconditions accept three incorrect per-file reviews/save receipts')

class ArgumentRoundtripTests(unittest.TestCase):

    def test_normalization_preserves_accepted_values_and_all_downstream_byte_budgets(self):
        rng = random.Random(20261117)
        alphabet = ['x', "'", '"', '\\', '界', 'é', '😀', '\x85', '$', ' ']
        corpus = [[], [''] * 32, ['😀' * 512] * 4, ['\\' * 2048] * 3 + ['\\' * 2028], ['界' * 682 + 'ab'] * 4]
        for _ in range(128):
            corpus.append([''.join(rng.choices(alphabet, k=rng.randrange(0, 100))) for _ in range(rng.randrange(0, 20))])
        for index, arguments in enumerate(corpus):
            raw = json.dumps(arguments, ensure_ascii=False, separators=(',', ':'))
            if len(raw.encode()) > 16384:
                continue
            with self.subTest(index=index):
                parsed = interop.zmodem_peer_args(raw, 'REVIEW_ARGS')
                normalized = json.dumps(parsed, ensure_ascii=False, separators=(',', ':'))
                self.assertEqual(interop.zmodem_peer_args(normalized, 'REVIEW_ARGS'), arguments)
                self.assertLessEqual(len(normalized.encode()), 16384)
                self.assertLessEqual(len(parsed), 32)
                self.assertLessEqual(sum((len(value.encode()) for value in parsed)), 8192)
                self.assertTrue(all((len(value.encode()) <= 2048 for value in parsed)))
        record('argument-roundtrip-corpus', {'seed': 20261117, 'case_count': len(corpus)})

    def test_json_raw_byte_budget_is_independent_of_equal_decoded_arguments(self):
        arguments = ['😀' * 512] * 4
        compact = json.dumps(arguments, ensure_ascii=False, separators=(',', ':'))
        escaped = json.dumps(arguments, ensure_ascii=True, separators=(',', ':'))
        self.assertEqual(len(''.join(arguments).encode()), 8192)
        self.assertEqual(interop.zmodem_peer_args(compact, 'ARGS'), arguments)
        self.assertGreater(len(escaped.encode()), 16384)
        with self.assertRaisesRegex(interop.InteropFailure, 'JSON budget'):
            interop.zmodem_peer_args(escaped, 'ARGS')

class PreflightFailureTests(unittest.TestCase):

    def setUp(self):
        self.root = Path(self.enterContext(tempfile.TemporaryDirectory(prefix='independent-', dir=OUTPUT / 'tmp')))
        self.environment = {}
        for role in ('RZ', 'SZ'):
            path = self.root / role.lower()
            path.write_bytes(b'#!/fixture-never-executed\n' + role.encode())
            path.chmod(448)
            self.environment['KEELSHELL_ZMODEM_' + role] = str(path)

    def run_main(self, name, *, clock=None, read_side_effect=None, signal_request=None, lookup_error=None):
        output = self.root / name
        handlers = {}
        real_open = interop.Path.open
        peers = {Path(value) for value in self.environment.values()}
        requested = False

        def handler(sig, callback):
            if sig not in handlers and callable(callback):
                handlers[sig] = callback
            return None

        def peer_open(path, mode='r', *args, **kwargs):
            if path not in peers or mode != 'rb' or read_side_effect is None:
                return real_open(path, mode, *args, **kwargs)

            class Stream:

                def __enter__(self):
                    return self

                def __exit__(self, *_):
                    return False

                def read(self, size):
                    nonlocal requested
                    if signal_request is not None and (not requested):
                        handlers[signal_request](signal_request, None)
                        requested = True
                    return read_side_effect(path, size)
            return Stream()
        with contextlib.ExitStack() as stack:
            stack.enter_context(patch.dict(os.environ, self.environment, clear=True))
            stack.enter_context(patch.object(interop, 'ROOT', self.root))
            stack.enter_context(patch.object(sys, 'argv', ['openssh_interop.py', '--zmodem', '--timeout', '15', '--output', str(output)]))
            stack.enter_context(patch.object(interop.os, 'umask'))
            stack.enter_context(patch.object(interop.signal, 'signal', side_effect=handler))
            stack.enter_context(patch.object(interop.Path, 'open', peer_open))
            if clock is not None:
                stack.enter_context(patch.object(interop.time, 'monotonic', side_effect=lambda: clock['now']))
            lookup = stack.enter_context(patch.object(interop, 'executable', side_effect=lookup_error or interop.InteropFailure('offline lookup sentinel')))
            mkdtemp = stack.enter_context(patch.object(interop.tempfile, 'mkdtemp'))
            popen = stack.enter_context(patch.object(interop.subprocess, 'Popen'))
            run = stack.enter_context(patch.object(interop.subprocess, 'run'))
            stdout = stack.enter_context(contextlib.redirect_stdout(io.StringIO()))
            stderr = stack.enter_context(contextlib.redirect_stderr(io.StringIO()))
            result = interop.main()
            popen.assert_not_called()
            run.assert_not_called()
            mkdtemp.assert_not_called()
        receipt = json.loads((output / 'result.json').read_text())
        record(name, {'returncode': result, 'receipt': receipt, 'stdout': stdout.getvalue(), 'stderr': stderr.getvalue(), 'executable_lookup_calls': lookup.call_count})
        return (result, receipt, lookup.call_count)

    def test_expiration_between_hash_chunks_preserves_failed_receipt_and_resource_boundary(self):
        clock = {'now': 100.0}
        reads = []

        def read(path, size):
            reads.append((str(path), size))
            clock['now'] = 103.0
            return b'hash chunk'
        result, receipt, lookups = self.run_main('deadline-between-chunks', clock=clock, read_side_effect=read)
        self.assertEqual(result, 1)
        self.assertEqual(receipt['outcome'], 'failed')
        self.assertIn('deadline', receipt['error'])
        self.assertEqual(len(reads), 1)
        self.assertEqual(lookups, 0)
        self.assertEqual(receipt['processes'], [])
        self.assertNotIn('temporary_directory', receipt)
        self.assertTrue(receipt['cleanup']['owned_processes_stopped'])
        self.assertTrue(receipt['cleanup']['temporary_directory_removed'])

    def test_interrupt_during_preflight_is_observed_before_more_hash_work_or_setup(self):
        for requested_signal in (signal.SIGINT, signal.SIGTERM):
            with self.subTest(signal=requested_signal):
                clock = {'now': 100.0}
                reads = []

                def read(path, size):
                    reads.append(str(path))
                    clock['now'] += 1.0
                    return b'bounded simulated slow hash chunk'
                result, receipt, lookups = self.run_main('interrupt-preflight-' + str(requested_signal), clock=clock, read_side_effect=read, signal_request=requested_signal)
                self.assertEqual((result, receipt['outcome']), (130, 'interrupted'), 'A signal in new preflight is ignored until its work deadline and recorded as failed')
                self.assertEqual(len(reads), 1)
                self.assertEqual(lookups, 0)

    def test_midstream_peer_read_failure_is_sanitized_and_creates_no_ssh_resources(self):
        calls = []

        def read(path, size):
            calls.append(str(path))
            if len(calls) == 1:
                return b'first chunk'
            raise OSError('private-control-marker')
        result, receipt, lookups = self.run_main('midstream-read-error', read_side_effect=read)
        self.assertEqual(result, 1)
        self.assertEqual(receipt['outcome'], 'failed')
        self.assertEqual(len(calls), 2)
        self.assertEqual(lookups, 0)
        self.assertEqual(receipt['processes'], [])
        self.assertNotIn('private-control-marker', json.dumps(receipt))
        self.assertTrue(receipt['cleanup']['temporary_directory_removed'])

    def test_successful_preflight_is_recorded_when_a_later_prerequisite_fails(self):
        expected = interop.zmodem_peers(self.environment, interop.time.monotonic() + 10, lambda: None)
        result, receipt, lookups = self.run_main('after-preflight-lookup-error')
        self.assertEqual(result, 1)
        self.assertEqual(receipt['zmodem_peers'], expected)
        self.assertEqual(lookups, 1)
        self.assertEqual(receipt['processes'], [])
        self.assertNotIn('temporary_directory', receipt)

    def test_preflight_digest_binds_only_observed_bytes_not_upstream_or_later_execution(self):
        peers = interop.zmodem_peers(self.environment, interop.time.monotonic() + 10, lambda: None)
        path = Path(self.environment['KEELSHELL_ZMODEM_SZ'])
        original = peers['sz']['sha256']
        path.write_bytes(b'replacement executable bytes; never executed')
        current = hashlib.sha256(path.read_bytes()).hexdigest()
        self.assertNotEqual(original, current)
        self.assertEqual(peers['sz']['sha256'], original)
        self.assertNotIn('source_commit', peers['sz'])
        record('preflight-binding-boundary', {'path': str(path), 'preflight_sha256': original, 'after_replacement_sha256': current, 'upstream_source_commit_bound_by_runner': False, '765_engineering_inputs_bound_by_runner': False, 'runtime_execution_identity_established': False, 'boundary': 'Snapshot of readable executable bytes at preflight only'})
