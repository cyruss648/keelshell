"""Validate frozen r6 Python and targeted controls without Cargo or SSH."""

import argparse
import ast
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import time
import types
import unittest

OUTPUT = Path(__file__).resolve().parent
REVIEW = OUTPUT.parent
FROZEN = OUTPUT / "reviewed-source"
sys.dont_write_bytecode = True
sys.path.insert(0, str(REVIEW))
import run_python_review as harness

sys.path.insert(0, str(FROZEN / "scripts"))
tempfile.tempdir = str(OUTPUT / "tmp")


class CallbackAdapter(ast.NodeTransformer):
    """Only add a no-op callback to the old controls' direct preflight calls."""

    count = 0

    def visit_Call(self, node):
        self.generic_visit(node)
        if (
            isinstance(node.func, ast.Attribute)
            and node.func.attr == "zmodem_peers"
            and len(node.args) == 2
        ):
            node.args.append(ast.parse("lambda: None", mode="eval").body)
            self.count += 1
        return node


def independent_suite():
    original = REVIEW / "independent_controls.py"
    adapter = CallbackAdapter()
    tree = adapter.visit(ast.parse(original.read_text()))
    ast.fix_missing_locations(tree)
    if adapter.count != 2:
        raise RuntimeError(f"Unexpected number of adapted calls: {adapter.count}")
    adapted = OUTPUT / "independent-controls-callback-adapted.py"
    adapted.write_text(ast.unparse(tree) + "\n")
    legacy = types.ModuleType("independent_review_controls_r6")
    legacy.__file__ = str(original)
    sys.modules[legacy.__name__] = legacy
    exec(compile(tree, str(adapted), "exec"), legacy.__dict__)
    legacy.OUTPUT = OUTPUT
    legacy.RUST = (FROZEN / "crates/keelshell-session/tests/zmodem_openssh.rs").read_text()
    legacy.PYTHON = (FROZEN / "scripts/openssh_interop.py").read_text()

    spec = importlib.util.spec_from_file_location(
        "peer_formats_r6", REVIEW / "r3/peer_formats_control.py"
    )
    peer = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = peer
    spec.loader.exec_module(peer)
    peer.OUTPUT = OUTPUT
    peer.SOURCE = legacy.RUST
    old_rust = (REVIEW / "r3/reviewed-source/crates/keelshell-session/tests/zmodem_openssh.rs").read_text()
    region = lambda text: text[text.index("struct PeerFormats {"):text.index("\nimpl Fixture {")]
    if region(old_rust) != region(legacy.RUST):
        raise RuntimeError("PeerFormats changed; the r3 counterexample model needs fresh review")
    (OUTPUT / "control-adaptation.json").write_text(json.dumps({
        "original_controls": str(original),
        "adapted_controls": str(adapted),
        "adaptation": "Added lambda: None to exactly two direct zmodem_peers calls",
        "assertions_changed": False,
        "signal_callback_and_main_controls_unchanged": True,
        "peer_formats_r3_to_r6_byte_identical": True,
        "boundary": "Five actual Python failure controls plus three source-derived observer controls; no Rust execution",
    }, indent=2) + "\n")
    return unittest.TestSuite([
        unittest.defaultTestLoader.loadTestsFromTestCase(legacy.PreflightFailureTests),
        unittest.defaultTestLoader.loadTestsFromTestCase(peer.PeerFormatsDeltaTests),
    ])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=("current30", "independent8"))
    stage = parser.parse_args().stage
    if stage == "current30":
        suite = unittest.defaultTestLoader.discover(
            str(FROZEN / "scripts"), pattern="test_openssh_interop.py"
        )
        expected = 30
    else:
        suite = independent_suite()
        expected = 8
    if suite.countTestCases() != expected:
        raise RuntimeError("Unexpected test inventory")
    sys.addaudithook(harness.audit)
    started = time.monotonic()
    result = unittest.TextTestRunner(
        verbosity=2, resultclass=harness.RecordedResult
    ).run(suite)
    failed_ids = sorted({
        identifier
        for identifier in result.started_ids
        if any(test.id().startswith(identifier) for test, _ in result.failures + result.errors)
    })
    receipt = {
        "revision": "r6",
        "stage": stage,
        "frozen_source": str(FROZEN),
        "tests_run": result.testsRun,
        "unique_tests": len(set(result.started_ids)),
        "passed": len(result.passed_ids),
        "failed_unique_tests": len(failed_ids),
        "failed_test_ids": failed_ids,
        "failure_records": [{"id": test.id(), "traceback": text} for test, text in result.failures],
        "errors": [{"id": test.id(), "traceback": text} for test, text in result.errors],
        "skipped": [{"id": test.id(), "reason": reason} for test, reason in result.skipped],
        "test_ids": result.started_ids,
        "subtests": result.subtests,
        "elapsed_seconds": time.monotonic() - started,
        "success": result.wasSuccessful(),
        "cargo_executed": False,
        "rust_tests_executed": False,
        "ssh_executed": False,
        "network_connections_allowed": False,
    }
    (OUTPUT / (stage + ".result.json")).write_text(
        json.dumps(receipt, ensure_ascii=False, indent=2) + "\n"
    )
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    sys.exit(main())
