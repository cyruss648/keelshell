"""Independent CRC oracle and source-derived r7 observer model, never Rust execution."""

import ast
import binascii
import hashlib
import json
from pathlib import Path
import re
import unittest
import zlib

OUTPUT = Path(__file__).resolve().parent
SOURCE = (
    OUTPUT / "reviewed-source/crates/keelshell-session/tests/zmodem_openssh.rs"
).read_text()
REGION = SOURCE[SOURCE.index("struct FirstDataHeader {"):SOURCE.index("\nimpl Fixture {")]
FLOW = bytes([0x11, 0x13, 0x91, 0x93, 13, 10])
VECTORS = {
    kind: ast.literal_eval(
        re.search(rf"const DATA{kind}: &\[u8\] = (b\"[^\n]+\");", SOURCE).group(1)
    )
    for kind in (16, 32)
}


def unescape(raw):
    result = bytearray()
    index = 0
    while index < len(raw):
        byte = raw[index]
        if byte == 0x18:
            index += 1
            if index == len(raw):
                raise ValueError("Incomplete escaped byte")
            byte = raw[index] ^ 0x40
        result.append(byte)
        index += 1
    return bytes(result)


class ObserverModel:
    """Manual translation of the frozen observe method; association is recorded."""

    def __init__(self):
        self.prefix = bytearray()
        self.format = None

    def observe(self, data):
        if self.format is not None:
            return
        self.prefix.extend(data[:96 - len(self.prefix)])
        index = next(
            (index for index, byte in enumerate(self.prefix) if byte not in FLOW),
            len(self.prefix),
        )
        candidate = self.prefix[index:]
        pads = 0
        for byte in candidate:
            if byte != ord("*"):
                break
            pads += 1
        if pads not in (1, 2):
            return
        for kind, golden in VECTORS.items():
            if candidate[pads:].startswith(golden[1:]):
                self.format = kind
                break


class FirstDataHeaderControls(unittest.TestCase):
    def test_vectors_match_independent_crc_oracles_for_zdata_offset_zero(self):
        checks = []
        for kind, wire in VECTORS.items():
            with self.subTest(format=kind):
                self.assertEqual(wire[:3], b"*\x18" + (b"A" if kind == 16 else b"C"))
                decoded = unescape(wire[3:])
                self.assertEqual(decoded[:5], bytes([10, 0, 0, 0, 0]))
                body, checksum = decoded[:5], decoded[5:]
                expected = (
                    binascii.crc_hqx(body, 0).to_bytes(2, "big")
                    if kind == 16 else zlib.crc32(body).to_bytes(4, "little")
                )
                self.assertEqual(checksum, expected)
                checks.append({
                    "format": kind, "wire_hex": wire.hex(),
                    "header_hex": body.hex(), "crc_hex": checksum.hex(),
                    "oracle": "binascii.crc_hqx(0), big endian" if kind == 16
                    else "zlib.crc32, little endian",
                })
        (OUTPUT / "independent-crc-oracle.json").write_text(
            json.dumps(checks, indent=2) + "\n"
        )

    def test_every_split_and_bytewise_input_recognize_only_the_initial_header(self):
        cases = 0
        for kind, golden in VECTORS.items():
            opposite_payload = b"*\x18C" if kind == 16 else b"*\x18A"
            for flow in (b"", FLOW, b"\r\n", FLOW * 3):
                for pads in (1, 2):
                    wire = flow + b"*" * pads + golden[1:] + opposite_payload
                    for split in range(len(wire) + 1):
                        with self.subTest(format=kind, flow=flow.hex(), pads=pads, split=split):
                            observer = ObserverModel()
                            observer.observe(wire[:split])
                            observer.observe(wire[split:])
                            self.assertEqual(observer.format, kind)
                            self.assertLessEqual(len(observer.prefix), 96)
                            cases += 1
                    observer = ObserverModel()
                    for byte in wire:
                        observer.observe(bytes([byte]))
                    self.assertEqual(observer.format, kind)
        (OUTPUT / "observer-split-coverage.json").write_text(
            json.dumps({"two_chunk_split_cases": cases, "bytewise_cases": 16}, indent=2) + "\n"
        )

    def test_recognition_is_sealed_before_opposite_format_payload_or_later_headers(self):
        for kind, golden in VECTORS.items():
            observer = ObserverModel()
            observer.observe(golden)
            before = bytes(observer.prefix)
            opposite = VECTORS[32 if kind == 16 else 16]
            for payload in (opposite * 1000, b"*\x18A*\x18C", FLOW * 1000):
                observer.observe(payload)
                self.assertEqual(observer.format, kind)
                self.assertEqual(bytes(observer.prefix), before)

    def test_corrupt_crc_or_header_and_payload_noise_never_resynchronize(self):
        cases = 0
        for kind, golden in VECTORS.items():
            # Every bit in the raw checksum bytes is changed independently.
            crc_start = len(golden) - (2 if kind == 16 else 6)
            bad_inputs = []
            for index in range(crc_start, len(golden)):
                for bit in range(8):
                    bad = bytearray(golden)
                    bad[index] ^= 1 << bit
                    bad_inputs.append(bytes(bad))
            bad_inputs.extend((
                b"noise" + golden,
                b"*\x18C" + VECTORS[16],
                b"*\x18A" + VECTORS[32],
                b"*\x18B00000000000000\r\n" + golden,
                golden[:3] + b"\x18K" + golden[5:],
                b"*" + golden,
            ))
            # Two pads are valid; remove that deliberate valid case here.
            bad_inputs.pop()
            for bad in bad_inputs:
                for split in (0, len(bad) // 2, len(bad)):
                    observer = ObserverModel()
                    observer.observe(bad[:split])
                    observer.observe(bad[split:])
                    observer.observe(VECTORS[32 if kind == 16 else 16])
                    self.assertIsNone(observer.format, (kind, bad.hex(), split))
                    self.assertLessEqual(len(observer.prefix), 96)
                    cases += 1
        (OUTPUT / "observer-rejected-corpus.json").write_text(
            json.dumps({"corruption_noise_split_cases": cases, "payload_rescan": False}, indent=2) + "\n"
        )

    def test_budget_accepts_header_ending_at_96_and_never_reads_past_the_cap(self):
        for kind, golden in VECTORS.items():
            for pads in (1, 2):
                header = b"*" * pads + golden[1:]
                accepted = FLOW[:1] * (96 - len(header)) + header
                self.assertEqual(len(accepted), 96)
                observer = ObserverModel()
                for byte in accepted:
                    observer.observe(bytes([byte]))
                self.assertEqual(observer.format, kind)
                self.assertEqual(len(observer.prefix), 96)
                observer.observe(VECTORS[32 if kind == 16 else 16] * 1000)
                self.assertEqual(observer.format, kind)
                self.assertEqual(len(observer.prefix), 96)
                for rejected in (
                    FLOW[:1] + accepted,
                    FLOW[:1] * 97 + golden,
                    golden[:-1] + b"noise" * 10000 + golden,
                ):
                    observer = ObserverModel()
                    for split in range(0, len(rejected), 17):
                        observer.observe(rejected[split:split + 17])
                    self.assertIsNone(observer.format)
                    self.assertEqual(len(observer.prefix), 96)

    def test_prefix_policy_rejects_extra_padding_noise_and_truncated_headers(self):
        for kind, golden in VECTORS.items():
            for wire in (
                golden[1:], b"**" + golden, b"***" + golden,
                b" " + golden, b"\0" + golden, b"\x7f" + golden,
                b"*\x18B" + golden[3:], golden[:-1], b"", FLOW,
            ):
                observer = ObserverModel()
                observer.observe(wire)
                self.assertIsNone(observer.format, (kind, wire.hex()))
        (OUTPUT / "observer-model-binding.json").write_text(json.dumps({
            "source": str(OUTPUT / "reviewed-source/crates/keelshell-session/tests/zmodem_openssh.rs"),
            "observer_region_sha256": hashlib.sha256(REGION.encode()).hexdigest(),
            "association": "Manual source-derived model of the reviewed FirstDataHeader::observe method",
            "rust_executed": False,
            "scope": "Initial complete ZDATA/offset0 canonical escaped header only, not all headers or batches",
        }, indent=2) + "\n")
