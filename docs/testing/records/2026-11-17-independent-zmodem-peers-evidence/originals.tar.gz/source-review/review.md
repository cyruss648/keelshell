r7 原三文件限定源审决定：APPROVE。当前未关闭发现：P0=0、P1=0、P2=0、P3=0；历史三项 P2 均关闭。

绑定基线 `ac7ec43e6a42329417a99b5933bc171faa19caf6`；冻结清单 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/zmodem-independent-peer-20261117/candidate-inputs-r7.json`；765 项 aggregate `7ae00377c1eb95929710c7d8170d444ea293f8c27a3c8690cb83aa79bde3ede6`。前后 765/765 匹配、三源文件匹配、清单未变；17 份 r1 原件哈希全部保持。

- R1-P2-001：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/openssh_interop.py:101`、`:119`、`:123`、`:476`。SIGINT/TERM 在 hash read 中到达的旧触发已关闭：真实 Python main 的离线 mock 控制返回 130/interrupted，只有一次 read，无后续 executable lookup、SSH 或 scratch。原断言只适配两个直接调用的必传 callback，没有降低。
- R1-P2-002：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/zmodem_openssh.rs:753`、`:783`、`:802`、`:807`、`:819`。逐项核对 offer/review/save 的名字、size、方向、路径、传输及唯一 ID、SHA256、事件次序和磁盘内容，旧错误回执/错配 review 反例已无法通过；此结论为静态复核。
- R3-P2-003：同一 Rust 文件 `:73`、`:83`、`:332`、`:585`、`:591`。FirstDataHeader 仅单文件下载 Review 确认时 arm，前缀内容最多 96 字节，允许 leading flow/CRLF 与 1–2 pad，完整匹配独立 CRC 已知 ZDATA/offset0 向量后封存，不从 payload 搜索。相反 escaped payload、坏 CRC、伪前缀及预算控制通过。空文件只跳过模式断言，内容与 strict completed 保持。

实际测试命令（均 exit 0）：

```text
python3 -B /Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/zmodem-independent-source-review-20261117/r7/run_review.py current30
python3 -B /Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/zmodem-independent-source-review-20261117/r7/run_review.py independent11
```

r7 唯一测试 41：30 项当前 Python 专项 + 5 项原 Python 失败控制 + 6 项源派生观察器模型；41 pass，0 fail/error/skip。子测试和历史重跑不计额外测试。Rust 18 项库存仅静态核对，没有由本审执行。

原 8 项 ignored peer 测试体、strict completed helper 字节相同；Runner、ownership、deadline 相关定义 AST 相同；cleanup/receipt tail 字节相同。参数预算维持 raw JSON UTF8 16384、32 项、每项 2048、合计 8192，C0/DEL 拒绝；逐项 shell quote 与 flags → caller argv → names 次序保持。仅 zmodem 命令增加 `--show-output`。

preflight 回执只绑定当时可读 executable 字节、调用路径及规范化调用者 argv 前缀；不绑定 peer 上游源码、765 项工程源码、后续执行身份或完整逐 case 命令。新模式观察只证明被识别的首个 canonical ZDATA/offset0，不扩展到所有 header、upload 或 batch。

父级报告 r7 默认 8 pass/10 ignored、lrzsz 9/10（empty 缺 OO）、SexyZ 8/10（两个 empty 拒 ZRPOS0）以及 strict Clippy 3.771s；这些是真实运行边界，非本审独立复验。旧 r1/r3/r4/r5 失败原件继续保留，r6 旧观察器结果不签模式。完整 final-gate-r1 尚由父级负责。此 APPROVE 不覆盖 core、peer 源码/实际原件、真实互操作通过或完整门禁批准。

所有写入只在 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/zmodem-independent-source-review-20261117`；未改源码/文档/Git metadata，未运行 Cargo/Rust binary/真实 SSH，未访问 target，未新建 chat/worktree，未委派。审查完成，停止等待父级关闭。
