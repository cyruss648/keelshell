"""Run authorized Python review controls with all artifacts in this directory."""

import argparse
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest

OUTPUT = Path(__file__).resolve().parent
ROOT = OUTPUT.parents[1]
tempfile.tempdir = str(OUTPUT / "tmp")
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / "scripts"))


def inside_output(value):
    if isinstance(value, int):
        return
    path = Path(os.fsdecode(value)).absolute().resolve()
    if path != OUTPUT and OUTPUT not in path.parents:
        raise RuntimeError(f"Review write outside authorized directory: {path}")


def audit(event, args):
    if event == "subprocess.Popen":
        executable, command, _, _ = args
        if not (
            executable == "/bin/sh"
            and len(command) == 2
            and Path(command[1]).parent == OUTPUT / "shell-probes"
        ):
            raise RuntimeError("Review controls may only launch their local shell quoting probe")
    if event == "socket.connect":
        raise RuntimeError("Review controls must not connect to SSH or other services")
    if event == "open":
        path, mode, flags = args
        if (mode and any(letter in mode for letter in "wax+")) or flags & (
            os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND
        ):
            inside_output(path)
    elif event in ("os.mkdir", "os.chmod", "os.symlink", "shutil.rmtree"):
        inside_output(args[1] if event == "os.symlink" else args[0])
    elif event in ("os.rename", "os.link"):
        inside_output(args[0])
        inside_output(args[1])


class RecordedResult(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.started_ids = []
        self.passed_ids = []
        self.subtests = []

    def startTest(self, test):
        self.started_ids.append(test.id())
        super().startTest(test)

    def addSuccess(self, test):
        self.passed_ids.append(test.id())
        super().addSuccess(test)

    def addSubTest(self, test, subtest, err):
        self.subtests.append({"id": subtest.id(), "passed": err is None})
        super().addSubTest(test, subtest, err)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("suite", choices=("current-28", "independent"))
    arguments = parser.parse_args()
    if arguments.suite == "current-28":
        suite = unittest.defaultTestLoader.discover(
            str(ROOT / "scripts"), pattern="test_openssh_interop.py"
        )
        expected = 28
    else:
        spec = importlib.util.spec_from_file_location(
            "independent_review_controls", OUTPUT / "independent_controls.py"
        )
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        suite = unittest.defaultTestLoader.loadTestsFromModule(module)
        expected = None
    count = suite.countTestCases()
    if expected is not None and count != expected:
        raise RuntimeError(f"Expected {expected} current tests, discovered {count}")
    sys.addaudithook(audit)
    started = time.monotonic()
    result = unittest.TextTestRunner(verbosity=2, resultclass=RecordedResult).run(suite)
    receipt = {
        "suite": arguments.suite,
        "command": [sys.executable, "-B", str(Path(__file__).resolve()), arguments.suite],
        "tests_discovered": count,
        "tests_run": result.testsRun,
        "unique_test_count": len(set(result.started_ids)),
        "passed": len(result.passed_ids),
        "failures": [{"id": test.id(), "traceback": text} for test, text in result.failures],
        "errors": [{"id": test.id(), "traceback": text} for test, text in result.errors],
        "skipped": [{"id": test.id(), "reason": reason} for test, reason in result.skipped],
        "test_ids": result.started_ids,
        "subtests": result.subtests,
        "elapsed_seconds": time.monotonic() - started,
        "external_process_allowlist": ["/bin/sh <review-output>/shell-probes/<script>"],
        "network_connections_allowed": False,
        "temporary_directory": tempfile.tempdir,
        "success": result.wasSuccessful(),
    }
    (OUTPUT / (arguments.suite + ".result.json")).write_text(
        json.dumps(receipt, ensure_ascii=False, indent=2) + "\n"
    )
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    sys.exit(main())
