# f910e001 源码 CI 原件收集

仅绑定 `f910e0013832643f09b112b08443675a956d5551`。本次 GET 观察 `2026-11-17T06:37:40.034698+00:00`；
Quality `44026933453`、Windows API `44026933510`、OpenSSH `44026933475`
均为 attempt 1、completed/success。已逐项读回 run、jobs 列表、全部 6 个单 job、artifact 列表与单 artifact JSON；无分页遗漏。
本地文档 HEAD 为 `4c8654f219779f48afd485bec8ff1b284905fbf0`，未当作源码 CI 身份。

| Quality 平台 / job | 普通 Rust passed/failed/ignored | doctest passed/failed/ignored | Python 主 run/skipped |
| --- | --- | --- | --- |
| native (ubuntu-24.04) / `133849410428` | 3448/0/69 | 15/0/0 | 526/3 |
| native (macos-26) / `133849410649` | 3455/0/68 | 15/0/0 | 526/3 |
| native (windows-2025) / `133849410871` | 3442/0/66 | 15/0/0 | 526/53 |

各平台 96 普通 Rust 套件、6 doctest 套件的声明数／逐名结果／summary 相等。Python 主为 quiet discovery，只有 run/skip 总数，无逐名列表；非跳过通过数为 473／523／523（Windows／Ubuntu／macOS，由 OK 推算）。
packaging 各 57 run，Windows skip4、其余 skip0；Quality 内嵌 helper 在 Ubuntu/macOS 各 30 run、skip0，均单列。
Windows preflight 单列为 filesystem 70/0/0、archive 41/0/0、session 461/0/3；未加入普通 Rust 主数。
macOS/Ubuntu 的 OpenSSH artifact 各为 interoperability 18/0/0 与 forwarding 6/0/0，逐名和结果 JSON 相符。

Windows API job `133849410135`：Python lab 111 run/3 skipped，capture replay Rust 1/0/0、9 filtered。
同 run 的 isolated-SSH job `133849412218` skipped，direct artifact 为 `ssh=UNRUN`。
OpenSSH job `133849409893`：Python lab 96 run/1 skipped，artifact 中实际执行 native SSH Rust 1/0/0，单测试库存相符。

SSH 原 seal 为 HOLD：21 原对象中 20 非 master 自然终态，exit 分布 0×14、255×5、1×1；master 仍活、1 pending、22 owned handles。
最终 cleanup 为 PASS，active/pending/owned handles 均 0、closed=true，但 master 为 cleanup exit125、natural_terminal_before_cleanup=false；不改写为全部自然 exit0。
API 的 6 个和 SSH 的 9 个 direct children 均记录 reaped；SSH owned-sshd 的 observed_exit=null 保留。
两份 Windows artifact 均为 `native_gui=UNRUN`。全部 skipped steps、Rust ignored 原因和 Python 可用的逐名 skip 原文在 `inventories/` 与原始日志中。

| 原始 ZIP | 字节 | 成员 | SHA-256 |
| --- | ---: | ---: | --- |
| `downloads/run-44026933453-attempt-1-logs.zip` | 1038132 | 40 | `a131882d07eb3908c69ab249984f5afbcab14f972cbf6ac49ce38809c23c24c5` |
| `downloads/artifact-14304977393.zip` | 5507 | 14 | `01802f409db92a9c90e2fb9be6363ae113797c3062b7568fbded3c24293ce0eb` |
| `downloads/artifact-14304472242.zip` | 5595 | 14 | `140f7da44b1e3a65c76372c23d21e07f678a59cd5a11a6d12365c39b49beec82` |
| `downloads/run-44026933510-attempt-1-logs.zip` | 31337 | 12 | `a41272982e8f5dcf0dbe0ef7855eaa97d8f0593a3911099bc0ad552071ed9b05` |
| `downloads/artifact-14304130642.zip` | 46877 | 34 | `8e8c09efada2d2fda19e9a16265d2948a17ee001a28152c22e18cf4b194195ed` |
| `downloads/run-44026933475-attempt-1-logs.zip` | 32016 | 12 | `9b911d3c3a704de396813da0743970c798a610d6a3aa53c4c06c7c543b0d3adb` |
| `downloads/artifact-14303232465.zip` | 54082 | 46 | `853e64bfaa5984e9a531bc2f380dca9243aa229dda2d31001af15d91d451d4ab` |

共 7 ZIP、172 成员、1,213,546 ZIP 字节；CRC、每个成员长度／SHA-256 已核对。
4 个 artifact 的长度和 digest 均与列表及单项 API 原件相等；run 日志 ZIP 的 SHA-256 为本地下载摘要，API 未提供服务端 digest。
收集者离线核验 99 通过／0 失败；无库存差异、无失败 GET、无 token/private-key marker 命中。这不是独立 review。

实际执行命令（cwd 为本目录；精确 argv、UTC、自然 exit/reaped、输出长度与摘要见 `commands/*/receipt.json`、`preparation-commands.json`、`command-ledger.json`）：

```text
python3 run_stage.py preparation python3 prepare.py
python3 run_stage.py collect-r1 python3 -u collect.py --snapshot
python3 run_stage.py analyze-r1 python3 -B analyze.py
python3 run_stage.py report-r1 python3 -B report.py
python3 run_stage.py report-r2 python3 -B report.py
python3 -B seal.py
```

网络实际为 26 次 `gh api --method GET <endpoint>`，ZIP 加 `--allow-escape-sequences`，全部自然 exit0/reaped，无 timeout。
端点只含指定 runs、jobs、artifacts 的元数据与下载；每次 GET 的完整 argv、路径、原始字节数和摘要保存于同名 `.receipt.json`。
本地 prepare 只执行 Git read 命令和输入复制；`helper-provenance.json` 记录已阅读并核对为已提交原件的旧封存 helper 及本次修改，旧 cdf1 结论未代签本次源码。

原件索引：`snapshots/001/` 为 run/jobs/artifacts JSON，`jobs/` 为单 job JSON，`artifacts/` 为单 artifact JSON，`downloads/` 为完整原始 ZIP；
`archive-manifest.json` 为每个 ZIP 成员的长度/摘要，`summary.json`、`inventories/`、`verification.json` 为派生计数与核验；`source-checkout-lines.json` 保留五个已执行 job 的精确 checkout SHA 行。
`SHA256SUMS` 在所有 stage receipt 生成后封口，覆盖本目录除其自身外的全部文件；最终逐项核验回执为 `seal-verification.json`。

局限：仅对已记录的指定源码 CI 原件解析，未本地重跑测试或独立 --list；Rust 自定义 controller 的原信号独立保留。Ubuntu/macOS 的 cleanup 仅证明原件声明的累计 ancestry 与 kernel birth identity 观察边界。
原生 GUI、外部供应商客户端、IME／辅助技术、安装、签名／公证、发行和完整产品均未验收。没有启动产品/CUA、Cargo 或 target 操作，没有提交／推送／清理／rerun／cancel；所有新增文件只在本目录。父级另行安排独立 reviewer。

共享 checkout 状态附记：初始 tracked status 为空；封口前读回出现以下四项修改。本收集未写这些文件、未判断其作者；前后原始 status 与命令回执已保留，未清理。

```text
 M crates/keelshell-session/src/monitor.rs
 M crates/keelshell-session/src/monitor/capabilities.rs
 M crates/keelshell-session/src/monitor/capabilities/tests.rs
 M crates/keelshell-session/src/monitor/platform.rs
```
