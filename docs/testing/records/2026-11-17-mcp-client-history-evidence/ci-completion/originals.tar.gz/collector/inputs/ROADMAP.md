# 当前开发路线 — 2026-11-17

完整产品继续开发，FILE-05/M4、原生桌面和六目标发行仍开放。
先读[当前交接](HANDOFF.md)，按[能力台账](product/CAPABILITIES.md)和各批精确记录接续。
改写前原文逐字节保存在[本日路线历史](ROADMAP_HISTORY_2026-11-17.md)；
历史状态不覆盖当前授权或精确源码回执。

## 产品与工程约束

- 只管理远程 SSH，使用真实原生 GPUI Kit，覆盖 macOS、Windows、Linux；本地终端、RDP、串口不在范围。
- 保持 app/UI、core/领域存储、session/传输、AI 分层；阻塞文件、SSH/SFTP 和模型 I/O 离开 UI 线程。
- 保留 Frost「霜白」、Graphite「曜石」、Lavender「雾紫」及 System/Light/Dark；
  新主题只扩展 registry、Palette、组件形状与 chrome token，业务视图不按 theme ID 分支。
- AI 上下文发送与每项命令／文件动作分别显式审核，模型不能自主执行；host key 变化 fail closed。
- 凭据默认短暂驻留；显式持久化使用 OS 凭据库或认证加密 vault，普通配置与日志不保存凭据。
- 所有直接 registry 依赖要求仅用 `x.y`，Cargo.lock 保留 patch 解析；不 pin Rust 工具链、不设 `rust-version`，
  默认使用当前开发环境／CI 提供的受支持工具链，本机版本观察不转成产品 MSRV。
- 代码门禁、非作者复核、真实联调、原生桌面和发行安装分别验收；编译、模拟、headless 不代签 native。
- 共享 target 同时只允许一个构建任务；切换源码归属遵循[共享 target 合同](testing/SHARED_TARGET.md)。

## 当前批次与接续顺序

MCP接入与提案记录增量的实现与限定工程验证完成：纯Codex／Claude模板和原生显式复制、
保留Unknown的批量清理、独立准确提案核对已实现；核对不执行／重试或改写状态。
专项MCP37／renderer13通过；实际renderer经独立Python解析41TOML／40JSON和1拒绝通过。
777输入冻结前后相等；新非作者Cicero源码/功能限定批准、P0–P3全0，
独立预编译62项通过并关闭。最终完整门禁通过Rust3455/0/68 ignored、
15rustdoc及Python主526 run/3 skipped，96普通库存逐名和二进制摘要相等。
原编译／首提案布局／库存工装解析失败保留；
首轮原生锁屏保留；随后f910新正常包在隔离空目录取得11组原JPEG/AX，
三推荐主题各双语的MCP空授权面板与客户端选中样式可见，原进程exit0/reaped；
复制模板始终disabled，没有新原生复制/未知动作闭环。
完整供应商客户端／三平台原生仍开放。
从[本批记录](testing/records/2026-11-17-mcp-client-history.md)接续精确交付，
不重复未变工程的完整门禁。工程f910e001已普通推送、三方一致，
777新输入/769旧输入/574成员Git绑定通过；原图非作者Boole实际查看11张，
限定ship、P0–P3全0，独立347检查/13报告读回通过并关闭；
90成员交付原件已封存。本批Quality44026933453的macOS已success、
Windows/Ubuntu仍进行中，
两Windows工作流为API状态success，新三平台终态单独验。

本地转发的原SSH生命周期增量已整合，见[ADR0159](adr/0159-local-forward-transport-lifetime.md)及
[本批记录](testing/records/2026-11-17-tunnel-transport-lifetime.md)。
Closing／Closed准入、bind竞态、原连接断线后的listener／streams回收及新旧owner隔离
已补齐；库级16项、真实Darwin OpenSSH三方向6项和工装33项通过。
首轮独立P2的既有sibling流断言已增强；新非作者Curie对r2限定批准、P0–P3全0，
独立45Python／父级预编译16项通过，P2关闭且agent已关闭；
769输入冻结后的完整门禁r2通过：普通Rust3435/0/68 ignored、14rustdoc，
Python主526 run／3 skipped，95普通套件逐名库存／二进制摘要及输入前后相等。
首轮Clippy失败保留。工程`cdf1e171`已普通推送、三方SHA一致，
769输入／478归档成员精确Git绑定通过；5位自有agent关闭，
6目录／478文件按原件核对回收，target与正常旧包保持。
Windows API44020265273／SSH44020265248及Quality44020265369均已completed/success，
Windows／Ubuntu／macOS普通Rust3422／3428／3435通过、0失败，各14rustdoc；
Python主526 run、skip53／3／3，7原始ZIP／172成员和4个digest已取得核对，
见[精确CI](testing/records/2026-11-17-tunnel-transport-lifetime-evidence/ci-completion/README.md)。
API isolated-SSH skipped、native_gui=UNRUN与历史HOLD／清理exit125保留；
新非作者Heisenberg离线13,543项通过、限定批准且关闭，
checksum历史P3已由外层完整原件说明纠正，未关闭P0–P3全0；
不代签本批新MCP源码、原生或发行。
uuid锁更新1.29.3后，完整官方直接依赖新快照37包／113声明全部通过。
原生再次锁屏、GUI操作／截图0；三平台原生及完整隧道阶段继续开放。

独立Zmodem peer交叉联调进行中，见[ADR0158](adr/0158-independent-zmodem-peer-matrix.md)与
[本批记录](testing/records/2026-11-17-independent-zmodem-peers.md)。
已修复捕获报文暴露的七字段metadata拒绝，core106项通过；
未修改SexyZ真实PTY由3／10提升到8／10通过，两个空文件下载失败继续OPEN。
有界peer argv／来源摘要、三文件逐项审核和中途取消已整合，
新非作者Fermat源审已批准且关闭三P2，Peirce的core／原件复核限定批准，两位均已关闭。
最终r7下lrzsz9／10、SexyZ8／10，单文件空传／缺OO边界保持；
冻结后完整门禁已通过：Rust3419/0/62 ignored、14 rustdoc、Python主523 run/3 skipped；
94普通套件逐名库存、765输入前后核对通过，不关闭FILE-05／旧lrzsz边界。
工程`de9768c`已普通推送、三方SHA一致；623成员原件与765输入Git绑定通过，
六个自有临时目录已回收，五位agent已关闭。
Windows SSH44013808220／API44013808184为success，Quality44013808155现已三平台success：
Windows／macOS／Ubuntu普通Rust3406／3419／3412通过、0失败，各14rustdoc；
Python523 run、skip50／3／3，macOS／Linux真实OpenSSH各18通过。
原件已取得，非作者Feynman离线5,091＋16检查通过、限定批准、已关闭；
207成员[精确CI封存](testing/records/2026-11-17-independent-zmodem-peers-evidence/ci-completion/README.md)
绑定765旧工程输入；旧快照仍保留于
[交付快照](testing/records/2026-11-17-independent-zmodem-peers-evidence/delivery/README.md)。

Windows 真实 OpenSSH 监控联调本机工程已完成，基线 `bfbea7b`：
隔离服务器、原进程调试接纳与公开 Rust 路由用例已整合，
父级整合Python271 run／0失败／3跳过，两位新非作者限定批准、P0–P3全0并实际关闭。
765输入冻结后的完整门禁r1通过：Rust3407/0/60 ignored、14 rustdoc、
Python493 run／3 skipped，库存逐名相等。工程`41671be`已普通推送、三方SHA一致，
765输入／168原件精确Git绑定通过；OpenSSH43990824640已FAIL，
API43990824533已success，Quality43990824137三平台已success。
真实认证、三类采集和4个PowerShell自然exit0不补签原Job census／清理失败；
当前仅4个Python文件的有界settle／argv0兼容修复已获新非作者限定批准，
独立49项通过、P0–P3全0并已关闭；最终完整门禁r2已
`0/reaped/731.529731s`，Rust3407/0/60 ignored、14 rustdoc、
Python501 run／3 skipped，765输入前后无漂移。修复工程`660e90d6`已普通推送，
三方SHA一致，765输入／50原件精确Git绑定通过；真实SSH43997403565及同源码
复跑43998970900均success，API43997403484也success。
新Quality43997403533三平台已success，Windows／macOS／Ubuntu普通Rust
3394／3407／3400通过、0失败，各14 rustdoc；Python主501 run，
skipped38／3／3，macOS／Linux真实OpenSSH interop各18项通过。
新非作者Darwin限定批准两次SSH与API原件，4018离线检查通过、P0–P3全0，
已实际关闭；510成员精确CI封存与765工程输入绑定通过，见
[CI终态](testing/records/2026-11-17-windows-openssh-monitor-evidence/ci-completion/README.md)；
以[ADR0157](adr/0157-windows-openssh-monitor-acceptance.md)及
[本批记录](testing/records/2026-11-17-windows-openssh-monitor.md)接续。

1. Windows 远端只读监控：固定 PowerShell 采集、独立身份、资源／进程／端口、按项缓存、
   三主题双语与未知值语义已整合。真实 Darwin SSH 15 项、Linux 恢复 2 项及专项通过；
   独立审查发现的 admission 后撤权与对照漏报均已修复。
   最终 758 输入 r3 的完整门禁已通过，普通 Rust3407/0/59 ignored、app1398/0/2；以[本批记录](testing/records/2026-11-17-windows-read-only-monitor.md)为准，
   两位独立非作者均限定批准，精确库存与冻结通过。工程 `5d2df2f` 已普通推送、三方一致，
   540成员／758输入 Git 绑定及精确来源正常包通过；API workflow43972365007成功，
   Server2025 AMD64实际cmd／PowerShell终态、独立对照与capture replay通过，真实SSH／原生仍另验。
   Quality43972364934三平台已成功，Windows／macOS／Ubuntu普通Rust3394／3407／3400通过、0失败；
   91成员终态与758精确Git输入绑定通过。Windows lab111 run＝108通过＋3跳过，
   新非作者API原件102项复算限定批准、已关闭，见[精确CI](testing/records/2026-11-17-windows-read-only-monitor-evidence/ci-completion/README.md)。
2. 监控栈修复 `bbd4eaccfa8bba2feb487ff43e0423567428bc82` 的 Quality `43955379234`
   已三平台成功，37 成员封存和 731 输入 Git 绑定通过；原 UDP 栈溢出失败保持。
   [栈修复记录](testing/records/2026-11-17-monitor-render-stack.md)与
   [精确 CI](testing/records/2026-11-17-monitor-render-stack-evidence/ci-completion/README.md)
   不代签当前 Windows 差分。
3. 桌面已可用。正常5d2df2f包单窗／空连接库的三推荐主题英文工具栏已有10组AX／JPEG，
   新非作者Hume限定ship、P0–P3全0并已关闭；原进程正常exit0。
   紧凑窗口尺寸未证实改变，旧P2连接上下文余集、完整主题／双语／键盘矩阵仍开放，
   见[限定原生证据](testing/records/2026-11-17-native-toolbar-evidence/README.md)。
4. 已完成批次及时普通提交／推送并读回 local／tracking／remote SHA；
   新功能按[阶段集中验证](testing/STRATEGY.md#阶段集中验证)集成、专项、新非作者复核和最终完整门禁。
   保留 UNKNOWN／quarantine 和原失败，不重放不确定动作；回收仅限本任务自有且已封存资源。

## FILE-05 / M4：高级传输仍开放

- 已实现[客户端 ZIP/tar.gz 归档](product/ARCHIVE_TRANSFERS.md)、有界 PAX、
  [两次审核的服务端打包](product/SERVER_ARCHIVES.md)、[PATH／版本与流式自测](product/ARCHIVE_TOOL_INSPECTION.md)，
  以及现有 SSH PTY 上的[审核式 Zmodem](product/ZMODEM.md)；源码实现与限定门禁不等于整阶段验收。
- 独立 peer 的直接 PTY strict `OO` 兼容保持 `HOLD/PARTIAL`：严格 `Finished` 必须实际收到 `OO`。
  缺握手警告、逐文件已验证保存、peer 退出 0、pipe relay 对照分别记录，均不能补签严格完成；
  继续独立 peer、真实 SSH PTY、取消／尾部恢复及同一 shell 新输入的可重复矩阵，见[收尾记录](testing/records/2026-11-15-bounded-zmodem-farewell.md)。
  [11月17日交叉矩阵](testing/records/2026-11-17-independent-zmodem-peers.md)已取得SexyZ的
  CRC16／CRC32实际格式和严格OO、同shell继续输入、首文件保存后取消；空文件发送两失败保持。
- Windows 来源／私有 staging／安全发布后端与 UI 已接入，前批后端预检和完整 app 通过；
  新 ZIP codec 41 项及 session 两项祖先替换断言已通过；原 958 完整 gate 的 Python 工装失败保持。
  发布标记修订已复核、封存、推送，当前 ee3 三平台完整 gate 已通过，原生桌面仍待验。
  以[根目录发布记录](testing/records/2026-11-16-windows-archive-root-publication.md)接续，不回退成“Windows 从未执行”。
- 既有 Linux arm64 本地后端／codec 专项只覆盖原冻结；不代签 Linux x64、GUI、独立 peer 或当前输入，
  见[本地后端记录](testing/records/2026-11-15-windows-local-backend.md)。更广远端 Linux 权限与旧 Python runtime 仍需覆盖。
- 用户自有 SSH 中继和审核式路径比较已有实现，真实 IP 延迟／丢包实验仅证明受控场景；
  用户中继长流程、跨平台和可重复收益仍待验，不把一次吞吐差异写成普遍加速，见[中继指南](product/SSH_RELAY.md)。

## 其余未完成产品范围

下表列当前缺口；已实现能力、历史复核和各自限定证据继续从对应指南／记录查询。

| 优先级 | 范围 | 当前边界与下一步 |
| --- | --- | --- |
| P1 | 工作区 | 分屏、逐叶标签、显式保存／恢复、独立窗口与窗口切换器已有实现；继续多 OS 窗口、外框、完整关闭／重连审核和 worker 回收原生矩阵，见[窗口指南](product/WORKSPACE_WINDOW_SWITCHER.md)。 |
| P1 | 外部 AI／MCP | API／受控 CLI Ask、逐步审核 Agent、对外 MCP 已实现；继续供应商账户、真实外部客户端和文件提案闭环、撤权／重连／取消；CLI 登录身份复用启用前仍需请求前隔离证明，见[能力计划](product/DESIGN_AND_AGENT_PLAN.md)。 |
| P2 | 日常文件与编辑器 | UTF-16 LE/BE、五种显式旧编码、审核保存／备份／合并／读回和键盘已有实现；继续更多编码边界、原生文件管理器拖放、完整键盘／辅助技术和其他平台，保持原字节与备份合同，见[文本格式](product/REMOTE_TEXT_FORMAT.md)及[文件键盘](product/FILE_BROWSER_KEYBOARD.md)。 |
| P2 | 监控与网络 | 按项能力、缓存、Linux 恢复、远端 macOS 只读资源及账户可见 TCP/UDP端口与缓存分页已有实现；UDP专项、真实SSH、最终门禁及两位独立复核通过，原生另验。Windows只读采集及界面已整合，本批精确真实OpenSSH两次成功，原件非作者复核批准、新Quality三平台成功并封存；更多工具缺失后恢复、真实错误／取消和ICMP矩阵仍开放，Darwin主动探测／终止及不支持指标保持未知，见[Windows SSH记录](testing/records/2026-11-17-windows-openssh-monitor.md)、[UDP记录](testing/records/2026-11-17-darwin-udp-sockets.md)、[监听记录](testing/records/2026-11-17-darwin-tcp-listeners.md)与[资源记录](testing/records/2026-11-16-host-monitor.md)。 |
| P2 | 持久化隧道 | 命名规则、三方向转发、流量、审核／停止及运行快照显式恢复已有实现；继续完整重连／管理、owner 失效、真实远端和跨平台验收，见[隧道指南](product/NAMED_TUNNEL_RULE_MANAGEMENT.md)。 |
| P2 | 配置恢复／同步 | 审核恢复、回退与认证加密目录同步已有实现；跨机器挂载、断电耐久性、最终一致同步器适用性及约束仍待验，不把原子发布专项扩成这些承诺，见[同步指南](product/PROFILE_SYNC.md)和[原子发布记录](testing/records/2026-11-14-profile-sync-atomic-publish.md)。 |
| P3 | AI 知识复用 | 本地分类、显式 Ask、审核式批量管理与命令片段草稿已有实现；跨设备同步和更多复用待设计，不恢复旧 SSH 权限、不自动执行 runbook，见[知识指南](product/AI_KNOWLEDGE_LIBRARY.md)。 |

## 跨平台原生与发行矩阵

- macOS、Windows、Linux 的 x64／arm64 六目标按[发行合同](RELEASING.md)逐项核验，
  CI runner、编译或包结构成功不等于实际桌面；Linux Wayland／X11 与运行库约束单独记录。
- 三主题、明暗／系统、中文／英文、宽窗／最小及紧凑窗口、焦点／Tab／Shift+Tab、
  IME／CJK／RTL、VoiceOver／NVDA 等辅助技术和像素对比度均需原生证据；完整产品验收继续开放。
- 真实 SSH/SFTP、Podman 长流程、取消／重连／未知结果及多窗口不能由 loopback 或短验统包。
- 六目标包、主程序／MCP 架构和摘要、精确源码来源、签名／公证、权限、隔离安装、升级／回滚及重启均待完整发行验收；
  [自动更新](product/AUTOMATIC_UPDATES.md)已有实现，真实 release 载荷下载和安装目录替换仍需单独验收。
  标签发布授权不包含覆盖安装现有应用或上传遥测。

## 精确证据入口

计数只在绑定的源码／输入／平台范围内有效；历史记录中的原失败、HOLD、UNKNOWN 和签署边界保持。

| 范围 | 记录与边界 |
| --- | --- |
| 当前 Windows 发布／Quality | [根目录发布终态](testing/records/2026-11-16-windows-archive-root-publication.md#精确-ci-终态)、[ZIP 终态](testing/records/2026-11-16-portable-zip-metadata.md#精确-ci-终态补充)、[Zmodem 测试契约](testing/records/2026-11-16-windows-zmodem-test-contract.md)、[工装发布屏障](testing/records/2026-11-16-windows-fixture-publication.md)；原四项 app、新 codec 与 session 修订按各自精确源码通过，当前 ee3 三平台完整 gate 及 macOS／Ubuntu OpenSSH 已成功，桌面／发行仍开放。 |
| Kit 0.10 与三主题 | [指定源码 CI／限定原生](testing/records/2026-11-16-kit010-native-ci.md)；旧包观察不代签后续源码或英文工具栏 P2。 |
| 文件列表与命令框焦点 | [列表键盘](testing/records/2026-11-16-file-browser-keyboard.md)、[双向焦点补验](testing/records/2026-11-16-archive-diagnostics-and-native-focus.md)；双侧各一文件的 Frost 限定路径不等于完整 IME／辅助技术。 |
| 编辑器原生 | [键盘及 UTF-16／GBK](testing/records/2026-11-16-editor-keyboard-native.md)；Frost 仅限定片段，Graphite HOLD、Lavender NOT_RUN，其他平台仍开放。 |
| 路径与真实 IP 实验 | [SSH 路径比较](testing/records/2026-11-16-ssh-path-comparison.md)、[原生／netem](testing/records/2026-11-16-native-network.md)；受控样本不证明生产收益。 |
| 隧道恢复／审核式片段 | [owner 与恢复卡片](testing/records/2026-11-14-named-tunnel-owner-and-recovery-card.md)、[AI 片段保存](testing/records/2026-11-14-ai-reviewed-snippet-save.md)；源码批准不代签完整原生或最终源码全量门禁。 |

新需求记入 `docs/product/`，设计决定记入 `docs/adr/`，实际结果与原件记入 `docs/testing/`。
本页保持精简当前路线，历史批次不再整段追加；交接入口与精确 CI 记录同步维护。
