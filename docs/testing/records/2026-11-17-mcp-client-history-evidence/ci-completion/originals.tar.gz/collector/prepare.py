"""Copy reviewed, committed CI helpers and record this collection's exact scope."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import subprocess
import tarfile
import time

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent
SOURCE = "f910e0013832643f09b112b08443675a956d5551"
ARCHIVE = "docs/testing/records/2026-11-17-tunnel-transport-lifetime-evidence/ci-completion/originals.tar.gz"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def dump(name, value):
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


commands = []


def command(argv, output):
    start = datetime.now(timezone.utc).isoformat()
    tick = time.monotonic()
    proc = subprocess.run(
        argv, cwd=REPO, env={**os.environ, "GIT_OPTIONAL_LOCKS": "0"},
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30, check=False,
    )
    destination = ROOT / output
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(proc.stdout)
    (ROOT / (output + ".stderr")).write_bytes(proc.stderr)
    commands.append({
        "argv": argv, "cwd": str(REPO), "started_at_utc": start,
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        "elapsed_seconds": round(time.monotonic() - tick, 6),
        "exit_code": proc.returncode, "natural_exit": proc.returncode >= 0,
        "reaped": True, "timed_out": False,
        "stdout_path": output, "stdout_bytes": len(proc.stdout),
        "stdout_sha256": sha(proc.stdout), "stderr_bytes": len(proc.stderr),
        "stderr_sha256": sha(proc.stderr),
    })
    if proc.returncode:
        dump("preparation-commands.json", commands)
        raise RuntimeError("Read-only preparation command failed; see receipt")
    return proc.stdout


head = command(["git", "rev-parse", "HEAD"], "inputs/checkout-head.txt").decode().strip()
command(["git", "status", "--porcelain=v1", "--untracked-files=no"], "inputs/tracked-status-before.txt")
command(["git", "show", "-s", "--format=fuller", SOURCE], "inputs/source-commit.txt")
tracked_archive = command(["git", "show", "HEAD:" + ARCHIVE], "inputs/helper-archive-committed.tar.gz")
assert tracked_archive == (REPO / ARCHIVE).read_bytes(), "Helper archive differs from Git"
workflow_names = command(
    ["git", "ls-tree", "--name-only", SOURCE + ":.github/workflows"],
    "inputs/source-workflow-names.txt",
).decode().splitlines()
for name in workflow_names:
    if name.endswith((".yml", ".yaml")):
        command(
            ["git", "show", SOURCE + ":.github/workflows/" + name],
            "inputs/workflows/" + name,
        )
command(["git", "show", SOURCE + ":scripts/check.py"], "inputs/source-check.py.txt")
inputs = []
for source, destination in [
    (REPO / "AGENTS.md", "inputs/AGENTS.md"),
    (Path("/Users/hdh/.codex/RTK.md"), "inputs/RTK.md"),
    (REPO / "docs/HANDOFF.md", "inputs/HANDOFF.md"),
    (REPO / "docs/ROADMAP.md", "inputs/ROADMAP.md"),
    (REPO / "work/mcp-client-finalize-20261117/continuation-source-ci-r1/command.log",
     "inputs/previous-quality-jobs-command.log"),
]:
    data = source.read_bytes()
    (ROOT / destination).write_bytes(data)
    inputs.append({"path": str(source), "copy": destination, "bytes": len(data), "sha256": sha(data)})
helpers = []
with tarfile.open(ROOT / "inputs/helper-archive-committed.tar.gz") as archive:
    for name in ["collect.py", "analyze.py"]:
        data = archive.extractfile(name).read()
        original = ROOT / "inputs" / ("previous-" + name + ".txt")
        original.write_bytes(data)
        (ROOT / name).write_bytes(data)
        helpers.append({"member": name, "bytes": len(data), "sha256": sha(data)})
(ROOT / "snapshots").mkdir()
dump("context.json", {
    "started_at_utc": datetime.now(timezone.utc).isoformat(), "started_epoch": time.time(),
    "repository": "cyruss648/keelshell", "checkout_head_supplied": head,
    "engineering_source_sha": SOURCE,
    "run_ids": [44026933453, 44026933510, 44026933475],
    "quality_run_id": 44026933453,
    "quality_expected_jobs": [133849410428, 133849410649, 133849410871],
    "scope": "Collector only; GET network; writes confined to this directory; no product execution, review, Cargo/target, git mutation, CUA or cleanup",
})
dump("helper-provenance.json", {
    "archive": ARCHIVE, "read_at_checkout_head": head,
    "archive_matches_committed_git_object": True, "archive_sha256": sha(tracked_archive),
    "members": helpers,
    "adaptation": "Current source/run/job context; fetch each exact job; explicit natural-exit and stderr length/digest receipts. Final report is new and does not reuse old conclusions.",
})
dump("input-copies.json", inputs)
dump("preparation-commands.json", commands)
print(json.dumps({"prepared": True, "head": head, "read_commands": len(commands), "helpers": helpers}))
