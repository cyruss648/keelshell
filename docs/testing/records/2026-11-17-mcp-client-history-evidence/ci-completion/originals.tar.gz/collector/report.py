"""Verify the collected payloads and write a short collector handoff."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent


def read(path):
    return json.loads((ROOT / path).read_text())


def sha(data):
    return hashlib.sha256(data).hexdigest()


def dump(path, value):
    (ROOT / path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


summary = read("summary.json")
context = read("context.json")
source = context["engineering_source_sha"]
snap = ROOT / read("latest.json")["snapshot"]
checks = []


def check(name, passed, detail=None):
    checks.append({"name": name, "passed": bool(passed), "detail": detail})


check("exact requested run inventory", [r["id"] for r in summary["runs"]] == context["run_ids"])
check("all requested runs completed/success", all(
    r["status"] == "completed" and r["conclusion"] == "success" for r in summary["runs"]))
check("all requested source SHAs", all(r["source_sha"] == source for r in summary["runs"]))
check("no parsed inventory discrepancies", not summary["inventory_mismatches"])
check("no failed jobs", not summary["failed_jobs_observed"])
check("no token/private-key markers", not summary["secret_scan"]["hits"])
check("seven raw archives", summary["archive_zip_count"] == 7)
source_lines = []
for run in summary["runs"]:
    run_meta = read(snap.relative_to(ROOT) / f"{run['id']}-run.json")
    check(f"run {run['id']} exact ID/attempt", run_meta["id"] == run["id"] and
          run_meta["run_attempt"] == run["run_attempt"] == 1)
    jobs = read(snap.relative_to(ROOT) / f"{run['id']}-jobs.json")
    check(f"run {run['id']} complete jobs pagination", jobs["total_count"] == len(jobs["jobs"]))
    artifacts = read(snap.relative_to(ROOT) / f"{run['id']}-artifacts.json")
    check(f"run {run['id']} complete artifact pagination",
          artifacts["total_count"] == len(artifacts["artifacts"]))
    if run["id"] == context["quality_run_id"]:
        check("exact Quality job IDs", sorted(j["id"] for j in jobs["jobs"]) ==
              sorted(context["quality_expected_jobs"]))
    for job in jobs["jobs"]:
        detail = read(f"jobs/{job['id']}.json")
        fields = ("id", "run_id", "run_attempt", "head_sha", "name", "status", "conclusion", "steps")
        check(f"job {job['id']} detail matches list", all(detail[k] == job[k] for k in fields))
        check(f"job {job['id']} source/run/attempt",
              detail["head_sha"] == source and detail["run_id"] == run["id"] and detail["run_attempt"] == 1)
        inv = read(f"inventories/job-{job['id']}.json")
        expected_steps = {s["number"] for s in job["steps"] if s["conclusion"] != "skipped"}
        check(f"job {job['id']} all executed step logs present",
              expected_steps == {s["number"] for s in inv["steps"]})
        checkout = next((s for s in inv["steps"] if s["number"] == 2), None)
        if job["conclusion"] == "skipped":
            check(f"job {job['id']} skipped remains unexecuted", not inv["steps"])
        elif checkout:
            with zipfile.ZipFile(ROOT / checkout["archive"]) as archive:
                lines = archive.read(checkout["member"]).decode("utf-8-sig").splitlines()
            found = [{"line": i + 1, "text": line} for i, line in enumerate(lines) if source in line]
            check(f"job {job['id']} exact checkout SHA recorded", bool(found))
            source_lines.append({"job_id": job["id"], "archive": checkout["archive"],
                                 "member": checkout["member"], "lines": found})
    for artifact in run["artifacts"]:
        aid = artifact["artifact_id"]
        check(f"artifact {aid} exact metadata binding", artifact["api_metadata_binding_matches"])
        if artifact.get("children_count"):
            check(f"artifact {aid} direct children reaped", artifact["all_children_reaped"])
        if "recorded_head_matches" in artifact:
            check(f"artifact {aid} recorded source HEAD", artifact["recorded_head_matches"])
            check(f"artifact {aid} native SSH inventory",
                  artifact["native_ssh_inventory_matches_execution"])
        for wire in artifact["wire_checks"]:
            check(f"artifact {aid} {wire['operation']} wire bytes/argv/digests",
                  all(wire[k] for k in ("assembly_matches_wire", "receipt_argv_contains_exact_wire",
                                       "receipt_production_bytes_match", "serialized_command_digest_matches")))
        for interop in artifact["openssh_interop"]:
            counts = interop["stdout_rust"]
            check(f"artifact {aid} {interop['result_member']} count/names",
                  interop["outcome"] == "passed" and interop["passed_tests"] == counts["passed"]
                  and counts["failed"] == 0 and counts["all_declarations_match"]
                  and counts["all_named_inventories_match"])
        if "process_cleanup" in artifact:
            seal, cleanup = artifact["original_process_seal"], artifact["process_cleanup"]
            check("SSH original HOLD retained", seal["state"] == "HOLD" and
                  seal["job_active_processes"] == seal["pending_process_objects"] == 1 and
                  seal["nonmaster_count"] == seal["nonmaster_naturally_terminal"] == 20)
            check("SSH cleanup complete", cleanup["state"] == "PASS" and cleanup["terminal_proven"]
                  and cleanup["job_active_processes"] == cleanup["pending_process_objects"] ==
                  cleanup["owned_handles_remaining"] == 0 and cleanup["closed"])
            check("SSH master cleanup nonzero retained", cleanup["masters"] == [{
                "natural_terminal_before_cleanup": False, "exit_code": 125, "original_signaled": True}])
            check("SSH nonmaster exit distribution retained",
                  cleanup["nonmaster_exit_codes"] == {"255": 5, "0": 14, "1": 1})
            check("SSH private temporary data removed", artifact["ssh_cleanup"]["temporary_directory_removed"])

for entry in summary["archives"]:
    path = ROOT / entry["path"]
    data = path.read_bytes()
    check(f"{path.name} download bytes/digest", len(data) == entry["bytes"] and sha(data) == entry["sha256"])
    with zipfile.ZipFile(path) as archive:
        check(f"{path.name} complete CRC/member inventory",
              archive.testzip() is None and len(archive.infolist()) == entry["zip_member_count"])
        manifest = next(m for m in read("archive-manifest.json") if m["path"] == entry["path"])
        check(f"{path.name} every member bytes/digest",
              len(manifest["members"]) == len(archive.infolist()) and all(
                  len(archive.read(m["path"])) == m["bytes"] and sha(archive.read(m["path"])) == m["sha256"]
                  for m in manifest["members"]))
    if entry["kind"] == "artifact_archive":
        check(f"{path.name} API digest and byte length",
              entry["digest_matches_api"] and entry["size_matches_api"])

requests = []
for path in sorted(ROOT.rglob("*.receipt.json")):
    value = json.loads(path.read_text())
    if "endpoint" in value:
        requests.append({"receipt": str(path.relative_to(ROOT)), **value})
check("all network commands GET", bool(requests) and all(r["method"] == "GET" for r in requests))
check("all GETs natural exit0/reaped", all(
    r.get("exit_code") == 0 and r.get("natural_exit") and r.get("reaped")
    and not r.get("timed_out") and not r.get("forced_termination") and not r.get("error")
    for r in requests))
check("every GET byte receipt matches original", all(
    len((ROOT / r["path"]).read_bytes()) == r["bytes"] and
    sha((ROOT / r["path"]).read_bytes()) == r["sha256"] for r in requests))
quality = summary["runs"][0]
for job in quality["jobs"]:
    check(f"job {job['id']} Rust/doctest names and totals",
          job["ordinary_rust"]["suites"] == 96 and
          all(job[k]["all_named_inventories_match"] and job[k]["all_declarations_match"]
              for k in ("ordinary_rust", "rustdoc")))
    check(f"job {job['id']} main Python success",
          job["python_main"]["outcome"].startswith("OK") and job["python_main"]["run"] == 526)
windows = [a for r in summary["runs"][1:] for a in r["artifacts"]]
check("both Windows artifacts retain native_gui UNRUN",
      len(windows) == 2 and all(a["receipt"]["native_gui"] == "UNRUN" for a in windows))
check("direct API SSH remains UNRUN", windows[0]["receipt"]["ssh"] == "UNRUN")

dump("source-checkout-lines.json", source_lines)
local = read("preparation-commands.json")
for path in sorted((ROOT / "commands").glob("*/receipt.json")):
    local.append({"receipt": str(path.relative_to(ROOT)), **json.loads(path.read_text())})
dump("command-ledger.json", {"local": local, "GET": requests,
                            "report_command_receipt": "commands/report-r2/receipt.json"})
verification = {
    "generated_at_utc": datetime.now(timezone.utc).isoformat(),
    "source_sha": source, "scope": "Collector's offline checks; no independent review or product tests",
    "checks_passed": sum(c["passed"] for c in checks),
    "checks_failed": sum(not c["passed"] for c in checks),
    "GET_requests": len(requests), "checks": checks,
}
dump("verification.json", verification)

lines = [
    "# f910e001 源码 CI 原件收集",
    "",
    f"仅绑定 `{source}`。本次 GET 观察 `{summary['observed_at_utc']}`；",
    "Quality `44026933453`、Windows API `44026933510`、OpenSSH `44026933475`",
    "均为 attempt 1、completed/success。已逐项读回 run、jobs 列表、全部 6 个单 job、artifact 列表与单 artifact JSON；无分页遗漏。",
    f"本地文档 HEAD 为 `{context['checkout_head_supplied']}`，未当作源码 CI 身份。",
    "",
    "| Quality 平台 / job | 普通 Rust passed/failed/ignored | doctest passed/failed/ignored | Python 主 run/skipped |",
    "| --- | --- | --- | --- |",
]
for job in quality["jobs"]:
    rust, doc, py = job["ordinary_rust"], job["rustdoc"], job["python_main"]
    lines.append(f"| {job['name']} / `{job['id']}` | {rust['passed']}/{rust['failed']}/{rust['ignored']} | "
                 f"{doc['passed']}/{doc['failed']}/{doc['ignored']} | {py['run']}/{py['skipped']} |")
lines += [
    "",
    "各平台 96 普通 Rust 套件、6 doctest 套件的声明数／逐名结果／summary 相等。Python 主为 quiet discovery，只有 run/skip 总数，无逐名列表；非跳过通过数为 473／523／523（Windows／Ubuntu／macOS，由 OK 推算）。",
    "packaging 各 57 run，Windows skip4、其余 skip0；Quality 内嵌 helper 在 Ubuntu/macOS 各 30 run、skip0，均单列。",
    "Windows preflight 单列为 filesystem 70/0/0、archive 41/0/0、session 461/0/3；未加入普通 Rust 主数。",
    "macOS/Ubuntu 的 OpenSSH artifact 各为 interoperability 18/0/0 与 forwarding 6/0/0，逐名和结果 JSON 相符。",
    "",
    "Windows API job `133849410135`：Python lab 111 run/3 skipped，capture replay Rust 1/0/0、9 filtered。",
    "同 run 的 isolated-SSH job `133849412218` skipped，direct artifact 为 `ssh=UNRUN`。",
    "OpenSSH job `133849409893`：Python lab 96 run/1 skipped，artifact 中实际执行 native SSH Rust 1/0/0，单测试库存相符。",
    "",
    "SSH 原 seal 为 HOLD：21 原对象中 20 非 master 自然终态，exit 分布 0×14、255×5、1×1；master 仍活、1 pending、22 owned handles。",
    "最终 cleanup 为 PASS，active/pending/owned handles 均 0、closed=true，但 master 为 cleanup exit125、natural_terminal_before_cleanup=false；不改写为全部自然 exit0。",
    "API 的 6 个和 SSH 的 9 个 direct children 均记录 reaped；SSH owned-sshd 的 observed_exit=null 保留。",
    "两份 Windows artifact 均为 `native_gui=UNRUN`。全部 skipped steps、Rust ignored 原因和 Python 可用的逐名 skip 原文在 `inventories/` 与原始日志中。",
    "",
    "| 原始 ZIP | 字节 | 成员 | SHA-256 |",
    "| --- | ---: | ---: | --- |",
]
for entry in summary["archives"]:
    lines.append(f"| `{entry['path']}` | {entry['bytes']} | {entry['zip_member_count']} | `{entry['sha256']}` |")
lines += [
    "",
    f"共 7 ZIP、172 成员、{sum(a['bytes'] for a in summary['archives']):,} ZIP 字节；CRC、每个成员长度／SHA-256 已核对。",
    "4 个 artifact 的长度和 digest 均与列表及单项 API 原件相等；run 日志 ZIP 的 SHA-256 为本地下载摘要，API 未提供服务端 digest。",
    f"收集者离线核验 {verification['checks_passed']} 通过／{verification['checks_failed']} 失败；无库存差异、无失败 GET、无 token/private-key marker 命中。这不是独立 review。",
    "",
    "实际执行命令（cwd 为本目录；精确 argv、UTC、自然 exit/reaped、输出长度与摘要见 `commands/*/receipt.json`、`preparation-commands.json`、`command-ledger.json`）：",
    "",
    "```text",
    "python3 run_stage.py preparation python3 prepare.py",
    "python3 run_stage.py collect-r1 python3 -u collect.py --snapshot",
    "python3 run_stage.py analyze-r1 python3 -B analyze.py",
    "python3 run_stage.py report-r1 python3 -B report.py",
    "python3 run_stage.py report-r2 python3 -B report.py",
    "python3 -B seal.py",
    "```",
    "",
    f"网络实际为 {len(requests)} 次 `gh api --method GET <endpoint>`，ZIP 加 `--allow-escape-sequences`，全部自然 exit0/reaped，无 timeout。",
    "端点只含指定 runs、jobs、artifacts 的元数据与下载；每次 GET 的完整 argv、路径、原始字节数和摘要保存于同名 `.receipt.json`。",
    "本地 prepare 只执行 Git read 命令和输入复制；`helper-provenance.json` 记录已阅读并核对为已提交原件的旧封存 helper 及本次修改，旧 cdf1 结论未代签本次源码。",
    "",
    "原件索引：`snapshots/001/` 为 run/jobs/artifacts JSON，`jobs/` 为单 job JSON，`artifacts/` 为单 artifact JSON，`downloads/` 为完整原始 ZIP；",
    "`archive-manifest.json` 为每个 ZIP 成员的长度/摘要，`summary.json`、`inventories/`、`verification.json` 为派生计数与核验；`source-checkout-lines.json` 保留五个已执行 job 的精确 checkout SHA 行。",
    "`SHA256SUMS` 在所有 stage receipt 生成后封口，覆盖本目录除其自身外的全部文件；最终逐项核验回执为 `seal-verification.json`。",
    "",
    "局限：仅对已记录的指定源码 CI 原件解析，未本地重跑测试或独立 --list；Rust 自定义 controller 的原信号独立保留。Ubuntu/macOS 的 cleanup 仅证明原件声明的累计 ancestry 与 kernel birth identity 观察边界。",
    "原生 GUI、外部供应商客户端、IME／辅助技术、安装、签名／公证、发行和完整产品均未验收。没有启动产品/CUA、Cargo 或 target 操作，没有提交／推送／清理／rerun／cancel；所有新增文件只在本目录。父级另行安排独立 reviewer。",
    "",
]
if (ROOT / "scope-readback.json").exists():
    scope = read("scope-readback.json")
    if not scope["tracked_status_equal_before"]:
        lines += [
            "共享 checkout 状态附记：初始 tracked status 为空；封口前读回出现以下四项修改。本收集未写这些文件、未判断其作者；前后原始 status 与命令回执已保留，未清理。",
            "",
            "```text",
            (ROOT / "inputs/tracked-status-after.txt").read_text().rstrip(),
            "```",
            "",
        ]
(ROOT / "REPORT.md").write_text("\n".join(lines))
print(json.dumps({k: verification[k] for k in ("source_sha", "checks_passed", "checks_failed", "GET_requests")}))
raise SystemExit(1 if verification["checks_failed"] else 0)
