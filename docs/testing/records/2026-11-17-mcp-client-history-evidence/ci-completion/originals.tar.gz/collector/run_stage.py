"""Record local collector commands without invoking product code."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
name, *argv = sys.argv[1:]
directory = ROOT / "commands" / name
directory.mkdir(parents=True, exist_ok=False)
start = datetime.now(timezone.utc).isoformat()
tick = time.monotonic()
with (directory / "stdout.log").open("wb") as stdout, (directory / "stderr.log").open("wb") as stderr:
    proc = subprocess.Popen(argv, cwd=ROOT, stdout=stdout, stderr=stderr)
    code = proc.wait()
receipt = {
    "argv": argv, "cwd": str(ROOT), "pid": proc.pid,
    "started_at_utc": start, "completed_at_utc": datetime.now(timezone.utc).isoformat(),
    "elapsed_seconds": round(time.monotonic() - tick, 6),
    "exit_code": code, "natural_exit": code >= 0, "reaped": True,
    "timed_out": False, "forced_termination": False,
}
for stream in ["stdout", "stderr"]:
    data = (directory / (stream + ".log")).read_bytes()
    receipt[stream + "_bytes"] = len(data)
    receipt[stream + "_sha256"] = hashlib.sha256(data).hexdigest()
(directory / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"stage": name, **receipt}), flush=True)
sys.exit(code)
