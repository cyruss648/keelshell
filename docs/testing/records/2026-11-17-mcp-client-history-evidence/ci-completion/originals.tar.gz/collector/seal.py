"""Seal the finished local collection; do not write outside this directory."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent


def dump(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def sha(data):
    return hashlib.sha256(data).hexdigest()


argv = ["git", "status", "--porcelain=v1", "--untracked-files=no"]
tick = time.monotonic()
proc = subprocess.run(argv, cwd=REPO, env={**os.environ, "GIT_OPTIONAL_LOCKS": "0"},
                      stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
(ROOT / "inputs/tracked-status-after.txt").write_bytes(proc.stdout)
(ROOT / "inputs/tracked-status-after.stderr").write_bytes(proc.stderr)
scope = {
    "argv": argv, "cwd": str(REPO), "exit_code": proc.returncode,
    "natural_exit": proc.returncode >= 0, "reaped": True, "timed_out": False,
    "elapsed_seconds": round(time.monotonic() - tick, 6),
    "stdout_path": "inputs/tracked-status-after.txt", "stdout_bytes": len(proc.stdout),
    "stdout_sha256": sha(proc.stdout), "stderr_bytes": len(proc.stderr),
    "stderr_sha256": sha(proc.stderr),
    "tracked_status_equal_before": proc.stdout == (ROOT / "inputs/tracked-status-before.txt").read_bytes(),
    "cargo_target_accessed": False, "product_or_CUA_started": False,
    "git_mutations": False, "network_methods": ["GET"],
}
dump("scope-readback.json", scope)
assert proc.returncode == 0

ledger = json.loads((ROOT / "command-ledger.json").read_text())
known = {r.get("receipt") for r in ledger["local"]}
for path in sorted((ROOT / "commands").glob("*/receipt.json")):
    relative = str(path.relative_to(ROOT))
    if relative not in known:
        ledger["local"].append({"receipt": relative, **json.loads(path.read_text())})
ledger["local"].append({"receipt": "scope-readback.json", **scope})
ledger["sealing_invocation"] = ["python3", "-B", str(ROOT / "seal.py")]
dump("command-ledger.json", ledger)

archives = json.loads((ROOT / "archive-manifest.json").read_text())
dump("length-summary.json", {
    "raw_ZIP_count": len(archives), "raw_ZIP_bytes": sum(a["bytes"] for a in archives),
    "ZIP_member_count": sum(len(a["members"]) for a in archives),
    "ZIP_members_uncompressed_bytes": sum(m["bytes"] for a in archives for m in a["members"]),
    "GET_count": len(ledger["GET"]),
    "GET_stdout_bytes": sum(r["bytes"] for r in ledger["GET"]),
    "GET_stderr_bytes": sum(r["stderr_bytes"] for r in ledger["GET"]),
    "archives": [{"path": a["path"], "bytes": a["bytes"], "sha256": a["sha256"],
                  "member_count": len(a["members"])} for a in archives],
})

# The receipt explicitly excludes itself. The subsequent outer checksum includes
# this receipt as well, and the final in-memory pass verifies every listed file.
excluded = {"SHA256SUMS", "seal-verification.json"}
payload = sorted(p for p in ROOT.rglob("*") if p.is_file() and p.name not in excluded)
entries = [(str(p.relative_to(ROOT)), sha(p.read_bytes()), p.stat().st_size) for p in payload]
assert all(sha((ROOT / name).read_bytes()) == digest and
           (ROOT / name).stat().st_size == size for name, digest, size in entries)
dump("seal-verification.json", {
    "generated_at_utc": datetime.now(timezone.utc).isoformat(),
    "scope": "Local payload byte/digest readback before outer SHA256SUMS generation",
    "verified_files": len(entries), "verified_bytes": sum(e[2] for e in entries),
    "mismatches": 0, "excludes_this_receipt_and_outer_checksums": True,
    "outer_checksum_next": "SHA256SUMS includes this receipt and all files except itself",
    "tracked_status_equal_before": scope["tracked_status_equal_before"],
})
paths = sorted(p for p in ROOT.rglob("*") if p.is_file() and p.name != "SHA256SUMS")
(ROOT / "SHA256SUMS").write_text("".join(
    f"{sha(p.read_bytes())}  {p.relative_to(ROOT)}\n" for p in paths))
rows = (ROOT / "SHA256SUMS").read_text().splitlines()
assert len(rows) == len(paths)
for row in rows:
    digest, name = row.split("  ", 1)
    assert sha((ROOT / name).read_bytes()) == digest
assert {str(p.relative_to(ROOT)) for p in paths} == {row.split("  ", 1)[1] for row in rows}
print(json.dumps({
    "checksum_entries_verified": len(rows), "mismatches": 0,
    "all_files_except_checksum_itself_covered": True,
    "total_files_including_checksum": len(paths) + 1,
    "total_bytes_including_checksum": sum(p.stat().st_size for p in paths) + (ROOT / "SHA256SUMS").stat().st_size,
    "SHA256SUMS_sha256": sha((ROOT / "SHA256SUMS").read_bytes()),
    "REPORT_sha256": sha((ROOT / "REPORT.md").read_bytes()),
    "tracked_status_equal_before": scope["tracked_status_equal_before"],
}), flush=True)
