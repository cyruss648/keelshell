**限定 APPROVE：精确 f910 的这三次 CI 原件、计数与身份绑定可接受。P0=0、P1=0、P2=0、P3=0。**

复核对象只有 `f910e0013832643f09b112b08443675a956d5551`：
Quality `44026933453`、Windows API `44026933510`、OpenSSH `44026933475`，均 attempt 1。
我是本次新增非作者复核者；先读 AGENTS、RTK、HANDOFF 与收集者 REPORT，再自行解析原件。
没有运行、导入或复跑收集者的 collect/analyze/report/seal，也没有用其 summary/verification 作为通过依据。
其旧 helper 只做 Git 归档字节核对。最终独立检查 **2,301 通过／0 失败**＝主脚本 2,296＋补充 5；
通过不包含独立产品执行。[最终计数][verify]、[全部断言][checks]、[补充 Git commit/tree 核对][supplement]。

| 原始 API / job | 原件终态 | 精确证据 |
| --- | --- | --- |
| Quality：Ubuntu `133849410428`、macOS `133849410649`、Windows `133849410871` | 三 job completed/success | `snapshots/001/44026933453-{run,jobs}.json:1`、三个 `jobs/<id>.json:1` |
| Windows API：direct `133849410135` | completed/success | `snapshots/001/44026933510-{run,jobs}.json:1`、`jobs/133849410135.json:1` |
| Windows API：isolated-SSH `133849412218` | completed/**skipped**，steps 空 | `jobs/133849412218.json:1`；f910 workflow 第 61–76 行 |
| OpenSSH：`133849409893` | completed/success | `snapshots/001/44026933475-{run,jobs}.json:1`、`jobs/133849409893.json:1` |

上述相对原件路径均以 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-source-ci-completion-20261117/` 为根。
3 run、6 单 job、4 单 artifact 与各自列表逐对象相等；列表 total_count 与独立枚举相等。
26 份 GET receipt 的方法、原始字节数、SHA、exit0/reaped/非 timeout 均一致；本复核网络请求为 0。
这是已封存的 2026-11-17 06:37:40 UTC 观察，未声称独立向 GitHub 重取或核实更晚状态。
五个实际执行 job 的 checkout 日志都有准确 f910 独立 SHA 行，见 [evidence.txt 第 1 行起][checkout]。
`git cat-file commit` 的 tree `a7324f43f4a6bc416b7f47e9bf1657b9b1f5745d` 与三个 run API 的 head_commit.tree_id 相等。

7 原始 ZIP 共 **172 成员／1,213,546 压缩字节**。逐 ZIP CRC、无重名/越界成员、成员全集、每成员长度与 SHA-256
均从原字节重算，再与 archive-manifest 逐项比较；不是采样或只检查外层摘要。[逐成员结果][members]。
四个 artifact ZIP 的服务端 digest、size、源 run/SHA 均与列表及单项 API 相等：
`14304977393`→`01802f40…ce0eb`、`14304472242`→`140f7da4…beec82`、
`14304130642`→`8e8c09ef…195ed`、`14303232465`→`853e64bf…d4ab`；完整摘要在逐成员 JSON 与原始 API。
三个 run 日志 ZIP 只有本地摘要，没有被表示成服务端 digest。
独立递归枚举封存目录 **131 文件**，`SHA256SUMS` 恰好覆盖除自身外 **130 文件**；
无缺项、额外条目、重复条目或摘要差异。开始/结束与自有 baseline 的全部原件字节相同。

| Quality 主结果（均各 96 普通套件） | Rust passed/failed/ignored | doctest passed/failed/ignored | Python 主 run/skip |
| --- | ---: | ---: | ---: |
| Ubuntu 24.04 | 3448/0/69 | 15/0/0 | 526/3 |
| macOS 26 | 3455/0/68 | 15/0/0 | 526/3 |
| Windows 2025 | 3442/0/66 | 15/0/0 | 526/53 |

每套件逐名状态、声明数、summary、名称唯一性相符，主 Rust **10,548 条**含 ignored；
doctest 共 **45 条**，每平台六个结果组（AI 普通和 compile-fail 分两组，含一个零用例组）。
逐名库存与 ignored 原因保存在自有 [inventories.json][inventory]，并与收集者库存逐名交叉比较相等。
原日志定位为 Quality ZIP 的 `native (<平台>)/8_Rust quality gate.txt`；
Ubuntu 主 Python 在原第 22/24 行、macOS 21/23 行、Windows 22/24 行，摘录见 [evidence.txt 第 31 行起][quality]。
主 discovery 是 quiet 输出：逐字符进度确为 526，`s` 分别 3/3/53；**没有逐名 skip 身份/原因，保持未知，不从当前源码后验补齐**。
packaging 每平台 57 run，Windows skip4，其余 skip0；主 gate 内嵌 Python helper 仅 Ubuntu/macOS 各 30 run/skip0，单列。
Windows preflight 单列 filesystem70/0/0、archive41/0/0、session461/0/3，不重复计入主 Rust。

macOS 与 Linux artifact 各有 OpenSSH interop **18/0/0**、forwarding **6/0/0**，
逐名、result.json 的命令/计数、6 份日志各自长度与 ZIP 原件一致；完整命令与 [interop.json][interop] 对应。
cleanup 声明的 ancestry/kernel birth identity 观察范围照录；不扩大为所有可能在观察间隙完全脱离的后代。
Windows API lab **111 run/skip3**；capture replay Rust **1/0/0，9 filtered**。
OpenSSH lab **96 run/skip1**；native SSH 原 `--list` 单名与实际 **1/0/0** 相符。
API 的三个 skip 分别为 `test_cli_records_nonwindows_hold_without_running_commands`、
`test_nonwindows_native_oracle_is_hold`、`test_shell_process_proof_cannot_fall_back_to_posix`，
原 lab 日志 115/119/120 行；SSH skip 为 `test_nonwindows_cli_preserves_explicit_hold_without_running_children`，原第 107 行。
四者原原因均为 `negative non-Windows boundary only`。packaging skip 名称/原原因也逐条保存在自有库存，没有当通过计数。

Windows API 六 direct children、SSH 九 direct children 的独立 receipt 与总 receipt 逐字段相等，
raw stdout/stderr 长度相等，均 direct_reaped、active=0、pipes_drained、errors=[]。
API 五个 CMD→PowerShell 的原对象自然 exit0；SSH `owned-sshd.observed_exit=null` **保留**。
另从独立 Win32 原 JSON 重算：两份 artifact 均有四自有监听/UDP 端点，
两 connected TCP 在独立 API 中实际存在且状态为 CONNECTED_OR_OTHER，生产监听结果排除；
自有进程/工作集、稳定接口 identity 与固定卷 inventory 相符。没有只信 comparison.json 的 PASS。

SSH seal 原件是 **HOLD**：21 原对象，master 仍活、active1/pending1、owned handles22。
20 非 master 均自然终态，exit 分布 **0×14、255×5、1×1**。
cleanup 后才为 PASS：相同 PID+creation_time 的 21 原对象、active0/pending0/handles0、closed=true。
**master cleanup exit125，natural_terminal_before_cleanup=false**；没有改成自然 exit0，也没有用最终 census 反推早期未知条件。
具体原件为 `artifact-14303232465.zip!ssh-debug-originals.json` 第 2–18/322/351 行、
`!ssh-debug-cleanup.json` 第 2–18/322/349 行；可读摘录见 [evidence.txt 第 238 行起][originals]和[第 282 行起][cleanup]。
临时私钥目录删除且 keys/private_config 未上传的原信号保留；原始非零退出、异常事件、控制测试信号和前述 HOLD 原件均未改写。

五份 archived workflows、`inputs/source-check.py.txt`、AGENTS 与 **f910 Git blob 逐字节相等**。
三个 workflow 顶层所有已执行 `run` 命令块与精确 YAML 字符串相等（仅去 Actions timestamp/ANSI 外壳），
`check.py` 的七条命令还从该 blob 的 AST 独立读出核对。
Windows PS 命令由 f910 `windows.rs` 常量＋`common.ps1`＋对应 body 原字节重新拼接，
独立 UTF-16LE/Base64 后与 API 的 `.wire.txt`、实际 CMD argv 逐字节相等；
SSH 则绑定到 seal 中四个原 PowerShell 的 PID/birth identity/实际命令行及自然 exit0，
只识别 argv0 与后续参数间可变空格，参数内容不规范化。[全部源码与命令绑定][sources]。
归档 HANDOFF、ROADMAP 和旧 helper archive 对应记录的文档 HEAD `4c8654f…`，与其 Git blob 相等；
HANDOFF/ROADMAP **不等于 f910**，只作为上下文，没有代签工程。RTK 与实际已读指令字节相等。

**HOLD 边界保留**：API isolated-SSH skipped，direct artifact `ssh=UNRUN`；
两份 Windows artifact **native_gui=UNRUN**；主 Python 各 skip 的逐名身份未知；
独立产品执行、独立二进制 `--list`、重新编译/测试、当前 monitor 取消增量、GUI/原生矩阵、安装、签名/公证、发行及完整产品均不在本批准内。
SSH artifact 只有已封存 binary digest/list/execution 记录，没有在本机取二进制重新哈希或重跑。
原始 raw API/ZIP 及其 digest 支持本限定结论，没有独立网络认证链或新的产品验收。

正式验证命令为 `python3 -B work/mcp-source-ci-review-20261117/verify.py` 三次，
最后五项补充从本目录 `supplement.py` 所保存的等价 inline Python 执行一次。
三个主脚本各实际启动 29 条 Git read 子命令，补充另 1 条；共 **88 条，全部 exit0/reaped**。
浏览用的 cat/rg/nl/Python 与初始 Git 探索不混入此正式子命令数。

| 自有离线核验 | 检查通过/失败 | 脚本真实退出 |
| --- | ---: | ---: |
| r1 | 2222/29 | 1 |
| r2 | 2290/6 | 1 |
| r3 | 2296/0 | 0 |
| supplement | 5/0 | 0 |

正式断言累计实际执行 6,848 次；最终有效断言为 2,301 项。
r1 的 24 项误把 result.logs 长度当 SHA、5 项误把 known-direct 句柄加入 Job census；
r2 的 4 项误把 upload action 当 `run`、2 项误要求独立 API 不包含 connected negative control。
均回到原始 schema/f910 源码修正，不改产品或原件；旧脚本、checks、verification、commands、stdout/stderr/receipt 全保留为 `r1-*`、`r2-*`、`verify-r*.{stdout,stderr,receipt.json}`。
只读探索另有一次不存在脚本的 cat-file exit128，及目录尚未创建时 ls exit2 使该 shell exit1；不隐去、不作为产品失败。
正式脚本子进程状态以 receipt 的 `exit` 为准，包装 Python 自身的 exit0 不能代签。

全过程只写本 review 目录；无 Cargo、target、网络、产品、GUI、提交/推送/清理操作。
共享 HEAD 前后均 `4c8654f…`，tracked status 从原 6 项变为 8 项，期间存在并行开发；没有认领作者或清理这些修改。
详见 [scope.json 第 5 行起][scope]。当前 dirty checkout 的 monitor.rs/platform/tests 从未用于旧 CI 的源码身份。
本报告批准仅限所列 f910 CI 原件完整性与可核实记录；P0/P1/P2/P3 未关闭发现全零，全部上述 HOLD 保持。

[verify]: /Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-source-ci-review-20261117/verification.json:2
[checks]: /Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-source-ci-review-20261117/checks.json:1
[supplement]: /Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-source-ci-review-20261117/supplement.json:1
[checkout]: /Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-source-ci-review-20261117/evidence.txt:1
[members]: /Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-source-ci-review-20261117/zip-members.json:1
[inventory]: /Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-source-ci-review-20261117/inventories.json:1
[quality]: /Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-source-ci-review-20261117/evidence.txt:31
[interop]: /Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-source-ci-review-20261117/interop.json:1
[originals]: /Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-source-ci-review-20261117/evidence.txt:238
[cleanup]: /Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-source-ci-review-20261117/evidence.txt:282
[sources]: /Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-source-ci-review-20261117/source-bindings.json:1
[scope]: /Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-source-ci-review-20261117/scope.json:5
