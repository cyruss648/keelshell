"""The five supplemental checks executed inline after verify-r3; offline only."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess

out = Path(__file__).resolve().parent
raw = out.parent / "mcp-source-ci-completion-20261117"
sha = "f910e0013832643f09b112b08443675a956d5551"
argv = ["git", "--no-optional-locks", "cat-file", "commit", sha]
process = subprocess.run(argv, cwd=out.parent.parent, capture_output=True, timeout=30)
(out / "source/f910.commit").write_bytes(process.stdout)
tree = process.stdout.decode().splitlines()[0].split()[1]
checks = [
    {"check": "cat-file exact commit exit", "pass": process.returncode == 0},
    {"check": "raw Git commit tree equals all three archived run APIs",
     "pass": all(json.loads((raw / f"snapshots/001/{run}-run.json").read_text())["head_commit"]["tree_id"] == tree
                 for run in [44026933453, 44026933510, 44026933475])},
    {"check": "RTK input equals actual instruction bytes",
     "pass": (raw / "inputs/RTK.md").read_bytes() == Path("/Users/hdh/.codex/RTK.md").read_bytes()},
    {"check": "archived source-commit display identifies f910",
     "pass": (raw / "inputs/source-commit.txt").read_text().splitlines()[0] == "commit " + sha},
    {"check": "archived checkout-head is exact recorded context head",
     "pass": (raw / "inputs/checkout-head.txt").read_text().strip() == "4c8654f219779f48afd485bec8ff1b284905fbf0"},
]
result = {
    "argv": argv, "exit": process.returncode, "natural_exit": True, "reaped": True,
    "stdout_bytes": len(process.stdout), "stdout_sha256": hashlib.sha256(process.stdout).hexdigest(),
    "stderr_bytes": len(process.stderr), "tree": tree, "checks": checks,
    "passed": sum(c["pass"] for c in checks), "failed": sum(not c["pass"] for c in checks),
    "generated_utc": datetime.now(timezone.utc).isoformat(),
}
(out / "supplement.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
raise SystemExit(1 if result["failed"] else 0)
