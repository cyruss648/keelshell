"""Offline independent review of only the three f910 CI runs. Stdlib; no product imports."""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import base64
import ast
import hashlib
import io
import json
import os
import re
import subprocess
import tarfile
import time
import zipfile

OUT = Path(__file__).resolve().parent
REPO = OUT.parent.parent
RAW = REPO / "work/mcp-source-ci-completion-20261117"
SHA = "f910e0013832643f09b112b08443675a956d5551"
DOC = "4c8654f219779f48afd485bec8ff1b284905fbf0"
RUNS = {
    44026933453: ("ci.yml", [133849410428, 133849410649, 133849410871]),
    44026933510: ("windows-monitor.yml", [133849410135, 133849412218]),
    44026933475: ("windows-monitor-ssh.yml", [133849409893]),
}
checks, commands, evidence, inventories, sources = [], [], [], {}, {}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def load(path):
    return json.loads((RAW / path).read_bytes())


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def check(label, ok, where="", actual=None):
    row = {"check": label, "pass": bool(ok), "evidence": where}
    if actual is not None:
        row["actual"] = actual
    checks.append(row)


def git(*args):
    argv = ["git", "--no-optional-locks", *args]
    start = time.monotonic()
    proc = subprocess.run(argv, cwd=REPO, capture_output=True, timeout=30,
                          env={**os.environ, "GIT_OPTIONAL_LOCKS": "0"})
    commands.append({"argv": argv, "exit": proc.returncode, "reaped": True,
                     "elapsed_seconds": round(time.monotonic() - start, 6),
                     "stdout_bytes": len(proc.stdout), "stdout_sha256": digest(proc.stdout),
                     "stderr_bytes": len(proc.stderr), "stderr_sha256": digest(proc.stderr)})
    check("git read completed", proc.returncode == 0, " ".join(argv))
    if proc.returncode:
        raise RuntimeError(proc.stderr.decode(errors="replace"))
    return proc.stdout


def blob(name, commit=SHA):
    key = f"{commit}:{name}"
    if key not in sources:
        data = git("cat-file", "blob", key)
        sources[key] = data
        dest = OUT / "source" / (name if commit == SHA else f"context/{name}")
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
    return sources[key]


def cite(archive, member, predicate):
    lines = archives[archive][member].decode("utf-8-sig", errors="replace").splitlines()
    evidence.append(f"{archive} ! {member}")
    for n, line in enumerate(lines, 1):
        if predicate(n, line):
            evidence.append(f"  raw line {n}: {line}")
    evidence.append("")


ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
STAMP = re.compile(r"^\ufeff?\d{4}-\d\d-\d\dT\S+Z ")


def lines(data):
    return [ANSI.sub("", STAMP.sub("", line))
            for line in data.decode("utf-8-sig").splitlines()]


def rust(data, where):
    suites, current, header, docs = [], None, "", False
    for n, line in enumerate(lines(data), 1):
        if "Doc-tests " in line:
            docs = True
            header = line.strip()
        elif line.lstrip().startswith("Running "):
            header = line.strip()
        m = re.fullmatch(r"running (\d+) tests?", line)
        if m:
            check("no unfinished Rust suite", current is None, f"{where}:{n}")
            current = {"header": header, "doctest": docs, "declared": int(m[1]),
                       "line": n, "names": []}
        m = re.fullmatch(r"test (.+?) \.\.\. (ok|FAILED|ignored)(?:, (.*))?", line)
        if m and current is not None:
            current["names"].append({"name": m[1], "status": m[2],
                                     "reason": m[3], "line": n})
        m = re.match(r"test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; "
                     r"(\d+) ignored; (\d+) measured; (\d+) filtered out;", line)
        if m:
            check("Rust summary has declaration", current is not None, f"{where}:{n}")
            if current is None:
                continue
            counts = Counter(row["status"] for row in current["names"])
            got = [int(m[k]) for k in (2, 3, 4)]
            current.update(summary=got, summary_line=n, filtered=int(m[6]), outcome=m[1])
            check("Rust declared/named/summary agree",
                  current["declared"] == len(current["names"]) == sum(got)
                  and got == [counts["ok"], counts["FAILED"], counts["ignored"]],
                  f"{where}:{current['line']}-{n}", got)
            check("Rust names unique", len({row["name"] for row in current["names"]})
                  == len(current["names"]), f"{where}:{n}")
            check("Rust reported no failures", m[1] == "ok" and got[1] == 0,
                  f"{where}:{n}")
            suites.append(current)
            current = None
    check("no truncated final Rust suite", current is None, where)
    return suites


def python(data, where):
    groups, named = [], []
    ll = lines(data)
    for n, line in enumerate(ll, 1):
        m = re.match(r"(test_\S+) \(([^)]+)\) \.\.\. (ok|skipped .+)$", line)
        if m:
            named.append({"name": m[1], "id": m[2], "status": m[3], "line": n})
        m = re.fullmatch(r"Ran (\d+) tests? in [\d.]+s", line)
        if m:
            following = [(i + 1, ll[i]) for i in range(n, min(n + 4, len(ll))) if ll[i]]
            outcome_line, outcome = following[0]
            ok = re.fullmatch(r"OK(?: \(skipped=(\d+)\))?", outcome)
            skip = int(ok[1] or 0) if ok else None
            group = {"run": int(m[1]), "skipped": skip, "line": n,
                     "outcome_line": outcome_line, "outcome": outcome, "names": named}
            check("Python completion OK", ok is not None, f"{where}:{n}")
            if named:
                check("Python named inventory agrees",
                      len(named) == group["run"]
                      and sum(x["status"].startswith("skipped") for x in named) == skip,
                      f"{where}:{n}")
            groups.append(group)
            named = []
    return groups


started = datetime.now(timezone.utc).isoformat()
baseline = load("../mcp-source-ci-review-20261117/baseline.json")
files = {str(p.relative_to(RAW)): p for p in RAW.rglob("*") if p.is_file()}
sums_lines = (RAW / "SHA256SUMS").read_text().splitlines()
sums = {line[66:]: line[:64] for line in sums_lines}
check("SHA256SUMS independent full enumeration",
      set(files) - {"SHA256SUMS"} == set(sums) and len(sums) == len(sums_lines),
      "SHA256SUMS", {"files": len(files), "entries": len(sums)})
for name, expected in sums.items():
    check("SHA256SUMS payload digest", name in files and digest(files[name].read_bytes()) == expected, name)
check("collection unchanged since reviewer baseline",
      baseline["files"] == {n: {"bytes": p.stat().st_size, "sha256": digest(p.read_bytes())}
                            for n, p in sorted(files.items())}, "baseline.json")

archives, zip_manifest = {}, []
claimed = {x["path"]: x for x in load("archive-manifest.json")}
for path in sorted((RAW / "downloads").glob("*.zip")):
    rel = str(path.relative_to(RAW))
    payload = path.read_bytes()
    with zipfile.ZipFile(io.BytesIO(payload)) as z:
        check("ZIP CRC", z.testzip() is None, rel)
        check("ZIP names unique and safe",
              len(set(z.namelist())) == len(z.namelist())
              and all(not Path(n).is_absolute() and ".." not in Path(n).parts for n in z.namelist()), rel)
        members = {n: z.read(n) for n in z.namelist()}
    archives[rel] = members
    record = {"path": rel, "bytes": len(payload), "sha256": digest(payload),
              "members": [{"path": n, "bytes": len(b), "sha256": digest(b)}
                          for n, b in members.items()]}
    check("ZIP manifest archive bytes",
          record["bytes"] == claimed[rel]["bytes"] and record["sha256"] == claimed[rel]["sha256"], rel)
    old_members = {m["path"]: m for m in claimed[rel]["members"]}
    check("ZIP manifest complete membership", set(old_members) == set(members), rel)
    for row in record["members"]:
        check("ZIP member bytes and digest", old_members[row["path"]] == row, f"{rel}!{row['path']}")
    zip_manifest.append(record)
check("seven ZIPs / 172 members / 1213546 compressed bytes",
      [len(zip_manifest), sum(len(z["members"]) for z in zip_manifest),
       sum(z["bytes"] for z in zip_manifest)] == [7, 172, 1213546], "downloads/")

get_receipts = sorted(p for p in RAW.rglob("*.receipt.json")
                      if p.parts[-2] in {"001", "jobs", "artifacts", "downloads"})
check("26 raw GET receipts", len(get_receipts) == 26, "raw API/download receipts")
for p in get_receipts:
    j = json.loads(p.read_bytes())
    payload = RAW / j["path"]
    check("original GET endpoint/exit/bytes",
          j["method"] == "GET" and j["argv"][:4] == ["gh", "api", "--method", "GET"]
          and not j["timed_out"] and j["natural_exit"] and j["reaped"]
          and j["exit_code"] == 0 and j["bytes"] == payload.stat().st_size
          and j["sha256"] == digest(payload.read_bytes()), str(p.relative_to(RAW)))

api = {}
for rid, (workflow, expected_jobs) in RUNS.items():
    prefix = f"snapshots/001/{rid}"
    run = load(prefix + "-run.json")
    jobs = load(prefix + "-jobs.json")
    arts = load(prefix + "-artifacts.json")
    check("run exact SHA/attempt/status/workflow",
          (run["id"], run["head_sha"], run["head_commit"]["id"], run["run_attempt"],
           run["status"], run["conclusion"], run["path"]) ==
          (rid, SHA, SHA, 1, "completed", "success", f".github/workflows/{workflow}"), prefix + "-run.json")
    check("job list complete", jobs["total_count"] == len(jobs["jobs"]) == len(expected_jobs)
          and sorted(j["id"] for j in jobs["jobs"]) == sorted(expected_jobs), prefix + "-jobs.json")
    check("artifact list complete", arts["total_count"] == len(arts["artifacts"]), prefix + "-artifacts.json")
    for job in jobs["jobs"]:
        jid = job["id"]
        single = load(f"jobs/{jid}.json")
        check("single job equals listed raw job", job == single, f"jobs/{jid}.json")
        check("job exact SHA/run/attempt/terminal",
              (job["head_sha"], job["run_id"], job["run_attempt"], job["status"], job["conclusion"])
              == (SHA, rid, 1, "completed", "skipped" if jid == 133849412218 else "success"),
              f"jobs/{jid}.json")
        if jid == 133849412218:
            check("isolated SSH skipped without steps", job["steps"] == [], f"jobs/{jid}.json")
        else:
            arc = f"downloads/run-{rid}-attempt-1-logs.zip"
            matches = [n for n in archives[arc] if "/2_Run actions_checkout@" in n and n.startswith(job["name"] + "/")]
            check("one checkout log", len(matches) == 1, arc)
            if matches:
                member = matches[0]
                check("checkout exact source SHA", any(line == SHA for line in lines(archives[arc][member])), f"{arc}!{member}")
                cite(arc, member, lambda n, l: SHA in l)
        api[str(jid)] = {"run": rid, "name": job["name"], "conclusion": job["conclusion"],
                         "skipped_steps": [s for s in job["steps"] if s["conclusion"] == "skipped"]}
    for artifact in arts["artifacts"]:
        aid = artifact["id"]
        single = load(f"artifacts/{aid}.json")
        p = RAW / f"downloads/artifact-{aid}.zip"
        check("single artifact equals listed raw artifact", artifact == single, f"artifacts/{aid}.json")
        check("artifact service digest and source",
              artifact["digest"] == "sha256:" + digest(p.read_bytes())
              and artifact["size_in_bytes"] == p.stat().st_size and not artifact["expired"]
              and artifact["workflow_run"]["id"] == rid and artifact["workflow_run"]["head_sha"] == SHA,
              f"artifacts/{aid}.json")

source_bindings = []
for workflow in ["ci.yml", "windows-monitor.yml", "windows-monitor-ssh.yml", "windows-native-crash.yml", "release.yml"]:
    name = f".github/workflows/{workflow}"
    data = blob(name)
    check("archived workflow exact f910 blob", data == (RAW / "inputs/workflows" / workflow).read_bytes(), name)
    source_bindings.append({"input": f"inputs/workflows/{workflow}", "git": f"{SHA}:{name}", "sha256": digest(data)})
# The narrow workflow syntax here uses only literal run strings and block scalars.
# Compare complete command blocks after removing only Actions timestamps/ANSI.
for rid, (workflow, _) in RUNS.items():
    src = blob(f".github/workflows/{workflow}").decode().splitlines()
    run_blocks = []
    for i, line in enumerate(src):
        m = re.match(r"(\s*)run: (.*)", line)
        if not m:
            continue
        indent, value = len(m[1]), m[2]
        if value == "|":
            block = []
            for child in src[i + 1:]:
                if child.strip() and len(child) - len(child.lstrip()) <= indent:
                    break
                block.append(child[indent + 2:])
            run_blocks.append(block)
        else:
            run_blocks.append([value])
    arc = f"downloads/run-{rid}-attempt-1-logs.zip"
    executed = {}
    for member, payload in archives[arc].items():
        if "/" not in member or member.endswith("/system.txt"):
            continue
        ll = lines(payload)
        if not any("##[group]Run " in l for l in ll[:3]):
            continue
        if "/2_Run actions_" in member or "/3_Run ._" in member:
            continue
        if any("##[group]Run actions/upload-artifact@" in l for l in ll[:3]):
            check("artifact action pinned in exact workflow",
                  "actions/upload-artifact@cf430e030ddbb5b0abf93d22962f4752f3646cd9" in "\n".join(src),
                  f"{arc}!{member}")
            continue
        # The source's Windows conditional steps have no log on other platforms.
        matches = [index for index, block in enumerate(run_blocks)
                   if any(ll[start:start + len(block)] == block
                          for start in range(len(ll) - len(block) + 1))]
        check("executed workflow command block byte equality", len(matches) == 1, f"{arc}!{member}")
        executed[member] = matches
    check("all non-skipped workflow run blocks observed",
          set(x for v in executed.values() for x in v) ==
          set(range(len(run_blocks) - (1 if workflow == "windows-monitor.yml" else 0))), workflow)
    source_bindings.append({"workflow": workflow, "command_blocks": run_blocks, "executed_members": executed})
data = blob("scripts/check.py")
check("archived gate exact f910 blob", data == (RAW / "inputs/source-check.py.txt").read_bytes(), "inputs/source-check.py.txt")
gate_ast = ast.parse(data)
gate_loop = next(n for n in ast.walk(gate_ast) if isinstance(n, ast.For)
                 and isinstance(n.target, ast.Tuple)
                 and [v.id for v in n.target.elts] == ["label", "command"])
source_gate_commands = []
for entry in gate_loop.iter.elts:
    source_gate_commands.append([ast.literal_eval(n) if isinstance(n, ast.Constant) else "{sys.executable}"
                                 for n in entry.elts[1].elts])
check("exact f910 gate seven command definitions", len(source_gate_commands) == 7, "scripts/check.py")
for dest, name, commit in [
    ("inputs/AGENTS.md", "AGENTS.md", SHA),
    ("inputs/HANDOFF.md", "docs/HANDOFF.md", DOC),
    ("inputs/ROADMAP.md", "docs/ROADMAP.md", DOC),
    ("inputs/helper-archive-committed.tar.gz",
     "docs/testing/records/2026-11-17-tunnel-transport-lifetime-evidence/ci-completion/originals.tar.gz", DOC),
]:
    data = blob(name, commit)
    check("archived input equals stated Git identity", data == (RAW / dest).read_bytes(), dest)
    source_bindings.append({"input": dest, "git": f"{commit}:{name}", "sha256": digest(data)})
for name in ["docs/HANDOFF.md", "docs/ROADMAP.md"]:
    source_bindings.append({"input": f"inputs/{Path(name).name}", "f910_equal":
                            blob(name) == (RAW / "inputs" / Path(name).name).read_bytes(),
                            "role": "context at recorded documentation HEAD; not CI source identity"})
with tarfile.open(fileobj=io.BytesIO((RAW / "inputs/helper-archive-committed.tar.gz").read_bytes())) as t:
    for member, dest in [("collect.py", "previous-collect.py.txt"), ("analyze.py", "previous-analyze.py.txt")]:
        check("old helper copy exact archive bytes",
              t.extractfile(member).read() == (RAW / "inputs" / dest).read_bytes(), dest)

q = "downloads/run-44026933453-attempt-1-logs.zip"
quality = {}
expected_counts = {"ubuntu-24.04": [3448, 0, 69], "macos-26": [3455, 0, 68], "windows-2025": [3442, 0, 66]}
for platform, expected in expected_counts.items():
    member = f"native ({platform})/8_Rust quality gate.txt"
    data = archives[q][member]
    suites = rust(data, f"{q}!{member}")
    main = [s for s in suites if not s["doctest"]]
    docs = [s for s in suites if s["doctest"]]
    total = lambda ss: [sum(s["summary"][i] for s in ss) for i in range(3)]
    check("Quality 96 main suites and exact totals", len(main) == 96 and total(main) == expected, member, total(main))
    check("Quality six doctest groups / 15 named passes", len(docs) == 6 and total(docs) == [15, 0, 0], member, total(docs))
    jid = {"ubuntu-24.04": 133849410428, "macos-26": 133849410649, "windows-2025": 133849410871}[platform]
    collected = next(s for s in load(f"inventories/job-{jid}.json")["steps"] if s["number"] == 8)["rust"]
    check("collector inventory agrees with independent original parse",
          len(collected) == len(suites) and
          [[(n["name"], n["status"], n["reason"]) for n in s["names"]] for s in collected] ==
          [[(n["name"], n["status"], n["reason"]) for n in s["names"]] for s in suites], member)
    py = python(data, member)
    check("Python 526 aggregate and platform skip",
          py[0]["run"] == 526 and py[0]["skipped"] == (53 if platform == "windows-2025" else 3), member)
    progress = [line for line in lines(data)[:py[0]["line"]] if re.fullmatch(r"[.s]+", line)]
    check("Python primary raw progress 526 with exact skip symbols",
          len(progress) == 1 and len(progress[0]) == 526
          and progress[0].count("s") == py[0]["skipped"], member)
    if platform != "windows-2025":
        check("inline helper Python 30", len(py) == 2 and py[1]["run"] == 30 and py[1]["skipped"] == 0, member)
    else:
        check("Windows no inline helper Python group", len(py) == 1, member)
    packaging = f"native ({platform})/4_Packaging regression tests.txt"
    pkg = python(archives[q][packaging], packaging)
    check("packaging 57 / platform skip", len(pkg) == 1 and pkg[0]["run"] == 57
          and pkg[0]["skipped"] == (4 if platform == "windows-2025" else 0), packaging)
    quality[platform] = {"main": total(main), "doctests": total(docs), "main_suites": len(main),
                         "doctest_groups": len(docs), "python": [{k: v for k, v in p.items() if k != "names"} for p in py]}
    inventories[platform] = {"archive": q, "member": member, "rust": suites, "python": py, "packaging": pkg}
    logged = [line.split("Running: ", 1)[1] for line in lines(data) if line.startswith("Running: ")]
    check("gate commands equal exact f910 AST",
          logged[0].endswith(" ".join(source_gate_commands[0][1:]))
          and logged[1:] == [" ".join(c) for c in source_gate_commands[1:]], member)
    check("all seven exact gate commands", len(logged) == 7 and logged[0].endswith("-m unittest discover -s scripts -p test_*.py")
          and logged[1:] == [
              "cargo fmt --all --check", "cargo clippy --workspace --all-targets --locked -- -D warnings",
              "cargo test --workspace --locked -- --test-threads=4",
              "cargo test -p keelshell-ai --test local_agent_process --locked -- --readiness-error-tests",
              "cargo test -p keelshell-ai --test local_agent_directory_process --locked -- --observer-io-error-tests",
              "cargo test -p keelshell-ai --test local_agent_process --locked -- --controller-small-stack"], member)
    cite(q, member, lambda n, l: any(x in ANSI.sub("", l) for x in
         ["Ran ", "OK", "Running: ", "Dependency version policy: passed", "Doc-tests ",
          "all assertions/scenario groups passed", "controller process controls passed"])
         and len(l) < 800)
for number, expected in [(5, [70, 0, 0]), (6, [41, 0, 0]), (7, [461, 0, 3])]:
    member = next(n for n in archives[q] if n.startswith(f"native (windows-2025)/{number}_"))
    suites = rust(archives[q][member], f"{q}!{member}")
    check("Windows preflight separate totals", len(suites) == 1 and suites[0]["summary"] == expected, member)
    inventories[f"windows-preflight-{number}"] = suites

interop = []
for aid in [14304472242, 14304977393]:
    arc = f"downloads/artifact-{aid}.zip"
    for member in archives[arc]:
        if not member.endswith("/result.json"):
            continue
        j = json.loads(archives[arc][member])
        parent = member.rsplit("/", 1)[0]
        log = parent + "/tests.log"
        suites = rust(archives[arc][log], f"{arc}!{log}")
        forwarding = "forwarding_openssh" in j["command"]
        expected = 6 if forwarding else 18
        command = ["cargo", "test", "-p", "keelshell-session", "--test",
                   "forwarding_openssh" if forwarding else "openssh_interop", "--locked",
                   "--", "--ignored", "--test-threads=1"]
        check("interop result/names/command/cleanup",
              len(suites) == 1 and suites[0]["summary"] == [expected, 0, 0]
              and j["passed_tests"] == expected and j["outcome"] == "passed" and j["command"] == command
              and j["cleanup"]["owned_processes_stopped"] and j["cleanup"]["temporary_directory_removed"]
              and j["cleanup"]["ancestry_unverified"] == [], f"{arc}!{member}")
        interop.append({"archive": arc, "member": member, "tests": suites,
                        "command": command, "cleanup": j["cleanup"], "logs_bound": j["logs"]})
        for n, h in j["logs"].items():
            data = archives[arc][parent + "/" + n]
            check("interop raw log length", h == len(data), f"{arc}!{parent}/{n}")
        cite(arc, log, lambda n, l: True)

windows = {}
for rid, aid, expected_lab in [(44026933510, 14304130642, (111, 3)),
                               (44026933475, 14303232465, (96, 1))]:
    arc = f"downloads/artifact-{aid}.zip"
    members = archives[arc]
    receipt = json.loads(members["receipt.json"])
    children = receipt["children"]
    check("Windows artifact PASS with GUI UNRUN", receipt["status"] == "PASS"
          and receipt["windows_api"] == "PASS" and receipt["native_gui"] == "UNRUN", f"{arc}!receipt.json")
    check("Windows child count", len(children) == (6 if rid == 44026933510 else 9), f"{arc}!receipt.json")
    child_rows = []
    for child in children:
        name = child["label"]
        raw_child = json.loads(members[name + ".receipt.json"])
        check("child receipt embedded equals original", raw_child == {k: v for k, v in child.items() if k != "label"},
              f"{arc}!{name}.receipt.json")
        terminal = child["terminal"]
        check("original direct child terminal",
              terminal["direct_reaped"] and terminal["active_processes"] == 0
              and terminal["pipes_drained"] and terminal["errors"] == [] and child["errors"] == [],
              f"{arc}!{name}.receipt.json")
        for suffix in ("stdout", "stderr"):
            check("child raw output length", len(members[f"{name}.{suffix}"]) == child[f"{suffix}_bytes"],
                  f"{arc}!{name}.{suffix}")
        child_rows.append({"label": name, "observed_exit": child["observed_exit"], "terminal_reaped": terminal["direct_reaped"]})
    logarc = f"downloads/run-{rid}-attempt-1-logs.zip"
    lablog = next(n for n in archives[logarc] if "/4_" in n)
    labs = python(archives[logarc][lablog], f"{logarc}!{lablog}")
    check("Windows lab exact count", len(labs) == 1 and (labs[0]["run"], labs[0]["skipped"]) == expected_lab, lablog)
    inventories[str(rid) + "-python"] = labs
    windows[str(rid)] = {"children": child_rows, "native_gui": receipt["native_gui"],
                         "ssh": receipt["ssh"], "windows_api": receipt["windows_api"]}
    cite(arc, "receipt.json", lambda n, l: n < 20 or '"observed_exit":' in l)
    for name in ["comparison.json", "fixture.json", "independent-before.json", "independent.json"]:
        # Parse original objects, not collector summaries. Preserve unknown CPU and capacity fields.
        windows[str(rid)][name] = json.loads(members[name])
    independent = json.loads(members["independent.json"])
    fixture = json.loads(members["fixture.json"])
    if rid == 44026933510:
        processes = json.loads(members["processes.stdout"])["data"]
        sockets = json.loads(members["sockets.stdout"])["data"]
        resources = json.loads(members["resources.stdout"])["data"]
    else:
        client = json.loads(members["rust-client.json"])
        processes, sockets, resources = [client[k] for k in ["windows_processes", "windows_sockets", "windows_resources"]]
    endpoint = lambda row: tuple(str(row[k]) for k in ["protocol", "address", "port", "pid"])
    required = {endpoint(row) for row in fixture["endpoints"]}
    excluded = {endpoint(row) for row in fixture["connected_only"]}
    prod = {endpoint(row) for row in sockets["sockets"]}
    oracle_all = {endpoint(row) for row in independent["sockets"]}
    oracle = {endpoint(row) for row in independent["sockets"] if row["state"] in ("LISTEN", "BOUND")}
    check("four actual owned endpoints in production and independent APIs",
          len(required) == 4 and required <= prod and required <= oracle
          and len(excluded) == 2 and excluded <= oracle_all
          and not excluded & prod and not excluded & oracle, arc)
    owned = [p for p in processes["processes"] if int(p["pid"]) == fixture["pid"]]
    check("owned actual process and working set",
          len(owned) == 1 and owned[0]["name"].lower() == independent["process"]["name"].lower()
          and abs(int(owned[0]["working_set_bytes"]) - independent["process"]["working_set_bytes"]) <= 16 * 1024 * 1024, arc)
    before_api, after_api = independent["before"], independent["after"]
    net_ids = lambda row: {(p["interface_guid"], p["interface_luid"], p["interface_index"], p["name"]) for p in row["networks"]}
    volumes = lambda row: {(p["mount"].lower(), p["volume_guid"].lower(), p["volume_serial"])
                           for p in row["drive_inventory"] if p["drive_type"] == 3 and p["ready"]}
    check("stable raw interface identity inventory complete",
          net_ids(before_api) == net_ids(after_api)
          and {p["name"] for p in resources["networks"]} == {p["name"] for p in before_api["networks"]}, arc)
    check("stable raw fixed drive identity inventory complete",
          volumes(before_api) == volumes(after_api)
          and {p["mount"].lower() for p in resources["filesystems"]} == {p[0] for p in volumes(before_api)}, arc)
check("API artifact SSH UNRUN", windows["44026933510"]["ssh"] == "UNRUN", "artifact-14304130642.zip!receipt.json")
replay_arc = "downloads/run-44026933510-attempt-1-logs.zip"
replay_member = next(n for n in archives[replay_arc] if "/6_Captured API" in n)
replay = rust(archives[replay_arc][replay_member], f"{replay_arc}!{replay_member}")
check("capture replay one passed nine filtered", len(replay) == 1
      and replay[0]["summary"] == [1, 0, 0] and replay[0]["filtered"] == 9, replay_member)
inventories["windows-api-replay"] = replay
ssh_arc = "downloads/artifact-14303232465.zip"
ssh_members = archives[ssh_arc]
native = rust(ssh_members["native-ssh-client.stdout"], f"{ssh_arc}!native-ssh-client.stdout")
binary = json.loads(ssh_members["test-binary.json"])
listing = ssh_members["live-test-inventory.stdout"].decode().splitlines()
test_name = "actual_windows_openssh_monitor_matches_owned_fixture"
check("native SSH exact list/execution", len(native) == 1 and native[0]["summary"] == [1, 0, 0]
      and [x["name"] for x in native[0]["names"]] == binary["inventory"] == [test_name]
      and binary["executed"] == test_name and test_name + ": test" in listing, f"{ssh_arc}!test-binary.json")
check("SSH source head and clean original checkout", ssh_members["source-head.stdout"].strip() == SHA.encode()
      and ssh_members["source-status.stdout"] == b"", f"{ssh_arc}!source-head.stdout")
inventories["windows-native-ssh"] = native
before = json.loads(ssh_members["ssh-debug-originals.json"])
after = json.loads(ssh_members["ssh-debug-cleanup.json"])
check("SSH pre-cleanup HOLD preserved",
      [before[k] for k in ["state", "terminal_proven", "job_total_processes", "job_active_processes",
                          "pending_process_objects", "owned_handles_remaining", "closed"]]
      == ["HOLD", False, 21, 1, 1, 22, False], f"{ssh_arc}!ssh-debug-originals.json")
check("SSH cleanup PASS with zero remaining",
      [after[k] for k in ["state", "terminal_proven", "job_total_processes", "job_active_processes",
                         "pending_process_objects", "owned_handles_remaining", "closed"]]
      == ["PASS", True, 21, 0, 0, 0, True], f"{ssh_arc}!ssh-debug-cleanup.json")
before_rows = {(a["pid"], a["creation_time"]): a for a in before["admissions"]}
after_rows = {(a["pid"], a["creation_time"]): a for a in after["admissions"]}
check("same 21 original objects before/after", len(before_rows) == len(after_rows) == 21
      and set(before_rows) == set(after_rows), ssh_arc)
for label, snapshot in [("seal", before), ("cleanup", after)]:
    check("complete census with no unknowns",
          snapshot["complete_original_object_census"] and snapshot["admission_closed"]
          and snapshot["identities_bound"] and snapshot["errors"] == []
          and snapshot["last_census_observation"]["unknown_pids"] == []
          and snapshot["debug_events_received"] == snapshot["debug_events_continued"], label)
for identity, row in before_rows.items():
    final = after_rows[identity]
    check("original identity retained before execution",
          row["retained_before_first_instruction"] and row["identity_bound_before_first_continue"]
          and row["image"] == final["image"] and row["command_line"] == final["command_line"], str(identity))
    if row["is_master"]:
        check("master cleanup 125 is not natural terminal",
              row["exit_code"] is None and not row["original_signaled"]
              and final["exit_code"] == final["exit_event_code"] == 125
              and not final["natural_terminal_before_cleanup"] and final["original_signaled"],
              f"{ssh_arc}!ssh-debug-cleanup.json")
    else:
        check("non-master exact natural terminal preserved",
              row["natural_terminal_before_cleanup"] and row["original_signaled"]
              and row["exit_event_received"] and row["exit_event_continued"]
              and row["exit_code"] == row["exit_event_code"] == final["exit_code"]
              and final["natural_terminal_before_cleanup"], str(identity))
check("non-master natural exit distribution", Counter(a["exit_code"] for a in before_rows.values()
      if not a["is_master"]) == Counter({0: 14, 255: 5, 1: 1}), ssh_arc)
check("owned sshd observed exit remains null",
      next(c for c in windows["44026933475"]["children"] if c["label"] == "owned-sshd")["observed_exit"] is None,
      ssh_arc)
windows["44026933475"]["originals"] = {"seal": before, "cleanup": after}
for name in ["ssh-debug-originals.json", "ssh-debug-cleanup.json"]:
    cite(ssh_arc, name, lambda n, l: n < 32 or any(s in l for s in [
        '"state":', '"exit_code": 255', '"exit_code": 1', '"natural_terminal_before_cleanup": false',
        '"job_total_processes":', '"job_active_processes":', '"pending_process_objects":',
        '"owned_handles_remaining":', '"closed":']))
material = json.loads(ssh_members["ssh-cleanup.json"])
check("SSH private material cleanup", material["temporary_directory_removed"]
      and not material["private_config_uploaded"] and not material["keys_uploaded"], ssh_arc)
rust_client = json.loads(ssh_members["rust-client.json"])
check("Rust live assertions and disconnect", rust_client["status"] == "PASS"
      and rust_client["errors"] == [] and len(rust_client["assertion_evidence"]) == 22
      and all(a["passed"] for a in rust_client["assertion_evidence"])
      and rust_client["disconnect"]["local_transport_closed"]
      and rust_client["independent_oracle_status"] == "NOT_RUN_BY_RUST", ssh_arc)

# Rebuild production bytes ourselves from Git objects; never import or run lab code.
win_dir = "crates/keelshell-session/src/monitor/windows/"
production = blob("crates/keelshell-session/src/monitor/windows.rs").decode()
prefix = json.loads(re.search(r'const COMMAND_PREFIX: &str = (".*");', production)[1])
suffix = json.loads(re.search(r'const SUFFIX: &str = (".*");', production)[1])
common = blob(win_dir + "common.ps1")
mapping = {}
for op in ["probe", "resources", "resources-skipped", "processes", "sockets"]:
    operation = "resources" if op == "resources-skipped" else op
    literal = f"$op='{operation}';$skip=${'true' if op == 'resources-skipped' else 'false'};\n"
    check("literal operation prefix present in exact Rust source", json.dumps(literal) in production, op)
    body = blob(win_dir + operation + ".ps1")
    script = literal.encode() + common + body + suffix.encode()
    wire = prefix.encode() + base64.b64encode(script.decode().encode("utf-16le"))
    check("production wire ASCII within fixed limit", wire.isascii() and len(wire) < 8000, op)
    mapping[op] = {"script": script, "wire": wire}
    for aid in [14304130642, 14303232465]:
        arc = f"downloads/artifact-{aid}.zip"
        assembly = json.loads(archives[arc][op + ".assembly.json"])
        check("assembly bytes/digests/parts match exact f910",
              assembly["literal_prefix"] == literal and assembly["literal_suffix"] == suffix
              and assembly["parts"] == [{"file": "common.ps1", "sha256": digest(common)},
                                       {"file": operation + ".ps1", "sha256": digest(body)}]
              and assembly["script_sha256"] == digest(script) and assembly["wire_command_sha256"] == digest(wire)
              and assembly["wire_command_ascii_bytes"] == len(wire), f"{arc}!{op}.assembly.json")
    api_members = archives["downloads/artifact-14304130642.zip"]
    child = json.loads(api_members[op + ".receipt.json"])
    shell = child["shell_execution"]
    check("direct actual wire bytes and shell argv exact",
          api_members[op + ".wire.txt"] == wire and shell["argv"][-1].encode() == wire
          and shell["complete_original_object_census"]
          and shell["job_total_processes"] == child["terminal"]["native_process_objects"]["retained_processes"],
          op)
    for original in shell["powershell_original_objects"]:
        check("direct original PowerShell natural exit0", original["exit_code"] == 0
              and original["retained_while_live"] and original["natural_terminal_before_cleanup"], op)
ssh_bound = []
for row in before_rows.values():
    if not row["image"].lower().endswith("\\powershell.exe"):
        continue
    args = re.search(r" +(-NoLogo -NoProfile -NonInteractive -EncodedCommand [A-Za-z0-9+/]+=*)$", row["command_line"])
    wire = b"powershell.exe " + args[1].encode() if args else b""
    matches = [op for op, value in mapping.items() if value["wire"] == wire]
    check("SSH original process production argument bytes exact", len(matches) == 1
          and row["exit_code"] == 0, f"{ssh_arc}!ssh-debug-originals.json pid={row['pid']}")
    if matches:
        ssh_bound.append({"operation": matches[0], "pid": row["pid"], "creation_time": row["creation_time"],
                          "exit_code": 0, "wire_sha256": digest(wire)})
binding = json.loads(ssh_members["ssh-production-binding.json"])
check("SSH four production operations independently rebound",
      sorted(ssh_bound, key=lambda x: x["operation"]) == sorted(binding["operations"], key=lambda x: x["operation"])
      and sorted(x["operation"] for x in ssh_bound) == ["probe", "processes", "resources", "sockets"], ssh_arc)

for name in ["scripts/check.py", ".github/actions/setup-build/action.yml", "scripts/openssh_interop.py",
             "scripts/windows_monitor_lab.py", "scripts/windows_monitor_ssh.py", "scripts/windows_monitor/ssh.py",
             "scripts/windows_monitor/debug_job.py", "crates/keelshell-session/tests/windows_openssh_monitor.rs",
             "crates/keelshell-session/tests/windows_monitor.rs", win_dir + "ASSEMBLY.md"]:
    blob(name)
head_after = git("rev-parse", "HEAD").decode().strip()
status_after = git("status", "--porcelain=v1", "--untracked-files=no").decode()
save("scope.json", {"started_utc": started, "finished_utc": datetime.now(timezone.utc).isoformat(),
                   "engineering_sha": SHA, "head_before": baseline["head"], "head_after": head_after,
                   "tracked_status_before": baseline["status"], "tracked_status_after": status_after,
                   "head_equal": baseline["head"] == head_after,
                   "status_equal": baseline["status"] == status_after,
                   "product_executions": 0, "network_commands": 0, "cargo_commands": 0,
                   "target_operations": 0, "gui_operations": 0, "git_mutations": 0,
                   "allowed_output_directory": str(OUT)})
check("collection final digest equals initial baseline",
      baseline["files"] == {n: {"bytes": p.stat().st_size, "sha256": digest(p.read_bytes())}
                            for n, p in sorted(files.items())}, "baseline.json")
save("zip-members.json", zip_manifest)
save("inventories.json", inventories)
save("api.json", api)
save("interop.json", interop)
save("windows.json", windows)
save("source-bindings.json", {"inputs": source_bindings, "production": [
    {"operation": op, "script_sha256": digest(v["script"]), "wire_sha256": digest(v["wire"]),
     "wire_bytes": len(v["wire"])} for op, v in mapping.items()],
    "git_blobs": [{"object": name, "bytes": len(data), "sha256": digest(data)} for name, data in sources.items()],
    "ssh_original_bindings": ssh_bound})
(OUT / "evidence.txt").write_text("\n".join(evidence) + "\n")
save("commands.json", commands)
save("checks.json", checks)
result = {"sha": SHA, "checks": len(checks), "passed": sum(x["pass"] for x in checks),
          "failed": sum(not x["pass"] for x in checks), "git_commands": len(commands),
          "git_exit_codes": dict(Counter(c["exit"] for c in commands)), "quality": quality,
          "raw_files": len(files), "checksum_entries": len(sums),
          "zip_count": len(zip_manifest), "zip_members": sum(len(x["members"]) for x in zip_manifest),
          "rust_main_named": sum(sum(len(s["names"]) for s in inventories[p]["rust"] if not s["doctest"]) for p in quality),
          "rust_doctest_named": sum(sum(len(s["names"]) for s in inventories[p]["rust"] if s["doctest"]) for p in quality)}
save("verification.json", result)
print(json.dumps(result, indent=2))
print("FAILED:", json.dumps([c for c in checks if not c["pass"]], ensure_ascii=False))
raise SystemExit(1 if result["failed"] else 0)
