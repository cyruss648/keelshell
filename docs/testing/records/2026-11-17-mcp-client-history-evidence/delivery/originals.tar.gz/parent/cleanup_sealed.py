"""Delete only task-owned copies exactly equal to committed archive members."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[2]
ALLOWED = {
    "work/mcp-external-workflow-20261117",
    "work/mcp-client-history-review-20261117",
    "work/tunnel-ci-completion-20261117",
    "work/tunnel-ci-final-review-20261117",
    "work/mcp-client-delivery-20261117",
    "work/mcp-native-finish-review-20261117",
    "work/mcp-client-native-20261117/runtime-r1",
}
TARGET = ROOT / "work/recovery-batch-integration-20261115/target"
PACKAGES = [
    ROOT / "work/windows-monitor-delivery-20261117/package-r2",
    ROOT / "work/mcp-client-native-20261117/package-r1",
]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git_blob(commit, path):
    return subprocess.check_output(
        ["git", "show", f"{commit}:{path}"], cwd=ROOT, timeout=30
    )


def protected():
    stat = TARGET.stat()
    return {
        "target": {"device": stat.st_dev, "inode": stat.st_ino},
        "normal_packages": {
            package.relative_to(ROOT).as_posix(): {
                path.relative_to(package).as_posix(): sha(path.read_bytes())
                for path in sorted(package.rglob("*")) if path.is_file()
            } for package in PACKAGES
        },
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--commit", required=True)
    parser.add_argument("--archive-directory", required=True)
    parser.add_argument("--owned-directory", action="append", required=True)
    parser.add_argument("--receipt", required=True)
    args = parser.parse_args()
    assert set(args.owned_directory) <= ALLOWED
    assert len(args.owned_directory) == len(set(args.owned_directory))
    receipt = ROOT / args.receipt
    assert receipt.parent == Path(__file__).resolve().parent
    assert not receipt.exists()
    directory = args.archive_directory
    manifest_raw = git_blob(args.commit, f"{directory}/manifest.json")
    archive_raw = git_blob(args.commit, f"{directory}/originals.tar.gz")
    assert manifest_raw == (ROOT / directory / "manifest.json").read_bytes()
    assert archive_raw == (ROOT / directory / "originals.tar.gz").read_bytes()
    manifest = json.loads(manifest_raw)
    assert sha(archive_raw) == manifest["sha256"]
    assert len(archive_raw) == manifest["bytes"]
    rows = {row["member"]: row for row in manifest["files"]}
    assert len(rows) == manifest["members"]
    content = {}
    with tarfile.open(fileobj=io.BytesIO(archive_raw)) as archive:
        members = archive.getmembers()
        assert len(members) == len(rows)
        assert {member.name for member in members} == set(rows)
        for member in members:
            assert member.isfile()
            raw = archive.extractfile(member).read()
            row = rows[member.name]
            assert len(raw) == row["bytes"] and sha(raw) == row["sha256"]
            content[row["source"]] = raw
    before = protected()
    inventory = []
    for source in args.owned_directory:
        root = ROOT / source
        assert root.is_dir() and not root.is_symlink()
        assert root.parent == ROOT / "work" or source == "work/mcp-client-native-20261117/runtime-r1"
        expected = {name: raw for name, raw in content.items()
                    if name.startswith(source + "/")}
        assert expected
        descendants = list(root.rglob("*"))
        assert not any(path.is_symlink() for path in descendants)
        actual = {path.relative_to(ROOT).as_posix(): path
                  for path in descendants if path.is_file()}
        assert set(actual) == set(expected), {
            "directory": source,
            "unexpected": sorted(set(actual) - set(expected)),
            "missing": sorted(set(expected) - set(actual)),
        }
        for name, path in actual.items():
            assert path.read_bytes() == expected[name], name
        inventory.append({
            "directory": source, "files": len(actual),
            "logical_bytes": sum(len(raw) for raw in expected.values()),
        })
    for source in args.owned_directory:
        shutil.rmtree(ROOT / source)
        assert not (ROOT / source).exists()
    after = protected()
    assert before == after
    result = {
        "archive_commit": args.commit, "archive_directory": directory,
        "archive_sha256": manifest["sha256"],
        "all_copy_file_sets_and_bytes_equal": True,
        "deleted": inventory,
        "files": sum(row["files"] for row in inventory),
        "logical_bytes": sum(row["logical_bytes"] for row in inventory),
        "protected_before": before, "protected_after": after,
        "boundary": "Logical file lengths, not physical disk reclamation. Unique target and normal old package retained unchanged.",
    }
    with receipt.open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
