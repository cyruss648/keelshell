"""Run only this task's isolated normal package and record actual exit."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
STAGE = ROOT / "work/mcp-client-native-20261117/package-r1"
RUNTIME = ROOT / "work/mcp-client-native-20261117/runtime-r1"
EXECUTABLE = STAGE / "KeelShell.app/Contents/MacOS/keelshell-app"
SOURCE = "f910e0013832643f09b112b08443675a956d5551"
manifest = json.loads((STAGE / "package-manifest.json").read_text())
assert manifest["build"]["commit"] == SOURCE
assert hashlib.sha256(EXECUTABLE.read_bytes()).hexdigest() == manifest["binary_sha256"]
assert not RUNTIME.exists()
RUNTIME.mkdir(parents=True)
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
clock = time.monotonic()
with (BASE / "native-app.log").open("xb") as output:
    process = subprocess.Popen(
        [str(EXECUTABLE)], cwd=RUNTIME,
        env=dict(os.environ, KEELSHELL_DATA_DIR=str(RUNTIME)),
        stdout=output, stderr=subprocess.STDOUT, start_new_session=True,
    )
    start = {
        "source": SOURCE, "pid": process.pid, "executable": str(EXECUTABLE),
        "runtime": str(RUNTIME), "started_at_utc": started,
        "binary_sha256": manifest["binary_sha256"],
        "isolated_empty_runtime": True, "installed": False,
    }
    with (BASE / "native-app-start.json").open("x") as stream:
        json.dump(start, stream, indent=2)
        stream.write("\n")
    print(json.dumps(start), flush=True)
    timed_out = False
    try:
        code = process.wait(timeout=1200)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            code = process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            code = process.wait(timeout=5)
result = {
    **start, "exit_code": code, "timed_out": timed_out, "reaped": True,
    "duration_seconds": round(time.monotonic() - clock, 6),
    "completed_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
}
with (BASE / "native-app-result.json").open("x") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
print(json.dumps(result), flush=True)
