ship — APPROVE，仅批准所供 11 张原生截图、配对 AX 与正常包/原进程回执所覆盖的可见子集。

本次为新非作者独立只读复核。P0=0、P1=0、P2=0、P3=0，未发现该可见子集的新增确定产品缺陷。完整 native finish 和发行均未授予。结论不扩大到源码正确性、CI、777 工程输入或未发生的原生动作。

精确源码 `f910e0013832643f09b112b08443675a956d5551`；应用 SHA-256 `70045d6ff4f278a8a9df8bea075dcaa6bb65b3304895924101af588c90c2f110`。已读 AGENTS、RTK、`docs/design/HALLMARK_NATIVE.md` 和交接约束；采用 Product Design audit 的原图逐张检查及证据边界规则。仅使用用户指定原件，未另取 UI 或网络证据。

| 原图步骤 | 实际可见界面 | 独立观察 | 健康度 |
| --- | --- | --- | --- |
| 01 | Frost System（实际暗色）/ 中文工作区 | 快速连接与空连接库可读，0/0 连接、无活动 SSH；顶部入口及底部 MCP 完整。 | 通过（限定可见） |
| 02 | Frost System（实际暗色）/ 中文 MCP | 无活动 SSH、提案(0)、空授权列表；Codex 有选中底色，模板及固定栏能力按钮呈禁用，关闭动作完整。 | 通过（限定可见） |
| 03 | Frost Light / English MCP | 说明正文完整换行；No active SSH session、Action proposals (0) 可读；Claude 有选中底色，底部动作完整。 | 通过（限定可见） |
| 04 | Frost Light / English MCP + Tab 轮廓 | Codex 有选中底色；右上关闭按钮存在完整焦点轮廓，未被裁切；其余空授权布局与图03一致。 | 通过（限定可见） |
| 05 | Frost Light / English themes | 三张主题卡及 Frost Light / Graphite Dark / Lavender Light 推荐值可读；当前 Frost 和 Applied Light 明确；Done 完整。 | 通过（限定可见） |
| 06 | Graphite Dark / English MCP | 暖深色背景上正文和零计数可读；Codex 有选中底色；禁用动作及固定底栏完整，单层模态外背景隔离。 | 通过（限定可见） |
| 07 | Graphite Dark / 中文 MCP | 中文说明、无活动 SSH、提案(0) 可读；Claude 有选中底色；关闭、授权和复制固定栏未裁切。 | 通过（限定可见） |
| 08 | Lavender Light / 中文 MCP | 浅紫表面及文字可辨；无活动 SSH、提案(0)；Claude 有显式紫色选中底色，底部动作完整。 | 通过（限定可见） |
| 09 | Lavender Light / English MCP | 英文长说明完整换行，零 SSH 和提案可读；Codex 有紫色选中底色；固定动作未裁切。 | 通过（限定可见） |
| 10 | Frost Light / 中文 MCP | 中文空授权页可读，Codex 有选中底色，提案(0) 与无活动 SSH 明确；模板、临时启动配置及授权为禁用外观。 | 通过（限定可见） |
| 11 | Frost Light / 中文关闭审核 | 唯一关闭审核显示 0 SSH / 0 文件草稿快照；警示正文、取消及红色确认关闭完整；背景没有 MCP 第二模态。 | 通过（限定可见） |

六个推荐组合由图03/04（Frost Light英文）、10（Frost Light中文）、06（Graphite Dark英文）、07（Graphite Dark中文）、08（Lavender Light中文）、09（Lavender Light英文）覆盖。正文和客户端说明正常换行，当前截图几何中关闭/撤销、复制和授权固定栏均完整。图05独立显示三家族与推荐外观；运行原件的8个备份及最终state也保留六组合。仅代表所拍几何，不能推定最小或紧凑尺寸通过。

图03 Claude 与图04 Codex、图07/08 Claude 与图09/10 Codex均有明确选中底色。AX中客户端只有普通按钮，没有 selected/toggle 值；中英文MCP AX各自跨主题/客户端完全相同。因此客户端选择、主题外观、正文零计数和图04关闭按钮轮廓按实际截图签署，不声称AX已表达这些状态。11份AX的 focused element全部仍是窗口。

11份AX均恰有1个标准窗口。图01含“工作区窗口，1”、空连接库；另10份各恰有1个 `keelshell.active-modal`，无工作区工具栏、SSH导航或连接列表后台节点。截图也只有一层当前模态和隔离背景。该证据支持所供原件的结构/视觉隔离，不证明全桌面窗口普查、后台事件拦截、完整焦点陷阱或辅助技术可用性。

8份MCP AX逐项核对13个禁用动作，共104个 disabled 状态：8种能力、捕获当前文本、清理历史、复制模板、复制临时启动配置及授权。空授权截图均无活动SSH且提案为0；图11关闭审核显示0 SSH/0文件草稿快照。正文这些文字不在AX中，依据原图观察。**复制模板因未授权始终disabled，native复制成功未验；没有未知动作modal的原生执行。**

| 身份/回执 | 独立复核结果 |
| --- | --- |
| source → package → start → result | observations、manifest、start、result均为精确f910e001；本地commit对象只读解析相同。777输入/Git相等及已推送为用户交接事实，本次不重复也不联网验证。 |
| 正常包 | 实际package-r1恰6文件，全部字节数和SHA-256与observations相等；5个应用文件也与manifest相等，实际包manifest与交付manifest逐字节摘要相等。没有执行包内文件。 |
| 正常release build | 父级现有receipt：exit0、reaped=true、未超时，219.335732秒；本次没有构建。receipt无独立source字段，源码归属承接manifest和用户冻结交接。 |
| 正常结构检查 | 父级现有receipt：exit0、reaped=true，0.136847秒；原command.log给出aarch64-apple-darwin、GUI/MCP各minos15.0，明确GUI验收另计；本次没有重跑检查。 |
| 原进程启动/退出 | PID34098、精确work包路径、独立runtime和binarySHA一致；start全部字段保留到result，observations.native_process与result完全相等。 |
| 原进程终态 | 2026-11-17 06:02:24.750654–06:08:05.316898 UTC，exit0、reaped=true、timed_out=false，记录340.564409秒；原app.log为0字节。仅检查封存回执，未再启动或CUA读取。 |
| 无安装 | 包/启动/结果均installed=false，启动路径为work下正常包；本次安装/启动0。签名、公证、发行未验。 |
| 运行原件 | 最终state+8份备份共9份JSON，连接、最近/删除连接、known_hosts等均空，AI关闭且无供应商profile；默认命令片段不代表实际执行。 |

首个stale AX34在capture05重编号后被拒、刷新7成功，保留为工装事实，产品失败=false。图05的AX独立可见当前7为Graphite且没有34；拒绝/成功过程来自父级native-observations叙述，本次没有重演或额外CUA日志。原图05未替换。

| 计数口径 | 实际数量 |
| --- | --- |
| `view_image`原图查看 | 11次 / 11张，均为原路径；工具显示预览自动缩放至1975×1280，未改动原JPEG |
| JPEG/AX摘要 | 11 JPEG SHA + 11 AX SHA全部相等；11个JPEG字节数相等 |
| JPEG尺寸 | 11/11直接解析SOF，原图均2880×1866；11个JPEG摘要互异 |
| AX读取 | 11份；唯一AX摘要5种，重复AX结构已明确其证明限制 |
| 正常包摘要 | 6/6文件一致，仅只读摘要 |
| 独立离线审计命令 | 2次：`python3 -B work/mcp-native-finish-review-20261117/audit.py`；r1回执见audit-r1.json，r2进程回执见audit-command.json |
| 本地Git身份命令 | 1次rev-parse，只读，exit0；远端命令0 |
| 最终r2证据谓词检查 | 347项，347通过，0失败，0跳过；逐项见review-result.json |
| 首轮r1及累计 | r1为348项/347通过/1工装清单失败；两轮累计695次谓词求值，694通过，1失败求值；原失败保留且已修正，不合并为产品测试数量 |
| 原件不变性 | 审计前后46个指定输入文件摘要相等；不扫描或改写并行docs/CI或target |
| 产品执行 | 产品测试0、Cargo/rustc0、UI操作0、CUA读取0、应用启动0、网络命令0、安装0、子agent0、清理/提交/推送0 |

| 审计谓词分组（非产品测试） | 数量 |
| --- | --- |
| inventory | 6 |
| captures | 55 |
| ax | 63 |
| disabled_controls | 104 |
| identity | 13 |
| package | 18 |
| receipts | 20 |
| runtime | 21 |
| tooling | 1 |
| immutability | 46 |

实际准备/阅读用了7次shell工具调用（第2次目录清单因尚不存在的复核输出目录返回2，其余6次为0），首轮诊断/工装原件归档2次，审计执行2次，最终报告/JSON读回1次，合计12次shell工具调用；逐次exit记录在audit-command.json。11次view_image另列。首轮审计348项中唯一失败是工装把辅助captures.json也列入“恰22张原件”的目录条件；11对图/AX、包及进程检查均已通过。按用户指定11 JPG+11 AX限定清单后修正；未删除/修改captures.json，首轮脚本、报告、结果和exit1已完整保存在audit-r1.json。该目录辅助条目及工装错误不是产品失败。不把阅读、脚本检查或父级成绩计作独立产品测试。

未验边界：

- 复制模板在未授权状态始终 disabled；native 复制成功未验。
- 未知动作核对 modal、完整命令/文件变更及未知结果执行/核对流程未验。
- 最小/紧凑尺寸、其他几何、多窗口及完整主题明暗矩阵未验。
- 真实 SSH、供应商配置加载/业务请求、外部客户端连接未验。
- AX 不含正文零计数、客户端 selected 状态或按钮级焦点；只签截图可见事实。
- 完整键盘焦点循环/陷阱、IME、VoiceOver、辅助技术和对比度规范验收未验。
- Windows/Linux 原生、安装、签名、公证和发行未验。
- 不重新编译、重放产品测试、复算777工程输入或联网验证远端推送；后两项沿用用户交接。
- build result没有独立source字段；source绑定来自包manifest及用户冻结交接，不能据此独立重建构建因果链。
- 封存AX只证明所供树中的单窗口/单模态及后台控件隐藏；不代替全桌面窗口普查或事件隔离测试。
- 原 native-app.log 为0字节，不能据此推断所有后台行为或无网络流量。

建议：可接收本批可见子集的原件复核，完整产品/原生/辅助技术及发布状态继续分别验收。报告及工装只写入 `work/mcp-native-finish-review-20261117/`，没有实施修复或变更父级材料。

原图证据按步骤附下（引用父级原路径，不复制、不修改）：

01. Frost System（实际暗色）/ 中文工作区 — 通过（限定可见）。

![01 original](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-client-delivery-20261117/native-captures/01-frost-system-zh-workspace.jpg)

02. Frost System（实际暗色）/ 中文 MCP — 通过（限定可见）。

![02 original](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-client-delivery-20261117/native-captures/02-frost-system-zh-mcp.jpg)

03. Frost Light / English MCP — 通过（限定可见）。

![03 original](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-client-delivery-20261117/native-captures/03-frost-light-en-claude-mcp.jpg)

04. Frost Light / English MCP + Tab 轮廓 — 通过（限定可见）。

![04 original](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-client-delivery-20261117/native-captures/04-frost-light-en-codex-focus.jpg)

05. Frost Light / English themes — 通过（限定可见）。

![05 original](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-client-delivery-20261117/native-captures/05-themes-en-registry.jpg)

06. Graphite Dark / English MCP — 通过（限定可见）。

![06 original](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-client-delivery-20261117/native-captures/06-graphite-dark-en-mcp.jpg)

07. Graphite Dark / 中文 MCP — 通过（限定可见）。

![07 original](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-client-delivery-20261117/native-captures/07-graphite-dark-zh-claude-mcp.jpg)

08. Lavender Light / 中文 MCP — 通过（限定可见）。

![08 original](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-client-delivery-20261117/native-captures/08-lavender-light-zh-mcp.jpg)

09. Lavender Light / English MCP — 通过（限定可见）。

![09 original](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-client-delivery-20261117/native-captures/09-lavender-light-en-codex-mcp.jpg)

10. Frost Light / 中文 MCP — 通过（限定可见）。

![10 original](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-client-delivery-20261117/native-captures/10-frost-light-zh-mcp.jpg)

11. Frost Light / 中文关闭审核 — 通过（限定可见）。

![11 original](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-client-delivery-20261117/native-captures/11-empty-window-close-review.jpg)
