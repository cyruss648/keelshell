#!/usr/bin/env python3
"""Offline receipt audit. Reads sealed inputs; writes only beside this script.

Visual notes below were recorded after eleven individual view_image calls.
No screenshot rendering, UI automation, product execution, or network access
occurs here. Check counts are evidence predicates, never product test counts.
"""

from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import struct
import sys


OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
INPUT = ROOT / "work/mcp-client-delivery-20261117"
CAPTURES = INPUT / "native-captures"
PACKAGE = ROOT / "work/mcp-client-native-20261117/package-r1"
SOURCE = "f910e0013832643f09b112b08443675a956d5551"
APP_SHA = "70045d6ff4f278a8a9df8bea075dcaa6bb65b3304895924101af588c90c2f110"

# Human visual evidence, not assertions generated from filenames or AX text.
VISUAL = [
    (1, "Frost System（实际暗色）/ 中文工作区",
     "快速连接与空连接库可读，0/0 连接、无活动 SSH；顶部入口及底部 MCP 完整。", None),
    (2, "Frost System（实际暗色）/ 中文 MCP",
     "无活动 SSH、提案(0)、空授权列表；Codex 有选中底色，模板及固定栏能力按钮呈禁用，关闭动作完整。", "Codex CLI"),
    (3, "Frost Light / English MCP",
     "说明正文完整换行；No active SSH session、Action proposals (0) 可读；Claude 有选中底色，底部动作完整。", "Claude Code"),
    (4, "Frost Light / English MCP + Tab 轮廓",
     "Codex 有选中底色；右上关闭按钮存在完整焦点轮廓，未被裁切；其余空授权布局与图03一致。", "Codex CLI"),
    (5, "Frost Light / English themes",
     "三张主题卡及 Frost Light / Graphite Dark / Lavender Light 推荐值可读；当前 Frost 和 Applied Light 明确；Done 完整。", None),
    (6, "Graphite Dark / English MCP",
     "暖深色背景上正文和零计数可读；Codex 有选中底色；禁用动作及固定底栏完整，单层模态外背景隔离。", "Codex CLI"),
    (7, "Graphite Dark / 中文 MCP",
     "中文说明、无活动 SSH、提案(0) 可读；Claude 有选中底色；关闭、授权和复制固定栏未裁切。", "Claude Code"),
    (8, "Lavender Light / 中文 MCP",
     "浅紫表面及文字可辨；无活动 SSH、提案(0)；Claude 有显式紫色选中底色，底部动作完整。", "Claude Code"),
    (9, "Lavender Light / English MCP",
     "英文长说明完整换行，零 SSH 和提案可读；Codex 有紫色选中底色；固定动作未裁切。", "Codex CLI"),
    (10, "Frost Light / 中文 MCP",
     "中文空授权页可读，Codex 有选中底色，提案(0) 与无活动 SSH 明确；模板、临时启动配置及授权为禁用外观。", "Codex CLI"),
    (11, "Frost Light / 中文关闭审核",
     "唯一关闭审核显示 0 SSH / 0 文件草稿快照；警示正文、取消及红色确认关闭完整；背景没有 MCP 第二模态。", None),
]


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load(path):
    return json.loads(path.read_text())


def jpeg_size(raw):
    """Read JPEG frame metadata directly without decoding or modifying pixels."""
    if raw[:2] != b"\xff\xd8" or raw[-2:] != b"\xff\xd9":
        raise ValueError("missing JPEG SOI/EOI")
    offset = 2
    frames = {0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7,
              0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF}
    while offset < len(raw):
        if raw[offset] != 0xFF:
            raise ValueError("invalid pre-scan JPEG marker")
        while offset < len(raw) and raw[offset] == 0xFF:
            offset += 1
        marker = raw[offset]
        offset += 1
        if marker in {0x01, 0xD8} or 0xD0 <= marker <= 0xD7:
            continue
        length = struct.unpack_from(">H", raw, offset)[0]
        if length < 2 or offset + length > len(raw):
            raise ValueError("invalid JPEG segment length")
        if marker in frames:
            height, width = struct.unpack_from(">HH", raw, offset + 3)
            return width, height
        if marker in {0xDA, 0xD9}:
            break
        offset += length
    raise ValueError("JPEG frame not found")


def snapshot(paths):
    result = {}
    for path in paths:
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"expected original regular file: {path}")
        result[str(path.relative_to(ROOT))] = {
            "bytes": path.stat().st_size,
            "sha256": sha(path),
        }
    return result


checks = []


def check(group, label, condition, evidence=None):
    entry = {"group": group, "check": label, "passed": bool(condition)}
    if evidence is not None:
        entry["evidence"] = evidence
    checks.append(entry)


def receipt_ok(name, receipt):
    check("receipts", name + " exit0", receipt.get("exit_code") == 0)
    check("receipts", name + " reaped", receipt.get("reaped") is True)
    check("receipts", name + " not timed out", receipt.get("timed_out") is False)
    check("receipts", name + " bounded positive duration",
          0 < receipt.get("duration_seconds", 0) < 600)


obs = load(INPUT / "native-observations.json")
fixed_inputs = [
    INPUT / name for name in (
        "native-observations.json", "normal-package-manifest.json",
        "normal-release-build-r1/result.json",
        "normal-native-structure-r1/result.json",
        "normal-native-structure-r1/command.log",
        "native-app-start.json", "native-app-result.json", "native-app.log",
    )
]
capture_paths = sorted(
    path for path in CAPTURES.iterdir()
    if path.suffix.lower() == ".jpg" or path.name.endswith(".ax.txt")
)
auxiliary_capture_entries = sorted(
    path.name for path in CAPTURES.iterdir() if path not in capture_paths
)
runtime_paths = sorted(path for path in (INPUT / "native-runtime-originals").rglob("*")
                       if path.is_file())
package_paths = sorted(path for path in PACKAGE.rglob("*") if path.is_file())
all_paths = fixed_inputs + capture_paths + runtime_paths + package_paths
before = snapshot(all_paths)

check("inventory", "exactly eleven listed captures", len(obs["images"]) == 11)
check("inventory", "exactly eleven JPEG files", len(list(CAPTURES.glob("*.jpg"))) == 11)
check("inventory", "exactly eleven AX files", len(list(CAPTURES.glob("*.ax.txt"))) == 11)
listed = {entry[key] for entry in obs["images"] for key in ("image", "ax")}
check("inventory", "JPEG and AX inventory exactly matches listed 22 files",
      {path.name for path in capture_paths} == listed)
check("inventory", "normal package exactly six listed files",
      {str(path.relative_to(PACKAGE)) for path in package_paths}
      == set(obs["package_files"]) and len(package_paths) == 6)

capture_results = []
ax_texts = {}
mcp_ids = {2, 3, 4, 6, 7, 8, 9, 10}
disabled_zh = [
    "枚举此会话", "读取明确选区", "列出授权目录", "读取常规 UTF-8 文件",
    "读取监控缓存", "提交待审命令", "提交待审文件修改", "查询提案状态",
    "捕获当前所选文本", "清除已处理记录", "复制配置模板",
    "复制临时启动配置", "授权此会话",
]
disabled_en = [
    "List this session", "Read selected fragment", "List granted directory",
    "Read regular UTF-8 files", "Read monitor cache", "Propose commands",
    "Propose file changes", "Read proposal status", "Capture selected terminal text",
    "Clear finished records", "Copy configuration template",
    "Copy temporary launch settings", "Grant this session",
]
for number, item in enumerate(obs["images"], 1):
    image = CAPTURES / item["image"]
    ax_path = CAPTURES / item["ax"]
    text = ax_path.read_text()
    ax_texts[number] = text
    width, height = jpeg_size(image.read_bytes())
    nodes = [line.strip() for line in text.splitlines()
             if re.match(r"^\s*\d+ ", line)]
    windows = [line for line in nodes if re.match(r"^\d+ 标准窗口 ", line)]
    modals = [line for line in nodes if "ID: keelshell.active-modal" in line]
    dialogs = [line for line in nodes if re.match(r"^\d+ 对话框 ", line)]
    check("captures", f"{number:02} filename AX pair",
          image.stem + ".ax.txt" == ax_path.name
          and image.name.startswith(f"{number:02}-"))
    check("captures", f"{number:02} JPEG bytes", image.stat().st_size == item["bytes"])
    check("captures", f"{number:02} JPEG sha256", sha(image) == item["sha256"])
    check("captures", f"{number:02} AX sha256", sha(ax_path) == item["ax_sha256"])
    check("captures", f"{number:02} JPEG frame dimensions",
          (width, height) == (item["pixel_dimensions"]["width"],
                              item["pixel_dimensions"]["height"]) == (2880, 1866))
    check("ax", f"{number:02} exactly one standard window", len(windows) == 1)
    check("ax", f"{number:02} active modal cardinality",
          len(modals) == len(dialogs) == (0 if number == 1 else 1))
    check("ax", f"{number:02} reported focus is window",
          "The focused UI element is 0 标准窗口 KeelShell" in text)
    if number != 1:
        check("ax", f"{number:02} background workspace controls absent",
              not any(token in text for token in (
                  "工作区工具栏", "Workspace toolbar", "SSH 会话导航",
                  "SSH session navigation", "连接列表", "Connection list")))
    if number in mcp_ids:
        language = "en" if "External MCP grants and review" in text else "zh-CN"
        labels = disabled_en if language == "en" else disabled_zh
        for label in labels:
            check("disabled_controls", f"{number:02} {label}",
                  any(re.fullmatch(r"\d+ 按钮 \(disabled\) " + re.escape(label),
                                   node) for node in nodes))
        for label in ("Codex CLI", "Claude Code"):
            check("ax", f"{number:02} plain client button {label}",
                  any(re.fullmatch(r"\d+ 按钮 " + re.escape(label), node)
                      for node in nodes))
    visual = VISUAL[number - 1]
    capture_results.append({
        "number": number, "image": str(image.relative_to(ROOT)),
        "ax": str(ax_path.relative_to(ROOT)), "jpeg_bytes": image.stat().st_size,
        "jpeg_sha256": sha(image), "ax_sha256": sha(ax_path),
        "width": width, "height": height,
        "window_count_in_supplied_ax": len(windows),
        "active_modal_count_in_supplied_ax": len(modals),
        "ax_line_count": len(text.splitlines()),
        "view_image_inspected": True, "visual_surface": visual[1],
        "visual_notes": visual[2], "visible_selected_client": visual[3],
        "health": "PASS_SCOPED_VISIBLE",
    })
check("inventory", "eleven distinct JPEG digests",
      len({entry["jpeg_sha256"] for entry in capture_results}) == 11)
check("ax", "workspace snapshot names one workspace window",
      "工作区窗口，1" in ax_texts[1])
check("ax", "capture05 refreshed Graphite index7",
      "\t\t7 按钮 Graphite · Recommended appearance：Dark · Apply · Dark" in ax_texts[5])
check("ax", "capture05 no index34",
      not re.search(r"^\s*34 ", ax_texts[5], re.M))
check("ax", "close review has named cancel and confirm",
      "6 按钮 取消" in ax_texts[11] and "7 按钮 确认关闭" in ax_texts[11])

manifest = load(INPUT / "normal-package-manifest.json")
start = load(INPUT / "native-app-start.json")
finish = load(INPUT / "native-app-result.json")
build = load(INPUT / "normal-release-build-r1/result.json")
structure = load(INPUT / "normal-native-structure-r1/result.json")
structure_log = (INPUT / "normal-native-structure-r1/command.log").read_text()
for name, value in (
    ("observations", obs["source"]), ("manifest", manifest["build"]["commit"]),
    ("start", start["source"]), ("result", finish["source"]),
):
    check("identity", f"{name} source exact", value == SOURCE)
check("identity", "manifest target macos arm64",
      manifest["platform"] == "macos"
      and manifest["target"] == "aarch64-apple-darwin")
for rel, expected in obs["package_files"].items():
    actual = before[str((PACKAGE / rel).relative_to(ROOT))]
    check("package", rel + " bytes", actual["bytes"] == expected["bytes"])
    check("package", rel + " SHA256", actual["sha256"] == expected["sha256"])
for rel, expected in manifest["files"].items():
    check("package", rel + " manifest SHA256",
          before[str((PACKAGE / rel).relative_to(ROOT))]["sha256"] == expected)
check("package", "delivered manifest equals actual package manifest",
      sha(INPUT / "normal-package-manifest.json") == sha(PACKAGE / "package-manifest.json"))
check("identity", "app hash exact across package and receipts",
      manifest["binary_sha256"] == start["binary_sha256"]
      == finish["binary_sha256"] == APP_SHA
      == obs["package_files"]["KeelShell.app/Contents/MacOS/keelshell-app"]["sha256"])
check("identity", "all start fields survive unchanged in result",
      all(finish.get(key) == value for key, value in start.items()))
check("identity", "observed native process equals final receipt",
      obs["native_process"] == finish)
check("identity", "owned app PID consistent", start["pid"] == finish["pid"] == 34098)
check("identity", "launch uses exact normal work package",
      start["executable"] == str(PACKAGE / "KeelShell.app/Contents/MacOS/keelshell-app"))
check("identity", "isolated work runtime",
      start["runtime"] == str(ROOT / "work/mcp-client-native-20261117/runtime-r1")
      and start["isolated_empty_runtime"] is True)
check("identity", "no installation declared in package/start/result",
      manifest["installed"] is False and start["installed"] is False
      and finish["installed"] is False)
check("identity", "packaging does not claim native or signing acceptance",
      manifest["native_acceptance"] == "not performed by this script"
      and manifest["signed_by_packaging_script"] is False)
for name, receipt in (("normal release build", build),
                      ("native structure inspection", structure), ("native process", finish)):
    receipt_ok(name, receipt)
check("receipts", "normal release argv",
      build["argv"] == ["cargo", "build", "-p", "keelshell-app", "-p",
                        "keelshell-mcp", "--release", "--locked"])
check("receipts", "build/structure cwd exact",
      build["cwd"] == structure["cwd"] == str(ROOT))
check("receipts", "structure argv exact normal package",
      structure["argv"] == [
          "python3", "-B", "packaging/inspect_native.py", "--platform", "macos",
          "--target", "aarch64-apple-darwin", "--stage",
          "work/mcp-client-native-20261117/package-r1",
      ])
check("receipts", "sealed structure log states arm64 and separates GUI",
      "Native package structure inspected: aarch64-apple-darwin; GUI acceptance remains separate"
      in structure_log)
check("receipts", "sealed structure log reports two minos15",
      structure_log.count("minos 15.0") == 2)
dt = datetime.fromisoformat
check("receipts", "build then structure then original app",
      dt(build["completed_at_utc"]) <= dt(structure["started_at_utc"])
      <= dt(structure["completed_at_utc"]) <= dt(start["started_at_utc"])
      < dt(finish["completed_at_utc"]))
wall_seconds = (dt(finish["completed_at_utc"]) - dt(start["started_at_utc"])).total_seconds()
check("receipts", "app duration agrees with timestamps within 100ms",
      abs(wall_seconds - finish["duration_seconds"]) < 0.1)
check("receipts", "native-app log zero bytes", (INPUT / "native-app.log").stat().st_size == 0)

runtime_states = []
for path in runtime_paths:
    if path.suffix != ".json":
        continue
    obj = load(path)
    state = obj.get("state", obj)
    check("runtime", path.name + " empty connection metadata",
          all(not state[key] for key in (
              "connections", "folders", "connection_folders",
              "deleted_connections", "recent_connections", "known_hosts")))
    check("runtime", path.name + " no AI profile/enabled provider",
          state["settings"]["ai"]["enabled"] is False
          and state["settings"]["ai_profiles"]["profiles"] == [])
    settings = state["settings"]
    runtime_states.append({
        "path": str(path.relative_to(ROOT)), "sequence": obj.get("sequence"),
        "language": settings["language"], "theme_family": settings["theme_family"],
        "appearance": settings["theme"], "connection_count": len(state["connections"]),
    })
check("runtime", "nine state originals including eight backups", len(runtime_states) == 9)
recommended = {(family, appearance, language)
               for family, appearance in (
                   ("frost", "light"), ("graphite", "dark"), ("lavender", "light"))
               for language in ("zh-CN", "en")}
seen = {(state["theme_family"], state["appearance"], state["language"])
        for state in runtime_states}
check("runtime", "all six recommended bilingual combinations recorded",
      recommended <= seen)
check("runtime", "backups preserve sequences1 through8",
      sorted(state["sequence"] for state in runtime_states
             if state["sequence"] is not None) == list(range(1, 9)))
check("tooling", "stale AX failure retained as nonproduct event",
      len(obs["preserved_failures"]) == 1
      and obs["preserved_failures"][0]["product_failure"] is False
      and "stale ID34" in obs["preserved_failures"][0]["event"]
      and "ID7 succeeded" in obs["preserved_failures"][0]["event"])

after = snapshot(all_paths)
for rel, value in before.items():
    check("immutability", rel + " unchanged during offline audit",
          after.get(rel) == value)
failed = [entry for entry in checks if not entry["passed"]]
groups = Counter(entry["group"] for entry in checks)
limits = [
    "复制模板在未授权状态始终 disabled；native 复制成功未验。",
    "未知动作核对 modal、完整命令/文件变更及未知结果执行/核对流程未验。",
    "最小/紧凑尺寸、其他几何、多窗口及完整主题明暗矩阵未验。",
    "真实 SSH、供应商配置加载/业务请求、外部客户端连接未验。",
    "AX 不含正文零计数、客户端 selected 状态或按钮级焦点；只签截图可见事实。",
    "完整键盘焦点循环/陷阱、IME、VoiceOver、辅助技术和对比度规范验收未验。",
    "Windows/Linux 原生、安装、签名、公证和发行未验。",
    "不重新编译、重放产品测试、复算777工程输入或联网验证远端推送；后两项沿用用户交接。",
    "build result没有独立source字段；source绑定来自包manifest及用户冻结交接，不能据此独立重建构建因果链。",
    "封存AX只证明所供树中的单窗口/单模态及后台控件隐藏；不代替全桌面窗口普查或事件隔离测试。",
    "原 native-app.log 为0字节，不能据此推断所有后台行为或无网络流量。",
]
result = {
    "schema_version": 1,
    "review_kind": "independent_nonauthor_read_only_visible_native_originals",
    "reviewer_role": "new nonauthor reviewer; no implementation or product execution",
    "created_at_utc": datetime.now(timezone.utc).isoformat(),
    "first_word": "ship" if not failed else "fix",
    "decision": "APPROVE" if not failed else "HOLD",
    "decision_scope": "only supplied eleven screenshots plus AX and normal package/process receipts",
    "source_commit": SOURCE, "app_sha256": APP_SHA,
    "full_native_finish": "NOT_GRANTED_OUT_OF_SCOPE",
    "severity_counts": {"P0": 0, "P1": 0, "P2": 0, "P3": 0},
    "product_findings": [],
    "evidence_check_failures": failed,
    "counts": {
        "view_image_calls": 11, "images_visually_inspected": 11, "ax_files_read": 11,
        "jpeg_hashes_recomputed": 11, "jpeg_sizes_recomputed": 11,
        "ax_hashes_recomputed": 11, "jpeg_dimensions_recomputed": 11,
        "normal_package_files_hashed": 6, "runtime_state_jsons": 9,
        "parent_exit0_reaped_receipts_checked": 3,
        "offline_audit_commands": 2, "local_git_metadata_commands": 1,
        "checks": len(checks), "checks_passed": len(checks) - len(failed),
        "checks_failed": len(failed), "checks_skipped": 0,
        "checks_by_group": dict(groups), "input_files_snapshotted": len(before),
        "unique_ax_hashes": len({entry["ax_sha256"] for entry in capture_results}),
        "product_tests": 0, "cargo_rustc_commands": 0,
        "ui_operations": 0, "cua_reads": 0, "app_launches": 0,
        "network_commands": 0, "installs": 0,
        "subagents_created": 0, "cleanup_commit_push_commands": 0,
    },
    "source_metadata_receipt": {
        "command": "GIT_OPTIONAL_LOCKS=0 git rev-parse --verify f910e0013832643f09b112b08443675a956d5551^{commit}",
        "exit_code": 0, "stdout": SOURCE,
        "remote_push_and_777_input_binding": "user-supplied; not rerun in this review",
    },
    "captures": capture_results, "checks": checks,
    "runtime_states": runtime_states,
    "input_file_manifest": before, "input_manifest_unchanged_during_audit": before == after,
    "parent_receipts": {
        "build": build, "structure": structure, "native_start": start,
        "native_result": finish, "native_app_log_bytes": 0,
    },
    "preserved_tooling_fact": {
        "event": obs["preserved_failures"][0]["event"],
        "product_failure": False,
        "evidence_strength": "parent narrative retained; capture05 AX independently has index7 Graphite and no34; no CUA replay",
    },
    "independent_audit_history": {
        "r1": {
            "archive": str((OUT / "audit-r1.json").relative_to(ROOT)),
            "exit_code": 1, "checks": 348, "passed": 347, "failed": 1,
            "failure": "directory inventory included auxiliary captures.json; image/AX integrity, package and process checks all passed",
            "product_failure": False,
        },
        "r2": {
            "scope_correction": "only the specified eleven JPEG and eleven AX files enter capture inventory",
            "auxiliary_capture_entries_excluded": auxiliary_capture_entries,
            "checks": len(checks), "passed": len(checks) - len(failed),
            "failed": len(failed),
        },
    },
    "ax_limits": {
        "client_selected_state": "not exposed; screenshot evidence only",
        "focused_element": "window in all eleven supplied AX files",
        "body_ssh_proposal_close_counts": "not exposed; screenshot evidence only",
        "identical_mcp_ax_groups": [[2, 7, 8, 10], [3, 4, 6, 9]],
    },
    "unverified": limits,
}
(OUT / "review-result.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")

decision = result["decision"]
word = result["first_word"]
rows = "\n".join(
    f"| {entry['number']:02} | {entry['visual_surface']} | {entry['visual_notes']} | 通过（限定可见） |"
    for entry in capture_results
)
group_rows = "\n".join(f"| {group} | {count} |" for group, count in groups.items())
image_links = "\n\n".join(
    f"{entry['number']:02}. {entry['visual_surface']} — 通过（限定可见）。\n\n"
    f"![{entry['number']:02} original]({ROOT / entry['image']})"
    for entry in capture_results
)
report = f"""{word} — {decision}，仅批准所供 11 张原生截图、配对 AX 与正常包/原进程回执所覆盖的可见子集。

本次为新非作者独立只读复核。P0=0、P1=0、P2=0、P3=0，未发现该可见子集的新增确定产品缺陷。完整 native finish 和发行均未授予。结论不扩大到源码正确性、CI、777 工程输入或未发生的原生动作。

精确源码 `{SOURCE}`；应用 SHA-256 `{APP_SHA}`。已读 AGENTS、RTK、`docs/design/HALLMARK_NATIVE.md` 和交接约束；采用 Product Design audit 的原图逐张检查及证据边界规则。仅使用用户指定原件，未另取 UI 或网络证据。

| 原图步骤 | 实际可见界面 | 独立观察 | 健康度 |
| --- | --- | --- | --- |
{rows}

六个推荐组合由图03/04（Frost Light英文）、10（Frost Light中文）、06（Graphite Dark英文）、07（Graphite Dark中文）、08（Lavender Light中文）、09（Lavender Light英文）覆盖。正文和客户端说明正常换行，当前截图几何中关闭/撤销、复制和授权固定栏均完整。图05独立显示三家族与推荐外观；运行原件的8个备份及最终state也保留六组合。仅代表所拍几何，不能推定最小或紧凑尺寸通过。

图03 Claude 与图04 Codex、图07/08 Claude 与图09/10 Codex均有明确选中底色。AX中客户端只有普通按钮，没有 selected/toggle 值；中英文MCP AX各自跨主题/客户端完全相同。因此客户端选择、主题外观、正文零计数和图04关闭按钮轮廓按实际截图签署，不声称AX已表达这些状态。11份AX的 focused element全部仍是窗口。

11份AX均恰有1个标准窗口。图01含“工作区窗口，1”、空连接库；另10份各恰有1个 `keelshell.active-modal`，无工作区工具栏、SSH导航或连接列表后台节点。截图也只有一层当前模态和隔离背景。该证据支持所供原件的结构/视觉隔离，不证明全桌面窗口普查、后台事件拦截、完整焦点陷阱或辅助技术可用性。

8份MCP AX逐项核对13个禁用动作，共104个 disabled 状态：8种能力、捕获当前文本、清理历史、复制模板、复制临时启动配置及授权。空授权截图均无活动SSH且提案为0；图11关闭审核显示0 SSH/0文件草稿快照。正文这些文字不在AX中，依据原图观察。**复制模板因未授权始终disabled，native复制成功未验；没有未知动作modal的原生执行。**

| 身份/回执 | 独立复核结果 |
| --- | --- |
| source → package → start → result | observations、manifest、start、result均为精确f910e001；本地commit对象只读解析相同。777输入/Git相等及已推送为用户交接事实，本次不重复也不联网验证。 |
| 正常包 | 实际package-r1恰6文件，全部字节数和SHA-256与observations相等；5个应用文件也与manifest相等，实际包manifest与交付manifest逐字节摘要相等。没有执行包内文件。 |
| 正常release build | 父级现有receipt：exit0、reaped=true、未超时，219.335732秒；本次没有构建。receipt无独立source字段，源码归属承接manifest和用户冻结交接。 |
| 正常结构检查 | 父级现有receipt：exit0、reaped=true，0.136847秒；原command.log给出aarch64-apple-darwin、GUI/MCP各minos15.0，明确GUI验收另计；本次没有重跑检查。 |
| 原进程启动/退出 | PID34098、精确work包路径、独立runtime和binarySHA一致；start全部字段保留到result，observations.native_process与result完全相等。 |
| 原进程终态 | 2026-11-17 06:02:24.750654–06:08:05.316898 UTC，exit0、reaped=true、timed_out=false，记录340.564409秒；原app.log为0字节。仅检查封存回执，未再启动或CUA读取。 |
| 无安装 | 包/启动/结果均installed=false，启动路径为work下正常包；本次安装/启动0。签名、公证、发行未验。 |
| 运行原件 | 最终state+8份备份共9份JSON，连接、最近/删除连接、known_hosts等均空，AI关闭且无供应商profile；默认命令片段不代表实际执行。 |

首个stale AX34在capture05重编号后被拒、刷新7成功，保留为工装事实，产品失败=false。图05的AX独立可见当前7为Graphite且没有34；拒绝/成功过程来自父级native-observations叙述，本次没有重演或额外CUA日志。原图05未替换。

| 计数口径 | 实际数量 |
| --- | --- |
| `view_image`原图查看 | 11次 / 11张，均为原路径；工具显示预览自动缩放至1975×1280，未改动原JPEG |
| JPEG/AX摘要 | 11 JPEG SHA + 11 AX SHA全部相等；11个JPEG字节数相等 |
| JPEG尺寸 | 11/11直接解析SOF，原图均2880×1866；11个JPEG摘要互异 |
| AX读取 | 11份；唯一AX摘要5种，重复AX结构已明确其证明限制 |
| 正常包摘要 | 6/6文件一致，仅只读摘要 |
| 独立离线审计命令 | 2次：`python3 -B work/mcp-native-finish-review-20261117/audit.py`；r1回执见audit-r1.json，r2进程回执见audit-command.json |
| 本地Git身份命令 | 1次rev-parse，只读，exit0；远端命令0 |
| 最终r2证据谓词检查 | {len(checks)}项，{len(checks) - len(failed)}通过，{len(failed)}失败，0跳过；逐项见review-result.json |
| 首轮r1及累计 | r1为348项/347通过/1工装清单失败；两轮累计{348 + len(checks)}次谓词求值，{347 + len(checks) - len(failed)}通过，{1 + len(failed)}失败求值；原失败保留且已修正，不合并为产品测试数量 |
| 原件不变性 | 审计前后{len(before)}个指定输入文件摘要相等；不扫描或改写并行docs/CI或target |
| 产品执行 | 产品测试0、Cargo/rustc0、UI操作0、CUA读取0、应用启动0、网络命令0、安装0、子agent0、清理/提交/推送0 |

| 审计谓词分组（非产品测试） | 数量 |
| --- | --- |
{group_rows}

实际准备/阅读用了7次shell工具调用（第2次目录清单因尚不存在的复核输出目录返回2，其余6次为0），首轮诊断/工装原件归档2次，审计执行2次，最终报告/JSON读回1次，合计12次shell工具调用；逐次exit记录在audit-command.json。11次view_image另列。首轮审计348项中唯一失败是工装把辅助captures.json也列入“恰22张原件”的目录条件；11对图/AX、包及进程检查均已通过。按用户指定11 JPG+11 AX限定清单后修正；未删除/修改captures.json，首轮脚本、报告、结果和exit1已完整保存在audit-r1.json。该目录辅助条目及工装错误不是产品失败。不把阅读、脚本检查或父级成绩计作独立产品测试。

未验边界：

{chr(10).join('- ' + item for item in limits)}

建议：可接收本批可见子集的原件复核，完整产品/原生/辅助技术及发布状态继续分别验收。报告及工装只写入 `work/mcp-native-finish-review-20261117/`，没有实施修复或变更父级材料。

原图证据按步骤附下（引用父级原路径，不复制、不修改）：

{image_links}
"""
(OUT / "REPORT.md").write_text(report)
print(json.dumps({
    "decision": decision, "checks": len(checks), "passed": len(checks) - len(failed),
    "failed": len(failed), "groups": dict(groups), "input_files": len(before),
    "images_inspected_with_view_image": 11, "package_files": len(package_paths),
    "output": str(OUT),
}, ensure_ascii=False))
sys.exit(0 if not failed else 1)
