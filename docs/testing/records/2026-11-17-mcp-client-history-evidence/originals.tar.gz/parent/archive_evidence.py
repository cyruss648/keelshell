"""Seal owned originals, excluding executable copies, with exact member hashes."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[2]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--destination", required=True)
    parser.add_argument("--mapping", action="append", required=True)
    parser.add_argument("--exclude", action="append", default=[])
    options = parser.parse_args()
    destination = ROOT / options.destination
    destination.mkdir(parents=True, exist_ok=True)
    excluded = set(options.exclude)
    rows = []
    seen = set()
    raw_archive = io.BytesIO()
    with tarfile.open(fileobj=raw_archive, mode="w") as archive:
        for mapping in options.mapping:
            source_name, prefix = mapping.split("=", 1)
            source = ROOT / source_name
            assert source.is_dir() and not source.is_symlink()
            for path in sorted(source.rglob("*")):
                assert not path.is_symlink(), path
                if not path.is_file():
                    continue
                relative = path.relative_to(ROOT).as_posix()
                if relative in excluded or any(
                        relative.startswith(item.rstrip("/") + "/") for item in excluded):
                    continue
                member = prefix + path.relative_to(source).as_posix()
                assert member not in seen and not member.startswith("/")
                assert ".." not in Path(member).parts
                seen.add(member)
                raw = path.read_bytes()
                info = tarfile.TarInfo(member)
                info.size = len(raw)
                info.mode = 0o644
                archive.addfile(info, io.BytesIO(raw))
                rows.append({
                    "member": member, "source": relative, "bytes": len(raw), "sha256": sha(raw),
                })
    compressed = io.BytesIO()
    with gzip.GzipFile(fileobj=compressed, mode="wb", filename="", mtime=0) as stream:
        stream.write(raw_archive.getvalue())
    blob = compressed.getvalue()
    with (destination / "originals.tar.gz").open("xb") as stream:
        stream.write(blob)
    manifest = {
        "schema_version": 1, "members": len(rows),
        "logical_bytes": sum(row["bytes"] for row in rows),
        "bytes": len(blob), "sha256": sha(blob), "excluded": sorted(excluded), "files": rows,
    }
    with (destination / "manifest.json").open("x") as stream:
        json.dump(manifest, stream, indent=2)
        stream.write("\n")
    with tarfile.open(fileobj=io.BytesIO(blob)) as archive:
        members = archive.getmembers()
        assert len(members) == len(rows)
        for member, row in zip(members, rows):
            assert member.name == row["member"] and member.isfile()
            raw = archive.extractfile(member).read()
            assert len(raw) == row["bytes"] and sha(raw) == row["sha256"]
    print(json.dumps({key: value for key, value in manifest.items() if key != "files"}))


if __name__ == "__main__":
    main()
