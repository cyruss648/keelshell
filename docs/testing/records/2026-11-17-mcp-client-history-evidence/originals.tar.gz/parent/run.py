"""Run a bounded owned command and retain its log and actual wait receipt."""
import datetime
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
label = sys.argv[1]
argv = sys.argv[2:]
destination = BASE / label
destination.mkdir()
env = dict(
    os.environ,
    CARGO_TARGET_DIR=str(ROOT / "work/recovery-batch-integration-20261115/target"),
    CARGO_BUILD_JOBS="2",
    MACOSX_DEPLOYMENT_TARGET="15.0",
    PYTHONDONTWRITEBYTECODE="1",
)
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
clock = time.monotonic()
timed_out = False
with (destination / "command.log").open("xb") as log:
    process = subprocess.Popen(
        argv, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT,
        start_new_session=True,
    )
    try:
        code = process.wait(timeout=1800)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            code = process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            code = process.wait(timeout=5)
receipt = {
    "argv": argv, "cwd": str(ROOT), "pid": process.pid,
    "started_at_utc": started,
    "completed_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "exit_code": code, "timed_out": timed_out, "reaped": True,
    "duration_seconds": round(time.monotonic() - clock, 6),
}
with (destination / "result.json").open("x") as output:
    json.dump(receipt, output, indent=2)
    output.write("\n")
print(json.dumps(receipt), flush=True)
sys.exit(code if 0 <= code < 256 else 1)
