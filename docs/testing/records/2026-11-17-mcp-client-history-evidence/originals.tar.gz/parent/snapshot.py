"""Freeze or verify all non-document repository inputs for this checkout."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
names = subprocess.check_output(
    ["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"],
    cwd=ROOT,
).decode().split("\0")
paths = sorted({name for name in names if name and not name.startswith("docs/")})
rows = []
for name in paths:
    path = ROOT / name
    assert path.is_file() and not path.is_symlink(), name
    data = path.read_bytes()
    rows.append({"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
record = {
    "count": len(rows),
    "inputs": rows,
    "aggregate_algorithm": "sha256(json.dumps(inputs, sort_keys=True, separators=(',', ':')).encode())",
    "aggregate_sha256": hashlib.sha256(
        json.dumps(rows, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest(),
    "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
}
if sys.argv[1] == "freeze":
    with (BASE / sys.argv[2]).open("x") as output:
        json.dump(record, output, indent=2)
        output.write("\n")
else:
    expected = json.loads((BASE / sys.argv[2]).read_text())
    assert rows == expected["inputs"], "engineering inputs changed"
print(json.dumps({key: value for key, value in record.items() if key != "inputs"}))
