use keelshell_mcp::{McpClientKind, client_configuration_template};
use std::{error::Error, path::Path};

fn hex(bytes: &[u8]) -> String {
    bytes.iter().map(|value| format!("{value:02x}")).collect()
}

fn main() -> Result<(), Box<dyn Error>> {
    let mut commands = vec![
        "/opt/keelshell/bin/keelshell-mcp".to_string(),
        "/Applications/KeelShell 中文.app/Contents/MacOS/keelshell-mcp".into(),
        r"C:\Program Files\KeelShell\keelshell-mcp.exe".into(),
        r"\\server\share\Keel Shell\keelshell-mcp.exe".into(),
        "/opt/\";\n[mcp_servers.injected]\ncommand = \"other\" #/keelshell-mcp".into(),
        "/opt/$(literal);`literal` & | '\"/keelshell-mcp".into(),
        "/opt/${UNSET}/keelshell-mcp".into(),
        "/opt/雪 e\u{301}\u{85}\u{2028}\u{2029}/keelshell-mcp".into(),
    ];
    for byte in (0u8..=31).chain(std::iter::once(127)) {
        commands.push(format!("/opt/a{}b/keelshell-mcp", char::from(byte)));
    }
    for command in commands {
        let codex = client_configuration_template(McpClientKind::CodexCli, Path::new(&command))?;
        let claude =
            match client_configuration_template(McpClientKind::ClaudeCode, Path::new(&command)) {
                Ok(value) => hex(value.as_bytes()),
                Err(_) if command.contains("${") => "-".to_string(),
                Err(error) => return Err(error.into()),
            };
        println!("{}\t{}\t{}", hex(command.as_bytes()), hex(codex.as_bytes()), claude);
    }
    Ok(())
}
