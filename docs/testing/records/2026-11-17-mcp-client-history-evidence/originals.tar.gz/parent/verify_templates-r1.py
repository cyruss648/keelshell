"""Independently parse the actual production renderer with Python TOML/JSON."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tomllib

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
build_log = BASE / "template-library-build-r1/command.log"
artifacts = []
for line in build_log.read_text().splitlines():
    if not line.startswith("{"):
        continue
    event = json.loads(line)
    if (event.get("reason") == "compiler-artifact"
            and event["target"]["name"] == "keelshell_mcp"
            and "lib" in event["target"]["kind"]):
        artifacts.extend(Path(name) for name in event["filenames"] if name.endswith(".rlib"))
assert len(artifacts) == 1
library = artifacts[0]
before = hashlib.sha256(library.read_bytes()).hexdigest()
binary = BASE / "template-probe"
argv = [
    "rustc", "--edition=2024", str(BASE / "template_probe.rs"),
    "--extern", f"keelshell_mcp={library}",
    "-L", f"dependency={ROOT / 'work/recovery-batch-integration-20261115/target/debug/deps'}",
    "-o", str(binary),
]
compiled = subprocess.run(argv, cwd=ROOT, capture_output=True, timeout=60)
(BASE / "template-probe-compile.log").write_bytes(compiled.stdout + compiled.stderr)
assert compiled.returncode == 0
result = subprocess.run([str(binary)], cwd=ROOT, capture_output=True, timeout=10)
(BASE / "template-probe.tsv").write_bytes(result.stdout)
(BASE / "template-probe-stderr.log").write_bytes(result.stderr)
assert result.returncode == 0 and result.stderr == b""
rows = []
for line in result.stdout.decode().splitlines():
    command_hex, codex_hex, claude_hex = line.split("\t")
    command, codex = (bytes.fromhex(raw).decode() for raw in (command_hex, codex_hex))
    document = tomllib.loads(codex)
    assert document == {"mcp_servers": {"keelshell": {
        "command": command, "args": [],
        "env_vars": ["KEELSHELL_MCP_ADDRESS", "KEELSHELL_MCP_SECRET"],
    }}}
    if claude_hex == "-":
        assert "${" in command
        claude_state = "rejected_literal_expansion"
    else:
        claude = bytes.fromhex(claude_hex).decode()
        assert json.loads(claude) == {"mcpServers": {"keelshell": {
            "type": "stdio", "command": command, "args": [], "env": {
                "KEELSHELL_MCP_ADDRESS": "${KEELSHELL_MCP_ADDRESS}",
                "KEELSHELL_MCP_SECRET": "${KEELSHELL_MCP_SECRET}",
            },
        }}}
        claude_state = "parsed_exact"
    rows.append({"command_hex": command_hex, "codex": "parsed_exact", "claude": claude_state})
assert len(rows) == 41
assert before == hashlib.sha256(library.read_bytes()).hexdigest()
report = {
    "producer": "current compiled production keelshell_mcp::client_configuration_template",
    "library": str(library), "library_sha256": before, "library_unchanged": True,
    "compile_argv": argv, "compile_exit": compiled.returncode, "execution_exit": result.returncode,
    "rows": rows, "cases": len(rows),
    "toml_exact_semantics": len(rows),
    "json_exact_semantics": sum(row["claude"] == "parsed_exact" for row in rows),
    "claude_literal_expansion_rejections": sum(row["claude"] != "parsed_exact" for row in rows),
    "output_sha256": hashlib.sha256(result.stdout).hexdigest(),
    "boundary": "Independent parser over actual renderer output; no installed client, grant, SSH or provider access.",
}
with (BASE / "template-parser-result.json").open("x") as output:
    json.dump(report, output, indent=2)
    output.write("\n")
print(json.dumps({key: value for key, value in report.items() if key not in ["compile_argv", "rows"]}))
