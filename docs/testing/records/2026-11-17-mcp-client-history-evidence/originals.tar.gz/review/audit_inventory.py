"""Compare independently listed and executed names, including every new test."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
freeze = json.loads((ROOT / "work/mcp-external-workflow-20261117/candidate-inputs-r1.json").read_text())
by_path = {item["path"]: item for item in freeze["inputs"]}

def listing(label):
    return set(re.findall(r"^(.+): test$", (BASE / (label + ".log")).read_text(), re.M))

def executed(label):
    text = (BASE / (label + ".log")).read_text()
    return re.findall(r"^test (\S+) \.\.\. (ok|FAILED|ignored)$", text, re.M)

app = listing("app-list")
client = listing("client-list")
groups = [("app-mcp", app, "workspace::tests::mcp", 37), ("app-history", app, "workspace::mcp::history", 1), ("app-modal", app, "workspace::modal_scope::tests", 11), ("client", client, "", 13)]
results = []
all_executed = set()
for label, listed, prefix, count in groups:
    expected = {name for name in listed if prefix in name}
    actual = executed(label)
    names = [name for name, state in actual]
    assert len(names) == len(set(names)) == count, label
    assert set(names) == expected, label
    assert all(state == "ok" for _, state in actual), label
    receipt = json.loads((BASE / (label + "-receipt.json")).read_text())
    assert receipt["exit_code"] == 0 and receipt["reaped"] and not receipt["timed_out"], label
    assert receipt["test_summary"][0]["passed"] == count and receipt["test_summary"][0]["failed"] == receipt["test_summary"][0]["ignored"] == 0
    all_executed.update(names)
    results.append({"label": label, "actual_count": count, "matches_independent_list": True, "names": sorted(expected)})

sources = [
    ("crates/keelshell-app/src/workspace/tests/mcp_action_history.rs", "workspace::tests::mcp::action_history::"),
    ("crates/keelshell-app/src/workspace/tests/mcp_client_settings.rs", "workspace::tests::mcp::client_settings::"),
    ("crates/keelshell-app/src/workspace/tests/mcp_file_unknown_history.rs", "workspace::tests::mcp::file_changes::unknown_history::"),
    ("crates/keelshell-app/src/workspace/mcp/history.rs", "workspace::mcp::history::tests::"),
    ("crates/keelshell-mcp/tests/client_config.rs", ""),
]
new = []
for name, prefix in sources:
    text = (ROOT / name).read_text()
    functions = re.findall(r"#\[(?:gpui_kit::)?test\]\s*(?:async\s+)?fn\s+(\w+)\s*\(", text)
    functions = [fn for fn in functions if fn != "templates_reject_unpaired_windows_surrogates_without_lossy_conversion"]
    expected = {prefix + function for function in functions}
    assert expected <= all_executed, (name, expected - all_executed)
    new.extend(sorted(expected))
assert len(new) == len(set(new)) == 20

env = dict(os.environ, GIT_OPTIONAL_LOCKS="0")
modified = subprocess.check_output(["git", "diff", "--name-only", "HEAD", "-z"], cwd=ROOT, env=env).decode().split("\0")
untracked = subprocess.check_output(["git", "ls-files", "--others", "--exclude-standard", "-z"], cwd=ROOT, env=env).decode().split("\0")
engineering = sorted({name for name in modified + untracked if name and not name.startswith("docs/")})
assert len(engineering) == 17
record = {"app_listed": len(app), "client_listed": len(client), "groups": results, "rust_passed": len(all_executed), "rust_failed": 0, "rust_ignored": 0, "new_tests_executed": new, "new_test_count": len(new), "changed_engineering_input_count": len(engineering), "reviewed_engineering_inputs": [by_path[name] for name in engineering], "boundary": "Listed/executed names agree with source names. This confirms copied-binary inventory and executions, not independent source compilation or binary-code equivalence."}
with (BASE / "inventory-audit.json").open("x") as stream:
    json.dump(record, stream, indent=2)
    stream.write("\n")
print(json.dumps({k: v for k,v in record.items() if k not in ("groups", "reviewed_engineering_inputs", "new_tests_executed")}, indent=2))
for row in record["reviewed_engineering_inputs"]:
    print(row["path"])
