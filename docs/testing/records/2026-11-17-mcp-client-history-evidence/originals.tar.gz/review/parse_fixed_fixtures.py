"""Parse fixed expected TOML literals from Rust tests, never the production renderer."""
import hashlib
import json
from pathlib import Path
import re
import sys
import tomllib

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
SOURCE = ROOT / "crates/keelshell-mcp/tests/client_config.rs"
text = SOURCE.read_text()

def rust_string(token):
    if token.startswith("r"):
        match = re.fullmatch(r'r(#+)?"(.*)"\1', token, re.S)
        if match is None:
            raise ValueError("unsupported raw fixture")
        return match.group(2)
    body = token[1:-1]
    result = []
    index = 0
    escapes = {"n": "\n", "r": "\r", "t": "\t", "0": "\0", "\\": "\\", '"': '"', "'": "'"}
    while index < len(body):
        if body[index] != "\\":
            result.append(body[index])
            index += 1
            continue
        index += 1
        escape = body[index]
        index += 1
        if escape == "u":
            assert body[index] == "{"
            end = body.index("}", index)
            result.append(chr(int(body[index+1:end].replace("_", ""), 16)))
            index = end + 1
        elif escape == "x":
            result.append(chr(int(body[index:index+2], 16)))
            index += 2
        else:
            result.append(escapes[escape])
    return "".join(result)

string_token = r'r\#"[\s\S]*?"\#|"(?:\\.|[^"\\])*"'
pair = re.compile(r"\(\s*(" + string_token + r"),\s*(" + string_token + r"),?\s*\)")
sections = [
    ("platform_paths", text[text.index("const PATH_CASES:"):text.index("fn assert_codex_template")]),
    ("shell_metacharacters", text[text.index("fn shell_metacharacters_remain"):text.index("fn configuration_shaped_paths")]),
    ("configuration_injection", text[text.index("fn configuration_shaped_paths"):text.index("fn claude_template_rejects")]),
    ("literal_codex_interpolation", text[text.index("fn codex_template_preserves_literal"):text.index("fn templates_reject_empty")]),
]
expected_counts = {"platform_paths": 13, "shell_metacharacters": 3, "configuration_injection": 3, "literal_codex_interpolation": 3}
prefix = "[mcp_servers.keelshell]\ncommand = "
suffix = '\nargs = []\nenv_vars = ["KEELSHELL_MCP_ADDRESS", "KEELSHELL_MCP_SECRET"]\n'
records = []
for label, section in sections:
    pairs = pair.findall(section)
    assert len(pairs) == expected_counts[label], (label, len(pairs))
    for index, (command_token, quoted_token) in enumerate(pairs):
        command, quoted = rust_string(command_token), rust_string(quoted_token)
        fixture = prefix + quoted + suffix
        parsed = tomllib.loads(fixture)
        assert parsed == {"mcp_servers": {"keelshell": {"command": command, "args": [], "env_vars": ["KEELSHELL_MCP_ADDRESS", "KEELSHELL_MCP_SECRET"]}}}, (label, index)
        assert json.loads(quoted) == command, (label, index)
        records.append({"group": label, "index": index, "ok": True, "fixture_sha256": hashlib.sha256(fixture.encode()).hexdigest()})
control_section = text[text.index("fn codex_template_escapes_every"):text.index("fn claude_template_round_trips")]
control_pairs = re.findall(r"\('((?:\\.|[^'\\])*)', r\"([^\"]*)\"\)", control_section)
assert len(control_pairs) == 33, len(control_pairs)
for index, (control, escaped) in enumerate(control_pairs):
    command = "/opt/prefix" + rust_string('"' + control + '"') + "suffix/keelshell-mcp"
    fixture = prefix + '"/opt/prefix' + escaped + 'suffix/keelshell-mcp"' + suffix
    parsed = tomllib.loads(fixture)
    assert parsed["mcp_servers"]["keelshell"]["command"] == command, index
    assert len(parsed["mcp_servers"]) == 1
    records.append({"group": "all_c0_and_del", "index": index, "ok": True, "fixture_sha256": hashlib.sha256(fixture.encode()).hexdigest()})
record = {"source": str(SOURCE), "source_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(), "python_version": sys.version, "kind": "independent fixed expected fixture parse only; no production renderer executed or reimplemented", "passed": len(records), "failed": 0, "records": records}
with (BASE / "fixed-fixture-parse.json").open("x") as stream:
    json.dump(record, stream, indent=2)
    stream.write("\n")
print(json.dumps({key: value for key, value in record.items() if key != "records"}, indent=2))
