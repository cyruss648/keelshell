"""Independently parse saved production-renderer outputs; execute no producer."""
import hashlib
import json
from pathlib import Path
import tomllib

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
PARENT = ROOT / "work/mcp-external-workflow-20261117/template-parser-r2"
source = PARENT / "template-probe.tsv"
receipt_path = PARENT / "result.json"
payload = source.read_bytes()
receipt = json.loads(receipt_path.read_text())
output_hash = hashlib.sha256(payload).hexdigest()
assert output_hash == receipt["output_sha256"]
counts = {"cases": 0, "toml_exact": 0, "json_exact": 0, "claude_expansion_rejected": 0}
records = []
for index, line in enumerate(payload.decode().splitlines()):
    command_hex, toml_hex, json_hex = line.split("\t")
    command = bytes.fromhex(command_hex).decode()
    codex = tomllib.loads(bytes.fromhex(toml_hex).decode())
    assert codex == {"mcp_servers": {"keelshell": {"command": command, "args": [], "env_vars": ["KEELSHELL_MCP_ADDRESS", "KEELSHELL_MCP_SECRET"]}}}, index
    counts["toml_exact"] += 1
    if "${" in command:
        assert json_hex == "ERR", (index, json_hex)
        counts["claude_expansion_rejected"] += 1
    else:
        claude = json.loads(bytes.fromhex(json_hex).decode())
        assert claude == {"mcpServers": {"keelshell": {"type": "stdio", "command": command, "args": [], "env": {"KEELSHELL_MCP_ADDRESS": "${KEELSHELL_MCP_ADDRESS}", "KEELSHELL_MCP_SECRET": "${KEELSHELL_MCP_SECRET}"}}}}, index
        counts["json_exact"] += 1
    counts["cases"] += 1
    records.append({"index": index, "command_hex": command_hex, "ok": True})
assert counts == {"cases": 41, "toml_exact": 41, "json_exact": 40, "claude_expansion_rejected": 1}, counts
record = {"input": str(source), "output_sha256": output_hash, "parent_receipt_sha256": hashlib.sha256(receipt_path.read_bytes()).hexdigest(), "counts": counts, "parent_reported_library_sha256": receipt["library_sha256"], "boundary": "Independent parse of parent-provided production renderer output. Did not rerun producer, compiler, Cargo, client or provider; library provenance is parent-reported, not independent compilation.", "records": records}
with (BASE / "production-output-reparse.json").open("x") as stream:
    json.dump(record, stream, indent=2)
    stream.write("\n")
print(json.dumps({k: v for k, v in record.items() if k != "records"}, indent=2))
