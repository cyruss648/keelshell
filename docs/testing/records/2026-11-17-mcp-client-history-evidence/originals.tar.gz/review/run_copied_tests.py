"""Execute only parent-provided copies; preserve each raw command and receipt."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
APP = BASE / "bin/keelshell_app-4bca9816c52f9a50"
CLIENT = BASE / "bin/client_config-f71a8eb5ca82ceca"
GROUPS = {
    "app-list": (APP, ["--list"], 60),
    "client-list": (CLIENT, ["--list"], 60),
    "app-mcp": (APP, ["workspace::tests::mcp", "--test-threads=1"], 240),
    "app-history": (APP, ["workspace::mcp::history", "--test-threads=1"], 60),
    "app-modal": (APP, ["workspace::modal_scope::tests", "--test-threads=1"], 180),
    "client": (CLIENT, ["--test-threads=1"], 60),
}
label = sys.argv[1]
binary, args, timeout = GROUPS[label]
command = [str(binary), *args]
tmp = BASE / "tmp" / label
tmp.mkdir(parents=True, exist_ok=False)
data = BASE / "runtime" / label
data.mkdir(parents=True, exist_ok=False)
env = dict(os.environ, TMPDIR=str(tmp), TMP=str(tmp), TEMP=str(tmp), KEELSHELL_DATA_DIR=str(data), GIT_OPTIONAL_LOCKS="0", PYTHONDONTWRITEBYTECODE="1")
started = datetime.now(timezone.utc).isoformat()
clock = time.monotonic()
output = BASE / (label + ".log")
timed_out = False
with output.open("xb") as log:
    process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
    try:
        code = process.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        timed_out = True
        process.kill()
        code = process.wait(timeout=10)
text = output.read_text(errors="replace")
summary = re.findall(r"test result: ([^.]+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out", text)
listed = re.findall(r"^([^\n]+): (test|benchmark)$", text, re.M)
record = {"label": label, "argv": command, "cwd": str(ROOT), "at_utc": started, "elapsed_seconds": round(time.monotonic() - clock, 6), "exit_code": code, "reaped": True, "timed_out": timed_out, "log": str(output), "test_summary": [{"status": s, "passed": int(p), "failed": int(f), "ignored": int(i), "measured": int(m), "filtered_out": int(o)} for s,p,f,i,m,o in summary], "listed_tests": sum(kind == "test" for _,kind in listed), "listed_benchmarks": sum(kind == "benchmark" for _,kind in listed), "environment_overrides": {k: env[k] for k in ["TMPDIR", "TMP", "TEMP", "KEELSHELL_DATA_DIR", "GIT_OPTIONAL_LOCKS", "PYTHONDONTWRITEBYTECODE"]}}
with (BASE / (label + "-receipt.json")).open("x") as result:
    json.dump(record, result, indent=2)
    result.write("\n")
print(json.dumps(record, indent=2))
if "--list" not in args:
    print(text[-18000:])
if code:
    raise SystemExit(1)
