"""Read-only checkout and copied-binary attestation; writes only here."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
EXPECTED_HEAD = "f4562ad17efc918976738b241352e7a4f8af434e"
EXPECTED_AGGREGATE = "b34aedb8d859f1ca0b97934b707c71de8200b3ffd8a53ab602d323809932553e"
FREEZE = ROOT / "work/mcp-external-workflow-20261117/candidate-inputs-r1.json"
ENV = dict(os.environ, GIT_OPTIONAL_LOCKS="0")

def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, env=ENV)

def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()

label = sys.argv[1]
expected = json.loads(FREEZE.read_text())
names = git("ls-files", "--cached", "--others", "--exclude-standard", "-z").decode().split("\0")
paths = sorted({name for name in names if name and not name.startswith("docs/")})
rows = []
for name in paths:
    path = ROOT / name
    assert path.is_file() and not path.is_symlink(), name
    rows.append({"path": name, "bytes": path.stat().st_size, "sha256": digest(path)})
aggregate = hashlib.sha256(json.dumps(rows, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
head = git("rev-parse", "HEAD").decode().strip()
expected_map = {row["path"]: row for row in expected["inputs"]}
actual_map = {row["path"]: row for row in rows}
changes = [name for name in sorted(expected_map.keys() | actual_map.keys()) if expected_map.get(name) != actual_map.get(name)]
provenance = json.loads((BASE / "binary-provenance.json").read_text())
binaries = []
for binary in provenance:
    path = ROOT / binary["copy"]
    assert path.resolve().is_relative_to(BASE / "bin"), path
    actual_hash = digest(path)
    size = path.stat().st_size
    binaries.append({"suite": binary["suite"], "path": str(path), "bytes": size, "sha256": actual_hash, "matches": size == binary["bytes"] and actual_hash == binary["sha256"]})
record = {
    "phase": label,
    "at_utc": datetime.now(timezone.utc).isoformat(),
    "head": head,
    "head_matches": head == expected["head"] == EXPECTED_HEAD,
    "count": len(rows),
    "aggregate_sha256": aggregate,
    "freeze_file_sha256": digest(FREEZE),
    "manifest_matches": len(rows) == expected["count"] == 777 and not changes and aggregate == expected["aggregate_sha256"] == EXPECTED_AGGREGATE,
    "changed_inputs": changes,
    "binaries": binaries,
}
record["ok"] = record["head_matches"] and record["manifest_matches"] and all(b["matches"] for b in binaries)
with (BASE / (label + "-attestation.json")).open("x") as stream:
    json.dump(record, stream, indent=2)
    stream.write("\n")
for suffix, data in [
    ("status.txt", git("status", "--porcelain=v1", "-uall")),
    ("tracked.diff", git("diff", "--no-ext-diff", "--binary", "HEAD")),
    ("untracked.txt", git("ls-files", "--others", "--exclude-standard")),
]:
    with (BASE / (label + "-" + suffix)).open("xb") as stream:
        stream.write(data)
print(json.dumps(record, indent=2))
if not record["ok"]:
    raise SystemExit(1)
