"""Preserve post-archive delivery receipts without copying unchanged evidence."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "work/mcp-review-scroll-integration-20261117"
BASE = ROOT / "docs/testing/records/2026-11-17-mcp-review-scroll-evidence"
DESTINATION = BASE / "delivery"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


prior = json.loads((BASE / "manifest.json").read_text())
old = {row["source"]: row for row in prior["files"]}
DESTINATION.mkdir(exist_ok=True)
archive = DESTINATION / "originals.tar.gz"
assert not archive.exists()
files, unchanged = [], []
with archive.open("xb") as output, gzip.GzipFile(fileobj=output, mode="wb", mtime=0, filename="") as zipped:
    with tarfile.open(fileobj=zipped, mode="w|") as target:
        for path in sorted(SOURCE.rglob("*")):
            assert not path.is_symlink()
            if path.is_dir():
                continue
            assert path.is_file()
            raw = path.read_bytes()
            name = str(path.relative_to(ROOT))
            row = {"source": name, "bytes": len(raw), "sha256": sha(raw)}
            if name in old and all(row[key] == old[name][key] for key in ("bytes", "sha256")):
                unchanged.append(name)
                continue
            member = path.relative_to(SOURCE).as_posix()
            info = tarfile.TarInfo(member)
            info.size = len(raw)
            info.mode = 0o644
            target.addfile(info, io.BytesIO(raw))
            files.append(dict(row, member=member))
manifest = {
    "feature_commit": "39d9041f350e30788b39121959d2ae7f7efea043",
    "main_archive_sha256": prior["sha256"], "files": files,
    "unchanged_in_main_archive": unchanged, "members": len(files),
    "logical_bytes": sum(row["bytes"] for row in files),
    "bytes": archive.stat().st_size, "sha256": sha(archive.read_bytes()),
}
(DESTINATION / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({key: manifest[key] for key in ("members", "logical_bytes", "bytes", "sha256", "feature_commit")}))
