"""Remove this run's exact labelled resources; never enumerate-and-delete."""
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
resources = json.loads((BASE/"owned-resources.json").read_text())
label, owner = resources["label"], resources["owner"]
report = {"owner": owner, "steps": []}


def run(arguments, seconds=20, allowed=(0,)):
    result = subprocess.run(
        arguments, cwd=ROOT, stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=seconds,
    )
    report["steps"].append({"argv": arguments, "exit_code": result.returncode,
                            "reaped": True, "stdout": result.stdout.decode(),
                            "stderr": result.stderr.decode()})
    assert result.returncode in allowed, arguments
    return result.stdout


container = resources["container_id"]
assert re.fullmatch(r"[0-9a-f]{64}", container)
row = json.loads(run(["podman", "inspect", container]))[0]
assert row["Id"] == container and row["Config"]["Labels"][label] == owner
assert row["Image"].removeprefix("sha256:") == resources["image"]
if row["State"]["Running"]:
    run(["podman", "stop", "--time", "10", container])
run(["podman", "logs", container])
run(["podman", "rm", container])
run(["podman", "container", "exists", container], allowed=(1,))
network = resources["network_id"]
network_row = json.loads(run(["podman", "network", "inspect", network]))[0]
assert network_row["id"] == network and network_row["labels"][label] == owner
run(["podman", "network", "rm", network])
run(["podman", "network", "exists", network], allowed=(1,))
image = resources["image"]
image_row = json.loads(run(["podman", "image", "inspect", image]))[0]
assert image_row["Id"].removeprefix("sha256:") == image
assert image_row["Config"]["Labels"][label] == owner
run(["podman", "image", "rm", image])
run(["podman", "image", "exists", image], allowed=(1,))
if resources.get("private_directory"):
    private = Path(resources["private_directory"])
    assert private.parent == ROOT/"work"
    assert private.name.startswith(".connected-native-private-")
    assert private.is_dir() and not private.is_symlink()
    assert {path.name for path in private.iterdir()} == {"client", "host.pub", "known_hosts"}
    assert not any(path.is_symlink() for path in private.iterdir())
    shutil.rmtree(private)
    assert not private.exists()
    report["private_directory_removed"] = True
destination = BASE/sys.argv[1]
with destination.open("x") as output:
    json.dump(report, output, indent=2)
    output.write("\n")
print(json.dumps({"cleanup": "PASS", "steps": len(report["steps"]),
                  "receipt": destination.name}))
