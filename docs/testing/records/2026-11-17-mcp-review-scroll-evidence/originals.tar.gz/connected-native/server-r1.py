"""Owned disposable real OpenSSH service for a bounded native acceptance run."""
import json
import os
from pathlib import Path
import pwd
import signal
import socket
import subprocess
import time

base = Path("/run/keelshell-native")
base.mkdir(mode=0o755)
keys = base / "keys"
keys.mkdir(mode=0o755)
Path("/run/sshd").mkdir(mode=0o755)
home = Path("/home/ksnative")
home.chmod(0o700)
account = pwd.getpwnam("ksnative")
os.chown(home, account.pw_uid, account.pw_gid)
for name in ("host", "client"):
    subprocess.run(
        ["ssh-keygen", "-q", "-t", "ed25519", "-N", "", "-C", "", "-f", str(keys/name)],
        stdin=subprocess.DEVNULL, check=True, timeout=5,
    )
(keys/"authorized_keys").write_text(
    "no-agent-forwarding,no-X11-forwarding,no-port-forwarding "
    + (keys/"client.pub").read_text()
)
(keys/"authorized_keys").chmod(0o644)
for name, content in {
    "native-review.txt": "KeelShell native acceptance\n原始内容：仅供本次审核式文件操作。\n",
    "连接说明.txt": "这是本次隔离容器中的真实文件。\n",
}.items():
    path = home/name
    path.write_text(content, encoding="utf-8")
    path.chmod(0o600)
    os.chown(path, account.pw_uid, account.pw_gid)
config = base/"sshd_config"
config.write_text("\n".join([
    "Port 2222", "AddressFamily inet", "ListenAddress 0.0.0.0",
    f"HostKey {keys}/host", f"AuthorizedKeysFile {keys}/authorized_keys",
    f"PidFile {base}/sshd.pid", "AllowUsers ksnative",
    "AuthenticationMethods publickey", "PubkeyAuthentication yes",
    "PasswordAuthentication no", "KbdInteractiveAuthentication no", "UsePAM no",
    "PermitRootLogin no", "PermitEmptyPasswords no", "StrictModes yes", "UseDNS no",
    "PermitUserEnvironment no", "AllowAgentForwarding no", "AllowTcpForwarding no",
    "AllowStreamLocalForwarding no", "PermitTunnel no", "X11Forwarding no",
    "PermitTTY yes", "Subsystem sftp internal-sftp", "MaxSessions 16",
    "MaxAuthTries 2", "LoginGraceTime 10", "LogLevel ERROR", "",
]))
subprocess.run(
    ["/usr/sbin/sshd", "-t", "-f", str(config)],
    stdin=subprocess.DEVNULL, check=True, timeout=5,
)
stopped = False


def stop(_signal, _frame):
    global stopped
    stopped = True


for sig in (signal.SIGINT, signal.SIGTERM):
    signal.signal(sig, stop)
child = subprocess.Popen(
    ["/usr/sbin/sshd", "-D", "-e", "-f", str(config)], stdin=subprocess.DEVNULL,
)
clock = time.monotonic()
try:
    deadline = clock+5
    while True:
        if child.poll() is not None:
            raise RuntimeError("owned sshd exited before readiness")
        try:
            with socket.create_connection(("127.0.0.1", 2222), timeout=0.1):
                break
        except OSError:
            if time.monotonic() >= deadline:
                raise TimeoutError("owned sshd readiness")
            time.sleep(0.05)
    print(json.dumps({"status": "READY", "owner": "connected-native-20261117",
                      "sshd_pid": child.pid}), flush=True)
    while not stopped and time.monotonic()-clock < 1800:
        if child.poll() is not None:
            raise RuntimeError("owned sshd exited unexpectedly")
        time.sleep(0.1)
finally:
    if child.poll() is None:
        child.terminate()
        try:
            code = child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            child.kill()
            code = child.wait(timeout=5)
    else:
        code = child.wait(timeout=5)
    print(json.dumps({"status": "STOPPED", "sshd_exit_code": code,
                      "sshd_reaped": True}), flush=True)
