"""Prepare isolated, owner-labelled Podman SSH and non-secret native state."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
import time
import uuid

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
OWNER = "connected-native-20261117"
LABEL = "io.keelshell.native.owner"
events = BASE/"setup-events.jsonl"


def event(value):
    value["observed_at_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with events.open("a") as stream:
        stream.write(json.dumps(value)+"\n")
        stream.flush()
        os.fsync(stream.fileno())


def command(name, arguments, seconds=20):
    event({"event": "started", "name": name, "argv": arguments})
    clock = time.monotonic()
    result = subprocess.run(
        arguments, cwd=ROOT, stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=seconds,
    )
    (BASE/(name+".stdout")).write_bytes(result.stdout)
    (BASE/(name+".stderr")).write_bytes(result.stderr)
    event({"event": "reaped", "name": name, "exit_code": result.returncode,
           "duration_seconds": round(time.monotonic()-clock, 6),
           "stdout_sha256": hashlib.sha256(result.stdout).hexdigest(),
           "stderr_sha256": hashlib.sha256(result.stderr).hexdigest()})
    if result.returncode:
        raise RuntimeError("owned command failed: "+name)
    return result.stdout


image = (BASE/"image-id").read_text().strip().removeprefix("sha256:")
assert re.fullmatch(r"[0-9a-f]{64}", image)
network_name = "keelshell-native-20261117"
network = command("network-create", [
    "podman", "network", "create", "--internal", "--disable-dns",
    "--label", LABEL+"="+OWNER, network_name,
]).decode().strip()
assert re.fullmatch(r"[0-9a-f]{64}", network)
resources = {"owner": OWNER, "label": LABEL, "image": image,
             "network_name": network_name, "network_id": network}
(BASE/"owned-resources.json").write_text(json.dumps(resources, indent=2)+"\n")
arguments = [
    "podman", "create", "--pull=never", "--name", "keelshell-native-20261117",
    "--label", LABEL+"="+OWNER, "--network", network,
    "--read-only", "--cap-drop=ALL", "--security-opt=no-new-privileges",
    "--memory=256m", "--pids-limit=128", "--cpus=1",
    "--tmpfs", "/run:rw,noexec,nosuid,nodev,size=16m,mode=755",
    "--tmpfs", "/tmp:rw,noexec,nosuid,nodev,size=16m",
    "--tmpfs", "/home/ksnative:rw,nosuid,nodev,size=32m,mode=700",
    "--publish", "127.0.0.1::2222",
]
for capability in ("CHOWN", "DAC_READ_SEARCH", "SETUID", "SETGID", "SYS_CHROOT"):
    arguments += ["--cap-add", capability]
container = command("container-create", arguments+[image]).decode().strip()
assert re.fullmatch(r"[0-9a-f]{64}", container)
resources["container_id"] = container
(BASE/"owned-resources.json").write_text(json.dumps(resources, indent=2)+"\n")
command("container-start", ["podman", "start", container])
row = json.loads(command("container-inspect", ["podman", "inspect", container]))[0]
assert row["Id"] == container and row["Image"].removeprefix("sha256:") == image
assert row["Config"]["Labels"][LABEL] == OWNER
ports = row["NetworkSettings"]["Ports"]["2222/tcp"]
assert len(ports) == 1 and ports[0]["HostIp"] == "127.0.0.1"
port = int(ports[0]["HostPort"])
for attempt in range(20):
    status = subprocess.run(
        ["podman", "logs", container], stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=5,
    )
    if status.returncode == 0 and b'"status": "READY"' in status.stdout:
        (BASE/"container-ready.jsonl").write_bytes(status.stdout)
        break
    time.sleep(0.1)
else:
    raise RuntimeError("owned SSH readiness absent")
private = Path(tempfile.mkdtemp(prefix=".connected-native-private-", dir=ROOT/"work"))
private.chmod(0o700)
resources.update({"port": port, "private_directory": str(private)})
(BASE/"owned-resources.json").write_text(json.dumps(resources, indent=2)+"\n")
command("copy-client-key", [
    "podman", "cp", container+":/run/keelshell-native/keys/client", str(private/"client"),
])
(private/"client").chmod(0o600)
host_key = command("read-host-public-key", [
    "podman", "exec", container, "cat", "/run/keelshell-native/keys/host.pub",
]).decode().strip()
(private/"host.pub").write_text(host_key+"\n")
fingerprint = command("host-fingerprint", [
    "ssh-keygen", "-l", "-E", "sha256", "-f", str(private/"host.pub"),
]).decode().split()[1]
(private/"known_hosts").write_text("[127.0.0.1]:"+str(port)+" "+host_key+"\n")
command("ssh-preflight", [
    "ssh", "-F", "/dev/null", "-i", str(private/"client"),
    "-o", "IdentitiesOnly=yes", "-o", "BatchMode=yes",
    "-o", "StrictHostKeyChecking=yes", "-o", "UserKnownHostsFile="+str(private/"known_hosts"),
    "-o", "ConnectTimeout=5", "-p", str(port), "ksnative@127.0.0.1",
    "printf 'KEELSHELL_NATIVE_SSH_READY\\n'; uname -s; cat /home/ksnative/native-review.txt",
])
runtime = BASE/"runtime-r1"
runtime.mkdir(mode=0o700)
profile = {
    "id": str(uuid.uuid4()),
    "name": "Native Linux SSH for toolbar layout and explicitly reviewed MCP file operations",
    "group": "Native acceptance",
    "host": "127.0.0.1", "port": port, "username": "ksnative",
    "auth": {"type": "private_key", "path": str(private/"client")},
    "tags": ["owned-fixture"], "favorite": True,
}
state = {
    "schema_version": 1, "connections": [profile], "folders": [],
    "connection_folders": {}, "deleted_connections": [], "recent_connections": [],
    "snippets": [],
    "settings": {
        "language": "en", "font_size": 14.0, "scrollback_lines": 10000,
        "theme": "light", "theme_family": "frost",
        "updates": {"frequency": "disabled", "auto_download": False},
    },
    "known_hosts": {},
}
path = runtime/"state.json"
path.write_text(json.dumps(state, ensure_ascii=False, indent=2)+"\n")
path.chmod(0o600)
resources.update({"runtime_directory": str(runtime), "host_fingerprint": fingerprint,
                  "profile_id": profile["id"], "profile_name": profile["name"]})
(BASE/"owned-resources.json").write_text(json.dumps(resources, indent=2)+"\n")
print(json.dumps({"status": "READY", "container_id": container, "port": port,
                  "host_fingerprint": fingerprint, "runtime_directory": str(runtime)}))
