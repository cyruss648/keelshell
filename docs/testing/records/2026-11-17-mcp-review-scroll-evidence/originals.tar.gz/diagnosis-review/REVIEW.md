# MCP 滚动前版 r1：独立诊断与测试边界复核

日期：2026-11-17，Asia/Shanghai。只读诊断；新增文件仅在本目录。

**结论：HOLD，暂不建议把前版 r1 作为原生滚动缺陷修复合并。**
分离 viewport/content 的结构合理，但没有证明命中这次原生失败的根因。
旧生产红控制与 r1 绿控制均为 4 passed / 0 failed / 0 ignored，不能称为已重现缺陷或有效红绿回归。
当前增加 ScrollHandle/Always 滚动条的工作版本未冻结，不在本报告批准范围。

**严重度：P0=0、P1=0、P2=2、P3=0。**
两项 P2 均是与修复范围直接相关的验证缺口；本次没有确认新的生产 Rust 安全或业务授权缺陷。
已知原生审核入口不可达仍保持 OPEN，精确滚轮根因保持 UNKNOWN。

## 复核对象与证据归属

- 只读解析的 Git HEAD：`e394f6d16a448b7f8c3617451749d0d4ebc1b05a`。
- 旧生产：`work/mcp-scroll-fix-20261117/view-before.rs`，
  SHA-256 `36b57b154d31abd08795a8c6be9d8d608079587d262e693eb41ac1dd1015943e`。
- 本报告候选：`work/mcp-scroll-fix-20261117/view-fixed-r1.rs`，
  SHA-256 `048e38fdca8f6bd9138f71dfc0967b02c42ce1940d1d38186dca96dc81298ec7`。
- 前版测试：`crates/keelshell-app/src/workspace/tests/mcp_first_proposal.rs`，
  SHA-256 `9e7aa30cd11e41605bfbecaba552db9b4602c7caca2a6cb5ac709dece0dfafef`。
  新增三个测试位于 532–548 行；原测试仍在 6–156 行。
- 生产 `mcp/view.rs` 在复核期间从 r1 发展到持有滚动条的新版本，
  `mcp.rs` 也发生父级修改。因此以下 r1 生产行号均指向保存的候选文件，不能套用到新工作版本。
- 阅读 AGENTS.md、RTK.md、HANDOFF、SHARED_TARGET、ADR0162、
  当前测试记录及 rust-best-practices 的相关测试、Option 和文档规范。

## P2-01：当前滚轮测试不能作为此次原生失败的回归证明

**位置：** `crates/keelshell-app/src/workspace/tests/mcp_first_proposal.rs:277–295, 373–396, 472–491`。

三个新测试确实通过 `Window::dispatch_event` 投递坐标 MouseMove/Scroll，
然后用生产控件几何、真实点击和 modal/action 身份断言检查效果。它们并非直接设置 scroll offset，
也没有直接调用审核按钮回调。因此不能把红控制通过简单归因于“测试绕过了生产 view”。

但测试每次滚轮后都调用 `window.render_frame(cx)`。锁定的
`gpui-kit-0.10.0/src/test.rs:348–350` 明确执行：

```rust
self.refresh();
self.draw(cx).clear(cx);
```

这会主动要求刷新并完成绘制。若真实失败属于通知、帧调度或缓存视图未失效，
此测试仍可能通过；它验证的是显式刷新后的状态与几何，未证明正常应用会自行刷新。
这是确定的测试覆盖边界，不是已定位的生产根因。

此外，宏构建的是 `TestAppContext::build`：

- `gpui-pre-macros-0.3.12/src/test.rs:164` 调用该构造器；
- `gpui-pre-0.3.12/src/app/test_context.rs:132–142` 构造 `TestPlatform`；
- `gpui-pre-0.3.12/src/platform/test/platform.rs:134–141` 默认注入 `NoopTextSystem`；
- `gpui-pre-0.3.12/src/platform.rs:1605–1644,1659–1703` 使用固定字体指标和合成字宽。

因此该矩阵中的中文、英文和主题是真实应用状态变化，但文本换行、按钮宽度、
卡片高度和 flex 压缩结果并不等同于 macOS 原生字体测量。
测试夹具也未精确复制原图的长连接名称、路径和未捕获选区状态。

**影响：** 红旧/绿新均通过时，新增测试只能证明其各自夹具中的 headless 生产组件交互成立，
不能证明此前原生失败已被捕获或修好。尤其不能用“所有主题/两种尺寸都过”
替代真实字体与正常帧循环的验收。

**建议：** 保留这些有价值的交互测试，明确其能力边界；由父级在准确绑定的新正常包中继续原生复验。
若需要工程级红绿证明，应补上能在旧生产下失败的精确夹具或诊断测试；
帧调度路径需另行观察，不依靠主动 `refresh()` 证明正常应用的自行刷新。

**实际原件：**

- `work/mcp-scroll-native-20261117/scroll-red-control-r1/command.log:10–16`：
  4/0/0，38.88s；外层 result：exit 0、reaped、50.895021s，
  UTC `08:19:47.600585–08:20:38.495988`。
- `work/mcp-scroll-native-20261117/focused-scroll-r3/command.log:10–16`：
  4/0/0，40.55s；外层 result：exit 0、reaped、48.824398s，
  UTC `08:21:26.193540–08:22:15.018292`。
- 两份日志均显示重新 `Compiling keelshell-app`，均列出三个新增测试和原测试；
  没有依据将这两次通过解释为根本没有收录新测试。

## P2-02：完整文件 diff 的滚动变更没有相应长内容验证

**位置：** 候选 `work/mcp-scroll-fix-20261117/view-fixed-r1.rs:47–57`；
测试 `crates/keelshell-app/src/workspace/tests/mcp_first_proposal.rs:158–159,228–234,443–457`。

r1 同时改了主面板和完整文件审核的滚动容器。测试原文只有一行，
替换文也只有一行。打开完整审核后只检查路径标签、固定 footer 与 Keep pending，
随后关闭；没有向 `mcp-file-review-scroll` 投递滚轮，
没有检查 diff 首尾内容、diff 位移或长内容能否完整阅读。

**影响：** 当前三测试即使全部通过，也不能覆盖另一个实际被修改的滚动区域。
完整 diff 可读性属于审批所需行为，不能只凭“成功进入 modal”推定。

**建议：** 最终冻结版本补充至少一份明显高于 viewport 的多行 diff，
通过滚轮和所新增的滚动条分别到达首尾；核对固定审核 footer 及批准/拒绝/返回控件。
无需在这种布局测试中批准真实写入。新增加的滚动条若成为正式能力，也应验证其坐标拖动，
而不是仅检查元素存在或 handle 值变化。

## r1 结构是否合理，以及根因目前能确定到哪里

r1 主面板在 308 行固定 header 不收缩，315–340 行将受限 viewport 与纵向 content 分开；
完整文件审核的 47–57 行采用相同思路。源码只改变布局，不改变
can_approve、待审动作身份、review_mcp_action 和文件写入准入。
未发现它引入自动批准、命令执行或绕过授权的新路径。

此布局思路有明确的库机制依据：

1. `gpui-pre-0.3.12/src/elements/div.rs:2040–2062`
   以**直接子节点**的 layout bounds 求 content_size，不递归汇总所有后代溢出。
2. 同文件 `2527–2539` 计算
   `scroll_max = max(content_size + padding - bounds.size, 0)`，
   再将 offset 裁到 `[-scroll_max,0]`。
3. `gpui-pre-0.3.12/src/style.rs:801–803` 默认 flex_shrink=1；
   r1 之前直接放在 viewport 内的 flex 子项确实可能受到压缩。
4. 同一 div 文件 `3400–3444` 的监听器要求 Bubble 阶段且 scroll hitbox 命中，
   加入 delta 后执行 `cx.notify(current_view)`。

因此“直接子节点被压缩，后代却仍越界，最终 viewport 计算不到足够滚动范围”是
**与库实现一致的候选机制**。增加自然高度的 content 子层是合理处理方式。
但本次没有从运行中的正常包读取 content_size、scroll_max、offset 或事件计数；
旧生产测试也没有失败，不能将此候选机制提升为已证实根因。

同样，正常原图中的正文不动，既可能对应 offset 被 clamp，也可能是事件未到达、
hitbox/传播不符或未重新绘制。仅凭截图无法区分这些阶段。
本报告不将这些可能性列成已确认缺陷。

## test-support 与正常 release 的具体区别

- 应用测试在 `tests.rs:119–134` 挂载实际 `Workspace::new`；
  MCP Harness 在 `tests/mcp.rs:100–150` 接入隔离 loopback SSH/SFTP，
  `:159–183` 调用真实 server.invoke 并驱动 maintain_mcp；
  本次不是操作用户或客户机器。
- `gpui-base-0.10.0/src/observe.rs:23–35` 显示：
  正常编译的 `.test_support()` 返回原 element；测试编译增加观察包装。
  `test_support.rs:471–478,543–546,577–578` 将 layout/prepaint/paint 转发给原 element，
  未增加额外布局节点。没有证据认为观察包装本身把布局修好了。
- `test_support.rs:506` 以 `node.is_disabled().then_some(true)` 记录 disabled；
  未设置的 flag 返回 None。父级改成 `!= Some(true)` 符合此 API。
  None 单独不能证明可点击，但测试随后确实以坐标点击并检查准确 action 的 modal 转换，
  这一业务后置条件有效。`cx.read` 的旧编译问题也已不在读取的最终测试文本中。
- `visible()` 仅根据可见性、opacity 与裁切后面积判断，见 `:563–571`，
  并不证明没有被其他控件遮挡。这里额外的 containment 和实际点击断言有价值。
- 原始坐标事件进入 GPUI 的相同 dispatch/hit-test 逻辑，
  但绕过 AppKit NSEvent 转换。正常路径的
  `gpui-pre-macos-0.3.12/src/events.rs:269–295` 读取 scrollingDelta、
  precise/lines、phase 和窗口坐标。测试的 Default event 仅覆盖默认 Moved/Pointer。
  `window.rs:5919–5922` 自己用 ScrollEvent.position 更新鼠标位置，
  因此不能无证据归因于“测试多发了 MouseMove，正常事件一定不更新位置”。

## 原图与 source binding

独立打开既有截图 `02-fixed-pending-file-correct-target.jpg` 与
`04-fixed-wheel-repeat.jpg`，均位于 `work/mcp-scroll-native-20261117/captures/`。
所见正文及提案卡在同一位置，完整审核按钮仍在固定 footer 以下；文件名中
“review-reached”或“fixed”不构成成功证据。
没有操作 UI，没有独立重复父级的原生滚动动作。
这两份 AX 文本是“树无变化”的增量消息，并非包含完整布局坐标的 AX 树；
不能据此判定输入事件是否到达应用。

本次重新计算了两个正常包各五件文件的 SHA-256，**10/10 与各自 package-manifest 一致**：

- 旧包 app：`ea01dd8ee26245543bd2568ba82bf3d2703e79228dc15172abfa2e6c9fd0d845`；
- r1 app：`94e82f90297ea79d35dcc9f3546ca1ee1b56ed86b11e9224dfde6bd10d0f0447`。

r1 的 `normal-build-input-binding.json` 同时记录 777 项工程输入、390 项生产 Rust 输入，
其中 `mcp/view.rs` 明确绑定 r1 的 `048e38fd...`，并保存相符 production patch。
其 release 日志确实重新编译 app；不是只有一个基线 HEAD 标识。
当时测试文件仍是 7035 字节、`f8fa3075...`，
不等于本次最终 20983 字节、`9e7aa30c...`；普通包与新增测试二进制必须分别记录。
manifest 的 build.commit=null 与未提交状态相容，但必须保留外部输入绑定材料。

红/绿日志的可执行路径相同并不证明是同一份字节：
相同配置下重新构建通常复用该路径。当前 `.d` 文件同时列出
`mcp/view.rs` 和 `mcp_first_proposal.rs`，只能说明当前依赖图收录了它们，
不能反推旧运行执行时具体源码字节。
现有 restoration 回执记录旧/新摘要及精确还原，但没有在本次独立复核中得到
每次测试运行前后的完整冻结/二进制摘要链。因此不作缓存错绑的确诊。

本 checkout 连续持有同一 target，与跨 checkout 共享 target 的归属切换不同；
不应仅因红控制通过就要求无条件 clean。若切换源码副本、保留旧 mtime、
并行 Cargo 或冻结期间修改输入，应按 SHARED_TARGET 合同另行失效与核对库存。
Cargo 官方 fingerprint 文档也将源文件/dep-info mtime 列为新鲜度判断依据，
故单凭 HEAD、exit 0 或一个当前 manifest 不能代签某次历史执行的源码归属。

## 对未冻结 ScrollHandle/Always 方向的静态提示

这是后续设计提示，**不构成新候选审查或批准**。

Kit Scrollbar 通过 `gpui-component-0.10.0/src/scroll/mod.rs:5–8`
重导出 gpui-base 的实现。`gpui-base-0.10.0/src/scrollbar.rs:96–97`
通过同一个 handle 的 max_offset 加 viewport size 得到 content size。
即使 Always，`:1421–1425` 仍在 content size 不超过 viewport 时跳过该轴。
因此 Always 不会制造缺失的滚动范围；如果旧问题是 scroll_max=0，
仅添加可视滚动条不能单独解决。

建议父级最终冻结时核对两处 `.track_scroll()` 与实际 Scrollbar 使用同一份持有 handle，
分别验证 wheel 与 thumb/track 坐标输入、两处 modal 的 footer 和正文可达性。
新 overlay 不应遮住正文或改变滚轮传播。应测试真实长 diff，
并保留实际正常 release 的原图、进程身份、包摘要和输入绑定。
滚动条能拖动只证明该输入路线可用，不能代替原滚轮路径成功。

## 独立执行范围与未验证边界

- 独立产品构建、Cargo/测试/Clippy/格式化/依赖门禁运行：均 **0**。
- 独立原生 UI 操作：**0**；仅查看两张既有本地原图。
- 独立重新核对包成员摘要：**10 passed / 0 mismatch**。
- 父级原件读回：旧生产 4/0/0，r1 4/0/0；它们不是本 reviewer 独立运行。
- 只读 Git HEAD/diff；没有 Git 变更，没有写源码、docs、Cargo 配置或 target，
  没有创建测试进程、容器、网络或应用实例。
- 最终新候选及其补充测试、正常包原生通过、具体事件投递、运行中 max_offset、
  自然帧调度、900×580 真正原生窗口、Windows/Linux、辅助技术与发行均未验收。

下一步由父级完成并冻结候选后，另派独立审查。该报告不能用于代签后续修改。

完成写报告时检测到父级也更新了 mcp_first_proposal.rs。该新测试版本未复核；本报告测试结论仅绑定上述 9e7aa30c 前版。完成时所见摘要另存 SUMMARY.json，不将并发更新冒充已审输入。
