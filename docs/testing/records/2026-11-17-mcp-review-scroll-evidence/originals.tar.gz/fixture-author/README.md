# Network fixture settle — 2026-11-17

结论：两个授权 Python 测试文件已修正并冻结，可交给父级独立复核。最终独立模块 ICMP 20/20、traceroute 14/14，另有生命周期证据提取 2/2；全部 exit 0、实际 wait/reaped、无超时及 ResourceWarning。未运行 Cargo/Git、未操作 target/UI、未修改生产源码或 docs；全部工作记录只在本目录。

## 精确修订

- `test_icmp.py:257` 的 supervisor_fixture：版本与固定 DNS 成功帧仅作为本用例的前置结果返回，最终 fake ping 仍通过原生产 icmp_run_owned、真实 Popen、真实 selector、真实 deadline、真实 killpg/wait/close 执行。其他 AdapterTests 保持真实 fake 工具的版本/DNS过程。
- fake ping 先完成 PID 临时文件写入，再原子 rename 发布 ready。父级最多等待 5 秒（原来 2 秒），要求最终 PID 已发布且 os.kill(pid,0) 成功，之后才发送 HUP/TERM/INT。未延长生产 7.5 秒操作期限或原 8.5 秒整体断言，未将取消结果放宽成 timeout。
- supervisor 内的观察包装在生产 adapter 返回后，记录最终 owned child 的 returncode、os.waitpid(WNOHANG) 是否抛 ChildProcessError，以及两根输出 pipe 的 closed。必须恰好一个最终子进程、returncode=-SIGKILL、already_reaped、pipes_closed=true，且仅输出一个结构帧、没有计数。自然期限进一步要求 total_ms >= 7500。
- 父级 finally 无论 supervisor 是否已自行退出，都执行 communicate，并在嵌套 finally 显式关闭 stdin/stdout/stderr，保留失败路径的 fake group 兜底清理。
- `test_traceroute.py:206` 的 DNS selected-family 用例固定 version 与 resolver 阶段结果。分别严格要求 dns_failure/resolution_failed、traceroute_failure/invalid_output；只允许两次 runner 调用，完整核对 --version、resolver argv、解码后的 host/family。任何第三次 probe 调用都会耗尽 side_effect 而失败；地址/跳点必须为空。没有启动版本/resolver解释器去消耗本用例 deadline。
- 今天较早修正的 `test_real_supervisor_deadline_actually_waits_owned_fake_tool` 方法源码逐字节不变，最终模块运行也通过该真实进程生命周期测试。

## 原失败与本 worker 的失败

原完整 gate 日志仍在原路径，SHA 未变，本目录 `original-command.log` 保存逐字节副本；`original-test_icmp.py` 和 `original-test_traceroute.py` 保存改前原代码。
原 gate 的 ICMP 仅证明 2 秒时未观察到最终 PID；traceroute 的 timeout 不能反推出当时精确发生在 version 还是 resolver 阶段，该历史子阶段仍 UNKNOWN。本修订不声称重新查明原调度时序。

本 worker 首轮 `module-results.json`、`test_icmp.py.log`、`test_traceroute.py.log` 原件保留：ICMP 19 通过/1 失败，traceroute 14 通过；失败是我新增自然期限断言错误要求 >=7900ms，实际 7503ms。生产源码明确为 started+7.5 秒，保留 0.5 秒回收；因此第二版改为准确的 >=7500ms，并补原子 PID 发布。首轮源码 `r1-test_icmp.py` 和执行器 `run_modules-r1.py` 保留。没有以未改输入反复重试直到通过。

## 最终真实命令与结果

`python3 -I -S -B work/network-fixture-settle-20261117/run_modules.py`

执行器对每模块使用独立 TMPDIR、-I -S -B -Werror::ResourceWarning -v、60 秒外层期限，保存真实 stdout/stderr，并在 wait 后以 os.waitpid 的 ChildProcessError 验证回收。

- ICMP：20 run / 20 pass / 0 skipped，exit 0，reaped=true，11.171298 秒。
- traceroute：14 run / 14 pass / 0 skipped，exit 0，reaped=true，9.498459 秒。
- 详细 argv、PID、时间、SHA 见 `r2/module-results.json`，原输出在 `r2/test_icmp.py.log` 和 `r2/test_traceroute.py.log`。

额外运行 `capture_lifecycle.py` 是为提取真实断言值，只观察 assertEqual 成功后的值，不替换生产行为。命令/外层回收见 `lifecycle-command.json`，原输出 `lifecycle.log`，2/2 通过，exit 0/reaped，7.947704 秒：

- 取消：fake ping PID 14465，returncode=-9、already_reaped、pipes_closed=true。
- 自然期限：fake ping PID 14469，returncode=-9、already_reaped、pipes_closed=true。

## 冻结与复核入口

两个文件最终 SHA-256：

- `crates/keelshell-session/src/network_diagnostic/tests/test_icmp.py`: `b94f6285ead7c17d880b8c111689dee28ca3d6a2d30204a31233719c03a60403`
- `crates/keelshell-session/src/network_diagnostic/tests/test_traceroute.py`: `5ca70f3b7af5da7f459c4cab441980a78c91b7ddc92d4c484de059e1e24c2da0`

两文件排序清单 aggregate SHA-256：`5411a7c03d048b737fa4fa6cf3876b32ee27508eb238d2cf3ee8f3de869e2e53`。算法及时间见 `freeze.json`。
最终代码副本 `final-test_icmp.py` / `final-test_traceroute.py`；精确变更见对应 `.diff`。
`integrity.json` 核对生产 icmp.py/traceroute.py/probe.py、原 full-gate-r1/command.log 未变，以及既有 traceroute deadline 方法逐字节相等。

## 未验证边界

本 worker 仅 macOS 当前解释器下的独立离线 Python 验证；没有完整 Rust gate 的并行调度、三平台、真实 ICMP/traceroute网络、原生 UI 或发行验收。本例固定前置结果之后，不单独覆盖 version/DNS 子进程生命周期；同模块其余真实前置进程测试保持。原 gate 的精确超时子阶段 UNKNOWN 保留。父级独立复核和最终完整 gate 尚待执行。

源码输入现已稳定，交付后若需变更先发消息。本目录不承担独立 reviewer 的批准结论。
