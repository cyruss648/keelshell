"""Observe the exact lifecycle assertions without changing production behavior."""
import importlib.util
import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[2]
RECORD = Path(__file__).resolve().parent
path = ROOT / "crates/keelshell-session/src/network_diagnostic/tests/test_icmp.py"
spec = importlib.util.spec_from_file_location("icmp_test_receipt", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
receipts = []
suite = unittest.TestSuite()
for name in (
    "test_full_supervisor_repeated_shutdown_reaps_fake_ping_before_one_frame",
    "test_full_supervisor_eight_second_budget_reaps_fake_ping_without_invented_loss",
):
    case = module.OwnedProcessTests(name)
    original = case.assertEqual

    def observe(actual, expected, msg=None, *, check=original, test=name):
        check(actual, expected, msg)
        if isinstance(actual, list) and actual and isinstance(actual[0], dict) \
                and "reaped" in actual[0]:
            receipts.append({"test": test, "owned": actual})
            (RECORD / "owned-lifecycle.json").write_text(json.dumps(receipts, indent=2) + "\n")
    case.assertEqual = observe
    suite.addTest(case)
result = unittest.TextTestRunner(verbosity=2).run(suite)
print(json.dumps({"lifecycle_receipts": receipts}), flush=True)
raise SystemExit(not result.wasSuccessful() or len(receipts) != 2)
