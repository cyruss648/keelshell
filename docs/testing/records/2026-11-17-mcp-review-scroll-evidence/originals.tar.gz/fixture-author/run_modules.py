"""Run only the two authorized offline modules, preserving bounded receipts."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[2]
RECORD = Path(__file__).resolve().parent
RUN = RECORD / "r2"
RUN.mkdir(exist_ok=False)
TESTS = ROOT / "crates/keelshell-session/src/network_diagnostic/tests"
results = []
for name in ("test_icmp.py", "test_traceroute.py"):
    command = [sys.executable, "-I", "-S", "-B", "-Werror::ResourceWarning",
               str(TESTS / name), "-v"]
    with tempfile.TemporaryDirectory(prefix="isolated-", dir=RECORD) as temporary:
        environment = dict(os.environ, TMPDIR=temporary, PYTHONDONTWRITEBYTECODE="1")
        started = time.monotonic()
        log = RUN / (name + ".log")
        with log.open("wb") as output:
            child = subprocess.Popen(command, cwd=ROOT, env=environment,
                                     stdin=subprocess.DEVNULL, stdout=output,
                                     stderr=subprocess.STDOUT, start_new_session=True)
            timed_out = False
            try:
                code = child.wait(timeout=60)
            except subprocess.TimeoutExpired:
                timed_out = True
                os.killpg(child.pid, 9)
                code = child.wait(timeout=3)
        try:
            os.waitpid(child.pid, os.WNOHANG)
            reaped = False
        except ChildProcessError:
            reaped = True
        text = log.read_text()
        result = {
            "command": command, "cwd": str(ROOT), "pid": child.pid,
            "exit_code": code, "reaped": reaped, "timed_out": timed_out,
            "elapsed_seconds": round(time.monotonic() - started, 6),
            "resource_warning": "ResourceWarning:" in text,
            "log": str(log),
            "sha256": hashlib.sha256((TESTS / name).read_bytes()).hexdigest(),
        }
        results.append(result)
        (RUN / "module-results.json").write_text(json.dumps(results, indent=2) + "\n")
        print(json.dumps(result), flush=True)
        print(text, flush=True)
raise SystemExit(any(row["exit_code"] or not row["reaped"] or row["timed_out"]
                     or row["resource_warning"] for row in results))
