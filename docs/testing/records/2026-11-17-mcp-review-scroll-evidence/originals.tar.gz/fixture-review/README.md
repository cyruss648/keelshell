**结论：限定接纳两个测试夹具修订（APPROVE）。P0=0、P1=0、P2=0、P3=0；没有需要阻止候选继续的实质发现。**

本次作为新非作者，仅审查相对 `HEAD 9d57510f24efcb522a0bc6af51c440e817dcd5c5` 的两个指定 Python 文件差异。已读取项目 `AGENTS.md`、`/Users/hdh/.codex/RTK.md`、`docs/HANDOFF.md`。仅在本报告目录写入回执、报告与测试临时数据；临时数据自然清理完成。没有运行 Cargo、读取或写入 target、Git 写操作、UI 操作或联网。测试在 macOS sandbox 中明确禁止 network*，并限制文件写入到本目录（另允许系统 `/dev/null`）。

首次捕获时间为 `2026-11-17T08:55:35.232924+00:00`，末次完整核对为 `2026-11-17T09:00:25.734873+00:00`。HEAD、两个测试文件及三个生产文件均未检测到漂移，文件 inode/mtime 也与首次捕获相等。两个文件与作者最终冻结完全一致：

| 文件 | SHA-256 |
| --- | --- |
| `test_icmp.py` | `b94f6285ead7c17d880b8c111689dee28ca3d6a2d30204a31233719c03a60403` |
| `test_traceroute.py` | `5ca70f3b7af5da7f459c4cab441980a78c91b7ddc92d4c484de059e1e24c2da0` |

两文件排序清单 aggregate 为 `5411a7c03d048b737fa4fa6cf3876b32ee27508eb238d2cf3ee8f3de869e2e53`。生产 `icmp.py`、`probe.py`、`traceroute.py` 均独立通过 Git 基线与工作文件 SHA-256 比对，逐字节不变；精确摘要见 `initial-source-receipt.json` 与 `final-integrity-receipt.json`。AST 方法体比较只发现 `OwnedProcessTests.supervisor_fixture` 和 `AdapterTests.test_resolution_missing_selected_family_never_runs_tool_probe` 两处变化。

审查与实际核查依据如下：

1. [crates/keelshell-session/src/network_diagnostic/tests/test_icmp.py:262](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/network_diagnostic/tests/test_icmp.py:262)：fake ping 仍是真实 Python 子进程，发布完整 PID 后进入 `time.sleep(30)`。`.ready` 写完再原子 rename，消除“文件存在但 PID 未写完”的观察窗口。[crates/keelshell-session/src/network_diagnostic/tests/test_icmp.py:287](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/network_diagnostic/tests/test_icmp.py:287) 仅固定版本与既定 DNS 成功结果，最终命令仍调用 `_real_run`；没有替换生产 `Popen` 的生命周期实现、selector、monotonic、deadline、killpg 或 wait。
2. [crates/keelshell-session/src/network_diagnostic/tests/test_icmp.py:320](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/network_diagnostic/tests/test_icmp.py:320)：前置等待上限从 2 秒变为 5 秒，只用于观察最终进程。PID 存在且 `os.kill(pid, 0)` 成功之后，取消用例仍依次发送 HUP、TERM、INT。[crates/keelshell-session/src/network_diagnostic/tests/test_icmp.py:329](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/network_diagnostic/tests/test_icmp.py:329) 保留返回码 0、空 stderr、恰好一个结构帧、精确 status/reason、目标地址、implementation、counts 为 None，以及原有整体 `<8.5s` 断言。生产期限仍为 `started+7.5s`（`icmp.py:190`、`traceroute.py:124`），保留八秒总合同中的回收余量；新增 `total_ms>=7500` 符合该实际合同。
3. [crates/keelshell-session/src/network_diagnostic/tests/test_icmp.py:297](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/network_diagnostic/tests/test_icmp.py:297) 的观察在生产 adapter 返回后发生。[crates/keelshell-session/src/network_diagnostic/tests/test_icmp.py:340](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/network_diagnostic/tests/test_icmp.py:340) 必须恰好一个 owned child，returncode 为 `-SIGKILL`、`os.waitpid` 抛 `ChildProcessError`，且 stdout/stderr 均 closed。如果观察器自己才 wait/reap 了遗留 zombie，记录将是 tuple，无法满足 `already_reaped`，因此不会遮掩生产遗漏 wait。最终 PID 必须已不存在。[crates/keelshell-session/src/network_diagnostic/tests/test_icmp.py:348](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/network_diagnostic/tests/test_icmp.py:348) 在 supervisor 已退出时仍 communicate，并通过嵌套 finally 显式关闭管道，保留失败路径的所属 fake group 清理。
4. [crates/keelshell-session/src/network_diagnostic/tests/test_traceroute.py:206](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/network_diagnostic/tests/test_traceroute.py:206)：两个输入分别严格要求 `dns_failure/resolution_failed` 与 `traceroute_failure/invalid_output`，未接受 timeout。side_effect 只有两个前置结果；调用计数必须为 2，逐项核对 version argv、resolver argv 及解码后的 host/family，address/addresses/hops 必须为空。第三次 probe 会耗尽 side_effect 并使测试失败。
5. [crates/keelshell-session/src/network_diagnostic/tests/test_traceroute.py:273](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/network_diagnostic/tests/test_traceroute.py:273) 的真实 supervisor/睡眠 fake/期限/回收用例相对基线方法正文逐字节不变，独立完整模块运行也实际执行通过（该项耗时 7.569630 秒）。本次 scoped 修改未移除真实前置进程、取消、管道提前关闭、输出洪泛与拒绝 kill 后 UNKNOWN 等现存模块测试。

独立运行只有两次，每个完整模块各一次，没有盲目重试；没有借用作者的 20+14 或额外 2 项作为本人计数。执行形式为 `/usr/bin/sandbox-exec -p <回执中的完整profile> /opt/homebrew/opt/python@3.15/bin/python3.15 -I -S -B -Werror::ResourceWarning -c <回执中的完整observer源码> <模块绝对路径>`，通过 unittest loader 运行未修改的源文件。observer 只在原 unittest 断言成功后记录实际值，没有代换生产行为。完整 argv、observer 原文及 SHA、每项测试名称、stdout/stderr 原件均在 `independent-python-receipt.json`。

| 本人独立运行 | run / pass | failure / error / skipped | exit | 含进程普查的外层秒数 |
| --- | --- | --- | --- | --- |
| ICMP 完整模块 | 20 / 20 | 0 / 0 / 0 | 0 | 12.999869 |
| traceroute 完整模块 | 14 / 14 | 0 / 0 / 0 | 0 | 11.777199 |
| 合计 | 34 / 34 | 0 / 0 / 0 | 两次均 0 | 24.777068 |

没有 expected failure、unexpected success 或 ResourceWarning。生命周期两项包含在上述 ICMP 的 20 项中，不另加计数：

| 实际路径 | 最终 fake PID | returncode / reaped / pipes_closed | 单一结果帧 | 实际整体时间 |
| --- | --- | --- | --- | --- |
| 自然期限 | 35276 | -9 / already_reaped / true | 1 | 7.555335s；生产 report total_ms=7502 |
| HUP/TERM/INT 取消 | 35521 | -9 / already_reaped / true | 1 | 0.361409s |

本人执行器对每个模块使用独立 `start_new_session=True` Popen 进程组、45 秒外层有界监控、实际 wait，以及 finally 关闭 stdout/stderr。45 秒只约束完整测试模块，未进入或改变生产期限。没有一次触发外层超时或强制清理。两个模块根 PID 为 35045、35556，均 exit0；随后 waitpid 均为 ChildProcessError，进程组均已不存在。执行中追踪后代（含另起进程组的 final child），退出后普查未见已观察的所属 PID/命令身份或临时根路径进程遗留；临时目录均为空并已移除。进程普查是离散采样，不能声称记录了每个短寿命前置子进程；最终两个关键睡眠子进程另有上述 adapter 内实际 wait/pipe/PID 断言证据。

原 full-gate-r1 原件仍保留其 `420 passed / 2 failed / 4 ignored` 失败：`command.log:4235` 的 traceroute 错误为 timeout 不在允许的拒绝状态中；`:4260` 的 ICMP 错误为两秒时未观察到 pidfile，另有 ResourceWarning。旧失败不能确定当时超时发生在版本、resolver 还是最终进程，精确历史子阶段仍 UNKNOWN。原日志当前 SHA-256 为 `5641e6665c707dfe03b469e39c86ef8dabe56003cd68e87e17bb7a3f9cfab8ad`。作者首轮新增 >=7900ms 的错误断言及其失败原件也由其目录保留，本批准仅针对当前准确的 >=7500ms 冻结值。

接纳建议仅覆盖这两个测试夹具差异与本机离线 Python 行为；允许候选继续父级最终完整 gate。没有独立运行 Cargo/完整并发调度 gate、Linux/Windows 原生工具、真实网络、GUI、发行或业务验收；不将本报告作为这些范围的通过证据。前置结果固定的两个焦点用例本身不证明 version/DNS 子进程生命周期，其余模块测试与真实最终子进程证据分开理解。

本人产物恰为本目录中的 `README.md`、`initial-source-receipt.json`、`independent-python-receipt.json`、`final-integrity-receipt.json`、`natural-exit-receipt.json`。完整绝对路径和摘要由自然退出回执列出。本人测试进程均已自然退出并回收；reviewer 会话由父级关闭。
