"""Remove only expanded CI evidence already preserved in the exact Git commit."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[2]
COMMIT = "9d57510f24efcb522a0bc6af51c440e817dcd5c5"
DESTINATION = ROOT / "work/mcp-review-scroll-integration-20261117/monitor-ci-source-cleanup.json"
EVIDENCE = "docs/testing/records/2026-11-17-monitor-read-cancellation-evidence/ci-completion"
OWNED = (
    "work/monitor-cancellation-ci-completion-20261117",
    "work/monitor-cancellation-ci-review-20261117",
)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def protected():
    target = (ROOT / "work/recovery-batch-integration-20261115/target").stat()
    packages = []
    for name in (
        "work/mcp-client-native-20261117/package-r1",
        "work/windows-monitor-delivery-20261117/package-r2",
        "work/mcp-scrollbar-native-20261117/package-r1",
    ):
        parent = ROOT / name
        for path in sorted(parent.rglob("*")):
            if path.is_file():
                packages.append({
                    "path": str(path.relative_to(ROOT)),
                    "sha256": digest(path.read_bytes()),
                })
    return {"target": [target.st_dev, target.st_ino], "packages": packages}


assert not DESTINATION.exists()
manifest_path = EVIDENCE + "/manifest.json"
manifest_raw = subprocess.check_output(
    ["git", "show", f"{COMMIT}:{manifest_path}"], cwd=ROOT, timeout=15
)
assert (ROOT / manifest_path).read_bytes() == manifest_raw
manifest = json.loads(manifest_raw)
archive_raw = subprocess.check_output(
    ["git", "show", f"{COMMIT}:{EVIDENCE}/originals.tar.gz"],
    cwd=ROOT, timeout=15,
)
assert len(archive_raw) == manifest["bytes"]
assert digest(archive_raw) == manifest["sha256"]
assert archive_raw == (ROOT / EVIDENCE / "originals.tar.gz").read_bytes()
before = protected()
deleted = []
for owned in OWNED:
    parent = ROOT / owned
    assert parent.is_dir() and not parent.is_symlink()
    expected = {row["source"]: row for row in manifest["files"]
                if row["source"].startswith(owned + "/")}
    paths = list(parent.rglob("*"))
    assert not any(path.is_symlink() for path in paths)
    actual = {str(path.relative_to(ROOT)) for path in paths if path.is_file()}
    assert actual == expected.keys()
    for name, row in expected.items():
        raw = (ROOT / name).read_bytes()
        assert len(raw) == row["bytes"] and digest(raw) == row["sha256"]
    identity = parent.stat()
    deleted.append({
        "path": owned, "device": identity.st_dev, "inode": identity.st_ino,
        "files": len(expected), "logical_bytes": sum(row["bytes"] for row in expected.values()),
    })
for row in deleted:
    parent = ROOT / row["path"]
    identity = parent.stat()
    assert [identity.st_dev, identity.st_ino] == [row["device"], row["inode"]]
    shutil.rmtree(parent)
    assert not parent.exists()
after = protected()
assert before == after
result = {
    "binding_commit": COMMIT, "archive_sha256": digest(archive_raw),
    "removed": deleted, "protected_before": before, "protected_after": after,
    "protected_equal": True,
}
DESTINATION.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({
    "removed_directories": len(deleted),
    "removed_files": sum(row["files"] for row in deleted),
    "removed_logical_bytes": sum(row["logical_bytes"] for row in deleted),
    "protected_equal": True,
}))
