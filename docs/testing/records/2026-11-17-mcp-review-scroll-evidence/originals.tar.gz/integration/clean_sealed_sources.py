"""Remove owned expanded copies only after exact committed archive verification."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
EVIDENCE = "docs/testing/records/2026-11-17-mcp-review-scroll-evidence"
OUTPUT = ROOT / "work/mcp-review-scroll-integration-20261117/sealed-source-cleanup.json"
OWNED = {
    "work/connected-native-20261117",
    "work/mcp-scroll-fix-20261117",
    "work/mcp-scroll-native-20261117",
    "work/mcp-scroll-test-20261117",
    "work/mcp-scroll-diagnosis-review-20261117",
    "work/mcp-scrollbar-native-20261117",
    "work/mcp-scrollbar-source-review-20261117",
    "work/mcp-scrollbar-native-review-20261117",
    "work/network-fixture-settle-20261117",
    "work/network-fixture-independent-review-20261117",
    "work/monitor-cancellation-ci-seal-20261117",
}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def protected():
    target = (ROOT / "work/recovery-batch-integration-20261115/target").stat()
    packages = []
    for name in (
        "work/mcp-client-native-20261117/package-r1",
        "work/windows-monitor-delivery-20261117/package-r2",
        "work/mcp-scrollbar-native-20261117/package-r1",
    ):
        for path in sorted((ROOT / name).rglob("*")):
            if path.is_file():
                packages.append({"path": str(path.relative_to(ROOT)), "sha256": sha(path.read_bytes())})
    return {"target": [target.st_dev, target.st_ino], "package_files": packages}


assert len(sys.argv) == 2 and not OUTPUT.exists()
commit = sys.argv[1]
verification = subprocess.run(
    [sys.executable, "-B", str(ROOT / EVIDENCE / "verify.py"), "--commit", commit],
    cwd=ROOT, capture_output=True, timeout=60, check=True,
)
manifest = json.loads((ROOT / EVIDENCE / "manifest.json").read_text())
all_rows = manifest["files"] + manifest["excluded"]
assert OWNED == {row["source"] for row in manifest["source_roots"] if row["alias"] != "integration"}
before = protected()
sources = []
for name in sorted(OWNED):
    parent = ROOT / name
    identity = parent.stat()
    bound = next(row for row in manifest["source_roots"] if row["source"] == name)
    assert not parent.is_symlink() and [identity.st_dev, identity.st_ino] == [bound["device"], bound["inode"]]
    expected = {row["source"]: row for row in all_rows if row["source"].startswith(name + "/")}
    paths = list(parent.rglob("*"))
    assert not any(path.is_symlink() for path in paths)
    actual = {str(path.relative_to(ROOT)) for path in paths if path.is_file()}
    assert actual == expected.keys()
    for path, row in expected.items():
        raw = (ROOT / path).read_bytes()
        assert len(raw) == row["bytes"] and sha(raw) == row["sha256"], path
    sources.append((name, expected))
removed = []
retained = []
for name, expected in sources:
    parent = ROOT / name
    keep_package = name == "work/mcp-scrollbar-native-20261117"
    selected = []
    for path, row in expected.items():
        if keep_package and path.startswith(name + "/package-r1/"):
            retained.append(path)
            continue
        selected.append(row)
        (ROOT / path).unlink()
    for path in sorted((p for p in parent.rglob("*") if p.is_dir()), key=lambda p: len(p.parts), reverse=True):
        if not any(path.iterdir()):
            path.rmdir()
    if not any(parent.iterdir()):
        parent.rmdir()
    removed.append({
        "source": name, "removed_files": len(selected),
        "logical_bytes": sum(row["bytes"] for row in selected),
        "source_directory_removed": not parent.exists(),
    })
after = protected()
assert before == after
result = {
    "commit": commit, "archive_sha256": manifest["sha256"],
    "verification": json.loads(verification.stdout),
    "removed": removed, "retained_normal_package_files": retained,
    "protected_before": before, "protected_after": after, "protected_equal": True,
}
OUTPUT.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({
    "removed_files": sum(row["removed_files"] for row in removed),
    "removed_logical_bytes": sum(row["logical_bytes"] for row in removed),
    "removed_source_directories": sum(row["source_directory_removed"] for row in removed),
    "retained_normal_package_files": len(retained), "protected_equal": True,
}))
