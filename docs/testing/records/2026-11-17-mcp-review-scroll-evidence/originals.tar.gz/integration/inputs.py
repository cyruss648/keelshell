"""Freeze tracked and new non-document engineering inputs in this checkout."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]


def snapshot():
    names = subprocess.check_output(
        ["git", "ls-files", "-z", "--cached", "--others", "--exclude-standard"],
        cwd=ROOT, timeout=15,
    ).decode().split("\0")
    rows = []
    for name in sorted(set(names) - {""}):
        if name.startswith(("docs/", "work/")):
            continue
        raw = (ROOT / name).read_bytes()
        rows.append({
            "path": name, "bytes": len(raw),
            "sha256": hashlib.sha256(raw).hexdigest(),
        })
    return {
        "head": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True, timeout=10
        ).strip(),
        "count": len(rows), "inputs": rows,
        "aggregate_algorithm": "sha256(json.dumps(inputs, sort_keys=True, separators=(',', ':')).encode())",
        "aggregate_sha256": hashlib.sha256(json.dumps(
            rows, sort_keys=True, separators=(",", ":")
        ).encode()).hexdigest(),
    }


current = snapshot()
destination = BASE / sys.argv[1]
with destination.open("x") as output:
    json.dump(current, output, indent=2)
    output.write("\n")
if len(sys.argv) > 2:
    expected = json.loads((BASE / sys.argv[2]).read_text())
    assert current["inputs"] == expected["inputs"]
    assert current["aggregate_sha256"] == expected["aggregate_sha256"]
print(json.dumps({
    "snapshot": destination.name, "count": current["count"],
    "aggregate_sha256": current["aggregate_sha256"],
    "matches_expected": True if len(sys.argv) > 2 else None,
}))
