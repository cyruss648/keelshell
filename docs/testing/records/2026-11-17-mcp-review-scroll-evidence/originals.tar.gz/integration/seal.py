"""Archive the owned evidence; packages, runtime data and test binaries stay out."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[2]
DESTINATION = ROOT / "docs/testing/records/2026-11-17-mcp-review-scroll-evidence"
SOURCES = {
    "connected-native": "work/connected-native-20261117",
    "layout-controls": "work/mcp-scroll-fix-20261117",
    "viewport-native": "work/mcp-scroll-native-20261117",
    "test-author": "work/mcp-scroll-test-20261117",
    "diagnosis-review": "work/mcp-scroll-diagnosis-review-20261117",
    "scrollbar-native": "work/mcp-scrollbar-native-20261117",
    "source-review": "work/mcp-scrollbar-source-review-20261117",
    "native-review": "work/mcp-scrollbar-native-review-20261117",
    "fixture-author": "work/network-fixture-settle-20261117",
    "fixture-review": "work/network-fixture-independent-review-20261117",
    "monitor-ci-seal": "work/monitor-cancellation-ci-seal-20261117",
    "integration": "work/mcp-review-scroll-integration-20261117",
}


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


gate = json.loads((ROOT / SOURCES["integration"] / "full-gate-r2/result.json").read_text())
assert gate["exit_code"] == 0 and gate["reaped"] and not gate["timed_out"]
inputs = json.loads((ROOT / SOURCES["integration"] / "inputs-r2.json").read_text())
after = json.loads((ROOT / SOURCES["integration"] / "inputs-after-r2.json").read_text())
assert inputs["inputs"] == after["inputs"]
inventory = json.loads((ROOT / SOURCES["integration"] / "full-gate-r2-inventory/summary.json").read_text())
assert inventory["all_inventory_names_match"] and inventory["all_binary_digests_unchanged"]
DESTINATION.mkdir(exist_ok=True)
archive = DESTINATION / "originals.tar.gz"
assert not archive.exists()
files, excluded, roots = [], [], []
with archive.open("xb") as output, gzip.GzipFile(fileobj=output, mode="wb", mtime=0, filename="") as zipped:
    with tarfile.open(fileobj=zipped, mode="w|") as target:
        for alias, name in SOURCES.items():
            source = ROOT / name
            identity = source.stat()
            roots.append({"alias": alias, "source": name, "device": identity.st_dev, "inode": identity.st_ino})
            for path in sorted(source.rglob("*")):
                assert not path.is_symlink(), str(path)
                if path.is_dir():
                    continue
                assert path.is_file(), str(path)
                relative = path.relative_to(source)
                reason = None
                if relative.parts[0].startswith("package-"):
                    reason = "Normal package excluded from Git; exact per-file hashes retained."
                elif relative.parts[0].startswith("runtime-"):
                    reason = "Disposable application/test runtime data excluded."
                elif relative.name == "keelshell-app-tests":
                    reason = "Reviewer copied prebuilt binary excluded; exact provenance retained."
                raw = path.read_bytes()
                row = {
                    "source": str(path.relative_to(ROOT)), "bytes": len(raw),
                    "sha256": digest(raw),
                }
                if reason:
                    excluded.append(dict(row, reason=reason))
                    continue
                member = f"{alias}/{relative.as_posix()}"
                info = tarfile.TarInfo(member)
                info.size = len(raw)
                info.mode = 0o644
                target.addfile(info, io.BytesIO(raw))
                files.append(dict(row, member=member))
manifest = {
    "schema_version": 1, "source_roots": roots, "files": files, "excluded": excluded,
    "members": len(files), "logical_bytes": sum(row["bytes"] for row in files),
    "bytes": archive.stat().st_size, "sha256": digest(archive.read_bytes()),
    "final_engineering_inputs": inputs["count"],
    "final_engineering_aggregate": inputs["aggregate_sha256"],
    "boundary": "Exact evidence only. Native r1 production equals final production; three test-only revisions differ. Wheel P2/root UNKNOWN, compact native and other platforms remain open.",
}
(DESTINATION / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({k: manifest[k] for k in ("members", "logical_bytes", "bytes", "sha256", "final_engineering_inputs", "final_engineering_aggregate")}))
