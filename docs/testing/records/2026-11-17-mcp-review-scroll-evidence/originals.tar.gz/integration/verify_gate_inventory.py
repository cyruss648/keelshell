"""Compare each ordinary gate suite with its exact compiled binary inventory."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
label = sys.argv[1]
gate = BASE / label / "command.log"
text = gate.read_text()
workspace = text.split(
    "Running: cargo test --workspace --locked -- --test-threads=4\n", 1
)[1].split("Running: cargo test -p keelshell-ai", 1)[0]
destination = BASE / (sys.argv[2] if len(sys.argv) > 2 else label + "-inventory")
destination.mkdir()
suites = []
interleaved = []
current = None
for line_number, original_line in enumerate(workspace.splitlines(), 1):
    # Embedded Python helper unittest prefixes can split libtest's writes.
    # Remove only the fully identified Python prefix, never a test outcome.
    line = re.sub(r"test_\S+ \(__main__\.[^)]+\) \.\.\. ", "", original_line)
    if line != original_line and re.search(r"\btest \S+ \.\.\. ", line):
        interleaved.append({
            "workspace_relative_line": line_number,
            "original": original_line,
            "without_python_prefix": line,
        })
    match = re.match(r"\s*Running (?:unittests|tests/).* \(([^)]+)\)$", line)
    if match:
        current = {"binary": match[1], "results": {}}
        suites.append(current)
    elif line.strip().startswith("Doc-tests "):
        current = None
    elif current is not None:
        # Child diagnostics can precede libtest's complete status on the same
        # merged stdout/stderr line. Exact binary-name and summary checks below
        # still reject missing, extra or duplicate Rust test results.
        outcome = re.search(
            r"\btest ([^\s]+) \.\.\. (ok|ignored|FAILED)(?:,.*)?$",
            line,
        )
        if outcome:
            assert outcome[1] not in current["results"]
            current["results"][outcome[1]] = outcome[2]
        summary = re.match(
            r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;", line
        )
        if summary:
            current["summary"] = [int(value) for value in summary.groups()]
assert suites
custom = [suite for suite in suites if "summary" not in suite]
assert all(Path(suite["binary"]).name.startswith(
    ("local_agent_process-", "local_agent_directory_process-")
) for suite in custom)
suites = [suite for suite in suites if "summary" in suite]


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as content:
        for chunk in iter(lambda: content.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


for index, suite in enumerate(suites):
    binary = (ROOT / suite["binary"]).resolve()
    assert binary.is_relative_to(ROOT / "work/recovery-batch-integration-20261115/target")
    before = digest(binary)
    result = subprocess.run(
        [str(binary), "--list"], cwd=ROOT, capture_output=True,
        text=True, timeout=15, check=False,
    )
    (destination / f"{index:03d}.log").write_text(result.stdout + result.stderr)
    listed = re.findall(r"^(.+): test$", result.stdout, re.MULTILINE)
    suite.update(
        inventory_exit=result.returncode, inventory_names=listed,
        binary_sha256=before,
        binary_unchanged=before == digest(binary),
        inventory_matches=sorted(listed) == sorted(suite["results"]),
    )
    assert result.returncode == 0 and suite["binary_unchanged"] and suite["inventory_matches"], suite["binary"]
    assert len(set(listed)) == len(listed)
    assert suite["summary"] == [
        sum(outcome == status for outcome in suite["results"].values())
        for status in ("ok", "FAILED", "ignored")
    ]
summary = {
    "gate_log_sha256": digest(gate),
    "suite_count": len(suites),
    "passed": sum(suite["summary"][0] for suite in suites),
    "failed": sum(suite["summary"][1] for suite in suites),
    "ignored": sum(suite["summary"][2] for suite in suites),
    "all_inventory_names_match": True,
    "all_binary_digests_unchanged": True,
    "normalization": "Only identified embedded Python unittest prefixes are removed; all result tokens and original log bytes are preserved. Shared ok tokens have equal status, and the exact Rust name inventory and aggregate result counters must both match.",
    "interleaved_python_prefixes": interleaved,
    "custom_harnesses_excluded_from_list_execution": [suite["binary"] for suite in custom],
    "suites": suites,
    "boundary": "Ordinary compiled inventory only; two harness=false controllers have no libtest list and are covered by the gate's actual executions. No behavioral rerun or native acceptance.",
}
with (destination / "summary.json").open("x") as output:
    json.dump(summary, output, indent=2)
    output.write("\n")
print(json.dumps({key: value for key, value in summary.items() if key != "suites"}))
