"""Run bounded offline verification and preserve every attempt."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys
import time

stage = Path(__file__).resolve().parent
root = stage.parents[1]
name, *flags = sys.argv[1:]
assert name and all(c.isalnum() or c in "-_" for c in name)
assert not (stage / (name + ".receipt.json")).exists()
script = root / "docs/testing/records/2026-11-17-monitor-read-cancellation-evidence/ci-completion/verify.py"
argv = [sys.executable, "-B", str(script), *flags]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
clock = time.monotonic()
result = subprocess.run(argv, cwd=root, capture_output=True, timeout=90)
receipt = {
    "argv": argv, "started_utc": started,
    "elapsed_seconds": round(time.monotonic() - clock, 6),
    "returncode": result.returncode, "natural_exit": True,
    "reaped": True, "timed_out": False,
    "verifier_sha256": hashlib.sha256(script.read_bytes()).hexdigest(),
}
for channel in ("stdout", "stderr"):
    data = getattr(result, channel)
    (stage / (name + "." + channel)).write_bytes(data)
    receipt[channel + "_bytes"] = len(data)
    receipt[channel + "_sha256"] = hashlib.sha256(data).hexdigest()
(stage / (name + ".receipt.json")).write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt))
if result.returncode:
    print(result.stderr.decode())
else:
    data = json.loads(result.stdout)
    print(json.dumps({k: data[k] for k in
                      ("source", "sources", "passed", "failed", "mismatches")}))
sys.exit(result.returncode)
