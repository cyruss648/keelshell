"""Deterministically archive every regular source member, without changing sources."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tarfile

STAGE = Path(__file__).resolve().parent
ROOT = STAGE.parents[1]
BASE = ROOT / "docs/testing/records/2026-11-17-monitor-read-cancellation-evidence/ci-completion"
ROOTS = {
    "collector": "work/monitor-cancellation-ci-completion-20261117",
    "review": "work/monitor-cancellation-ci-review-20261117",
}
before = json.loads((STAGE / "source-before.json").read_bytes())
after, rows = {}, []
buffer = io.BytesIO()
with gzip.GzipFile(fileobj=buffer, mode="wb", filename="", mtime=0) as zipped:
    with tarfile.open(fileobj=zipped, mode="w", format=tarfile.PAX_FORMAT) as archive:
        for prefix, relative in ROOTS.items():
            snapshot = []
            paths = []
            for directory, dirs, names in os.walk(ROOT / relative, followlinks=False):
                assert all(not (Path(directory) / name).is_symlink() for name in dirs)
                paths.extend(Path(directory) / name for name in names)
            for path in sorted(paths):
                assert stat.S_ISREG(path.lstat().st_mode)
                raw = path.read_bytes()
                relative_name = path.relative_to(ROOT / relative).as_posix()
                digest = hashlib.sha256(raw).hexdigest()
                snapshot.append({"path": relative_name, "bytes": len(raw), "sha256": digest})
                member = prefix + "/" + relative_name
                info = tarfile.TarInfo(member)
                info.size, info.mode, info.mtime = len(raw), 0o644, 0
                archive.addfile(info, io.BytesIO(raw))
                rows.append({"member": member, "source": relative + "/" + relative_name,
                             "bytes": len(raw), "sha256": digest})
            after[relative] = snapshot
assert after == before, "source member sets or bytes changed"
assert len(rows) == 449 and sum(row["bytes"] for row in rows) == 13052356
raw = buffer.getvalue()
manifest = {
    "schema_version": 1, "members": len(rows),
    "logical_bytes": sum(row["bytes"] for row in rows),
    "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
    "engineering_source": "6ae91d2e90668e7d9c04a2a7eea7c5de1bf6d3d4",
    "excluded": [], "files": rows,
}
(BASE / "originals.tar.gz").write_bytes(raw)
(BASE / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
(STAGE / "source-after.json").write_text(json.dumps(after, indent=2) + "\n")
(STAGE / "seal-result.json").write_text(json.dumps({
    key: value for key, value in manifest.items() if key != "files"
}, indent=2) + "\n")
print(json.dumps({key: value for key, value in manifest.items() if key != "files"}))
