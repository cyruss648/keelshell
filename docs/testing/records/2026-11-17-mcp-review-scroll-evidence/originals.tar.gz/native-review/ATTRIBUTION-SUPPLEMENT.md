ship

**2026-11-17 证据归属P2补审——仅限r1正常包原生子集**

新增证据归属P2在限定r1正常包原生范围内关闭。原发现、三项真实差异、首次24通过／1失败检查，以及原报告的 `fix` 结论全部保留；本补充记录给出其后续处置。最终开放 findings：P0=0、P1=0、P2=1、P3=0。唯一开放项为原生滚轮未位移，ROOT UNKNOWN保持OPEN。

最终限定状态为 `APPROVE_SCOPED_NATIVE_EVIDENCE / Hallmark ship`：批准原r1正常包的显式拖动通路、完整文件审核首尾／固定footer、文件完整读回与命令拒绝证据。完整native、供应商／模型、900×580、IME／辅助技术、其他平台和发行继续HOLD。本补审没有重看图片、操作GUI或重跑产品；没有Cargo、Git、网络、模型或供应商调用，所有新文件仅写入原review目录。

**独立清单与包核对**

读取新增 [normal-build-final-test-differences.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/normal-build-final-test-differences.json:1)，并以原始r1/r2清单逐项重新比较，而非仅采信其中 `production_scope_equal=true`。

| 核对项 | 本次独立结果 |
| --- | --- |
| 两版输入数量与路径集合 | 各777项、无重名，路径集合相同。 |
| r1归属 | normal-build-input-binding的全部777条记录与inputs-r1逐项相等，source_base与r1的head字段相符。此为记录归属核对，没有把base HEAD提升为未提交修订的commit identity。 |
| r1 aggregate复算 | 按清单声明算法 `sha256(json.dumps(inputs, sort_keys=True, separators=(',', ':')).encode())`，独立复算为 `21c81c898b3015147794525858c292303f73f2749dff6eeb8225086a7ece5f6c`，与r1及正常包绑定相等。 |
| r2 aggregate复算 | 同算法独立复算为 `5b5c1d2887d21ecf7e721d212e81f9f64acfe574b6ba32689dd9c6ad0cbb1e12`，与r2及新增差异记录相等。 |
| r1→r2差异 | 774条相等，恰好3条测试文件不同；每条原／新bytes及SHA均与新增差异记录和首次review的current-input-drift.json相等。 |
| 当前文件读回 | 本次补审时实际读取777项，全部与r2对应记录匹配。这是工程清单内的核对，不包括docs、work或Git状态，未宣称整个工作树一致。 |
| 正常包 | 实际重读6个包文件，大小及SHA全部同时匹配原normal-build绑定和新增package_files_verified。app仍为 `cb963bbce61dd5af79770064a98c61ba524bc8fcaeed8e32a82e6392041c456b`。 |
| 包交付身份 | manifest仍为commit=null、installed=false、signed_by_packaging_script=false。没有以r2清单的head字段代签r1包已提交、已安装或已签名。 |

r1、r2原始清单分别为 [inputs-r1.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-review-scroll-integration-20261117/inputs-r1.json) 和 [inputs-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-review-scroll-integration-20261117/inputs-r2.json)。聚合算法见 [inputs.py:31](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-review-scroll-integration-20261117/inputs.py:31)；本reviewer未执行该脚本中的Git调用，使用自己的只读比较代码复算。

正常构建回执 [normal-release-r2/result.json:2](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-review-scroll-integration-20261117/normal-release-r2/result.json:2) 的argv为普通 `cargo build -p keelshell-app -p keelshell-mcp --release --locked`，记录exit0／reaped／152.481352秒。此目录名中的r2是构建尝试编号；本报告的r1/r2输入身份以清单aggregate及normal-build绑定为准，不按目录后缀猜测。没有执行构建或从该argv声称已审计全部历史编译环境。

**三项差异的测试边界**

| 差异文件 | 完整纳入链与本次判断 |
| --- | --- |
| [mcp_first_proposal.rs](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/workspace/tests/mcp_first_proposal.rs:1) | [workspace.rs:56](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/workspace.rs:56) 的 `#[cfg(test)] pub(crate) mod tests` → [tests.rs:2182](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/workspace/tests.rs:2182) 的 `mod mcp` → [tests/mcp.rs:8](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/workspace/tests/mcp.rs:8) 的path子模块。修改文件在测试配置子树内，普通正常包不会编译此模块；不要求该文件自身重复写cfg(test)。 |
| [test_icmp.py](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/network_diagnostic/tests/test_icmp.py:1) | [network_diagnostic.rs:639](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/network_diagnostic.rs:639) 的 `#[cfg(test)] mod tests` → [tests.rs:12](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/network_diagnostic/tests.rs:12) 的 `mod icmp` → [icmp.rs:1](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/network_diagnostic/tests/icmp.rs:1) 的文件级cfg(test)。Python路径仅由 [icmp.rs:190](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/network_diagnostic/tests/icmp.rs:190) 的Unix测试函数190–205行启动，不是生产adapter载荷；该Python反向导入生产icmp.py以测试。 |
| [test_traceroute.py](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/network_diagnostic/tests/test_traceroute.py:1) | 同一network_diagnostic的cfg(test)父模块 → [tests.rs:15](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/network_diagnostic/tests.rs:15) 的 `mod traceroute` → [traceroute.rs:1](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/network_diagnostic/tests/traceroute.rs:1) 的文件级cfg(test)。Python路径仅由 [traceroute.rs:274](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/network_diagnostic/tests/traceroute.rs:274) 的Unix测试函数274–289行启动；其导入生产adapter用于离线测试，不会因此成为正常包生产输入。 |

上述纳入链的7个Rust文件及应用build.rs共8项，在r1/r2清单中均相等，本次当前文件读回也与之相符。因此测试边界同时适用于两版清单，不是只根据后来修改的cfg推断旧版边界。在777清单的Rust／Python／TOML文本中检索三个差异文件名，只找到表中这三处测试引用；应用唯一build.rs用于Windows图标／版本资源，没有引入这些测试正文。除这3个测试文件外的774项全部保持一致，支持“正常包生产输入未随这3项最终测试修订变化”的限定判断。

本次核对没有重新执行三项测试，也不评判它们的测试充分性或r2门禁终态。r1包不包含r2新增测试库存；本补审仅建立生产输入相同及原正常包身份的证据链，不代签r2测试已进入r1二进制。

**文档边界与P2处置**

已读更新后的测试记录：[98行](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/testing/records/2026-11-17-mcp-review-scroll.md:98) 绑定r1冻结输入，[105行](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/testing/records/2026-11-17-mcp-review-scroll.md:105) 说明正常包，[111行](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/testing/records/2026-11-17-mcp-review-scroll.md:111) 说明全部输入／六件摘要及未提交身份，[141行](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/testing/records/2026-11-17-mcp-review-scroll.md:141) 限定原生子集，[151行](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/testing/records/2026-11-17-mcp-review-scroll.md:151) 说明测试修订不改正常包生产输入，[153行](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/testing/records/2026-11-17-mcp-review-scroll.md:153) 保留首轮完整门禁失败及后续另记。

三项差异仍真实存在；新增逐项归属、测试边界和明确的文档限定已消除原P2在r1原生证据范围内的归属风险。关闭范围仅为该P2的r1包归属，不把当前工程、r2完整gate、未来HANDOFF或提交状态纳入批准。本补审未读取r2完整gate终态，不报告成功，也不等待或干预父级门禁。用户说明HANDOFF将稍后同步，本补审未代签尚未核对的同步。

原报告的滚轮P2继续OPEN，原图02/03未位移、ROOT UNKNOWN和完整native HOLD均保持。图04/08的drag成功、05/06的首尾／固定footer与客户端读回仍按原报告限定批准，不新增GUI证据。

本补审31项离线证据检查全部通过、0失败；不是31项产品测试。首次补审范围检索曾因不存在的可选路径 `crates/keelshell-session/build.rs` 和 `.cargo` 两次退出2，随后在实际存在的路径内重查成功，未安装或创建这些路径，也未运行代码。六份原review文件的bytes／SHA在补审前后完全相等，原发现及失败原件未被覆盖。机器结果见 [attribution-supplement-checks.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-review-20261117/attribution-supplement-checks.json)，本次读取21份关键材料的摘要见 [attribution-supplement-inputs.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-review-20261117/attribution-supplement-inputs.json)。

补审完成，本reviewer工作结束，可关闭reviewer。继续实现时应保留显式滚动条、固定审核footer、完整目标／内容／摘要、原失败和全部未验收边界。
