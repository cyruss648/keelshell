fix

**2026-11-17 新非作者原生视觉／功能原件复核**

限定结论：本正常包的可见拖动通路、完整文件审核首尾与固定 footer、文件写后读回和命令拒绝，批准为 `APPROVE_SCOPED_NATIVE_EVIDENCE`。所检视觉子集为 `ship`；完整原生功能／工程交付为 `fix / HOLD`。原生滚轮未位移仍开放，且本次发现当前工作树有三项测试输入偏离原冻结清单。P0=0、P1=0、P2=2（历史功能问题1、当前证据归属问题1）、P3=0；不是新增两项源码缺陷。

本 reviewer 没有参与实现，实际逐张调用 `view_image` 查看15张新原始JPEG，读取其全部15份AX文本；另只查看获准的两张旧对照（connected-native/10、mcp-scroll-native/04）及其文本。未查看或采用旧01 wrongtarget。没有独立GUI重跑、启动应用、Podman／SSH调用、网络、模型／供应商请求、Cargo、Git、测试运行或图片修改。唯一写入目录为本报告所在 review 目录。图片工具显示时自动缩小了预览，输入文件保持原JPEG字节；下述 y 坐标为2880×1866原图的大致像素行，AX行号为实际文本文件行号。

已读 AGENTS.md、RTK.md、docs/HANDOFF.md、docs/design/HALLMARK_NATIVE.md 和用户授权的 Hallmark 技能及 app-screen／finish 规则。按项目原生映射审阅既有Kit组件，不运行网页render或生成替代页面。历史记忆仅用于查找复核边界和报告习惯；本包、原图和回执结论来自本次读取。

**身份与失败记录**

正常 app 的SHA-256为 `cb963bbce61dd5af79770064a98c61ba524bc8fcaeed8e32a82e6392041c456b`，MCP二进制为 `8579a3188d4d4af85bcd2efc67d87a2891dc61ba7d7aa88c1497753985b4148e`。实际读取并哈希核对绑定中的6个包文件，全部匹配。manifest 的 `build.commit=null`、`installed=false`、`signed_by_packaging_script=false`，不授予提交、安装、签名或发行身份。包路径是本次 work/mcp-scrollbar-native-20261117/package-r1，不能沿用 HANDOFF 中旧正常包的身份。

绑定声明基线 `e394f6d16a448b7f8c3617451749d0d4ebc1b05a`，777输入 aggregate `21c81c898b3015147794525858c292303f73f2749dff6eeb8225086a7ece5f6c`。本次逐项核对了全部777项的路径、大小和SHA；774项匹配，3项测试文件不匹配。aggregate 是原记录的声明，本 reviewer 没有独立推导生产方aggregate算法，不能报告“复算aggregate成功”。具体差异保存于 [current-input-drift.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-review-20261117/current-input-drift.json)。

离线核对为25项分组检查、24通过／1失败，失败是上述777输入当前一致性。它们是证据检查，不是25项产品测试；独立产品运行数为0。首次元数据检查因环境没有PIL而退出1，随后用标准库只读解析JPEG SOF，未安装依赖；首失败保存在 [review-tooling-failure.txt](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-review-20261117/review-tooling-failure.txt)。完整分组结果在 [offline-checks.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-review-20261117/offline-checks.json)，30份新捕获及11份相关输入的大小／摘要在 [input-manifest.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-review-20261117/input-manifest.json)。

**逐图观察**

以下“可见”均来自实际图像检查，不用AX存在某按钮代替屏幕可达性。每行列出对应完整AX原文的关键行；图片与文本均属于新 captures 目录。

| 原图 | 实际观察、首尾／footer与限度 | AX原文定位 |
| --- | --- | --- |
| [01 native-profile](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/captures/01-native-profile.jpg) | 英文工作台和1条自有连接可见，host 127.0.0.1、port42121。表格名称列省略成长名开头，同行端点与Connect仍能辨识；不声称已经显示完整长名或处于连接状态。右上设置／语言入口没有横向裁掉。 | [01 AX:59](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/captures/01-native-profile.ax.txt:59)，59–66保留完整名称及对应动作。 |
| [02 pending-file](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/captures/02-pending-file-with-visible-scrollbar.jpg) | 主MCP面板顶部、六个高亮能力和/home/ksnative可见；明确选区／监控缓存未高亮。右侧有可见滑块。底部提案仅露路径及原SHA，审核按钮仍在当前视口外；固定授权footer完整，不能把此图算作审核入口已可见。 | [02 AX:9](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/captures/02-pending-file-with-visible-scrollbar.ax.txt:9)，9–17列能力／路径；22虽有Open full file review，但不证明其可见；26–28是footer。 |
| [03 wheel-observation](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/captures/03-native-wheel-observation.jpg) | 与02相比，正文、提案和滑块所在位置未见位移，审核按钮仍未露出；鼠标位置变化不能算滚动成功。固定footer仍完整。 | [03 AX:3](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/captures/03-native-wheel-observation.ax.txt:3)，全34行与02相同；静态AX相同本身不能证明几何变化。 |
| [04 scrollbar-reaches-review](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/captures/04-native-scrollbar-reaches-file-review.jpg) | 正文已向下，滑块接近底端；完整文件提案、原→新SHA、Reject和Open full file review完整可见，按钮约在y1225–1285，明显位于固定footer上方。客户端模板区也可见。主面板拖动可达性成立，不能转换成滚轮成功。 | [04 AX:21](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/captures/04-native-scrollbar-reaches-file-review.ax.txt:21)，21–22审核动作；26–28固定footer。 |
| [05 complete-review-top](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/captures/05-complete-file-review-top.jpg) | 完整文件审核顶部显示长连接名、准确路径、端点、connection/session/route/action/digest、原新SHA和SFTP并发限制。diff首部可读：--- original、+++ replacement、原文两行删除及新增开头。底部三动作固定且完整，约y1560–1660，不受正文长度挤压。当前焦点外观在顶部System，不能签署键盘确认路径。 | [05 AX:8](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/captures/05-complete-file-review-top.ax.txt:8)，8是准确路径，9–11为暂不处理／拒绝／准确确认；完整17行未导出diff正文。 |
| [06 complete-review-bottom](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/captures/06-complete-file-review-bottom.jpg) | 滑块已到底，末尾新增文本及其下的留白可见，约y1460–1535；固定三动作保持与05相同位置，无正文盖住按钮。可确认首尾两个视口及footer可达。当前底部不再显示路径／目标身份，不声称目标标题是sticky；两张静态图不证明中间每一行都被逐行阅读。 | [06 AX:9](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/captures/06-complete-file-review-bottom.ax.txt:9)，9–11与05相同；AX仍只有路径及动作，不是完整正文的辅助技术证明。 |
| [07 file-succeeded-command-pending](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/captures/07-file-succeeded-command-pending.jpg) | 文件提案显示Succeeded及新SHA；下一条命令显示Awaiting human review，命令行刚好露在正文底部，审核按钮仍在视口外。footer完整。Action proposals(1)与一条待审、另一条历史成功的组合一致，不应误读为总历史条数。 | [07 AX:21](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/captures/07-file-succeeded-command-pending.ax.txt:21)，21–22为命令拒绝／执行动作；它们在AX存在仍不等于此图可见。 |
| [08 command-review-reachable](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/captures/08-command-review-reachable.jpg) | 主bar更低位置使完整命令、Reject和Confirm target and run this command均可见，约y1225–1285；文件成功记录仍可见，模板区与固定授权footer也可见。审核对象没有被footer遮挡。 | [08 AX:21](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/captures/08-command-review-reachable.ax.txt:21)，21–22可与实际按钮配对。 |
| [09 command-rejected](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/captures/09-command-rejected.jpg) | 命令状态变Rejected，操作提案(0)，文件Succeeded保留。待审确认／拒绝按钮不再显示，命令原文仍在记录内。静态画面不独立证明远端无任何exec；客户端状态检查支持本次拒绝结果。 | [09 AX:19](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/captures/09-command-rejected.ax.txt:19)，后续是清理、模板与授权动作，原21/22审核动作已消失。 |
| [10 Frost 中文撤权](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/captures/10-frost-zh-revoked-records.jpg) | “MCP已关闭，全部临时授权已撤销”、空授权区、成功／拒绝历史均可见；模板复制及临时配置复制呈禁用，footer完整。授权此会话此刻仍启用，下一图变禁用；不得声称切换主题时所有状态完全相同。 | [10 AX:22](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/captures/10-frost-zh-revoked-records.ax.txt:22)，22与24禁用，25授权动作未标disabled。 |
| [11 Graphite 中文](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/captures/11-graphite-zh-records.jpg) | 暖黑背景、较亮面板与代码底色分层清楚；长名和“已成功／已拒绝”完整，滑块在深背景上容易识别。复制及授权按钮均灰化。没有全黑底白色大块或层级反转。 | [11 AX:22](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/captures/11-graphite-zh-records.ax.txt:22)，22、24、25标disabled。 |
| [12 Graphite 英文](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/captures/12-graphite-en-records.jpg) | 英文状态／拒绝记录／长名完整，footer动作标签单行且未横向截掉。模板说明在当前正文下缘有自然滚动裁切，不是footer文字被遮挡，也不证明全文已读到末尾。 | [12 AX:23](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/captures/12-graphite-en-records.ax.txt:23)，23–25固定动作与禁用状态。 |
| [13 Lavender 英文](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/captures/13-lavender-en-records.jpg) | 淡紫surface、较深画布和低饱和选中胶囊保持同一布局；长名、两条状态、SHA和命令可读；主bar可见。英文模板说明同样在下缘滚动裁切，footer本身完整。 | [13 AX:23](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/captures/13-lavender-en-records.ax.txt:23)，23–25与12同种状态。 |
| [14 Lavender 中文](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/captures/14-lavender-zh-records.jpg) | 中文模板说明在本视口内完整，成功／拒绝记录保留，长名称与中文状态同一行完整；footer不裁切。色彩柔和，按钮圆角比Frost更明显，但没有压过真实内容。 | [14 AX:22](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/captures/14-lavender-zh-records.ax.txt:22)，22、24、25为禁用动作。 |
| [15 close-review](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/captures/15-native-close-review.jpg) | 关闭审核说明会放弃未保存草稿、撤销审核并关闭SSH，列出1 SSH及1文件草稿快照；取消和红色确认关闭均完整可见，未用普通成功色混淆危险动作。此图是退出前的确认，不能独自证明退出。 | [15 AX:9](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/captures/15-native-close-review.ax.txt:9)，fresh索引7为确认关闭，完整树15行。 |

**真实功能证据及边界**

六个能力的高亮和授权路径由02图支持；AX只列普通按钮，不提供能力checked值，不能仅凭AX数出“六项已授权”。八工具枚举的成功由客户端脚本79–80行断言及 pending JSON 13行支持；回执没有保存完整tools/list原始八项载荷，不能据此宣称逐项工具schema已独立复核。八项可枚举也不等于八种远端行为都实际执行。

自有Python stdio脚本明确使用本包MCP进程、loopback临时能力；本 reviewer 只读脚本，没有执行pbpaste或读取能力值。脚本84–106行先SFTP读原文、提出文件修改、查pending，再SFTP读回原SHA；[pending回执:9](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/mcp-file-proposal-pending.json:9)的9–14行与之吻合。本次离线重建已知fixture原文并复算SHA，等于 `08b1d40ca40e688d55c6b54a8a3e719eb1bcf9a13538ab621a7aff0733a2af7a`。支持“提案未写”，不代表复核者新建SSH再验证。

05画面中的action `5690fdbd-7692-42f8-bfcc-6c709c7fa94f`、digest与pending一致。脚本111–121行在人工继续信号后检查succeeded并实际SFTP读回，断言text全等。离线重建replacement为101行、6,628字节，SHA为 `3b29151ebd94b81f531a055f27d33f57287e3ff105a353fd5af4080a9f0bb6d4`，与 [readback:7](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/mcp-file-reviewed-readback.json:7)的7–11行相符，target/action与pending相同。支持准确审核之后的真实客户端完整读回；没有把一张Succeeded截图当作全等校验。101是replacement数据行数，不是截图中存在可逐行点名的101个行号，也不是本 reviewer逐行看过整个长diff。

新命令与文件为不同action，命令为 `printf 'KEELSHELL_NATIVE_REVIEWED_COMMAND\n'`；08可见其审核动作，09可见Rejected，脚本133–135行检查同一命令action为rejected。[客户端回执:8](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/mcp-native-client-result.json:8)记录文件读回及命令拒绝PASS，11–47行恰9次tools/call，全部is_error=false；不是八工具全覆盖，更不是命令批准执行通过。未检查独立远端exec审计，故不额外证明整个运行期间零exec。

客户端内部MCP子进程自然exit0、reaped、stderr0，122.368563秒；其外层Python监督器另为122.482727秒，不能混成一个计时。脚本有超时terminate分支，但成功回执没有forced_shutdown，支持本次走自然退出。

10图支持原生撤权后的可见状态；客户端在撤权前已结束，本组没有以旧能力再次请求验证“撤权后实际请求被拒绝”。因此只批准已观察撤权动作和UI状态，不扩大到独立的撤权负向协议测试。自有Podman SSH＋SFTP功能结论限本fixture；未调用供应商客户端或模型。

[应用退出回执:8](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/native-app-r1/result.json:8)记录pid99445，从2026-11-17 08:36:33.468931 UTC至08:44:37.901156 UTC（上海16:36:33至16:44:37），exit0／未超时／reaped，484.428668秒。15图配合这个回执支持正常退出；不是本 reviewer新关闭一次应用。

关闭时先用旧AX索引34无效、刷新后索引7确认：旧34失败作为用户提供的操作事实保留，本组没有对应旧点击原始事件回执可独立重放或逐项核验；15完整AX确实支持fresh7。不能把旧34无效归为本次应用崩溃，也不能删掉这次工装失败。

[fixture cleanup回执:12](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/fixture-cleanup-r1/result.json:12)已到场，12–15行exit0／未超时／reaped、1.214615秒。final-fixture-cleanup包含11步，容器／网络／派生镜像exists的1是预期“不存在”，其余0，全部reaped；private_directory_removed=true。本 reviewer还只读确认记录的私有目录现在不存在。未重跑Podman，不能宣称对当前全局容器／网络／进程作了独立清查，也未删除任何资源。

**P0–P3与限定修订建议**

1. **P2 / 保留历史 / 原生滚轮路径未证实可用。** 02与03原图y约440–1560的正文及滑块位置无实质变化，文件审核入口仍在下缘之外；对应02/03 AX 21–22行虽然列动作，不能代替屏幕可达。04/08证明drag通路，不能证明wheel已恢复。触发为本次原生wheel尝试，影响为用户按常见滚动方式仍无法到达待审操作。ROOT仍UNKNOWN；本 reviewer没有输入事件轨迹，不能推定是AppKit、工装、焦点、覆盖层或GPUI中的某一项。限定建议：保留显式bar和fixed footer，将原生wheel正控／输入投递与位移关联单独补验，确认原因后再关闭。不会用旧headless强制绘帧或新drag的成功冲销此项。

2. **P2 / 新发现 / 当前777输入身份不再完整等于包绑定。** [normal-build-input-binding.json:1885](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/mcp-scrollbar-native-20261117/normal-build-input-binding.json:1885)、3035、3040行分别对应 `mcp_first_proposal.rs`、`test_icmp.py`、`test_traceroute.py`；实际大小／摘要不匹配，详见current-input-drift.json。触发为把当前checkout或当前全门禁结果表述为冻结777那一版，影响是测试与包的归属不成立。它不否定原6文件包与原图，也不是已经证明生产源码变化。限定建议：交付文字保持“原正常包及其声明的777冻结记录”；后续工程门禁按最终实际输入另作绑定，并明确三项后续测试变化，不能只沿用aggregate或HEAD。这次原件复核无需重跑GUI来补这个身份问题。

新增确证的P0/P1/P3为0。没有从“未测”推导产品失败。完整AX未包含文件diff、正文风险说明、完整目标身份或历史状态文本，这是本次导出范围的事实；未运行VoiceOver，不能据此诊断其全部实际朗读行为，但这组AX显然不足以关闭辅助技术验收。

**Hallmark finish判断与美观舒适度**

主视觉是能追踪目标、原新内容和历史状态的原生审核工具。三套主题在所检宽窗内布局一致，标题／主体／技术元数据有字重和surface层级，主动作位置稳定；没有用装饰动画、虚构数据或宣传式大标题抢占审核内容。所检视觉子集可 `ship`，不需重做主题或外壳。整体克制、整齐，属于可长期工作的工具界面；“好看”主要来自稳定的间距和内容秩序，尚不属于特别精炼的完成态。

Frost的文字和边界最直观；Graphite降低大面积亮面刺激，暖灰比纯黑白温和，副元数据较淡但在本预览仍可辨；Lavender柔和、选中态容易辨认，紫色没有压过审核内容。此为原图观感，不是对比度数值测量或长时间用眼实验。没有据静态图签署hover、pressed、busy、焦点顺序、减少动态效果、键盘或屏幕阅读器矩阵。

完整长名在MCP主体／记录标题均能读完，状态未被挤出；01连接表只看到省略名，AX保留完整名称，但hover tooltip及同名前缀消歧没有本次证据。当前只能判“宽窗MCP长名可用，连接表需依赖完整AX或后续详情核验”，不能推广到900×580。

可进一步精修的最大差距是重复长连接名与UUID／digest让记录显得偏重，且06读到底时准确路径已滚出。可在后续设计中评估保留简短目标／路径上下文、把技术身份分成明确标签详情；不得丢掉完整target、SHA或审核challenge。此处为非阻断建议，不新增未经行为证实的缺陷。名称与实时状态之间单个中点承担状态关系，未把它机械计为多段元数据串联的Floor失败。

旧对照中，connected-native/10的完整文件审核入口仍压在footer下，mcp-scroll-native/04的wheel重复仍未露出按钮；没有看到旧版在这条审核通路上更易使用。新图04/08的明显滑块和可见审核动作是实际改善。两批分辨率不全相同，不能以预览字号差别评价字体回归。保留原失败与新成功各自身份，旧包及01 wrongtarget均不代签新包。

完整Hallmark native finish仍为HOLD：原生wheel ROOT UNKNOWN；900×580 UNRUN；三主题各明暗×双语×尺寸并未覆盖；供应商／模型、完整键盘、IME、VoiceOver／辅助技术、Windows／Linux原生均未验。10–14有三主题和双语记录，但Frost英文依据本组02–09；不虚报10–14本身覆盖三主题各两种语言的六格矩阵。源码审查、最终工程门禁、提交／推送、安装和发行均不能由本次离线原件复核代签。

完成通知：本 reviewer复核工作已完成，可关闭本复核任务。结束前只读再次核对输入摘要并将结果保存在本目录；保留所有输入、失败、包和其他任务资源。
