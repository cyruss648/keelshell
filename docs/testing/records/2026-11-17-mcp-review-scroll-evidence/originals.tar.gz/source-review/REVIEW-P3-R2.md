# P3 fix supplement: exact test revision and independent focused execution

2026-11-17, Asia/Shanghai.

**Recommendation: APPROVE within the test-fix scope. P3-01 is CLOSED for test SHA `0ac3a3ae7177b25a4446281915ae0a0f889d49040cd4591ab2d3a66f63dc7362`. Current open findings: P0=0, P1=0, P2=0, P3=0.**

The historical r1 review still records its original P3=1, correct-binary 40/0/0, and initial wrong-binary 37/3/0 failure. Those reports, receipts, scripts, logs, and source snapshots were not overwritten. This supplement adds the finding's closure; it does not rewrite history or close nativeROOT UNKNOWN.

## Source review and why P3 closes

Reviewed file:

`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/workspace/tests/mcp_first_proposal.rs`

Exact bytes: **25128**. SHA-256:

`0ac3a3ae7177b25a4446281915ae0a0f889d49040cd4591ab2d3a66f63dc7362`

The old source and new source were compared directly. Changes are the private `ReviewScrollScenario` argument bundle, the explicit long-diff flag, and the overflow/end-reachability assertions. There is no additional production behavior change.

- **Line 611:** `long_diff: record_count == 1` selects the existing real 120-line proposal case. This flag is independent of whether the initial geometry happens to look scrollable.
- **Lines 502–506:** for every long-diff scenario, the test requires `diff.size.height > review_viewport.size.height`. The old regression could skip its only meaningful diff-scroll assertion if the content were incorrectly shortened; the new long-diff scenario fails on that condition.
- **Lines 508–525:** after the existing real scrollbar pointer drag, the test still requires actual diff movement and now requires its bottom to be greater than the viewport top and no lower than the viewport bottom. This addresses the old case where a partially working scroll range could satisfy “origin moved” while leaving the end inaccessible.
- **Lines 527–530:** fixed review-footer geometry remains asserted after dragging. Actual Keep pending clicks, exact action identity, PendingReview preservation, and no-write checks remain in the tested matrix.

The production callback still resets the file-review handle before opening. With that unchanged initial state, the overflowing long diff begins below the viewport end and enters the existing drag branch. The new scenario flag and unconditional long-content height assertion therefore address the recorded P3 omission without changing the production review or approval paths.

No new P0–P3 findings were identified in this test-only diff. This is the closure of the original nonblocking test-quality finding, not a claim that the original r1 had zero findings.

## Production/source binding

Before and after the independent run, both production files still match the reviewed r1:

| File under crates/keelshell-app/src/ | Bytes | SHA-256 |
| --- | ---: | --- |
| workspace/mcp.rs | 25135 | `28d1f8409470e36f9fb77d436c0df5f7b42083296f4b10d3ee64e3257c493cb6` |
| workspace/mcp/view.rs | 24063 | `6b63036394719fa03e565db81854e2f71691e9cca047d5da380f38256cea4f4b` |
| workspace/tests/mcp_first_proposal.rs | 25128 | `0ac3a3ae7177b25a4446281915ae0a0f889d49040cd4591ab2d3a66f63dc7362` |

Comparison with the old 777-input r1 manifest found three changed entries: this test file and the two separately owned network Python fixtures (`test_icmp.py`, `test_traceroute.py`). The network changes are outside this supplement's review scope. This report does not claim the old 777-input aggregate is a new full-workspace freeze.

## Exact binary copy and independent execution

Parent source binary, opened read-only:

`work/recovery-batch-integration-20261115/target/debug/build/keelshell-app/4bca9816c52f9a50/out/keelshell_app-4bca9816c52f9a50`

Owned copy actually executed:

`work/mcp-scrollbar-source-review-20261117/p3-fix-prebuilt-r2/keelshell-app-tests`

Exact bytes: **276248176**. Source hash before/after copying and owned-copy hash before/after execution all equal:

`e086b8857f16bbb2200bfb536b9dfccbb6847c4381bcad0847f0cdd899f3b226`

The target path's device/inode/mtime/size also remained the same across copying. Subsequent parent builds could proceed independently because execution used the owned copy.

This source pathname was also used by the earlier wrong artifact, but the bytes differ. The earlier artifact SHA `97d7e62a…697dd970` and its 37/3/0 failure remain distinct and preserved. A matching pathname is not used as evidence of matching binaries.

Commands executed directly against the owned copy:

```text
<owned copy> workspace::tests::mcp::first_proposal:: --list
<owned copy> workspace::tests::mcp::first_proposal:: --nocapture --test-threads=1
```

| Operation | PID | Limit | Actual duration | Result |
| --- | ---: | ---: | ---: | --- |
| Focused inventory | 17534 | 30s | 1.699664s | exit 0, reaped |
| Four focused tests | 17571 | 180s | 39.980505s | exit 0, reaped, not timed out |

Test process UTC **08:54:57.100853–08:55:37.081554**; deadline **08:57:57.100853**.

**Independent result: 4 passed / 0 failed / 0 ignored; 1406 filtered out; libtest 39.96s.** Inventory and observed statuses match exactly, with no missing or extra test names:

| Test suffix under workspace::tests::mcp::first_proposal:: | Status |
| --- | --- |
| first_pending_file_with_full_grant_scrolls_to_clickable_review | ok |
| first_short_proposal_with_selection_and_directory_has_reachable_review | ok |
| multiple_pending_files_scroll_to_first_and_last_clickable_reviews | ok |
| saturated_pending_files_scroll_to_middle_and_last_clickable_reviews | ok |

Only those four product tests ran in this supplement. The unchanged 40-item MCP suite was not rerun. Temporary fixtures and app data stayed under the owned copy's `runtime/` directory. The runner and its final hash/status verification exited 0 without a helper failure.

Parent `focused-scroll-r6` was separately read back: four passed, exit 0/reaped, outer 56.736593s. Its result is not counted as this reviewer's execution.

## Preservation and remaining boundaries

All **45** prior report/receipt/source-snapshot artifacts in the preservation inventory match their original lengths and SHA-256 values after this supplement. In particular, `REVIEW.md`, `REVIEW-STATIC.md`, `REVIEW-R1-PREBUILT.md`, `SUMMARY.json`, the initial failed run, and the r1 receipt-helper failures remain byte-for-byte unchanged.

This supplement performed one test-list process and one focused test process. Both were actually waited/reaped. Cargo commands, target writes, source/docs/Git changes, and native UI actions: **0**.

The new assertions and focused run establish the P3 regression-test correction. They do not establish the original native wheel root cause, natural native frame scheduling, a new full gate, or new platform/native acceptance. **nativeROOT remains UNKNOWN.** The parent's real SSH/native observations retain their separate evidence boundary.

Primary new receipts:

- `p3-fix-source-r2/mcp_first_proposal.rs` and `test-only.diff`
- `p3-fix-prebuilt-r2/copy-receipt.json`
- `p3-fix-prebuilt-r2/inventory.log` and `inventory-check.json`
- `p3-fix-prebuilt-r2/focused.log` and `focused-result.json`
- `p3-fix-prebuilt-r2/test-results.json`
- `p3-fix-prebuilt-r2/source-and-binary-before.json` and `source-and-binary-after.json`
- `p3-supplement-prior-artifacts-before.json` and `p3-supplement-prior-artifacts-final.json`
