# 原冻结 r1：独立预编译 MCP 复跑收口

2026-11-17，Asia/Shanghai。**限定建议：接纳原 r1 的源码／MCP 预编译子集；P0=0、P1=0、P2=0、P3=1。** 原 P3 保持非阻断、未关闭；新测试修订尚未审查、尚未绑定此次结果。完整门禁、原生滚轮根因和原生验收分开处理。

## 准确二进制与实际结果

父级 full-gate-r1 `command.log:1007` 实际执行的 app 测试二进制为：

`work/recovery-batch-integration-20261115/target/debug/build/keelshell-app/2a22076af35c6647/out/keelshell_app-2a22076af35c6647`

独立 SHA-256 前后均为：

`ccf006b9a40d4d362a290799e7daf232f5ee95454c5f6bdaba8feb4b2e0e6095`

字节 276323456；device、inode、mtime_ns 和 SHA 前后均不变。本 reviewer 没有复制、重编译、修改或清理 target。

直接运行：

```text
<上述二进制> --list
<上述二进制> workspace::tests::mcp:: --nocapture --test-threads=1
```

- `--list`：PID **9256**，exit **0**，reaped，0.015338s；期限 30s。
- MCP 子集：PID **9257**，**40 passed / 0 failed / 0 ignored**，1370 filtered。
- 子进程 UTC **08:46:43.396282–08:47:59.120717**，**exit 0 / reaped / 75.724054s**；libtest 75.71s。
- 固定期限 UTC **08:49:43.396282**／180s；没有超时或发送终止信号。
- 逐名库存与实际执行 **40/40 相等**：0 缺项、0 多项、0 未解析，全部四个 first_proposal 测试通过。没有把矩阵中的场景数量计为测试数量。
- TMPDIR／TEMP／TMP 和 KEELSHELL_DATA_DIR 都指向本审核目录的 `runtime-mcp-r2/`。这只是执行尝试编号，不是新源码 r2。所有网络交互为这些测试已有的隔离 loopback peer。

## 首次错误路径的失败完整保留

用户起初给出的路径为 `.../4bca9816c52f9a50/out/keelshell_app-4bca9816c52f9a50`，并非 full-gate-r1 日志实际执行的二进制。

本 reviewer 对该路径的实际结果为 **37 passed / 3 failed / 0 ignored**，PID **5808**，exit **101**／reaped，40.585704s。三个新增测试均因缺少 `mcp-scrollbar` 失败。该二进制 SHA 前后同为 `97d7e62af4dc5dd72cf87d62e5535cea527d6d8b65a1e2447c8146d2697dd970`。

只读诊断中，这份二进制虽包含新测试名称和测试中的 scrollbar ID，但缺少当前生产 view 的两个新 label、两个 content ID 及 review_scrollbar 字样；实际 full-gate 二进制则都有。字串检索本身不是完整编译来源证明；父级执行日志的准确路径差异和实际测试结果共同说明，第一份产物不能用于当前生产 view 验收。其历史构建来源没有在本次确诊，不能把它称为当前源码的生产缺陷。

首次日志、库存、哈希和失败回执全部原样保留。路径纠正后的 40/0/0 不覆盖或删除原 37/3/0，也不改变原生轮滚根因 UNKNOWN。

## 冻结绑定与父级并发修订

运行正确二进制前，**777 项／0 差异**，manifest 仍为 `inputs-r1.json`，aggregate 为：

`21c81c898b3015147794525858c292303f73f2749dff6eeb8225086a7ece5f6c`

本结论绑定已保存的原 r1 三文件，尤其测试：

`mcp_first_proposal.rs`，24149 字节，SHA `0d4d6c4c92ceb4231d8ebea193084278399e0ecd9ac095819e230e54f4ed2082`。

父级随后明确通知修改 P3。UTC 08:49:01.356371 的后验逐项核对中，旧 manifest 的 **776 项仍相等，1 项为已通知的父级测试修改**：

`mcp_first_proposal.rs`，25128 字节，SHA `0ac3a3ae7177b25a4446281915ae0a0f889d49040cd4591ab2d3a66f63dc7362`。

生产 `mcp.rs`／`mcp/view.rs` 仍匹配旧冻结。测试二进制前后不变，旧源码快照仍在本审核目录，因此该 40/0/0 只证明原 r1 编译产物；**不声称当前全部 777 项前后未变，也不将旧二进制结果绑定新测试 SHA**。新修订等待父级冻结／给出准确二进制后，以新报告补审和专项即可，不重复未变的 40 项。

## 唯一代码发现仍为 P3-01

原 r1 位置：

`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/workspace/tests/mcp_first_proposal.rs:490–508`

该行号指原 r1 已保存的 0d4d6c4c 版本。120 行用例有条件执行拖动检查，且只断言 diff 的 origin.y 减小，没有强制溢出或末尾进入 viewport 的断言。建议无条件确认长内容溢出，并在拖到底后确认末尾完整可达。

这是非阻断测试约束不足，没有确认当前生产裁切；本次 40 项通过也没有关闭它。父级最新正常包已观察到完整 diff 首尾属于单独原生证据，不会自动改变冻结 Rust 测试中的断言。新测试可能针对它修改，但本报告尚未审查或关闭该发现。

## 工装回执问题与边界

本 reviewer 首版逐名解析器只接受同一行的 `... ok/FAILED`，遗漏了 `--nocapture` 拆行记录。已从原产品日志重新解析，40 名逐项对齐，未重放产品测试。原解析输出保留。

第二次执行脚本机械替换编号时，将后验 manifest 误改为不存在的 `inputs-r2.json`；因此工装外层 exit 1，发生在产品子进程 exit 0／reaped 之后。已用独立后验命令读取准确 `inputs-r1.json`，补存二进制身份／SHA、777 项差异及逐名核对。原脚本、原错误和恢复回执均保留；不把工装 exit 1 写成产品失败或整体工装成功。

原生信息只记录为父级在消息中报告，未由本 reviewer 操作／重审原件：正常 app `cb963bbc…`、真实 Podman SSH、101 行完整 diff 首尾／固定 footer、准确批准、客户端 full readback+SHA、原生命令拒绝、9 tools 成功、自然 exit 0／reaped／122.368563s。独立原生操作为 0，原轮滚未动仍 UNKNOWN。

父级 full-gate-r1 app 日志为 1408 passed／0 failed／2 ignored；父级随后报告门禁因两个旧 network Python fixture 失败并安排独立修复。此处不代签完整门禁通过，也不将其非 MCP 失败作为本增量新增代码发现。

实际独立产品子集运行 **2 次**、逐名列表运行 **2 次**，分别为错误产物 37/3/0 和纠正产物 40/0/0，**不合并成 77 项验收**。Cargo、源码／docs／Git／target 修改、原生 UI 操作均为 0。自有测试子进程均已实际 wait／reaped。

## 主要原件

- `mcp-selected-inventory-r2.json`／`.txt`：正确产物的 40 名库存。
- `mcp-independent-prebuilt-r2.log`／`-result.json`：正确产物的逐名输出与真实进程终态。
- `mcp-test-results-reparsed-r2.json`：40/40 独立对齐。
- `prebuilt-source-binary-before-r2.json`／`prebuilt-source-binary-after-r2-recovered.json`：准确旧冻结绑定、二进制前后身份与已通知源码差异。
- `binary-path-correction-r1.json`／`parent-app-binary-provenance-r1.json`：错误路径事件与父级日志行号。
- `mcp-independent-prebuilt-r1.log`／`-result.json`：首次错误产物的失败原件。
- `reviewer-receipt-helper-failure.json`：工装错误及不重跑产品的恢复说明。
- `REVIEW-STATIC.md`／`source-snapshots/`：原 r1 静态结论与准确源码快照。
