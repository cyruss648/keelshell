# MCP 显式滚动条：独立源码／功能复核阶段报告

2026-11-17，Asia/Shanghai。非作者复核；本阶段没有编译、运行产品测试或操作原生 UI。

**结论：限定 APPROVE WITH NIT。生产变更未见阻断项；P0=0、P1=0、P2=0、P3=1。**
批准范围为冻结的三个工程文件的源码与测试设计，不代签完整门禁、正常 release 的原生行为、真实 SSH 原生验收或原滚轮缺陷的根因。预编译独立复跑待父级提供精确二进制后补充。

## 冻结与权限

- Git HEAD：`e394f6d16a448b7f8c3617451749d0d4ebc1b05a`。
- 777 项冻结输入：`work/mcp-review-scroll-integration-20261117/inputs-r1.json`。
- 独立逐项长度及 SHA-256 核对 **777/777 相等，0 差异**。
- 独立复算 aggregate：`21c81c898b3015147794525858c292303f73f2749dff6eeb8225086a7ece5f6c`。
- manifest 文件 SHA-256：`23f61e1602769aeb2597fc5e12dc8491ab14c7f0548c108d1e313d213ff06f0e`。
- 工程 diff 只有 `workspace/mcp.rs`、`workspace/mcp/view.rs`、`workspace/tests/mcp_first_proposal.rs`；另外观察到的父级 docs 修改不属于本次工程审查。
- 读 AGENTS、RTK、HANDOFF、SHARED_TARGET，按 rust-best-practices 的所有权、错误处理、性能与测试规范复核。只读 Git 使用 `--no-optional-locks`／`GIT_OPTIONAL_LOCKS=0`。
- 唯一写目录为本报告所在目录；没有修改源码、docs、Git、Cargo 配置或共享 target，没有执行 Cargo、原生 UI 操作或客户网络操作。

冻结三个文件：

| 文件（均位于 crates/keelshell-app/src/） | 字节 | SHA-256 |
| --- | ---: | --- |
| workspace/mcp.rs | 25135 | `28d1f8409470e36f9fb77d436c0df5f7b42083296f4b10d3ee64e3257c493cb6` |
| workspace/mcp/view.rs | 24063 | `6b63036394719fa03e565db81854e2f71691e9cca047d5da380f38256cea4f4b` |
| workspace/tests/mcp_first_proposal.rs | 24149 | `0d4d6c4c92ceb4231d8ebea193084278399e0ecd9ac095819e230e54f4ed2082` |

## P3-01：长 diff 回归只证明移动，尚未锁住末尾可达

位置：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/workspace/tests/mcp_first_proposal.rs:489–508`。

120 行 replacement 已在 232–233 行创建。当前 490 行将 diff 拖动检查放在 `if diff.bottom() > viewport.bottom()` 内，499–501 行只断言 `origin.y` 减小。因此如果未来完整 diff 被错误限制高度，检查可能被跳过；如果滚动范围只允许移动一部分，测试也仍可能通过。它没有断言拖到下端后 diff 的末尾位于 viewport 内，也没有唯一末行 sentinel 的可见性检查。

影响：这是测试回归约束不足，没有确认当前生产 diff 不可达。120 行真实提案、实际指针拖动与固定 footer 已实质补足此前完全没有长 diff 拖动的缺口；本项不重复登记历史 P2，也不阻断当前源码变更。

建议：对单提案长 diff 无条件断言初始高度显著超过 viewport；拖到下端后断言 diff.bottom 在 viewport.bottom 以内（允许少量像素误差），或断言唯一末行 sentinel 可见。再由滚轮返回顶部并核对首行、三个固定审核按钮。可以顺带在关闭后重开准确提案时核对顶部复位；目前缺少针对复位本身的明确断言。

## 生产安全、状态与滚动作用域

1. `mcp.rs:115–116,175–176` 持有两个独立 `ScrollHandle`。主面板 `view.rs:349,376` 和文件审核 `:77,88` 的 viewport 与 scrollbar 各使用同一份对应 handle，没有把主面板与文件审核的滚动状态混用，也没有新增异步任务、阻塞 I/O、凭据存储或写入调用。
2. `view.rs:76–88,348–376` 将受限 viewport 与自然高度正文分开。主／子审核的 header 与 footer 是 viewport 包装层的兄弟，固定 footer 均有 `flex_shrink_0`。正文预留 24px 右边距，滚动条置于相对定位的正文区域，不覆盖整个 dialog/footer。
3. `view.rs:7–30` 的辅助函数只构造显示层；两个 scrollbar 明确 `Always`。锁定库 `gpui-base-0.10.0/src/scrollbar.rs:1304–1307` 使用 Normal hitbox，`gpui-pre-0.3.12/src/window.rs:891–894` 明确这种 hitbox 不屏蔽其他 hitbox；条的 MouseDown 仅在自己的 bar hitbox 命中时停止传播（scrollbar.rs:1739–1771）。没有源码证据表明这个透明全视口包装会吞掉正文点击。实际点击仍需预编译与父级原生结果分别验证。
4. 滚动条内容范围来自同一个 handle 的 `max_offset + bounds.size`（scrollbar.rs:83–98）。Always 不会凭空增加 range；内容不足时库仍隐藏该轴（:1421–1425）。直接子节点自然高度的结构仍是计算完整范围的必要部分；这与 `gpui-pre` 的直接子布局边界统计及 clamp（div.rs:2040–2062,2527–2544）一致。
5. `view.rs:318–331` 打开准确文件提案，只设置 `reviewing=Some(id)`、将文件审核 handle 归零并通知。没有消费提案或执行文件写入。`view.rs:61–70,208–217` 的审批按钮准入保持原样。
6. 执行仍经过未改动的 `workspace/mcp/review.rs:10–60`：Running 互斥、准确 action ID、PendingReview、期限、lease、当前会话身份、同连接核对，随后在 UI 线程先消费为 Running，再后台执行。完整文件替换仍复核 baseline，保留 quarantine／OutcomeUnknown 语义（:115–173）。停止授权的 PendingReview→Cancelled、Running→OutcomeUnknown 也未改变（mcp.rs:202–225）。本次没有新增自动批准、静默重放或错绑目标路径。

## 测试质量及已读父级证据

- 三个新增测试通过真实隔离 loopback SSH/SFTP 的既有 Harness 提交 1／6／32 项待审文件提案，枚举并读取明确选区和授权根；第 33 次返回 Busy（测试 161–268 行）。不是直接向 action 列表塞测试数据。
- 三推荐主题使用 registry 的 preferred appearance，中文／英文，900×580／1440×900；1 项取首项、6 项取首末、32 项取中末。像素滚轮在正文中部，行滚轮在左侧 gutter，搜索上限 192 步（523–594 行）。没有把主题矩阵误计为独立 Rust 测试数量。
- `raw_wheel`、`raw_drag`、`raw_click` 通过 Window::dispatch_event 的坐标路径操作；没有直接设置生产 handle 或调用审核回调。先验证按钮完整包含在 viewport/window 内，再实际点击，核对 modal 类型、准确 action ID、准确文件路径与 PendingReview（363–483 行）。这比仅检查 disabled flag 或几何位置更强。
- 主 header/footer 稳定；文件审核通过 scrollbar 拖动长 diff、核对 footer 稳定，并实际点 Keep pending 返回。最终所有 actions 仍 PendingReview，命令请求为空，transfer_writes_started 等于 initial_writes，atomic_writes_started=0（596–610 行）。这些支持“打开／关闭审核没有批准写入”的限定结论。
- 原有 `mcp_file_changes.rs:665–776` 另覆盖大 diff 的完整 payload、三外观双语、紧凑窗口内三个审核按钮和不写入，但其 `window.scroll` 及 footer 断言仍不能补成“最后一行已可见”的证据。
- 父级 focused-scroll-r5：**4 passed / 0 failed / 0 ignored**，1406 filtered，测试 44.45s；外层 **exit 0 / reaped / 65.623789s**。本 reviewer 读回原件，尚未独立复跑。
- 父级 focused-scroll-r1 与 r4 是两次编译 helper 失败；r2 为错误 disabled 断言，1 passed／3 failed；修后 r3 和当前 r5 的结果保持各自归属。没有抹除失败或把它们计为通过。
- 红控制 r1 旧生产滚轮 **4/0/0**，不能重现原原生缺陷。红控制 r2 **1/3/0**，三项失败在查找旧 view 不具备的新显式 scrollbar，证明测试依赖新机制，不能证明原滚轮故障根因或有效复现其故障过程。

## 保留的验收边界与后续

历史 Raman P2-01 的 headless/native 差异继续作为 **nativeROOT UNKNOWN** 边界保留，不重列为本次阻断发现。测试 helper 显式 `render_frame`，锁定 Kit 实现 `test.rs:348–350` 为 `refresh(); draw(...).clear(...)`，不能证明正常 release 自行失效、帧调度、AppKit 输入或真实字体测量。历史 P2-02 的长内容缺口已由真实 120 行提案与拖动／固定 footer 补充到工程交互层；末尾可达性加强为上述 P3。

父级正常 release 构建回执已读到 exit 0／reaped，UTC 08:32:44.485348–08:35:16.967613，152.481352s；这是父级构建事实，不是本 reviewer 构建、源码到包成员绑定核对或原生验收。

本阶段独立执行：冻结输入核对 777 项／0 差异；Cargo 0、产品测试 0、原生 UI 操作 0。没有运行格式化、Clippy、依赖门禁或完整 gate。待父级将冻结测试二进制及来源／摘要回执放到允许目录，再先核对库存与二进制前后 SHA，直接运行新增 4 项及有关状态／布局子集。若 12 分钟时限内未提供，明确保留 UNRUN，不闲等或转用 Cargo。
