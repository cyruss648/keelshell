"""Run exactly the four P3 supplement tests from this owned immutable copy."""

import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time

BASE = Path(__file__).resolve().parent
REVIEW = BASE.parent
ROOT = REVIEW.parents[1]
BINARY = BASE / "keelshell-app-tests"
EXPECTED_SHA = "e086b8857f16bbb2200bfb536b9dfccbb6847c4381bcad0847f0cdd899f3b226"
PREFIX = "workspace::tests::mcp::first_proposal::"
EXPECTED_NAMES = sorted(PREFIX + name for name in [
    "first_pending_file_with_full_grant_scrolls_to_clickable_review",
    "first_short_proposal_with_selection_and_directory_has_reachable_review",
    "multiple_pending_files_scroll_to_first_and_last_clickable_reviews",
    "saturated_pending_files_scroll_to_middle_and_last_clickable_reviews",
])
SOURCE_EXPECTED = {
    "crates/keelshell-app/src/workspace/mcp.rs":
        "28d1f8409470e36f9fb77d436c0df5f7b42083296f4b10d3ee64e3257c493cb6",
    "crates/keelshell-app/src/workspace/mcp/view.rs":
        "6b63036394719fa03e565db81854e2f71691e9cca047d5da380f38256cea4f4b",
    "crates/keelshell-app/src/workspace/tests/mcp_first_proposal.rs":
        "0ac3a3ae7177b25a4446281915ae0a0f889d49040cd4591ab2d3a66f63dc7362",
}


def digest(path):
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def write_json(name, value):
    (BASE / name).write_text(json.dumps(value, indent=2) + "\n")


def source_state():
    return [
        {"path": path, "bytes": (ROOT / path).stat().st_size,
         "sha256": digest(ROOT / path), "expected_sha256": expected}
        for path, expected in SOURCE_EXPECTED.items()
    ]


def run(arguments, label, timeout):
    started = datetime.datetime.now(datetime.timezone.utc)
    clock = time.monotonic()
    env = dict(os.environ)
    runtime = BASE / "runtime"
    env.update(
        TMPDIR=str(runtime), TMP=str(runtime), TEMP=str(runtime),
        KEELSHELL_DATA_DIR=str(runtime / "app-data"),
        RUST_TEST_THREADS="1", PYTHONDONTWRITEBYTECODE="1",
    )
    with (BASE / f"{label}.log").open("xb") as output:
        process = subprocess.Popen(
            [str(BINARY), *arguments], cwd=ROOT, env=env,
            stdout=output, stderr=subprocess.STDOUT, start_new_session=True,
        )
        receipt = {
            "argv": [str(BINARY), *arguments], "cwd": str(ROOT), "pid": process.pid,
            "started_at_utc": started.isoformat(),
            "deadline_at_utc": (started + datetime.timedelta(seconds=timeout)).isoformat(),
            "timeout_seconds": timeout, "binary_sha256": EXPECTED_SHA,
            "fixture_temp_directory": str(runtime), "cargo_executed": False,
            "native_ui_executed": False, "target_writes": False,
        }
        write_json(f"{label}-started.json", receipt)
        print(json.dumps(receipt), flush=True)
        timed_out = False
        try:
            code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGTERM)
            try:
                code = process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                code = process.wait(timeout=5)
    receipt.update(
        exit_code=code, reaped=True, timed_out=timed_out,
        completed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        duration_seconds=round(time.monotonic() - clock, 6),
    )
    write_json(f"{label}-result.json", receipt)
    print(json.dumps(receipt), flush=True)
    return receipt


def main():
    (BASE / "runtime").mkdir(exist_ok=False)
    if digest(BINARY) != EXPECTED_SHA or BINARY.stat().st_size != 276248176:
        raise RuntimeError("Unexpected copied binary")
    sources = source_state()
    write_json("source-and-binary-before.json", {
        "binary_sha256": digest(BINARY), "binary_bytes": BINARY.stat().st_size,
        "sources": sources,
    })
    if any(item["sha256"] != item["expected_sha256"] for item in sources):
        raise RuntimeError("Reviewed source changed before execution")
    listing = run([PREFIX, "--list"], "inventory", 30)
    if listing["exit_code"] != 0:
        raise RuntimeError("Test inventory failed")
    inventory = (BASE / "inventory.log").read_text()
    names = sorted(
        line.removesuffix(": test") for line in inventory.splitlines()
        if line.startswith(PREFIX) and line.endswith(": test")
    )
    write_json("inventory-check.json", {
        "names": names, "count": len(names), "expected": EXPECTED_NAMES,
        "exact_match": names == EXPECTED_NAMES,
    })
    if names != EXPECTED_NAMES:
        raise RuntimeError("Expected exactly four focused tests")
    result = run(
        [PREFIX, "--nocapture", "--test-threads=1"], "focused", 180,
    )
    text = (BASE / "focused.log").read_text()
    starts = list(re.finditer(r"^test (workspace::tests::mcp::\S+) \.\.\.(.*)$", text, re.M))
    entries = []
    for index, match in enumerate(starts):
        block = text[match.start():starts[index + 1].start() if index + 1 < len(starts) else len(text)]
        status = re.search(r"(?:\.\.\. |^)(ok|FAILED|ignored)(?:\b.*)?$", block, re.M)
        entries.append({
            "name": match.group(1),
            "status": status.group(1) if status else "UNPARSED",
            "start_log_line": text.count("\n", 0, match.start()) + 1,
        })
    summary = re.search(
        r"test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; "
        r"(\d+) measured; (\d+) filtered out; finished in ([\d.]+)s", text,
    )
    verification = {
        "expected_names": EXPECTED_NAMES, "observed": entries,
        "names_match": sorted(item["name"] for item in entries) == EXPECTED_NAMES,
        "all_four_passed": len(entries) == 4 and all(item["status"] == "ok" for item in entries),
        "raw_libtest_summary": summary.group(0) if summary else None,
        "process": result,
    }
    write_json("test-results.json", verification)
    if (
        result["exit_code"] != 0 or not verification["names_match"]
        or not verification["all_four_passed"] or summary is None
        or tuple(map(int, summary.groups()[1:4])) != (4, 0, 0)
    ):
        raise RuntimeError("Focused execution or inventory failed")


if __name__ == "__main__":
    failure = None
    try:
        main()
    except Exception as error:
        failure = f"{type(error).__name__}: {error}"
    finally:
        after = {
            "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "binary_sha256": digest(BINARY), "binary_bytes": BINARY.stat().st_size,
            "expected_binary_sha256": EXPECTED_SHA, "sources": source_state(),
            "failure": failure,
        }
        write_json("source-and-binary-after.json", after)
        print(json.dumps(after), flush=True)
        if (
            failure or after["binary_sha256"] != EXPECTED_SHA
            or any(item["sha256"] != item["expected_sha256"] for item in after["sources"])
        ):
            raise SystemExit(1)
