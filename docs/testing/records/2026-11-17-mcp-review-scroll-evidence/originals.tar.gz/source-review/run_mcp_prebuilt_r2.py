"""Independently execute the user-authorized read-only test binary without Cargo."""

import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
BEFORE = json.loads((BASE / "prebuilt-source-binary-before-r2.json").read_text())
BINARY = Path(BEFORE["binary"])
PREFIX = "workspace::tests::mcp::"
RUNTIME = BASE / "runtime-mcp-r2"


def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def save(name, data):
    (BASE / name).write_text(json.dumps(data, indent=2) + "\n")


def run(args, label, timeout):
    started = datetime.datetime.now(datetime.timezone.utc)
    clock = time.monotonic()
    deadline = started + datetime.timedelta(seconds=timeout)
    timed_out = False
    env = dict(os.environ)
    env.update(
        TMPDIR=str(RUNTIME), TEMP=str(RUNTIME), TMP=str(RUNTIME),
        KEELSHELL_DATA_DIR=str(RUNTIME / "app-data"),
        RUST_TEST_THREADS="1", PYTHONDONTWRITEBYTECODE="1",
    )
    with (BASE / f"{label}.log").open("xb") as log:
        proc = subprocess.Popen(
            [str(BINARY), *args], cwd=ROOT, env=env,
            stdout=log, stderr=subprocess.STDOUT, start_new_session=True,
        )
        receipt = {
            "argv": [str(BINARY), *args], "cwd": str(ROOT), "pid": proc.pid,
            "started_at_utc": started.isoformat(),
            "deadline_at_utc": deadline.isoformat(), "timeout_seconds": timeout,
            "binary_sha256": BEFORE["binary_sha256"],
            "fixture_temp_directory": str(RUNTIME),
            "cargo_executed": False, "native_ui_executed": False,
        }
        save(f"{label}-started.json", receipt)
        print(json.dumps(receipt), flush=True)
        try:
            code = proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                code = proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                code = proc.wait(timeout=5)
    receipt.update(
        completed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        exit_code=code, reaped=True, timed_out=timed_out,
        duration_seconds=round(time.monotonic() - clock, 6),
    )
    save(f"{label}-result.json", receipt)
    print(json.dumps(receipt), flush=True)
    return receipt


def main():
    RUNTIME.mkdir(exist_ok=False)
    if sha256(BINARY) != BEFORE["binary_sha256"]:
        raise RuntimeError("Supplied binary changed before inventory")
    listing = run(["--list"], "mcp-inventory-all-r2", 30)
    if listing["exit_code"] != 0:
        raise RuntimeError("Cannot read binary inventory")
    all_text = (BASE / "mcp-inventory-all-r2.log").read_text()
    names = sorted(
        line.removesuffix(": test")
        for line in all_text.splitlines()
        if line.startswith(PREFIX) and line.endswith(": test")
    )
    required = [
        PREFIX + "first_proposal::first_pending_file_with_full_grant_scrolls_to_clickable_review",
        PREFIX + "first_proposal::first_short_proposal_with_selection_and_directory_has_reachable_review",
        PREFIX + "first_proposal::multiple_pending_files_scroll_to_first_and_last_clickable_reviews",
        PREFIX + "first_proposal::saturated_pending_files_scroll_to_middle_and_last_clickable_reviews",
    ]
    missing = sorted(set(required) - set(names))
    save("mcp-selected-inventory-r2.json", {
        "filter": PREFIX, "count": len(names), "names": names,
        "required_first_proposal_count": len(required), "missing": missing,
        "binary_sha256": BEFORE["binary_sha256"],
    })
    (BASE / "mcp-selected-inventory-r2.txt").write_text("\n".join(names) + "\n")
    if missing or len(names) != len(set(names)):
        raise RuntimeError("Missing required tests or duplicated inventory")
    result = run(
        [PREFIX, "--nocapture", "--test-threads=1"],
        "mcp-independent-prebuilt-r2", 180,
    )
    text = (BASE / "mcp-independent-prebuilt-r2.log").read_text()
    observed = re.findall(
        r"^test (workspace::tests::mcp::\S+) \.\.\. (ok|FAILED|ignored)[^\n]*$",
        text, flags=re.MULTILINE,
    )
    summary_match = re.search(
        r"test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; "
        r"(\d+) measured; (\d+) filtered out; finished in ([\d.]+)s",
        text,
    )
    parsed_summary = None
    if summary_match:
        parsed_summary = dict(zip(
            ["status", "passed", "failed", "ignored", "measured", "filtered_out", "test_seconds"],
            summary_match.groups(),
        ))
        for key in ["passed", "failed", "ignored", "measured", "filtered_out"]:
            parsed_summary[key] = int(parsed_summary[key])
        parsed_summary["test_seconds"] = float(parsed_summary["test_seconds"])
    ran_names = [name for name, _ in observed]
    verification = {
        "expected_count": len(names), "observed_count": len(observed),
        "missing_names": sorted(set(names) - set(ran_names)),
        "unexpected_names": sorted(set(ran_names) - set(names)),
        "duplicate_names": sorted({name for name in ran_names if ran_names.count(name) > 1}),
        "results": [{"name": name, "result": status} for name, status in observed],
        "summary": parsed_summary, "process": result,
    }
    save("mcp-test-results-r2.json", verification)
    if result["exit_code"] != 0 or verification["missing_names"] or verification["unexpected_names"]:
        raise RuntimeError("Test execution failed or inventory mismatch")
    if parsed_summary is None or parsed_summary["failed"] or parsed_summary["ignored"]:
        raise RuntimeError("No complete passing unignored summary")


if __name__ == "__main__":
    failure = None
    try:
        main()
    except Exception as error:
        failure = f"{type(error).__name__}: {error}"
    finally:
        manifest = json.loads(
            (ROOT / "work/mcp-review-scroll-integration-20261117/inputs-r2.json").read_text()
        )
        mismatches = []
        for item in manifest["inputs"]:
            path = ROOT / item["path"]
            if path.stat().st_size != item["bytes"] or sha256(path) != item["sha256"]:
                mismatches.append(item["path"])
        stat = BINARY.stat()
        after = {
            "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "binary_sha256": sha256(BINARY), "binary_bytes": stat.st_size,
            "binary_inode": stat.st_ino, "binary_device": stat.st_dev,
            "binary_mtime_ns": stat.st_mtime_ns,
            "binary_sha256_before": BEFORE["binary_sha256"],
            "input_count": len(manifest["inputs"]), "input_mismatches": mismatches,
            "aggregate": hashlib.sha256(json.dumps(
                manifest["inputs"], sort_keys=True, separators=(",", ":")
            ).encode()).hexdigest(),
            "failure": failure,
        }
        save("prebuilt-source-binary-after-r2.json", after)
        print(json.dumps(after), flush=True)
        if failure or after["binary_sha256"] != BEFORE["binary_sha256"] or mismatches:
            raise SystemExit(1)
