"""Run only a supplied frozen test executable; write receipts under this directory."""

import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
MANIFEST = ROOT / "work/mcp-review-scroll-integration-20261117/inputs-r1.json"
EXPECTED_AGGREGATE = "21c81c898b3015147794525858c292303f73f2749dff6eeb8225086a7ece5f6c"


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def verify_inputs():
    manifest = json.loads(MANIFEST.read_text())
    aggregate = hashlib.sha256(
        json.dumps(manifest["inputs"], sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    if len(manifest["inputs"]) != 777 or aggregate != EXPECTED_AGGREGATE:
        raise RuntimeError("Unexpected frozen input manifest")
    mismatches = []
    for item in manifest["inputs"]:
        path = ROOT / item["path"]
        if path.stat().st_size != item["bytes"] or digest(path) != item["sha256"]:
            mismatches.append(item["path"])
    return {"count": len(manifest["inputs"]), "aggregate": aggregate, "mismatches": mismatches}


def run(binary, args, label, env, timeout):
    argv = [str(binary), *args]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    clock = time.monotonic()
    timed_out = False
    with (BASE / f"{label}.log").open("xb") as output:
        process = subprocess.Popen(
            argv, cwd=ROOT, env=env, stdout=output, stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        try:
            code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGTERM)
            try:
                code = process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                code = process.wait(timeout=5)
    receipt = {
        "argv": argv, "pid": process.pid, "cwd": str(ROOT),
        "started_at_utc": started,
        "completed_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "exit_code": code, "reaped": True, "timed_out": timed_out,
        "duration_seconds": round(time.monotonic() - clock, 6),
    }
    (BASE / f"{label}.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt), flush=True)
    if code != 0:
        raise RuntimeError(f"{label} failed with {code}")


def main():
    binary = Path(sys.argv[1]).resolve(strict=True)
    expected_sha = sys.argv[2]
    if not binary.is_relative_to(BASE) or "target" in binary.parts:
        raise RuntimeError("Parent must supply a frozen executable inside the allowed directory")
    actual_sha = digest(binary)
    if actual_sha != expected_sha:
        raise RuntimeError("Frozen executable SHA-256 mismatch")
    before = verify_inputs()
    if before["mismatches"]:
        raise RuntimeError(f"Source drift before run: {before['mismatches']}")
    runtime = BASE / "runtime"
    runtime.mkdir(exist_ok=True)
    env = dict(os.environ)
    env.update(
        TMPDIR=str(runtime),
        TMP=str(runtime),
        TEMP=str(runtime),
        KEELSHELL_DATA_DIR=str(runtime / "app-data"),
        PYTHONDONTWRITEBYTECODE="1",
        RUST_TEST_THREADS="1",
    )
    (BASE / "prebuilt-before.json").write_text(
        json.dumps({"binary": str(binary), "sha256": actual_sha, "inputs": before}, indent=2)
        + "\n"
    )
    run(binary, ["--list"], "inventory", env, 30)
    inventory = (BASE / "inventory.log").read_text()
    required = [
        "workspace::tests::mcp::first_proposal::first_pending_file_with_full_grant_scrolls_to_clickable_review",
        "workspace::tests::mcp::first_proposal::first_short_proposal_with_selection_and_directory_has_reachable_review",
        "workspace::tests::mcp::first_proposal::multiple_pending_files_scroll_to_first_and_last_clickable_reviews",
        "workspace::tests::mcp::first_proposal::saturated_pending_files_scroll_to_middle_and_last_clickable_reviews",
        "workspace::tests::mcp::file_changes::mcp_file_review_compact_languages_themes_has_complete_diff_and_fixed_buttons",
        "workspace::tests::mcp::action_history::mcp_history_clear_preserves_unknown_pending_and_window_close_hold",
        "workspace::tests::mcp::action_history::mcp_unknown_review_cancel_and_confirm_preserve_original_state_without_replay",
        "workspace::tests::mcp::action_history::mcp_unknown_review_rejects_a_confirmation_for_another_action",
    ]
    names = {line.removesuffix(": test") for line in inventory.splitlines() if line.endswith(": test")}
    missing = sorted(set(required) - names)
    (BASE / "inventory-check.json").write_text(
        json.dumps({"required_count": len(required), "missing": missing, "names": required}, indent=2)
        + "\n"
    )
    if missing:
        raise RuntimeError(f"Required tests missing from binary: {missing}")
    run(
        binary,
        ["workspace::tests::mcp::first_proposal::", "--nocapture", "--test-threads=1"],
        "focused-scroll-independent-r1", env, 140,
    )
    run(
        binary,
        [required[4], "--exact", "--nocapture", "--test-threads=1"],
        "existing-long-diff-independent-r1", env, 80,
    )
    run(
        binary,
        ["workspace::tests::mcp::action_history::", "--nocapture", "--test-threads=1"],
        "history-state-independent-r1", env, 80,
    )
    after = verify_inputs()
    after_sha = digest(binary)
    result = {
        "binary": str(binary), "sha256_before": actual_sha, "sha256_after": after_sha,
        "binary_unchanged": actual_sha == after_sha, "inputs_after": after,
        "cargo_executed": False, "native_ui_executed": False,
    }
    (BASE / "prebuilt-after.json").write_text(json.dumps(result, indent=2) + "\n")
    if after["mismatches"] or actual_sha != after_sha:
        raise RuntimeError("Source or executable changed during independent runs")


if __name__ == "__main__":
    main()
