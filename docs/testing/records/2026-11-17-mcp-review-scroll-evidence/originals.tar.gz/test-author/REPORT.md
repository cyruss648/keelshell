# MCP 文件提案滚轮回归 — 测试作者交接

日期：2026-11-17。此任务只编写测试，不作独立批准，也不声称原生验收通过。

## 修改范围

唯一修改的项目代码：

`crates/keelshell-app/src/workspace/tests/mcp_first_proposal.rs`

本目录保存原文件、摘要、静态检查与差异。不修改其他源码、docs、Git 或 target。
已阅读根 AGENTS、RTK、HANDOFF 及 rust-best-practices 的测试、注释章节。
未联网、调用模型、新建 chat、worktree 或 agent。

## 新增测试

模块前缀：`workspace::tests::mcp::first_proposal::`

1. `first_pending_file_with_full_grant_scrolls_to_clickable_review`
   - 一个真实待审文件提案，要求初始审阅按钮越出正文 viewport。
2. `multiple_pending_files_scroll_to_first_and_last_clickable_reviews`
   - 六个真实待审文件提案，分别滚到第一个及最后一个。
3. `saturated_pending_files_scroll_to_middle_and_last_clickable_reviews`
   - 32 个真实待审文件提案，额外实际请求第 33 条并断言 Busy，
     分别滚到第 16 个及最后一个，防止仅验证极端滚动终点。

原命令提案测试逐字节保持不变（不含模块级说明和 imports）。

每个夹具都通过现有真实 SSH/SFTP Harness、生产授权按钮和 MCP invoke 创建：
全部八种能力、经枚举确认的 canonical `/approved` 根、实际捕获并再次读取的选区、
已有 `/approved/中文.txt` 的匹配 SHA-256，以及独立待审文件提案。
不注入合成 actions，不写 reviewing，不直接调用 review_mcp_action。

每个夹具遍历当前主题 registry（Frost、Graphite、Lavender），使用各自推荐外观，
中英文 × 900×580／1440×900，共 12 个主题／语言／尺寸组合。
每个目标分别使用正文内部的像素滚轮和左侧内缘的行滚轮。
三测试总计 36 个主题／语言／尺寸场景、120 次滚轮定位及打开／关闭审阅交互。
此数字是源码中的设计库存，尚未执行。

## 关键断言

- 初始按钮确实在正文 viewport 下方，避免夹具没有触发裁切条件。
- 正文位置与按钮位置在第一下向下滚轮后都真实上移，尺寸不变。
- 每次滚轮后正文 viewport、标题关闭按钮、三个固定 footer 按钮的位置都保持相等。
- 只通过 `window.dispatch_event` 发 MouseMove、Scroll、MouseDown、MouseUp；
  不用直接定向 scroll helper，不修改 scroll handle。
- 回到顶部也用真实正向滚轮；向下定位只用小步滚轮（像素 -120／行 -6），
  每次搜索上限 192 步，不计算目标位移直接跳转。
- 定位后按钮 visible、enabled、完整处于正文和窗口内；
  用准确坐标的鼠标按下／释放打开，断言 `McpFileReview` 和准确 action UUID。
- 授权层卸载、完整文件路径正确；通过审阅固定 footer 上的真实点击关闭，
  返回 MCP 授权模态，提案仍为 PendingReview。
- 所有记录继续 PendingReview、没有命令执行，transfer writes 未增加、
  atomic writes 为零。

这些检查面向生产行为和可达性，不依赖父级拟增加的 content ID、flex/block 层级，
也没有另建一个测试专用渲染树。

## 实际执行

- `rustfmt --edition 2024 crates/keelshell-app/src/workspace/tests/mcp_first_proposal.rs`
  自然退出 0。
- `rustfmt --edition 2024 --check crates/keelshell-app/src/workspace/tests/mcp_first_proposal.rs`
  自然退出 0。
- Python 静态核对：原命令用例未改、四个 GPUI 入口、新场景 1／6／32、
  原始滚轮／点击事件存在、未直接修改 scroll handle／reviewing，
  结果见 `static-checks.json`。
- Cargo 命令 0、共享产品二进制执行 0、产品测试执行 0、Git 命令 0。
- 无编译结果、无红／绿结果、无独立 review 结论、无新原生操作。

## 父级后续

父级独占 target 后对本模块执行专项，确认精确编译库存为四个测试入口。
旧生产渲染加新测试的红控制，应该在真实正文不移动／按钮不可达处失败；
若是夹具、编译或其他前置断言失败，不能记录为原缺陷已被测试证明。
修复渲染后，绿专项需保留三个新测试和原命令测试全部结果。
继续执行适用的严格 Clippy／完整门禁和正常包原生复核。
本作者不进行独立批准；请按既定计划另开新 reviewer。

若运行暴露任何失败，应保留准确原件并修复原因，不放宽位移、边界、
固定 footer 或真实点击断言来消除失败。
