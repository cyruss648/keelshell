"""Owned stdio client; capability remains in memory and never enters receipts."""
import asyncio
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
PATH = "/home/ksnative/native-review.txt"
REPLACEMENT = "KeelShell native acceptance\n" + "审核后的真实文件内容：MCP → 原生审阅 → SFTP。\n" * 100
COMMAND = "printf 'KEELSHELL_NATIVE_REVIEWED_COMMAND\\n'"


def write_new(name, value):
    with (BASE/name).open("x") as output:
        json.dump(value, output, ensure_ascii=False, indent=2)
        output.write("\n")


async def main():
    raw = subprocess.check_output(["pbpaste"], timeout=5)
    config = json.loads(raw)
    expected = str(ROOT/"work/mcp-scrollbar-native-20261117/package-r1/KeelShell.app/Contents/MacOS/keelshell-mcp")
    assert config["command"] == expected and config["args"] == []
    assert set(config["env"]) == {"KEELSHELL_MCP_ADDRESS", "KEELSHELL_MCP_SECRET"}
    assert config["env"]["KEELSHELL_MCP_ADDRESS"].startswith("127.0.0.1:")
    env = {key: os.environ[key] for key in ("PATH", "TMPDIR", "LANG") if key in os.environ}
    env.update(config["env"])
    # Remove the sensitive copied capability before any further native capture.
    subprocess.run(
        ["pbcopy"], input=b"KeelShell native acceptance: temporary capability consumed",
        timeout=5, check=True,
    )
    process = await asyncio.create_subprocess_exec(
        config["command"], stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
        env=env, cwd=BASE, start_new_session=True,
    )
    del config, raw
    sequence = 0
    calls = []
    clock = time.monotonic()

    async def request(method, params):
        nonlocal sequence
        sequence += 1
        process.stdin.write((json.dumps(
            {"jsonrpc": "2.0", "id": sequence, "method": method, "params": params},
            ensure_ascii=False,
        )+"\n").encode())
        await process.stdin.drain()
        while True:
            line = await asyncio.wait_for(process.stdout.readline(), timeout=12)
            assert line
            result = json.loads(line)
            if result.get("id") == sequence:
                assert "error" not in result, "RPC error (payload intentionally withheld)"
                return result["result"]

    async def call(name, arguments):
        result = await request("tools/call", {"name": name, "arguments": arguments})
        assert not result.get("isError", False), "tool error (payload intentionally withheld)"
        calls.append({"tool": name, "is_error": False})
        return result["structuredContent"]

    receipt = {"source_base": "39d9041f350e30788b39121959d2ae7f7efea043", "source_binding": "normal-build-input-binding.json",
               "pid": process.pid, "external_client": "owned Python stdio; no supplier/model",
               "capability_persisted": False, "steps": []}
    try:
        init = await request("initialize", {
            "protocolVersion": "2025-03-26", "capabilities": {},
            "clientInfo": {"name": "keelshell-native-acceptance", "version": "1.0"},
        })
        process.stdin.write(b'{"jsonrpc":"2.0","method":"notifications/initialized"}\n')
        await process.stdin.drain()
        tools = await request("tools/list", {})
        assert len(tools["tools"]) == 8
        sessions = await call("keelshell_list_sessions", {})
        assert len(sessions["sessions"]) == 1
        target = sessions["sessions"][0]["target"]
        read = await call("keelshell_sftp_read", {"target": target, "path": PATH,
                                                "max_bytes": 65536})
        assert hashlib.sha256(read["text"].encode()).hexdigest() == read["sha256"]
        assert read["text"] == "KeelShell native acceptance\n原始内容：仅供本次审核式文件操作。\n"
        proposed = await call("keelshell_propose_file_change", {
            "target": target, "path": PATH, "expected_sha256": read["sha256"],
            "replacement": REPLACEMENT,
        })
        assert proposed["kind"] == "pending_file_change"
        status = await call("keelshell_get_action_status",
                            {"target": target, "action_id": proposed["action_id"]})
        assert status["state"] == "pending_review"
        after_proposal = await call("keelshell_sftp_read", {
            "target": target, "path": PATH, "max_bytes": 65536,
        })
        assert after_proposal["sha256"] == read["sha256"]
        write_new("mcp-file-proposal-pending.json", {
            "target": target, "action_id": proposed["action_id"], "digest": proposed["digest"],
            "state": status["state"], "original_sha256": read["sha256"],
            "replacement_sha256": hashlib.sha256(REPLACEMENT.encode()).hexdigest(),
            "proposal_did_not_write": True, "server_tools": len(tools["tools"]),
            "protocol_version": init["protocolVersion"],
        })
        deadline = time.monotonic()+280
        while not (BASE/"continue-after-file-review").exists():
            assert time.monotonic() < deadline, "native file review deadline"
            await asyncio.sleep(0.2)
        status = await call("keelshell_get_action_status",
                            {"target": target, "action_id": proposed["action_id"]})
        assert status["state"] == "rejected"
        saved = await call("keelshell_sftp_read", {"target": target, "path": PATH,
                                                 "max_bytes": 65536})
        assert saved["text"] == read["text"]
        assert saved["sha256"] == read["sha256"]
        write_new("mcp-file-reviewed-readback.json", {
            "target": target, "action_id": proposed["action_id"], "state": status["state"],
            "full_original_unchanged": True, "sha256": saved["sha256"],
            "bytes": len(saved["text"].encode()), "calls_so_far": calls,
        })
        receipt.update({"status": "PASS", "unchanged_file_readback": "PASS",
                        "file_proposal_rejection": "PASS", "calls": calls})
    finally:
        process.stdin.close()
        await process.stdin.wait_closed()
        try:
            exit_code = await asyncio.wait_for(process.wait(), timeout=8)
        except asyncio.TimeoutError:
            process.terminate()
            receipt["forced_shutdown"] = True
            try:
                exit_code = await asyncio.wait_for(process.wait(), timeout=5)
            except asyncio.TimeoutError:
                process.kill()
                exit_code = await asyncio.wait_for(process.wait(), timeout=5)
                receipt["forced_kill"] = True
        stderr = await asyncio.wait_for(process.stderr.read(), timeout=2)
        receipt.update({"exit_code": exit_code, "reaped": True,
                        "stderr_bytes": len(stderr),
                        "duration_seconds": round(time.monotonic()-clock, 6)})
        write_new("mcp-native-client-result.json", receipt)
    assert receipt["status"] == "PASS" and receipt["exit_code"] == 0
    print(json.dumps({"status": "PASS", "unchanged_file_readback": "PASS",
                      "file_proposal_rejection": "PASS", "client_exit": exit_code,
                      "reaped": True, "tool_calls": len(calls)}))


asyncio.run(main())
