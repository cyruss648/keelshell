"""Independent evidence assertions. Reads evidence; writes only beside this file.

Run with python3 -B. No product/harness execution, imports from the repository,
network access, UI operations, Cargo, target access, or Git mutations.
Each check() invocation is one counted assertion; file checks combine size/hash.
"""

import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import struct
import subprocess
import tarfile


OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
DIAG = ROOT / "work/mcp-wheel-native-diagnosis-20261117"
ARCHIVE = ROOT / "docs/testing/records/2026-11-17-mcp-review-scroll-evidence"
HEAD = "f51b68c2251e1e27b354de48ba5af27c8d476682"
SOURCE = "39d9041f350e30788b39121959d2ae7f7efea043"
checks = []
started = datetime.now(timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def check(group, name, condition, detail=None):
    row = {"group": group, "name": name, "passed": bool(condition)}
    if detail is not None:
        row["detail"] = detail
    checks.append(row)


def git(*args, data=None):
    env = dict(os.environ, GIT_OPTIONAL_LOCKS="0")
    return subprocess.run(
        ["git", "-c", "core.fsmonitor=false", *args],
        cwd=ROOT, env=env, input=data, stdout=subprocess.PIPE,
        stderr=subprocess.PIPE, check=True, timeout=60,
    ).stdout


def aggregate(rows):
    return digest(json.dumps(rows, sort_keys=True, separators=(",", ":")).encode())


def jpeg_size(data):
    if data[:2] != b"\xff\xd8":
        return None
    i = 2
    sof = {0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7,
           0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF}
    while i < len(data):
        if data[i] != 255:
            return None
        while data[i] == 255:
            i += 1
        tag = data[i]
        i += 1
        if tag in {1, *range(0xD0, 0xDA)}:
            continue
        length = int.from_bytes(data[i:i + 2], "big")
        if tag in sof:
            h, w = struct.unpack(">HH", data[i + 3:i + 7])
            return [w, h]
        i += length
    return None


def safe_constant(node):
    if isinstance(node, ast.Constant) and isinstance(node.value, (str, int)):
        return node.value
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        return safe_constant(node.left) + safe_constant(node.right)
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Mult):
        return safe_constant(node.left) * safe_constant(node.right)
    raise ValueError("Only literal string fixture expressions are accepted")


binding = load(DIAG / "normal-build-input-binding.json")
normal = binding["normal_build"]
differences = binding["final_test_differences"]
manifest = load(ARCHIVE / "manifest.json")
actions = load(DIAG / "native-wheel-actions.json")
pending = load(DIAG / "mcp-file-proposal-pending.json")
rejected = load(DIAG / "mcp-file-rejected-readback-r2.json")
readback = load(DIAG / "mcp-native-readback-r2-result.json")
first = load(DIAG / "mcp-native-client-result.json")
owned = load(DIAG / "owned-resources.json")
cleanup = load(DIAG / "final-fixture-cleanup.json")
package = Path(binding["normal_app_path"]).parent
archive_data = (ARCHIVE / "originals.tar.gz").read_bytes()
check("identity", "HEAD at review start", git("rev-parse", "HEAD").decode().strip() == HEAD)
check("identity", "Tracked status at review start", git("status", "--porcelain=v1", "--untracked-files=no") == b"")
check("identity", "Probe and binding HEAD match pinned HEAD",
      binding["current_head"] == actions["head_at_probe"] == HEAD)
check("identity", "Diagnostic source base", actions["source_base"] == SOURCE)
check("archive", "Compressed archive size/hash",
      len(archive_data) == manifest["bytes"] == 9478543
      and digest(archive_data) == manifest["sha256"]
      == "07cc1659cf3164e8b24c0a0fed67f70dcafe3a8bd705af8fedb08f7174cb19ee")
for name in ["manifest.json", "originals.tar.gz"]:
    data = (ARCHIVE / name).read_bytes()
    rel = str((ARCHIVE / name).relative_to(ROOT))
    committed = git("show", f"{SOURCE}:{rel}")
    check("archive", f"Exact source Git blob: {name}", data == committed)

with tarfile.open(fileobj=io.BytesIO(archive_data), mode="r:gz") as tar:
    members = tar.getmembers()
    check("archive", "Member names/count and regular-file topology",
          len(members) == len(manifest["files"]) == 555
          and len({m.name for m in members}) == 555
          and all(m.isfile() for m in members)
          and {m.name for m in members} == {r["member"] for r in manifest["files"]})
    chosen = [
        "scrollbar-native/normal-build-input-binding.json",
        "scrollbar-native/normal-build-final-test-differences.json",
        "integration/inputs-r2.json",
    ]
    extracted = {}
    by_member = {r["member"]: r for r in manifest["files"]}
    for name in chosen:
        raw = tar.extractfile(name).read()
        r = by_member[name]
        check("archive", f"Selected member size/hash: {name}",
              len(raw) == r["bytes"] and digest(raw) == r["sha256"])
        extracted[name] = json.loads(raw)
    check("archive", "Embedded normal binding equals archived original",
          normal == extracted[chosen[0]])
    check("archive", "Embedded final test differences equal archived original",
          differences == extracted[chosen[1]])
    final = extracted[chosen[2]]

r1 = normal["engineering_inputs"]
r2 = final["inputs"]
r1map = {r["path"]: r for r in r1}
r2map = {r["path"]: r for r in r2}
check("inputs", "Both inventories have 777 unique paths",
      len(r1) == len(r1map) == len(r2) == len(r2map) == 777)
check("inputs", "r1 aggregate recomputed",
      aggregate(r1) == normal["aggregate_sha256"]
      == differences["native_build_aggregate"]
      == "21c81c898b3015147794525858c292303f73f2749dff6eeb8225086a7ece5f6c")
check("inputs", "r2 aggregate recomputed",
      aggregate(r2) == final["aggregate_sha256"]
      == binding["current_input_aggregate"] == differences["final_gate_aggregate"]
      == "5b5c1d2887d21ecf7e721d212e81f9f64acfe574b6ba32689dd9c6ad0cbb1e12")
names = git("ls-files", "-z", "--cached", "--others", "--exclude-standard").decode().split("\0")
engineering = sorted(n for n in set(names) if n and not n.startswith(("docs/", "work/")))
check("inputs", "Current engineering path set equals frozen final set", engineering == sorted(r2map))
check("inputs", "r1 and r2 path sets equal", set(r1map) == set(r2map))
changed = sorted(n for n in r2map if r1map[n] != r2map[n])
expected_changed = sorted([
    "crates/keelshell-app/src/workspace/tests/mcp_first_proposal.rs",
    "crates/keelshell-session/src/network_diagnostic/tests/test_icmp.py",
    "crates/keelshell-session/src/network_diagnostic/tests/test_traceroute.py",
])
check("inputs", "Exactly 774 equal inputs and three named test changes",
      changed == expected_changed and len(r2map) - len(changed) == 774)
check("inputs", "Every declared test difference matches both independent inventories",
      sorted(r["path"] for r in differences["changed_test_inputs"]) == changed
      and all(r["native_build"] == r1map[r["path"]]
              and r["final_gate"] == r2map[r["path"]]
              for r in differences["changed_test_inputs"]))

object_specs = b"".join(f"{SOURCE}:{r['path']}\n".encode() for r in r2)
batch = io.BytesIO(git("cat-file", "--batch", data=object_specs))
protected = {}
for r in r2:
    obj, kind, size = batch.readline().split()
    blob = batch.read(int(size))
    end = batch.read(1)
    path = ROOT / r["path"]
    actual = path.read_bytes()
    protected[str(path.relative_to(ROOT))] = (len(actual), digest(actual))
    check("inputs", f"Working bytes + pinned source Git blob: {r['path']}",
          kind == b"blob" and end == b"\n" and actual == blob
          and len(actual) == r["bytes"] and digest(actual) == r["sha256"])
check("inputs", "Git batch consumed completely", batch.read() == b"")
app_boundary = (ROOT / "crates/keelshell-app/src/workspace.rs").read_text()
session_boundary = (ROOT / "crates/keelshell-session/src/network_diagnostic.rs").read_text()
check("inputs", "Changed Rust test module is behind cfg(test)",
      "#[cfg(test)]\npub(crate) mod tests;" in app_boundary)
check("inputs", "Changed Python fixtures are in cfg(test) diagnostic module",
      "#[cfg(test)]\nmod tests;" in session_boundary
      and all((ROOT / f"crates/keelshell-session/src/network_diagnostic/tests/{n}.rs")
              .read_text().startswith("#![cfg(test)]") for n in ["icmp", "traceroute"]))

expected_package = {r["path"]: r for r in normal["package_files"]}
check("package", "Actual package contains exactly the six recorded files",
      {str(p.relative_to(package)) for p in package.rglob("*") if p.is_file()}
      == set(expected_package))
for rel, r in expected_package.items():
    p = package / rel
    raw = p.read_bytes()
    protected[str(p.relative_to(ROOT))] = (len(raw), digest(raw))
    check("package", f"Retained package size/hash: {rel}",
          len(raw) == r["bytes"] and digest(raw) == r["sha256"] and not p.is_symlink())
check("package", "r1 and final test supplement bind the same package files",
      normal["package_files"] == differences["package_files_verified"])
package_manifest = load(package / "package-manifest.json")
check("package", "Normal package metadata and null build commit preserved",
      package_manifest["build"]["commit"] is None
      and package_manifest["platform"] == "macos"
      and package_manifest["target"] == "aarch64-apple-darwin"
      and package_manifest["installed"] is False
      and all(package_manifest["files"][n] == r["sha256"]
              for n, r in expected_package.items() if n.startswith("KeelShell.app/")))
for binary in ["keelshell-app", "keelshell-mcp"]:
    raw = (package / "KeelShell.app/Contents/MacOS" / binary).read_bytes()
    magic, cpu, subtype, filetype, ncmds, sizeofcmds, flags, reserved = struct.unpack("<8I", raw[:32])
    pos = 32
    platforms = []
    for _ in range(ncmds):
        cmd, size = struct.unpack("<II", raw[pos:pos + 8])
        if cmd == 0x32:
            platforms.append(struct.unpack("<IIII", raw[pos + 8:pos + 24])[:2])
        pos += size
    check("package", f"Mach-O arm64 macOS minos15.0: {binary}",
          magic == 0xFEEDFACF and cpu == 0x100000C and platforms == [(1, 0xF0000)]
          and pos == 32 + sizeofcmds)

capture_rows = []
jpgs = sorted((DIAG / "captures").glob("*.jpg"))
axes = sorted((DIAG / "captures").glob("*.ax.txt"))
check("captures", "Ten exact JPEG/full-AX pairs",
      len(jpgs) == len(axes) == 10
      and [p.stem for p in jpgs] == [p.name.removesuffix(".ax.txt") for p in axes]
      == [s["capture"] for s in actions["sequence"]])
for index, (jpg, ax) in enumerate(zip(jpgs, axes), 1):
    raw, text = jpg.read_bytes(), ax.read_text()
    size = jpeg_size(raw)
    check("captures", f"JPEG header/dimensions/EOI: {jpg.name}",
          size == [2880, 1866] and raw[-2:] == b"\xff\xd9")
    modal = ("Remote file change review" if 5 <= index <= 7 else
             "Review window close" if index == 10 else "External MCP grants and review")
    check("captures", f"Complete AX root/modal/focus: {ax.name}",
          text.startswith('Window: "KeelShell", App: KeelShell.\n')
          and f"对话框 {modal}, ID: keelshell.active-modal" in text
          and "The focused UI element is 0 标准窗口 KeelShell, Secondary Actions: Raise" in text)
    capture_rows.append({
        "jpeg": str(jpg.relative_to(ROOT)), "jpeg_bytes": len(raw),
        "jpeg_sha256": digest(raw), "dimensions": size,
        "ax": str(ax.relative_to(ROOT)), "ax_bytes": ax.stat().st_size,
        "ax_sha256": digest(ax.read_bytes()), "ax_lines": len(text.splitlines()),
    })
for a, b in [(1, 2), (2, 3), (3, 4), (5, 6), (6, 7)]:
    check("captures", f"AX bytes identical despite visual-state comparison {a:02}/{b:02}",
          axes[a - 1].read_bytes() == axes[b - 1].read_bytes())
check("captures", "02 and 04 JPEG bytes exactly equal after main-body return",
      jpgs[1].read_bytes() == jpgs[3].read_bytes())
check("captures", "03 differs from top and 06 differs from diff top",
      jpgs[2].read_bytes() != jpgs[1].read_bytes()
      and jpgs[5].read_bytes() != jpgs[4].read_bytes())
check("captures", "Post-rejection AX removed review actions and enabled history clear",
      "Open full file review" not in axes[7].read_text()
      and "按钮 Reject\n" not in axes[7].read_text()
      and "按钮 Clear finished records" in axes[7].read_text())
check("captures", "Revocation AX removed grant row and disabled both copies",
      "Revoke session" not in axes[8].read_text()
      and "按钮 (disabled) Copy configuration template" in axes[8].read_text()
      and "按钮 (disabled) Copy temporary launch settings" in axes[8].read_text())
check("captures", "Fresh close-confirm node7 exists and node34 is absent",
      "\t\t7 按钮 Confirm close\n" in axes[9].read_text()
      and "\t\t34 " not in axes[9].read_text())
check("actions", "Recorded wheel-only/no-production-change scope",
      actions["package_reused_unchanged"] is True
      and actions["production_changes"] == 0 and actions["scrollbar_dragging"] is False)
check("actions", "Recorded up/down labels and quantities retained",
      actions["sequence"][1]["action"] == "CUA scroll([1440,1200], down, 1)"
      and actions["sequence"][2]["action"] == "CUA scroll([1440,1200], up, 1)"
      and actions["sequence"][3]["action"] == "CUA scroll([1440,1200], down, 1)"
      and actions["sequence"][5]["action"] == "CUA scroll over diff, up, 4"
      and actions["sequence"][6]["action"] == "CUA scroll over diff, down, 4")
check("actions", "Direction and matrix limitations remain explicit",
      actions["direction_cause"].startswith("UNKNOWN")
      and set(actions["unverified"]) == {
          "physical mouse or trackpad", "other platforms native GUI",
          "compact native sizing", "full themes/languages/IME/accessibility matrix"})
check("actions", "Stale34/fresh7 failure retained as reported action record",
      "stale34 rejected without action, fresh7 used successfully"
      in actions["ui_attempt_failure"]["cause"])

first_tree = ast.parse((DIAG / "mcp_native_client.py").read_text())
r2_tree = ast.parse((DIAG / "mcp_readback_only.py").read_text())
replacement = next(safe_constant(n.value) for n in first_tree.body
                   if isinstance(n, ast.Assign) and any(
                       isinstance(t, ast.Name) and t.id == "REPLACEMENT" for t in n.targets))
original = next(n.value.value for n in ast.walk(r2_tree)
                if isinstance(n, ast.Assign) and isinstance(n.value, ast.Constant)
                and any(isinstance(t, ast.Name) and t.id == "original" for t in n.targets))
check("clients", "Original literal independently recomputes full 80-byte digest",
      len(original.encode()) == rejected["bytes"] == 80
      and digest(original.encode()) == pending["original_sha256"]
      == rejected["sha256"] == "08b1d40ca40e688d55c6b54a8a3e719eb1bcf9a13538ab621a7aff0733a2af7a")
check("clients", "Replacement independently recomputes 101 lines and digest",
      len(replacement.splitlines()) == 101 and len(replacement.encode()) == 6628
      and digest(replacement.encode()) == pending["replacement_sha256"]
      == "3b29151ebd94b81f531a055f27d33f57287e3ff105a353fd5af4080a9f0bb6d4")
check("clients", "Exact target/action preserved from pending to rejected",
      pending["target"] == rejected["target"]
      and pending["action_id"] == rejected["action_id"]
      and pending["state"] == "pending_review" and rejected["state"] == "rejected"
      and rejected["full_original_unchanged"] is True)
call_nodes = sorted((n for n in ast.walk(r2_tree) if isinstance(n, ast.Call)
                     and isinstance(n.func, ast.Name) and n.func.id == "call"),
                    key=lambda n: n.lineno)
tool_names = [ast.literal_eval(n.args[0]) for n in call_nodes]
expected_calls = ["keelshell_list_sessions", "keelshell_get_action_status", "keelshell_sftp_read"]
check("clients", "r2 source contains exactly three tool calls in receipt order",
      tool_names == [r["tool"] for r in readback["calls"]]
      == [r["tool"] for r in rejected["calls"]] == expected_calls
      and all(r["is_error"] is False for r in readback["calls"]))
check("clients", "r2 source has no file/command proposal call",
      not any("propose" in n for n in tool_names))
check("clients", "r2 status and file reads use original target/action/exact fixture",
      ast.unparse(call_nodes[1].args[1]) == "{'target': target, 'action_id': pending['action_id']}"
      and ast.unparse(call_nodes[2].args[1]) == "{'target': target, 'path': PATH, 'max_bytes': 65536}"
      and next(ast.literal_eval(n.value) for n in r2_tree.body
               if isinstance(n, ast.Assign) and any(
                   isinstance(t, ast.Name) and t.id == "PATH" for t in n.targets))
      == "/home/ksnative/native-review.txt")
check("clients", "r2 checks entire original text and independently hashes received UTF8",
      'assert saved["text"] == original' in (DIAG / "mcp_readback_only.py").read_text()
      and 'hashlib.sha256(saved["text"].encode()).hexdigest() == saved["sha256"]'
      in (DIAG / "mcp_readback_only.py").read_text())
check("clients", "First client preserves inner native-marker failure",
      "AssertionError: native file review deadline" in
      (DIAG / "native-client-r1/command.log").read_text()
      and "time.monotonic() + 280" in ast.unparse(first_tree)
      and first.get("status") != "PASS" and "calls" not in first)
for name, receipt in [("r1", first), ("r2", readback)]:
    check("clients", f"{name} companion normal exit0/reaped without forced shutdown",
          receipt["exit_code"] == 0 and receipt["reaped"] is True
          and receipt["stderr_bytes"] == 0
          and not receipt.get("forced_shutdown", False) and not receipt.get("forced_kill", False))
check("clients", "r2 logs attest exactly 3 successful calls",
      json.loads((DIAG / "native-readback-r2/command.log").read_text())
      == {"status": "PASS", "unchanged_file_readback": "PASS",
          "file_proposal_rejection": "PASS", "client_exit": 0, "reaped": True, "tool_calls": 3})
receipts = {}
for name, expected_exit in [("native-client-r1", 1), ("native-readback-r2", 0),
                            ("native-app-r1", 0), ("fixture-cleanup-r1", 0)]:
    r = load(DIAG / name / "result.json")
    receipts[name] = r
    check("receipts", f"{name}: actual wait/exit/outer timeout",
          r["exit_code"] == expected_exit and r["reaped"] is True and r["timed_out"] is False)
    start = datetime.fromisoformat(r["started_at_utc"])
    end = datetime.fromisoformat(r["completed_at_utc"])
    check("receipts", f"{name}: timestamps match bounded monotonic duration",
          abs((end - start).total_seconds() - r["duration_seconds"]) < 0.05)
check("receipts", "App launched exact retained package in isolated runtime",
      receipts["native-app-r1"]["argv"] == [
          "env", f"KEELSHELL_DATA_DIR={DIAG / 'runtime-r1'}",
          str((package / "KeelShell.app/Contents/MacOS/keelshell-app").relative_to(ROOT))])
check("receipts", "First failure precedes r2 readback, app reap, then cleanup",
      receipts["native-app-r1"]["started_at_utc"]
      < receipts["native-client-r1"]["started_at_utc"]
      < receipts["native-client-r1"]["completed_at_utc"]
      < receipts["native-readback-r2"]["started_at_utc"]
      < receipts["native-readback-r2"]["completed_at_utc"]
      < receipts["native-app-r1"]["completed_at_utc"]
      < receipts["fixture-cleanup-r1"]["started_at_utc"])

cid, nid, iid = owned["container_id"], owned["network_id"], owned["image"]
expected_argv = [
    ["podman", "inspect", cid], ["podman", "stop", "--time", "10", cid],
    ["podman", "logs", cid], ["podman", "rm", cid],
    ["podman", "container", "exists", cid], ["podman", "network", "inspect", nid],
    ["podman", "network", "rm", nid], ["podman", "network", "exists", nid],
    ["podman", "image", "inspect", iid], ["podman", "image", "rm", iid],
    ["podman", "image", "exists", iid],
]
check("cleanup", "Exact owner and eleven command identities",
      cleanup["owner"] == owned["owner"] == "mcp-wheel-native-diagnosis-20261117"
      and [s["argv"] for s in cleanup["steps"]] == expected_argv)
for i, step in enumerate(cleanup["steps"]):
    check("cleanup", f"Step {i}: reaped and expected exit including absence=1",
          step["reaped"] is True and step["exit_code"] == (1 if i in [4, 7, 10] else 0))
c = json.loads(cleanup["steps"][0]["stdout"])[0]
n = json.loads(cleanup["steps"][5]["stdout"])[0]
im = json.loads(cleanup["steps"][8]["stdout"])[0]
check("cleanup", "Container ID/owner/image/localhost port",
      c["Id"] == cid and c["Config"]["Labels"][owned["label"]] == owned["owner"]
      and c["Image"] == iid
      and c["NetworkSettings"]["Ports"]["2222/tcp"] == [
          {"HostIp": "127.0.0.1", "HostPort": str(owned["port"])}])
check("cleanup", "Internal network exact ID/owner and no remaining container",
      n["id"] == nid and n["labels"][owned["label"]] == owned["owner"]
      and n["internal"] is True and n["containers"] == {})
check("cleanup", "Derived image exact ID and owner",
      im["Id"] == iid and im["Config"]["Labels"][owned["label"]] == owned["owner"])
server = [json.loads(line) for line in cleanup["steps"][2]["stdout"].splitlines()]
check("cleanup", "Server recorded sshd exit0/reaped before container removal",
      server[-1] == {"status": "STOPPED", "sshd_exit_code": 0, "sshd_reaped": True})
check("cleanup", "Nonempty teardown stderr retained",
      "cleanup_exit: kill(15): Operation not permitted" in cleanup["steps"][2]["stderr"]
      and "kex_exchange_identification: Connection closed by remote host"
      in cleanup["steps"][2]["stderr"])
check("cleanup", "Exact private-directory removal receipt and present absence",
      cleanup["private_directory_removed"] is True
      and Path(owned["private_directory"]).parent == ROOT / "work"
      and not Path(owned["private_directory"]).exists())

for p in sorted(DIAG.rglob("*")):
    if p.is_file() and "runtime-r1" not in p.relative_to(DIAG).parts:
        raw = p.read_bytes()
        protected[str(p.relative_to(ROOT))] = (len(raw), digest(raw))
for rel in ["manifest.json", "originals.tar.gz"]:
    raw = (ARCHIVE / rel).read_bytes()
    protected[str((ARCHIVE / rel).relative_to(ROOT))] = (len(raw), digest(raw))
check("preservation", "All protected inputs/evidence/package bytes retained",
      all((len((ROOT / p).read_bytes()), digest((ROOT / p).read_bytes())) == expected
          for p, expected in protected.items()),
      {"files": len(protected)})
check("preservation", "HEAD retained", git("rev-parse", "HEAD").decode().strip() == HEAD)
check("preservation", "Tracked status retained clean",
      git("status", "--porcelain=v1", "--untracked-files=no") == b"")
counts = Counter(r["group"] for r in checks)
failed = [r for r in checks if not r["passed"]]
result = {
    "schema_version": 1, "started_at_utc": started,
    "completed_at_utc": datetime.now(timezone.utc).isoformat(),
    "review_head": HEAD, "engineering_source": SOURCE,
    "counting_rule": "One check() invocation is one assertion; each file size/hash/blob comparison is combined.",
    "summary": {"assertions": len(checks), "passed": len(checks) - len(failed),
                "failed": len(failed), "skipped": 0, "by_group": dict(counts)},
    "captures": capture_rows, "checks": checks,
    "receipts": receipts, "protected_file_count": len(protected),
    "scope": "Offline evidence assertions only; no product tests, native rerun, or original helpers executed.",
}
(OUT / "checks.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(result["summary"], ensure_ascii=False))
for row in failed:
    print(json.dumps(row, ensure_ascii=False))
raise SystemExit(1 if failed else 0)
