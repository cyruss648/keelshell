"""Check immutable old-r1 evidence and exact 39d Git inputs, offline.

Current HEAD/status are observations only. No current source equality, clean
status, drift cardinality, product execution, network, UI, Cargo or target access.
One check() call is one assertion; a file size/hash comparison is combined.
Any failed assertion or unexpected exception makes this process exit 1.
"""

from collections import Counter
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import struct
import subprocess
import tarfile
import traceback


OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
DIAG = ROOT / "work/mcp-wheel-native-diagnosis-20261117"
ARCHIVE = ROOT / "docs/testing/records/2026-11-17-mcp-review-scroll-evidence"
SOURCE = "39d9041f350e30788b39121959d2ae7f7efea043"
checks = []
protected = {}
observations = {}
started = datetime.now(timezone.utc).isoformat()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    raw = path.read_bytes()
    protected[str(path.relative_to(ROOT))] = {"bytes": len(raw), "sha256": sha(raw)}
    return raw


def load(path):
    return json.loads(read(path))


def check(group, name, condition):
    checks.append({"group": group, "name": name, "passed": bool(condition)})


def git(*args, data=None, required=True):
    result = subprocess.run(
        ["git", "-c", "core.fsmonitor=false", *args],
        cwd=ROOT, env=dict(os.environ, GIT_OPTIONAL_LOCKS="0"),
        input=data, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60,
    )
    if required:
        result.check_returncode()
        return result.stdout
    return {"exit_code": result.returncode,
            "stdout": result.stdout.decode(), "stderr": result.stderr.decode()}


def aggregate(rows):
    return sha(json.dumps(rows, sort_keys=True, separators=(",", ":")).encode())


def jpeg_dimensions(raw):
    if raw[:2] != b"\xff\xd8":
        return None
    i = 2
    sof = {0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7,
           0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF}
    while i < len(raw):
        if raw[i] != 255:
            return None
        while raw[i] == 255:
            i += 1
        marker = raw[i]
        i += 1
        if marker in {1, *range(0xD0, 0xDA)}:
            continue
        length = int.from_bytes(raw[i:i + 2], "big")
        if marker in sof:
            height, width = struct.unpack(">HH", raw[i + 3:i + 7])
            return [width, height]
        i += length
    return None


def main():
    observations["current_worktree"] = {
        "recorded_at_utc": datetime.now(timezone.utc).isoformat(),
        "head": git("rev-parse", "HEAD", required=False),
        "tracked_status": git("status", "--porcelain=v1", "--untracked-files=no", required=False),
        "asserted": False,
        "boundary": "Concurrent authorized source work; no current source bytes are read or certified.",
    }
    history_raw = read(OUT / "checks-r1.json")
    supplement_raw = read(OUT / "binding-supplement.json")
    history = json.loads(history_raw)
    supplement = json.loads(supplement_raw)
    check("history_preservation", "Original r1 failures retained byte-for-byte",
          sha(history_raw) == "5ab4d1c1c148d3a997a82fb56a305d7db16ec57d81dec95251d5649fc718ab1c"
          and history["summary"]["failed"] == 3)
    check("history_preservation", "Supplement failures retained byte-for-byte",
          sha(supplement_raw) == "fa640b3fe3a83554d7fe671c41eac60ba6318ef68748d81895ddb34ba19d0bc6"
          and supplement["summary"]["failed"] == 2)

    binding = load(DIAG / "normal-build-input-binding.json")
    normal = binding["normal_build"]
    differences = binding["final_test_differences"]
    manifest = load(ARCHIVE / "manifest.json")
    archive_raw = read(ARCHIVE / "originals.tar.gz")
    check("archive", "Compressed archive exact size/hash",
          len(archive_raw) == manifest["bytes"] == 9478543
          and sha(archive_raw) == manifest["sha256"]
          == "07cc1659cf3164e8b24c0a0fed67f70dcafe3a8bd705af8fedb08f7174cb19ee")
    for filename in ["manifest.json", "originals.tar.gz"]:
        path = ARCHIVE / filename
        check("archive", f"Exact 39d Git blob: {filename}",
              read(path) == git("show", f"{SOURCE}:{path.relative_to(ROOT)}"))
    with tarfile.open(fileobj=io.BytesIO(archive_raw), mode="r:gz") as tar:
        members = tar.getmembers()
        check("archive", "555 unique regular-file member names match manifest",
              len(members) == len(manifest["files"]) == 555
              and len({m.name for m in members}) == 555
              and all(m.isfile() for m in members)
              and {m.name for m in members} == {r["member"] for r in manifest["files"]})
        by_name = {r["member"]: r for r in manifest["files"]}
        selected = {}
        for name in [
            "scrollbar-native/normal-build-input-binding.json",
            "scrollbar-native/normal-build-final-test-differences.json",
            "integration/inputs-r2.json",
        ]:
            raw = tar.extractfile(name).read()
            row = by_name[name]
            check("archive", f"Selected archived binding size/hash: {name}",
                  len(raw) == row["bytes"] and sha(raw) == row["sha256"])
            selected[name] = json.loads(raw)
    check("archive", "Embedded normal binding equals archived original",
          normal == selected["scrollbar-native/normal-build-input-binding.json"])
    check("archive", "Embedded test differences equal archived original",
          differences == selected["scrollbar-native/normal-build-final-test-differences.json"])
    final = selected["integration/inputs-r2.json"]
    r1, r2 = normal["engineering_inputs"], final["inputs"]
    r1map, r2map = ({r["path"]: r for r in rows} for rows in [r1, r2])
    check("git_inputs", "r1/r2 inventories each contain 777 unique equal path names",
          len(r1) == len(r1map) == len(r2) == len(r2map) == 777
          and set(r1map) == set(r2map))
    check("git_inputs", "Native r1 aggregate independently recomputed",
          aggregate(r1) == normal["aggregate_sha256"] == differences["native_build_aggregate"]
          == "21c81c898b3015147794525858c292303f73f2749dff6eeb8225086a7ece5f6c")
    check("git_inputs", "Final r2 aggregate independently recomputed",
          aggregate(r2) == final["aggregate_sha256"] == differences["final_gate_aggregate"]
          == binding["current_input_aggregate"]
          == "5b5c1d2887d21ecf7e721d212e81f9f64acfe574b6ba32689dd9c6ad0cbb1e12")
    changed = sorted(p for p in r2map if r1map[p] != r2map[p])
    check("git_inputs", "774 equal inputs and three exact archived test differences",
          len(r2map) - len(changed) == 774
          and changed == sorted(r["path"] for r in differences["changed_test_inputs"])
          and all(r["native_build"] == r1map[r["path"]]
                  and r["final_gate"] == r2map[r["path"]]
                  for r in differences["changed_test_inputs"]))
    requests = b"".join(f"{SOURCE}:{r['path']}\n".encode() for r in r2)
    batch = io.BytesIO(git("cat-file", "--batch", data=requests))
    for row in r2:
        header = batch.readline().split()
        raw = batch.read(int(header[2]))
        end = batch.read(1)
        check("git_inputs", f"Exact 39d Git input size/hash: {row['path']}",
              header[1] == b"blob" and end == b"\n"
              and len(raw) == row["bytes"] and sha(raw) == row["sha256"])
    check("git_inputs", "777-input Git batch fully consumed", batch.read() == b"")

    package = Path(binding["normal_app_path"]).parent
    package_rows = normal["package_files"]
    check("package", "Archived native/final package bindings are identical",
          package_rows == differences["package_files_verified"])
    check("package", "Retained package has exactly six recorded files",
          len(package_rows) == 6
          and {str(p.relative_to(package)) for p in package.rglob("*") if p.is_file()}
          == {r["path"] for r in package_rows})
    for row in package_rows:
        path = package / row["path"]
        raw = read(path)
        check("package", f"Retained package size/hash: {row['path']}",
              not path.is_symlink() and len(raw) == row["bytes"] and sha(raw) == row["sha256"])

    actions = load(DIAG / "native-wheel-actions.json")
    check("captures", "Original ten JPEG/full-AX pairs match recorded sequence",
          len(history["captures"]) == len(actions["sequence"]) == 10
          and [Path(c["jpeg"]).stem for c in history["captures"]]
          == [s["capture"] for s in actions["sequence"]]
          and {p.name for p in (DIAG / "captures").iterdir()}
          == {Path(c[key]).name for c in history["captures"] for key in ["jpeg", "ax"]})
    for capture in history["captures"]:
        for kind in ["jpeg", "ax"]:
            raw = read(ROOT / capture[kind])
            check("captures", f"Original {kind} size/hash: {Path(capture[kind]).name}",
                  len(raw) == capture[f"{kind}_bytes"] and sha(raw) == capture[f"{kind}_sha256"])
            if kind == "jpeg":
                check("captures", f"JPEG dimensions/EOI: {Path(capture[kind]).name}",
                      jpeg_dimensions(raw) == capture["dimensions"] == [2880, 1866]
                      and raw[-2:] == b"\xff\xd9")
    check("captures", "Recorded scope retains unchanged package/no drag and UNKNOWN cause",
          actions["source_base"] == SOURCE and actions["package_reused_unchanged"] is True
          and actions["production_changes"] == 0 and actions["scrollbar_dragging"] is False
          and actions["direction_cause"].startswith("UNKNOWN"))

    receipts = {}
    for name, code in [
        ("native-client-r1", 1), ("native-readback-r2", 0),
        ("native-app-r1", 0), ("fixture-cleanup-r1", 0),
    ]:
        row = load(DIAG / name / "result.json")
        receipts[name] = row
        check("receipts", f"Original {name} wrapper receipt matches preserved record",
              row == history["receipts"][name] and row["exit_code"] == code
              and row["reaped"] is True and row["timed_out"] is False)
    first_log = read(DIAG / "native-client-r1/command.log").decode()
    first = load(DIAG / "mcp-native-client-result.json")
    check("receipts", "First native marker failure and distinct normal child exit preserved",
          "AssertionError: native file review deadline" in first_log
          and first.get("status") != "PASS" and "calls" not in first
          and first["exit_code"] == 0 and first["reaped"] is True
          and not first.get("forced_shutdown", False) and not first.get("forced_kill", False))
    pending = load(DIAG / "mcp-file-proposal-pending.json")
    rejected = load(DIAG / "mcp-file-rejected-readback-r2.json")
    second = load(DIAG / "mcp-native-readback-r2-result.json")
    call_names = ["keelshell_list_sessions", "keelshell_get_action_status", "keelshell_sftp_read"]
    check("receipts", "Second read-only tool calls exactly list/status/read without errors",
          [r["tool"] for r in second["calls"]]
          == [r["tool"] for r in rejected["calls"]] == call_names
          and all(r["is_error"] is False for r in second["calls"])
          and all(r["is_error"] is False for r in rejected["calls"]))
    check("receipts", "Original target/action transition is pending to rejected",
          pending["target"] == rejected["target"]
          and pending["action_id"] == rejected["action_id"]
          == "b4b94712-d59b-4171-a6ac-262dadb4d286"
          and pending["state"] == "pending_review" and rejected["state"] == "rejected"
          and rejected["full_original_unchanged"] is True)
    original = "KeelShell native acceptance\n原始内容：仅供本次审核式文件操作。\n"
    replacement = "KeelShell native acceptance\n" + "审核后的真实文件内容：MCP → 原生审阅 → SFTP。\n" * 100
    check("receipts", "Entire 80-byte original receipt digest independently recomputed",
          len(original.encode()) == rejected["bytes"] == 80
          and sha(original.encode()) == pending["original_sha256"] == rejected["sha256"]
          == "08b1d40ca40e688d55c6b54a8a3e719eb1bcf9a13538ab621a7aff0733a2af7a")
    check("receipts", "101-line replacement digest independently recomputed",
          len(replacement.splitlines()) == 101 and len(replacement.encode()) == 6628
          and sha(replacement.encode()) == pending["replacement_sha256"])
    check("receipts", "Second companion is successful and naturally reaped",
          second["status"] == second["unchanged_file_readback"]
          == second["file_proposal_rejection"] == "PASS"
          and second["exit_code"] == 0 and second["reaped"] is True
          and not second.get("forced_shutdown", False) and not second.get("forced_kill", False))
    second_log = json.loads(read(DIAG / "native-readback-r2/command.log"))
    check("receipts", "Second wrapper output confirms three calls and complete successful readback",
          second_log == {
              "status": "PASS", "unchanged_file_readback": "PASS",
              "file_proposal_rejection": "PASS", "client_exit": 0, "reaped": True, "tool_calls": 3})
    close_ax = read(DIAG / "captures/10-owned-app-close-review.ax.txt").decode()
    check("receipts", "Reported stale34 failure and fresh7 close confirmation retained",
          "stale34 rejected without action, fresh7 used successfully"
          in actions["ui_attempt_failure"]["cause"]
          and "\t\t7 按钮 Confirm close\n" in close_ax)

    owned = load(DIAG / "owned-resources.json")
    cleanup = load(DIAG / "final-fixture-cleanup.json")
    cid, nid, iid = owned["container_id"], owned["network_id"], owned["image"]
    commands = [
        ["podman", "inspect", cid], ["podman", "stop", "--time", "10", cid],
        ["podman", "logs", cid], ["podman", "rm", cid],
        ["podman", "container", "exists", cid], ["podman", "network", "inspect", nid],
        ["podman", "network", "rm", nid], ["podman", "network", "exists", nid],
        ["podman", "image", "inspect", iid], ["podman", "image", "rm", iid],
        ["podman", "image", "exists", iid],
    ]
    check("cleanup", "Exact owner and eleven cleanup command identities",
          cleanup["owner"] == owned["owner"] == "mcp-wheel-native-diagnosis-20261117"
          and [s["argv"] for s in cleanup["steps"]] == commands)
    for index, step in enumerate(cleanup["steps"]):
        check("cleanup", f"Cleanup step {index} actual reaped/expected exit",
              step["reaped"] is True
              and step["exit_code"] == (1 if index in [4, 7, 10] else 0))
    c = json.loads(cleanup["steps"][0]["stdout"])[0]
    n = json.loads(cleanup["steps"][5]["stdout"])[0]
    im = json.loads(cleanup["steps"][8]["stdout"])[0]
    check("cleanup", "Container identity/owner/image and localhost port",
          c["Id"] == cid and c["Config"]["Labels"][owned["label"]] == owned["owner"]
          and c["Image"] == iid and c["NetworkSettings"]["Ports"]["2222/tcp"]
          == [{"HostIp": "127.0.0.1", "HostPort": str(owned["port"])}])
    check("cleanup", "Exact empty internal network and owned image identities",
          n["id"] == nid and n["labels"][owned["label"]] == owned["owner"]
          and n["internal"] is True and n["containers"] == {}
          and im["Id"] == iid and im["Config"]["Labels"][owned["label"]] == owned["owner"])
    server = [json.loads(line) for line in cleanup["steps"][2]["stdout"].splitlines()]
    check("cleanup", "Recorded sshd exit0/reaped and private cleanup receipt",
          server[-1] == {"status": "STOPPED", "sshd_exit_code": 0, "sshd_reaped": True}
          and cleanup["private_directory_removed"] is True)
    check("cleanup", "Original nonempty teardown stderr remains preserved",
          "cleanup_exit: kill(15): Operation not permitted" in cleanup["steps"][2]["stderr"]
          and "kex_exchange_identification: Connection closed by remote host"
          in cleanup["steps"][2]["stderr"])
    cleanup_log = json.loads(read(DIAG / "fixture-cleanup-r1/command.log"))
    check("cleanup", "Cleanup wrapper output retains eleven completed steps",
          cleanup_log == {"cleanup": "PASS", "steps": 11, "receipt": "final-fixture-cleanup.json"})

    for rel, expected in sorted(protected.items()):
        raw = (ROOT / rel).read_bytes()
        check("immutable_preservation", f"Immutable input unchanged during r3: {rel}",
              len(raw) == expected["bytes"] and sha(raw) == expected["sha256"])
    observations["current_worktree_after"] = {
        "recorded_at_utc": datetime.now(timezone.utc).isoformat(),
        "head": git("rev-parse", "HEAD", required=False),
        "tracked_status": git("status", "--porcelain=v1", "--untracked-files=no", required=False),
        "asserted": False,
    }


unexpected = None
try:
    main()
except Exception as error:
    unexpected = {"type": type(error).__name__, "message": str(error),
                  "traceback": traceback.format_exc()}
    check("unexpected_error", "Immutable validation completed without unexpected exception", False)
failed = [r for r in checks if not r["passed"]]
summary = {
    "assertions": len(checks), "passed": len(checks) - len(failed),
    "failed": len(failed), "skipped": 0,
    "by_group": dict(Counter(r["group"] for r in checks)),
}
result = {
    "schema_version": 1, "revision": "r3",
    "started_at_utc": started, "completed_at_utc": datetime.now(timezone.utc).isoformat(),
    "pinned_engineering_commit": SOURCE,
    "scope": "Immutable original raw captures/receipts/archived bindings/exact 39d777 Git inputs/unchanged package6 only; historical failure preservation.",
    "current_worktree_is_observation_only": True,
    "current_source_bytes_read": False,
    "counting_rule": "One check() invocation is one assertion; per-file size/hash checks are combined.",
    "summary": summary, "checks": checks,
    "observations": observations, "immutable_input_manifest": protected,
    "unexpected_exception": unexpected, "exit_code": 1 if failed else 0,
    "earlier_runs_are_preserved_and_not_summed": True,
}
with (OUT / "checks-r3.json").open("x") as output:
    json.dump(result, output, ensure_ascii=False, indent=2)
    output.write("\n")
print(json.dumps({"revision": "r3", "summary": summary,
                  "exit_code": result["exit_code"]}, ensure_ascii=False))
for row in failed:
    print(json.dumps(row, ensure_ascii=False))
if unexpected:
    print(unexpected["traceback"])
raise SystemExit(result["exit_code"])
