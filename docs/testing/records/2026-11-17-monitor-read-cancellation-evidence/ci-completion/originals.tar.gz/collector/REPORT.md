# 精确工程 CI 原件收集

工程 `6ae91d2e90668e7d9c04a2a7eea7c5de1bf6d3d4`，GET 观察 `2026-11-17T07:56:50.191583+00:00`，快照 `004`。
只写当前自有目录；未运行 Git、Cargo、产品、安装、workflow rerun 或 cancel。
从已提交上一批封存仅读取所需普通文件；helper-provenance.json 记录来源及摘要。
collect.py 仅将后续 single-job 元数据写入对应快照，避免复用旧 in_progress 元数据。

| Run | ID | attempt | 状态 | conclusion |
| --- | --- | ---: | --- | --- |
| Quality | 44040248864 | 1 | in_progress | None |
| Windows monitor integration | 44040248806 | 1 | completed | success |
| Windows OpenSSH monitor integration | 44040248746 | 1 | completed | success |

| Quality 平台 / job | 普通 Rust pass/fail/ignored | rustdoc pass/fail/ignored | Python 主 run/skip |
| --- | --- | --- | --- |
| native (macos-26) / 133892795291 | UNKNOWN（in_progress，尚无完整终态日志） | UNKNOWN | UNKNOWN |
| native (windows-2025) / 133892795649 | UNKNOWN（in_progress，尚无完整终态日志） | UNKNOWN | UNKNOWN |
| native (ubuntu-24.04) / 133892795682 | UNKNOWN（in_progress，尚无完整终态日志） | UNKNOWN | UNKNOWN |

普通 Rust、rustdoc、Windows preflight、packaging、内嵌 helper、OpenSSH 及自定义 controller 单列；
逐名库存、ignored 原因、可用 Python skip 原文、skipped steps 与完整逐步计数见 inventories/ 和 summary.json。
Python quiet discovery 无逐名清单时仅记录总数与 skipped；OK 推算的非跳过数明确标记为 inferred。

Windows/API 详细逐步计数：

```json
[
  {
    "run": 44040248806,
    "jobs": [
      {
        "id": 133892794901,
        "name": "Actual collectors and independent Windows APIs",
        "status": "completed",
        "conclusion": "success",
        "counts": [
          {
            "number": 4,
            "name": "Lab unit tests",
            "rust": {
              "suites": 0,
              "passed": 0,
              "failed": 0,
              "ignored": 0,
              "measured": 0,
              "filtered_out": 0,
              "declared_total": 0,
              "named_total": 0,
              "all_declarations_match": true,
              "all_named_inventories_match": true
            },
            "rustdoc": {
              "suites": 0,
              "passed": 0,
              "failed": 0,
              "ignored": 0,
              "measured": 0,
              "filtered_out": 0,
              "declared_total": 0,
              "named_total": 0,
              "all_declarations_match": true,
              "all_named_inventories_match": true
            },
            "python": [
              {
                "run": 111,
                "skipped": 3,
                "passed_inferred_from_success": 108,
                "outcome": "OK (skipped=3)",
                "named_counts": {
                  "ok": 108,
                  "skipped": 3
                },
                "named_inventory_available": true,
                "named_count_matches_run": true,
                "named_skip_matches_summary": true
              }
            ]
          },
          {
            "number": 6,
            "name": "Captured API frames through public authenticated routing (capture replay)",
            "rust": {
              "suites": 1,
              "passed": 1,
              "failed": 0,
              "ignored": 0,
              "measured": 0,
              "filtered_out": 18,
              "declared_total": 1,
              "named_total": 1,
              "all_declarations_match": true,
              "all_named_inventories_match": true
            },
            "rustdoc": {
              "suites": 0,
              "passed": 0,
              "failed": 0,
              "ignored": 0,
              "measured": 0,
              "filtered_out": 0,
              "declared_total": 0,
              "named_total": 0,
              "all_declarations_match": true,
              "all_named_inventories_match": true
            },
            "python": []
          }
        ]
      },
      {
        "id": 133892796479,
        "name": "Isolated OpenSSH prerequisites (HOLD until terminal proof)",
        "status": "completed",
        "conclusion": "skipped",
        "counts": []
      }
    ]
  },
  {
    "run": 44040248746,
    "jobs": [
      {
        "id": 133892794705,
        "name": "Actual Windows OpenSSH and original remote processes",
        "status": "completed",
        "conclusion": "success",
        "counts": [
          {
            "number": 4,
            "name": "SSH ownership and integration lab unit tests",
            "rust": {
              "suites": 0,
              "passed": 0,
              "failed": 0,
              "ignored": 0,
              "measured": 0,
              "filtered_out": 0,
              "declared_total": 0,
              "named_total": 0,
              "all_declarations_match": true,
              "all_named_inventories_match": true
            },
            "rustdoc": {
              "suites": 0,
              "passed": 0,
              "failed": 0,
              "ignored": 0,
              "measured": 0,
              "filtered_out": 0,
              "declared_total": 0,
              "named_total": 0,
              "all_declarations_match": true,
              "all_named_inventories_match": true
            },
            "python": [
              {
                "run": 96,
                "skipped": 1,
                "passed_inferred_from_success": 95,
                "outcome": "OK (skipped=1)",
                "named_counts": {
                  "ok": 95,
                  "skipped": 1
                },
                "named_inventory_available": true,
                "named_count_matches_run": true,
                "named_skip_matches_summary": true
              }
            ]
          }
        ]
      }
    ]
  }
]
```

SSH 原 seal HOLD，21 原对象中20非master自然终态：0×14、255×5、1×1；master尚活，1 pending，22 owned handles。
cleanup PASS且active/pending/owned handles均0、closed=true；master cleanup exit125，natural_terminal_before_cleanup=false。
API isolated-SSH job skipped，direct API ssh=UNRUN；两份Windows artifact native_gui=UNRUN。
API六个与SSH九个direct children记录reaped；SSH owned-sshd observed_exit=null保留。
不由workflow success推定全部业务成功、全部自然exit0、远端进程普遍终止或原生GUI验收。

| 原始 ZIP/日志 | 字节 | 成员 | SHA256 |
| --- | ---: | ---: | --- |
| downloads/run-44040248806-attempt-1-logs.zip | 31638 | 12 | 9f4dd092230f08f7d62a39afd7f8d3fdc2cb3babf5c2a57c3d2d0a3cc9b35bac |
| downloads/artifact-14308319951.zip | 46863 | 34 | 88b9ed0cf60e25963af31155c227b2b39524ca5dc42767ba2cda7f3b5a690009 |
| downloads/run-44040248746-attempt-1-logs.zip | 31818 | 12 | 9459fda9f8418ff4250b333405007b7b62dac6271716f4169dfa51e516acd867 |
| downloads/artifact-14308219775.zip | 54235 | 46 | 352d64f9b905acd4cd8ad5f963e77985da4c22aec19d450327962476b0fa639a |

ZIP 4个，成员104个。
收集者离线检查196通过/0失败；独立review由父级另行安排。
artifact的本地SHA256与列表/单artifact API digest及长度独立复算，详见digest-verification.json。
run日志ZIP仅有本地下载摘要，API未提供服务端digest。
全部GET命令终态及原件字节回执见command-ledger.json；本地stage终态见commands/*/receipt.json。
本地/网络exit分布见exit-summary.json，封口时刷新；失败尝试、timeout、强制终止不会隐去。

精确pending边界见pending.json；未取得终态的平台不填测试总数。
没有本地测试、独立--list、原生GUI、安装、签名/公证、发行或完整产品验收。
父级负责独立复核、Git归档、提交推送及关闭本agent；本目录没有删除或触碰其他资源。
SHA256SUMS封口覆盖除自身外所有普通文件；seal-verification.json保留读回结果。
