#!/usr/bin/env python3
"""Collect bounded read-only GitHub Actions evidence in this directory only."""

from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import time
import zipfile

ROOT = Path(__file__).resolve().parent
CONTEXT = json.loads((ROOT / "context.json").read_text())
REPO = CONTEXT["repository"]
SOURCE = CONTEXT["engineering_source_sha"]
RUNS = CONTEXT["run_ids"]


def now():
    return datetime.now(timezone.utc).isoformat()


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def request(endpoint, destination, binary=False, text=False):
    destination.parent.mkdir(parents=True, exist_ok=True)
    receipt_path = destination.with_name(destination.name + ".receipt.json")
    if destination.exists() and receipt_path.exists():
        previous = json.loads(receipt_path.read_text())
        if previous.get("exit_code") == 0 and not previous.get("error"):
            return previous
    if receipt_path.exists():
        attempt = 1
        while receipt_path.with_name(
            receipt_path.name.replace(".receipt.json", f".attempt-{attempt:03d}.receipt.json")
        ).exists():
            attempt += 1
        receipt_path.rename(receipt_path.with_name(
            receipt_path.name.replace(".receipt.json", f".attempt-{attempt:03d}.receipt.json")
        ))
    started = now()
    tick = time.monotonic()
    argv = ["gh", "api", "--method", "GET", endpoint]
    if binary or text:
        argv.append("--allow-escape-sequences")
    receipt = {
        "started_at_utc": started,
        "method": "GET",
        "endpoint": endpoint,
        "argv": argv,
        "timeout_seconds": 55 if binary else 35,
        "path": str(destination.relative_to(ROOT)),
    }
    try:
        proc = subprocess.run(
            argv,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=receipt["timeout_seconds"],
        )
        receipt.update(
            exit_code=proc.returncode,
            natural_exit=proc.returncode >= 0,
            forced_termination=False,
            reaped=True,
            timed_out=False,
            stderr_bytes=len(proc.stderr),
            stderr_sha256=hashlib.sha256(proc.stderr).hexdigest(),
            completed_at_utc=now(),
            elapsed_seconds=round(time.monotonic() - tick, 6),
        )
        if proc.returncode:
            # Never record response headers, credential helpers, or environment.
            receipt["error"] = proc.stderr.decode(errors="replace")[:2000]
        else:
            if not binary and not text:
                json.loads(proc.stdout)
            destination.write_bytes(proc.stdout)
            receipt.update(
                bytes=len(proc.stdout),
                sha256=hashlib.sha256(proc.stdout).hexdigest(),
            )
            if binary:
                with zipfile.ZipFile(destination) as archive:
                    members = archive.infolist()
                    bad_member = archive.testzip()
                    receipt["zip"] = {
                        "member_count": len(members),
                        "uncompressed_bytes": sum(x.file_size for x in members),
                        "crc_valid": bad_member is None,
                        "bad_member": bad_member,
                        "members": [
                            {
                                "name": x.filename,
                                "bytes": x.file_size,
                                "compressed_bytes": x.compress_size,
                                "crc32": f"{x.CRC:08x}",
                            }
                            for x in members
                        ],
                    }
    except subprocess.TimeoutExpired:
        receipt.update(
            exit_code=None,
            natural_exit=False,
            forced_termination=True,
            timed_out=True,
            reaped=True,
            completed_at_utc=now(),
            elapsed_seconds=round(time.monotonic() - tick, 6),
            error="bounded gh api request timed out; subprocess.run killed and waited",
        )
    except Exception as exc:
        receipt.update(
            completed_at_utc=now(),
            elapsed_seconds=round(time.monotonic() - tick, 6),
            error=str(exc)[:2000],
        )
    dump(receipt_path, receipt)
    return receipt


def snapshot():
    prior = [
        int(p.name)
        for p in (ROOT / "snapshots").iterdir()
        if p.is_dir() and p.name.isdigit()
    ]
    snap = ROOT / "snapshots" / f"{max(prior, default=0) + 1:03d}"
    tasks = [
        (
            f"repos/{REPO}/actions/runs/{run_id}{suffix}",
            snap / f"{run_id}-{kind}.json",
        )
        for run_id in RUNS
        for kind, suffix in (
            ("run", ""),
            ("jobs", "/jobs?per_page=100&page=1"),
            ("artifacts", "/artifacts?per_page=100&page=1"),
        )
    ]
    with ThreadPoolExecutor(max_workers=6) as pool:
        futures = [pool.submit(request, endpoint, path) for endpoint, path in tasks]
        for future in as_completed(futures):
            receipt = future.result()
            if receipt.get("exit_code") != 0 or receipt.get("error"):
                print(json.dumps({"request_error": receipt}, ensure_ascii=False))
    return snap


def load(path):
    return json.loads(path.read_text()) if path.exists() else {}


def collect(snap):
    tasks = []
    bindings = []
    for run_id in RUNS:
        run = load(snap / f"{run_id}-run.json")
        jobs = load(snap / f"{run_id}-jobs.json")
        artifacts = load(snap / f"{run_id}-artifacts.json")
        if run.get("head_sha") != SOURCE:
            raise RuntimeError(f"Run {run_id} source mismatch or missing metadata")
        if jobs.get("total_count") != len(jobs.get("jobs", [])):
            raise RuntimeError(f"Run {run_id} job pagination is incomplete")
        if artifacts.get("total_count") != len(artifacts.get("artifacts", [])):
            raise RuntimeError(f"Run {run_id} artifact pagination is incomplete")
        if run_id == CONTEXT["quality_run_id"]:
            if sorted(j["id"] for j in jobs["jobs"]) != sorted(
                CONTEXT["quality_expected_jobs"]
            ):
                raise RuntimeError("Quality job IDs differ from requested inventory")
        print(
            json.dumps(
                {
                    "run_id": run_id,
                    "source_sha": run["head_sha"],
                    "status": run.get("status"),
                    "conclusion": run.get("conclusion"),
                    "jobs": [
                        {
                            k: job.get(k)
                            for k in ("id", "name", "status", "conclusion")
                        }
                        for job in jobs["jobs"]
                    ],
                    "artifact_count": artifacts["total_count"],
                }
            ),
            flush=True,
        )
        if run.get("status") == "completed":
            relative = f"downloads/run-{run_id}-attempt-{run['run_attempt']}-logs.zip"
            tasks.append(
                (f"repos/{REPO}/actions/runs/{run_id}/attempts/{run['run_attempt']}/logs",
                 ROOT / relative)
            )
            bindings.append(
                {
                    "kind": "run_log_archive",
                    "run_id": run_id,
                    "run_attempt": run["run_attempt"],
                    "source_sha": SOURCE,
                    "metadata_snapshot": str(snap.relative_to(ROOT)),
                    "path": relative,
                }
            )
        for job in jobs["jobs"]:
            if job.get("head_sha") != SOURCE or job.get("run_id") != run_id:
                raise RuntimeError(f"Job {job['id']} source/run mismatch")
            request(
                f"repos/{REPO}/actions/jobs/{job['id']}",
                snap / f"job-{job['id']}.json",
            )
            if job.get("status") == "completed" and job.get("conclusion") not in (
                "success",
                "skipped",
            ):
                # Failed/cancelled job details and raw log are fetched before
                # other downloads, including while sibling jobs are running.
                detail = ROOT / "failures" / f"job-{job['id']}.json"
                request(f"repos/{REPO}/actions/jobs/{job['id']}", detail)
                request(
                    f"repos/{REPO}/actions/jobs/{job['id']}/logs",
                    ROOT / "failures" / f"job-{job['id']}.log",
                    text=True,
                )
            elif job.get("status") == "completed" and run.get("status") != "completed":
                # Job logs are a raw text endpoint, not a log ZIP; the complete
                # immutable run ZIP remains the canonical final raw archive.
                if job.get("conclusion") != "skipped":
                    relative = f"downloads/job-{job['id']}-logs.txt"
                    request(
                        f"repos/{REPO}/actions/jobs/{job['id']}/logs",
                        ROOT / relative,
                        text=True,
                    )
                    bindings.append({
                        "kind": "job_log_text",
                        "run_id": run_id,
                        "run_attempt": run["run_attempt"],
                        "job_id": job["id"],
                        "source_sha": SOURCE,
                        "metadata_snapshot": str(snap.relative_to(ROOT)),
                        "path": relative,
                    })
        for artifact in artifacts["artifacts"]:
            if artifact.get("workflow_run", {}).get("head_sha") != SOURCE:
                raise RuntimeError(f"Artifact {artifact['id']} source mismatch")
            if artifact.get("workflow_run", {}).get("id") != run_id:
                raise RuntimeError(f"Artifact {artifact['id']} run mismatch")
            artifact_id = artifact["id"]
            metadata_path = ROOT / "artifacts" / f"{artifact_id}.json"
            request(f"repos/{REPO}/actions/artifacts/{artifact_id}", metadata_path)
            relative = f"downloads/artifact-{artifact_id}.zip"
            if not artifact.get("expired"):
                tasks.append(
                    (f"repos/{REPO}/actions/artifacts/{artifact_id}/zip", ROOT / relative)
                )
            bindings.append(
                {
                    "kind": "artifact_archive",
                    "run_id": run_id,
                    "run_attempt": run["run_attempt"],
                    "source_sha": SOURCE,
                    "artifact_id": artifact_id,
                    "name": artifact["name"],
                    "api_digest": artifact.get("digest"),
                    "api_size_in_bytes": artifact.get("size_in_bytes"),
                    "expired": artifact.get("expired"),
                    "metadata_snapshot": str(snap.relative_to(ROOT)),
                    "metadata_path": str(metadata_path.relative_to(ROOT)),
                    "path": relative,
                }
            )
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures = [
            pool.submit(request, endpoint, path, True) for endpoint, path in tasks
        ]
        for future in as_completed(futures):
            receipt = future.result()
            print(
                json.dumps(
                    {
                        "download": receipt["path"],
                        "exit_code": receipt.get("exit_code"),
                        "bytes": receipt.get("bytes"),
                        "sha256": receipt.get("sha256"),
                        "zip_members": receipt.get("zip", {}).get("member_count"),
                        "crc_valid": receipt.get("zip", {}).get("crc_valid"),
                        "error": receipt.get("error"),
                    }
                ),
                flush=True,
            )
    for binding in bindings:
        path = ROOT / binding["path"]
        if not path.exists():
            binding["downloaded"] = False
            continue
        binding["downloaded"] = True
        binding["bytes"] = path.stat().st_size
        binding["sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
        if binding["kind"] == "artifact_archive":
            binding["digest_matches_api"] = (
                binding["api_digest"] == "sha256:" + binding["sha256"]
            )
            binding["size_matches_api"] = binding["api_size_in_bytes"] == binding["bytes"]
        receipt = load(path.with_name(path.name + ".receipt.json"))
        binding["zip_crc_valid"] = receipt.get("zip", {}).get("crc_valid")
        binding["zip_member_count"] = receipt.get("zip", {}).get("member_count")
    dump(ROOT / "archive-bindings.json", bindings)
    dump(
        ROOT / "latest.json",
        {
            "observed_at_utc": now(),
            "snapshot": str(snap.relative_to(ROOT)),
            "elapsed_seconds": round(time.time() - CONTEXT["started_epoch"], 3),
            "all_terminal": all(
                load(snap / f"{run_id}-run.json").get("status") == "completed"
                for run_id in RUNS
            ),
        },
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--snapshot", action="store_true")
    args = parser.parse_args()
    if args.snapshot:
        snap = snapshot()
    else:
        snap = max((ROOT / "snapshots").iterdir(), key=lambda p: p.name)
    collect(snap)


if __name__ == "__main__":
    main()
