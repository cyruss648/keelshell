"""Verify exact-source CI originals offline; support truthful partial collection."""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent


def read(path):
    return json.loads((ROOT / path).read_text())


def dump(path, value):
    (ROOT / path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def sha(data):
    return hashlib.sha256(data).hexdigest()


summary, context = read("summary.json"), read("context.json")
source = context["engineering_source_sha"]
snap = ROOT / read("latest.json")["snapshot"]
checks, source_lines, observations = [], [], []


def check(name, passed, detail=None):
    checks.append({"name": name, "passed": bool(passed), "detail": detail})


check("requested run inventory", [r["id"] for r in summary["runs"]] == context["run_ids"])
check("exact engineering source on all runs", all(r["source_sha"] == source for r in summary["runs"]))
check("parsed inventories have no discrepancies", not summary["inventory_mismatches"])
check("no failed jobs observed", not summary["failed_jobs_observed"])
check("no token or private-key marker in downloaded bodies", not summary["secret_scan"]["hits"])
for run in summary["runs"]:
    metadata = read(snap.relative_to(ROOT) / f"{run['id']}-run.json")
    check(f"run {run['id']} exact ID/source/attempt",
          metadata["id"] == run["id"] and metadata["head_sha"] == source
          and metadata["run_attempt"] == run["run_attempt"] == 1)
    jobs = read(snap.relative_to(ROOT) / f"{run['id']}-jobs.json")
    artifacts = read(snap.relative_to(ROOT) / f"{run['id']}-artifacts.json")
    check(f"run {run['id']} complete job pagination", jobs["total_count"] == len(jobs["jobs"]))
    check(f"run {run['id']} complete artifact pagination",
          artifacts["total_count"] == len(artifacts["artifacts"]))
    if run["id"] == context["quality_run_id"]:
        check("Quality job identity unchanged", sorted(j["id"] for j in jobs["jobs"]) ==
              sorted(context["quality_expected_jobs"]))
    for job in jobs["jobs"]:
        detail_path = snap.relative_to(ROOT) / f"job-{job['id']}.json"
        if not (ROOT / detail_path).exists():
            detail_path = Path(f"jobs/{job['id']}.json")
        detail = read(detail_path)
        check(f"job {job['id']} list/detail source identity",
              all(detail[k] == job[k] for k in ("id", "run_id", "run_attempt", "head_sha", "name"))
              and detail["head_sha"] == source and detail["run_id"] == run["id"])
        if job["status"] == "completed":
            check(f"job {job['id']} terminal list/detail agreement",
                  all(detail[k] == job[k] for k in ("status", "conclusion", "steps")))
        elif detail["status"] != job["status"] or detail["steps"] != job["steps"]:
            observations.append({"job_id": job["id"], "kind": "list/detail timing difference",
                                 "list_status": job["status"], "detail_status": detail["status"]})
        inventory = read(f"inventories/job-{job['id']}.json")
        if run["status"] == "completed":
            expected = {s["number"] for s in job["steps"] if s["conclusion"] != "skipped"}
            check(f"job {job['id']} executed steps have original logs",
                  expected == {s["number"] for s in inventory["steps"]})
        if job["conclusion"] == "skipped":
            check(f"job {job['id']} skipped remains unexecuted", not inventory["steps"])
        checkout = next((s for s in inventory["steps"] if s["number"] == 2 and s["member"]), None)
        if checkout:
            with zipfile.ZipFile(ROOT / checkout["archive"]) as archive:
                lines = archive.read(checkout["member"]).decode("utf-8-sig").splitlines()
            found = [{"line": i + 1, "text": line} for i, line in enumerate(lines) if source in line]
            check(f"job {job['id']} checkout log binds source", bool(found))
            source_lines.append({"job_id": job["id"], "archive": checkout["archive"],
                                 "member": checkout["member"], "lines": found})
    for artifact in run["artifacts"]:
        aid = artifact["artifact_id"]
        check(f"artifact {aid} metadata identity", artifact.get("api_metadata_binding_matches"))
        if artifact.get("children_count"):
            check(f"artifact {aid} direct children reaped", artifact["all_children_reaped"])
        if "recorded_head_matches" in artifact:
            check(f"artifact {aid} recorded exact source", artifact["recorded_head_matches"])
            check(f"artifact {aid} native SSH names", artifact["native_ssh_inventory_matches_execution"])
        for wire in artifact.get("wire_checks", []):
            check(f"artifact {aid} {wire['operation']} exact wire and argv",
                  all(wire[k] for k in ("assembly_matches_wire", "receipt_argv_contains_exact_wire",
                                       "receipt_production_bytes_match", "serialized_command_digest_matches")))
        for interop in artifact.get("openssh_interop", []):
            counts = interop["stdout_rust"]
            check(f"artifact {aid} {interop['result_member']} interop names/counts",
                  interop["outcome"] == "passed" and interop["passed_tests"] == counts["passed"]
                  and counts["failed"] == 0 and counts["all_declarations_match"]
                  and counts["all_named_inventories_match"])
        if "process_cleanup" in artifact:
            seal, cleanup = artifact["original_process_seal"], artifact["process_cleanup"]
            check("SSH original seal HOLD retained", seal["state"] == "HOLD" and
                  seal["job_active_processes"] == seal["pending_process_objects"] == 1 and
                  seal["nonmaster_count"] == seal["nonmaster_naturally_terminal"] == 20)
            check("SSH cleanup completed", cleanup["state"] == "PASS" and cleanup["terminal_proven"]
                  and cleanup["job_active_processes"] == cleanup["pending_process_objects"] ==
                  cleanup["owned_handles_remaining"] == 0 and cleanup["closed"])
            check("SSH master cleanup nonzero and non-natural retained", cleanup["masters"] == [{
                "natural_terminal_before_cleanup": False, "exit_code": 125, "original_signaled": True}])
            check("SSH nonmaster natural nonzero distribution retained",
                  cleanup["nonmaster_exit_codes"] == {"255": 5, "0": 14, "1": 1})
            check("SSH temporary private directory removed", artifact["ssh_cleanup"]["temporary_directory_removed"])

manifest = read("archive-manifest.json")
digest_bindings = []
for entry in summary["archives"]:
    path = ROOT / entry["path"]
    if not entry.get("downloaded"):
        observations.append({"kind": "archive not downloaded", "path": entry["path"]})
        continue
    data = path.read_bytes()
    check(f"{path.name} original byte length/hash", len(data) == entry["bytes"] and sha(data) == entry["sha256"])
    if path.suffix == ".zip":
        with zipfile.ZipFile(path) as archive:
            check(f"{path.name} CRC/member inventory",
                  archive.testzip() is None and len(archive.infolist()) == entry["zip_member_count"])
            members = next(m["members"] for m in manifest if m["path"] == entry["path"])
            check(f"{path.name} all member byte lengths/hashes", len(members) == len(archive.infolist()) and all(
                len(archive.read(m["path"])) == m["bytes"] and sha(archive.read(m["path"])) == m["sha256"]
                for m in members))
    if entry["kind"] == "artifact_archive":
        single = read(entry["metadata_path"])
        listed = read(Path(entry["metadata_snapshot"]) / f"{entry['run_id']}-artifacts.json")
        listed = next(a for a in listed["artifacts"] if a["id"] == entry["artifact_id"])
        binding = {
            "artifact_id": entry["artifact_id"], "run_id": entry["run_id"], "path": entry["path"],
            "local_sha256": sha(data), "local_bytes": len(data),
            "list_digest": listed.get("digest"), "single_digest": single.get("digest"),
            "both_digests_match": listed.get("digest") == single.get("digest") == "sha256:" + sha(data),
            "both_sizes_match": listed.get("size_in_bytes") == single.get("size_in_bytes") == len(data),
            "both_source_ids_match": all(a.get("workflow_run", {}).get("head_sha") == source and
                                         a.get("workflow_run", {}).get("id") == entry["run_id"]
                                         for a in (single, listed)),
        }
        digest_bindings.append(binding)
        check(f"{path.name} independent local/list/single digest check",
              binding["both_digests_match"] and binding["both_sizes_match"] and binding["both_source_ids_match"])
dump("digest-verification.json", {"source_sha": source, "artifacts": digest_bindings,
                                  "run_log_digest_boundary": "Only local SHA256; GitHub run log API supplies no digest"})

requests = []
for path in sorted(ROOT.rglob("*.receipt.json")):
    value = json.loads(path.read_text())
    if "endpoint" in value:
        requests.append({"receipt": str(path.relative_to(ROOT)), **value})
check("network methods exclusively GET", bool(requests) and all(r["method"] == "GET" for r in requests))
for request in requests:
    check(f"{request['receipt']} natural command terminal",
          request.get("exit_code") == 0 and request.get("natural_exit") and request.get("reaped")
          and not request.get("timed_out") and not request.get("forced_termination") and not request.get("error"))
    if request.get("exit_code") == 0 and "bytes" in request:
        data = (ROOT / request["path"]).read_bytes()
        check(f"{request['receipt']} raw bytes retained", len(data) == request["bytes"] and sha(data) == request["sha256"])

quality = next(r for r in summary["runs"] if r["id"] == context["quality_run_id"])
for job in quality["jobs"]:
    if "ordinary_rust" in job:
        check(f"job {job['id']} ordinary Rust/rustdoc complete names",
              all(job[k]["all_named_inventories_match"] and job[k]["all_declarations_match"]
                  for k in ("ordinary_rust", "rustdoc")))
        check(f"job {job['id']} main Python success", job["python_main"]["outcome"].startswith("OK"))
windows = [a for r in summary["runs"] if r["id"] != context["quality_run_id"] for a in r["artifacts"]]
check("Windows artifacts preserve native_gui UNRUN",
      len(windows) == 2 and all(a["receipt"]["native_gui"] == "UNRUN" for a in windows))
api = next(r for r in summary["runs"] if r["id"] == 44040248806)
check("API isolated SSH remains skipped", any(j["conclusion"] == "skipped" and
      "Isolated OpenSSH" in j["name"] for j in api["jobs"]))
check("API direct artifact preserves SSH UNRUN", all(a["receipt"]["ssh"] == "UNRUN" for a in api["artifacts"]))
dump("source-checkout-lines.json", source_lines)
dump("pending.json", {
    "source_sha": source, "observed_at_utc": summary["observed_at_utc"],
    "snapshot": str(snap.relative_to(ROOT)), "all_runs_terminal": summary["all_runs_terminal"],
    "pending_runs": [r for r in summary["runs"] if r["status"] != "completed"],
    "collection_deadline_epoch": context["started_epoch"] + context["maximum_follow_seconds"],
})
verification = {
    "generated_at_utc": datetime.now(timezone.utc).isoformat(), "source_sha": source,
    "scope": "Collector offline verification, not independent review; no test execution",
    "checks_passed": sum(c["passed"] for c in checks), "checks_failed": sum(not c["passed"] for c in checks),
    "GET_requests": len(requests), "checks": checks, "observations": observations,
}
dump("verification.json", verification)
local = [{"receipt": str(p.relative_to(ROOT)), **json.loads(p.read_text())}
         for p in sorted((ROOT / "commands").glob("*/receipt.json"))]
dump("command-ledger.json", {"local": local, "GET": requests,
                            "boundary": "Current report receipt is added by sealing after natural command exit"})

lines = [
    "# 精确工程 CI 原件收集",
    "",
    f"工程 `{source}`，GET 观察 `{summary['observed_at_utc']}`，快照 `{snap.name}`。",
    "只写当前自有目录；未运行 Git、Cargo、产品、安装、workflow rerun 或 cancel。",
    "从已提交上一批封存仅读取所需普通文件；helper-provenance.json 记录来源及摘要。",
    "collect.py 仅将后续 single-job 元数据写入对应快照，避免复用旧 in_progress 元数据。",
    "",
    "| Run | ID | attempt | 状态 | conclusion |",
    "| --- | --- | ---: | --- | --- |",
]
for run in summary["runs"]:
    lines.append(f"| {run['name']} | {run['id']} | {run['run_attempt']} | {run['status']} | {run['conclusion']} |")
lines += ["", "| Quality 平台 / job | 普通 Rust pass/fail/ignored | rustdoc pass/fail/ignored | Python 主 run/skip |",
          "| --- | --- | --- | --- |"]
for job in quality["jobs"]:
    if "ordinary_rust" in job:
        rust, doc, py = job["ordinary_rust"], job["rustdoc"], job["python_main"]
        counts = lambda r: "/".join(str(r[k]) for k in ("passed", "failed", "ignored"))
        lines.append(f"| {job['name']} / {job['id']} | {counts(rust)} | {counts(doc)} | {py['run']}/{py['skipped']} |")
        lines.append(f"")
    else:
        lines.append(f"| {job['name']} / {job['id']} | UNKNOWN（{job['status']}，尚无完整终态日志） | UNKNOWN | UNKNOWN |")
lines += [
    "",
    "普通 Rust、rustdoc、Windows preflight、packaging、内嵌 helper、OpenSSH 及自定义 controller 单列；",
    "逐名库存、ignored 原因、可用 Python skip 原文、skipped steps 与完整逐步计数见 inventories/ 和 summary.json。",
    "Python quiet discovery 无逐名清单时仅记录总数与 skipped；OK 推算的非跳过数明确标记为 inferred。",
    "",
    "Windows/API 详细逐步计数：",
    "",
    "```json",
    json.dumps([{"run": r["id"], "jobs": [{"id": j["id"], "name": j["name"],
                 "status": j["status"], "conclusion": j["conclusion"], "counts": j["step_counts"]}
                for j in r["jobs"]]} for r in summary["runs"] if r["id"] != context["quality_run_id"]],
               ensure_ascii=False, indent=2),
    "```",
    "",
    "SSH 原 seal HOLD，21 原对象中20非master自然终态：0×14、255×5、1×1；master尚活，1 pending，22 owned handles。",
    "cleanup PASS且active/pending/owned handles均0、closed=true；master cleanup exit125，natural_terminal_before_cleanup=false。",
    "API isolated-SSH job skipped，direct API ssh=UNRUN；两份Windows artifact native_gui=UNRUN。",
    "API六个与SSH九个direct children记录reaped；SSH owned-sshd observed_exit=null保留。",
    "不由workflow success推定全部业务成功、全部自然exit0、远端进程普遍终止或原生GUI验收。",
    "",
    "| 原始 ZIP/日志 | 字节 | 成员 | SHA256 |",
    "| --- | ---: | ---: | --- |",
]
for entry in summary["archives"]:
    if entry.get("downloaded"):
        lines.append(f"| {entry['path']} | {entry['bytes']} | {entry.get('zip_member_count')} | {entry['sha256']} |")
lines += [
    "",
    f"ZIP {summary['archive_zip_count']}个，成员{summary['archive_member_count']}个。",
    f"收集者离线检查{verification['checks_passed']}通过/{verification['checks_failed']}失败；独立review由父级另行安排。",
    "artifact的本地SHA256与列表/单artifact API digest及长度独立复算，详见digest-verification.json。",
    "run日志ZIP仅有本地下载摘要，API未提供服务端digest。",
    f"全部GET命令终态及原件字节回执见command-ledger.json；本地stage终态见commands/*/receipt.json。",
    "本地/网络exit分布见exit-summary.json，封口时刷新；失败尝试、timeout、强制终止不会隐去。",
    "",
    "精确pending边界见pending.json；未取得终态的平台不填测试总数。",
    "没有本地测试、独立--list、原生GUI、安装、签名/公证、发行或完整产品验收。",
    "父级负责独立复核、Git归档、提交推送及关闭本agent；本目录没有删除或触碰其他资源。",
    "SHA256SUMS封口覆盖除自身外所有普通文件；seal-verification.json保留读回结果。",
    "",
]
(ROOT / "REPORT.md").write_text("\n".join(lines))
print(json.dumps({k: verification[k] for k in ("source_sha", "checks_passed", "checks_failed", "GET_requests")}))
if verification["checks_failed"]:
    print(json.dumps([c for c in checks if not c["passed"]], ensure_ascii=False))
raise SystemExit(1 if verification["checks_failed"] else 0)
