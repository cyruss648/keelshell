"""Seal collector files after all tracked subprocesses have naturally exited."""
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


def dump(name, value):
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


ledger = json.loads((ROOT / "command-ledger.json").read_text())
ledger["local"] = [{"receipt": str(p.relative_to(ROOT)), **json.loads(p.read_text())}
                   for p in sorted((ROOT / "commands").glob("*/receipt.json"))]
ledger["sealing_command"] = {
    "argv": ["python3", "-B", "seal.py"],
    "receipt_boundary": "This sealer's natural exit is returned by the outer exec tool, not self-certified here",
}
dump("command-ledger.json", ledger)
counts = {}
for kind, receipts in (("GET", ledger["GET"]), ("local_stages", ledger["local"])):
    counts[kind] = {
        "commands": len(receipts),
        "exit_codes": dict(Counter(str(r.get("exit_code")) for r in receipts)),
        "natural_exits": sum(r.get("natural_exit") is True for r in receipts),
        "reaped": sum(r.get("reaped") is True for r in receipts),
        "timed_out": sum(r.get("timed_out") is True for r in receipts),
        "forced_termination": sum(r.get("forced_termination") is True for r in receipts),
        "stderr_bytes": sum(r.get("stderr_bytes", 0) for r in receipts),
    }
dump("exit-summary.json", counts)
provenance = json.loads((ROOT / "helper-provenance.json").read_text())
provenance["current_helpers"] = [
    {"path": n, "bytes": (ROOT / n).stat().st_size, "sha256": sha((ROOT / n).read_bytes())}
    for n in ("collect.py", "analyze.py", "report.py", "run_stage.py", "seal.py")
]
provenance["adaptations"] = [
    "collect: store fresh single-job metadata under each numbered snapshot",
    "analyze: no local checkout HEAD claimed; exact engineering source supplied by parent",
    "report: adapt previous offline checks for this source, dynamic IDs and partial/pending collection",
    "seal: no Git read or mutation; refresh command ledger and exit totals after report completion",
]
dump("helper-provenance.json", provenance)
archives = json.loads((ROOT / "archive-manifest.json").read_text())
zips = [a for a in archives if a["path"].endswith(".zip") and a.get("downloaded")]
dump("length-summary.json", {
    "raw_ZIP_count": len(zips), "raw_ZIP_bytes": sum(a["bytes"] for a in zips),
    "ZIP_member_count": sum(len(a["members"]) for a in zips),
    "ZIP_members_uncompressed_bytes": sum(m["bytes"] for a in zips for m in a["members"]),
    "GET_count": len(ledger["GET"]),
    "GET_stdout_bytes": sum(r.get("bytes", 0) for r in ledger["GET"]),
})
excluded = {"SHA256SUMS", "seal-verification.json"}
payload = sorted(p for p in ROOT.rglob("*") if p.is_file() and p.name not in excluded)
assert all(not p.is_symlink() for p in payload)
entries = [(str(p.relative_to(ROOT)), sha(p.read_bytes()), p.stat().st_size) for p in payload]
assert all(sha((ROOT / name).read_bytes()) == digest and (ROOT / name).stat().st_size == size
           for name, digest, size in entries)
dump("seal-verification.json", {
    "generated_at_utc": datetime.now(timezone.utc).isoformat(),
    "verified_files": len(entries), "verified_bytes": sum(e[2] for e in entries),
    "mismatches": 0, "excludes_this_receipt_and_outer_checksum": True,
    "outer_checksum_covers_this_receipt": True,
    "scope": "Only this directory; no product/docs/Git/target/other-work writes or cleanup",
})
paths = sorted(p for p in ROOT.rglob("*") if p.is_file() and p.name != "SHA256SUMS")
(ROOT / "SHA256SUMS").write_text("".join(f"{sha(p.read_bytes())}  {p.relative_to(ROOT)}\n" for p in paths))
rows = (ROOT / "SHA256SUMS").read_text().splitlines()
assert len(rows) == len(paths)
assert {str(p.relative_to(ROOT)) for p in paths} == {row.split("  ", 1)[1] for row in rows}
for row in rows:
    digest, name = row.split("  ", 1)
    assert sha((ROOT / name).read_bytes()) == digest
print(json.dumps({
    "checksum_entries_verified": len(rows), "mismatches": 0,
    "total_files_including_checksum": len(paths) + 1,
    "SHA256SUMS_sha256": sha((ROOT / "SHA256SUMS").read_bytes()),
    "REPORT_sha256": sha((ROOT / "REPORT.md").read_bytes()),
    "exit_counts": counts,
}), flush=True)
