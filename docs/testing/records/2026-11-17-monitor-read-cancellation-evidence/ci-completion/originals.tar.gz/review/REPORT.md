# 独立 CI 原件复核

结论：**APPROVE_CI_EVIDENCE_ONLY**。任务A、B完成，P0/P1/P2/P3各0项实际发现。
限定接受精确工程 `6ae91d2e90668e7d9c04a2a7eea7c5de1bf6d3d4` 的既有Windows原件与新Quality终态证据。
此结论不覆盖父级正在修改的原生MCP滚动实现、完整原生矩阵、产品完成或发行。

范围：先读AGENTS、RTK、HANDOFF。只读取父级已封口目录 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-cancellation-ci-completion-20261117`；
唯一写入 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-cancellation-ci-review-20261117`。没有运行Git/Cargo、产品、安装或重跑工作流，没有创建chat/worktree。
父级封口目录195文件前后完整文件集、长度及摘要相等，`source-before.json`与`source-after.json`可复核。
所有终态与测试数先从API原件、ZIP、逐名测试输出重算，之后才比较父级summary。

## Quality终态与有界采集

首次GET于2026-11-17 08:08:28 UTC即为completed/success，三平台job全部completed/success。
只进行一轮，11次GET，4.478621秒完成全部元数据、jobs、artifacts、日志ZIP采集；
pending跟进0秒，未消耗允许的8分钟等待，不把父级07:56:50 UTC的pending倒写为成功。
11次GET均自然exit0/reaped，无timeout、强制终止或stderr。
精确run44040248864，attempt1；job133892795291(macOS)、133892795649(Windows)、
133892795682(Ubuntu)。新原件目录 `originals/quality-001/`。
`run.json:1`、`jobs.json:1`和三个`job-*.json:1`分别有head_sha、状态、步骤原件；
每个平台checkout步骤也有独立SHA原行，见`independent-results.json`。

| 平台 | 普通Rust通过/失败/ignored | rustdoc通过/失败/ignored | Python主run/skipped |
| --- | ---: | ---: | ---: |
| Windows | 3453/0/66 | 15/0/0 | 526/53 |
| macOS | 3466/0/68 | 15/0/0 | 526/3 |
| Ubuntu | 3459/0/69 | 15/0/0 | 526/3 |

每平台普通Rust96组、rustdoc6组，逐名状态、声明数量和每组结果数全部相等。
Rustdoc编译失败用例仍属于rustdoc通过。解析冻结每组开始时的类别：
Linux最后一个普通套件尚未打印summary时下一Doc-tests stderr已经出现，不按字面出现顺序误分类。
各平台其他Python步骤、内嵌Python、跳过步骤与所有ignored测试保存在inventories及decision中，
与Python主526分开；未将预检重跑或controller计为普通Rust新用例。

原始计数路径与行：

- `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-cancellation-ci-review-20261117/extracted/quality/run-logs/native (macos-26)/8_Rust quality gate.txt`：普通/Rustdoc逐名库存起止行 62–4989；Rustdoc结果行 4945, 4952, 4966, 4975, 4982, 4989；Python 21/23。
- `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-cancellation-ci-review-20261117/extracted/quality/run-logs/native (windows-2025)/8_Rust quality gate.txt`：普通/Rustdoc逐名库存起止行 59–4930；Rustdoc结果行 4886, 4893, 4907, 4916, 4923, 4930；Python 22/24。
- `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-cancellation-ci-review-20261117/extracted/quality/run-logs/native (ubuntu-24.04)/8_Rust quality gate.txt`：普通/Rustdoc逐名库存起止行 58–4982；Rustdoc结果行 4938, 4945, 4959, 4968, 4975, 4982；Python 22/24。

全部102组结果行及逐名位置在`inventories/<platform>-rust.json`与`evidence-index.json`，
对应字节来自原`originals/quality-001/run-logs.zip`成员，解压不改换行和内容。

## Windows既有原件

- API run44040248806、SSH run44040248746的head_sha、attempt、job、checkout和artifact元数据一致。
- API原日志`extracted/parent/run-44040248806-attempt-1-logs/Actual collectors and independent Windows APIs/4_Lab unit tests.txt:127–129`：
  Python111 run/3 skipped，逐名108 ok/3 skipped；capture replay原`6_*.txt:43`为Rust1通过/0失败/18 filtered。
- SSH原日志`extracted/parent/run-44040248746-attempt-1-logs/Actual Windows OpenSSH and original remote processes/4_SSH ownership and integration lab unit tests.txt:113–115`：
  Python96 run/1 skipped，逐名95 ok/1 skipped；
  `extracted/parent/artifact-14308219775/native-ssh-client.stdout:2–5`为真实SSH Rust1通过/0失败。
- API三个Python跳过与SSH一个跳过均为Windows上不适用的负向非Windows边界；逐名原因在对应inventory。
  API另有isolated SSH job133892796479，原件`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-cancellation-ci-completion-20261117/jobs/133892796479.json:1`保留`skipped`；
  这不是capture replay通过所证明的真实SSH。
- 两份Windows artifact均`native_gui=UNRUN`，原行`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-cancellation-ci-review-20261117/extracted/parent/artifact-14308319951/receipt.json:15`与
  `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-cancellation-ci-review-20261117/extracted/parent/artifact-14308219775/receipt.json:6`；未执行独立Windows或GUI重跑。

## SSH进程与清理边界

- 原seal为HOLD、terminal_proven=false：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-cancellation-ci-review-20261117/extracted/parent/artifact-14308219775/ssh-debug-originals.json:3`。21个原对象的完整census
  在seal中只有master仍活着，不能称seal自然终态通过。
- 20个非master均有原对象自然终态证据：exit0×14、255×5、1×1。
  五个255的全部精确原行在`evidence-index.json/ssh_nonmaster_255`，
  1的原行`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-cancellation-ci-review-20261117/extracted/parent/artifact-14308219775/ssh-debug-originals.json:122`。未把这些非零退出抹为零。
- master最终cleanup exit125：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-cancellation-ci-review-20261117/extracted/parent/artifact-14308219775/ssh-debug-cleanup.json:17`，
  natural_terminal_before_cleanup=false：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-cancellation-ci-review-20261117/extracted/parent/artifact-14308219775/ssh-debug-cleanup.json:18`。
  owner外层`observed_exit=null`亦保留，不凭direct_reaped捏造自然exit0。
- cleanup原件记录21个原身份集合不变、job active0、pending0、owned handles0、debug connections0、
  全debug事件continued且无fallback detach或errors；临时私钥目录已移除
  `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-cancellation-ci-review-20261117/extracted/parent/artifact-14308219775/ssh-cleanup.json:2`，未上传私钥或私有客户端配置。
- 四个生产PowerShell operation分别绑定pid+creation_time，均是自然exit0；
  此限定事实不扩大为所有SSH进程exit0，详情`process-terminal-inventory.json`逐项链接原行。

macOS与Linux新OpenSSH artifact各有真实interop18/0/0及forwarding6/0/0。
四个`result.json`与各自tests.log逐名、结果数、步骤exit0、字节长度相符，原路径见
`independent-results.json/openssh_interop`及`inventories/interop-*.json`。
cleanup原件记录observed/owned进程停止、临时目录删除、ancestry_unverified空；
保留其累计祖先观察边界，不能证明在观察间隙完全脱离且未观察到的后代。

## ZIP、官方digest与完整性

共7个原始ZIP/172成员：父级4/104、新Quality3/68。逐ZIP CRC、成员长度/摘要、
重复路径与不安全成员检查通过；`zip-inventory.json`保存原ZIP路径、每成员路径与SHA。
四个artifact的官方列表和单项API digest、字节长度及head_sha相符：

| Artifact | Run | ZIP bytes | SHA-256 |
| --- | --- | ---: | --- |
| 14308219775 | 44040248746 | 54235 | `352d64f9b905acd4cd8ad5f963e77985da4c22aec19d450327962476b0fa639a` |
| 14308319951 | 44040248806 | 46863 | `88b9ed0cf60e25963af31155c227b2b39524ca5dc42767ba2cda7f3b5a690009` |
| 14309968324 | 44040248864 | 5593 | `32554df4c5b873765d210dbde7417b255ad8adcc762a1bee737058312681c0b0` |
| 14309783967 | 44040248864 | 5512 | `d44532b440cc0ca0f25a56421463c61865247507c7eb0cd05ec081f41ade9df0` |

日志ZIP的GitHub API没有服务端digest，本地SHA只提供已下载字节绑定，未声称官方digest认证。
父级外层194条SHA256SUMS覆盖除自身外全部文件。独立复核父级66次GET及8个local stage的
自然exit0/reaped/无timeout回执，并逐GET绑定原输出长度/摘要；
这是文档回执核对，不是重新执行收集者或Windows产品。

## 独立检查、尝试与父级复核入口

最终`recompute-r3`：**3318通过/0失败**，exit0/reaped，0.204689秒；
逐检查见`independent-checks.json`。本复核未新增产品测试运行。
原`recompute-r1`及r2两个helper exit1已保留：前者错误要求debug owner外层exit0，
后者误将receipt JSON纳入job元数据。二者是本复算工具分类/选文件问题，修后仅重算原件，
没有修产品或重跑CI。代码/原失败结果在`analysis-history/`，自然退出和traceback在`receipts/`。
`exit-summary.json`区分11个GET和本地各阶段；最终report阶段回执在结束后由父driver写入。

父级请另外核对新Quality关键原件：

1. `originals/quality-001/run.json`、`jobs.json`、三个`job-*.json`的精确SHA与终态。
2. `originals/quality-001/run-logs.zip`的各平台`8_Rust quality gate.txt`及checkout成员。
3. `artifact-14309783967.json/.zip`与`artifact-14309968324.json/.zip`对官方列表的digest和长度。
4. 四个artifact内`result.json`、`tests.log`及cleanup边界。
5. `decision.json`和`evidence-index.json`：不得把CI成功代签原生MCP滚动修复或完整产品验收。

本任务已结束，无剩余pending工作。所有新增材料仍仅在分配review目录，等待父级封存并关闭本子任务。
