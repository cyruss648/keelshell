"""Recompute CI facts from original metadata, ZIP bytes and individual tests."""

from collections import Counter
import json
from pathlib import Path
import re

from review_io import ROOT, RUN_ID, SOURCE_SHA, digest, now, write_json

SOURCE = Path(json.loads((ROOT / "context.json").read_bytes())["source"])
CHECKS = []
ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
TIMESTAMP = re.compile(r"^\ufeff?\d{4}-\d\d-\d\dT\S+ ")
RESULT = re.compile(
    r"^test result: (?P<outcome>\w+)\. (?P<passed>\d+) passed; "
    r"(?P<failed>\d+) failed; (?P<ignored>\d+) ignored; "
    r"(?P<measured>\d+) measured; (?P<filtered>\d+) filtered out;"
)
TEST = re.compile(
    r"^test (?P<name>.+?) \.\.\. (?P<status>ok|FAILED|ignored)(?:, .*)?$"
)


def check(label, condition, evidence):
    CHECKS.append(
        {"label": label, "passed": bool(condition), "evidence": evidence}
    )


def load(path):
    return json.loads(path.read_bytes())


def lines(path):
    return [
        (i + 1, TIMESTAMP.sub("", ANSI.sub("", value)))
        for i, value in enumerate(path.read_text(encoding="utf-8-sig").splitlines())
    ]


def location(path, line=None):
    out = str(path)
    return f"{out}:{line}" if line is not None else out


def rust_inventory(path):
    """Freeze group kind at `running`: stderr may lead the previous stdout."""
    kind, binary = "ordinary", None
    active, groups, prefixes = None, [], []
    for number, text in lines(path):
        if text.lstrip().startswith("Doc-tests "):
            kind, binary = "rustdoc", text.strip()
        elif re.match(r"^\s*Running\s+(?:unittests|tests/)", text):
            kind, binary = "ordinary", text.strip()
        start = re.fullmatch(r"running (\d+) tests?", text)
        if start:
            check("no overlapping Rust group", active is None, location(path, number))
            active = {
                "kind": kind,
                "binary": binary,
                "declared": int(start[1]),
                "start_line": number,
                "tests": [],
            }
        # Embedded Python unittest progress may prefix a Rust harness record.
        candidate = text
        prefix = re.match(r"^([.s]+)(test .+ \.\.\. (?:ok|FAILED|ignored).*)$", text)
        if prefix:
            candidate = prefix[2]
            prefixes.append({"line": number, "prefix": prefix[1]})
        case = TEST.fullmatch(candidate)
        if case and active is not None:
            active["tests"].append(
                {"name": case["name"], "status": case["status"], "line": number}
            )
        summary = RESULT.match(text)
        if summary:
            check("Rust result has declared group", active is not None, location(path, number))
            if active is None:
                continue
            counts = {k: int(summary[k]) for k in ("passed", "failed", "ignored", "measured", "filtered")}
            active.update(counts)
            active["result_line"] = number
            active["outcome"] = summary["outcome"]
            observed = Counter(t["status"] for t in active["tests"])
            expected = Counter(
                {"ok": counts["passed"], "FAILED": counts["failed"], "ignored": counts["ignored"]}
            )
            check("Rust per-name counts equal result", observed == expected, location(path, number))
            check(
                "Rust declared count equals result",
                active["declared"] == counts["passed"] + counts["failed"] + counts["ignored"],
                location(path, active["start_line"]),
            )
            names = [t["name"] for t in active["tests"]]
            check("Rust names unique within group", len(names) == len(set(names)), location(path, number))
            check("Rust group has no failures", counts["failed"] == 0 and summary["outcome"] == "ok", location(path, number))
            groups.append(active)
            active = None
    check("all Rust groups closed", active is None, str(path))
    totals = {}
    for category in ("ordinary", "rustdoc"):
        selected = [g for g in groups if g["kind"] == category]
        totals[category] = {
            "groups": len(selected),
            **{key: sum(g[key] for g in selected) for key in ("passed", "failed", "ignored", "measured", "filtered")},
        }
    return {
        "path": str(path),
        "totals": totals,
        "groups": groups,
        "recognized_embedded_python_prefixes": prefixes,
    }


def python_results(path, require_names=False):
    raw = lines(path)
    results, names, skipped = [], [], []
    for n, text in raw:
        case = re.match(r"^(test_\S+ \(.+?\)) \.\.\. (ok|skipped .+|FAIL|ERROR)$", text)
        if case:
            names.append({"name": case[1], "status": case[2], "line": n})
            if case[2].startswith("skipped"):
                skipped.append({"name": case[1], "reason": case[2][8:], "line": n})
        match = re.fullmatch(r"Ran (\d+) tests? in ([\d.]+)s", text)
        if match:
            following = next(((ln, value) for ln, value in raw if ln > n and value), None)
            ok = following is not None and re.fullmatch(r"OK(?: \(skipped=(\d+)\))?", following[1])
            skip = int(ok[1]) if ok and ok[1] else 0
            result = {
                "run": int(match[1]), "skipped": skip,
                "seconds": float(match[2]), "run_line": n,
                "terminal_line": following[0] if following else None,
                "terminal": following[1] if following else None,
            }
            check("Python unittest terminal is OK", bool(ok), location(path, n))
            results.append(result)
    if require_names:
        check("one Python summary for lab", len(results) == 1, str(path))
        if len(results) == 1:
            check("Python per-name count equals run", len(names) == results[0]["run"], str(path))
            check("Python individual skips equal summary", len(skipped) == results[0]["skipped"], str(path))
            check("Python individual cases are nonfailed", all(t["status"] == "ok" or t["status"].startswith("skipped") for t in names), str(path))
    return {"path": str(path), "results": results, "tests": names, "skips": skipped}


# First establish the parent seal independently, without its derived summary.
seal = SOURCE / "SHA256SUMS"
covered = []
for n, text in enumerate(seal.read_text().splitlines(), 1):
    expected, relative = text.split("  ", 1)
    path = SOURCE / relative
    covered.append(relative)
    check("parent sealed file exists", path.is_file(), location(seal, n))
    check("parent sealed file sha256", path.is_file() and digest(path.read_bytes()) == expected, location(seal, n))
actual = sorted(p.relative_to(SOURCE).as_posix() for p in SOURCE.rglob("*") if p.is_file())
check("parent seal covers exact file set", sorted(covered + ["SHA256SUMS"]) == actual, str(seal))
check("parent seal paths unique", len(covered) == len(set(covered)), str(seal))

expected_runs = {44040248746, 44040248806, RUN_ID}
metadata_counts = Counter()
for path in sorted((SOURCE / "snapshots").glob("*/*-run.json")):
    data = load(path)
    check("snapshot exact run ID", data["id"] in expected_runs, str(path))
    check("snapshot exact source", data["head_sha"] == SOURCE_SHA, str(path))
    check("snapshot attempt one", data["run_attempt"] == 1, str(path))
    check("snapshot repository exact", data["repository"]["full_name"] == "cyruss648/keelshell", str(path))
    metadata_counts["run"] += 1
for path in sorted((SOURCE / "snapshots").glob("*/*-jobs.json")):
    data = load(path)
    check("snapshot jobs pagination complete", data["total_count"] == len(data["jobs"]), str(path))
    for job in data["jobs"]:
        check("snapshot job exact source", job["head_sha"] == SOURCE_SHA, str(path))
        check("snapshot job exact run", job["run_id"] in expected_runs, str(path))
        metadata_counts["job"] += 1

archive_inventory = load(ROOT / "zip-inventory.json")
for archive in archive_inventory:
    check("ZIP current bytes match independent inventory", digest(Path(archive["path"]).read_bytes()) == archive["sha256"], archive["path"])
    for member in archive["members"]:
        p = ROOT / member["extracted"]
        check("ZIP member size", p.stat().st_size == member["bytes"] == member["zip_uncompressed_bytes"], str(p))
        check("ZIP member sha256", digest(p.read_bytes()) == member["sha256"], str(p))

artifact_bindings = []
parent_artifacts = [
    (14308219775, 44040248746), (14308319951, 44040248806)
]
for artifact_id, run_id in parent_artifacts:
    meta = SOURCE / f"artifacts/{artifact_id}.json"
    individual = load(meta)
    data = (SOURCE / f"downloads/artifact-{artifact_id}.zip").read_bytes()
    for snapshot in sorted((SOURCE / "snapshots").glob(f"*/{run_id}-artifacts.json")):
        listing = load(snapshot)
        check("parent artifact listing complete", listing["total_count"] == len(listing["artifacts"]), str(snapshot))
        for a in listing["artifacts"]:
            if a["id"] != artifact_id:
                continue
            check("parent list/individual artifact metadata equal", a == individual, str(snapshot))
    check("parent artifact digest official", individual["digest"] == f"sha256:{digest(data)}", str(meta))
    check("parent artifact byte length official", individual["size_in_bytes"] == len(data), str(meta))
    check("parent artifact exact run", individual["workflow_run"]["id"] == run_id, str(meta))
    check("parent artifact exact source", individual["workflow_run"]["head_sha"] == SOURCE_SHA, str(meta))
    artifact_bindings.append({"id": artifact_id, "run_id": run_id, "bytes": len(data), "sha256": digest(data), "metadata": str(meta)})

qroot = ROOT / "originals/quality-001"
qrun = load(qroot / "run.json")
qjobs = load(qroot / "jobs.json")
check("Quality exact source", qrun["head_sha"] == SOURCE_SHA, str(qroot / "run.json"))
check("Quality completed success", qrun["status"] == "completed" and qrun["conclusion"] == "success", str(qroot / "run.json"))
check("Quality jobs exactly three", len(qjobs["jobs"]) == qjobs["total_count"] == 3, str(qroot / "jobs.json"))
for job in qjobs["jobs"]:
    individual = load(qroot / f"job-{job['id']}.json")
    check("Quality job exact head", individual["head_sha"] == job["head_sha"] == SOURCE_SHA, str(qroot / f"job-{job['id']}.json"))
    check("Quality job exact run", individual["run_id"] == job["run_id"] == RUN_ID, str(qroot / f"job-{job['id']}.json"))
    check("Quality job completed success", individual["status"] == job["status"] == "completed" and individual["conclusion"] == job["conclusion"] == "success", str(qroot / f"job-{job['id']}.json"))
    check("Quality steps equal list/individual", individual["steps"] == job["steps"], str(qroot / f"job-{job['id']}.json"))
    for step in individual["steps"]:
        check("Quality step no failed outcome", step["conclusion"] in ("success", "skipped"), str(qroot / f"job-{job['id']}.json") + f"#steps[{step['number']}]")

for artifact in load(qroot / "artifacts.json")["artifacts"]:
    meta = qroot / f"artifact-{artifact['id']}.json"
    individual = load(meta)
    data = (qroot / f"artifact-{artifact['id']}.zip").read_bytes()
    check("Quality artifact list/individual equal", artifact == individual, str(meta))
    check("Quality artifact digest official", artifact["digest"] == f"sha256:{digest(data)}", str(meta))
    check("Quality artifact byte length official", artifact["size_in_bytes"] == len(data), str(meta))
    check("Quality artifact source", artifact["workflow_run"]["head_sha"] == SOURCE_SHA, str(meta))
    check("Quality artifact run", artifact["workflow_run"]["id"] == RUN_ID, str(meta))
    artifact_bindings.append({"id": artifact["id"], "run_id": RUN_ID, "bytes": len(data), "sha256": digest(data), "metadata": str(meta)})

results = {"source_sha": SOURCE_SHA, "computed_utc": now(), "artifact_bindings": artifact_bindings}
platform_results = {}
for platform in ("macos-26", "windows-2025", "ubuntu-24.04"):
    folder = ROOT / f"extracted/quality/run-logs/native ({platform})"
    quality = folder / "8_Rust quality gate.txt"
    rust = rust_inventory(quality)
    python = python_results(quality)
    check("Quality ordinary inventory 96 groups", rust["totals"]["ordinary"]["groups"] == 96, str(quality))
    check("Quality rustdoc inventory six groups", rust["totals"]["rustdoc"]["groups"] == 6, str(quality))
    check("Quality has main Python suite", len(python["results"]) >= 1 and python["results"][0]["run"] == 526, str(quality))
    check("Quality rustdoc count", rust["totals"]["rustdoc"]["passed"] == 15, str(quality))
    # Independently confirm exact checkout identity in this job's own log.
    checkout = next(folder.glob("2_Run actions_checkout*.txt"))
    pinned_lines = [n for n, text in lines(checkout) if text.strip() == SOURCE_SHA]
    check("Quality checkout log pins source", bool(pinned_lines), str(checkout))
    write_json(f"inventories/{platform}-rust.json", rust)
    write_json(f"inventories/{platform}-python.json", python)
    platform_results[platform] = {
        "rust": rust["totals"],
        "python_main": python["results"][0] if python["results"] else None,
        "python_embedded": python["results"][1:],
        "quality_log": str(quality),
        "checkout": str(checkout),
        "checkout_source_lines": pinned_lines,
    }
results["quality"] = platform_results

lab_data = {}
for artifact_id, run_id in parent_artifacts:
    logroot = ROOT / f"extracted/parent/run-{run_id}-attempt-1-logs"
    lab = next(logroot.glob("*/4_*.txt"))
    py = python_results(lab, require_names=True)
    write_json(f"inventories/windows-{run_id}-python.json", py)
    checkout = next(logroot.glob("*/2_Run actions_checkout*.txt"))
    check("Windows checkout pinned exact source", any(text.strip() == SOURCE_SHA for _, text in lines(checkout)), str(checkout))
    artifact = ROOT / f"extracted/parent/artifact-{artifact_id}"
    receipt = load(artifact / "receipt.json")
    check("Windows artifact native GUI remains UNRUN", receipt["native_gui"] == "UNRUN", str(artifact / "receipt.json"))
    check("Windows API receipt PASS", receipt["windows_api"] == "PASS", str(artifact / "receipt.json"))
    for index, child in enumerate(receipt["children"]):
        evidence = str(artifact / "receipt.json") + f"#children[{index}]"
        check("Windows direct child naturally reaped zero", child["observed_exit"] == 0 and child["terminal"]["direct_reaped"], evidence)
        check("Windows direct child no pending descendants", child["terminal"]["active_processes"] == 0 and child["terminal"]["native_process_objects"]["pending_process_objects"] == 0, evidence)
        check("Windows direct child pipes drained", child["terminal"]["pipes_drained"], evidence)
        check("Windows direct child no terminal errors", child["terminal"]["errors"] == [] and child["errors"] == [], evidence)
    lab_data[str(run_id)] = {"python": py["results"], "skips": py["skips"], "native_gui": receipt["native_gui"], "direct_children": len(receipt["children"])}
    if run_id == 44040248806:
        replay = next(logroot.glob("*/6_*.txt"))
        replay_rust = rust_inventory(replay)
        write_json("inventories/windows-api-capture-replay.json", replay_rust)
        lab_data[str(run_id)]["capture_replay"] = replay_rust["totals"]
        check("API receipt does not claim SSH", receipt["ssh"] == "UNRUN", str(artifact / "receipt.json"))
    else:
        check("SSH artifact source exact", receipt["source"] == SOURCE_SHA, str(artifact / "receipt.json"))
        client = rust_inventory(artifact / "native-ssh-client.stdout")
        write_json("inventories/windows-native-ssh.json", client)
        lab_data[str(run_id)]["native_ssh"] = client["totals"]
        check("SSH original source-head", (artifact / "source-head.stdout").read_text().strip() == SOURCE_SHA, str(artifact / "source-head.stdout"))
        check("SSH original source-status empty", not (artifact / "source-status.stdout").read_bytes(), str(artifact / "source-status.stdout"))
        client_json = load(artifact / "rust-client.json")
        check("SSH Rust result PASS", client_json["status"] == "PASS" and client_json["errors"] == [], str(artifact / "rust-client.json"))
        for index, assertion in enumerate(client_json["assertion_evidence"]):
            check("SSH Rust assertion passed", assertion["passed"] is True, str(artifact / "rust-client.json") + f"#assertion_evidence[{index}]")
results["windows_labs"] = lab_data

ssh = ROOT / "extracted/parent/artifact-14308219775"
seal_data, cleanup_data = load(ssh / "ssh-debug-originals.json"), load(ssh / "ssh-debug-cleanup.json")
check("SSH seal remains HOLD", seal_data["state"] == "HOLD" and not seal_data["terminal_proven"], str(ssh / "ssh-debug-originals.json"))
check("SSH seal complete census", seal_data["complete_original_object_census"] and seal_data["job_total_processes"] == len(seal_data["admissions"]) == 21, str(ssh / "ssh-debug-originals.json"))
identities = lambda data: {(a["pid"], a["creation_time"]): a for a in data["admissions"]}
before, after = identities(seal_data), identities(cleanup_data)
check("SSH exact original identities preserved through cleanup", set(before) == set(after) and len(after) == 21, str(ssh / "ssh-debug-cleanup.json"))
nonmasters = [a for a in seal_data["admissions"] if not a["is_master"]]
masters = [a for a in seal_data["admissions"] if a["is_master"]]
check("SSH twenty nonmasters natural terminals", len(nonmasters) == 20 and all(a["natural_terminal_before_cleanup"] and a["original_signaled"] and a["exit_event_received"] and a["exit_event_continued"] for a in nonmasters), str(ssh / "ssh-debug-originals.json"))
exit_counts = Counter(a["exit_code"] for a in nonmasters)
check("SSH nonmaster nonzero exits retained", exit_counts == Counter({0: 14, 255: 5, 1: 1}), str(ssh / "ssh-debug-originals.json"))
check("SSH master is not natural at seal", len(masters) == 1 and not masters[0]["natural_terminal_before_cleanup"] and masters[0]["exit_code"] is None, str(ssh / "ssh-debug-originals.json"))
master_final = after[(masters[0]["pid"], masters[0]["creation_time"])]
check("SSH master cleanup exit125 not natural", master_final["exit_code"] == 125 and not master_final["natural_terminal_before_cleanup"], str(ssh / "ssh-debug-cleanup.json"))
check("SSH cleanup terminal proof exact", cleanup_data["state"] == "PASS" and cleanup_data["terminal_proven"] and cleanup_data["closed"] and cleanup_data["job_active_processes"] == cleanup_data["pending_process_objects"] == cleanup_data["owned_handles_remaining"] == cleanup_data["debug_connections"] == 0, str(ssh / "ssh-debug-cleanup.json"))
check("SSH cleanup no detached fallback or errors", cleanup_data["fallback_detaches"] == 0 and not cleanup_data["pending_debug_event"] and cleanup_data["errors"] == [], str(ssh / "ssh-debug-cleanup.json"))
check("SSH cleanup debug events continued", cleanup_data["debug_events_received"] == cleanup_data["debug_events_continued"], str(ssh / "ssh-debug-cleanup.json"))
binding = load(ssh / "ssh-production-binding.json")
for op in binding["operations"]:
    identity = (op["pid"], op["creation_time"])
    check("SSH operation binds exact natural original zero", identity in before and before[identity]["natural_terminal_before_cleanup"] and before[identity]["exit_code"] == op["exit_code"] == 0, str(ssh / "ssh-production-binding.json") + "#" + op["operation"])
check("SSH production binding four operations", {o["operation"] for o in binding["operations"]} == {"probe", "resources", "processes", "sockets"}, str(ssh / "ssh-production-binding.json"))
cleanup = load(ssh / "ssh-cleanup.json")
check("SSH private directory removed without credential upload", cleanup["temporary_directory_removed"] and not cleanup["private_config_uploaded"] and not cleanup["keys_uploaded"], str(ssh / "ssh-cleanup.json"))
results["ssh_lifecycle"] = {
    "seal_state": seal_data["state"], "seal_terminal_proven": seal_data["terminal_proven"],
    "originals": len(before), "nonmaster_exit_counts": dict(exit_counts),
    "master_cleanup_exit": master_final["exit_code"],
    "master_natural_terminal_before_cleanup": master_final["natural_terminal_before_cleanup"],
    "cleanup_state": cleanup_data["state"],
    "cleanup_temporary_directory_removed": cleanup["temporary_directory_removed"],
    "not_all_remote_processes_exit_zero": True,
}

# Native OpenSSH artifacts: count individual test names, then bind the wrapper.
interop = []
for result_path in sorted((ROOT / "extracted/quality").glob("artifact-*/**/result.json")):
    result = load(result_path)
    tests = rust_inventory(result_path.parent / "tests.log")
    write_json(f"inventories/interop-{result_path.parent.name}.json", tests)
    counts = tests["totals"]["ordinary"]
    suite = result["command"][result["command"].index("--test") + 1]
    check("OpenSSH individual tests match wrapper", result["passed_tests"] == counts["passed"] and counts["failed"] == counts["ignored"] == 0, str(result_path))
    check("OpenSSH outcome passed", result["outcome"] == "passed", str(result_path))
    check("OpenSSH steps exit zero", all(s["returncode"] == 0 for s in result["steps"]), str(result_path))
    check("OpenSSH owned cleanup recorded", result["cleanup"]["owned_processes_stopped"] and result["cleanup"]["observed_processes_stopped"] and result["cleanup"]["temporary_directory_removed"] and result["cleanup"]["ancestry_unverified"] == [], str(result_path))
    check("OpenSSH cleanup boundary retained", "detached entirely between observations" in result["cleanup"]["ownership_boundary"], str(result_path))
    for name, length in result["logs"].items():
        p = result_path.parent / name
        check("OpenSSH wrapper log byte lengths", p.stat().st_size == length, str(p))
    interop.append({"platform": result["platform"], "suite": suite, "counts": counts, "result": str(result_path), "cleanup": result["cleanup"]})
results["openssh_interop"] = interop

write_json("independent-results.json", results)
write_json("independent-checks.json", {"checks": CHECKS, "passed": sum(c["passed"] for c in CHECKS), "failed": sum(not c["passed"] for c in CHECKS)})
print("Checks", sum(c["passed"] for c in CHECKS), "passed", sum(not c["passed"] for c in CHECKS), "failed")
for c in CHECKS:
    if not c["passed"]:
        print("MISMATCH", c["label"], c["evidence"])
print(json.dumps({p: r["rust"] for p, r in platform_results.items()}, indent=2))
raise SystemExit(1 if any(not c["passed"] for c in CHECKS) else 0)
