"""Independently inventory all original ZIPs and safely expose line evidence."""

import json
from pathlib import Path, PurePosixPath
import stat
import zipfile

from review_io import ROOT, digest, write_json

source = Path(json.loads((ROOT / "context.json").read_text())["source"])
archives = [("parent", p) for p in sorted((source / "downloads").glob("*.zip"))]
archives += [
    ("quality", p)
    for p in sorted((ROOT / "originals/quality-001").glob("*.zip"))
]
inventory = []
for group, path in archives:
    data = path.read_bytes()
    entry = {
        "group": group,
        "path": str(path),
        "bytes": len(data),
        "sha256": digest(data),
        "members": [],
    }
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names)), "duplicate archive members"
        assert archive.testzip() is None, "CRC failed"
        for info in archive.infolist():
            relative = PurePosixPath(info.filename)
            assert not relative.is_absolute() and ".." not in relative.parts
            assert not stat.S_ISLNK(info.external_attr >> 16)
            assert not info.is_dir()
            content = archive.read(info)
            destination = ROOT / "extracted" / group / path.stem / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            assert not destination.exists(), "would replace extracted original"
            destination.write_bytes(content)
            entry["members"].append(
                {
                    "member": info.filename,
                    "bytes": len(content),
                    "zip_uncompressed_bytes": info.file_size,
                    "crc32": f"{info.CRC:08x}",
                    "sha256": digest(content),
                    "extracted": destination.relative_to(ROOT).as_posix(),
                }
            )
    inventory.append(entry)
write_json("zip-inventory.json", inventory)
for item in inventory:
    print(item["group"], Path(item["path"]).name, len(item["members"]))
print("TOTAL", len(inventory), sum(len(a["members"]) for a in inventory))
