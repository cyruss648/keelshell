"""Fetch exact-source Quality metadata and, after completion, original ZIPs."""

from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import sys

from review_io import ROOT, REPOSITORY, SOURCE_SHA, RUN_ID, get, now, write_json

round_id = sys.argv[1]
directory = f"originals/quality-{round_id}"
endpoints = [
    (f"repos/{REPOSITORY}/actions/runs/{RUN_ID}", "run.json"),
    (
        f"repos/{REPOSITORY}/actions/runs/{RUN_ID}/jobs?filter=all&per_page=100",
        "jobs.json",
    ),
    (
        f"repos/{REPOSITORY}/actions/runs/{RUN_ID}/artifacts?per_page=100",
        "artifacts.json",
    ),
]


def fetch(item):
    endpoint, name = item
    return get(endpoint, f"{directory}/{name}", f"quality-{round_id}-{name}")


with ThreadPoolExecutor(max_workers=3) as pool:
    receipts = list(pool.map(fetch, endpoints))

run = json.loads((ROOT / directory / "run.json").read_bytes())
assert run["id"] == RUN_ID
assert run["head_sha"] == SOURCE_SHA
assert run["repository"]["full_name"] == REPOSITORY
jobs = json.loads((ROOT / directory / "jobs.json").read_bytes())
artifacts = json.loads((ROOT / directory / "artifacts.json").read_bytes())
assert len(jobs["jobs"]) == jobs["total_count"]
assert len(artifacts["artifacts"]) == artifacts["total_count"]
for job in jobs["jobs"]:
    assert job["run_id"] == RUN_ID and job["head_sha"] == SOURCE_SHA

status = {
    "observed_utc": now(),
    "id": RUN_ID,
    "head_sha": run["head_sha"],
    "run_attempt": run["run_attempt"],
    "status": run["status"],
    "conclusion": run["conclusion"],
    "jobs": [
        {k: j.get(k) for k in ("id", "name", "head_sha", "status", "conclusion")}
        for j in jobs["jobs"]
    ],
    "artifacts": [
        {k: a.get(k) for k in ("id", "name", "size_in_bytes", "digest")}
        for a in artifacts["artifacts"]
    ],
}
write_json(f"{directory}/observed.json", status)
print(json.dumps(status, indent=2))

if run["status"] == "completed":
    work = [
        (
            f"repos/{REPOSITORY}/actions/runs/{RUN_ID}/attempts/{run['run_attempt']}/logs",
            "run-logs.zip",
        )
    ]
    work += [
        (
            f"repos/{REPOSITORY}/actions/jobs/{job['id']}",
            f"job-{job['id']}.json",
        )
        for job in jobs["jobs"]
    ]
    for artifact in artifacts["artifacts"]:
        assert artifact["workflow_run"]["id"] == RUN_ID
        assert artifact["workflow_run"]["head_sha"] == SOURCE_SHA
        work += [
            (
                f"repos/{REPOSITORY}/actions/artifacts/{artifact['id']}",
                f"artifact-{artifact['id']}.json",
            ),
            (
                f"repos/{REPOSITORY}/actions/artifacts/{artifact['id']}/zip",
                f"artifact-{artifact['id']}.zip",
            ),
        ]
    with ThreadPoolExecutor(max_workers=4) as pool:
        receipts += list(pool.map(fetch, work))
    print(f"Fetched {len(receipts)} original GET responses, all natural exit 0/reaped.")
