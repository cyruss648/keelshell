"""Write the bounded evidence-only review and explicit acceptance limits."""

from collections import Counter
import json
from pathlib import Path

from review_io import ROOT, SOURCE_SHA, digest, now, write_json

source = Path(json.loads((ROOT / "context.json").read_bytes())["source"])
results = json.loads((ROOT / "independent-results.json").read_bytes())
checks = json.loads((ROOT / "independent-checks.json").read_bytes())
assert checks["failed"] == 0
baseline = json.loads((ROOT / "source-before.json").read_bytes())
after = [
    {"path": p.relative_to(source).as_posix(), "size": p.stat().st_size, "sha256": digest(p.read_bytes())}
    for p in sorted(source.rglob("*")) if p.is_file()
]
assert after == baseline["files"], "sealed source changed during independent read"
write_json("source-after.json", {"root": str(source), "files": after, "unchanged": True})


def evidence(relative, pattern, all_matches=False):
    path = ROOT / relative
    matches = [
        {"path": str(path), "line": i + 1, "text": text}
        for i, text in enumerate(path.read_text(encoding="utf-8-sig").splitlines())
        if pattern in text
    ]
    assert matches, (relative, pattern)
    return matches if all_matches else matches[0]


index = {
    "quality_source_and_terminal": {"path": str(ROOT / "originals/quality-001/run.json"), "line": 1, "json_pointers": ["/head_sha", "/status", "/conclusion", "/run_attempt"]},
    "ssh_seal_hold": evidence("extracted/parent/artifact-14308219775/ssh-debug-originals.json", '"state": "HOLD"'),
    "ssh_master_cleanup_125": evidence("extracted/parent/artifact-14308219775/ssh-debug-cleanup.json", '"exit_code": 125'),
    "ssh_master_not_natural": evidence("extracted/parent/artifact-14308219775/ssh-debug-cleanup.json", '"natural_terminal_before_cleanup": false'),
    "ssh_nonmaster_255": evidence("extracted/parent/artifact-14308219775/ssh-debug-originals.json", '"exit_code": 255', True),
    "ssh_nonmaster_1": evidence("extracted/parent/artifact-14308219775/ssh-debug-originals.json", '"exit_code": 1,'),
    "ssh_temp_removed": evidence("extracted/parent/artifact-14308219775/ssh-cleanup.json", '"temporary_directory_removed": true'),
    "api_native_gui_unrun": evidence("extracted/parent/artifact-14308319951/receipt.json", '"native_gui": "UNRUN"'),
    "ssh_native_gui_unrun": evidence("extracted/parent/artifact-14308219775/receipt.json", '"native_gui": "UNRUN"'),
    "api_isolated_ssh_skipped": {"path": str(source / "jobs/133892796479.json"), "line": 1, "json_pointers": ["/head_sha", "/status", "/conclusion"]},
}
for platform, data in results["quality"].items():
    inv = json.loads((ROOT / f"inventories/{platform}-rust.json").read_bytes())
    first = inv["groups"][0]["start_line"]
    last = inv["groups"][-1]["result_line"]
    index[f"{platform}_quality_inventory"] = {
        "path": data["quality_log"], "first_line": first, "last_line": last,
        "ordinary_result_lines": [g["result_line"] for g in inv["groups"] if g["kind"] == "ordinary"],
        "rustdoc_result_lines": [g["result_line"] for g in inv["groups"] if g["kind"] == "rustdoc"],
        "python_run_line": data["python_main"]["run_line"], "python_terminal_line": data["python_main"]["terminal_line"],
    }
write_json("evidence-index.json", index)

process_rows = []
seal_path = ROOT / "extracted/parent/artifact-14308219775/ssh-debug-originals.json"
cleanup_path = ROOT / "extracted/parent/artifact-14308219775/ssh-debug-cleanup.json"
seal, cleanup = json.loads(seal_path.read_bytes()), json.loads(cleanup_path.read_bytes())
for i, (a, b) in enumerate(zip(seal["admissions"], cleanup["admissions"], strict=True)):
    assert (a["pid"], a["creation_time"]) == (b["pid"], b["creation_time"])
    process_rows.append({
        "index": i, "pid": a["pid"], "creation_time": a["creation_time"],
        "image": a["image"], "is_master": a["is_master"],
        "seal_exit": a["exit_code"], "cleanup_exit": b["exit_code"],
        "natural_before_cleanup": b["natural_terminal_before_cleanup"],
        "seal_source": evidence(str(seal_path.relative_to(ROOT)), f'"pid": {a["pid"]},'),
        "cleanup_source": evidence(str(cleanup_path.relative_to(ROOT)), f'"pid": {b["pid"]},'),
    })
write_json("process-terminal-inventory.json", process_rows)

get_receipts = []
stage_receipts = []
for p in sorted((ROOT / "receipts").glob("*.json")):
    d = json.loads(p.read_bytes())
    if d.get("method") == "GET":
        assert d["returncode"] == 0 and d["natural_exit"] and d["reaped"] and not d["timed_out"]
        assert d["stderr_bytes"] == 0
        get_receipts.append({"path": str(p), **d})
    elif p.name.endswith("-stage.json"):
        stage_receipts.append({"path": str(p), **d})
exit_summary = {
    "GET": {
        "commands": len(get_receipts), "natural_exit_0": len(get_receipts),
        "reaped": len(get_receipts), "timed_out": 0, "forced_termination": 0,
        "stderr_bytes": 0,
    },
    "completed_local_stages_before_this_report": {
        "commands": len(stage_receipts),
        "exit_codes": dict(Counter(str(s["returncode"]) for s in stage_receipts)),
        "natural_exits": sum(s["natural_exit"] for s in stage_receipts),
        "reaped": sum(s["reaped"] for s in stage_receipts),
        "timed_out": sum(s["timed_out"] for s in stage_receipts),
    },
    "local_attempt_explanations": [
        "recompute-r1 exit1: review helper initially required owned-sshd observed_exit=0; raw debug-owner status is null and original master cleanup is125/non-natural. Corrected helper classification; retained r1 code/results/receipt. No product mismatch.",
        "recompute-r2 exit1: review helper included *.receipt.json as job metadata; corrected file selection. Retained r2 code/traceback/receipt.",
        "recompute-r3 exit0:3318 independent checks passed/0 failed.",
        "Report stage receipt is written by run_stage.py after this report exits; final sealing includes it.",
    ],
}
write_json("exit-summary.json", exit_summary)
decision = {
    "decision": "APPROVE_CI_EVIDENCE_ONLY",
    "reviewed_engineering_source": SOURCE_SHA,
    "completed_utc": now(),
    "tasks_completed": ["A_existing_sealed_Windows_originals", "B_independent_exact_source_Quality_terminal"],
    "findings": {"P0": [], "P1": [], "P2": [], "P3": []},
    "independent_checks": {"passed": checks["passed"], "failed": checks["failed"]},
    "original_archives": 7, "original_archive_members": 172,
    "official_artifact_digests_verified": 4,
    "quality": results["quality"],
    "windows_labs": results["windows_labs"],
    "ssh_lifecycle": results["ssh_lifecycle"],
    "openssh_interop": results["openssh_interop"],
    "source_read_only_file_count": len(after), "source_tree_unchanged": True,
    "new_remote_GET_count": len(get_receipts),
    "pending_follow": {
        "allowed_seconds": 480, "first_GET_terminal": True,
        "actual_pending_follow_seconds": 0, "polling_rounds": 1,
        "collection_started_utc": "2026-11-17T08:08:27.719032+00:00",
        "collection_completed_utc": "2026-11-17T08:08:32.197656+00:00",
    },
    "limits": [
        "Original CI evidence review, not an independent rerun on Windows or any platform.",
        "No Cargo, Git commands, workflow rerun, product execution, installation, new chat/worktree, source/docs/target/other-work writes.",
        "The current checkout's live HEAD was not resolved with Git; all reviewed CI identities bind the supplied engineering SHA through original API metadata and checkout logs.",
        "SSH seal HOLD, nonmaster255x5/1x1, master cleanup125/non-natural, API isolated SSH skipped and native_gui UNRUN remain.",
        "OpenSSH cleanup proves observed owned identity cleanup within its documented cumulative ancestry boundary; it does not prove detached unobserved descendants.",
        "No approval of the parent's new native MCP scrolling change, complete native matrix, product completion or release.",
        "Parent must separately verify newly acquired Quality key original bytes, identities, digests and totals.",
    ],
}
write_json("decision.json", decision)
write_json("summary.json", decision)


def cite(item):
    return f"`{item['path']}:{item['line']}`"


rows = []
for label, platform in [("Windows", "windows-2025"), ("macOS", "macos-26"), ("Ubuntu", "ubuntu-24.04")]:
    data = results["quality"][platform]
    ordinary = data["rust"]["ordinary"]
    py = data["python_main"]
    rows.append(f"| {label} | {ordinary['passed']}/0/{ordinary['ignored']} | 15/0/0 | {py['run']}/{py['skipped']} |")

artifact_rows = [
    f"| {a['id']} | {a['run_id']} | {a['bytes']} | `{a['sha256']}` |"
    for a in results["artifact_bindings"]
]
quality_evidence = []
for platform, data in results["quality"].items():
    item = index[f"{platform}_quality_inventory"]
    quality_evidence.append(
        f"- `{data['quality_log']}`：普通/Rustdoc逐名库存起止行 {item['first_line']}–{item['last_line']}；"
        f"Rustdoc结果行 {', '.join(map(str, item['rustdoc_result_lines']))}；"
        f"Python {item['python_run_line']}/{item['python_terminal_line']}。"
    )

report = f"""# 独立 CI 原件复核

结论：**APPROVE_CI_EVIDENCE_ONLY**。任务A、B完成，P0/P1/P2/P3各0项实际发现。
限定接受精确工程 `{SOURCE_SHA}` 的既有Windows原件与新Quality终态证据。
此结论不覆盖父级正在修改的原生MCP滚动实现、完整原生矩阵、产品完成或发行。

范围：先读AGENTS、RTK、HANDOFF。只读取父级已封口目录 `{source}`；
唯一写入 `{ROOT}`。没有运行Git/Cargo、产品、安装或重跑工作流，没有创建chat/worktree。
父级封口目录195文件前后完整文件集、长度及摘要相等，`source-before.json`与`source-after.json`可复核。
所有终态与测试数先从API原件、ZIP、逐名测试输出重算，之后才比较父级summary。

## Quality终态与有界采集

首次GET于2026-11-17 08:08:28 UTC即为completed/success，三平台job全部completed/success。
只进行一轮，11次GET，4.478621秒完成全部元数据、jobs、artifacts、日志ZIP采集；
pending跟进0秒，未消耗允许的8分钟等待，不把父级07:56:50 UTC的pending倒写为成功。
11次GET均自然exit0/reaped，无timeout、强制终止或stderr。
精确run44040248864，attempt1；job133892795291(macOS)、133892795649(Windows)、
133892795682(Ubuntu)。新原件目录 `originals/quality-001/`。
`run.json:1`、`jobs.json:1`和三个`job-*.json:1`分别有head_sha、状态、步骤原件；
每个平台checkout步骤也有独立SHA原行，见`independent-results.json`。

| 平台 | 普通Rust通过/失败/ignored | rustdoc通过/失败/ignored | Python主run/skipped |
| --- | ---: | ---: | ---: |
{chr(10).join(rows)}

每平台普通Rust96组、rustdoc6组，逐名状态、声明数量和每组结果数全部相等。
Rustdoc编译失败用例仍属于rustdoc通过。解析冻结每组开始时的类别：
Linux最后一个普通套件尚未打印summary时下一Doc-tests stderr已经出现，不按字面出现顺序误分类。
各平台其他Python步骤、内嵌Python、跳过步骤与所有ignored测试保存在inventories及decision中，
与Python主526分开；未将预检重跑或controller计为普通Rust新用例。

原始计数路径与行：

{chr(10).join(quality_evidence)}

全部102组结果行及逐名位置在`inventories/<platform>-rust.json`与`evidence-index.json`，
对应字节来自原`originals/quality-001/run-logs.zip`成员，解压不改换行和内容。

## Windows既有原件

- API run44040248806、SSH run44040248746的head_sha、attempt、job、checkout和artifact元数据一致。
- API原日志`extracted/parent/run-44040248806-attempt-1-logs/Actual collectors and independent Windows APIs/4_Lab unit tests.txt:127–129`：
  Python111 run/3 skipped，逐名108 ok/3 skipped；capture replay原`6_*.txt:43`为Rust1通过/0失败/18 filtered。
- SSH原日志`extracted/parent/run-44040248746-attempt-1-logs/Actual Windows OpenSSH and original remote processes/4_SSH ownership and integration lab unit tests.txt:113–115`：
  Python96 run/1 skipped，逐名95 ok/1 skipped；
  `extracted/parent/artifact-14308219775/native-ssh-client.stdout:2–5`为真实SSH Rust1通过/0失败。
- API三个Python跳过与SSH一个跳过均为Windows上不适用的负向非Windows边界；逐名原因在对应inventory。
  API另有isolated SSH job133892796479，原件{cite(index['api_isolated_ssh_skipped'])}保留`skipped`；
  这不是capture replay通过所证明的真实SSH。
- 两份Windows artifact均`native_gui=UNRUN`，原行{cite(index['api_native_gui_unrun'])}与
  {cite(index['ssh_native_gui_unrun'])}；未执行独立Windows或GUI重跑。

## SSH进程与清理边界

- 原seal为HOLD、terminal_proven=false：{cite(index['ssh_seal_hold'])}。21个原对象的完整census
  在seal中只有master仍活着，不能称seal自然终态通过。
- 20个非master均有原对象自然终态证据：exit0×14、255×5、1×1。
  五个255的全部精确原行在`evidence-index.json/ssh_nonmaster_255`，
  1的原行{cite(index['ssh_nonmaster_1'])}。未把这些非零退出抹为零。
- master最终cleanup exit125：{cite(index['ssh_master_cleanup_125'])}，
  natural_terminal_before_cleanup=false：{cite(index['ssh_master_not_natural'])}。
  owner外层`observed_exit=null`亦保留，不凭direct_reaped捏造自然exit0。
- cleanup原件记录21个原身份集合不变、job active0、pending0、owned handles0、debug connections0、
  全debug事件continued且无fallback detach或errors；临时私钥目录已移除
  {cite(index['ssh_temp_removed'])}，未上传私钥或私有客户端配置。
- 四个生产PowerShell operation分别绑定pid+creation_time，均是自然exit0；
  此限定事实不扩大为所有SSH进程exit0，详情`process-terminal-inventory.json`逐项链接原行。

macOS与Linux新OpenSSH artifact各有真实interop18/0/0及forwarding6/0/0。
四个`result.json`与各自tests.log逐名、结果数、步骤exit0、字节长度相符，原路径见
`independent-results.json/openssh_interop`及`inventories/interop-*.json`。
cleanup原件记录observed/owned进程停止、临时目录删除、ancestry_unverified空；
保留其累计祖先观察边界，不能证明在观察间隙完全脱离且未观察到的后代。

## ZIP、官方digest与完整性

共7个原始ZIP/172成员：父级4/104、新Quality3/68。逐ZIP CRC、成员长度/摘要、
重复路径与不安全成员检查通过；`zip-inventory.json`保存原ZIP路径、每成员路径与SHA。
四个artifact的官方列表和单项API digest、字节长度及head_sha相符：

| Artifact | Run | ZIP bytes | SHA-256 |
| --- | --- | ---: | --- |
{chr(10).join(artifact_rows)}

日志ZIP的GitHub API没有服务端digest，本地SHA只提供已下载字节绑定，未声称官方digest认证。
父级外层194条SHA256SUMS覆盖除自身外全部文件。独立复核父级66次GET及8个local stage的
自然exit0/reaped/无timeout回执，并逐GET绑定原输出长度/摘要；
这是文档回执核对，不是重新执行收集者或Windows产品。

## 独立检查、尝试与父级复核入口

最终`recompute-r3`：**3318通过/0失败**，exit0/reaped，0.204689秒；
逐检查见`independent-checks.json`。本复核未新增产品测试运行。
原`recompute-r1`及r2两个helper exit1已保留：前者错误要求debug owner外层exit0，
后者误将receipt JSON纳入job元数据。二者是本复算工具分类/选文件问题，修后仅重算原件，
没有修产品或重跑CI。代码/原失败结果在`analysis-history/`，自然退出和traceback在`receipts/`。
`exit-summary.json`区分11个GET和本地各阶段；最终report阶段回执在结束后由父driver写入。

父级请另外核对新Quality关键原件：

1. `originals/quality-001/run.json`、`jobs.json`、三个`job-*.json`的精确SHA与终态。
2. `originals/quality-001/run-logs.zip`的各平台`8_Rust quality gate.txt`及checkout成员。
3. `artifact-14309783967.json/.zip`与`artifact-14309968324.json/.zip`对官方列表的digest和长度。
4. 四个artifact内`result.json`、`tests.log`及cleanup边界。
5. `decision.json`和`evidence-index.json`：不得把CI成功代签原生MCP滚动修复或完整产品验收。

本任务已结束，无剩余pending工作。所有新增材料仍仅在分配review目录，等待父级封存并关闭本子任务。
"""
(ROOT / "REPORT.md").write_text(report)
print(json.dumps({
    "decision": decision["decision"], "P0": 0, "P1": 0, "P2": 0, "P3": 0,
    "checks_passed": checks["passed"], "checks_failed": checks["failed"],
    "source_files_unchanged": len(after), "new_GET": len(get_receipts),
    "report": str(ROOT / "REPORT.md"),
}, indent=2))
