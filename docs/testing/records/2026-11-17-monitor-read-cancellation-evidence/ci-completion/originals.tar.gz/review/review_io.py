"""Bounded GET-only evidence I/O for this isolated review directory."""

from __future__ import annotations

import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parent
REPOSITORY = "cyruss648/keelshell"
SOURCE_SHA = "6ae91d2e90668e7d9c04a2a7eea7c5de1bf6d3d4"
RUN_ID = 44040248864


def now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def write_json(relative: str, value: object) -> None:
    path = ROOT / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def get(endpoint: str, relative: str, label: str) -> dict:
    """Record the exact argv, process termination and response binding."""
    if not endpoint.startswith(f"repos/{REPOSITORY}/actions/"):
        raise ValueError("endpoint outside authorized CI scope")
    output = ROOT / relative
    if output.exists():
        raise ValueError(f"refusing to replace original: {relative}")
    output.parent.mkdir(parents=True, exist_ok=True)
    argv = [
        "gh",
        "api",
        "--hostname",
        "github.com",
        "--method",
        "GET",
        endpoint,
    ]
    started, start = now(), time.monotonic()
    proc = subprocess.Popen(
        argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE
    )
    timed_out = False
    try:
        stdout, stderr = proc.communicate(timeout=55)
    except subprocess.TimeoutExpired:
        timed_out = True
        proc.kill()
        stdout, stderr = proc.communicate()
    # No headers, environment, authorization or signed redirect URLs are logged.
    safe_stderr = re.sub(
        rb"(?:gh[pousr]_[A-Za-z0-9_]+|github_pat_[A-Za-z0-9_]+)",
        b"[REDACTED_SECRET]",
        stderr,
    )
    output.write_bytes(stdout)
    receipt = {
        "argv": argv,
        "method": "GET",
        "endpoint": endpoint,
        "started_utc": started,
        "completed_utc": now(),
        "elapsed_seconds": round(time.monotonic() - start, 6),
        "pid": proc.pid,
        "returncode": proc.returncode,
        "reaped": proc.poll() is not None,
        "timed_out": timed_out,
        "natural_exit": not timed_out and proc.returncode >= 0,
        "signal": -proc.returncode if proc.returncode < 0 else None,
        "output": relative,
        "bytes": len(stdout),
        "sha256": digest(stdout),
        "stderr_bytes": len(stderr),
        "stderr": safe_stderr.decode("utf-8", "replace"),
    }
    write_json(f"receipts/{label}.json", receipt)
    if proc.returncode != 0 or timed_out:
        raise RuntimeError(f"GET failed; see receipts/{label}.json")
    return receipt
