"""Record natural process exit for a local, review-owned analysis script."""

import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

from review_io import ROOT, now, write_json

label, script, *args = sys.argv[1:]
path = (ROOT / script).resolve()
if path.parent != ROOT or path.suffix != ".py":
    raise ValueError("analysis script outside review root")
started, clock = now(), time.monotonic()
argv = [sys.executable, "-B", str(path), *args]
proc = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
stdout, stderr = proc.communicate()
(ROOT / f"receipts/{label}.stdout").write_bytes(stdout)
(ROOT / f"receipts/{label}.stderr").write_bytes(stderr)
receipt = {
    "argv": argv,
    "started_utc": started,
    "completed_utc": now(),
    "elapsed_seconds": round(time.monotonic() - clock, 6),
    "pid": proc.pid,
    "returncode": proc.returncode,
    "reaped": proc.poll() is not None,
    "natural_exit": proc.returncode >= 0,
    "timed_out": False,
    "stdout_bytes": len(stdout),
    "stdout_sha256": hashlib.sha256(stdout).hexdigest(),
    "stderr_bytes": len(stderr),
    "stderr_sha256": hashlib.sha256(stderr).hexdigest(),
}
write_json(f"receipts/{label}-stage.json", receipt)
sys.stdout.buffer.write(stdout)
sys.stderr.buffer.write(stderr)
print(json.dumps(receipt))
raise SystemExit(proc.returncode)
