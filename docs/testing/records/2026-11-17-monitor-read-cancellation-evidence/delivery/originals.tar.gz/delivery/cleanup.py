"""Remove only this batch's owned expanded copies after exact Git/archive checks."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
MAIN = ROOT / "docs/testing/records/2026-11-17-monitor-read-cancellation-evidence"
PREVIOUS = ROOT / "docs/testing/records/2026-11-17-mcp-client-history-evidence"
if sys.flags.optimize:
    raise RuntimeError("cleanup requires enabled assertions")
commit = sys.argv[1]
subprocess.run(
    ["python3", "-B", str(MAIN / "verify.py"), "--commit", commit],
    cwd=ROOT, check=True, timeout=60,
)
directories = [
    "monitor-cancellation-20261117",
    "monitor-cancellation-review-20261117",
    "traceroute-fixture-review-20261117",
    "zmodem-empty-peer-diagnosis-20261117",
    "mcp-source-ci-completion-20261117",
    "mcp-source-ci-review-20261117",
]
owners = [ROOT / "work" / name for name in directories]
manifests = [MAIN, MAIN / "review", MAIN / "fixture-review", MAIN / "peer-diagnosis",
             PREVIOUS / "ci-completion", PREVIOUS / "ci-completion/review"]
expected = {}
for directory in manifests:
    for row in json.loads((directory / "manifest.json").read_text())["files"]:
        path = ROOT / row["source"]
        assert path not in expected
        expected[path] = (row["bytes"], row["sha256"])

# Downloaded third-party bodies and long excerpts were deliberately not published.
# Their already archived source/command receipts still identify the exact bytes.
peer = ROOT / "work/zmodem-empty-peer-diagnosis-20261117"
for row in json.loads((peer / "sources-manifest.json").read_text()):
    expected[peer / row["file"]] = (row["bytes"], row["sha256"])
for name in [
    "source-excerpts", "protocol-and-completion-excerpts",
    "protocol-locations", "source-locations", "zero-data-send-excerpt",
]:
    receipt = json.loads((peer / "commands" / f"{name}.json").read_text())
    path = peer / receipt["stdout_file"]
    expected[path] = (path.stat().st_size, receipt["stdout_sha256"])

protected = json.loads((
    ROOT / "work/monitor-cancellation-20261117/protected-resources-wide-before.json"
).read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_protected():
    target = ROOT / protected["target"]["relative_path"]
    stat = target.stat()
    assert (stat.st_dev, stat.st_ino) == (
        protected["target"]["device"], protected["target"]["inode"]
    )
    for name, rows in protected["packages"].items():
        package = ROOT / "work" / name
        actual = [
            {"path": path.relative_to(package).as_posix(),
             "bytes": path.stat().st_size, "sha256": digest(path)}
            for path in sorted(package.rglob("*")) if path.is_file()
        ]
        assert actual == rows


verify_protected()
verified = []
for owner in owners:
    assert owner.parent == ROOT / "work" and owner.is_dir() and not owner.is_symlink()
    paths = sorted(owner.rglob("*"))
    assert all(not path.is_symlink() for path in paths)
    files = {path for path in paths if path.is_file()}
    owned_expected = {path for path in expected if path.is_relative_to(owner)}
    assert files == owned_expected, {
        "owner": owner.name,
        "unsealed": sorted(str(path.relative_to(owner)) for path in files - owned_expected),
        "missing": sorted(str(path.relative_to(owner)) for path in owned_expected - files),
    }
    for path in files:
        size, sha = expected[path]
        assert path.stat().st_size == size and digest(path) == sha, str(path)
    verified.append({
        "directory": owner.relative_to(ROOT).as_posix(),
        "files": len(files), "logical_bytes": sum(path.stat().st_size for path in files),
    })

# All directories and protected objects have been checked before the first delete.
for owner in owners:
    shutil.rmtree(owner)
verify_protected()
result = {
    "commit": commit, "removed": verified,
    "files": sum(row["files"] for row in verified),
    "logical_bytes": sum(row["logical_bytes"] for row in verified),
    "all_exact_archived_or_explicitly_excluded_receipt_bytes_equal": True,
    "protected_target_identity_and_two_package_file_sets_equal": True,
    "boundary": "Owned expanded copies only. Logical byte sums are not physical disk-space measurements.",
}
with (BASE / "cleanup-result.json").open("x") as output:
    json.dump(result, output, indent=2)
    output.write("\n")
print(json.dumps(result))
