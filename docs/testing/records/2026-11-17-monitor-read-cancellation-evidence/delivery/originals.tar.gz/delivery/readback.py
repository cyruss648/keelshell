"""Read back the delivered branch's exact local, tracking and remote identities."""
import datetime
import json
from pathlib import Path
import subprocess
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
expected, label = sys.argv[1:]


def git(*args):
    return subprocess.check_output(
        ["git", *args], cwd=ROOT, text=True, timeout=30
    ).strip()


branch = git("branch", "--show-current")
assert branch == "feature/editor-unicode-codec-20261114"
local = git("rev-parse", "HEAD")
tracking = git("rev-parse", f"refs/remotes/origin/{branch}")
remote_line = git("ls-remote", "--exit-code", "origin", f"refs/heads/{branch}")
remote, ref = remote_line.split()
status = git("status", "--porcelain")
report = {
    "observed_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "branch": branch, "expected": expected,
    "local": local, "tracking": tracking, "remote": remote, "remote_ref": ref,
    "all_equal": expected == local == tracking == remote,
    "tracked_and_untracked_status": status, "worktree_clean": status == "",
    "boundary": "One delivered feature branch only; no force push or update to origin/main.",
}
with (BASE / f"{label}.json").open("x") as output:
    json.dump(report, output, indent=2)
    output.write("\n")
print(json.dumps(report))
assert report["all_equal"] and report["worktree_clean"]
