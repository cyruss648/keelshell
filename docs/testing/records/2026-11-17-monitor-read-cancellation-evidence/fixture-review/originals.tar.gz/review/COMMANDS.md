# 命令与检查回执

工作目录始终为 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`，
除测试子进程 cwd/TMPDIR 显式设为本复核目录。唯一写入根为本目录。

1. `pwd`；读取 `/Users/hdh/.codex/RTK.md`、实际 `AGENTS.md`、
   `docs/HANDOFF.md` 及存在的祖先/下级 AGENTS。exit 0；没有额外下级合同。
2. 轻量读取记忆 `MEMORY.md:428-469`，仅沿用严格只读复核与证据分层约定；
   本批所有源码、输入、测试结论均重新现场验证。
3. `git --no-optional-locks status --short --untracked-files=no`、
   `git --no-optional-locks diff -- crates/keelshell-session/src/network_diagnostic/tests/test_traceroute.py`；
   exit 0。另由 Python `difflib` 保存完整未压缩 r2/r3 diff。
4. `nl -ba` 读取测试与三件生产 Python 全文；exit 0。Python 只读读取 r2 result、
   原 log 与旧 fixture metadata。初次目录 `rg` 因 `/work/` 被忽略而无匹配、exit 1，
   随即以 Python 直接读取原 log，确认唯一 FileNotFoundError 与 421/1/4；
   `rg -n '^/?work/?$|work/' .gitignore` exit 0，定位第 2 行 `/work/`。
5. 用 `Path.mkdir()` 新建本目录；仅在本目录新增 `review.py`。主检查执行一次：

   ```sh
   python3 -B work/traceroute-fixture-review-20261117/review.py
   ```

   自然 exit 0。其精确 Git 子命令与 Python 测试 argv/cwd/终态见
   `commands.json`，实际检查逻辑完整保存在 `review.py`。
   Git 子命令仅 rev-parse/show，无索引刷新或写入。
6. 主检查复算 r2/r3 aggregate、核验 777 项当前字节数/SHA、比对唯一变更、
   旧 fixture 与 HEAD blob；全部 PASS。目标方法之外 AST 相同，
   原七 assertion 调用保留、仅加三个；无新 skip/retry/deadline 修改。
7. 四文件逐字节复制，独立 TMPDIR 执行原 14 项一次：
   14 passed / 0 failed / 0 skipped，driver exit 0 / reaped / 11.559321s。
   20ms 只读采样观察自有 PID 文件及 `os.kill(pid, 0)`；
   采样不修改 fixture，不重跑测试，不向存活进程发送终止信号。
   外层 45s 保护未触发。
8. 重核 777 项、HEAD、四件复制品及四件 r2 原证据；全部相同。
   原始日志及 SHA、测试 PID 与 live→absent 时间见 JSON 回执。
9. 写出并读回 `REVIEW.md`、`decision.json`；最后为本目录生成 `SHA256SUMS`
   与 `final-receipt.json`，不重复执行产品测试。

Cargo/fmt/clean/target、产品修改、GUI、提交、推送、外部网络均未执行。
没有启动真实 traceroute 或 ping；测试仅启动自有 Python fixture 和 stdlib numeric resolver。
本入口是一次性复核原件，已有运行结果应直接读取，避免重复运行覆盖证据。
