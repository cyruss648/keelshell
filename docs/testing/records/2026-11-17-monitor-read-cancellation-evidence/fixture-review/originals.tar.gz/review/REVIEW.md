# 离线 traceroute 生命周期 fixture 独立有界复核

**APPROVE，仅批准本次 fixture 增量。P0=0、P1=0、P2=0、P3=0，未关闭发现 0。**
复核者未参与该增量编写。没有重审已由 Turing 批准的五文件 monitor 功能，也不代签父级 fullgate-r3。

冻结 HEAD：`4c8654f219779f48afd485bec8ff1b284905fbf0`。独立复算 r3 的 777 项输入：
`6d495b849c63e00dfc7ba8b867f3fa8b5ba3481de9e4b66669dee77f40fa22d5`。
运行前后逐文件字节数与 SHA-256 全部匹配；与 r2 相比仅
`crates/keelshell-session/src/network_diagnostic/tests/test_traceroute.py` 改变，其余 776 项相同。
旧副本与 HEAD Git blob、r2 清单逐字节相等。完整差异见 [complete.diff](complete.diff)，
校验见 [input-audit.json](input-audit.json)、[postcheck.json](postcheck.json)。

**代码判断与精确位置：**

- [test_traceroute.py:256](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/network_diagnostic/tests/test_traceroute.py:256)：
  mock 只存在于该方法拼装后送给子解释器的源码内。仅固定 `--version` 的成功 stderr 和准确
  `sys.executable` / `TRACE_RESOLVER` 调用的 IPv4 numeric 结果；最终工具 argv 重定向至自有脚本，
  第 274 行仍无条件委托 `_production_run`。未替换全局 adapter，未改变生产文件、deadline、kill/wait。
- [test_traceroute.py:287](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/network_diagnostic/tests/test_traceroute.py:287)：
  原七个 assertion 调用全部保留，包括 supervisor exit 0、空 stderr、原 `<9s` 上界、单帧、
  timeout、空 hops、PID 已不存在。新增 reason=`deadline`、implementation、address 三项断言。
  PID 必须由实际执行的工具脚本写出；缺文件仍会失败。目标方法之外整个文件 AST 相等。
- [traceroute.py:159](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/network_diagnostic/traceroute.py:159)：
  旧机制允许版本探测的 `.75s` deadline 在工具启动前返回 `timeout`；resolver 也在最终工具之前。
  原断言不能区分阶段。implementation 直到第 167 行才赋值、address 直到第 187 行才赋值，
  新断言结合 PID 证据排除了前置超时冒充最终工具超时。
  **原 r2 日志没有保存 report 的阶段字段，不能仅凭 FileNotFoundError 断言当次具体卡在 version 还是 resolver。**
- [traceroute.py:124](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/network_diagnostic/traceroute.py:124)、
  [icmp.py:104](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/network_diagnostic/icmp.py:104)、
  [probe.py:66](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/network_diagnostic/probe.py:66)：
  保留真实生产分派、7.5 秒绝对预算、最终 Popen、新进程组、SIGKILL、`.4s` 实际 wait 与单帧终态。
  三件生产 Python 均与 HEAD 相同，复制前后 SHA 相等。
- [test_traceroute.py:92](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/network_diagnostic/tests/test_traceroute.py:92)：
  其余测试仍经 `self.actual_runner` 执行生产 runner。第 111 行成功用例核对版本→原 numeric resolver→probe
  三次调用；第 122 行十种版本拒绝组合仍启动受控版本进程，核对 stdout/stderr/exit 与准入失败。
  第 183 行缺工具/未知版本、第 206 行 resolver 拒绝路径未改；
  unsafe/缺工具用例按原设计验证不启动进程，IPv6/错误 resolver 使用原有受控脚本。
  本次固定返回值没有传播到这些 admission 测试。

**独立执行：** 四个文件逐字节复制到本目录 `source/`，在本目录 `tmp/` 下运行原 14 项一次。
Python `/opt/homebrew/opt/python@3.15/bin/python3.15 -I -S -B source/tests/test_traceroute.py -v`，
**14 passed / 0 failed / 0 skipped**；unittest 11.463s，外层 11.559321s；
测试驱动自然 exit 0、无外层超时、已 wait 回收。未跳过、重试或缩短任何测试 deadline。
测试输出见 [command.log](command.log)，完整 argv、环境与终态见 [run-result.json](run-result.json)。

独立观察到最终 `sleep(30)` 工具 **PID 3772**：相对测试启动 3.670362s 首次存活，
10.868104s 仍存活，10.898431s 首次不存在；脚本 SHA
`29e900b6ed8fb6e97d382d25e9981d60c66502dc6496096cabbc8c2f32ac9c7e`。
这与用例自身 PID 不存在断言及生产显式 wait 相互印证。工具由生产 deadline 终止；
没有把它描述为自然 exit 0，也未独立采集其 wait 返回码。取消用例的 PID 3709 同样观察到存活后消失。

原 r2 gate **421 passed / 1 failed / 4 ignored**、Python 14 项中一个 PID
FileNotFoundError 保持原状；gate result、完整 log、旧 fixture 与 metadata 前后 SHA 相同。
摘录见 [r2-failure-excerpt.log](r2-failure-excerpt.log)。原失败未改写为通过。

**未覆盖：** 本修改与此次执行不证明真实 traceroute/真实 DNS 或网络、Windows、三平台 native、
Rust session wrapper/全门禁、monitor 业务验收；也不证明原 `.75s` 准入在高负载下稳定，
或无限次重复运行的无竞态性。真实 DNS 前置阶段在本生命周期用例中已受控，
其生产路径由其余受控离线用例承担现有覆盖。父级 fullgate-r3 应独立读取自然终态。

**执行边界：** 本次唯一写入根为 `work/traceroute-fixture-review-20261117/`；
tracked 文件修改 0，Cargo/fmt/clean/target/GUI/提交/推送/外部网络操作 0。
只启动本地 Python 与自有 fixture 进程。证据充分后停止，不等待或代签父级门禁。
复核入口与检查命令见 [COMMANDS.md](COMMANDS.md)、[commands.json](commands.json)、
[review.py](review.py)。
