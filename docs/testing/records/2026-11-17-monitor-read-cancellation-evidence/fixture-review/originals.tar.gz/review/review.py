"""Bounded offline review; all writes stay below this script's directory."""
import ast
import copy
from datetime import datetime, timezone
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

OWN = Path(__file__).resolve().parent
CHECKOUT = OWN.parent.parent
PARENT = CHECKOUT / "work/monitor-cancellation-20261117"
TEST = "crates/keelshell-session/src/network_diagnostic/tests/test_traceroute.py"
DIAG = Path(TEST).parent.parent
EXPECTED = "6d495b849c63e00dfc7ba8b867f3fa8b5ba3481de9e4b66669dee77f40fa22d5"
CASE = "test_real_supervisor_deadline_actually_waits_owned_fake_tool"
commands = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(name, value):
    (OWN / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def git(*args):
    argv = ["git", "--no-optional-locks", *args]
    result = subprocess.run(argv, cwd=CHECKOUT, capture_output=True, timeout=10)
    commands.append({"argv": argv, "cwd": str(CHECKOUT), "exit_code": result.returncode})
    result.check_returncode()
    return result.stdout


def inputs(revision):
    path = PARENT / f"candidate-inputs-{revision}.json"
    raw = path.read_bytes()
    value = json.loads(raw)
    items = value["inputs"]
    aggregate = sha(json.dumps(items, sort_keys=True, separators=(",", ":")).encode())
    assert aggregate == value["aggregate_sha256"]
    assert value["count"] == len(items) == 777
    assert len({item["path"] for item in items}) == 777
    return value, {"path": str(path), "sha256": sha(raw), "count": len(items),
                   "aggregate_sha256": aggregate}


def current_mismatches(items):
    bad = []
    for item in items:
        data = (CHECKOUT / item["path"]).read_bytes()
        if len(data) != item["bytes"] or sha(data) != item["sha256"]:
            bad.append(item["path"])
    return bad


started_at = datetime.now(timezone.utc).isoformat()
head = git("rev-parse", "HEAD").decode().strip()
r2, r2_receipt = inputs("r2")
r3, r3_receipt = inputs("r3")
assert r3_receipt["aggregate_sha256"] == EXPECTED
assert head == r2["head"] == r3["head"]
before_mismatches = current_mismatches(r3["inputs"])
assert not before_mismatches, before_mismatches
old_items = {item["path"]: item for item in r2["inputs"]}
new_items = {item["path"]: item for item in r3["inputs"]}
assert old_items.keys() == new_items.keys()
changed = [path for path in old_items if old_items[path] != new_items[path]]
assert changed == [TEST], changed
old = (PARENT / "traceroute-fixture-before.py").read_bytes()
new = (CHECKOUT / TEST).read_bytes()
assert old == git("show", f"{head}:{TEST}")
assert sha(old) == old_items[TEST]["sha256"]
assert len(old) == old_items[TEST]["bytes"]
(OWN / "r2-test_traceroute.py").write_bytes(old)
(OWN / "complete.diff").write_text("".join(difflib.unified_diff(
    old.decode().splitlines(keepends=True), new.decode().splitlines(keepends=True),
    fromfile="r2/" + TEST, tofile="r3/" + TEST)))

trees = [ast.parse(old), ast.parse(new)]
methods = []
for tree in trees:
    methods.append(next(node for node in ast.walk(tree)
                        if isinstance(node, ast.FunctionDef) and node.name == CASE))
outside = copy.deepcopy(trees)
for tree in outside:
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            node.body = [part for part in node.body
                         if not (isinstance(part, ast.FunctionDef) and part.name == CASE)]
assert ast.dump(outside[0]) == ast.dump(outside[1])
assertions = [[ast.dump(node) for node in ast.walk(method)
               if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
               and node.func.attr.startswith("assert")] for method in methods]
assert all(item in assertions[1] for item in assertions[0])
assert len(assertions[1]) == len(assertions[0]) + 3
names = [node.name for node in ast.walk(trees[1])
         if isinstance(node, ast.FunctionDef) and node.name.startswith("test_")]
assert len(names) == 14

source = OWN / "source"
(source / "tests").mkdir(parents=True)
copies = []
for relative in [TEST, *(str(DIAG / name) for name in ("icmp.py", "traceroute.py", "probe.py"))]:
    data = (CHECKOUT / relative).read_bytes()
    dest = source / ("tests/test_traceroute.py" if relative == TEST else Path(relative).name)
    dest.write_bytes(data)
    if relative != TEST:
        assert data == git("show", f"{head}:{relative}")
    copies.append({"source": relative, "copy": str(dest.relative_to(OWN)),
                   "bytes": len(data), "sha256": sha(data), "byte_equal": True,
                   "production_equals_head": relative != TEST})

preserved = {}
for name in ("final-gate-r2/result.json", "final-gate-r2/command.log",
             "traceroute-fixture-before.py", "traceroute-fixture-before.json"):
    data = (PARENT / name).read_bytes()
    preserved[name] = {"bytes": len(data), "sha256": sha(data)}
failure = (PARENT / "final-gate-r2/command.log").read_text()
begin = failure.index("---- network_diagnostic::tests::traceroute::traceroute_offline_")
excerpt = failure[begin:]
assert "FileNotFoundError" in excerpt and "421 passed; 1 failed; 4 ignored" in excerpt
assert "Ran 14 tests" in excerpt and "FAILED (errors=1)" in excerpt
(OWN / "r2-failure-excerpt.log").write_text(excerpt)
save("input-audit.json", {
    "started_at_utc": started_at, "head": head, "r2": r2_receipt, "r3": r3_receipt,
    "before_mismatches": before_mismatches, "changed": changed, "unchanged_count": 776,
    "old_equals_head": True, "outside_case_ast_equal": True,
    "original_assertion_calls_retained": len(assertions[0]), "added_assertion_calls": 3,
    "test_inventory": names, "copies": copies, "preserved": preserved,
})

tmp = OWN / "tmp"
tmp.mkdir()
env = dict(os.environ, TMPDIR=str(tmp), TMP=str(tmp), TEMP=str(tmp),
           PYTHONDONTWRITEBYTECODE="1")
argv = [sys.executable, "-I", "-S", "-B", str(source / "tests/test_traceroute.py"), "-v"]
observations = {}
t0 = time.monotonic()
timed_out = False


def observe():
    now = time.monotonic() - t0
    for marker in tmp.glob("keelshell-owned-traceroute-*/pid"):
        try:
            pid = int(marker.read_text())
            tool = (marker.parent / "traceroute").read_bytes()
        except (FileNotFoundError, ValueError):
            continue
        observations.setdefault(pid, {
            "pid": pid, "marker": str(marker.relative_to(OWN)), "marker_pid": pid,
            "tool_sha256": sha(tool), "sleep_30_present": b"time.sleep(30)" in tool,
            "kind": "cancel" if b"\nsys.stdout.write(" in tool else "deadline",
        })
    for pid, item in observations.items():
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            item.setdefault("first_absent_seconds", round(now, 6))
        else:
            item.setdefault("first_alive_seconds", round(now, 6))
            item["last_alive_seconds"] = round(now, 6)


with (OWN / "command.log").open("wb") as log:
    child = subprocess.Popen(argv, cwd=OWN, env=env, stdin=subprocess.DEVNULL,
                             stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    while child.poll() is None:
        observe()
        if time.monotonic() - t0 > 45:
            timed_out = True
            os.killpg(child.pid, signal.SIGKILL)
            break
        time.sleep(.02)
    exit_code = child.wait(timeout=2)
observe()
try:
    os.waitpid(child.pid, os.WNOHANG)
except ChildProcessError:
    reaped = True
else:
    reaped = False
duration = time.monotonic() - t0
output = (OWN / "command.log").read_text()
ok_names = re.findall(r"^(test_\S+) .* \.\.\. ok$", output, re.MULTILINE)
run = {"argv": argv, "cwd": str(OWN), "TMPDIR": str(tmp), "pid": child.pid,
       "exit_code": exit_code, "timed_out": timed_out, "reaped": reaped,
       "duration_seconds": round(duration, 6), "passed": len(ok_names),
       "failed": 0 if exit_code == 0 else None, "skipped": 0 if "skipped" not in output else None,
       "fixture_pids": list(observations.values()), "command_log_sha256": sha(output.encode())}
commands.append(run)
save("run-result.json", run)
save("commands.json", commands)
after_mismatches = current_mismatches(r3["inputs"])
preserved_after = {name: (sha((PARENT / name).read_bytes()) == item["sha256"])
                   for name, item in preserved.items()}
copies_after = {item["copy"]: sha((OWN / item["copy"]).read_bytes()) == item["sha256"]
                for item in copies}
save("postcheck.json", {"after_mismatches": after_mismatches,
                        "head_unchanged": git("rev-parse", "HEAD").decode().strip() == head,
                        "preserved_unchanged": preserved_after, "copies_unchanged": copies_after})
save("commands.json", commands)
print(json.dumps(run, indent=2))
assert exit_code == 0 and not timed_out and reaped
assert len(ok_names) == 14 and "Ran 14 tests" in output and "\nOK\n" in output
assert not after_mismatches and all(preserved_after.values()) and all(copies_after.values())
deadline = [item for item in observations.values() if item["kind"] == "deadline"]
assert len(deadline) == 1
assert "first_alive_seconds" in deadline[0] and "first_absent_seconds" in deadline[0]
assert deadline[0]["sleep_30_present"]
