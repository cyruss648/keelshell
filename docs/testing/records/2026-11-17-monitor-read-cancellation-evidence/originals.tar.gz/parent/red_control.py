"""Run current integration tests against the exact baseline production files."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
rows = json.loads((BASE / "before.json").read_text())
current = {}
for row in rows:
    path = ROOT / row["path"]
    current[row["path"]] = path.read_bytes()
    original = (BASE / "before" / row["path"]).read_bytes()
    assert hashlib.sha256(original).hexdigest() == row["sha256"]
    assert original == subprocess.check_output(
        ["git", "cat-file", "blob", "4c8654f219779f48afd485bec8ff1b284905fbf0:" + row["path"]],
        cwd=ROOT, timeout=10,
    )
argv = [
    "cargo", "test", "-p", "keelshell-session", "--test", "windows_monitor",
    "--locked", "--", "--test-threads=1", "--show-output",
]
process = None
receipt = {"argv": argv, "production": "exact baseline files", "reaped": False}
started = time.monotonic()
try:
    for row in rows:
        (ROOT / row["path"]).write_bytes((BASE / "before" / row["path"]).read_bytes())
    process = subprocess.Popen(argv, cwd=ROOT, env=os.environ, start_new_session=True)
    receipt["pid"] = process.pid
    try:
        receipt["exit_code"] = process.wait(timeout=120)
    except subprocess.TimeoutExpired:
        receipt["timed_out"] = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            receipt["exit_code"] = process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            receipt["exit_code"] = process.wait(timeout=5)
    receipt["reaped"] = True
finally:
    for name, raw in current.items():
        (ROOT / name).write_bytes(raw)
    receipt["restored_implementation"] = all(
        (ROOT / name).read_bytes() == raw for name, raw in current.items()
    )
    receipt["duration_seconds"] = round(time.monotonic() - started, 6)
    with (BASE / "red-control-result.json").open("x") as output:
        json.dump(receipt, output, indent=2)
        output.write("\n")
print(json.dumps(receipt), flush=True)
assert receipt["exit_code"] == 101 and not receipt.get("timed_out", False)
assert receipt["reaped"] and receipt["restored_implementation"]
