**结论：这是固定上游发送端的空文件边界缺陷。当前 KeelShell 接收端发出 `ZRPOS(0)` 合规；在不改变“逐文件审核、完整接收及保存、真实协议收尾”含义的前提下，没有可以使该未修改 peer 成功发送空文件的客户端报文替代。建议保持该兼容项 OPEN，不写产品修复。**

诊断日期：2026-11-17。范围仅 Synchronet SexyZ 3.7 / zmodem.c 2.7，
精确提交 `acce09a1778dc2c61a996a3407ff6ddcaf70acb3`。
本地只读入口 HEAD 为 `4c8654f219779f48afd485bec8ff1b284905fbf0`。
本报告属于 FILE-05 有界源码诊断，不是新一轮传输、平台、原生或产品验收。

**确切源码路径与触发链**

以下行号均对应本目录 `downloads/` 中未修改的完整上游文件；三件源码的
字节数、SHA-256 均与已提交的 preparation 来源基线逐项相等。

1. `src/sbbs3/zmodem.c:1969–1970` 对实际输入文件执行 `fstat`，
   将 `s.st_size` 写入 `zm->current_file_size`。空文件因此为 0。
   `2032–2037` 如实把该长度写入 ZFILE 元数据。
2. `2041–2102` 发出 ZFILE 和元数据后，只有收到 ZRPOS 才离开正常接收起点等待；
   ZSKIP 是单独的跳过分支。
3. `2104–2105` 在进入任何 `zmodem_send_from` 调用前，调用
   `zmodem_handle_zrpos`，失败则立即返回 FALSE。
4. `1679–1693` 的核心条件位于 **1681**：

   ```c
   if (zm->rxd_header_pos < zm->current_file_size) {
   ```

   该分支才会返回 TRUE；否则 `1691–1693` 输出
   `Received INVALID ZRPOS offset` 并返回 FALSE。
   对空文件而言条件为 **`0 < 0`，恒假**。
   `zmodem.h:235` 将 offset 定义为 `uint32_t`，`276` 将 size 定义为 `int64_t`；
   当 size=0 时，任何可编码 offset 都无法满足该条件。
5. 所以 `zmodem.c:2123` 的数据发送调用不可达，
   `1806` 的读取、`1849` 的数据子包发送和 `1887` 的 ZEOF 发送均未发生。
   这在数据 CRC16/CRC32 或零长度子包的处理之前就已经失败。
   同一条件还拒绝非空文件恰好位于 EOF 的 offset=size；这是源码推论，
   本任务没有执行该额外场景。
6. CLI `sexyz.c:1126` 接到 FALSE，`1152–1153` 报传输失败，
   `1180–1181` 停止文件循环，`1187–1191` 返回 -1。
   `1184–1185` 仅在 success 或已发送字节非零等条件满足时进入结束握手：
   单独空文件失败没有此前字节，直接退出；已有非空文件成功的 batch 可以继续尝试
   ZFIN，但这不能补成当前空文件的 ZEOF 或保存。

batch 旧诊断中的 `!20 Received INVALID ZRPOS offset: 0` 并非请求 offset=20。
`zmodem.c:1692` 的首个值是上一文件留下的 `current_file_pos`；
真正收到的 offset 是冒号后的 0。当前文件 size 已在 `1970` 重新设为 0，
而 `current_file_pos` 要进入 `send_from` 后才在 `1749` 更新。

**与原有失败证据及本方实现交叉核对**

选择性读取原归档 `parent/mac-sexyz-r7/tests.log`，完整副本位于
`archived-receipts/parent/mac-sexyz-r7/tests.log`：

- 第 57 行：三文件 batch 的前两个文件有保存回执，第三个 `empty.bin` 声明 size=0、
  触发独立审核，随后 peer 报 INVALID ZRPOS offset 0、传输失败；
  KeelShell 报 `Protocol`，没有给空文件补发保存回执。
- 第 60 行：单独 `empty.bin` 经审核后 peer 报相同 offset 0 错误并退出，
  KeelShell 报 `ConnectionClosed`，没有空文件保存回执。
- 第 67 行：该历史实际轮次为 8 passed / 2 failed。本任务没有重跑它。
  空文件上传到该 peer 的接收方向通过，不反证其发送方向分支缺陷。

本方 `crates/keelshell-core/src/zmodem/receiver.rs:155–163`
仅在外部批准当前 offer 后进入 Receiving，发出 `ZRPOS(0)`。
`415–432` 必须收到位置、声明长度、累计内容长度相等的有效 ZEOF 才发出
FileReceived；`187–202` 只有外层确认实际保存后才发送下一文件的 ZRINIT。
因此无需通过修改审核、完整保存或末尾握手策略来解释此失败。

**官方 lrzsz 维护者协议文档交叉核对**

重新下载官方来源 `zmodem-wip-20261004.txt`，61,016 字节，
SHA-256 与封存 `protocol-reference-r1.json` 完全相等。
原文第 3–13 行明确这是 Uwe Ohse 的 2026 年 10 月规范重写、仍为 WIP；
本报告按该维护者文档解释协议，不将其称为额外正式标准或一次实测。

| 原文行号 | 对本问题的约束 |
| --- | --- |
| 1035–1046 | 正常 ZFILE 接受回复是 ZRPOS，通常 offset=0；由发送方发送数据和 ZEOF，接收方核对 EOF 后回复 ZRINIT。 |
| 979–993，尤其 984–986 | 发送方须验证 ZRPOS 偏移，不能超过输入文件长度。这里是包含 EOF 的上界，不是必须严格小于文件长度；零文件的 0 不超过 0。 |
| 742–752、776–784 | ZDATA 可以含零长度子包；ZEOF 由发送方声明结束位置。零负载不会要求接收方编造任意数据或自行发出 ZEOF。 |
| 555–562、905–912 | ZFILE 元数据后的 ZCRCW 是特殊情况，接收方不能用 ZACK 代替 ZRPOS/ZSKIP。 |
| 934–943 | ZCRC 请求只能取得内容 CRC；请求长度 0 表示整个文件，并不充当文件结束或保存确认。 |
| 847–850、1037–1041 | ZSKIP 跳过文件；ZNAK 重发坏报文；ZABORT/ZFERR 终止批次。 |
| 1052–1058 | 正常结束是发送方 ZFIN、接收方 ZFIN、发送方 OO。它与逐文件 ZEOF/保存是两个层次。 |

所以本方审核后发送 `ZRPOS(0)` 正是正常接受流程。上游把合法区间的边界
排除了。这个结论不依赖 PTY 调度、参数名称或 peer exit code。

**客户端合法替代的边界**

| 候选 | 此固定 peer 的源码结果及语义判断 |
| --- | --- |
| 更换 HEX/BIN16/BIN32、CRC、转义、窗口或重试时机 | 正确解码的 ZRPOS 仍是 offset=0，触发同一数值条件；不会修复。 |
| ZRPOS 非零或最大 32 位值 | 对 size=0 同样被拒绝，并且超出文件范围；不合规。 |
| 先 ZCRC(0)，核对空文件 CRC 后再接受 | `zmodem.c:2087–2095` 回 CRC 后继续接收控制头，最后仍须通过 `2104` 的相同 ZRPOS 条件；不能取得缺失的 ZEOF。 |
| 用 ZACK(0) 接受 | 协议文档禁止；该 peer 的 `2070–2071` 还会直接忽略它。 |
| 提前 ZRINIT / ZNAK | `2073–2075` 忽略首个滞后 ZRINIT，其余不成为 ZRPOS，则外层重新 offer，直到 `2044–2045` 达到尝试上限；不是完成当前文件。 |
| ZSKIP(0) | 合法跳过；`2097–2100` 设置 file_skipped 并返回。可作为未来显式“跳过空文件继续批次”的独立能力，但不得报告该文件已传输、已验证保存或完整批次内容成功。 |
| ZABORT / ZFERR / 提前结束会话 | 合法放弃，不能变成空文件接收成功。此版本对 ZFILE 等待期间的其他控制头兼容程度不由本次静态分析代签。 |
| 根据 metadata/CRC 本地造空文件，再 ZSKIP / ZRINIT | 会改变既有完整接收及保存的证据语义；本任务不接受，也没有实施。 |

不能让接收方发送属于发送方向的 ZEOF，不能伪造 OO，不能把退出 0、跳过、
文件元数据或空内容摘要冒充完整保存。
本方接收器目前在有效 `ZEOF(0)` 到达时可沿现有长度核验进入 Saving；
本故障恰恰是该 peer 在此前就退出。

**后续选项**

1. 保留该精确版本的发送空文件兼容失败、8/10 历史结果及 FILE-05 OPEN。
   当前诊断不需要产品补丁。
2. 准备上游缺陷说明：函数、行 1681、空文件 size=0/offset=0、首次接受在 2104 失败。
   上游可考虑接纳合法 EOF 边界或显式处理零长度输入，并增加空文件、
   offset=size、offset>size 及传输中 ZRPOS 控制。
   这只是建议；本任务没有修改第三方实现、发 issue 或验证修订后的 peer。
   源码 `1820–1828` 的短包路径还会选择 ZCRCE；
   维护者文档 `750–752` 要求首次 ZRPOS 后用 ZCRCW，故不能仅凭比较符修改
   就宣称完全符合该新版文档或实际互操作已通过。
3. 如用户另行要求更强兼容，可评估显式跳过操作，仍分别记录已保存、已跳过和失败；
   或另选经过精确版本验证、确实支持空文件发送的未修改 peer。
   原 lrzsz 空文件缺 OO 是另一项后置收尾问题，继续单独保留，不能由本诊断关闭。

**来源、摘要、HTTP 和执行回执**

只下载 4 件原文件，共 **208,912 字节**；没有下载整个上游归档、克隆仓库或安装。
`sources-manifest.json` 保存完整 HTTPS URL、精确提交、字节数、SHA-256、
HTTP 头文件及其完整 SHA-256、最终 HTTP 200/TLS 验证结果。
三个源码 URL 固定到上述 commit，官方协议 URL 从已提交封存回执定位。

| 下载原件 | 字节数 | 完整 SHA-256 |
| --- | ---: | --- |
| `downloads/zmodem.c` | 71570 | `a9ae09a60b5b34d7add66a1f04c7a841a865bbc02c23ad94e2faebc3f64739fa` |
| `downloads/zmodem.h` | 14376 | `d9167ce9b2472984eb8e7d41c86d1182b8281da6dae8fd8e323f86372bf4c976` |
| `downloads/sexyz.c` | 61950 | `fbd5b6b925e52f48fa38015bec085b5359734684afe72a17cb911b3381df683d` |
| `downloads/zmodem-wip-20261004.txt` | 61016 | `ce4bf1125b737293b0be6ef161d3e0e49d416f4971dfcfe99910a311ba01c337` |

只从 originals.tar.gz 选择复制 9 件不超过 20 KB 的来源/结果小文件；
另在内存中定向读取一个 285,112 字节的 JSON 摘要索引，只保留三源码匹配条目。
没有对 tar 做未筛选大规模解包。`archive-readback.json` 保存逐件原成员摘要、
索引完整摘要及归档摘要：
`9eca3013dbd8424c0f2fa2613a0d7aae58df24d6267e40848d8a8bb45154c888`。

`commands/` 保留命令 argv、cwd、UTC 起点、耗时、退出码、stdout/stderr 原文及
各自完整 SHA-256；`http/` 保留 HTTP 原头。协议首次下载 exit 35
（TLS SSL_ERROR_SYSCALL，无响应正文）保持；第二次同一 HTTPS URL exit 0、
HTTP 200、TLS 校验 0。另有两次前置查找失误：
一次 rg 指向不存在的 interop 文件名、一次 zsh 将未引用的 `=https` 作路径展开而
在启动 curl 前失败；均没有运行产品、peer 或任何传输。

`verify_evidence.py` 离线核对 **3 件源码基线相等、1 件协议参考相等、9 件选择复制
原件逐字节相等**，`verify-evidence-r1` exit 0，结果 PASS。
`predicate-analysis.json` 是对源码条件的算术解释，明确没有执行 C、Rust 或 peer，
不把该解释当作运行测试。

新增文件全部限于本 work 目录。Cargo、peer、产品、CUA、SSH、安装、
第三方修改及 Git 提交/推送的执行次数均为 0。
Git 初始 tracked status 为空，末次只看到父级并行的四件 monitor 文件修改；
HEAD 前后相同。本任务未触碰这些修改，也不据此声称共享 checkout 最终干净。
所查 Zmodem 文件和约束文档的摘要另外记录在 `inputs-reviewed.json`。
