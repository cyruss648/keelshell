"""Bounded, workspace-local evidence helpers for the read-only peer diagnosis."""

import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def run(label, argv):
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    before = time.monotonic()
    log = ROOT / "commands" / label
    log.parent.mkdir(parents=True, exist_ok=True)
    script_input = None
    if Path(argv[0]).name.startswith("python") and "-" in argv[1:]:
        script_input = sys.stdin.buffer.read()
        log.with_suffix(".stdin").write_bytes(script_input)
    completed = subprocess.run(
        argv, cwd=REPO, input=script_input, capture_output=True, timeout=60
    )
    stdout = log.with_suffix(".stdout")
    stderr = log.with_suffix(".stderr")
    stdout.write_bytes(completed.stdout)
    stderr.write_bytes(completed.stderr)
    receipt = {
        "argv": argv,
        "cwd": str(REPO),
        "started_utc": started,
        "elapsed_seconds": time.monotonic() - before,
        "exit_code": completed.returncode,
        "stdout_file": str(stdout.relative_to(ROOT)),
        "stdout_sha256": sha256(completed.stdout),
        "stderr_file": str(stderr.relative_to(ROOT)),
        "stderr_sha256": sha256(completed.stderr),
    }
    if script_input is not None:
        receipt["stdin_file"] = str(log.with_suffix(".stdin").relative_to(ROOT))
        receipt["stdin_sha256"] = sha256(script_input)
    write_json(log.with_suffix(".json"), receipt)
    print(json.dumps(receipt, ensure_ascii=False))
    print(completed.stdout.decode(errors="replace"))
    if completed.stderr:
        print(completed.stderr.decode(errors="replace"), file=sys.stderr)
    return completed.returncode


if __name__ == "__main__":
    raise SystemExit(run(sys.argv[1], sys.argv[2:]))
