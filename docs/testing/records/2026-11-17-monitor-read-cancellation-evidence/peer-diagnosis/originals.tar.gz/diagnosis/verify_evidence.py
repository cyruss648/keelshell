"""Verify source provenance and archived receipts without running any peer."""

import hashlib
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent
ARCHIVE = (
    REPO
    / "docs/testing/records/2026-11-17-independent-zmodem-peers-evidence"
    / "originals.tar.gz"
)
COMMIT = "acce09a1778dc2c61a996a3407ff6ddcaf70acb3"


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def write_json(name, value):
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


with tarfile.open(ARCHIVE, "r:gz") as archive:
    member = archive.getmember("sexyz-preparation/evidence/source-baseline.json")
    assert member.isfile() and member.size < 300000
    baseline_data = archive.extractfile(member).read(300000)
    assert len(baseline_data) == member.size
    baseline = load(ROOT / "archived-source-baseline-selection.json")
    original = json.loads(baseline_data)
    for row in baseline:
        assert row in original
    copied = []
    for path in sorted((ROOT / "archived-receipts").rglob("*")):
        if not path.is_file():
            continue
        name = path.relative_to(ROOT / "archived-receipts").as_posix()
        member = archive.getmember(name)
        assert member.isfile() and member.size <= 20000
        data = archive.extractfile(member).read(20001)
        assert data == path.read_bytes(), name
        copied.append({"member": name, "bytes": len(data), "sha256": sha256(data)})

source_rows = []
for row in baseline:
    name = Path(row["path"]).name
    data = (ROOT / "downloads" / name).read_bytes()
    assert len(data) == row["bytes"] and sha256(data) == row["sha256"], name
    label = "fetch-" + name.replace(".", "-")
    receipt = load(ROOT / "commands" / (label + ".json"))
    response = load(ROOT / receipt["stdout_file"])
    assert receipt["exit_code"] == response["exitcode"] == 0
    assert response["http_code"] == 200 and response["ssl_verify_result"] == 0
    assert response["size_download"] == len(data)
    expected_url = (
        f"https://raw.githubusercontent.com/SynchronetBBS/sbbs/{COMMIT}"
        f"/src/sbbs3/{name}"
    )
    assert response["url_effective"] == expected_url
    headers = ROOT / "http" / (name + ".headers")
    source_rows.append(
        {
            "file": "downloads/" + name,
            "upstream_path": "src/sbbs3/" + name,
            "commit": COMMIT,
            "url": expected_url,
            "bytes": len(data),
            "sha256": sha256(data),
            "archive_baseline_exact_match": True,
            "http_status": 200,
            "tls_verification": 0,
            "http_headers": str(headers.relative_to(ROOT)),
            "http_headers_sha256": sha256(headers.read_bytes()),
        }
    )

reference = load(ROOT / "archived-receipts/parent/protocol-reference-r1.json")
data = (ROOT / "downloads/zmodem-wip-20261004.txt").read_bytes()
assert sha256(data) == reference["sha256"] and len(data) == reference["bytes"]
receipt = load(ROOT / "commands/fetch-protocol-r2.json")
response = load(ROOT / receipt["stdout_file"])
assert receipt["exit_code"] == 0 and response["http_code"] == 200
assert response["ssl_verify_result"] == 0 and response["url_effective"] == reference["url"]
source_rows.append(
    {
        "file": "downloads/zmodem-wip-20261004.txt",
        "url": reference["url"],
        "bytes": len(data),
        "sha256": sha256(data),
        "archive_reference_exact_match": True,
        "http_status": 200,
        "tls_verification": 0,
        "http_headers": "http/protocol-r2.headers",
        "http_headers_sha256": sha256((ROOT / "http/protocol-r2.headers").read_bytes()),
        "reference_status": "Maintainer work-in-progress rewrite, October 2026",
    }
)
write_json("sources-manifest.json", source_rows)
write_json(
    "archive-readback.json",
    {
        "archive": str(ARCHIVE.relative_to(REPO)),
        "sha256": sha256(ARCHIVE.read_bytes()),
        "expected_sha256": "9eca3013dbd8424c0f2fa2613a0d7aae58df24d6267e40848d8a8bb45154c888",
        "baseline_member": "sexyz-preparation/evidence/source-baseline.json",
        "baseline_member_bytes": len(baseline_data),
        "baseline_member_sha256": sha256(baseline_data),
        "copied_small_members": copied,
        "full_archive_extracted": False,
    },
)
assert sha256(ARCHIVE.read_bytes()) == "9eca3013dbd8424c0f2fa2613a0d7aae58df24d6267e40848d8a8bb45154c888"

# This is arithmetic applied to the source condition, not an executed C test.
source_lines = (ROOT / "downloads/zmodem.c").read_text().splitlines()
assert source_lines[1680].strip() == "if (zm->rxd_header_pos < zm->current_file_size) {"
assert source_lines[2103].strip() == "if (!zmodem_handle_zrpos(zm, &pos, /* timeout: */ 0))"
truth_table = [
    {
        "file_size": size,
        "offset": offset,
        "source_predicate_offset_lt_size": offset < size,
        "offset_within_inclusive_protocol_range": 0 <= offset <= size,
    }
    for size, offset in [(0, 0), (0, 1), (0, 4294967295), (1, 0), (1, 1), (1, 2)]
]
write_json(
    "predicate-analysis.json",
    {
        "method": "Arithmetic source-condition analysis only; no C or product execution",
        "source_line": 1681,
        "offset_type_source": "zmodem.h:235 uint32_t",
        "file_size_type_source": "zmodem.h:276 int64_t",
        "rows": truth_table,
        "zero_size_result": "No representable uint32_t offset can satisfy offset < 0",
    },
)
inputs = load(ROOT / "input-manifest.json")
for path in [
    "crates/keelshell-core/src/zmodem/receiver.rs",
    "crates/keelshell-core/src/zmodem/codec.rs",
]:
    data = (REPO / path).read_bytes()
    inputs.append({"path": path, "bytes": len(data), "sha256": sha256(data)})
write_json("inputs-reviewed.json", inputs)
print(
    json.dumps(
        {
            "status": "PASS",
            "downloaded_original_files": len(source_rows),
            "downloaded_bytes": sum(row["bytes"] for row in source_rows),
            "source_baseline_matches": len(baseline),
            "protocol_reference_matches": 1,
            "copied_archive_members_verified": len(copied),
            "protocol_or_peer_executions": 0,
            "sources": source_rows,
        },
        ensure_ascii=False,
        indent=2,
    )
)
