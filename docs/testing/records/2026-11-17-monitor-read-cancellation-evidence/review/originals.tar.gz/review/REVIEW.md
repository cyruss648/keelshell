**KeelShell 监控及时取消增量：独立非作者严格只读复核**

**结论：APPROVE，限于 r2 的五文件源码／功能增量。P0=0、P1=0、P2=0、P3=0。**
没有发现需要修改的源码或测试断言问题。该结论不代签父级正在执行的完整 r2 gate、完整产品、Windows API／OpenSSH、原生桌面或发行。

复核时间：2026-11-17T15:08:03.096608+08:00。工作目录为 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`。
评审者未参与产品实现；仅在 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-cancellation-review-20261117` 写入评审脚本、报告、清单、日志与测试二进制副本。
已读取 AGENTS、RTK、HANDOFF、SHARED_TARGET 及 Rust Engineer／Rust Best Practices 相关规则。用户本次严格只读约束优先：没有 Cargo、fmt、clean、tracked 写入、提交、推送、网络连接、产品启动、GUI 操作，也没有执行原 target 二进制。两次实际单测执行均通过 macOS sandbox-exec 禁止 network* 和专属目录外文件写入。

**来源与冻结绑定**

- 基线／开始与结束 HEAD：`4c8654f219779f48afd485bec8ff1b284905fbf0`；这是基线加未提交冻结输入的复核，不能仅用 HEAD 代表候选实现。
- r1：777 项，aggregate `22512505b86df8101b990974617593e869cdce55b7145b814b2bbab6ecfb4659`；开始逐项字节长度／SHA-256及聚合均独立匹配。
- 最终 r2：777 项，aggregate `5add62bc9b71b90964b71ebdeb9927192a7bc2c29a03cb24dae0ac390a730df2`；最终逐项与 `candidate-inputs-r2.json` 独立匹配。
- r1→r2 仅 `crates/keelshell-session/src/monitor/capabilities/tests.rs` 变化；其余 776 项完全相同，包括其他四件 source、集成夹具及 SSH owner 关联源码。
- r2 unit SHA-256：`755d20775e715addacc3e65e7055b967f1818037d669158ccbfd31e787997553`；10,786 字节。三处 `expect` 改为 `assert!(...is_ok())` 的完整替换已逐字节核对，timeout、future、说明及失败条件不变。`wait_invalidated` 的 Output 为 `()`，不存在因只检查外层成功而吞掉内层错误的弱化。
- 基线对比恰为五个 source 文件；`monitor.rs` 只有九行 rustdoc 增补，生产体完全相同。`ssh.rs`、`ssh/channel.rs` 全文件与基线逐字节相同。docs 由父级维护，未作为本评审可写范围。

**风险计数与位置**

| 级别 | 未关闭问题 | 文件／行 |
| --- | ---: | --- |
| P0 | 0 | 无 |
| P1 | 0 | 无 |
| P2 | 0 | 无 |
| P3 | 0 | 无 |

**关键源码／功能判断**

| 关注点 | 核对结论与精确位置 |
| --- | --- |
| 首次 poll 前撤权／防丢唤醒 | [crates/keelshell-session/src/monitor/capabilities.rs:174](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/capabilities.rs:174) 先递增 generation／revision 再 notify_waiters；[crates/keelshell-session/src/monitor/capabilities.rs:180](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/capabilities.rs:180) 先创建并 enable 通知，再 Acquire 读取 generation。撤权早于首次 poll 靠 generation 返回；发生在检查与 await 之间则由已注册通知保留。新 unit [crates/keelshell-session/src/monitor/capabilities/tests.rs:5](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/capabilities/tests.rs:5) 覆盖的是已经携带旧 generation 的 wait future，不能误说成尚未 begin 的整个 snapshot 也属于旧 generation。 |
| 同时 waiters／当前代 spurious 唤醒 | [crates/keelshell-session/src/monitor/capabilities.rs:181](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/capabilities.rs:181) 的 loop 每次重建通知并再次检查 generation。若旧 invalidate 在线程间延迟 notify，唤醒了已经取得新 generation 的等待者，它会重新等待，不把通知本身当作取消。[crates/keelshell-session/src/monitor/capabilities/tests.rs:20](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/capabilities/tests.rs:20) 实际登记 32 个旧等待者并验证全部完成，同时验证新代初次为 Pending。当前代 spurious 注入与精确多线程交错仅源码证明，现有用例未直接注入。 |
| 取消优先／probe_gate leader 未继续 poll | [crates/keelshell-session/src/monitor/platform.rs:84](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/platform.rs:84) 与 [crates/keelshell-session/src/monitor/platform.rs:104](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/platform.rs:104) 均 biased select，取消在 exec／锁等待之前；结果后仍复核 generation。[crates/keelshell-session/tests/windows_monitor.rs:698](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/windows_monitor.rs:698) 逐一 poll 三个 waiter；[crates/keelshell-session/tests/windows_monitor.rs:709](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/windows_monitor.rs:709) 撤权后保留 leader 不再 poll，先要求所有 waiter 返回 Cancelled，避免仅靠 leader 放锁造成假通过。 |
| 已发送 exec 的所属 CLOSE | [crates/keelshell-session/src/monitor/platform.rs:84](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/platform.rs:84) 丢弃 exec future 后，[crates/keelshell-session/src/ssh/channel.rs:150](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/ssh/channel.rs:150) 的 PendingChannel Drop 转交独立有界 owner。[crates/keelshell-session/tests/windows_monitor.rs:613](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/windows_monitor.rs:613) 先证实已发送，再在尚未释放回复时要求 Cancelled 和准确 channel CLOSE；不是等远端完成后才丢弃结果。 |
| 迟到 open 与派发门槛 | [crates/keelshell-session/src/ssh/channel.rs:199](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/ssh/channel.rs:199) 的独立 open owner 在 receiver 消失后仍持有已经 admission 的请求；[crates/keelshell-session/src/ssh/channel.rs:217](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/ssh/channel.rs:217) 继续等待至原期限，取得 channel 后关闭；send 失败的 payload 也带清理 owner。[crates/keelshell-session/src/ssh.rs:731](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/ssh.rs:731) 保留 open 后发送前 guard。[crates/keelshell-session/tests/windows_monitor.rs:1008](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/windows_monitor.rs:1008)、[crates/keelshell-session/tests/windows_monitor.rs:1067](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/windows_monitor.rs:1067) 要求先取消、再释放 held OPEN、观察准确 CLOSE，并以操作计数或完整 commands 长度核对无 stale exec。 |
| 普通 exec、独立 monitor、新代仍活 | [crates/keelshell-session/tests/windows_monitor.rs:775](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/windows_monitor.rs:775) 的 sibling monitor 与普通 exec 都在撤权前已打开；[crates/keelshell-session/tests/windows_monitor.rs:783](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/windows_monitor.rs:783) 在 poll 旧取消前再打开新代。[crates/keelshell-session/tests/windows_monitor.rs:790](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/windows_monitor.rs:790) 之后继续消费同三个在途 future，分别检查 CPU、PID、完整 stdout／stderr／非零 status 23。不是在取消后仅新建一个普通命令即宣称 sibling 存活。 |
| 缓存语义／不重试 | [crates/keelshell-session/src/monitor/capabilities.rs:196](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/capabilities.rs:196) 的 reset 在 observations 锁内撤权并清空；invalidate 只撤权，保留原观察时间与平台身份。[crates/keelshell-session/src/monitor/capabilities.rs:246](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/capabilities.rs:246) 的写入前后 generation 检查拒绝 stale 记录。[crates/keelshell-session/tests/windows_monitor.rs:625](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/windows_monitor.rs:625) 对照完整旧缓存或默认值，迟到回复后再核对；[crates/keelshell-session/tests/windows_monitor.rs:647](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/windows_monitor.rs:647) 精确命令计数区分显式下一次读取和 reset 后重新 probe。没有自动重放旧请求。 |
| 普通 exec／审核终止边界 | `ssh.rs` 全文件未改。[crates/keelshell-session/src/monitor.rs:906](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor.rs:906) 的 terminate 仍在实际发送处直接调用 guarded exec，[crates/keelshell-session/src/monitor.rs:922](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor.rs:922) 后不引入新取消 select；已经发送的审核动作保留真实回执。require_linux 的身份读取可及时取消，只影响发送前的只读前置步骤。 |
| 清理失败与共享连接 | [crates/keelshell-session/src/ssh/channel.rs:161](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/ssh/channel.rs:161) 的正常 CLOSE 只证明进入协议队列，不是远端进程终止或普遍远端 ACK。CLOSE 错误／2 秒超时可进入 [crates/keelshell-session/src/ssh.rs:1080](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/ssh.rs:1080) 的 close_or_abort；迟到 OPEN 到期也可中止共享连接。普通 sibling 存活只在正常清理条件成立，不能承诺失败清理下也隔离。[crates/keelshell-session/src/monitor.rs:621](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor.rs:621) 及 ADR 明确保留此边界；本次未注入这些故障。 |
| 测试任务回收／失败不可变成功 | [crates/keelshell-session/tests/windows_monitor.rs:494](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/windows_monitor.rs:494) 取出 JoinSet、abort_all 并在 2 秒内逐个 join；成功任务错误／panic 均传播，取消型 JoinError 按预期处理。session 关闭、server task 等待及 listener 断开检查分别执行。[crates/keelshell-session/tests/windows_monitor.rs:528](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/windows_monitor.rs:528) 对新／强化案例在错误、panic、15 秒超时后也先执行 close；清理失败不会使测试通过。Drop 只是 abort／socket shutdown 兜底，不能扩称为对 russh 全内部任务或 OS 子进程的完整 census。 |

**实际执行与断言强度**

| 项目 | 本评审实际结果 | 来源与边界 |
| --- | --- | --- |
| 复制前后摘要 | 两个原件 copy 前／后及副本全部一致；收尾原件与副本仍一致 | 原件 21,551,488 与 45,527,936 字节；只有这两件测试 binary 被复制，路径／SHA／receipt 见 binary-copies.json、binary-final.jsonl。 |
| 集成库存 | 19 个唯一名称，ignored 库存准确 1 项 | 对自有副本 --list；九个新增／三个强化均在。按“禁网络”要求未独立重跑 localhost TCP 集成用例，不能把父级 18 pass 写成我的执行结果。 |
| session lib 库存 | 426 个唯一名称，ignored 库存 4 项 | capabilities 十项逐名与源码一致；完整 lib 未执行。 |
| 缓存单测 | 10 passed／0 failed／0 ignored | r1 自有预编译副本，单独进程 sandbox 执行、exit 0／reaped，416 filtered；含两项新 unit，不能再重复加作 12 项缓存单测。 |
| 平台解析单测 | 2 passed／0 failed／0 ignored | 同一 r1 自有副本，另一个 sandbox 进程、exit 0／reaped，424 filtered。 |
| 独立实际功能测试合计 | **12 passed／0 failed／0 ignored** | 仅以上互不重复的 10+2；r2 独立 runtime 测试为 0，不包装成新编译。 |
| 完整性／库存离线检查 | **64 PASS／0 FAIL** | checks.json；这些是文件、receipt、测试名与版本绑定检查，不是额外 64 个产品测试。 |
| 记录的验证子进程 | 23 个，全部自然 exit 0／reaped，无 timeout | commands.json／commands.jsonl。初始规则和源码读取另列；未将父级 Cargo 命令计入本评审执行。 |

新增九项、强化三项、保留原七项与零删除已独立按函数内容核对，见 integration-test-delta.json。
取消辅助器 [crates/keelshell-session/tests/windows_monitor.rs:572](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/windows_monitor.rs:572) 要求 1 秒内准确返回 MonitorError::Cancelled，Session Timeout、其他错误或成功都失败；夹具 SSH 超时 3 秒，gate 60 秒。held exec／held OPEN 通过事件门槛建立先后关系，未用 sleep 推断“已发送”。已发送用例还在取消时确认 peer 没有发出响应，并在释放迟到回复后检查缓存没有刷新。

32 waiter 单元测试使用 Waker::noop 后手动轮询，证明已登记通知能被消费；它不直接证明 executor 实际调度延迟。集成也使用显式轮询来控制时序。与 Notify 底层实现和 generation 顺序相结合可支持本源码结论，不能外推为 UI 负载下的性能或公平调度验收。
本机 Cargo.lock 的 Tokio 1.54.1 与已缓存 notify.rs 的主源实现／文档亦只读核对，未联网查库。

**已有父级原件的复核，未算为独立执行**

- 红控制：实际准确替换基线三件生产文件，当前集成 **6 pass／12 fail／1 ignored**。十二个失败名称恰好等于九个新增和三个强化，原件分别有 `Error: Elapsed(())`；不是编译失败。内层 Cargo 101／reaped，外层控制器 0／reaped；before 副本分别与本评审 git cat-file 基线、摘要相等，r1 implementation 与冻结的对应输入相等。没有重新做源码替换／Cargo 红控制。
- r1 新集成：**18 pass／0 fail／1 ignored**，父级回执 0／reaped／2.786202s；完整 capabilities 10 pass，0／reaped／2.034611s。原日志、逐名结果、实际 Running 路径和完成回执均核对，之后才摘要并复制 binary。
- Darwin 真实 SSH：父级回执 0／reaped／5.813216s、15 pass；记录的自有资源已清理。这是本批既有采集回归证据，不是我独立建立的 SSH 测试，也不覆盖 Windows API／Windows SSH 或完整后代普查。
- r1 完整 gate：**失败保留**，1／reaped／19.303036s；在 unit 三处 expect_used Clippy 错误停止，Rust 全量未执行。原件保存在 logs/final-gate-r1-*。
- r2 format：父级 0／reaped／2.154196s；strict session all-targets Clippy：父级 0／reaped／9.784211s。两件 receipt 与原日志已读取保留。
- r2 完整 gate：父级已启动，本报告不等待、不判定完成，不拿 r1 的预编译结果代替 r2 全量运行。r2 只对 unit 三处等价断言修订做源码／摘要绑定。

**原失败与最终边界**

`checks-r1-during-update.json` 原样保留首次 48 PASS／1 FAIL：当时 r1 implementation 与正在改为 r2 的 unit 源码已不同。它被正确识别为版本变动，没有继续把 r1 整体冻结作为最终源码；r1／r2 manifest、unit 两份原文与完整差异均保留，最终重新绑定后 64 项全通过。最初误找 stdout.log／stderr.log 的读取失败亦在 commands.json 中保留，随后读取实际 command.log。

当前代 spurious Notify 的显式注入、enable／检查／await 精确多线程竞争、CLOSE 队列失败与永不确认的 OPEN 对共享连接的影响，本次主要依靠关联源码复核，不宣称为新增动态故障覆盖。受控 Windows 帧验证传输、路由和缓存，ignored 的真实 capture 项未解禁。完整产品、真实 Windows API／OpenSSH、三平台 native 和发行均保持另验。

**最终建议：对 `candidate-inputs-r2.json` 所绑定的五 source 增量给出限定 APPROVE；没有请求作者修改。完整 gate 与后续交付继续按父级实际原件判定。**
