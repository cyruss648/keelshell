"""Independent read-only review evidence; all writes stay beside this file."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
BASE = "4c8654f219779f48afd485bec8ff1b284905fbf0"
PARENT = ROOT / "work/monitor-cancellation-20261117"


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(name, value):
    path = OUT / name
    path.resolve().relative_to(OUT)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def run(label, argv, timeout=30, isolated=False):
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    tick = time.monotonic()
    env = os.environ.copy()
    env["GIT_OPTIONAL_LOCKS"] = "0"
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    if isolated:
        env["TMPDIR"] = str(OUT / "tmp")
        env["HOME"] = str(OUT / "home")
        env["RUST_TEST_THREADS"] = "1"
    process = subprocess.Popen(
        argv, cwd=OUT if isolated else ROOT, env=env,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True,
    )
    timed_out = False
    try:
        raw, _ = process.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            raw, _ = process.communicate(timeout=3)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            raw, _ = process.communicate(timeout=3)
    log = OUT / "logs" / f"{label}.log"
    log.write_bytes(raw)
    receipt = {
        "label": label, "argv": argv, "cwd": str(OUT if isolated else ROOT),
        "started_utc": started, "elapsed_seconds": time.monotonic() - tick,
        "pid": process.pid, "exit_code": process.returncode,
        "timed_out": timed_out, "reaped": process.returncode is not None,
        "log": str(log.relative_to(OUT)), "log_sha256": digest(log),
        "isolated_environment": isolated,
    }
    with (OUT / "commands.jsonl").open("a") as stream:
        stream.write(json.dumps(receipt, ensure_ascii=False) + "\n")
    return raw


def snapshot(label, frozen_name="candidate-inputs-r1.json"):
    names = run(
        f"{label}-names",
        ["git", "--no-optional-locks", "ls-files", "-z",
         "--cached", "--others", "--exclude-standard"],
    ).decode().split("\0")
    rows = []
    for name in sorted(set(names) - {""}):
        if name.startswith(("docs/", "work/")):
            continue
        path = ROOT / name
        raw = path.read_bytes()
        rows.append({"path": name, "bytes": len(raw),
                     "sha256": hashlib.sha256(raw).hexdigest()})
    frozen = json.loads((PARENT / frozen_name).read_text())
    aggregate = hashlib.sha256(json.dumps(
        rows, sort_keys=True, separators=(",", ":")
    ).encode()).hexdigest()
    head = run(f"{label}-head", [
        "git", "--no-optional-locks", "rev-parse", "HEAD",
    ]).decode().strip()
    result = {
        "head": head, "count": len(rows), "inputs": rows,
        "aggregate_sha256": aggregate,
        "matches_frozen_rows": rows == frozen["inputs"],
        "matches_frozen_aggregate": aggregate == frozen["aggregate_sha256"],
        "matches_base_head": head == BASE,
        "frozen_manifest": str(PARENT / frozen_name),
        "frozen_manifest_sha256": digest(PARENT / frozen_name),
    }
    save(f"inputs-{label}.json", result)
    print(json.dumps({k: v for k, v in result.items() if k != "inputs"}))
    return result


if __name__ == "__main__":
    snapshot("before")
    run("status-before", ["git", "--no-optional-locks", "status",
                         "--porcelain=v1", "--untracked-files=all"])
    run("changed-names-before", ["git", "--no-optional-locks", "diff",
                                "--name-only", BASE])
    run("candidate-diff", ["git", "--no-optional-locks", "diff",
                          "--no-ext-diff", "--no-textconv", BASE,
                          "--", "crates/keelshell-session"])
    run("whitespace", ["git", "--no-optional-locks", "diff",
                       "--check", BASE])
