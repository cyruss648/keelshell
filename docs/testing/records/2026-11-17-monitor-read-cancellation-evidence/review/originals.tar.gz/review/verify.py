"""Verify review inputs, inventories and existing receipts without rebuilding."""
import hashlib
import json
from pathlib import Path
import re

import audit

checks = []


def check(name, ok, evidence):
    checks.append({"id": name, "status": "PASS" if ok else "FAIL",
                   "evidence": evidence})
    if not ok:
        print("FAIL:", name)


before = json.loads((audit.OUT / "inputs-before.json").read_text())
check("base-head", before["matches_base_head"], before["head"])
check("engineering-count", before["count"] == 777, before["count"])
check("engineering-rows", before["matches_frozen_rows"], "777 byte lengths and hashes")
check("engineering-aggregate", before["matches_frozen_aggregate"],
      before["aggregate_sha256"])
changed = set((audit.OUT / "logs/changed-names-before.log").read_text().splitlines())
expected = {
    "crates/keelshell-session/src/monitor.rs",
    "crates/keelshell-session/src/monitor/capabilities.rs",
    "crates/keelshell-session/src/monitor/platform.rs",
    "crates/keelshell-session/src/monitor/capabilities/tests.rs",
    "crates/keelshell-session/tests/windows_monitor.rs",
}
check("five-source-files", {p for p in changed if not p.startswith("docs/")} == expected,
      sorted(changed))
comparison = json.loads((audit.OUT / "source-comparison.json").read_text())
for row in comparison[-2:]:
    check("unchanged-" + row["path"], not row["changed"], row)
base_monitor = (audit.OUT / "logs/base-source-0.log").read_text()
current_monitor = (audit.ROOT / "crates/keelshell-session/src/monitor.rs").read_text()
def no_rustdoc(text):
    return "\n".join(line for line in text.splitlines()
                     if not line.lstrip().startswith("///"))
check("monitor-rs-production-unchanged", no_rustdoc(base_monitor) == no_rustdoc(current_monitor),
      "Only rustdoc lines differ; terminate and read-collector bodies are unchanged.")

delta = json.loads((audit.OUT / "integration-test-delta.json").read_text())
check("nine-new-integration-tests", len(delta["added"]) == 9, delta["added"])
check("three-strengthened-existing-tests", len(delta["changed_existing"]) == 3,
      delta["changed_existing"])
check("no-test-removal", not delta["removed"], delta["removed"])
def inventory(label):
    return [line.removesuffix(": test")
            for line in (audit.OUT / "logs" / label).read_text().splitlines()
            if line.endswith(": test")]
integration = inventory("inventory-monitor-focused-green-r1.log")
lib = inventory("inventory-monitor-capabilities-green-r1.log")
ignored_lib = inventory("lib-ignored-inventory.log")
check("integration-inventory", len(integration) == 19 and len(set(integration)) == 19,
      integration)
check("lib-inventory", len(lib) == 426 and len(set(lib)) == 426,
      {"count": len(lib), "ignored": ignored_lib})
for name in delta["added"] + delta["changed_existing"]:
    check("inventory-" + name, name in integration, name)
source_tests = (audit.ROOT / "crates/keelshell-session/src/monitor/capabilities/tests.rs").read_text()
source_capabilities = re.findall(r"(?:async )?fn (\w+)\(", source_tests)
source_capabilities.remove("with_capacity")
lib_capabilities = [s for s in lib if s.startswith("monitor::capabilities::tests::")]
check("capabilities-inventory-exact",
      {s.split("::")[-1] for s in lib_capabilities} == set(source_capabilities),
      lib_capabilities)

receipts = {}
parent_logs = {}
for label in ["monitor-focused-green-r1", "monitor-capabilities-green-r1",
              "monitor-red-control-r1", "darwin-ssh-regression-r1"]:
    path = audit.PARENT / label / "result.json"
    receipt = json.loads(path.read_text())
    receipts[label] = receipt
    logpath = audit.PARENT / label / "command.log"
    raw = logpath.read_bytes()
    (audit.OUT / "logs" / (label + "-parent.log")).write_bytes(raw)
    parent_logs[label] = raw.decode(errors="replace")
    check("parent-receipt-" + label,
          receipt["reaped"] and not receipt["timed_out"] and receipt["exit_code"] == 0,
          {"path": str(path), "sha256": audit.digest(path), "receipt": receipt,
           "command_log_sha256": hashlib.sha256(raw).hexdigest()})
green = parent_logs["monitor-focused-green-r1"]
red = parent_logs["monitor-red-control-r1"]
def outcomes(log, kind):
    return {m.group(1) for m in re.finditer(r"(?m)^test ([\w:]+) \.\.\. " + kind, log)}
check("parent-green-result", "18 passed; 0 failed; 1 ignored" in green, "parent only")
check("parent-red-result", "6 passed; 12 failed; 1 ignored" in red, "parent only")
check("parent-green-exact-names", outcomes(green, "ok") == set(integration) - {
    "captured_windows_api_frames_are_accepted_through_authenticated_monitor_routing"},
    sorted(outcomes(green, "ok")))
check("parent-red-failures-exact", outcomes(red, "FAILED") ==
      set(delta["added"] + delta["changed_existing"]), sorted(outcomes(red, "FAILED")))
check("parent-red-timeout-reasons",
      red.count("Error: Elapsed(())") == 12, "12 executed test failures, not compile failures")
red_receipt = json.loads((audit.PARENT / "red-control-result.json").read_text())
check("parent-red-inner-receipt", red_receipt["exit_code"] == 101
      and red_receipt["reaped"] and red_receipt["restored_implementation"],
      red_receipt)
base_rows = json.loads((audit.PARENT / "before.json").read_text())
for row in base_rows:
    path = row["path"]
    index = next(i for i, item in enumerate(comparison) if item["path"] == path)
    baseline = (audit.OUT / "logs" / f"base-source-{index}.log").read_bytes()
    check("parent-red-baseline-" + path,
          baseline == (audit.PARENT / "before" / path).read_bytes()
          and hashlib.sha256(baseline).hexdigest() == row["sha256"],
          row)
for path in expected - {"crates/keelshell-session/tests/windows_monitor.rs",
                        "crates/keelshell-session/src/monitor/capabilities/tests.rs"}:
    copy = audit.PARENT / "implementation-r1" / path
    check("parent-implementation-restored-" + path,
          copy.read_bytes() == (audit.ROOT / path).read_bytes(), path)
unit = "crates/keelshell-session/src/monitor/capabilities/tests.rs"
frozen_unit = next(row for row in before["inputs"] if row["path"] == unit)
check("parent-implementation-r1-unit-matches-r1-freeze",
      audit.digest(audit.PARENT / "implementation-r1" / unit) == frozen_unit["sha256"],
      {"path": unit, "r1_sha256": frozen_unit["sha256"],
       "current_revision": "r2 assertion-only edit independently reviewed"})

for label, expected_count in [("capabilities", 10), ("platform", 2)]:
    log = (audit.OUT / "logs" / (label + ".log")).read_text()
    check("independent-" + label,
          len(outcomes(log, "ok")) == expected_count
          and f"{expected_count} passed; 0 failed; 0 ignored" in log,
          {"passed": expected_count, "failed": 0, "ignored": 0,
           "network": "denied by sandbox-exec", "binary": "review-owned copy"})
copies = json.loads((audit.OUT / "binary-copies.json").read_text())
for row in copies:
    check("binary-copy-" + row["parent_label"],
          row["same_hash_before_copy_after"]
          and row["sha256_copy"] == audit.digest(row["copy"]),
          row)
r2 = json.loads((audit.OUT / "inputs-final-r2.json").read_text())
binding = json.loads((audit.OUT / "r1-r2-binding.json").read_text())
check("r2-count", r2["count"] == 777, r2["count"])
check("r2-rows", r2["matches_frozen_rows"], r2["frozen_manifest"])
check("r2-aggregate", r2["matches_frozen_aggregate"], r2["aggregate_sha256"])
check("r2-base-head", r2["matches_base_head"], r2["head"])
check("r2-single-unit-change", binding["changed_non_docs_inputs"] == [unit],
      binding["changed_non_docs_inputs"])
check("r2-other-776-unchanged", binding["same_other_776_inputs"],
      "Includes production and the complete integration fixture.")
check("r2-assertion-equivalence", binding["only_three_exact_assertion_replacements"],
      binding["timeout_output"])
check("r2-unit-hash", audit.digest(audit.ROOT / unit) == binding["r2_unit"]["sha256"],
      binding["r2_unit"])
check("integration-ignored-inventory", inventory("integration-ignored-inventory.log") == [
    "captured_windows_api_frames_are_accepted_through_authenticated_monitor_routing"],
    "One genuine Windows capture test remains ignored; not executed.")
for row in [json.loads(s) for s in
            (audit.OUT / "binary-final.jsonl").read_text().splitlines()]:
    check("original-final-" + row["parent_label"], row["original_unchanged"],
          row["original_sha256_final"])
    check("copy-final-" + row["parent_label"], row["copy_unchanged"],
          row["copy_sha256_final"])
for label in ["format-r2", "session-clippy-r2"]:
    receipt = json.loads((audit.OUT / "logs" / (label + "-result.json")).read_text())
    check("parent-r2-" + label, receipt["reaped"] and receipt["exit_code"] == 0
          and not receipt["timed_out"], receipt)
audit.save("parent-evidence.json", {
    "receipts": receipts, "red_control_inner": red_receipt,
    "integration_execution": "parent only; reviewer did not open loopback sockets",
})
commands = [json.loads(s) for s in (audit.OUT / "commands.jsonl").read_text().splitlines()]
check("recorded-commands-reaped", all(c["reaped"] and not c["timed_out"] for c in commands),
      {"count": len(commands)})
check("recorded-commands-no-cargo", all(c["argv"][0] not in
      {"cargo", "rustc", "rustfmt", "clippy-driver"} for c in commands),
      "No build, fmt, clean, dependency registry, network or product launch commands.")
audit.save("checks.json", {
    "schema": 1, "checks": checks,
    "passed": sum(c["status"] == "PASS" for c in checks),
    "failed": sum(c["status"] == "FAIL" for c in checks),
    "independent_test_results": {"passed": 12, "failed": 0, "ignored": 0},
    "integration_tests": {"inventoried": 19, "executed_by_reviewer": 0,
                          "parent_passed": 18, "parent_failed": 0, "parent_ignored": 1},
    "source_revision": "candidate-inputs-r2",
    "independent_runtime_revision": "candidate-inputs-r1",
    "independent_r2_runtime_tests": 0,
    "full_gate_r2": "parent running; not certified by this review",
})
print(json.dumps({"checks": len(checks),
                  "passed": sum(c["status"] == "PASS" for c in checks),
                  "failed": sum(c["status"] == "FAIL" for c in checks)}))
