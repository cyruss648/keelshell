"""Derive the exact historical CI terminal state using existing local bytes only."""

from collections import Counter
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import re
import subprocess

SOURCE = "bbd4eaccfa8bba2feb487ff43e0423567428bc82"
RUN = 43955379234
AGGREGATE = "2ea283af87af7e0af2fa912ebc28f9360e0c5113cd40e1111502f8cdd6d8551e"
JOBS = {
    133608443190: "native (windows-2025)",
    133608443592: "native (macos-26)",
    133608443616: "native (ubuntu-24.04)",
}
REGRESSIONS = [
    "monitor::tests::independent_disk_monitor::independent_disk_samples_survive_production_theme_buttons_and_focused_input",
    "monitor::tests::disk_monitor_minimum_workspace_languages_themes_scroll_and_selection_are_stable",
]
KEYS = ("passed", "failed", "ignored")


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def totals(rows):
    return {key: sum(row["summary"][key] for row in rows) for key in KEYS}


def check_receipt(files, label, expected):
    receipt = json.loads(files[label + ".json"])
    raw = files[label + ".log"]
    assert receipt["observed_exit"] == receipt["controller_exit"] == expected, label
    assert not receipt["timed_out"] and not receipt["interrupted"], label
    assert receipt["terminal"]["direct_reaped"], label
    assert receipt["terminal"]["active_processes"] == 0, label
    assert receipt["terminal"]["pipes_drained"], label
    assert not receipt["terminal"]["errors"] and not receipt["errors"], label
    assert len(raw) == receipt["log_bytes"] and digest(raw) == receipt["log_sha256"], label


def python_runs(text):
    """Keep separate unittest subruns instead of adding them to Rust counts."""
    lines = text.splitlines()
    rows = []
    for index, line in enumerate(lines):
        match = re.fullmatch(r"Ran (\d+) tests? in ([\d.]+)s", line)
        if not match:
            continue
        following = [value for value in lines[index + 1:index + 5] if value.strip()]
        assert following, ("missing Python outcome", index)
        outcome = re.fullmatch(r"OK(?: \(skipped=(\d+)\))?", following[0])
        assert outcome, ("unsuccessful Python subrun", following[0])
        ran, skipped = int(match[1]), int(outcome[1] or 0)
        rows.append({
            "run": ran, "passed": ran - skipped, "failed": 0,
            "skipped": skipped, "seconds": float(match[2]),
            "summary": line, "outcome": following[0],
        })
    return rows


def group(text, command):
    marker = f"##[group]Run {command}\n"
    assert text.count(marker) == 1, command
    return text.split(marker, 1)[1].split("\n##[group]Run ", 1)[0]


def derive(files):
    """Validate saved parser outputs and return a reproducible JSON summary."""
    document = lambda name: json.loads(files[name])
    state = document("ci-current-r1.log")
    assert state["databaseId"] == RUN and state["headSha"] == SOURCE
    assert state["status"] == "completed" and state["conclusion"] == "success"
    assert len(state["jobs"]) == 3
    assert {job["databaseId"]: job["name"] for job in state["jobs"]} == JOBS
    check_receipt(files, "ci-current-r1", 0)
    check_receipt(files, "collect-terminal-r1", 1)
    check_receipt(files, "collect-terminal-r2", 1)
    assert "AssertionError: 133608443190" in files["collect-terminal-r1.log"].decode()
    assert "StopIteration" in files["collect-terminal-r2.log"].decode()
    assert files["download_and_derive.py"] == files["download-diagnostics/r2/download_and_derive.py"]
    assert b"--allow-escape-sequences" not in files["download-diagnostics/r1/download_and_derive.py"]
    assert b"--allow-escape-sequences" in files["download-diagnostics/r2/download_and_derive.py"]

    namespace = {"__name__": "sealed_original_ci_parser"}
    exec(compile(files["summarize_tests.py"], "sealed_original_ci_parser", "exec"), namespace)
    reports = []
    for job in state["jobs"]:
        job_id = job["databaseId"]
        assert job["status"] == "completed" and job["conclusion"] == "success"
        raw_name = f"job-{job_id}.log"
        raw = files[raw_name]
        assert raw and not files[f"job-{job_id}-download-stderr.log"]
        assert files[f"download-diagnostics/r1/job-{job_id}.log"] == b""
        assert files[f"download-diagnostics/r1/job-{job_id}-download-stderr.log"] == (
            b"the response contains terminal escape sequences; "
            b"pass --allow-escape-sequences to output it anyway\n"
        )
        parsed = namespace["summarize"](raw)
        assert parsed == document(f"job-{job_id}-suites.json"), job_id
        suites, docs = parsed["suites"], parsed["doctest_runs_unassigned"]
        assert len(suites) == 92 and len(docs) == 6
        assert not parsed["inventory_result_summary_mismatches"]
        for row in suites + docs:
            names = dict(row["results"])
            counts = Counter(names.values())
            assert len(names) == len(row["results"]) == row["declared_tests"]
            assert [counts[value] for value in ("ok", "FAILED", "ignored")] == [
                row["summary"][key] for key in KEYS
            ]
            assert row["summary"]["state"] == "ok" and row["summary"]["failed"] == 0
        # Only this derived selector normalizes separators; all original bytes stay intact.
        app_rows = [
            row for row in suites
            if "unittests src/main.rs " in row["suite"].replace("\\", "/")
            and "keelshell_app" in row["suite"]
        ]
        assert len(app_rows) == 1, job_id
        app = app_rows[0]
        outcomes = dict(app["results"])
        assert all(outcomes.get(name) == "ok" for name in REGRESSIONS), job_id
        text = namespace["normalize"](raw)
        assert text.splitlines().count(SOURCE) == 2, job_id
        gate = group(text, "python scripts/check.py")
        discovery_start = re.search(
            r"^Running: .+ -m unittest discover -s scripts -p test_\*\.py$", gate, re.M,
        )
        assert discovery_start and gate.count("Running: cargo fmt --all --check") == 1
        discovery = gate[discovery_start.start():].split("Running: cargo fmt --all --check", 1)[0]
        discovery_runs = python_runs(discovery)
        assert len(discovery_runs) == 1 and discovery_runs[0]["run"] == 293
        workspace = gate.split(
            "Running: cargo test --workspace --locked -- --test-threads=4\n", 1,
        )[1].split("Running: cargo test -p keelshell-ai ", 1)[0]
        helpers = python_runs(workspace)
        assert [row["run"] for row in helpers] == ([] if job_id == 133608443190 else [30])
        packaging = python_runs(group(
            text, 'python -m unittest discover -s packaging -p "test_*.py" -v',
        ))
        assert len(packaging) == 1 and packaging[0]["run"] == 57
        assert "Dependency version policy: passed" in gate
        commands = re.findall(r"^Running: (.*)$", gate, re.M)
        assert len(commands) == 7
        steps = [
            {key: step[key] for key in (
                "number", "name", "status", "conclusion", "startedAt", "completedAt",
            )}
            for step in job["steps"]
        ]
        assert len(steps) == len({step["number"] for step in steps}) == 14
        assert all(step["status"] == "completed" for step in steps)
        assert all(step["conclusion"] in ("success", "skipped") for step in steps)
        by_name = {step["name"]: step["conclusion"] for step in steps}
        assert by_name["Rust quality gate"] == by_name["Packaging regression tests"] == "success"
        windows = job_id == 133608443190
        for name in (
            "Windows native filesystem preflight", "Windows archive codec preflight",
            "Windows session backend preflight",
        ):
            assert by_name[name] == ("success" if windows else "skipped")
        for name in (
            "OpenSSH interoperability (macOS and Linux)",
            "Preserve OpenSSH interoperability receipts",
        ):
            assert by_name[name] == ("skipped" if windows else "success")
        assert by_name["Prepare Linux OpenSSH interoperability server"] == (
            "success" if job_id == 133608443616 else "skipped"
        )
        reports.append({
            "job_id": job_id, "name": job["name"],
            "status": job["status"], "conclusion": job["conclusion"],
            "started_utc": job["startedAt"], "completed_utc": job["completedAt"],
            "raw_file": raw_name, "raw_bytes": len(raw), "raw_sha256": digest(raw),
            "saved_parser_output_exactly_recomputed": True,
            "ordinary_suites": len(suites), "ordinary_rust": totals(suites),
            "ordinary_declared": sum(row["declared_tests"] for row in suites),
            "rustdoc_subruns": len(docs), "rustdoc": totals(docs),
            "rustdoc_headers_unassigned": parsed["doctest_headers_unassigned"],
            "app_suite_original": app["suite"], "app_declared": app["declared_tests"],
            "app": app["summary"], "original_failure_results": {
                name: outcomes[name] for name in REGRESSIONS
            },
            "python_discovery": discovery_runs[0], "python_workspace_helpers": helpers,
            "python_packaging": packaging[0],
            "custom_harness_headers_not_added_to_libtest_counts": parsed["custom_harness_headers"],
            "gate_commands": commands, "dependency_version_policy": "passed",
            "steps": steps, "step_counts": dict(Counter(row["conclusion"] for row in steps)),
            "tests_replayed": 0,
        })
    return {
        "source_commit": SOURCE, "run_id": RUN,
        "status": state["status"], "conclusion": state["conclusion"],
        "snapshot_updated_utc": state["updatedAt"],
        "jobs": reports, "steps_total": sum(len(row["steps"]) for row in reports),
        "derivation": "Existing local logs and unchanged parser; no download or test replay.",
        "collector_failures_preserved": ["collect-terminal-r1", "collect-terminal-r2"],
        "original_download_receipt_limit": (
            "The failed outer r2 collector saved all logs and suites before StopIteration; "
            "it saved no completed aggregate summary or independent per-job download receipt. "
            "This derivation does not invent those exits, durations, or acquisition times."
        ),
        "independent_app_list_inventory_available": False,
        "python_discovery_verbose_inventory_available": False,
        "tests_replayed": 0, "network_requests": 0, "cargo_commands": 0,
        "target_accesses": 0, "native_desktop_acceptance": False,
        "current_dirty_windows_implementation_certified": False,
    }


def bind_git(root, freeze):
    """Read the historical commit's tree/blobs, never current engineering files."""
    assert freeze["count"] == len(freeze["inputs"]) == 731
    assert digest("".join(
        f"{row['path']}\0{row['sha256']}\n" for row in freeze["inputs"]
    ).encode()) == freeze["aggregate_sha256"] == AGGREGATE
    names = [
        name.decode() for name in subprocess.check_output(
            ["git", "--no-optional-locks", "ls-tree", "-r", "--name-only", "-z", SOURCE],
            cwd=root, timeout=20,
        ).split(b"\0") if name and not name.startswith((b"docs/", b".hallmark/"))
    ]
    assert sorted(names) == [row["path"] for row in freeze["inputs"]]
    assert len(names) == len(set(names)) == 731

    def verify(row):
        assert "target" not in Path(row["path"]).parts
        raw = subprocess.check_output(
            ["git", "--no-optional-locks", "show", f"{SOURCE}:{row['path']}"],
            cwd=root, timeout=15,
        )
        assert len(raw) == row["bytes"] and digest(raw) == row["sha256"], row["path"]

    with ThreadPoolExecutor(max_workers=4) as pool:
        list(pool.map(verify, freeze["inputs"]))
    return {
        "source": SOURCE, "run_id": RUN, "engineering_inputs": 731,
        "aggregate_sha256": AGGREGATE, "mismatches": [],
        "freeze_capture_head_metadata": freeze["head"],
        "binding": "Complete engineering path set, lengths and SHA-256 from exact Git blobs.",
        "current_working_engineering_files_read": 0,
        "tests_replayed": 0, "network_requests": 0, "cargo_commands": 0, "target_accesses": 0,
    }


def main():
    base = Path(__file__).resolve().parent
    root = base.parents[1]
    original = json.loads((base / "original-inputs-r1.json").read_text())
    files = {}
    for row in original["entries"]:
        data = (base / row["path"]).read_bytes()
        assert len(data) == row["bytes"] and digest(data) == row["sha256"], row["path"]
        if row["archive_member"]:
            files[row["path"]] = data
    summary = derive(files)
    binding = bind_git(root, json.loads(files["inputs-freeze-r2.json"]))
    for name, data in (
        ("terminal-summary-offline-r1.json", summary),
        ("exact-source-binding-offline-r1.json", binding),
    ):
        with (base / name).open("x") as output:
            json.dump(data, output, indent=2)
            output.write("\n")
    print(json.dumps({
        "source": SOURCE, "run": RUN, "engineering_inputs": 731,
        "platforms": [{key: job[key] for key in (
            "job_id", "name", "ordinary_rust", "app", "rustdoc",
            "python_discovery", "python_workspace_helpers", "python_packaging",
            "step_counts", "original_failure_results",
        )} for job in summary["jobs"]],
        "mismatches": [], "tests_replayed": 0, "network_requests": 0,
    }))


if __name__ == "__main__":
    main()
