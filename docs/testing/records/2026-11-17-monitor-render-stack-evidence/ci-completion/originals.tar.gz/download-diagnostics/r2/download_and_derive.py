"""Fetch terminal exact-source CI job logs, preserving bytes before derivation."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
from summarize_tests import normalize, summarize

run = json.loads((BASE / "ci-current-r1.log").read_text())
assert run["headSha"] == "bbd4eaccfa8bba2feb487ff43e0423567428bc82"
assert run["databaseId"] == 43955379234
assert run["status"] == "completed" and run["conclusion"] == "success"


def collect(job):
    job_id = job["databaseId"]
    assert job["status"] == "completed" and job["conclusion"] == "success"
    command = [
        "gh", "api", "--allow-escape-sequences", "--method", "GET",
        f"repos/cyruss648/keelshell/actions/jobs/{job_id}/logs",
    ]
    started = time.monotonic()
    result = subprocess.run(command, capture_output=True, timeout=120)
    (BASE / f"job-{job_id}.log").write_bytes(result.stdout)
    (BASE / f"job-{job_id}-download-stderr.log").write_bytes(result.stderr)
    assert result.returncode == 0, job_id
    parsed = summarize(result.stdout)
    (BASE / f"job-{job_id}-suites.json").write_text(json.dumps(parsed, indent=2) + "\n")
    ordinary = {
        key: sum(row["summary"][key] for row in parsed["suites"])
        for key in ("passed", "failed", "ignored")
    }
    rustdoc = {
        key: sum(row["summary"][key] for row in parsed["doctest_runs_unassigned"])
        for key in ("passed", "failed", "ignored")
    }
    app = next(row for row in parsed["suites"]
               if "unittests src/main.rs " in row["suite"] and "keelshell_app" in row["suite"])
    normalized = normalize(result.stdout)
    gate = normalized.split("##[group]Run python scripts/check.py", 1)[1]
    gate = gate.split("\n##[group]Run ", 1)[0]
    python = re.findall(r"Ran (\d+) tests? in ([\d.]+)s", gate)
    skipped = re.findall(r"^OK \(skipped=(\d+)\)$", gate, re.M)
    assert python and skipped
    original_failures = [
        "monitor::tests::independent_disk_monitor::independent_disk_samples_survive_production_theme_buttons_and_focused_input",
        "monitor::tests::disk_monitor_minimum_workspace_languages_themes_scroll_and_selection_are_stable",
    ]
    results = dict(app["results"])
    assert all(results.get(name) == "ok" for name in original_failures)
    return dict(
        job_id=job_id, name=job["name"], command=command,
        download_exit=result.returncode, download_seconds=time.monotonic() - started,
        raw_bytes=len(result.stdout), raw_sha256=hashlib.sha256(result.stdout).hexdigest(),
        ordinary=ordinary, rustdoc=rustdoc, app=app["summary"],
        ordinary_suites=len(parsed["suites"]), python_runs=python, python_skipped=skipped,
        original_failure_names_now_ok=original_failures,
        steps=[dict(name=s["name"], conclusion=s["conclusion"])
               for s in job["steps"] if s["name"] in (
                   "Rust quality gate", "OpenSSH interoperability (macOS and Linux)",
                   "Windows session backend preflight",
               )],
        tests_replayed=0,
    )


with ThreadPoolExecutor(max_workers=3) as pool:
    reports = list(pool.map(collect, run["jobs"]))
with (BASE / "terminal-summary-r1.json").open("x") as output:
    json.dump(dict(
        source_commit=run["headSha"], run_id=run["databaseId"],
        status="completed", conclusion="success", jobs=reports,
        tests_replayed=0, native_desktop_acceptance=False,
    ), output, indent=2)
    output.write("\n")
for row in reports:
    print(json.dumps({k: row[k] for k in (
        "job_id", "name", "ordinary", "rustdoc", "app", "python_runs", "python_skipped",
        "original_failure_names_now_ok", "tests_replayed",
    )}))
