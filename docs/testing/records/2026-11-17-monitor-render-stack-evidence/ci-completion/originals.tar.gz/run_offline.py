"""Record a bounded local Python derivation/verification without importing project code."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

base = Path(__file__).resolve().parent
root = base.parents[1]
label, script = sys.argv[1:]
allowed = {
    "work/monitor-stack-ci-20261117/derive_terminal_offline.py",
    "docs/testing/records/2026-11-17-monitor-render-stack-evidence/ci-completion/verify.py",
}
assert script in allowed, script
log, receipt = base / f"{label}.log", base / f"{label}.json"
assert not log.exists() and not receipt.exists()
command = [sys.executable, "-B", script]
started_utc = datetime.now(timezone.utc).isoformat()
started = time.monotonic()
with log.open("xb") as output:
    result = subprocess.run(
        command, cwd=root, stdout=output, stderr=subprocess.STDOUT, timeout=60,
        env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1", GIT_OPTIONAL_LOCKS="0"),
    )
raw = log.read_bytes()
record = {
    "started_utc": started_utc, "observed_exit": result.returncode,
    "controller_exit": result.returncode, "timed_out": False, "interrupted": False,
    "terminal": {
        "direct_reaped": True, "active_processes": 0,
        "pipes_drained": True, "errors": [],
        "scope": "Synchronous child completed; helper Git children are bounded and waited.",
    },
    "errors": [], "command": command, "seconds": time.monotonic() - started,
    "log_bytes": len(raw), "log_sha256": hashlib.sha256(raw).hexdigest(),
    "network_requests": 0, "cargo_commands": 0, "target_accesses": 0,
    "tests_replayed": 0,
}
with receipt.open("x") as output:
    json.dump(record, output, indent=2)
    output.write("\n")
print(json.dumps(record))
if result.returncode:
    print(raw.decode(errors="replace"))
sys.exit(result.returncode)
