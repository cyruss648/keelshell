"""Remove only owned duplicates whose exact Git originals have been verified."""
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
COMMIT = json.loads((BASE / "feature-readback-r2.json").read_text())["head"]
TARGET = ROOT / "work/recovery-batch-integration-20261115/target"


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def git_file(commit, path):
    return subprocess.check_output(
        ["git", "show", f"{commit}:{path}"], cwd=ROOT, timeout=30,
    )


def identity(path):
    value = path.stat()
    return [value.st_dev, value.st_ino]


def package_rows(path):
    return {
        p.relative_to(path).as_posix(): digest(p.read_bytes())
        for p in sorted(path.rglob("*")) if p.is_file()
    }


target_before = identity(TARGET)
package_before = package_rows(BASE / "package-r2")
plan = {}
archives = []


def add(path, raw, original):
    if not path.exists():
        return
    assert path.is_file() and not path.is_symlink(), path
    assert path.read_bytes() == raw, path
    row = dict(
        path=path.relative_to(ROOT).as_posix(), bytes=len(raw),
        sha256=digest(raw), original=original,
    )
    assert path not in plan or plan[path]["sha256"] == row["sha256"], path
    plan[path] = row


def archive(commit, directory, candidates):
    prefix = f"docs/testing/records/{directory}"
    manifest = json.loads(git_file(commit, prefix + "/manifest.json"))
    raw = git_file(commit, prefix + "/originals.tar.gz")
    assert len(raw) == manifest["archive_bytes"]
    assert digest(raw) == manifest["archive_sha256"]
    with tarfile.open(fileobj=io.BytesIO(raw), mode="r:gz") as tar:
        members = tar.getmembers()
        assert len(members) == manifest["count"] == len(manifest["entries"])
        assert [m.name for m in members] == [r["path"] for r in manifest["entries"]]
        for member, row in zip(members, manifest["entries"]):
            assert member.isfile()
            content = tar.extractfile(member).read()
            assert len(content) == row["bytes"] and digest(content) == row["sha256"]
            for local_base, relative_prefix in candidates:
                name = row["path"]
                if relative_prefix and not name.startswith(relative_prefix):
                    continue
                if relative_prefix:
                    name = name[len(relative_prefix):]
                add(
                    ROOT / local_base / name, content,
                    f"{commit}:{prefix}/originals.tar.gz#{row['path']}",
                )
    archives.append(dict(
        commit=commit, path=prefix, members=manifest["count"],
        archive_sha256=manifest["archive_sha256"],
    ))


archive(COMMIT, "2026-11-17-monitor-render-stack-evidence", [
    ("work/monitor-stack-20261117", ""),
    ("work/windows-monitor-planning-20261117", "windows-monitor-planning/"),
])
archive(COMMIT, "2026-11-17-darwin-udp-sockets-evidence/ci-completion", [
    ("work/darwin-udp-ci-20261117", ""),
    ("work/darwin-udp-delivery-20261117", ""),
])
archive("262a642605ffdb52ef4d6bef075aef17cc910149",
        "2026-11-17-darwin-udp-sockets-evidence/delivery", [
    ("work/darwin-udp-delivery-20261117", ""),
])

precommit = json.loads(
    (ROOT / "work/monitor-stack-20261117/normal-package-precommit-r2.json").read_text()
)
normal = json.loads((BASE / "normal-package-r2.json").read_text())
assert normal["application_files_equal_to_precommit"]
assert normal["manifest"]["files"] == precommit["manifest"]["files"]
for row in precommit["files"]:
    path = ROOT / "work/monitor-stack-20261117/package-precommit-r2" / row["path"]
    raw = path.read_bytes()
    assert len(raw) == row["bytes"] and digest(raw) == row["sha256"], path
    plan[path] = dict(
        path=path.relative_to(ROOT).as_posix(), bytes=len(raw),
        sha256=row["sha256"],
        original="superseded precommit package; exact file digests retained in Git main evidence",
    )

# Verification-only receipts were created after their parent archive. Preserve
# their bytes in the current delivery before removing the obsolete owned base.
old_delivery = ROOT / "work/darwin-udp-delivery-20261117"
saved = BASE / "previous-delivery-tail"
for path in sorted(old_delivery.rglob("*")):
    if path.is_file() and path not in plan:
        assert not path.is_symlink()
        destination = saved / path.relative_to(old_delivery)
        destination.parent.mkdir(parents=True, exist_ok=True)
        raw = path.read_bytes()
        if not destination.exists():
            destination.write_bytes(raw)
        assert destination.read_bytes() == raw
        add(path, raw, destination.relative_to(ROOT).as_posix())

roots = [
    ROOT / "work/monitor-stack-20261117",
    ROOT / "work/windows-monitor-planning-20261117",
    ROOT / "work/darwin-udp-ci-20261117",
    old_delivery,
]
for base in roots:
    for path in base.rglob("*.pyc"):
        if "__pycache__" in path.relative_to(base).parts:
            raw = path.read_bytes()
            assert not path.is_symlink()
            plan[path] = dict(
                path=path.relative_to(ROOT).as_posix(), bytes=len(raw),
                sha256=digest(raw), original="owned disposable Python bytecode",
            )
leftovers = [
    str(path.relative_to(ROOT))
    for base in roots for path in base.rglob("*")
    if path.is_file() and path not in plan
]
assert not leftovers, leftovers
for path, row in plan.items():
    assert digest(path.read_bytes()) == row["sha256"], path

for path in plan:
    path.unlink()
for base in roots:
    for path in sorted(base.rglob("*"), key=lambda p: len(p.parts), reverse=True):
        if path.is_dir():
            path.rmdir()
    base.rmdir()
assert identity(TARGET) == target_before
assert package_rows(BASE / "package-r2") == package_before
receipt = dict(
    captured_utc=datetime.now(timezone.utc).isoformat(),
    source_commit=COMMIT, archives_verified=archives,
    removed_files=len(plan), removed_bytes=sum(r["bytes"] for r in plan.values()),
    entries=list(plan.values()), target_identity_unchanged=True,
    normal_package_unchanged=True, obsolete_owned_directories_removed=4,
    kept_current_delivery_helpers=True,
)
with (BASE / "cleanup-r2.json").open("x") as output:
    json.dump(receipt, output, indent=2)
    output.write("\n")
print(json.dumps({k: v for k, v in receipt.items() if k != "entries"}))
