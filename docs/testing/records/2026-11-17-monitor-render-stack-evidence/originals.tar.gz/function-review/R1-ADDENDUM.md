**r1 收口补记：仅保留历史执行，当前最终签署转入 r2。**

r1 的库存和 2 MiB monitor 专项已真实执行，1377 名 / 78 passed、0 failed、0 ignored、exit 0；r1 测试前、测试后和当时最终快照均匹配原 730 冻结与专用副本。

在随后交付核验中，monitor.rs 已从 65488 bytes / 32b7f59d66bb500e24deabb8d9e099b7419cf20e37dc8c18cf12ef7e69d5c1db 变成 35759 bytes / d2efeedc51544747800c7ab6419172f25ecba394a15c833264622db8e6ad1f23；对应行号断言实际 exit 1。原报告、快照、测试原文、回执和该失败全部保留。此为交付阶段外部源码漂移，不能把 r1 的 APPROVE 或 78/0/0 移签为 r2。

用户随后明确生产 r2 已完成，并授权用全新 r2 冻结与私有副本独立重审。最终报告在 r2 子目录使用新编号产生。父级 r1 限定 gate 主动 SIGINT / exit 130 / reaped 为用户提供的事实，未被本 reviewer 重放或写成全量通过。详见 r1-delivery-source-drift.json。
