**监控栈修复 r2 独立非作者功能复核：APPROVE（限定范围）**

时间：2026-11-17T04:41:45.713233+08:00。P0 / P1 / P2 / P3：**0 / 0 / 0 / 0**。建议父级接受精确 **r2** 的机械提取审阅和下述专用 prebuilt 功能结果，继续取得当前修复的 Linux / Windows 精确 CI 与原生验收。本报告只签 r2，不把 r1、旧 CI 或父级 gate 计作本次成功。由父收取并关闭 reviewer。

工作区 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`。开始和最终读回 HEAD 均为 `262a642605ffdb52ef4d6bef075aef17cc910149`。已读 AGENTS / RTK / HANDOFF / SHARED_TARGET，写入仅限指定 `function-review/` 内。没有访问任何共享 target。

**准确 r2 绑定及前后身份**

冻结文件 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-stack-20261117/inputs-freeze-r2.json`，输入 **731**，aggregate **`2ea283af87af7e0af2fa912ebc28f9360e0c5113cd40e1111502f8cdd6d8551e`**。独立成员表、每项 bytes 和 SHA-256 全部匹配冻结，mismatch **0**。测试前、测试后、最终与交付四次快照中，731 输入以及冻结文件本身的完整身份、bytes、SHA-256 相等。详见 [before-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-stack-20261117/function-review/r2/before-r2.json)、[after-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-stack-20261117/function-review/r2/after-r2.json)、[final-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-stack-20261117/function-review/r2/final-r2.json)、[delivery-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-stack-20261117/function-review/r2/delivery-r2.json) 和 [identity-verification-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-stack-20261117/function-review/r2/identity-verification-r2.json)。身份比较 device/inode/mode/nlink/uid/gid/size/mtime_ns/ctime_ns；atime 不作为不变断言。

唯一执行的 app 文件为 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-stack-20261117/review-prebuilt-r2/keelshell-app-tests`，独立识别为 macOS arm64 Mach-O。四次核对均为 **274,011,088 bytes**，SHA-256 **`805d56eaff8546ada4906971a660b2739d50a9fd8ba28afdb437d4f3d15f6190`**；device `16777231`、inode `279492966`、nlink `1` 及完整身份不变。r1 私有文件没有被本次替换或执行。父级记录中的 target 位置仅被当作回执文本读取，未对所指 target 对象执行 open/stat/遍历/运行。

**本次实际执行**

| 子命令 | 实际退出 | 结果与执行数 | 耗时 |
| --- | --- | --- | --- |
| r2 专用二进制 `--list` | `0` | **1377 tests / 1377 唯一名 / 0 benchmarks**；逐名和顺序等于父级 r2 编译库存，原始文本也完全一致 | 0.013918 s |
| `env RUST_MIN_STACK=2097152` r2 专用二进制 `monitor:: --test-threads=1` | `0` | **78 passed / 0 failed / 0 ignored**；0 measured，1299 filtered out | 外层 **72.141823 s**；harness **72.13 s** |

专项预算 **180 秒**，未超时；已实际 wait/reap，外层 controller 实际退出 `0`。r2 专项仅运行 **1 次**。`--list` 不执行测试，未执行其余 1299 项，不将 1377 记作全量 app 通过。78 个库存名、78 个唯一执行名、声明数和摘要逐项相等，无重复/缺失/额外结果。独立完整库存见 [1377 名](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-stack-20261117/function-review/r2/app-inventory-r2.names.txt)、[78 名](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-stack-20261117/function-review/r2/monitor-inventory-r2.names.txt)；逐名结果与日志行号见 [results-verification-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-stack-20261117/function-review/r2/results-verification-r2.json)。

两个原失败名与新增 UDP 三名均在独立库存中恰好一次、本次执行恰好一次，全部 **ok**：

| 关键项 | 完整名称 | 库存数 / 执行数 | 本次结果 | 原始证据 |
| --- | --- | --- | --- | --- |
| 原 Linux 失败名 | `monitor::tests::independent_disk_monitor::independent_disk_samples_survive_production_theme_buttons_and_focused_input` | 1 / 1 | **ok** | [stdout:73](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-stack-20261117/function-review/r2/monitor-2m-r2.stdout.log:73) |
| 原 Windows 失败名 | `monitor::tests::disk_monitor_minimum_workspace_languages_themes_scroll_and_selection_are_stable` | 1 / 1 | **ok** | [stdout:72](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-stack-20261117/function-review/r2/monitor-2m-r2.stdout.log:72) |
| UDP 主题/双语 | `monitor::tests::darwin_sockets::darwin_udp_rows_retain_endpoints_across_themes_and_languages_without_io` | 1 / 1 | **ok** | [stdout:68](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-stack-20261117/function-review/r2/monitor-2m-r2.stdout.log:68) |
| UDP 只读分派 | `monitor::tests::darwin_sockets::darwin_udp_probe_dispatch_stays_read_only_with_and_without_resource_sample` | 1 / 1 | **ok** | [stdout:67](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-stack-20261117/function-review/r2/monitor-2m-r2.stdout.log:67) |
| UDP 缓存分页 | `monitor::tests::darwin_sockets::socket_pagination_reaches_every_cached_row_without_ssh_and_clamps_on_refresh` | 1 / 1 | **ok** | [stdout:69](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-stack-20261117/function-review/r2/monitor-2m-r2.stdout.log:69) |

原始 [monitor stdout](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-stack-20261117/function-review/r2/monitor-2m-r2.stdout.log) 完整保留，stderr **0 bytes**；实际 argv、环境变量、预算、退出和 wait/reap 见 [monitor 回执](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-stack-20261117/function-review/r2/monitor-2m-r2.receipt.json)。库存实际回执见 [inventory 回执](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-stack-20261117/function-review/r2/app-inventory-r2.receipt.json)。

**r2 源码提取核验**

从本 reviewer r1 读取的 base Git blob 独立重建 r1 `monitor.rs`，重建产物的 **65,488 bytes / SHA-256 `32b7f59d66bb500e24deabb8d9e099b7419cf20e37dc8c18cf12ef7e69d5c1db`** 与当时冻结相等，再逐字比较以下六块。共 **681 行 / 29,809 bytes**，均逐字节一致。新 `monitor_view.rs` 整文件也等于独立构造的“原块 + 独立 helper 边界”结果；当前 `monitor.rs` 整文件等于仅执行模块注册、原块移除和对应 child/children 调用替换的预期结果。

| helper | 原块行数 | 原块 bytes | 逐字相等 | 返回 | 当前源码证据 |
| --- | --- | --- | --- | --- | --- |
| `controls_view` | 232 | 9693 | 是 | `AnyElement` | [monitor_view.rs:9](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_view.rs:9) |
| `resources_view` | 143 | 5504 | 是 | `AnyElement` | [monitor_view.rs:248](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_view.rs:248) |
| `networks_view` | 92 | 4350 | 是 | `AnyElement` | [monitor_view.rs:397](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_view.rs:397) |
| `filesystems_view` | 69 | 2880 | 是 | `AnyElement` | [monitor_view.rs:496](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_view.rs:496) |
| `processes_view` | 130 | 5449 | 是 | `AnyElement` | [monitor_view.rs:571](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_view.rs:571) |
| `process_confirmation_view` | 15 | 1933 | 是 | `Option<AnyElement>` | [monitor_view.rs:707](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor_view.rs:707) |

六个 helper 均为 `#[inline(never)]`；确认区保留 optional 语义，返回 `Option<AnyElement>`，其余五块返回 `AnyElement`。原 sockets 模块逐字保持，其原 231 行提取及独立 `#[inline(never)]` / `AnyElement` 边界也保持。当前工程差异只有 `monitor.rs` 和新增 `monitor_sockets.rs` / `monitor_view.rs`；没有测试、断言、预算、依赖或生产栈配置变化。详情含每块 SHA-256 见 [mechanical-verification-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-stack-20261117/function-review/r2/mechanical-verification-r2.json)。

监控内容与控件的顺序、元素 ID、无障碍标签、disabled 条件和 listener 都保留。[monitor.rs:884](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor.rs:884) 逐块调用 helper；[controls 调用](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor.rs:916) 与 [confirmation 调用](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-app/src/monitor.rs:917) 保持原父子位置。没有独立测量 prologue 栈帧字节数，父级提供的 r1 约 1.19 MB 数据不记作 reviewer 实测。

**保留 r1 与原 CI 失败**

r1 原库存、78/0/0 执行、前后/当时最终快照和报告均原样保留。交付时 `monitor.rs` 实际已漂移为 35,759 bytes / `d2efeedc51544747800c7ab6419172f25ecba394a15c833264622db8e6ad1f23`，使行号断言 exit **1**；该事实和原诊断分别保存于 [r1 漂移回执](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-stack-20261117/function-review/r1-delivery-source-drift.json)、[r1 检查失败](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-stack-20261117/function-review/delivery-verification-r1-failure.json) 和 [R1-ADDENDUM.md](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-stack-20261117/function-review/R1-ADDENDUM.md)。r1 历史观察与本次 r2 重新执行分开，不移签。父级 r1 限定 gate 的 SIGINT / exit 130 / reaped 仅按用户新增事实记载，未重放、未签为全通过；父级正在准备/执行的 r2 gate 也不属于本 reviewer 签署范围。

原 Quality `43945988599`、精确源码 `16703293012d798f885e1590f02c348c47e81a10` 的 Ubuntu job `133575666946` [原日志:2387](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-udp-ci-20261117/job-133575666946-failure-r1.log:2387) 为 independent disk 测试栈溢出 / SIGABRT；Windows job `133575666982` [原日志:3202](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/darwin-udp-ci-20261117/job-133575666982-failure-r1.log:3202) 为 minimum workspace 测试栈溢出，3206 行 `0xc00000fd / STATUS_STACK_OVERFLOW`。两项原失败保持；本次同名测试在 macOS arm64 prebuilt 的通过不等于原两平台已经通过。

**实际受控子命令计数**

r2 共 **12 个**受控子命令，全部实际退出 `0`、未超时、已 wait/reap。下表只统计 r2 受控子进程，r1 的测试和交付检查不并入 r2；初始只读文档、源码和机械比对工具调用留在本 chat 工具记录中。完整 argv/起止时刻见 [command-ledger-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-stack-20261117/function-review/r2/command-ledger-r2.json)。

| r2 回执标签 | 实际退出 | 外层秒数 | wait/reap |
| --- | --- | --- | --- |
| `before-r2-git-input-membership` | `0` | 0.032204 | 是 |
| `app-inventory-r2` | `0` | 0.013918 | 是 |
| `monitor-2m-r2` | `0` | 72.141823 | 是 |
| `head-r2` | `0` | 0.011273 | 是 |
| `engineering-diff-r2` | `0` | 0.013377 | 是 |
| `untracked-app-r2` | `0` | 0.012510 | 是 |
| `private-format-r2` | `0` | 0.003263 | 是 |
| `after-r2-git-input-membership` | `0` | 0.034753 | 是 |
| `results-parse-r2` | `0` | 0.030870 | 是 |
| `final-head-r2` | `0` | 0.010851 | 是 |
| `final-r2-git-input-membership` | `0` | 0.033177 | 是 |
| `delivery-r2-git-input-membership` | `0` | 0.034892 | 是 |

**未验证边界与交付**

独立编译 **0**；Cargo **0**；格式化 **0**；共享 target 访问 **0**；Git 变更 **0**；源码/docs 写入 **0**。使用父级本次复制的 r2 prebuilt，独立验证冻结、专用文件身份、编译库存与实际执行；源码到二进制的独立重新编译和构建来源验证仍为 **0**，构建来源依赖父级 r2 记录，不扩大为独立编译结论。

当前修复的 Linux / Windows 执行均 **0**，精确修复后 CI 尚未由本 reviewer 验证；三平台真实原生桌面操作与验收均 **0**。没有执行全量 app 或完整质量门禁；没有真实远端 SSH 重放，78 项既有测试自身使用的受控回环 SSH fixture 属授权测试内部。没有提交、推送、合并、清理、安装或启动正常应用，也没有关闭其他 agent。

可机读结论为 [review-summary-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/monitor-stack-20261117/function-review/r2/review-summary-r2.json)，完整 78 项结果、二进制/源码四次身份及每个实际退出均可沿以上链接读回。**批准建议：限定批准准确 r2；Linux / Windows 与真实原生待验收，由父收口。**
