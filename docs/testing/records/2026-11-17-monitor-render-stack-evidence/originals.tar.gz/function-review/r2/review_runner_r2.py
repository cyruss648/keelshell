"""Read frozen inputs and execute only the dedicated review test binary."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import platform
import signal
import stat
import subprocess
import sys
import time


ROOT = Path(__file__).absolute().parents[4]
OUT = Path(__file__).absolute().parent
FREEZE = ROOT / "work/monitor-stack-20261117/inputs-freeze-r2.json"
BINARY = ROOT / "work/monitor-stack-20261117/review-prebuilt-r2/keelshell-app-tests"
BASE = "262a642605ffdb52ef4d6bef075aef17cc910149"
AGGREGATE = "2ea283af87af7e0af2fa912ebc28f9360e0c5113cd40e1111502f8cdd6d8551e"
BINARY_SHA = "805d56eaff8546ada4906971a660b2739d50a9fd8ba28afdb437d4f3d15f6190"
BINARY_BYTES = 274011088


def utc():
    return datetime.now(timezone.utc).isoformat()


def write_json(name, data):
    with (OUT / name).open("x") as stream:
        json.dump(data, stream, indent=2, ensure_ascii=False)
        stream.write("\n")


def safe_file(path):
    relative = path.relative_to(ROOT)
    assert "target" not in relative.parts, str(relative)
    cursor = ROOT
    for part in relative.parts:
        cursor = cursor / part
        assert not cursor.is_symlink(), f"symlink forbidden: {cursor}"
    assert stat.S_ISREG(path.lstat().st_mode), str(path)


def identity(path):
    safe_file(path)
    before = path.stat()
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    after = path.stat()
    fields = ("st_dev", "st_ino", "st_mode", "st_nlink", "st_uid", "st_gid",
              "st_size", "st_mtime_ns", "st_ctime_ns")
    first = {field: getattr(before, field) for field in fields}
    last = {field: getattr(after, field) for field in fields}
    assert first == last, f"changed during hashing: {path}"
    return {"path": str(path.relative_to(ROOT)), "bytes": after.st_size,
            "sha256": digest.hexdigest(), "identity": last}


def execute(label, argv, budget, env_overrides=None):
    started = utc()
    start = time.monotonic()
    environment = os.environ.copy()
    environment["GIT_OPTIONAL_LOCKS"] = "0"
    if env_overrides:
        environment.update(env_overrides)
    timed_out = False
    with (OUT / f"{label}.stdout.log").open("xb") as stdout, \
            (OUT / f"{label}.stderr.log").open("xb") as stderr:
        process = subprocess.Popen(
            argv, cwd=ROOT, env=environment, stdout=stdout, stderr=stderr,
            start_new_session=True,
        )
        while process.poll() is None:
            remaining = budget - (time.monotonic() - start)
            if remaining <= 0:
                timed_out = True
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait(timeout=10)
                break
            try:
                process.wait(timeout=min(5, remaining))
            except subprocess.TimeoutExpired:
                pass
    receipt = {
        "started_utc": started, "finished_utc": utc(),
        "command": argv, "cwd": str(ROOT),
        "environment_overrides": env_overrides or {},
        "budget_seconds": budget, "elapsed_seconds": time.monotonic() - start,
        "pid": process.pid, "actual_exit_code": process.returncode,
        "timed_out": timed_out, "direct_child_waited_and_reaped": True,
        "stdout": identity(OUT / f"{label}.stdout.log"),
        "stderr": identity(OUT / f"{label}.stderr.log"),
    }
    write_json(f"{label}.receipt.json", receipt)
    print(json.dumps({key: receipt[key] for key in (
        "command", "actual_exit_code", "elapsed_seconds", "timed_out",
        "direct_child_waited_and_reaped",
    )}), flush=True)
    return receipt


def snapshot(label):
    declaration = json.loads(FREEZE.read_text())
    assert declaration["head"] == BASE
    assert declaration["count"] == len(declaration["inputs"]) == 731
    assert declaration["aggregate_sha256"] == AGGREGATE
    expected = declaration["inputs"]
    paths = [row["path"] for row in expected]
    assert paths == sorted(set(paths)), "duplicate or unsorted frozen paths"
    for name in paths:
        parsed = PurePosixPath(name)
        assert not parsed.is_absolute() and ".." not in parsed.parts
        assert "target" not in parsed.parts
    membership = execute(
        f"{label}-git-input-membership",
        ["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"],
        30,
    )
    assert membership["actual_exit_code"] == 0
    listed = (OUT / f"{label}-git-input-membership.stdout.log").read_bytes()
    names = sorted({
        entry.decode() for entry in listed.split(b"\0")
        if entry and not entry.startswith((b"docs/", b".hallmark/"))
    })
    assert names == paths, "current input membership differs from freeze"
    rows = [identity(ROOT / name) for name in names]
    content_rows = [{key: row[key] for key in ("path", "bytes", "sha256")}
                    for row in rows]
    mismatches = [
        {"expected": prior, "actual": current}
        for prior, current in zip(expected, content_rows) if prior != current
    ]
    aggregate = hashlib.sha256("".join(
        f"{row['path']}\0{row['sha256']}\n" for row in rows
    ).encode()).hexdigest()
    binary = identity(BINARY)
    result = {
        "captured_utc": utc(), "host": platform.platform(),
        "machine": platform.machine(), "base": BASE, "count": len(rows),
        "aggregate_sha256": aggregate, "freeze_file": identity(FREEZE),
        "input_content_mismatches": mismatches, "inputs": rows,
        "binary": binary, "current_membership_equals_freeze": names == paths,
    }
    write_json(f"{label}.json", result)
    assert not mismatches and aggregate == AGGREGATE
    assert binary["bytes"] == BINARY_BYTES and binary["sha256"] == BINARY_SHA
    print(json.dumps({
        "snapshot": label, "count": len(rows), "aggregate": aggregate,
        "mismatches": len(mismatches), "binary_bytes": binary["bytes"],
        "binary_sha256": binary["sha256"],
    }), flush=True)
    return result


def main():
    assert Path.cwd() == ROOT
    before = snapshot("before-r2")
    inventory = execute("app-inventory-r2", [str(BINARY), "--list"], 30)
    assert inventory["actual_exit_code"] == 0 and not inventory["timed_out"]
    monitor = execute(
        "monitor-2m-r2", ["/usr/bin/env", "RUST_MIN_STACK=2097152", str(BINARY),
                       "monitor::", "--test-threads=1"],
        180, {"RUST_MIN_STACK": "2097152"},
    )
    after = snapshot("after-r2")
    comparison = {
        "inputs_same_content_and_identity": before["inputs"] == after["inputs"],
        "freeze_same_content_and_identity": before["freeze_file"] == after["freeze_file"],
        "private_binary_same_content_and_identity": before["binary"] == after["binary"],
        "independent_compilations": 0, "cargo_commands": 0,
        "shared_target_accesses": 0, "test_executions": 1,
        "inventory_commands": 1,
        "test_actual_exit_code": monitor["actual_exit_code"],
        "test_timed_out": monitor["timed_out"],
    }
    write_json("before-after-comparison.json", comparison)
    print(json.dumps(comparison), flush=True)
    assert all(comparison[key] for key in (
        "inputs_same_content_and_identity", "freeze_same_content_and_identity",
        "private_binary_same_content_and_identity",
    ))
    return 0 if monitor["actual_exit_code"] == 0 and not monitor["timed_out"] else 1


if __name__ == "__main__":
    sys.exit(main())
