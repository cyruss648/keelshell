"""Reconcile the independent inventory and monitor run without running tests."""

import hashlib
import json
from pathlib import Path
import re


OUT = Path(__file__).absolute().parent
ROOT = OUT.parents[3]
WORK = ROOT / "work/monitor-stack-20261117"

KEY_NAMES = {
    "original_linux_failure": (
        "monitor::tests::independent_disk_monitor::"
        "independent_disk_samples_survive_production_theme_buttons_and_focused_input"
    ),
    "original_windows_failure": (
        "monitor::tests::"
        "disk_monitor_minimum_workspace_languages_themes_scroll_and_selection_are_stable"
    ),
    "udp_theme_locale": (
        "monitor::tests::darwin_sockets::"
        "darwin_udp_rows_retain_endpoints_across_themes_and_languages_without_io"
    ),
    "udp_readonly_dispatch": (
        "monitor::tests::darwin_sockets::"
        "darwin_udp_probe_dispatch_stays_read_only_with_and_without_resource_sample"
    ),
    "udp_cached_pagination": (
        "monitor::tests::darwin_sockets::"
        "socket_pagination_reaches_every_cached_row_without_ssh_and_clamps_on_refresh"
    ),
}


def write_json(name, data):
    with (OUT / name).open("x") as stream:
        json.dump(data, stream, indent=2, ensure_ascii=False)
        stream.write("\n")


def main():
    inventory_text = (OUT / "app-inventory-r2.stdout.log").read_text()
    parent_text = (WORK / "app-inventory-r2.log").read_text()
    run_text = (OUT / "monitor-2m-r2.stdout.log").read_text()
    names = re.findall(r"^(.+): test$", inventory_text, re.M)
    parent_names = re.findall(r"^(.+): test$", parent_text, re.M)
    monitor_names = [name for name in names if name.startswith("monitor::")]
    rows = []
    for number, line in enumerate(run_text.splitlines(), 1):
        match = re.fullmatch(r"test (.+) \.\.\. (ok|FAILED|ignored.*)", line)
        if match:
            rows.append({
                "name": match.group(1), "result": match.group(2),
                "stdout_line": number,
            })
    executed_names = [row["name"] for row in rows]
    declared = re.findall(r"^running (\d+) tests$", run_text, re.M)
    summaries = re.findall(
        r"^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; "
        r"(\d+) ignored; (\d+) measured; (\d+) filtered out; "
        r"finished in ([0-9.]+)s$", run_text, re.M,
    )
    assert len(summaries) == 1, summaries
    result, passed, failed, ignored, measured, filtered, seconds = summaries[0]
    counts = {
        "passed": int(passed), "failed": int(failed), "ignored": int(ignored),
        "measured": int(measured), "filtered_out": int(filtered),
    }
    keys = {
        label: {
            "name": name, "inventory_occurrences": names.count(name),
            "execution_occurrences": executed_names.count(name),
            "results": [row for row in rows if row["name"] == name],
        }
        for label, name in KEY_NAMES.items()
    }
    receipts = {
        label: json.loads((OUT / f"{label}.receipt.json").read_text())
        for label in ("app-inventory-r2", "monitor-2m-r2")
    }
    before = json.loads((OUT / "before-r2.json").read_text())
    after = json.loads((OUT / "after-r2.json").read_text())
    comparison = json.loads((OUT / "before-after-comparison.json").read_text())
    checks = {
        "1377_unique_app_tests": len(names) == len(set(names)) == 1377,
        "inventory_summary_is_1377_tests_zero_benchmarks":
            re.findall(r"^(\d+) tests, (\d+) benchmarks$", inventory_text, re.M)
            == [("1377", "0")],
        "independent_inventory_equals_parent_compiled_inventory": names == parent_names,
        "78_unique_monitor_inventory_names": len(monitor_names) == len(set(monitor_names)) == 78,
        "78_unique_monitor_execution_names": len(executed_names) == len(set(executed_names)) == 78,
        "monitor_inventory_and_execution_names_equal_including_order":
            monitor_names == executed_names,
        "no_unexpected_or_missing_monitor_names": set(monitor_names) == set(executed_names),
        "declared_78_tests": declared == ["78"],
        "summary_78_passed_0_failed_0_ignored":
            result == "ok" and counts == {
                "passed": 78, "failed": 0, "ignored": 0,
                "measured": 0, "filtered_out": 1299,
            },
        "every_result_ok": all(row["result"] == "ok" for row in rows),
        "two_original_failure_names_and_three_udp_names_each_present_once_and_ok":
            all(value["inventory_occurrences"] == value["execution_occurrences"] == 1
                and value["results"][0]["result"] == "ok" for value in keys.values()),
        "actual_exit_zero_and_waited":
            all(receipt["actual_exit_code"] == 0
                and receipt["direct_child_waited_and_reaped"]
                and not receipt["timed_out"] for receipt in receipts.values()),
        "exact_2m_stack_and_180s_budget":
            receipts["monitor-2m-r2"]["environment_overrides"]["RUST_MIN_STACK"] == "2097152"
            and receipts["monitor-2m-r2"]["budget_seconds"] == 180,
        "source_content_and_identity_unchanged":
            before["inputs"] == after["inputs"]
            and comparison["inputs_same_content_and_identity"],
        "freeze_content_and_identity_unchanged":
            before["freeze_file"] == after["freeze_file"]
            and comparison["freeze_same_content_and_identity"],
        "private_binary_content_and_identity_unchanged":
            before["binary"] == after["binary"]
            and comparison["private_binary_same_content_and_identity"],
    }
    result_data = {
        "checks": checks, "all_checks_passed": all(checks.values()),
        "app_inventory_count": len(names), "app_inventory_unique_count": len(set(names)),
        "monitor_inventory_count": len(monitor_names),
        "executed_test_count": len(rows), "counts": counts,
        "harness_seconds": float(seconds),
        "wall_seconds": receipts["monitor-2m-r2"]["elapsed_seconds"],
        "inventory_wall_seconds": receipts["app-inventory-r2"]["elapsed_seconds"],
        "key_tests": keys, "results": rows,
        "independent_compilations": 0, "independent_test_runs": 1,
        "shared_target_accesses": 0,
    }
    write_json("results-verification-r2.json", result_data)
    print(json.dumps({
        key: value for key, value in result_data.items()
        if key not in ("results", "checks")
    }, ensure_ascii=False, indent=2))
    assert result_data["all_checks_passed"], checks


if __name__ == "__main__":
    main()
