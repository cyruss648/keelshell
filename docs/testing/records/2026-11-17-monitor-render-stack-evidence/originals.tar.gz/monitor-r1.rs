//! Live host monitoring, with a separately confirmed Linux SIGTERM workflow.

#[path = "monitor_capabilities.rs"]
mod capabilities;
#[path = "monitor_disk.rs"]
mod disk;
#[path = "monitor_history.rs"]
mod history;
#[path = "monitor_path_comparison.rs"]
pub(crate) mod path_comparison;
#[path = "monitor_protocol.rs"]
mod protocol;
#[path = "monitor_sockets.rs"]
mod sockets;
#[cfg(test)]
#[path = "monitor_tests.rs"]
mod tests;
use gpui_kit::assets::IconName;
use std::{
    collections::BTreeMap,
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
        mpsc::{self, TryRecvError},
    },
    time::{Duration, Instant},
};

use gpui_kit::{
    component::{
        Disableable,
        button::{Button, ButtonVariants},
    },
    *,
};
use keelshell_session::{
    SshSession,
    monitor::{
        Capability, CapabilityReport, CapabilityState, DiskDevice, LinuxMonitor,
        MonitorCapabilities, MonitorError, MonitorPlatform, MonitorResult, ProcessIdentity,
        ProcessInfo, SampleRates, Snapshot, SocketInfo, TcpProbeResult,
    },
};

enum Job {
    Refresh,
    Redetect,
    Sockets,
    Probe(SocketInfo),
    Inspect(ProcessInfo),
    Terminate(ProcessIdentity),
}
use crate::i18n::{Message, t};

const PROCESS_PAGE_SIZE: usize = 5;
const SOCKET_PAGE_SIZE: usize = 12;
const MAX_RESULT_AGE: Duration = Duration::from_secs(10);

enum Outcome {
    Cancelled,
    Refreshed {
        snapshot: Box<MonitorResult<Snapshot>>,
        sampled_at: Instant,
        processes: MonitorResult<Vec<ProcessInfo>>,
        process_sampled_at: Instant,
        sockets: Option<MonitorResult<Vec<SocketInfo>>>,
        capabilities: CapabilityReport,
    },
    Sockets {
        result: MonitorResult<Vec<SocketInfo>>,
        capabilities: CapabilityReport,
    },
    Probed {
        socket: SocketInfo,
        result: MonitorResult<TcpProbeResult>,
        capabilities: CapabilityReport,
    },
    Inspected(MonitorResult<ProcessIdentity>),
    Terminated(MonitorResult<()>),
}

/// Resource and process panel bound to one authenticated SSH connection.
///
/// Opening it performs read-only collection. Automatic five-second refresh can
/// be paused; process inspection and the final SIGTERM confirmation are separate
/// actions. No process is stopped merely by selecting it.
pub struct MonitorPanel {
    protocol: Entity<protocol::ProtocolPanel>,
    path_comparison: Entity<path_comparison::PathComparisonPanel>,
    monitor: Option<LinuxMonitor>,
    capabilities: MonitorCapabilities,
    suspended: bool,
    host: String,
    runtime: Arc<tokio::runtime::Runtime>,
    snapshot: Option<Snapshot>,
    history: history::ResourceHistory,
    sample_generation: uuid::Uuid,
    refresh_in_flight: bool,
    mcp_sample_id: Option<uuid::Uuid>,
    rates: SampleRates,
    selected_disk: Option<DiskDevice>,
    processes: Vec<ProcessInfo>,
    sockets: Vec<SocketInfo>,
    socket_page: usize,
    probes: BTreeMap<String, TcpProbeResult>,
    process_page: usize,
    last_sample: Option<Instant>,
    last_process_sample: Option<Instant>,
    busy: bool,
    paused: bool,
    status: Message,
    pending: Option<ProcessIdentity>,
    worker_cancel: Option<Arc<AtomicBool>>,
    _job: Option<Task<()>>,
    _poll: Task<()>,
}

impl MonitorPanel {
    /// Start a host panel with an immutable, authenticated connection label.
    ///
    /// Workers belong to the application registry. Closing the panel cancels work
    /// that has not started; an already sent SIGTERM is awaited, never retried.
    /// Application shutdown joins workers after their SSH deadlines complete.
    pub fn new(
        session: SshSession,
        host: String,
        runtime: Arc<tokio::runtime::Runtime>,
        window: &mut Window,
        cx: &mut Context<Self>,
    ) -> Self {
        let executor = cx.background_executor().clone();
        let poll = cx.spawn(async move |this, cx| {
            loop {
                executor.timer(Duration::from_secs(5)).await;
                if this
                    .update(cx, |panel, cx| {
                        panel.history.prune(Instant::now());
                        if !panel.paused && panel.pending.is_none() {
                            panel.run(Job::Refresh, cx);
                        }
                        // Age and the five-minute viewport advance while paused.
                        cx.notify();
                    })
                    .is_err()
                {
                    break;
                }
            }
        });
        let protocol = cx.new(|cx| {
            protocol::ProtocolPanel::new(session.clone(), host.clone(), runtime.clone(), window, cx)
        });
        let path_comparison =
            cx.new(|_| path_comparison::PathComparisonPanel::new(session.clone(), runtime.clone()));
        let mut panel = Self {
            protocol,
            path_comparison,
            monitor: Some(LinuxMonitor::new(session)),
            capabilities: MonitorCapabilities::default(),
            suspended: false,
            host,
            runtime,
            snapshot: None,
            history: history::ResourceHistory::default(),
            sample_generation: uuid::Uuid::new_v4(),
            refresh_in_flight: false,
            mcp_sample_id: None,
            rates: SampleRates::default(),
            selected_disk: None,
            processes: Vec::new(),
            sockets: Vec::new(),
            socket_page: 0,
            probes: BTreeMap::new(),
            process_page: 0,
            last_sample: None,
            last_process_sample: None,
            busy: false,
            paused: false,
            status: Message::empty(),
            pending: None,
            worker_cancel: None,
            _job: None,
            _poll: poll,
        };
        panel.run(Job::Refresh, cx);
        panel
    }

    /// Share only fixed existing monitoring fields, without collecting new data.
    pub(crate) fn mcp_snapshot(&self) -> Option<keelshell_mcp::MonitorSnapshot> {
        if self.suspended {
            return None;
        }
        let snapshot = self.snapshot.as_ref()?;
        Some(keelshell_mcp::MonitorSnapshot {
            sample_id: self.mcp_sample_id?,
            age_milliseconds: self
                .last_sample?
                .elapsed()
                .as_millis()
                .min(u64::MAX as u128) as u64,
            cpu_percent: self.rates.cpu_busy_percent,
            memory_used_bytes: snapshot.memory.used_bytes(),
            memory_total_bytes: Some(snapshot.memory.total_bytes),
        })
    }

    /// Stop collection and revoke pending process actions, retaining displayed data.
    pub fn suspend(&mut self, cx: &mut Context<Self>) {
        if self.suspended {
            return;
        }
        self.suspended = true;
        self.paused = true;
        self.history.interrupt();
        self.sample_generation = uuid::Uuid::new_v4();
        self.pending = None;
        if let Some(monitor) = &self.monitor {
            monitor.invalidate_pending_capabilities();
        }
        self.monitor = None;
        self.protocol.update(cx, |panel, cx| panel.suspend(cx));
        self.path_comparison
            .update(cx, |panel, cx| panel.suspend(cx));
        if let Some(cancel) = &self.worker_cancel {
            cancel.store(true, Ordering::Release);
        }
        cx.notify();
    }

    /// Redraw labels without restarting collection or changing the selected process.
    pub fn refresh_locale(&mut self, _window: &mut Window, cx: &mut Context<Self>) {
        self.protocol.update(cx, |_, cx| cx.notify());
        self.path_comparison.update(cx, |_, cx| cx.notify());
        cx.notify();
    }

    fn set_paused(&mut self, paused: bool, cx: &mut Context<Self>) {
        if self.paused == paused || self.suspended {
            return;
        }
        self.paused = paused;
        self.history.interrupt();
        // Pause/resume is an authority boundary even if no frame was drawn.
        self.sample_generation = uuid::Uuid::new_v4();
        if let Some(monitor) = &self.monitor {
            monitor.invalidate_pending_capabilities();
        }
        if self.refresh_in_flight
            && let Some(cancel) = &self.worker_cancel
        {
            cancel.store(true, Ordering::Release);
        }
        // A revoked refresh cannot publish a later status. Keep independent
        // socket/process operations responsible for their own receipts.
        if !self.busy || self.refresh_in_flight {
            self.status = if paused {
                Message::new("自动刷新已暂停。", "Polling paused.")
            } else {
                Message::new(
                    "自动刷新已恢复，等待下一次采样。",
                    "Polling resumed; waiting for the next sample.",
                )
            };
        }
        cx.notify();
    }

    fn adopt_outcome(
        &mut self,
        outcome: Outcome,
        generation: Option<uuid::Uuid>,
        completed_at: Instant,
        cx: &mut Context<Self>,
    ) {
        self.adopt_outcome_at(outcome, generation, completed_at, Instant::now(), cx);
    }

    fn adopt_outcome_at(
        &mut self,
        outcome: Outcome,
        generation: Option<uuid::Uuid>,
        completed_at: Instant,
        now: Instant,
        cx: &mut Context<Self>,
    ) {
        self.busy = false;
        self.worker_cancel = None;
        self.refresh_in_flight = false;
        if generation.is_some_and(|generation| generation != self.sample_generation) {
            cx.notify();
            return;
        }
        if generation.is_some() && !fresh(completed_at, now) {
            self.history.interrupt();
            self.status = Message::new(
                "监控响应已过期，未采用；请刷新或重新检测。",
                "Monitoring response expired and was discarded; refresh or recheck capabilities.",
            );
            cx.notify();
            return;
        }
        self.apply_outcome(outcome, now, cx);
    }

    fn apply_outcome(&mut self, outcome: Outcome, now: Instant, cx: &mut Context<Self>) {
        self.busy = false;
        self.worker_cancel = None;
        // A sent SIGTERM still has a meaningful receipt. Other old results must
        // not refresh snapshots or resurrect process confirmation dialogs.
        if self.suspended && !matches!(outcome, Outcome::Terminated(_)) {
            return;
        }
        match outcome {
            Outcome::Cancelled => {
                self.history.interrupt();
                self.status = Message::new(
                    "下一条命令发送前已取消监控。",
                    "Monitoring cancelled before the next command was sent.",
                )
            }
            Outcome::Refreshed {
                snapshot,
                sampled_at,
                processes,
                process_sampled_at,
                sockets,
                capabilities,
            } => {
                if !self.adopt_capabilities(&capabilities, now, cx) {
                    return;
                }
                let mut errors_zh = Vec::new();
                let mut errors_en = Vec::new();
                match *snapshot {
                    _ if !fresh(sampled_at, now) => {
                        self.history.interrupt();
                        self.rates = SampleRates::default();
                        errors_zh.push("资源：过期响应未采用".into());
                        errors_en.push("Resources: expired response was discarded".into());
                    }
                    Ok(snapshot) => {
                        match self.history.record(
                            &snapshot,
                            self.snapshot.as_ref(),
                            sampled_at,
                            now,
                        ) {
                            Ok(cpu) => {
                                self.rates = self
                                    .snapshot
                                    .as_ref()
                                    .map(|old| snapshot.rates_since(old))
                                    .unwrap_or_default();
                                self.rates.cpu_busy_percent = cpu;
                                if cpu.is_none() {
                                    self.rates.cpu_iowait_percent = None;
                                }
                                self.snapshot = Some(snapshot);
                                self.mcp_sample_id = Some(uuid::Uuid::new_v4());
                                self.last_sample = Some(sampled_at);
                            }
                            Err(_) => {
                                self.rates = SampleRates::default();
                                errors_zh.push("资源：迟到或时间无效的采样未采用".into());
                                errors_en.push(
                                    "Resources: late or invalid sample time was discarded".into(),
                                );
                            }
                        }
                    }
                    Err(error) => {
                        self.history.interrupt();
                        self.rates = SampleRates::default();
                        let (zh, en) = error_text(&error);
                        errors_zh.push(format!("资源：{zh}"));
                        errors_en.push(format!("Resources: {en}"));
                    }
                }
                match processes {
                    _ if !fresh(process_sampled_at, now) => {
                        errors_zh.push("进程：过期响应未采用".into());
                        errors_en.push("Processes: expired response was discarded".into());
                    }
                    Ok(processes) => {
                        self.processes = processes;
                        self.process_page = self
                            .process_page
                            .min(self.processes.len().saturating_sub(1) / PROCESS_PAGE_SIZE);
                        self.last_process_sample = Some(process_sampled_at);
                    }
                    Err(error) => {
                        let (zh, en) = error_text(&error);
                        errors_zh.push(format!("进程：{zh}"));
                        errors_en.push(format!("Processes: {en}"));
                    }
                }
                if let Some(result) = sockets {
                    match result {
                        Ok(sockets) => {
                            self.replace_sockets(sockets);
                        }
                        Err(error) => {
                            let (zh, en) = error_text(&error);
                            errors_zh.push(format!("端口：{zh}"));
                            errors_en.push(format!("Sockets: {en}"));
                            self.replace_sockets(Vec::new());
                        }
                    }
                }
                if let CapabilityState::Unavailable(reason) = self.capabilities.filesystems.state {
                    errors_zh.push(format!("磁盘容量：{}", capabilities::reason_text(reason).0));
                    errors_en.push(format!("Filesystem capacity: {reason}"));
                }
                self.status = if errors_zh.is_empty() {
                    Message::new(
                        "已更新；CPU 与网速需要两次有效采样。",
                        "Updated; CPU and network rates need two valid samples.",
                    )
                } else {
                    Message::new(
                        format!(
                            "部分项目未更新，保留条目为旧数据；可重新检测。{}",
                            errors_zh.join(" · ")
                        ),
                        format!(
                            "Some items were not updated; retained entries are old. Recheck capabilities to retry. {}",
                            errors_en.join(" · ")
                        ),
                    )
                };
            }
            Outcome::Sockets {
                result,
                capabilities,
            } => {
                if !self.adopt_capabilities(&capabilities, now, cx) {
                    return;
                }
                match result {
                    Ok(sockets) => {
                        self.status = Message::new(
                            format!("已读取 {} 个端口条目。", sockets.len()),
                            format!("Loaded {} socket entries.", sockets.len()),
                        );
                        self.replace_sockets(sockets);
                    }
                    Err(error) => {
                        let (zh, en) = error_text(&error);
                        self.status = Message::new(
                            format!("端口诊断失败：{zh}"),
                            format!("Socket diagnostics failed: {en}"),
                        );
                        self.replace_sockets(Vec::new());
                    }
                }
            }
            Outcome::Probed {
                socket,
                result,
                capabilities,
            } => {
                if !self.adopt_capabilities(&capabilities, now, cx) {
                    return;
                }
                match result {
                    Ok(probe) => {
                        self.status = Message::new(
                            if probe.reachable {
                                format!("TCP {}:{} 可建立连接。", probe.host, probe.port)
                            } else {
                                format!(
                                    "TCP {}:{} 未建立连接（nc 状态 {}）。",
                                    probe.host, probe.port, probe.probe_status
                                )
                            },
                            if probe.reachable {
                                format!("TCP {}:{} accepted a connection.", probe.host, probe.port)
                            } else {
                                format!(
                                    "TCP {}:{} did not accept a connection (nc status {}).",
                                    probe.host, probe.port, probe.probe_status
                                )
                            },
                        );
                        self.probes.insert(socket_key(&socket), probe);
                    }
                    Err(error) => {
                        let (zh, en) = error_text(&error);
                        self.status = Message::new(
                            format!("TCP 探测失败：{zh}"),
                            format!("TCP probe failed: {en}"),
                        );
                        self.probes.remove(&socket_key(&socket));
                    }
                }
            }
            Outcome::Inspected(result) => match result {
                Ok(identity) => {
                    self.pending = Some(identity);
                    self.status = Message::new(
                        "请核对主机与进程后确认终止。自动刷新已暂停。",
                        "Review the host and process before confirming termination. Polling is paused.",
                    );
                }
                Err(error) => {
                    let (zh, en) = error_text(&error);
                    self.status = Message::new(
                        format!("进程核对失败：{zh}"),
                        format!("Process review failed: {en}"),
                    );
                }
            },
            Outcome::Terminated(result) => {
                self.status = match result {
                    Ok(()) => Message::new(
                        "已发送 SIGTERM，请刷新确认进程是否退出。自动刷新仍暂停。",
                        "SIGTERM sent; refresh to verify whether the process exited. Polling remains paused.",
                    ),
                    Err(error) => {
                        let (zh, en) = error_text(&error);
                        Message::new(
                            format!("终止结果：{zh}。超时可能代表结果未知，请核对后再操作。"),
                            format!(
                                "SIGTERM result: {en}. After timeout the result may be unknown; inspect before retrying."
                            ),
                        )
                    }
                }
            }
        }
        cx.notify();
    }

    fn replace_sockets(&mut self, sockets: Vec<SocketInfo>) {
        self.socket_page = self
            .socket_page
            .min(sockets.len().saturating_sub(1) / SOCKET_PAGE_SIZE);
        self.sockets = sockets;
        self.probes.clear();
    }

    fn run(&mut self, job: Job, cx: &mut Context<Self>) {
        let Some(monitor) = self.monitor.clone().filter(|_| !self.suspended) else {
            return;
        };
        if self.busy {
            return;
        }
        if matches!(&job, Job::Inspect(_) | Job::Terminate(_) | Job::Probe(_))
            && !self.linux_monitor_actions_available()
        {
            self.pending = None;
            self.status = Message::new(
                "此操作需要当前 Linux 资源采样；macOS 支持资源、进程、TCP 监听与 UDP 端口的只读采集。",
                "This operation requires a current Linux resource sample; macOS supports read-only resources, processes, TCP listeners and UDP sockets.",
            );
            cx.notify();
            return;
        }
        self.busy = true;
        let generation = (!matches!(&job, Job::Terminate(_))).then_some(self.sample_generation);
        self.refresh_in_flight = matches!(&job, Job::Refresh | Job::Redetect);
        self.status = match &job {
            Job::Refresh => Message::new("正在刷新主机状态…", "Refreshing from the host…"),
            Job::Redetect => Message::new(
                "正在重新检测主机监控能力…",
                "Rechecking host monitoring capabilities…",
            ),
            Job::Sockets => Message::new("正在读取端口…", "Reading sockets…"),
            Job::Probe(_) => Message::new(
                "正在执行只读 TCP 连接探测…",
                "Running a read-only TCP connect probe…",
            ),
            Job::Inspect(_) => Message::new(
                "正在核对进程身份，请稍候…",
                "Checking process identity before confirmation…",
            ),
            Job::Terminate(_) => Message::new(
                "正在发送已确认的 SIGTERM…",
                "Sending the confirmed SIGTERM once…",
            ),
        };
        let runtime = self.runtime.clone();
        let cancel = Arc::new(AtomicBool::new(false));
        let worker_cancel = cancel.clone();
        let (outgoing, incoming) = mpsc::sync_channel(1);
        let started = crate::terminal::spawn_owned_transport_worker(
            cx.entity_id(),
            "keelshell-monitor",
            cancel.clone(),
            move || {
                let outcome = runtime.block_on(execute_job(monitor, job, &worker_cancel));
                // Registry owns and joins the worker even after this view disappears.
                // In-flight writes run to a bounded outcome, never detached/retried.
                let failure = match &outcome {
                    Outcome::Terminated(Err(error)) => Some(error.to_string()),
                    _ => None,
                };
                let _ = outgoing.try_send((outcome, Instant::now()));
                failure.map_or(Ok(()), Err)
            },
        );
        if let Err(error) = started {
            self.busy = false;
            self.refresh_in_flight = false;
            if generation.is_some() {
                self.history.interrupt();
            }
            self.status = Message::detail(
                "无法启动监控任务",
                "Unable to start monitoring worker",
                error,
            );
            cx.notify();
            return;
        }
        self.worker_cancel = Some(cancel);
        let executor = cx.background_executor().clone();
        self._job = Some(cx.spawn(async move |this, cx| {
            let (outcome, completed_at) = loop {
                match incoming.try_recv() {
                    Ok(outcome) => break outcome,
                    Err(TryRecvError::Empty) => executor.timer(Duration::from_millis(30)).await,
                    Err(TryRecvError::Disconnected) => {
                        let _ = this.update(cx, |panel, cx| {
                            panel.busy = false;
                            panel.worker_cancel = None;
                            panel.refresh_in_flight = false;
                            if generation.is_some_and(|generation| generation != panel.sample_generation)
                                || panel.suspended
                            {
                                cx.notify();
                                return;
                            }
                            if generation.is_some() {
                                panel.history.interrupt();
                            }
                            panel.status = Message::new("监控任务未返回结果，请刷新后再操作。", "Monitoring worker ended without a result. Refresh before retrying any action.");
                            cx.notify();
                        });
                        return;
                    },
                }
            };
            let _ = this.update(cx, |panel, cx| {
                panel.adopt_outcome(outcome, generation, completed_at, cx);
                cx.notify();
            });
        }));
        cx.notify();
    }

    fn is_darwin(&self) -> bool {
        self.snapshot
            .as_ref()
            .is_some_and(|snapshot| snapshot.platform == MonitorPlatform::Darwin)
    }

    fn linux_monitor_actions_available(&self) -> bool {
        self.snapshot
            .as_ref()
            .is_some_and(|snapshot| snapshot.platform == MonitorPlatform::Linux)
    }
}

impl Drop for MonitorPanel {
    fn drop(&mut self) {
        if let Some(cancel) = &self.worker_cancel {
            cancel.store(true, Ordering::Release);
        }
    }
}

async fn execute_job(monitor: LinuxMonitor, job: Job, cancel: &AtomicBool) -> Outcome {
    // Cancellation deliberately does not drop an in-flight SSH exec future: its
    // bounded completion closes the channel and records unknown write outcomes.
    if cancel.load(Ordering::Acquire) {
        return Outcome::Cancelled;
    }
    match job {
        Job::Refresh | Job::Redetect => {
            let redetect = matches!(job, Job::Redetect);
            if redetect {
                monitor.reset_capabilities().await;
            }
            if cancel.load(Ordering::Acquire) {
                return Outcome::Cancelled;
            }
            let snapshot = monitor.snapshot().await;
            // Timestamp the resource response, before the independent ps query
            // or UI dispatch can delay adoption and make it look fresh.
            let sampled_at = Instant::now();
            if cancel.load(Ordering::Acquire) {
                return Outcome::Cancelled;
            }
            let processes = monitor.processes().await;
            let process_sampled_at = Instant::now();
            if cancel.load(Ordering::Acquire) {
                return Outcome::Cancelled;
            }
            let sockets = if redetect {
                Some(monitor.listening_sockets().await)
            } else {
                None
            };
            Outcome::Refreshed {
                snapshot: Box::new(snapshot),
                sampled_at,
                processes,
                process_sampled_at,
                sockets,
                capabilities: monitor.capability_report().await,
            }
        }
        Job::Sockets => Outcome::Sockets {
            result: monitor.listening_sockets().await,
            capabilities: monitor.capability_report().await,
        },
        Job::Probe(socket) => {
            let result = monitor.probe_tcp(&socket).await;
            Outcome::Probed {
                result,
                socket,
                capabilities: monitor.capability_report().await,
            }
        }
        Job::Inspect(process) => Outcome::Inspected(monitor.inspect_process(&process).await),
        Job::Terminate(identity) => Outcome::Terminated(monitor.terminate(identity).await),
    }
}

fn fresh(at: Instant, now: Instant) -> bool {
    now.checked_duration_since(at)
        .is_some_and(|age| age <= MAX_RESULT_AGE)
}

fn bytes(value: u64) -> String {
    const GIB: f64 = 1024.0 * 1024.0 * 1024.0;
    if value >= 1024 * 1024 * 1024 {
        format!("{:.2} GiB", value as f64 / GIB)
    } else {
        format!("{:.1} MiB", value as f64 / 1024.0 / 1024.0)
    }
}

fn rate(value: Option<f64>) -> String {
    value
        .map(|value| format!("{:.1} KiB/s", value / 1024.0))
        .unwrap_or_else(|| "—".into())
}

fn age(sample: Option<Instant>, cx: &App) -> String {
    sample
        .map(|at| {
            Message::new(
                format!("{} 秒前", at.elapsed().as_secs()),
                format!("{}s ago", at.elapsed().as_secs()),
            )
            .render(cx)
        })
        .unwrap_or_else(|| "—".into())
}

fn error_text(error: &MonitorError) -> (String, String) {
    let zh = match error {
        MonitorError::Session(error) => format!("SSH 通信失败：{error}"),
        MonitorError::Unsupported(_) => "目标系统不支持此项功能或所需系统命令。".into(),
        MonitorError::CapabilityUnavailable { reason, .. } => {
            capabilities::reason_text(*reason).0.into()
        }
        MonitorError::RemoteFailure { exit_status, .. } => match exit_status {
            Some(status) => format!("远端操作失败，退出状态 {status}"),
            None => "远端操作未返回退出状态，不能确认成功".into(),
        },
        MonitorError::InvalidData(_) => "采集响应不完整或格式不受支持".into(),
        MonitorError::ProcessChanged => "进程已退出或身份发生变化，请刷新后重新核对".into(),
        MonitorError::SocketChanged => "监听端口已变化，请刷新后重新探测".into(),
        MonitorError::InvalidPid => "只允许向大于 1 的有效 PID 发送终止信号".into(),
        MonitorError::ReviewExpired => "进程确认已过期，请重新核对".into(),
    };
    (zh, error.to_string())
}

fn socket_key(socket: &SocketInfo) -> String {
    format!("{}|{}|{}", socket.protocol, socket.local, socket.peer)
}

fn metric(
    cx: &App,
    label: &str,
    value: String,
    ratio: Option<f32>,
    color: u32,
) -> impl IntoElement {
    let visual = crate::design::palette(cx);
    let mut track = div().h(px(5.)).w_full().rounded_sm().bg(rgb(visual.border));
    if let Some(ratio) = ratio.filter(|value| value.is_finite()) {
        track = track.child(
            div()
                .h_full()
                .w(relative(ratio.clamp(0., 1.)))
                .rounded_sm()
                .bg(rgb(color)),
        );
    }
    div()
        .flex()
        .flex_col()
        .gap_1()
        .p_2()
        .rounded(px(crate::design::components(cx).control_radius))
        .bg(rgb(visual.surface))
        .border_1()
        .border_color(rgb(visual.border))
        .id(format!("monitor-metric-{label}"))
        .test_support()
        .role(accesskit::Role::Label)
        .aria_label(format!("{label}: {value}"))
        .child(
            div()
                .flex()
                .items_start()
                .justify_between()
                .gap_2()
                .text_xs()
                .child(
                    div()
                        .flex_1()
                        .min_w_0()
                        .whitespace_normal()
                        .text_color(rgb(visual.muted))
                        .child(label.to_owned()),
                )
                .child(
                    div()
                        .flex_shrink_0()
                        .text_right()
                        .text_color(rgb(visual.text))
                        .child(value),
                ),
        )
        .child(track)
}

fn section(cx: &App, label: &'static str, icon: IconName) -> Div {
    let visual = crate::design::palette(cx);
    div()
        .flex()
        .flex_col()
        .gap_2()
        .p_2()
        .my_1()
        .rounded(px(crate::design::components(cx).panel_radius))
        .border_1()
        .border_color(rgb(visual.border))
        .bg(rgb(visual.canvas))
        .child(
            div()
                .text_xs()
                .font_weight(FontWeight::SEMIBOLD)
                .text_color(rgb(visual.text))
                .flex()
                .items_center()
                .gap_2()
                .child(
                    div()
                        .w(px(20.))
                        .h(px(20.))
                        .flex()
                        .items_center()
                        .justify_center()
                        .rounded(px(crate::design::components(cx).control_radius))
                        .bg(rgb(visual.surface_active))
                        .text_color(rgb(visual.accent))
                        .child(icon),
                )
                .child(div().flex_1().min_w_0().child(label)),
        )
}

impl Render for MonitorPanel {
    fn render(&mut self, _: &mut Window, cx: &mut Context<Self>) -> impl IntoElement {
        let visual = crate::design::palette(cx);
        let components = crate::design::components(cx);
        let monitor_state = if self.suspended {
            (
                t(cx, "快照", "Snapshot"),
                t(
                    cx,
                    "上一会话快照；不会继续采集",
                    "Previous-session snapshot; collection is stopped",
                ),
                visual.warning,
            )
        } else if self.busy {
            (
                t(cx, "读取中", "Updating"),
                t(
                    cx,
                    "正在从主机读取监控数据",
                    "Reading monitoring data from the host",
                ),
                visual.accent,
            )
        } else if self.paused {
            (
                t(cx, "已暂停", "Paused"),
                t(
                    cx,
                    "自动刷新已暂停，可手动刷新",
                    "Automatic refresh is paused; manual refresh is available",
                ),
                visual.warning,
            )
        } else {
            (
                t(cx, "实时", "Live"),
                t(
                    cx,
                    "自动刷新每 5 秒运行",
                    "Automatic refresh runs every 5 seconds",
                ),
                visual.success,
            )
        };
        let controls = div()
            .id("monitor-controls")
            .test_support()
            .role(accesskit::Role::Group)
            .aria_label(t(cx, "主机监控控制区", "Host monitor controls"))
            .px_3()
            .py_2()
            .border_b_1()
            .border_color(rgb(visual.border))
            .flex()
            .flex_col()
            .gap_2()
            .child(
                div()
                    .flex()
                    .items_center()
                    .justify_between()
                    .gap_2()
                    .child(
                        div()
                            .flex()
                            .items_center()
                            .gap_2()
                            .min_w_0()
                            .text_sm()
                            .font_weight(FontWeight::SEMIBOLD)
                            .child(
                                div()
                                    .w(px(22.))
                                    .h(px(22.))
                                    .flex()
                                    .items_center()
                                    .justify_center()
                                    .rounded(px(components.control_radius))
                                    .bg(rgb(visual.surface_active))
                                    .text_color(rgb(visual.accent))
                                    .child(IconName::Server),
                            )
                            .child(div().flex_1().min_w_0().text_ellipsis().child(
                                if self.suspended {
                                    t(cx, "上一会话监控快照", "Previous session snapshot")
                                } else {
                                    t(cx, "主机监控", "Host monitor")
                                },
                            )),
                    )
                    .child(
                        div()
                            .id("monitor-state")
                            .test_support()
                            .role(accesskit::Role::Label)
                            .aria_label(monitor_state.1)
                            .flex_shrink_0()
                            .px_2()
                            .py_1()
                            .rounded_full()
                            .bg(rgb(visual.surface_active))
                            .text_xs()
                            .text_color(rgb(monitor_state.2))
                            .child(monitor_state.0),
                    ),
            )
            .child(
                div()
                    .id("monitor-host")
                    .test_support()
                    .role(accesskit::Role::Label)
                    .aria_label(self.host.clone())
                    .flex()
                    .items_center()
                    .gap_1()
                    .min_w_0()
                    .text_xs()
                    .text_color(rgb(visual.muted))
                    .child(IconName::Globe)
                    .child(
                        div()
                            .flex_1()
                            .min_w_0()
                            .text_ellipsis()
                            .child(self.host.clone()),
                    ),
            )
            .child(
                div()
                    .id("monitor-actions")
                    .test_support()
                    .role(accesskit::Role::Group)
                    .aria_label(t(cx, "主机监控操作", "Host monitor actions"))
                    .flex()
                    .flex_wrap()
                    .gap_1()
                    .child(
                        Button::new("refresh-monitor")
                            .disabled(self.suspended)
                            .icon(IconName::RefreshCw)
                            .ghost()
                            .compact()
                            .rounded(px(components.control_radius))
                            .label(if self.busy {
                                t(cx, "读取中…", "Reading…")
                            } else {
                                t(cx, "刷新", "Refresh")
                            })
                            .accessibility_label(t(
                                cx,
                                "刷新主机监控数据",
                                "Refresh host monitoring data",
                            ))
                            .on_click(cx.listener(|panel, _, _, cx| {
                                if panel.pending.is_none() {
                                    panel.run(Job::Refresh, cx);
                                }
                            })),
                    )
                    .child(
                        Button::new("pause-monitor")
                            .disabled(self.suspended)
                            .icon(if self.paused {
                                IconName::Play
                            } else {
                                IconName::Pause
                            })
                            .ghost()
                            .compact()
                            .rounded(px(components.control_radius))
                            .label(if self.paused {
                                t(cx, "继续", "Resume")
                            } else {
                                t(cx, "暂停", "Pause")
                            })
                            .accessibility_label(if self.paused {
                                t(cx, "继续自动刷新", "Resume automatic refresh")
                            } else {
                                t(cx, "暂停自动刷新", "Pause automatic refresh")
                            })
                            .on_click(cx.listener(|panel, _, _, cx| {
                                if !panel.suspended && panel.pending.is_none() {
                                    panel.set_paused(!panel.paused, cx);
                                }
                                cx.notify();
                            })),
                    )
                    .child(
                        Button::new("refresh-sockets")
                            .disabled(self.suspended || self.busy || self.pending.is_some())
                            .icon(IconName::Network)
                            .ghost()
                            .compact()
                            .rounded(px(components.control_radius))
                            .label(t(cx, "端口", "Sockets"))
                            .accessibility_label(t(cx, "读取端口", "Read sockets"))
                            .on_click(cx.listener(|panel, _, _, cx| {
                                if panel.pending.is_none() {
                                    panel.run(Job::Sockets, cx);
                                }
                            })),
                    ),
            )
            .child(
                div()
                    .text_xs()
                    .flex()
                    .items_center()
                    .gap_2()
                    .min_w_0()
                    .child(
                        div()
                            .flex_1()
                            .min_w_0()
                            .truncate()
                            .text_xs()
                            .text_color(rgb(visual.muted))
                            .child(
                                Message::new(
                                    format!(
                                        "资源 {} · 进程 {}",
                                        age(self.last_sample, cx),
                                        age(self.last_process_sample, cx)
                                    ),
                                    format!(
                                        "Resources {} · Processes {}",
                                        age(self.last_sample, cx),
                                        age(self.last_process_sample, cx)
                                    ),
                                )
                                .render(cx),
                            ),
                    )
                    .child(self.redetect_button(cx)),
            );
        let history_now = Instant::now();
        let cpu = self.rates.cpu_busy_percent;
        let memory = self.snapshot.as_ref().map(|snapshot| &snapshot.memory);
        let memory_ratio = memory.and_then(|m| {
            m.used_bytes()
                .filter(|_| m.total_bytes > 0)
                .map(|used| used as f32 / m.total_bytes as f32)
        });
        let memory_value = memory
            .and_then(|m| {
                m.used_bytes().filter(|_| m.total_bytes > 0).map(|used| {
                    format!(
                        "{:.1}% · {} / {}",
                        used as f64 / m.total_bytes as f64 * 100.,
                        bytes(used),
                        bytes(m.total_bytes)
                    )
                })
            })
            .unwrap_or_else(|| "—".into());
        let swap = memory.and_then(|m| Some((m.swap_total_bytes?, m.swap_free_bytes?)));
        let swap_used =
            swap.and_then(|(total, free)| total.checked_sub(free).map(|used| (used, total)));
        let swap_ratio = swap_used.map(|(used, total)| {
            if total == 0 {
                0.
            } else {
                used as f32 / total as f32
            }
        });
        let mut resources = section(cx, t(cx, "资源使用", "Resources"), IconName::Activity)
            .id("monitor-resources")
            .test_support()
            .role(accesskit::Role::Group)
            .aria_label(t(cx, "资源使用", "Resources"))
            .child(metric(
                cx,
                t(cx, "CPU", "CPU"),
                cpu.map(|value| format!("{value:.1}%"))
                    .unwrap_or_else(|| "—".into()),
                cpu.map(|value| value as f32 / 100.),
                visual.accent,
            ))
            .child(history::view(
                &self.history,
                history::Series::Cpu,
                history_now,
                cx,
            ))
            .child(metric(
                cx,
                t(cx, "内存", "Memory"),
                memory_value,
                memory_ratio,
                visual.success,
            ))
            .child(history::view(
                &self.history,
                history::Series::Memory,
                history_now,
                cx,
            ))
            .child(
                div()
                    .text_xs()
                    .text_color(rgb(visual.muted))
                    .child(self.history.time_range(history_now, cx)),
            )
            .child(metric(
                cx,
                t(cx, "交换空间", "Swap"),
                swap_used
                    .map(|(used, total)| format!("{} / {}", bytes(used), bytes(total)))
                    .unwrap_or_else(|| "—".into()),
                swap_ratio,
                visual.warning,
            ));
        if self.is_darwin() {
            resources = resources
                .child(metric(
                    cx,
                    t(cx, "总内存", "Total memory"),
                    memory.map(|m| bytes(m.total_bytes)).unwrap_or_else(|| "—".into()),
                    None,
                    visual.success,
                ))
                .child(metric(
                    cx,
                    t(cx, "空闲内存", "Free memory"),
                    memory.and_then(|m| m.free_bytes).map(bytes).unwrap_or_else(|| "—".into()),
                    None,
                    visual.success,
                ))
                .child(
                    div()
                        .id("monitor-darwin-memory-note")
                        .test_support()
                        .role(accesskit::Role::Label)
                        .aria_label(t(cx, "空闲页不等于可用内存；已用内存估计不可用。", "Free pages are not available memory; used-memory estimate unavailable."))
                        .text_xs()
                        .text_color(rgb(visual.muted))
                        .whitespace_normal()
                        .child(t(cx, "空闲页不等于可用内存；已用内存估计不可用。", "Free pages are not available memory; used-memory estimate unavailable.")),
                );
        }
        let load = self
            .snapshot
            .as_ref()
            .map(|snapshot| {
                format!(
                    "{:.2} / {:.2} / {:.2}",
                    snapshot.load_average[0], snapshot.load_average[1], snapshot.load_average[2]
                )
            })
            .unwrap_or_else(|| "—".into());
        let uptime = self
            .snapshot
            .as_ref()
            .map(|snapshot| {
                Message::new(
                    format!("{:.1} 小时", snapshot.uptime_seconds / 3600.),
                    format!("{:.1} hours", snapshot.uptime_seconds / 3600.),
                )
                .render(cx)
            })
            .unwrap_or_else(|| "—".into());
        resources = resources
            .child(
                div()
                    .flex()
                    .justify_between()
                    .text_xs()
                    .child(t(cx, "负载 1/5/15", "Load 1/5/15"))
                    .child(load),
            )
            .child(
                div()
                    .flex()
                    .justify_between()
                    .text_xs()
                    .child(t(cx, "运行时间", "Uptime"))
                    .child(uptime),
            );
        let mut networks = section(cx, t(cx, "网络", "Network"), IconName::Network)
            .id("monitor-network")
            .test_support()
            .role(accesskit::Role::Group)
            .aria_label(t(cx, "网络", "Network"));
        if let Some(snapshot) = &self.snapshot {
            for (interface_index, interface) in snapshot.networks.iter().enumerate() {
                let sample = self
                    .rates
                    .networks
                    .iter()
                    .find(|rate| rate.name == interface.name);
                networks = networks.child(
                    div()
                        .id(("monitor-network-interface", interface_index))
                        .test_support()
                        .role(accesskit::Role::Group)
                        .aria_label(interface.name.clone())
                        .min_w_0()
                        .p_2()
                        .rounded(px(components.control_radius))
                        .bg(rgb(visual.surface))
                        .border_1()
                        .border_color(rgb(visual.border))
                        .flex()
                        .flex_col()
                        .gap_1()
                        .text_xs()
                        .child(
                            div()
                                .font_weight(FontWeight::SEMIBOLD)
                                .text_color(rgb(visual.muted))
                                .child(interface.name.clone()),
                        )
                        .child(
                            div()
                                .flex()
                                .flex_wrap()
                                .gap_2()
                                .justify_between()
                                .child(
                                    div()
                                        .flex()
                                        .items_center()
                                        .gap_1()
                                        .text_color(rgb(visual.success))
                                        .child(IconName::ArrowDown)
                                        .child(rate(
                                            sample.and_then(|r| r.received_bytes_per_second),
                                        )),
                                )
                                .child(
                                    div()
                                        .flex()
                                        .items_center()
                                        .gap_1()
                                        .text_color(rgb(visual.accent))
                                        .child(IconName::ArrowUp)
                                        .child(rate(
                                            sample.and_then(|r| r.transmitted_bytes_per_second),
                                        )),
                                ),
                        )
                        .child(
                            div()
                                .text_color(rgb(visual.muted))
                                .whitespace_normal()
                                .child(
                                    Message::new(
                                        format!(
                                            "接收 {} · 发送 {}",
                                            bytes(interface.received_bytes),
                                            bytes(interface.transmitted_bytes)
                                        ),
                                        format!(
                                            "Received {} · Sent {}",
                                            bytes(interface.received_bytes),
                                            bytes(interface.transmitted_bytes)
                                        ),
                                    )
                                    .render(cx),
                                ),
                        ),
                );
            }
        } else {
            networks = networks.child(div().text_xs().text_color(rgb(visual.muted)).child(t(
                cx,
                "暂无网络采样",
                "No network sample",
            )));
        }
        let mut disks = section(
            cx,
            t(cx, "磁盘容量", "Filesystem capacity"),
            IconName::HardDrive,
        )
        .id("monitor-filesystems")
        .test_support()
        .role(accesskit::Role::Group)
        .aria_label(t(cx, "磁盘容量", "Filesystem capacity"));
        if let Some(snapshot) = &self.snapshot {
            for filesystem in &snapshot.filesystems {
                disks = disks
                    .child(metric(
                        cx,
                        &filesystem.mount,
                        format!("{}%", filesystem.used_percent),
                        Some(filesystem.used_percent as f32 / 100.),
                        visual.resource,
                    ))
                    .child(
                        div().text_xs().text_color(rgb(visual.muted)).child(
                            Message::new(
                                format!(
                                    "可用 {} / {}",
                                    bytes(filesystem.available_bytes),
                                    bytes(filesystem.total_bytes)
                                ),
                                format!(
                                    "Free {} / {}",
                                    bytes(filesystem.available_bytes),
                                    bytes(filesystem.total_bytes)
                                ),
                            )
                            .render(cx),
                        ),
                    );
            }
            if snapshot.filesystems.is_empty() {
                let empty = t(
                    cx,
                    if self.capabilities.filesystems.state == CapabilityState::Available {
                        "未发现挂载点"
                    } else {
                        "容量不可用；CPU、内存和网络独立采集"
                    },
                    if self.capabilities.filesystems.state == CapabilityState::Available {
                        "No mounts found"
                    } else {
                        "Capacity unavailable; CPU, memory and network collect independently"
                    },
                );
                disks = disks.child(
                    div()
                        .id("monitor-filesystem-empty")
                        .test_support()
                        .role(accesskit::Role::Label)
                        .aria_label(empty)
                        .text_xs()
                        .text_color(rgb(visual.muted))
                        .child(empty),
                );
            }
        } else {
            disks = disks.child(div().text_xs().text_color(rgb(visual.muted)).child(t(
                cx,
                "暂无磁盘采样",
                "No filesystem sample",
            )));
        }
        let mut processes = section(cx, t(cx, "进程", "Processes"), IconName::Cpu)
            .id("monitor-processes")
            .test_support()
            .role(accesskit::Role::Group)
            .aria_label(t(cx, "进程", "Processes"))
            .child(div().text_xs().text_color(rgb(visual.muted)).child(t(
                cx,
                if self.is_darwin() {
                    "macOS · 按 CPU 排序 · 只读列表，不支持终止"
                } else {
                    "按 CPU 排序 · 生命周期均值"
                },
                if self.is_darwin() {
                    "macOS · CPU order · Read-only list; stopping unavailable"
                } else {
                    "CPU order · lifetime average"
                },
            )));
        processes = processes.child(
            div()
                .flex()
                .gap_1()
                .text_xs()
                .text_color(rgb(visual.muted))
                .child(div().w(px(42.)).child("CPU"))
                .child(div().w(px(42.)).child(t(cx, "内存", "MEM")))
                .child(div().flex_1().child(t(cx, "PID / 命令", "PID / Command"))),
        );
        for process in self
            .processes
            .iter()
            .skip(self.process_page * PROCESS_PAGE_SIZE)
            .take(PROCESS_PAGE_SIZE)
        {
            let selected = process.clone();
            let mut row = div()
                .flex()
                .items_center()
                .gap_1()
                .py_1()
                .border_b_1()
                .border_color(rgb(visual.border))
                .text_xs()
                .child(
                    div()
                        .w(px(42.))
                        .flex_shrink_0()
                        .child(format!("{:.1}%", process.cpu_percent)),
                )
                .child(
                    div()
                        .w(px(42.))
                        .flex_shrink_0()
                        .child(format!("{:.1}%", process.memory_percent)),
                )
                .child(
                    div()
                        .flex_1()
                        .min_w_0()
                        .truncate()
                        .child(format!("{} {}", process.pid, process.command)),
                );
            if process.pid > 1 && self.linux_monitor_actions_available() {
                row = row.child(
                    Button::new(("review-process", process.pid as usize))
                        .text_color(rgb(visual.danger))
                        .ghost()
                        .compact()
                        .rounded(px(crate::design::components(cx).control_radius))
                        .label(t(cx, "终止", "Stop"))
                        .on_click(cx.listener(move |panel, _, _, cx| {
                            if panel.busy || panel.pending.is_some() {
                                return;
                            }
                            panel.set_paused(true, cx);
                            panel.run(Job::Inspect(selected.clone()), cx);
                        })),
                );
            }
            processes = processes.child(row);
        }
        if self.processes.is_empty() {
            processes = processes.child(div().text_xs().text_color(rgb(visual.muted)).child(t(
                cx,
                "暂无进程采样",
                "No process sample",
            )));
        }
        let pages = self.processes.len().div_ceil(PROCESS_PAGE_SIZE).max(1);
        if pages > 1 {
            processes = processes.child(
                div()
                    .flex()
                    .justify_between()
                    .items_center()
                    .child(
                        Button::new("process-page-previous")
                            .icon(IconName::ChevronLeft)
                            .ghost()
                            .compact()
                            .rounded(px(crate::design::components(cx).control_radius))
                            .label(t(cx, "上一页", "Previous"))
                            .on_click(cx.listener(|panel, _, _, cx| {
                                panel.process_page = panel.process_page.saturating_sub(1);
                                cx.notify();
                            })),
                    )
                    .child(
                        div()
                            .text_xs()
                            .child(format!("{} / {pages}", self.process_page + 1)),
                    )
                    .child(
                        Button::new("process-page-next")
                            .icon(IconName::ChevronRight)
                            .ghost()
                            .compact()
                            .rounded(px(crate::design::components(cx).control_radius))
                            .label(t(cx, "下一页", "Next"))
                            .on_click(cx.listener(|panel, _, _, cx| {
                                if (panel.process_page + 1) * PROCESS_PAGE_SIZE
                                    < panel.processes.len()
                                {
                                    panel.process_page += 1;
                                }
                                cx.notify();
                            })),
                    ),
            );
        }
        let content = div()
            .id("monitor-scroll")
            .test_support()
            .flex_1()
            .min_h_0()
            .overflow_y_scroll()
            .px_3()
            .pb_2()
            .child(resources)
            .child(processes)
            .child(self.disk_view(cx))
            .child(networks)
            .child(self.protocol.clone())
            .child(self.path_comparison.clone())
            .child(self.sockets_view(cx))
            .child(disks)
            .child(self.capabilities_view(cx));
        let mut confirmation = None;
        if let Some(identity) = &self.pending {
            let process = identity.process();
            confirmation = Some(div().id("process-confirmation").max_h(px(250.)).overflow_y_scroll().m_2().p_2().bg(rgb(visual.danger_surface)).rounded(px(crate::design::components(cx).control_radius)).border_1().border_color(rgb(visual.danger_border)).flex().flex_col().gap_2()
                .child(div().text_xs().font_weight(FontWeight::SEMIBOLD).child(t(cx, "确认终止进程", "Confirm termination")))
                .child(div().text_xs().child(self.host.clone()))
                .child(div().text_xs().child(format!("PID {} · {}", process.pid, process.user)))
                .child(div().text_xs().child(process.command.clone()))
                .child(div().text_xs().child(t(cx, "将发送 SIGTERM，可能中断任务。不会强制终止或提权；启动时间复核仍有极小的 PID 重用竞争。", "SIGTERM may interrupt work. No force kill or privilege escalation; a narrow PID reuse race remains after the start-time check.")))
                .child(div().flex().gap_1()
                    .child(Button::new("confirm-process-term").icon(IconName::Square).primary().compact().rounded(px(crate::design::components(cx).control_radius)).label(t(cx, "发送 SIGTERM", "Send SIGTERM"))
                        .on_click(cx.listener(|panel, _, _, cx| { if !panel.busy && let Some(identity) = panel.pending.take() { panel.run(Job::Terminate(identity), cx); } })))
                    .child(Button::new("cancel-process-term").ghost().compact().rounded(px(crate::design::components(cx).control_radius)).label(t(cx, "取消", "Cancel"))
                        .on_click(cx.listener(|panel, _, _, cx| { panel.pending = None; panel.status = Message::new("已取消终止，自动刷新仍暂停。", "Termination cancelled. Polling remains paused."); cx.notify(); })))));
        }
        div()
            .id("monitor-panel")
            .test_support()
            .role(accesskit::Role::Group)
            .aria_label(t(cx, "主机监控面板", "Host monitor panel"))
            .w(px(260.))
            .h_full()
            .flex_shrink_0()
            .flex()
            .flex_col()
            .bg(rgb(visual.surface))
            .text_color(rgb(visual.text))
            .child(controls)
            .children(confirmation)
            .child(content)
            .child(
                div()
                    .id("monitor-operation-status")
                    .test_support()
                    .max_h(px(110.))
                    .overflow_y_scroll()
                    .px_3()
                    .py_2()
                    .bg(rgb(visual.canvas))
                    .border_t_1()
                    .border_color(rgb(visual.border))
                    .text_xs()
                    .text_color(rgb(visual.muted))
                    .child(self.status.render(cx)),
            )
    }
}
