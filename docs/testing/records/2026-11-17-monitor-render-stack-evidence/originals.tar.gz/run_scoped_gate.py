"""Validate the UI-only extraction with the original assertions and 2 MiB stack."""
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[2]
environment = dict(os.environ, RUST_MIN_STACK="2097152")
commands = [
    ["cargo", "fmt", "--all", "--check"],
    ["cargo", "clippy", "--workspace", "--all-targets", "--locked", "--offline", "--", "-D", "warnings"],
    [sys.executable, "scripts/check.py", "--policy-only"],
    ["cargo", "test", "--locked", "--offline", "-p", "keelshell-app",
     "--bin", "keelshell-app", "--", "--test-threads=4"],
]
for command in commands:
    print("Running: " + " ".join(command), flush=True)
    subprocess.run(command, cwd=root, env=environment, check=True)
