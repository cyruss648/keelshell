# 远端 Windows 只读监控：下一批最小规划

2026-11-17，限定静态规划。**当前没有 Windows 资源／进程／端口采集分支；建议下一批交付只读资源、进程、TCP LISTEN／UDP bound 列表，保留未知指标和 Linux 动作门槛。** 本次不复审 UDP，不查询或重放父级 CI。

初读 HEAD：`16703293012d798f885e1590f02c348c47e81a10`；最后一次已完成的只读 HEAD 观察：`262a642605ffdb52ef4d6bef075aef17cc910149`。父告知三平台 gate 运行中，本任务未独立验证。已读 AGENTS、HANDOFF、ROADMAP、MONITOR_CAPABILITIES。下列行号来自已读取源码；此前收束观察中相关源码摘要保持，只有父的 HANDOFF／ROADMAP 发生变化，此后不再追查。

## 实际路径与具体缺口

路径相对于仓库根；表内为源码事实及其限制，不是运行结果。

| 精确入口 | 当前行为与阻断 |
| --- | --- |
| `crates/keelshell-session/src/monitor.rs:61、563` | 资源先找绝对路径 uname，再以 POSIX case 分流 Linux／Darwin；没有 Windows bootstrap。脚本失败不能证明目标 OS 或 PowerShell 缺失。 |
| 同文件 `:67、85、605、639` | 进程使用 ps；端口使用 ss／lsof，同样依赖 POSIX shell／uname，没有 Windows collector／parser。 |
| 同文件 `:164、173、233、419` | 平台只有 Linux／Darwin；CPU 固定累计 ticks，load average、进程 user／CPU%／MEM% 必填。Windows 缺失值和不同来源指标不能填零或强行套入。 |
| `crates/keelshell-session/src/monitor/capabilities.rs:128、162、214、233` | 已有连接身份、generation／revision、负缓存与 Transport 例外；可复用。平台／执行器尚无独立观测，现有 POSIX 退出码／英文 stderr 分类不应直接套 Windows。 |
| `crates/keelshell-app/src/monitor.rs:541、658、1474、1713` | 探测／核对／终止依赖当前 Linux 资源样本；此门槛保留，Windows 只读能力不授予动作权限。 |
| `crates/keelshell-app/src/monitor_capabilities.rs:96`；`monitor.rs:1193、1227、1651、1698`；`monitor_history.rs:105` | 文案固定 df／ps、Darwin 内存分支、必填负载／进程百分比及 ticks 趋势比较均需适配，不能只加脚本。 |
| `.github/workflows/ci.yml:81`；`scripts/openssh_interop.py:4、348` | 现有真实 OpenSSH 工装明确只用于 macOS／Linux。Windows runner 编译／单测不证明 Windows 远端采集或 SSH 启动链。 |

## 冻结最小实现合同

1. **平台与执行器独立识别。** 每个认证连接惰性、去重探测，支持先点端口，以及资源失败但进程可读。只有固定完整帧、显式 OS／runtime 身份和成功退出才能建立事实。POSIX 探针不能验证时，可有界尝试固定 `powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand …`，使用 UTF-16LE Base64，不拼接用户内容。初批只覆盖这一个执行器；pwsh／自定义 shell 另列未验。两种探针均失败时是“平台／执行器未确认”，不能猜 Windows、UnsupportedPlatform 或缺命令。
2. **资源只做清楚的指标。** CPU 用 Win32_Processor.LoadPercentage，并标明提供程序上一秒均值；多实例按有效逻辑处理器数加权，聚合为需测试的设计。内存取 CIM 总量／未用量并显式换算，used／available 估计保持未知；运行时间用同次 CIM LocalDateTime／LastBootUpTime 差并标为系统时钟估算。网络显示 .NET GetIPStatistics 实际累计字节，**初批速率保持未知**，避免新增时钟框架。容量只读已就绪固定卷 DriveInfo，区分 TotalFreeSpace 与 AvailableFreeSpace；容量失败不丢有效核心样本。load／swap／iowait／disk I/O 未实现则未知。
3. **进程／端口。** Get-Process 取 PID、ProcessName、可读 WorkingSet64，按 PID 排序；owner／CPU%／MEM% 未取得则未知，不用 IncludeUserName、不默认读取命令行、不提权。Get-NetTCPConnection 只保留 Listen；Get-NetUDPEndpoint 只列绑定的本地端点，UDP peer 未提供则未知。校验 IPv4／IPv6／端口／PID；不标连通或健康。初批沿用一个 Sockets 能力，TCP／UDP 任一失败不发布为完整成功；只有完整成功的显式空数组才可显示账户可见范围内“未观察到”。
4. **必要类型调整。** 增加 Windows；CPU 区分累计 ticks／报告百分比；load average 可缺失；进程 user／CPU%／MEM% 可缺失，增加可缺失 working-set bytes。保留 Linux／Darwin 指标来源及语义；不伪造 Windows ticks，不全仓改名 LinuxMonitor。历史趋势同步支持 gauge 的首样本／断段，MCP 沿用可缺失字段。
5. **严格帧与解析。** probe／resources／processes／sockets 固定版本、操作、单位及字段白名单；JSON 显式数组与行数，Console UTF-8，宽整数用规范十进制字符串。拒绝重复键／身份、溢出、坏单位／schema、缺项、非有限值、杂文、截断、非成功或缺失退出码；只接受约定的 CRLF／LF。空数组不能变成 null／单对象。合并输出沿用 2 MiB、进程 20,000；端口约定 20,000、接口 256、卷 512，并限字段长度。超限拒绝，不静默截断。编码后命令长度须过实际 shell 边界测试，不能假定大 EncodedCommand 可用。
6. **能力缓存。** 四项能力沿用原缓存；平台／runtime 观测加入同一连接权威和代次。clone 共享，新连接全新；显式重检同时清平台与能力观测。普通刷新跳过确认负缓存；Transport／超时不判命令不存在。Windows 使用固定类型化错误，不能依赖本地化 stderr 猜原因；证据不足保持未知。渲染、主题／语言切换与分页不发 SSH。

## 取消、迟到与 UI

复用 `app/monitor.rs:206、236、277、673` 的暂停／退役、sample generation、逐命令取消和有界在途完成，以及 `monitor_capabilities.rs:26` 的报告权威校验。新探针／collector 每次发送前也检查取消；旧代次不得更新平台缓存、能力、样本、趋势、状态或 MCP sample ID。沿用各自真实采样时间及过期规则，覆盖暂停 ABA、重检时旧探针、新连接与迟到报告；拆分 exec 不能绕过检查。

`session/ssh.rs:711` 已限制输出和 open／exec 超时、关闭通道；**关闭通道不证明远端 PowerShell 已终止**。隔离工装必须记录本批拥有进程的实际终态；不能证明时保留 UNKNOWN／HOLD，不能签为远端已回收。

UI 用既有 registry／palette／组件 token 与缓存分页，能力名称去掉固定 df／ps。补“Windows · 只读 / Windows · Read-only”“工作集 / Working set”、未知／陈旧年龄及指标来源说明；Windows 无 Probe／Inspect／Stop 可触发入口。中文／英文 × Frost／Graphite／Lavender × Light／Dark／System，覆盖宽／紧凑窗口、Tab／Shift+Tab、AX 标签和重检／暂停／分页可达性。headless 仅签模型／几何范围，原生另验。

## 最小写集与顺序（本次均未执行）

| 写集 | 下一批文件与交付 |
| --- | --- |
| A：session／合同 | 改 `crates/keelshell-session/src/monitor.rs`、`monitor/capabilities.rs`；新增 `monitor/platform.rs`、`monitor/windows.rs`、`monitor/windows/{probe,resources,processes,sockets}.ps1` 及 parser／cache tests。交付识别、collector、严格解析、类型、缓存与 rustdoc；按类型变化适配 Darwin 构造点及相关测试。 |
| B：UI，可在 A 合同冻结后并行 | 改 `crates/keelshell-app/src/monitor.rs`、`monitor_capabilities.rs`、`monitor_history.rs`、`monitor_tests.rs`；新增 `monitor_tests/windows.rs`。交付双语三主题、未知／来源、gauge 趋势、动作门槛、缓存分页及迟到隔离。 |
| C：真实隔离测试，可并行 | 新增 `crates/keelshell-session/tests/windows_monitor_interop.rs`、`scripts/windows_monitor_lab.py` 及工装单测；在现有 CI 增 Windows 专项或独立 workflow。实际 Windows API 与 Windows OpenSSH 分别留证，不直接取消 Unix 工装的平台拒绝。 |
| D：父集成／收口 | 新 ADR（编号由父分配）、MONITOR_CAPABILITIES、新 testing record、ROADMAP／HANDOFF；改变 README 声明时中英同步。复核实际写集、新非作者审查后冻结输入，由父按共享构建合同做一次最终门禁。已有 base64／serde／serde_json 可复用，初案不加 registry 依赖。 |

先冻结 A 的公共类型／协议，再平行 A／B／C；每组按归属提交，公共 facade 由 A 集成。**G0 环境确认先于真实 SSH 交付承诺**。

## 可执行验收清单

- [ ] **G0 前置现场**：自有可销毁 Windows VM／独立实例；记录精确 OS build／架构、OpenSSH 版本、默认 shell、PowerShell edition／version／语言模式、模块／API 和非管理员账户权限。测试认证材料仅由后续工装临时新建，不读取开发者凭据。
- [ ] **G1 纯解析**：合法／空／单元素数组、Unicode、CRLF、IPv4／IPv6、重复／超限／坏帧／坏单位／大整数／缺退出码；未知不为零，CPU 秒不为百分比，CIM 未用量不推 used。模拟 SSH 仅算模型／协议测试。
- [ ] **G2 缓存／归属**：各能力分别失败／恢复、负缓存命令计数不增、显式重检、Transport 重试、先点端口、clone／新连接、暂停 ABA／退役／探针迟到，以及重绘／语言／主题／分页零命令增量。复用现有 `monitor_tests/capabilities.rs:156、207、537` 的方向，增加 Windows 路由例。
- [ ] **G3 真 Windows API**：在隔离 Windows 执行实际生产 PS collector；自建短命进程、IPv4／IPv6 TCP listener、已连接 TCP 对照、UDP bound socket，核对自有 PID／端点与独立 API 读数。缺 IPv6 等条件单列未验；注入失败仅发生于 fixture，不能修改系统命令／全局 PATH／权限，注入与真实成功分签。
- [ ] **G4 真 Windows SSH**：临时配置、高端口、独立 host pin／authorized key 的自有 OpenSSH；不改现有服务／注册表／防火墙。隔离启动／认证权限不足则 HOLD，转预置牺牲 VM；直调 PS、Rust loopback 或 Linux 容器不能代签。
- [ ] **G5 清理与取消**：记录自有 sshd／PS／fixture 身份、终态、socket 释放及私有目录清理；取消不发下一命令，迟到不发布；无远端退出证明保持 UNKNOWN／HOLD。
- [ ] **G6 分层验收**：后续父执行 fmt／严格 Clippy／相关专项／依赖策略及冻结后的最终工程 gate，保存真实库存、逐名结果与退出码；实际 GPUI 包另测中英三主题／尺寸／键盘／AX。未测 OS／架构、安装／签名／发行继续未验。

**尚未知／外部依赖：默认 OpenSSH shell、PowerShell 的存在／可调用性／版本、模块／权限、隔离 Windows sshd 启动与认证条件、真实 Windows 远端全部未验。** 建议先测观察到的 Windows PowerShell 5.1；没有据此承诺任何 Windows OS 版本支持。支持声明最多覆盖后续实际验证的精确组合。

## 官方事实与回执边界

仅查询 Microsoft 一手文档，HTTP 状态、最终 URL、正文 SHA 及检索项见回执，未执行文档命令；页面描述不证明目标可用。

- [OpenSSH 配置](https://learn.microsoft.com/en-us/windows-server/administration/openssh/openssh-server-configuration)（c036）：默认 shell 可配置，现场仍未知；[powershell.exe 5.1](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_powershell_exe?view=powershell-5.1)（c037）：UTF-16LE EncodedCommand 与启动参数。
- [Win32_OperatingSystem](https://learn.microsoft.com/en-us/windows/win32/cimwin32prov/win32-operatingsystem)／[Win32_Processor](https://learn.microsoft.com/en-us/windows/win32/cimwin32prov/win32-processor)（c038–039）：内存单位／CPU 上一秒均值；[Get-Process](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.management/get-process?view=powershell-5.1)（c042）：CPU(s) 是累计秒、IncludeUserName 要求提升权限。聚合与字段映射属于待测试设计。
- [Get-NetTCPConnection](https://learn.microsoft.com/en-us/powershell/module/nettcpip/get-nettcpconnection)／[Get-NetUDPEndpoint](https://learn.microsoft.com/en-us/powershell/module/nettcpip/get-netudpendpoint)（c040–041）：查询接口；[DriveInfo.AvailableFreeSpace](https://learn.microsoft.com/en-us/dotnet/api/system.io.driveinfo.availablefreespace)（c044）：考虑配额；[GetIPStatistics](https://learn.microsoft.com/en-us/dotnet/api/system.net.networkinformation.networkinterface.getipstatistics?view=netframework-4.8.1)（c059／063／071）：实际接口累计字节。均未验证目标可用。

[command-receipts.jsonl](command-receipts.jsonl) 保留 argv／行段、退出码和摘要，包括 rg 未命中 exit 1、误猜 workflow 文件名 exit 2、官方 URL 404／操作 exit 1；失败不改签。初次合并读取只捕获整体 exit 0，输出截断，已用后续行段补读；不声称每个初始子命令均有独立退出码。web 工具未给可用内容，文档事实来自直接官方 HTTP 读取。

**本次 Cargo／测试／应用／容器／CI 查询／native 操作均为 0。未访问 target 或凭据，未改生产源码、现有文档或 Git；仅在指定 work 目录写报告及回执。此报告不是实现完成、合并批准或 native 验收。**
