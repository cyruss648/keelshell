"""Record raw native captures; do not transcode or inspect private runtime data."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
rows = []
for image in sorted(BASE.glob("*.png")):
    metadata = subprocess.check_output(
        ["file", "-b", str(image)], text=True, timeout=5,
    ).strip()
    dimensions = re.search(r"\bprecision \d+, (\d+)x(\d+)\b", metadata)
    assert metadata.startswith("JPEG image data") and dimensions, metadata
    ax = image.with_suffix(".ax.txt")
    assert ax.is_file()
    rows.append({
        "image": image.name, "image_bytes": image.stat().st_size,
        "image_sha256": hashlib.sha256(image.read_bytes()).hexdigest(),
        "actual_format": "JPEG", "dimensions": list(map(int, dimensions.groups())),
        "file_metadata": metadata,
        "ax": ax.name, "ax_bytes": ax.stat().st_size,
        "ax_sha256": hashlib.sha256(ax.read_bytes()).hexdigest(),
    })
assert len(rows) == 10
assert all(row["dimensions"] == [2880, 1866] for row in rows)
shutil.copyfile(
    ROOT / "work/windows-monitor-delivery-20261117/package-r2/package-manifest.json",
    BASE / "package-manifest.json",
)
value = {
    "recorded_utc": datetime.now(timezone.utc).isoformat(),
    "scope": "one normal macOS arm64 window; empty isolated workspace; toolbar and recommended theme subset only",
    "package_source": "5d2df2fc5ac8566fe11182b7f4337076296dfa54",
    "current_source": "660e90d6f7c7111853db7b73f4ca2344f633700d",
    "captures": rows,
    "observed_themes": [
        "Frost System dark zh/en", "Frost Light en", "Graphite Dark en",
        "Lavender Light en/zh",
    ],
    "verified_visible_toolbar_subset": [
        "Three recommended English themes have visible right-side appearance/language controls",
        "Appearance opens and theme selection applies",
        "Language changes Chinese/English",
        "Close review shows 0 SSH and 0 file drafts; confirmed close; original owner exits 0",
    ],
    "compact_window_acceptance": False, "original_full_toolbar_p2_closed": False,
    "failures_and_limits": [
        "First Done click used invalid ID82 after full AX capture; no action happened. Fresh ID12 succeeded.",
        "Ctrl+Command+F and raw-coordinate bottom-right drag did not establish a different size; compact size is unverified.",
        "Post-close AX retrieval auto-launched another same-path process outside the isolated owner. That tree is excluded. PID2486 was identity-checked and SIGTERM-terminated; its exit code/reap is not asserted.",
        "Cleanup did not read/write/delete global application data. App startup effects on global data were not audited; the cleanup receipt global_application_data_untouched field describes cleanup file operations only.",
        "First metadata utility failed because PIL was unavailable; system file reads supplied format/dimensions instead. No image edits or package installs.",
        "The first file-output parser mistook 72x72 DPI for pixels; its invalid observation is preserved separately. The corrected parser reads the precision field and requires actual 2880x1866 pixels.",
    ],
    "gui_ssh_or_model_send_actions": 0, "installed": False,
    "native_full_matrix_acceptance": False, "windows_linux_gui_acceptance": False,
    "image_bytes_modified": False,
}
with (BASE / "observation.json").open("x") as output:
    json.dump(value, output, ensure_ascii=False, indent=2)
    output.write("\n")
print(json.dumps({
    "captures": len(rows), "actual_formats": sorted({row["actual_format"] for row in rows}),
    "dimensions": sorted({tuple(row["dimensions"]) for row in rows}),
    "original_isolated_exit": json.loads((BASE / "native-receipt.json").read_text())["controller_exit"],
    "compact_acceptance": False,
}))
