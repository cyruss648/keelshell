"""Run the previously verified normal package with isolated, disposable state."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "scripts"))
import windows_native_crash as owned

program = ROOT / "work/windows-monitor-delivery-20261117/package-r2/KeelShell.app/Contents/MacOS/keelshell-app"
runtime = BASE / "runtime"
runtime.mkdir(exist_ok=False)
binding = json.loads((BASE / "package-binding.json").read_text())
expected = next(row["sha256"] for row in binding["package_files"]
                if row["path"].endswith("/keelshell-app"))
assert hashlib.sha256(program.read_bytes()).hexdigest() == expected


class NativeOwner(owned.PosixOwner):
    def spawn(self, command, cwd, env, deadline, merge_error=False):
        process = super().spawn(command, cwd, env, deadline, merge_error)
        identity = subprocess.run(
            ["ps", "-p", str(process.pid), "-o", "pid=,pgid=,lstart=,command="],
            capture_output=True, text=True, timeout=5, check=True,
        )
        (BASE / "native-process.json").write_text(json.dumps({
            "launched_utc": datetime.now(timezone.utc).isoformat(),
            "pid": process.pid, "identity": identity.stdout.strip(),
            "executable_sha256": expected, "package_source": binding["source"],
            "runtime": str(runtime.relative_to(ROOT)), "installed": False,
        }, indent=2) + "\n")
        return process


started = time.monotonic()
environment = dict(os.environ, KEELSHELL_DATA_DIR=str(runtime))
result, receipt = owned.run_owned(
    [str(program)], ROOT, environment, owned.Deadline(time.time() + 1800),
    owner=NativeOwner(),
)
(BASE / "native.stdout").write_text(result.stdout)
(BASE / "native.stderr").write_text(result.stderr)
receipt["seconds"] = time.monotonic() - started
receipt["package_source"] = binding["source"]
receipt["executable_sha256"] = expected
(BASE / "native-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt))
sys.exit(result.returncode)
