范围受限结论：**APPROVE_SCOPED_NATIVE_TOOLBAR_EVIDENCE / ship_observed_subset_only**。本次独立、非作者复核未发现所检工具栏子集的新产品问题，新增 P0=0、P1=0、P2=0、P3=0。旧 P2 保留 1 项的未验收余集，不能整体关闭；紧凑窗口及完整 native finish 均为 HOLD。

已按顺序阅读本 checkout 的 AGENTS.md、docs/HANDOFF.md、docs/design/HALLMARK_NATIVE.md，以及旧记录 docs/testing/records/2026-11-16-kit010-native-ci.md。工具栏要求见 HALLMARK_NATIVE.md:55–64；旧裁切、表单与矩阵边界见旧记录:74–80，旧最终 P2=1 见:109–111。通用旧记忆只用于只读及范围表达习惯，实际裁决来自本次提供的原件。

包为复用的正常 macOS arm64 包，源码 **5d2df2fc5ac8566fe11182b7f4337076296dfa54**，应用 SHA-256 **127526280ffc1409abe9f6519c0f8d5818c4fedf66a22468737bd8e0217e35bf**。package-binding.json:2–4、package-manifest.json 的 build.commit、原进程/回执均一致。不是当前 660e90d6 的新构建。独立复核该包五个文件及 manifest 摘要；固定 660e90d6f7c7111853db7b73f4ca2344f633700d 与包源码间共 35 个变更路径，与绑定记录逐项一致，441 个生产 Rust/Cargo 文件的 Git blob 完全相同。唯一新增 Rust 文件位于 session/tests/windows_openssh_monitor.rs。未运行 Cargo、产品测试或构建。

复核范围为一份实际捕获的单窗、空连接库与无活动 SSH 工作区。新独立目录由 run_native.py:17–22 的 exist_ok=False 及 :41–45 的 KEELSHELL_DATA_DIR 声明支持；未读取 runtime 内容。全部正常工作区 AX 报告窗口计数 1，连接库 0/0。不存在真实已连接或长主机名上下文，本次不检验这些情况。

我实际通过 functions.view_image 打开全部 01–10 原图，包括明确要求的 04/05/06 和 10。未启动或操作 GUI，未重新捕获、转换、裁剪或改写图片。下表的 PASS 只对应所述画面；07/08 的 HOLD 是尺寸未证实，不能视为产品失败。

| 步骤 | 观察 | 健康状态及结论 |
| --- | --- | --- |
| 01 | Frost System 中文，所见为深色 | PASS：右设置组及中/EN 入口在视口内，0/0 连接。 |
| 02 | Frost System 英文，所见为深色 | PASS：右设置组及 EN/中 入口可见。 |
| 03 | Frost Light 英文外观页 | PASS：三家族卡片、Light/Dark/Light 推荐及 Done 均可见；当前 AX 的 Done 为 12。 |
| 04 | Frost Light 英文工作区 | PASS：右侧设置与语言入口完整，当前空上下文文字可读。 |
| 05 | Graphite Dark 英文工作区 | PASS：右侧入口完整，顺序与 04 一致。 |
| 06 | Lavender Light 英文工作区 | PASS：右侧入口完整，顺序与 04/05 一致。 |
| 07 | Lavender 快捷键尺寸尝试 | HOLD：未证实 Ctrl+Cmd+F 改变尺寸。 |
| 08 | Lavender raw 边角拖动结果 | HOLD：未证实拖动改变尺寸。 |
| 09 | Lavender Light 中文工作区 | PASS：右设置组及中/EN 入口可见，中文 AX 完整。 |
| 10 | 中文关闭窗口审核 | PASS：0 SSH、0 文件草稿快照、风险说明和取消/确认按钮可见；关闭动作不由静态图独立证明。 |

04/05/06 的右侧凭据库、关于/更新、配置备份恢复、主题外观与 EN/中 依次保留在边界内，没有所检空态窗口的右侧裁切。对应 AX 三份全字节相等，均为 8b1b751c95062d80f38197bb60f909a075a825577f31b2b0eda69ae6e983de29；各自 :18–23 包含 Workspace settings、Credential vault、About / updates、Configuration backup and recovery、Themes and appearance、Switch language: Chinese or English。只证明这些画面的可见及所述语义，不把静态 AX 等同点击、焦点、VoiceOver 或完整辅助技术验收。

10 原图清楚显示窗口短标识 350a4d2c、0 SSH、0 文件草稿快照，正文说明确认后丢弃未保存草稿、撤销审核、关闭 SSH 且不自动保存布局；两个底部按钮完整。10-close-review.ax.txt:3–9 证明 active-modal 和取消/确认关闭按钮；该 AX 文本不含风险正文及计数，不能签署关闭对话框完整辅助技术表现。本次没有新增产品问题结论，也没有代签该缺口。

原隔离 PID 92747 的身份及启动时间为 2026-11-17 09:43:52 +08:00；native-receipt.json:2–15 记录 observed_exit=0、controller_exit=0、direct_reaped=true、active_processes=0、pipes_drained=true、无超时及 349.9020121250069 秒。super+q 后经 GUI 确认的动作来自任务陈述及 observation.json，10 是确认前画面；退出回执独立支持原运行终态，复核者没有重放操作或现场等待进程。

关闭后 getAX 意外启动的同包 PID 2486（2026-11-17 09:49:42 +08:00）与原隔离运行严格分开。post-close-processes.json:2–7 明确排除该树；它没有进入 01–10 图像/AX 接受集。父的 post-close-cleanup.json:3–11 记录按路径/启动时间核对后 SIGTERM 及 terminated=true，direct_reaped=null；只作为补充回执阅读，未独立现场核对，也未等待此清理。原隔离 exit0 不延伸到该进程。global_application_data_untouched 仅描述清理文件操作，非隔离启动对全局数据的影响未审计。

失败原件及未证实操作保持：旧 ID82 被拒绝、刷新后新 ID12 成功，属于工装操作失败，不计为产品 P2。来源为任务陈述和 observation.json 的 failures_and_limits；当前 03 AX:14 独立确认 ID12，原拒绝动作返回未单独存在于此证据目录，不伪造。Ctrl+Cmd+F 与 raw 拖动均未证实尺寸变化；06/07/08 AX 全字节相等，画面没有可证实的缩窗布局变化。源图同为 2880×1866 只说明栅格尺寸，不能推导逻辑窗口尺寸或紧凑验收成功。

所有 .png 扩展名原件真实均为 JPEG/JFIF，SOI=FFD8，像素 2880×1866。系统 file 输出与独立 stdlib JPEG SOF 解析一致，view_image 显示预览为 1975×1280，不作为原图尺寸。父的 observation-metadata-r1-invalid.json 把 72×72 DPI 误当像素，已原样保留且明确排除；PIL 缺失及错误解析均为工装失败，不覆盖或改写。修正 observation.json 的十对大小、SHA、格式及尺寸逐项与原件相等。

| 原图 | 实际格式/像素 | SHA-256 |
| --- | --- | --- |
| 01-frost-zh-initial.png | JPEG / 2880×1866 | eee078ff45f668f0f5c103091093a67becfe1a8064dbb51156590706eae72828 |
| 02-frost-en-system.png | JPEG / 2880×1866 | d4b533aa66bbfa3ad0eb7ef319530b0c1ee67da802b3d3113b654546548475cb |
| 03-frost-light-en-appearance.png | JPEG / 2880×1866 | d9d8ab332a938689fdb00209ef327f8881791d6b82b056401c214ca570d250b6 |
| 04-frost-light-en-workspace.png | JPEG / 2880×1866 | 74b8d59e4696f875ef42f3fe3008206e2e3c83bed5082bdce98e41c8beba5f97 |
| 05-graphite-dark-en-workspace.png | JPEG / 2880×1866 | 780070cf6b7d26e070c7a1ce75b616c045f7eccb19cef0135900640d1f535848 |
| 06-lavender-light-en-workspace.png | JPEG / 2880×1866 | 731f77a92ba130d0202bc0b253637fca0671f63cb21ff209ba53305ec478bf00 |
| 07-lavender-window-geometry-attempt.png | JPEG / 2880×1866 | 5d23cea11cf31e7ab5e1b799f591d20491675858f1155dfb4ac5bd446ed02f7c |
| 08-lavender-drag-result.png | JPEG / 2880×1866 | d46a29c428a1450c6921b7b4589c49312baad5d114ebaa22f0734129fb7fbd37 |
| 09-lavender-zh-workspace.png | JPEG / 2880×1866 | 39adbd60c7b5745ca1b792442281d4b3120b085876e7035ab0f4d8fe400dba95 |
| 10-close-review.png | JPEG / 2880×1866 | d2e70cfc5976954217377069b0e5a3dbb909851636628dd44e0d77960ab5eae0 |

离线复算实际结果为 **267/267 PASS、0 FAIL**，重算 38 个输入文件，含全部 10 图/10 AX、绑定/进程/终态、工装记录、原包五文件及 manifest。执行回执为 exit 0、direct_reaped=true、pipes_drained=true、0.177136s；详细检查及命令见 verification.json、execution-receipt.json。自动脚本仅复算文件及字段，不自动复算人的视觉判断。

复算命令（从 checkout 执行，只写本评审目录）：

```sh
python3 -B work/native-toolbar-review-20261117/run_verify.py
```

旧 P2 不能整体关闭：本次没有保存/实时 SSH 连接、长连接上下文、其他尺寸、连接编辑下部认证控件/滚动，或完整主题×明暗×语言×尺寸矩阵。紧凑窗口、完整键盘/焦点/悬停、IME/VoiceOver、多窗口/重启、Windows/Linux 原生桌面、真实 Windows CI/SSH、发行安装/签名/公证保持各自未核验状态；不从本结论推导完整 native finish。

复核动作计数：view_image=10；Cargo=0，产品测试=0，构建=0，GUI 操作=0，联网=0，Git 修改=0，源码/项目文档/target 修改=0，委派=0，新 chat/worktree=0。所有产物仅在 work/native-toolbar-review-20261117/。decision.json 与 summary.json 已包含完整裁决和边界，父无需读取本正文。

以下直接引用实际查看的四张原图，不产生派生图或替换原件。

![步骤 04 实际原图](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/native-toolbar-20261117/04-frost-light-en-workspace.png)

![步骤 05 实际原图](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/native-toolbar-20261117/05-graphite-dark-en-workspace.png)

![步骤 06 实际原图](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/native-toolbar-20261117/06-lavender-light-en-workspace.png)

![步骤 10 实际原图](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/native-toolbar-20261117/10-close-review.png)

