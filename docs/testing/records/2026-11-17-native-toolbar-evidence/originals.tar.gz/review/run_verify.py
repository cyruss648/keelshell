#!/usr/bin/env python3
"""Run the offline evidence verifier and persist its actual execution receipt."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

base = Path(__file__).resolve().parent
if base.name != "native-toolbar-review-20261117":
    raise SystemExit("unexpected output directory")
command = [sys.executable, "-B", str(base / "verify.py")]
started = datetime.now(timezone.utc).isoformat()
clock = time.monotonic()
process = subprocess.Popen(
    command, cwd=base.parents[1],
    env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1", GIT_OPTIONAL_LOCKS="0"),
    stdout=subprocess.PIPE, stderr=subprocess.PIPE,
)
timed_out = False
try:
    stdout, stderr = process.communicate(timeout=60)
except subprocess.TimeoutExpired:
    timed_out = True
    process.kill()
    stdout, stderr = process.communicate(timeout=10)
elapsed = time.monotonic() - clock
(base / "verification.json").write_bytes(stdout)
(base / "verification.stderr").write_bytes(stderr)
payload = json.loads(stdout) if process.returncode == 0 else {}
receipt = {
    "schema_version": 1, "command": command,
    "started_utc": started, "completed_utc": datetime.now(timezone.utc).isoformat(),
    "pid": process.pid, "observed_exit": process.returncode,
    "direct_reaped": process.poll() is not None,
    "pipes_drained": True, "timed_out": timed_out, "seconds": elapsed,
    "stdout_file": "verification.json", "stderr_file": "verification.stderr",
    "stdout_sha256": hashlib.sha256(stdout).hexdigest(),
    "stderr_sha256": hashlib.sha256(stderr).hexdigest(),
    "checks_run": payload.get("checks_run"),
    "checks_passed": payload.get("checks_passed"),
    "checks_failed": payload.get("checks_failed"),
    "verifier_sha256": hashlib.sha256((base / "verify.py").read_bytes()).hexdigest(),
    "inputs_sha256": hashlib.sha256((base / "inputs.json").read_bytes()).hexdigest(),
    "decision_sha256": hashlib.sha256((base / "decision.json").read_bytes()).hexdigest(),
    "scope": "offline evidence recomputation; no native action replay or product tests",
}
(base / "execution-receipt.json").write_text(
    json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
)
print(json.dumps(receipt, ensure_ascii=False, indent=2))
sys.exit(process.returncode)
