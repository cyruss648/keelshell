#!/usr/bin/env python3
"""Recheck supplied evidence offline; print JSON and never write input files.

This verifies hashes, JPEG dimensions, AX labels, package/source binding and
the recorded isolated process receipt. It does not reproduce native actions,
reassess the human visual verdict, run product tests, or inspect live apps.
"""

import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
EVIDENCE = ROOT / "work/native-toolbar-20261117"
PACKAGE = ROOT / "work/windows-monitor-delivery-20261117/package-r2"
SOURCE = "5d2df2fc5ac8566fe11182b7f4337076296dfa54"
CURRENT = "660e90d6f7c7111853db7b73f4ca2344f633700d"
APP_SHA = "127526280ffc1409abe9f6519c0f8d5818c4fedf66a22468737bd8e0217e35bf"
checks = []
errors = []


def check(name, condition):
    checks.append({"name": name, "passed": bool(condition)})
    if not condition:
        errors.append(name)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def git(*args):
    result = subprocess.run(
        ["git", "--no-optional-locks", "-c", "core.fsmonitor=false", *args],
        cwd=ROOT,
        env=dict(os.environ, GIT_OPTIONAL_LOCKS="0", GIT_PAGER="cat"),
        capture_output=True,
        timeout=30,
        check=True,
    )
    return result.stdout


def production_tree(commit):
    result = {}
    for record in git(
        "ls-tree", "-r", "-z", commit, "--", "crates", "Cargo.toml", "Cargo.lock"
    ).split(b"\0"):
        if not record:
            continue
        metadata, raw_path = record.split(b"\t", 1)
        path = raw_path.decode()
        if (
            path.endswith(".rs") and "/tests/" not in path
        ) or Path(path).name in ("Cargo.toml", "Cargo.lock"):
            result[path] = metadata.decode()
    return result


def jpeg_dimensions(data):
    if not data.startswith(b"\xff\xd8") or not data.endswith(b"\xff\xd9"):
        raise ValueError("not a complete JPEG SOI/EOI stream")
    offset = 2
    sof = {0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7,
           0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF}
    while offset < len(data):
        if data[offset] != 0xFF:
            raise ValueError("invalid JPEG segment boundary")
        while data[offset] == 0xFF:
            offset += 1
        marker = data[offset]
        offset += 1
        if marker in (0xD8, 0x01) or 0xD0 <= marker <= 0xD7:
            continue
        length = struct.unpack_from(">H", data, offset)[0]
        if length < 2 or offset + length > len(data):
            raise ValueError("invalid JPEG segment length")
        if marker in sof:
            height, width = struct.unpack_from(">HH", data, offset + 3)
            return width, height
        if marker in (0xDA, 0xD9):
            break
        offset += length
    raise ValueError("JPEG dimensions missing")


def main():
    expected = load(BASE / "inputs.json")
    for row in expected["files"]:
        path = (ROOT / row["path"]).resolve()
        check("input stays under checkout: " + row["path"], path.is_relative_to(ROOT))
        data = path.read_bytes()
        check("input bytes: " + row["path"], len(data) == row["bytes"])
        check("input SHA256: " + row["path"], sha256(data) == row["sha256"])

    images = sorted(EVIDENCE.glob("*.png"))
    axes = sorted(EVIDENCE.glob("*.ax.txt"))
    expected_stems = expected["image_stems"]
    check("exact 01..10 image inventory",
          [p.stem for p in images] == expected_stems)
    check("exact 01..10 AX inventory",
          [p.name.removesuffix(".ax.txt") for p in axes] == expected_stems)
    image_rows = []
    for path in images:
        data = path.read_bytes()
        width, height = jpeg_dimensions(data)
        check("JPEG 2880x1866: " + path.name, (width, height) == (2880, 1866))
        check("not PNG bytes: " + path.name, not data.startswith(b"\x89PNG\r\n\x1a\n"))
        image_rows.append({
            "file": path.name, "bytes": len(data), "format": "JPEG",
            "width": width, "height": height, "sha256": sha256(data),
        })
    observation = load(EVIDENCE / "observation.json")
    captures = observation["captures"]
    check("parent observation exact capture inventory",
          [row["image"] for row in captures] == [p.name for p in images])
    for row, image in zip(captures, image_rows, strict=True):
        ax_path = EVIDENCE / row["ax"]
        ax_data = ax_path.read_bytes()
        check("parent observation independently rechecked: " + row["image"],
              row["actual_format"] == image["format"]
              and row["dimensions"] == [image["width"], image["height"]]
              and row["image_bytes"] == image["bytes"]
              and row["image_sha256"] == image["sha256"]
              and row["ax_bytes"] == len(ax_data)
              and row["ax_sha256"] == sha256(ax_data))
    invalid = load(EVIDENCE / "observation-metadata-r1-invalid.json")
    check("invalid DPI-as-pixels metadata preserved, not accepted",
          len(invalid["captures"]) == 10
          and all(row["dimensions"] == [72, 72] for row in invalid["captures"])
          and all(row["dimensions"] == [2880, 1866] for row in captures))

    texts = {p.name[:2]: p.read_text(encoding="utf-8") for p in axes}
    english = [
        "Workspace windows 1", "Current workspace context",
        "Workspace settings", "Credential vault", "About / updates",
        "Configuration backup and recovery", "Themes and appearance",
        "Switch language: Chinese or English", "0 / 0 profiles",
        "No saved profiles",
    ]
    for number in ("02", "04", "05", "06", "07", "08"):
        for label in english:
            check(number + " AX label: " + label, label in texts[number])
    check("04/05/06 complete AX byte identity",
          texts["04"] == texts["05"] == texts["06"])
    check("06/07/08 complete AX byte identity",
          texts["06"] == texts["07"] == texts["08"])
    for number in ("01", "09"):
        for label in ("工作区窗口，1", "工作区设置", "主题与外观",
                      "切换语言：中文或英文", "0 / 0 个连接"):
            check(number + " AX label: " + label, label in texts[number])
    check("01/09 complete AX byte identity", texts["01"] == texts["09"])
    for label in ("Frost", "Graphite", "Lavender", "12 按钮 Done"):
        check("03 appearance AX: " + label, label in texts["03"])
    for label in ("对话框 关闭窗口审核", "ID: keelshell.active-modal",
                  "6 按钮 取消", "7 按钮 确认关闭"):
        check("10 close AX: " + label, label in texts["10"])

    binding = load(EVIDENCE / "package-binding.json")
    manifest_path = PACKAGE / "package-manifest.json"
    manifest = load(manifest_path)
    process = load(EVIDENCE / "native-process.json")
    receipt = load(EVIDENCE / "native-receipt.json")
    check("binding source/current",
          binding["source"] == SOURCE and binding["current_source"] == CURRENT)
    check("manifest hash binding",
          sha256(manifest_path.read_bytes()) == binding["package_manifest_sha256"])
    check("evidence manifest copy equals original",
          (EVIDENCE / "package-manifest.json").read_bytes() == manifest_path.read_bytes())
    check("manifest source is old build", manifest["build"]["commit"] == SOURCE)
    check("manifest app SHA256", manifest["binary_sha256"] == APP_SHA)
    check("manifest is macOS arm64",
          manifest["platform"] == "macos" and manifest["target"] == "aarch64-apple-darwin")
    check("exact manifest file inventory",
          set(manifest["files"]) == {row["path"] for row in binding["package_files"]})
    for row in binding["package_files"]:
        data = (PACKAGE / row["path"]).read_bytes()
        check("package bytes: " + row["path"], len(data) == row["bytes"])
        check("package SHA256: " + row["path"],
              sha256(data) == row["sha256"] == manifest["files"][row["path"]])
    check("recorded non-installation",
          not binding["installed"] and not process["installed"] and not manifest["installed"])
    check("recorded zero customer connections", binding["new_customer_connections"] == 0)
    for label, record in (("process", process), ("receipt", receipt)):
        check(label + " exact source/hash",
              record["package_source"] == SOURCE and record["executable_sha256"] == APP_SHA)
    check("original isolated process identity",
          process["pid"] == 92747 and "Tue Nov 17 09:43:52 2026" in process["identity"]
          and process["identity"].endswith(str(PACKAGE / "KeelShell.app/Contents/MacOS/keelshell-app")))
    check("original isolated data directory",
          process["runtime"] == "work/native-toolbar-20261117/runtime")
    launcher = (EVIDENCE / "run_native.py").read_text()
    check("launcher declares new isolated state",
          "runtime.mkdir(exist_ok=False)" in launcher
          and "KEELSHELL_DATA_DIR=str(runtime)" in launcher)
    check("original isolated natural recorded terminal",
          receipt["observed_exit"] == 0 and receipt["controller_exit"] == 0
          and not receipt["timed_out"] and not receipt["interrupted"]
          and receipt["terminal"]["direct_reaped"]
          and receipt["terminal"]["active_processes"] == 0
          and receipt["terminal"]["pipes_drained"]
          and receipt["terminal"]["errors"] == [] and receipt["errors"] == [])
    check("original recorded elapsed time", receipt["seconds"] == 349.9020121250069)
    check("original stdout/stderr empty",
          (EVIDENCE / "native.stdout").stat().st_size == 0
          and (EVIDENCE / "native.stderr").stat().st_size == 0)

    post = load(EVIDENCE / "post-close-processes.json")
    check("post-close auto-launch explicitly excluded",
          post["post_close_ax_excluded_from_acceptance"] is True
          and post["original_pid"] == 92747 and post["original_reaped"] is True
          and len(post["remaining_keelshell_processes"]) == 1
          and "2486" in post["remaining_keelshell_processes"][0]
          and "Tue Nov 17 09:49:42 2026" in post["remaining_keelshell_processes"][0])
    # Cleanup receipt is supplementary only; no signal or live census is made here.
    cleanup = load(EVIDENCE / "post-close-cleanup.json")
    check("cleanup receipt belongs only to excluded PID",
          cleanup["pid"] == 2486 and cleanup["original_isolated_exit"] == 0
          and cleanup["direct_reaped"] is None)

    check("fixed source objects exist",
          git("rev-parse", SOURCE + "^{commit}", CURRENT + "^{commit}").decode().splitlines()
          == [SOURCE, CURRENT])
    left, right = production_tree(SOURCE), production_tree(CURRENT)
    check("nonempty production Rust/Cargo inventory", len(left) > 0 and len(right) > 0)
    check("production Rust/Cargo blobs identical", left == right)
    changed = [p for p in git(
        "diff", "--no-ext-diff", "--name-only", "-z", SOURCE, CURRENT
    ).decode().split("\0") if p]
    check("changed path inventory equals binding", changed == binding["all_changed_paths"])
    check("binding claims no production Rust/Cargo changes",
          binding["production_rust_cargo_changes"] == [])
    check("tracked crates and Cargo clean relative to fixed current",
          not git("diff", "--no-ext-diff", "--name-only", CURRENT,
                  "--", "crates", "Cargo.toml", "Cargo.lock").strip())
    observed_head = git("rev-parse", "HEAD").decode().strip()

    decision = load(BASE / "decision.json")
    check("scoped approval only",
          decision["decision"] == "APPROVE_SCOPED_NATIVE_TOOLBAR_EVIDENCE"
          and decision["ship"] == "ship_observed_subset_only"
          and decision["finding_counts"] == {"P0": 0, "P1": 0, "P2": 0, "P3": 0}
          and not decision["full_native_finish"]
          and not decision["old_p2"]["closed"]
          and decision["compact_window"] == "HOLD")
    check("human inspected complete supplied image set",
          decision["visual_review"]["tool"] == "functions.view_image"
          and decision["visual_review"]["images_actually_opened"] == list(range(1, 11)))
    check("tool action failure preserved separately",
          decision["instrumentation_events"][0]["old_id"] == 82
          and decision["instrumentation_events"][0]["fresh_id"] == 12)
    print(json.dumps({
        "schema_version": 1, "result": "PASS" if not errors else "FAIL",
        "checks_run": len(checks), "checks_passed": sum(x["passed"] for x in checks),
        "checks_failed": len(errors), "errors": errors, "checks": checks,
        "input_files_rehashed": len(expected["files"]),
        "image_count": len(images), "ax_count": len(axes),
        "production_rust_cargo_files_compared": len(left),
        "changed_paths_compared": len(changed),
        "observed_head": observed_head, "bound_current": CURRENT,
        "package_source": SOURCE, "app_sha256": APP_SHA, "images": image_rows,
        "visual_judgment_recomputed": False,
        "product_tests_run": 0, "cargo_commands_run": 0,
        "gui_actions_run": 0, "network_requests_run": 0,
    }, ensure_ascii=False, indent=2))
    return 0 if not errors else 1


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError, KeyError, IndexError, struct.error,
            subprocess.SubprocessError) as error:
        print(json.dumps({"result": "ERROR", "error": str(error)}, ensure_ascii=False))
        sys.exit(2)
