# Tunnel CI collection — 2026-11-17

Exact engineering source: `cdf1e171f2f9b179f09db230f4739696d02fe80d`. Checkout HEAD at start: `f4562ad17efc918976738b241352e7a4f8af434e`; the latter is not the CI source.
Latest observation: `2026-11-17T05:43:37.040413+00:00`. All requested runs terminal: **True**.

| Workflow / job | ID | Observed result | Recorded test inventory |
| --- | --- | --- | --- |
| Quality / native (windows-2025) | `133827817935` | success | Rust 3422/0/66 passed/failed/ignored (95 suites); rustdoc 14 passed; Python main 526 run / 53 skipped |
| Quality / native (ubuntu-24.04) | `133827818182` | success | Rust 3428/0/69 passed/failed/ignored (95 suites); rustdoc 14 passed; Python main 526 run / 3 skipped |
| Quality / native (macos-26) | `133827818303` | success | Rust 3435/0/68 passed/failed/ignored (95 suites); rustdoc 14 passed; Python main 526 run / 3 skipped |
| Windows monitor integration / Actual collectors and independent Windows APIs | `133827817731` | success | Python 111 run / 3 skipped; Rust 1 passed / 0 failed / 0 ignored / 9 filtered |
| Windows monitor integration / Isolated OpenSSH prerequisites (HOLD until terminal proof) | `133827819414` | skipped | Job skipped; no tests executed |
| Windows OpenSSH monitor integration / Actual Windows OpenSSH and original remote processes | `133827817472` | success | Python 96 run / 1 skipped; Native SSH Rust 1 passed (artifact stdout and single-test inventory agree) |

Normal Rust and rustdoc totals are separate. Python discovery is not added to wrapper/helper runs; full per-step counts and named records are in `summary.json` and `inventories/`. These are recorded stdout inventories, not a new local `--list` run. API metadata binds every job and artifact to the exact run SHA; log checkout lines and the SSH source-head receipt provide additional recorded source evidence.

Quality Python main discovery uses quiet output: run/skip totals are available, but individual Python names are not. Completed Quality plaintext logs are preserved while command-group boundaries identify each test step. The final Quality run ZIP is retained.

| Raw ZIP | Bytes | SHA-256 | API digest |
| --- | ---: | --- | --- |
| `downloads/run-44020265369-attempt-1-logs.zip` | 1036337 | `51f46c97f5ad262fa8cf7688f23c16ecc67965a8bac393247764659f9e2b5850` | not supplied for log archives |
| `downloads/artifact-14302006704.zip` | 5522 | `cf8d8f514416d35aadc99cce5118939fefb3b013725bf00dda5995a70f93a6ef` | matches |
| `downloads/artifact-14300944839.zip` | 5604 | `e821363873da9bbaf0b5903007dd4fc581bc6fa146f8025df559b578c804bfbb` | matches |
| `downloads/run-44020265273-attempt-1-logs.zip` | 33355 | `f2a7c4549665cbee1436bfca348b208399b07be8c703ed51e3e7064843ce107b` | not supplied for log archives |
| `downloads/artifact-14301275329.zip` | 46378 | `de56cee2b72e9801ee6b7117b147862402ce0b0f6777b2f24e60f1bf51a96b22` | matches |
| `downloads/run-44020265248-attempt-1-logs.zip` | 33117 | `9450f9120045d9a6ed8b0d531cd230c062ce09e9d3b497bd62977097b3996f97` | not supplied for log archives |
| `downloads/artifact-14300447980.zip` | 53908 | `1663513c81ac54069e04a008f7e51677cb897a2656792a9a927c021eab711398` | matches |

Retained 7 raw ZIPs with 172 members. ZIP CRCs and artifact API digests are checked. Failed jobs observed: 0; inventory discrepancies: 0; offline evidence checks: 77 passed / 0 failed. No independent code review was performed.

API request receipts: 140; prior retrieval failures: 1 (1 recovered). The initial completed-macOS plaintext download was rejected by gh's terminal-escape guard; its failed receipt is retained. The raw-byte retry explicitly allowed escape sequences. This collection error is separate from CI job conclusions.

The API workflow's isolated-SSH prerequisite job remains skipped, and its direct API artifact reports `ssh=UNRUN`. Its three Python skips are non-Windows negative cases; the actual OpenSSH job's one Python skip has the same boundary. The separate OpenSSH artifact records one executed native SSH test, four production collector operations with exit0, and 20 non-master original objects naturally terminal. Their recorded exit codes include 255 and 1, so they are not described as all exit0. The earlier seal is HOLD with the master alive; cleanup is PASS with active objects and owned handles zero, while the master has cleanup exit125. Both states are preserved.

Workflow/API success alone does not establish artifact content or GUI acceptance. Both Windows artifacts record `native_gui=UNRUN`. GUI, IME, accessibility, installation, signing, notarization, releases and complete product acceptance remain unverified. Controller gates and ignored tests retain their recorded scope.

The macOS and Ubuntu OpenSSH artifacts each contain 18 interoperability and 6 forwarding passes with matching named stdout counts. Their cleanup receipts certify observed ancestry with kernel birth identity checks; entirely detached descendants between observations remain outside that proof.

All output stays in this new directory. Only bounded `gh api` GETs and offline parsing were used; no reruns, cancellations, source work, docs writes, git mutations, local cargo/tests/builds, shared-target access, MCP inspection, or child agents. Raw ZIPs are unchanged. Authentication headers, tokens, credential helpers and environment values were not recorded; the retained payload scan found no GitHub token/private-key markers.

All requested runs reached natural terminal states. No further CI polling remains for these exact run IDs. The parent owns archiving, committing and closing the sidecar.

Evidence map: `snapshots/` contains exact API responses and per-request receipts; `artifacts/` contains individual artifact API metadata; `archive-bindings.json` binds archives to source/run/attempt; `archive-manifest.json` lists per-member SHA-256; `inventories/` retains per-test records; `verification.json` records offline checks. `SHA256SUMS` covers every file except itself.
