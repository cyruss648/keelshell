#!/usr/bin/env python3
"""Parse downloaded CI evidence; never execute product code or tests."""

from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import re
import time
import zipfile

ROOT = Path(__file__).resolve().parent
CTX = json.loads((ROOT / "context.json").read_text())
SOURCE = CTX["engineering_source_sha"]
ANSI = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")
STAMP = re.compile(r"^\d{4}-\d\d-\d\dT\S+Z\s?")
RUST_SUMMARY = re.compile(
    r"^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; "
    r"(\d+) ignored; (\d+) measured; (\d+) filtered out;"
)
RUST_NAME = re.compile(r"^test (.+) \.\.\. (ok|FAILED|ignored(?:, .*)?)$")
PY_NAME = re.compile(
    r"^(\S+) \((.+)\) \.\.\. "
    r"(ok|skipped .+|FAIL|ERROR|expected failure|unexpected success)$"
)
SECRET = re.compile(
    rb"(?:ghp_|gho_|ghu_|ghs_|github_pat_)[A-Za-z0-9_]{20,}"
    rb"|-----BEGIN (?:OPENSSH |RSA |EC |DSA )?PRIVATE KEY-----"
)


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def read(path):
    return json.loads(path.read_text())


def digest(data):
    return hashlib.sha256(data).hexdigest()


def stripped_lines(data):
    return [ANSI.sub("", STAMP.sub("", line)).rstrip() for line in data.decode(
        "utf-8-sig", errors="replace"
    ).splitlines()]


def parse_log(data):
    lines = stripped_lines(data)
    rust, python = [], []
    rust_group = None
    heading = "unlabelled"
    doctest = False
    py_names = []
    for index, line in enumerate(lines):
        clean = line.strip()
        if re.search(r"\bRunning (?:unittests|tests/|.*[/\\]deps[/\\])", clean):
            heading, doctest = clean, False
        elif "Doc-tests " in clean:
            heading, doctest = clean, True
        count = re.match(r"running (\d+) tests?$", clean)
        if count:
            rust_group = {
                "source_sha": SOURCE,
                "heading": heading,
                "doctest": doctest,
                "declared": int(count[1]),
                "start_line": index + 1,
                "names": [],
            }
        named = RUST_NAME.match(clean)
        if named and rust_group is not None:
            status = named[2].split(",", 1)[0]
            rust_group["names"].append({
                "name": named[1],
                "status": status,
                "reason": named[2].partition(", ")[2] or None,
                "line": index + 1,
            })
        summary = RUST_SUMMARY.match(clean)
        if summary:
            group = rust_group or {
                "source_sha": SOURCE, "heading": heading, "doctest": doctest,
                "declared": None, "start_line": None, "names": [],
            }
            counts = dict(zip(
                ["passed", "failed", "ignored", "measured", "filtered_out"],
                map(int, summary.groups()[1:]),
            ))
            group.update(counts)
            group["end_line"] = index + 1
            actual = Counter(item["status"] for item in group["names"])
            group["named_counts"] = dict(actual)
            group["declared_matches_summary"] = group["declared"] == sum(
                counts[key] for key in ("passed", "failed", "ignored", "measured")
            )
            group["named_matches_summary"] = (
                actual["ok"] == counts["passed"]
                and actual["FAILED"] == counts["failed"]
                and actual["ignored"] == counts["ignored"]
                and sum(actual.values()) == group["declared"]
            )
            rust.append(group)
            rust_group = None
        py_name = PY_NAME.match(clean)
        if py_name:
            py_names.append({
                "name": py_name[1], "id": py_name[2],
                "status": py_name[3].split(" ", 1)[0],
                "detail": py_name[3], "line": index + 1,
            })
        py_summary = re.match(r"Ran (\d+) tests? in (.+)$", clean)
        if py_summary:
            outcome = next(
                (x.strip() for x in lines[index + 1:index + 51]
                 if re.match(r"^(OK|FAILED)(?:\s|\(|$)", x.strip())),
                "UNKNOWN",
            )
            skipped_match = re.search(r"skipped=(\d+)", outcome)
            skipped = int(skipped_match[1]) if skipped_match else 0
            counts = Counter(x["status"] for x in py_names)
            python.append({
                "source_sha": SOURCE,
                "run": int(py_summary[1]),
                "skipped": skipped,
                "outcome": outcome,
                "passed_inferred_from_success": int(py_summary[1]) - skipped
                if outcome.startswith("OK") else None,
                "named_counts": dict(counts),
                "named_inventory_available": bool(py_names),
                "named_count_matches_run": len(py_names) == int(py_summary[1]) if py_names else None,
                "named_skip_matches_summary": counts["skipped"] == skipped if py_names else None,
                "names": py_names,
                "summary_line": index + 1,
            })
            py_names = []
    return {
        "source_sha": SOURCE,
        "raw_sha256": digest(data),
        "raw_bytes": len(data),
        "line_count": len(lines),
        "source_sha_literal_present": any(SOURCE in line for line in lines),
        "rust": rust,
        "python": python,
        "controller_signals": [
            {"line": i + 1, "text": line}
            for i, line in enumerate(lines)
            if any(token in line.lower() for token in (
                "controller gate", "controller_gate", "harness=false",
                "readiness gate", "readiness controller", "small-stack",
            ))
        ],
        "custom_controller_completions": [
            {"line": i + 1, "text": line}
            for i, line in enumerate(lines)
            if (
                "controller-stage " in line
                and '"stage":"controller","phase":"end"' in line
            ) or "all assertions/scenario groups passed" in line
        ],
    }


def aggregate(groups):
    return {
        "suites": len(groups),
        **{
            key: sum(group.get(key, 0) for group in groups)
            for key in ("passed", "failed", "ignored", "measured", "filtered_out")
        },
        "declared_total": sum(g.get("declared") or 0 for g in groups),
        "named_total": sum(len(g["names"]) for g in groups),
        "all_declarations_match": all(g["declared_matches_summary"] for g in groups),
        "all_named_inventories_match": all(g["named_matches_summary"] for g in groups),
    }


def raw_job_steps(path, job):
    """Retain command-delimited groups when the whole run ZIP is not ready."""
    raw_lines = path.read_bytes().splitlines(keepends=True)
    starts = [i for i, line in enumerate(raw_lines) if b"##[group]Run " in line]
    steps = []
    for begin, end in zip(starts, starts[1:] + [len(raw_lines)]):
        first = stripped_lines(raw_lines[begin])[0]
        command = first.split("##[group]Run ", 1)[1]
        if "scripts/check.py" in command:
            name = "Rust quality gate"
        elif 'unittest discover -s packaging' in command:
            name = "Packaging regression tests"
        elif "scripts/openssh_interop.py --forwarding" in command:
            name = "OpenSSH forwarding lifecycles (macOS and Linux)"
        elif "scripts/openssh_interop.py" in command:
            name = "OpenSSH interoperability (macOS and Linux)"
        else:
            name = "Raw CI command: " + command
        number = next((s["number"] for s in job.get("steps", []) if s["name"] == name), 0)
        parsed = parse_log(b"".join(raw_lines[begin:end]))
        parsed.update(
            number=number, name=name, member=None,
            archive=str(path.relative_to(ROOT)),
            provenance="Completed job plaintext, delimited by raw CI Run command groups",
            raw_job_start_line=begin + 1, raw_job_end_line=end,
        )
        steps.append(parsed)
    return steps


def artifact_evidence(binding):
    path = ROOT / binding["path"]
    if not path.exists():
        return {"artifact_id": binding["artifact_id"], "downloaded": False}
    with zipfile.ZipFile(path) as archive:
        files = set(archive.namelist())
        receipt = json.loads(archive.read("receipt.json")) if "receipt.json" in files else {}
        summary = {
            "artifact_id": binding["artifact_id"],
            "name": binding["name"],
            "run_id": binding["run_id"],
            "source_sha": SOURCE,
            "metadata_digest_matches": binding.get("digest_matches_api"),
            "receipt": {
                key: receipt.get(key)
                for key in ("schema", "mode", "status", "source", "ssh",
                            "windows_api", "native_gui", "scope")
            },
        }
        metadata = read(ROOT / binding["metadata_path"])
        summary["api_metadata_binding_matches"] = (
            metadata.get("id") == binding["artifact_id"]
            and metadata.get("workflow_run", {}).get("id") == binding["run_id"]
            and metadata.get("workflow_run", {}).get("head_sha") == SOURCE
            and metadata.get("digest") == binding["api_digest"]
            and metadata.get("size_in_bytes") == binding["bytes"]
        )
        children = []
        for child in receipt.get("children", []):
            terminal = child.get("terminal", {})
            proof = terminal.get("native_process_objects", {}) if isinstance(terminal, dict) else {}
            children.append({
                "label": child.get("label"),
                "observed_exit": child.get("observed_exit"),
                "direct_reaped": terminal.get("direct_reaped") if isinstance(terminal, dict) else None,
                "active_processes": terminal.get("active_processes") if isinstance(terminal, dict) else None,
                "pipes_drained": terminal.get("pipes_drained") if isinstance(terminal, dict) else None,
                "pending_process_objects": proof.get("pending_process_objects"),
                "original_handles_checked": proof.get("original_handles_checked"),
                "errors": child.get("errors"),
            })
        summary["children"] = children
        summary["children_count"] = len(children)
        summary["all_children_reaped"] = (
            all(c["direct_reaped"] for c in children) if children else None
        )
        if "source-head.stdout" in files:
            summary["recorded_head_matches"] = (
                archive.read("source-head.stdout").decode().strip() == SOURCE
                and receipt.get("source") == SOURCE
            )
        if "test-binary.json" in files:
            summary["test_binary"] = json.loads(archive.read("test-binary.json"))
        if "native-ssh-client.stdout" in files:
            parsed = parse_log(archive.read("native-ssh-client.stdout"))
            summary["native_ssh_test"] = aggregate(parsed["rust"])
            actual_names = [
                item["name"] for group in parsed["rust"] for item in group["names"]
            ]
            declared = summary.get("test_binary", {}).get("inventory", [])
            summary["native_ssh_inventory_matches_execution"] = (
                actual_names == declared
                and summary["test_binary"].get("executed") in declared
            )
            dump(ROOT / "inventories" / f"artifact-{binding['artifact_id']}-native-ssh.json", parsed)
        if "rust-client.json" in files:
            client = json.loads(archive.read("rust-client.json"))
            summary["rust_client"] = {
                key: client.get(key)
                for key in ("status", "test", "identity", "errors",
                            "independent_oracle_status", "data_provenance")
            }
        for member, key in (
            ("ssh-debug-originals.json", "original_process_seal"),
            ("ssh-debug-cleanup.json", "process_cleanup"),
        ):
            if member not in files:
                continue
            raw = json.loads(archive.read(member))
            selected = {
                field: raw.get(field)
                for field in (
                    "state", "terminal_proven", "job_total_processes",
                    "job_active_processes", "complete_original_object_census",
                    "admission_closed", "identities_bound", "pending_process_objects",
                    "fallback_detaches", "owned_handles_remaining", "closed", "errors",
                )
            }
            admissions = raw.get("admissions", [])
            masters = [a for a in admissions if a.get("is_master")]
            nonmasters = [a for a in admissions if not a.get("is_master")]
            selected.update(
                admissions_count=len(admissions),
                nonmaster_count=len(nonmasters),
                nonmaster_naturally_terminal=sum(
                    a.get("natural_terminal_before_cleanup") is True for a in nonmasters
                ),
                nonmaster_exit_codes=dict(Counter(str(a.get("exit_code")) for a in nonmasters)),
                masters=[{
                    "natural_terminal_before_cleanup": a.get("natural_terminal_before_cleanup"),
                    "exit_code": a.get("exit_code"),
                    "original_signaled": a.get("original_signaled"),
                } for a in masters],
            )
            summary[key] = selected
        for member, key in (
            ("ssh-cleanup.json", "ssh_cleanup"),
            ("ssh-production-binding.json", "production_binding"),
        ):
            if member in files:
                summary[key] = json.loads(archive.read(member))
        # Verify artifact wire assembly and command receipts without running them.
        wire_checks = []
        for member in sorted(files):
            if not member.endswith(".wire.txt"):
                continue
            prefix = member[:-len(".wire.txt")]
            assembly = json.loads(archive.read(prefix + ".assembly.json"))
            command_receipt = json.loads(archive.read(prefix + ".receipt.json"))
            wire = archive.read(member)
            execution = command_receipt.get("shell_execution", {})
            wire_checks.append({
                "operation": prefix,
                "wire_sha256": digest(wire),
                "assembly_matches_wire": assembly.get("wire_command_sha256") == digest(wire),
                "receipt_argv_contains_exact_wire": wire.decode("ascii") in execution.get("argv", []),
                "receipt_production_bytes_match": execution.get("production_command_ascii_bytes") == len(wire),
                "serialized_command_digest_matches": command_receipt.get("command_sha256") == digest(
                    execution.get("serialized_command_line", "").encode()
                ),
            })
        summary["wire_checks"] = wire_checks
        interop = []
        for member in sorted(files):
            if not member.endswith("/result.json"):
                continue
            result = json.loads(archive.read(member))
            log_member = member.removesuffix("result.json") + "tests.log"
            parsed = parse_log(archive.read(log_member)) if log_member in files else {}
            interop.append({
                "result_member": member, "source_sha": SOURCE,
                "outcome": result.get("outcome"),
                "passed_tests": result.get("passed_tests"),
                "cleanup": result.get("cleanup"),
                "boundary": result.get("boundary"),
                "stdout_rust": aggregate(parsed.get("rust", [])),
                "tests_log_member": log_member,
            })
            if parsed:
                dump(ROOT / "inventories" / (
                    f"artifact-{binding['artifact_id']}-"
                    + member.split("/")[0] + ".json"
                ), parsed)
        summary["openssh_interop"] = interop
        return summary


def main():
    latest = read(ROOT / "latest.json")
    snap = ROOT / latest["snapshot"]
    bindings = read(ROOT / "archive-bindings.json")
    failures, mismatches, secret_hits = [], [], []
    archives = []
    for binding in bindings:
        entry = dict(binding)
        path = ROOT / entry["path"]
        if path.exists() and path.suffix == ".zip":
            with zipfile.ZipFile(path) as archive:
                members = archive.infolist()
                entry["members"] = [{
                    "path": m.filename, "bytes": m.file_size,
                    "sha256": digest(archive.read(m)),
                } for m in members]
                for member in members:
                    # Scan without printing or recording any matched secret value.
                    if SECRET.search(archive.read(member)):
                        secret_hits.append({"archive": entry["path"], "member": member.filename})
        elif path.exists() and SECRET.search(path.read_bytes()):
            secret_hits.append({"path": entry["path"]})
        archives.append(entry)
    dump(ROOT / "archive-manifest.json", archives)
    runs = []
    for run_id in CTX["run_ids"]:
        run = read(snap / f"{run_id}-run.json")
        jobs_data = read(snap / f"{run_id}-jobs.json")
        run_archive = next(
            (ROOT / b["path"] for b in bindings
             if b["kind"] == "run_log_archive" and b["run_id"] == run_id
             and (ROOT / b["path"]).exists()), None
        )
        jobs = []
        for job in jobs_data["jobs"]:
            inventory = {
                "run_id": run_id, "run_attempt": run["run_attempt"],
                "job_id": job["id"], "job_name": job["name"],
                "source_sha": SOURCE, "status": job["status"],
                "conclusion": job["conclusion"], "steps": [],
            }
            if run_archive:
                with zipfile.ZipFile(run_archive) as archive:
                    for member in archive.namelist():
                        match = re.match(
                            re.escape(job["name"]) + r"/(\d+)_(.+)\.txt$", member
                        )
                        if match:
                            parsed = parse_log(archive.read(member))
                            parsed.update(
                                number=int(match[1]), name=match[2], member=member,
                                archive=str(run_archive.relative_to(ROOT)),
                            )
                            inventory["steps"].append(parsed)
            elif (ROOT / "downloads" / f"job-{job['id']}-logs.txt").exists():
                inventory["steps"] = raw_job_steps(
                    ROOT / "downloads" / f"job-{job['id']}-logs.txt", job
                )
            inventory["steps"].sort(key=lambda item: item["number"])
            inventory_path = ROOT / "inventories" / f"job-{job['id']}.json"
            dump(inventory_path, inventory)
            job_summary = {
                "id": job["id"], "name": job["name"], "source_sha": SOURCE,
                "status": job["status"], "conclusion": job["conclusion"],
                "started_at": job.get("started_at"), "completed_at": job.get("completed_at"),
                "inventory_path": str(inventory_path.relative_to(ROOT)),
                "inventory_available": bool(inventory["steps"]),
                "skipped_steps": [
                    {"number": s["number"], "name": s["name"]}
                    for s in job.get("steps", []) if s.get("conclusion") == "skipped"
                ],
                "incomplete_steps": [
                    {"number": s["number"], "name": s["name"], "status": s["status"]}
                    for s in job.get("steps", []) if s["status"] != "completed"
                ],
                "step_counts": [],
            }
            if job["conclusion"] not in (None, "success", "skipped"):
                failures.append({"run_id": run_id, "job_id": job["id"],
                                 "conclusion": job["conclusion"]})
            for step in inventory["steps"]:
                groups = step["rust"]
                python = step["python"]
                if groups or python:
                    selected = {
                        "number": step["number"], "name": step["name"],
                        "rust": aggregate([g for g in groups if not g["doctest"]]),
                        "rustdoc": aggregate([g for g in groups if g["doctest"]]),
                        "python": [{
                            key: group[key] for key in (
                                "run", "skipped", "passed_inferred_from_success", "outcome",
                                "named_counts", "named_inventory_available",
                                "named_count_matches_run", "named_skip_matches_summary",
                            )
                        } for group in python],
                    }
                    job_summary["step_counts"].append(selected)
                    if step["name"] == "Rust quality gate":
                        job_summary["ordinary_rust"] = selected["rust"]
                        job_summary["rustdoc"] = selected["rustdoc"]
                        job_summary["python_main"] = max(
                            selected["python"], key=lambda g: g["run"], default=None
                        )
                for group in groups:
                    if not group["declared_matches_summary"] or not group["named_matches_summary"]:
                        mismatches.append({
                            "job_id": job["id"], "step": step["name"],
                            "kind": "rust_inventory", "heading": group["heading"],
                            "declared": group["declared"], "named": len(group["names"]),
                            "line": group["end_line"],
                        })
                for group in python:
                    if group["names"] and (
                        not group["named_count_matches_run"] or not group["named_skip_matches_summary"]
                    ):
                        mismatches.append({
                            "job_id": job["id"], "step": step["name"],
                            "kind": "python_inventory", "run": group["run"],
                            "named": len(group["names"]), "line": group["summary_line"],
                        })
            jobs.append(job_summary)
        runs.append({
            "id": run_id, "name": run["name"], "source_sha": run["head_sha"],
            "run_attempt": run["run_attempt"], "status": run["status"],
            "conclusion": run["conclusion"], "created_at": run["created_at"],
            "updated_at": run["updated_at"], "metadata_snapshot": latest["snapshot"],
            "jobs": jobs,
            "artifacts": [
                artifact_evidence(b) for b in bindings
                if b["kind"] == "artifact_archive" and b["run_id"] == run_id
            ],
        })
    summary = {
        "schema": 1,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "observed_at_utc": latest["observed_at_utc"],
        "elapsed_collection_seconds": round(time.time() - CTX["started_epoch"], 3),
        "repository": CTX["repository"],
        "checkout_head_at_start": CTX["checkout_head_supplied"],
        "engineering_source_sha": SOURCE,
        "all_runs_terminal": latest["all_terminal"],
        "runs": runs,
        "archives": [{k: v for k, v in b.items() if k != "members"} for b in archives],
        "archive_zip_count": sum(b["path"].endswith(".zip") for b in archives),
        "archive_member_count": sum(len(b.get("members", [])) for b in archives),
        "all_artifact_digests_match": all(
            b.get("digest_matches_api") for b in bindings if b["kind"] == "artifact_archive"
        ),
        "failed_jobs_observed": failures,
        "inventory_mismatches": mismatches,
        "secret_scan": {"patterns": "GitHub token prefixes and private-key PEM markers",
                        "hits": secret_hits, "matched_values_recorded": False},
        "boundaries": [
            "Only the exact run source SHA is covered; checkout documentation HEAD is not the CI source.",
            "Inventory is parsed from recorded CI stdout; no independent --list execution was performed.",
            "Normal Rust, rustdoc, Python runs, explicit ignored tests and custom controller gates are separate.",
            "The API workflow isolated-SSH prerequisite job is skipped; direct API artifact reports ssh=UNRUN.",
            "OpenSSH original seal HOLD/master alive and cleanup PASS/master exit125 are distinct states.",
            "API and workflow success do not by themselves prove artifact content or native GUI acceptance.",
            "Native GUI, installation, signing, notarization, release and full product acceptance are unverified.",
            "No local product tests, cargo, build, shared-target access, source work, git mutations or MCP inspection.",
            "No child agents were created; the parent owns archive, commit and closure.",
        ],
    }
    dump(ROOT / "summary.json", summary)
    print(json.dumps({
        "all_terminal": summary["all_runs_terminal"],
        "elapsed_seconds": summary["elapsed_collection_seconds"],
        "zip_count": summary["archive_zip_count"],
        "member_count": summary["archive_member_count"],
        "failed_jobs": failures, "inventory_mismatches": mismatches,
        "secret_hit_count": len(secret_hits),
        "job_counts": [{
            "id": j["id"], "status": j["status"], "conclusion": j["conclusion"],
            "ordinary_rust": j.get("ordinary_rust"), "rustdoc": j.get("rustdoc"),
            "python_main": j.get("python_main"),
            "other_step_counts": j["step_counts"] if run["id"] != 44020265369 else None,
        } for run in runs for j in run["jobs"]],
    }, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
