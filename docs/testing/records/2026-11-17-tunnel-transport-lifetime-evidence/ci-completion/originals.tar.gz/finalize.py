#!/usr/bin/env python3
"""Write the compact handoff and final checksums from collected evidence only."""

from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent


def load(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    summary = load(ROOT / "summary.json")
    source = summary["engineering_source_sha"]
    checks = []

    def check(name, result, detail=None):
        checks.append({"name": name, "passed": bool(result), "detail": detail})

    check("all run source SHAs match", all(r["source_sha"] == source for r in summary["runs"]))
    check("no inventory mismatches", not summary["inventory_mismatches"])
    check("no token or private-key markers found", not summary["secret_scan"]["hits"])
    for entry in summary["archives"]:
        path = ROOT / entry["path"]
        check(f"{path.name} downloaded", path.exists())
        if not path.exists():
            continue
        check(f"{path.name} digest equals recorded download", sha(path) == entry["sha256"])
        if path.suffix == ".zip":
            with zipfile.ZipFile(path) as archive:
                check(f"{path.name} CRC", archive.testzip() is None)
                check(f"{path.name} member count", len(archive.infolist()) == entry["zip_member_count"])
        if entry["kind"] == "artifact_archive":
            check(f"{path.name} API digest", entry.get("digest_matches_api"))
            check(f"{path.name} API bytes", entry.get("size_matches_api"))
    for run in summary["runs"]:
        for artifact in run["artifacts"]:
            aid = artifact["artifact_id"]
            check(f"artifact {aid} metadata source/run/digest/bytes", artifact.get("api_metadata_binding_matches"))
            if artifact.get("children_count"):
                check(f"artifact {aid} original direct children reaped", artifact.get("all_children_reaped"))
            if "recorded_head_matches" in artifact:
                check(f"artifact {aid} recorded source HEAD", artifact["recorded_head_matches"])
            if "native_ssh_inventory_matches_execution" in artifact:
                check(f"artifact {aid} native SSH inventory", artifact["native_ssh_inventory_matches_execution"])
            for wire in artifact.get("wire_checks", []):
                for field in (
                    "assembly_matches_wire", "receipt_argv_contains_exact_wire",
                    "receipt_production_bytes_match", "serialized_command_digest_matches",
                ):
                    check(f"artifact {aid} {wire['operation']} {field}", wire[field])
            for interop in artifact.get("openssh_interop", []):
                counts = interop["stdout_rust"]
                check(f"artifact {aid} {interop['result_member']} count and names",
                      interop["outcome"] == "passed"
                      and interop["passed_tests"] == counts["passed"]
                      and counts["failed"] == 0
                      and counts["all_declarations_match"]
                      and counts["all_named_inventories_match"])
            if "process_cleanup" in artifact:
                seal = artifact["original_process_seal"]
                cleanup = artifact["process_cleanup"]
                check("SSH seal preserves HOLD with master alive",
                      seal["state"] == "HOLD" and seal["job_active_processes"] == 1
                      and seal["nonmaster_count"] == seal["nonmaster_naturally_terminal"] == 20)
                check("SSH cleanup PASS with empty job and no owned handles",
                      cleanup["state"] == "PASS" and cleanup["terminal_proven"]
                      and cleanup["job_active_processes"] == cleanup["pending_process_objects"]
                      == cleanup["owned_handles_remaining"] == 0 and cleanup["closed"])
                check("SSH master cleanup exit125 kept distinct",
                      len(cleanup["masters"]) == 1
                      and cleanup["masters"][0]["exit_code"] == 125
                      and not cleanup["masters"][0]["natural_terminal_before_cleanup"])
    receipts = []
    for path in sorted(ROOT.rglob("*.receipt.json")):
        receipt = load(path)
        if "endpoint" in receipt:
            receipts.append({"path": str(path.relative_to(ROOT)), **receipt})
    check("every remote request was GET", all(x.get("method") == "GET" for x in receipts))
    successful_endpoints = {x["endpoint"] for x in receipts if x.get("exit_code") == 0}
    request_failures = [{
        "path": x["path"], "endpoint": x["endpoint"], "exit_code": x.get("exit_code"),
        "error": x.get("error"), "recovered": x["endpoint"] in successful_endpoints,
    } for x in receipts if x.get("exit_code") != 0]
    check("every failed request has a successful recovery",
          all(x["recovered"] for x in request_failures))
    check("no request timed out", not any(x.get("timed_out") for x in receipts))
    verification = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_sha": source,
        "scope": "Offline archive/metadata/inventory checks, not product tests or independent review",
        "checks_passed": sum(x["passed"] for x in checks),
        "checks_failed": sum(not x["passed"] for x in checks),
        "checks": checks,
        "api_request_receipt_count": len(receipts),
        "recorded_exit_codes": {str(code): sum(x.get("exit_code") == code for x in receipts)
                                for code in set(x.get("exit_code") for x in receipts)},
        "retrieval_failures": request_failures,
        "no_local_product_execution": True,
        "no_child_agents_created": True,
    }
    (ROOT / "verification.json").write_text(json.dumps(verification, indent=2) + "\n")

    lines = [
        "# Tunnel CI collection — 2026-11-17",
        "",
        f"Exact engineering source: `{source}`. Checkout HEAD at start: "
        f"`{summary['checkout_head_at_start']}`; the latter is not the CI source.",
        f"Latest observation: `{summary['observed_at_utc']}`. "
        f"All requested runs terminal: **{summary['all_runs_terminal']}**.",
        "",
        "| Workflow / job | ID | Observed result | Recorded test inventory |",
        "| --- | --- | --- | --- |",
    ]
    remaining = []
    for run in summary["runs"]:
        for job in run["jobs"]:
            outcome = job["conclusion"] if job["status"] == "completed" else job["status"]
            facts = []
            if "ordinary_rust" in job:
                rust = job["ordinary_rust"]
                doc = job["rustdoc"]
                facts.append(
                    f"Rust {rust['passed']}/{rust['failed']}/{rust['ignored']} "
                    f"passed/failed/ignored ({rust['suites']} suites); "
                    f"rustdoc {doc['passed']} passed"
                )
                py = job.get("python_main")
                if py:
                    facts.append(f"Python main {py['run']} run / {py['skipped']} skipped")
            elif job["status"] != "completed":
                facts.append("UNKNOWN: terminal stdout not yet available")
            elif job["conclusion"] == "skipped":
                facts.append("Job skipped; no tests executed")
            else:
                for step in job["step_counts"]:
                    for py in step["python"]:
                        facts.append(f"Python {py['run']} run / {py['skipped']} skipped")
                    if step["rust"]["suites"]:
                        rust = step["rust"]
                        facts.append(f"Rust {rust['passed']} passed / {rust['failed']} failed / "
                                     f"{rust['ignored']} ignored / {rust['filtered_out']} filtered")
                for artifact in run["artifacts"]:
                    if "native_ssh_test" in artifact:
                        facts.append(f"Native SSH Rust {artifact['native_ssh_test']['passed']} passed "
                                     "(artifact stdout and single-test inventory agree)")
            if run["id"] == 44020265369:
                platform = job["name"].partition("(")[2].removesuffix(")")
                for artifact in run["artifacts"]:
                    if platform and platform in artifact.get("name", ""):
                        counts = [str(x["stdout_rust"]["passed"])
                                  for x in artifact.get("openssh_interop", [])]
                        if counts:
                            facts.append("Actual OpenSSH " + " + ".join(counts)
                                         + " passed (interop / forwarding, artifact stdout)")
                for step in job["step_counts"]:
                    if step["name"].startswith("OpenSSH"):
                        rust = step["rust"]
                        facts.append(f"{step['name']}: {rust['passed']} passed / {rust['ignored']} ignored")
            lines.append(
                f"| {run['name']} / {job['name']} | `{job['id']}` | {outcome} | "
                + "; ".join(facts) + " |"
            )
            if job["status"] != "completed":
                active = ", ".join(
                    s["name"] for s in job["incomplete_steps"] if s["status"] == "in_progress"
                )
                remaining.append(
                    f"- Run `{run['id']}`, job `{job['id']}`: await natural terminal state"
                    f" ({active or 'no active step reported'}), then collect final log ZIP, "
                    "artifact metadata/archives, digests and exact stdout counts."
                )
    lines.extend([
        "",
        "Normal Rust and rustdoc totals are separate. Python discovery is not added to wrapper/helper "
        "runs; full per-step counts and named records are in `summary.json` and `inventories/`. "
        "These are recorded stdout inventories, not a new local `--list` run. API metadata binds "
        "every job and artifact to the exact run SHA; log checkout lines and the SSH source-head "
        "receipt provide additional recorded source evidence.",
        "",
        "Quality Python main discovery uses quiet output: run/skip totals are available, but "
        "individual Python names are not. Completed Quality plaintext logs are preserved while "
        "command-group boundaries identify each test step. "
        + ("The final Quality run ZIP is retained."
           if summary["all_runs_terminal"] else
           "The final Quality run ZIP remains pending until the run completes."),
        "",
        "| Raw ZIP | Bytes | SHA-256 | API digest |",
        "| --- | ---: | --- | --- |",
    ])
    for archive in summary["archives"]:
        if not archive["path"].endswith(".zip"):
            continue
        lines.append(
            f"| `{archive['path']}` | {archive.get('bytes', 'UNKNOWN')} | "
            f"`{archive.get('sha256', 'UNKNOWN')}` | "
            + ("matches" if archive.get("digest_matches_api") else
               "not supplied for log archives") + " |"
        )
    lines.extend([
        "",
        f"Retained {summary['archive_zip_count']} raw ZIPs with "
        f"{summary['archive_member_count']} members. ZIP CRCs and artifact API digests "
        f"are checked. Failed jobs observed: {len(summary['failed_jobs_observed'])}; "
        f"inventory discrepancies: {len(summary['inventory_mismatches'])}; "
        f"offline evidence checks: {verification['checks_passed']} passed / "
        f"{verification['checks_failed']} failed. No independent code review was performed.",
        "",
        f"API request receipts: {len(receipts)}; prior retrieval failures: {len(request_failures)} "
        f"({sum(x['recovered'] for x in request_failures)} recovered). "
        "The initial completed-macOS plaintext download was rejected by gh's terminal-escape "
        "guard; its failed receipt is retained. The raw-byte retry explicitly allowed escape "
        "sequences. This collection error is separate from CI job conclusions.",
        "",
        "The API workflow's isolated-SSH prerequisite job remains skipped, and its direct API "
        "artifact reports `ssh=UNRUN`. Its three Python skips are non-Windows negative cases; "
        "the actual OpenSSH job's one Python skip has the same boundary. The separate OpenSSH "
        "artifact records one executed native SSH test, four production collector operations "
        "with exit0, and 20 non-master original objects naturally terminal. Their recorded "
        "exit codes include 255 and 1, so they are not described as all exit0. The earlier "
        "seal is HOLD with the master alive; cleanup is PASS with active objects and owned "
        "handles zero, while the master has cleanup exit125. Both states are preserved.",
        "",
        "Workflow/API success alone does not establish artifact content or GUI acceptance. "
        "Both Windows artifacts record `native_gui=UNRUN`. GUI, IME, accessibility, installation, "
        "signing, notarization, releases and complete product acceptance remain unverified. "
        "Controller gates and ignored tests retain their recorded scope.",
        "",
        "The macOS and Ubuntu OpenSSH artifacts each contain 18 interoperability and 6 forwarding "
        "passes with matching named stdout counts. Their cleanup receipts certify observed "
        "ancestry with kernel birth identity checks; entirely detached descendants between "
        "observations remain outside that proof.",
        "",
        "All output stays in this new directory. Only bounded `gh api` GETs and offline parsing "
        "were used; no reruns, cancellations, source work, docs writes, git mutations, local "
        "cargo/tests/builds, shared-target access, MCP inspection, or child agents. Raw ZIPs "
        "are unchanged. Authentication headers, tokens, credential helpers and environment "
        "values were not recorded; the retained payload scan found no GitHub token/private-key markers.",
        "",
    ])
    if remaining:
        lines.extend([
            "Collection stops at the requested approximately 15-minute bound; pending results "
            "are UNKNOWN, not failures or successes. Remaining work:",
            "",
            *remaining,
            "",
            "The parent can resume the read-only collector with `python3 collect.py --snapshot`, "
            "then `python3 analyze.py` and `python3 finalize.py`, from this directory.",
            "",
        ])
    else:
        lines.extend([
            "All requested runs reached natural terminal states. No further CI polling remains "
            "for these exact run IDs. The parent owns archiving, committing and closing the sidecar.",
            "",
        ])
    lines.extend([
        "Evidence map: `snapshots/` contains exact API responses and per-request receipts; "
        "`artifacts/` contains individual artifact API metadata; `archive-bindings.json` binds "
        "archives to source/run/attempt; `archive-manifest.json` lists per-member SHA-256; "
        "`inventories/` retains per-test records; `verification.json` records offline checks. "
        "`SHA256SUMS` covers every file except itself.",
        "",
    ])
    (ROOT / "README.md").write_text("\n".join(lines))
    paths = sorted(p for p in ROOT.rglob("*") if p.is_file() and p.name != "SHA256SUMS")
    (ROOT / "SHA256SUMS").write_text(
        "".join(f"{sha(p)}  {p.relative_to(ROOT)}\n" for p in paths)
    )
    print(json.dumps({
        "source_sha": source,
        "all_terminal": summary["all_runs_terminal"],
        "file_count_including_checksums": len(paths) + 1,
        "total_bytes": sum(p.stat().st_size for p in paths) + (ROOT / "SHA256SUMS").stat().st_size,
        "checks_passed": verification["checks_passed"],
        "checks_failed": verification["checks_failed"],
        "request_receipts": len(receipts),
        "sha256": {
            name: sha(ROOT / name)
            for name in ("summary.json", "README.md", "archive-manifest.json", "SHA256SUMS")
        },
    }), flush=True)


if __name__ == "__main__":
    main()
