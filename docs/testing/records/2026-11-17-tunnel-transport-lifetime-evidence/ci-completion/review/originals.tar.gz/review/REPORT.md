旧工程 CI 终态原件独立复核 · 2026-11-17

**结论：限定 APPROVE。** 仅批准工程 `cdf1e171f2f9b179f09db230f4739696d02fe80d` 的三个指定 CI 运行、原始 ZIP/API 回执和精确封存的证据完整性与所记录结果。P0=0、P1=0、P2=0；历史 P3=1，已由实际读回的外层说明与完整 manifest 关闭，当前未关闭 P0/P1/P2/P3 均为 0。此结论可用于交付文档封存，不授予新工程、原生 GUI、发行或完整产品验收。

本 reviewer 为独立非作者；未导入或执行 collector 的 collect/analyze/finalize 工装，未调用产品、测试二进制或 Rust 工具链。已先读 AGENTS.md、RTK 和 docs/HANDOFF.md；当前用户指定的只读范围覆盖常规工程验证要求。写入仅位于 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/tunnel-ci-final-review-20261117`。未等待父级新提交或构建，未检查新 MCP、f910 的 CI、macOS 包或原生操作。

**原件、来源与外层封存。** 冻结输入为 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/tunnel-ci-completion-20261117`，独立枚举 314 文件、7,314,736 逻辑字节；前后逐文件 size/SHA-256/mtime 相等。外层 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/testing/records/2026-11-17-tunnel-transport-lifetime-evidence/ci-completion/originals.tar.gz` 为 2,046,994 字节，SHA-256：

`88c25669ca00d7d0a6f6609ecad08e57feffcc06ac0c523248428615abccc4e2`

从 TAR 流逐件读取，314 件均为常规文件、名称唯一且无路径逃逸；成员路径、大小与 SHA-256 分别等于外层 manifest 和冻结输入，覆盖两个 SHA256SUMS，无排除项。未解包或修改原件。外层 README 是新增更正说明，位于 314 成员封存之外，已单独读回并摘要为 `238a9571587cf0aeb0a1a7ea920e92e95a1aec350e2c4bace32ec1d5a0b11127`。

来源链从 raw API `snapshots/001` 至 `snapshots/014` 的 14 组观察独立重建。三个 run、六个 job、四个 artifact 均核对 repository `cyruss648/keelshell`、run id、attempt 1、head_sha 与对应对象；所有最终成功 job 的 API step 集与 ZIP 内逐步日志集相等，checkout 日志均含精确旧工程 SHA。140 个 GET 回执逐一核对载荷大小和摘要：139 次 exit0，1 次历史 exit1 为 macOS 明文日志的 terminal-escape guard，原失败回执保留；允许原始 escape 的后续下载成功，其字节又与最终 Quality ZIP 的 macOS 完整 job 日志相等。Ubuntu 明文日志与最终 ZIP 也相等。本 reviewer 的网络请求为 0。

| Workflow | run id | 最终 API 状态 | 终态更新时间 UTC |
| --- | --- | --- | --- |
| Quality | `44020265369` | completed/success；三平台 job success | 2026-11-17 05:31:43 |
| Windows monitor integration | `44020265273` | completed/success；API job success；isolated-SSH job skipped | 2026-11-17 04:56:28 |
| Windows OpenSSH monitor integration | `44020265248` | completed/success | 2026-11-17 04:56:46 |

最终 snapshot 014 观察为 UTC 2026-11-17 05:43:37。保留 API 记录中未见 failure/cancelled/timed_out job，最终 step 也均 completed/success 或按条件 skipped；run 均为 push、attempt 1。本次未 rerun/cancel 或控制 CI。上述“自然终态”指原件记录的成功完成过程，不声称离线 JSON 能证明服务端所有未提供事件的绝对不存在。历史 bounded snapshot 中 Quality 仍为 in_progress、conclusion=null 的状态继续原字节保留。

**独立逐名库存与 summary。** 直接解析每个 ZIP 的逐步日志，剥离时间戳/ANSI 仅用于解析，摘要仍针对原字节。每个 libtest suite 的 running 声明、全部名称/状态/ignored 原因、summary、filtered 数及行号，均与父级 inventory 逐项相等；再独立对照 summary 的分步和普通 Rust/rustdoc 总数。

| Quality 平台 / job | 普通 Rust passed/failed/ignored | 普通套件 / 名称记录 | rustdoc passed / 套件 | Python 主 run/skipped |
| --- | --- | --- | --- | --- |
| native (windows-2025) / `133827817935` | 3422/0/66 | 95 / 3488 | 14 / 6 | 526/53 |
| native (ubuntu-24.04) / `133827818182` | 3428/0/69 | 95 / 3497 | 14 / 6 | 526/3 |
| native (macos-26) / `133827818303` | 3435/0/68 | 95 / 3503 | 14 / 6 | 526/3 |

跨三个独立平台执行，共 285 普通 suite、10,488 个逐名记录，其中 10,285 passed、0 failed、203 ignored；rustdoc 为 18 suite、42 passed。这是执行记录总量，不是跨平台去重的唯一用例数。各平台 526 的 Python 主 discovery 为 quiet 输出，逐名不可得；Windows 可推知 473 非 skip、macOS/Ubuntu 各 523，未将 526 写成全通过。

包装 Python 为三个 57 run，Windows skip4、另两平台 skip0；macOS/Ubuntu 另各有内嵌 helper 30 run/0 skip，均独立逐名核对。三个 Quality 的 readiness-error、observer-io-error、small-stack controller 调用和完成记录单列，不伪造为普通 libtest 数；Windows 的三个 preflight 分别 70/0/0、41/0/0、461/0/3，未叠加到普通 95 套件。

API job 的 Python lab 为 111 run=108 ok+3 skipped，111 个名称相等；公共认证路由 capture replay 为 Rust 1 passed/0 failed/0 ignored、9 filtered。其 isolated-SSH job `133827819414` 仍 skipped，无执行库存；不能由 workflow success 关闭该 HOLD。三个 skip 均为日志明确的 negative non-Windows boundary。

真实 Windows SSH job 的 Python 为 96 run=95 ok+1 skipped，96 个名称相等；其 skip 同为 negative non-Windows boundary。artifact 的 `native-ssh-client.stdout` 为真实 SSH Rust 1 passed，名称与原 `live-test-inventory.stdout` 和 `test-binary.json` 的单项库存完全相等。这里只核对已记录二进制摘要/库存，不在本机执行二进制或验证其实体。

macOS/Ubuntu artifact 各含 interop 18 和 forwarding 6 passed，合计 48 个逐名记录；其 result.passed_tests、tests.log、所有 step.returncode 和日志 byte 数均相等。Unix cleanup 记录已观察进程停止、owned 停止、临时目录删除，ancestry_unverified 为空；保留“仅累积 ancestry 与 kernel birth identity、观测之间完全脱离后代不能认证”的边界。

**ZIP 与 artifact digest。** 7 ZIP 的 CRC 均通过，172 成员的完整路径、大小、SHA-256 与 archive-manifest 精确一致。4 个 artifact 的压缩字节大小、SHA-256 与个别 API metadata 及最终 artifact 列表一致。run-log ZIP 无服务端 digest，仅有本地原字节与下载回执的 SHA-256。

| ZIP | 压缩 bytes | 成员 | 独立 SHA-256 | 外部摘要 |
| --- | ---: | ---: | --- | --- |
| `artifact-14300447980.zip` | 53908 | 46 | `1663513c81ac54069e04a008f7e51677cb897a2656792a9a927c021eab711398` | API digest 相等 |
| `artifact-14300944839.zip` | 5604 | 14 | `e821363873da9bbaf0b5903007dd4fc581bc6fa146f8025df559b578c804bfbb` | API digest 相等 |
| `artifact-14301275329.zip` | 46378 | 34 | `de56cee2b72e9801ee6b7117b147862402ce0b0f6777b2f24e60f1bf51a96b22` | API digest 相等 |
| `artifact-14302006704.zip` | 5522 | 14 | `cf8d8f514416d35aadc99cce5118939fefb3b013725bf00dda5995a70f93a6ef` | API digest 相等 |
| `run-44020265248-attempt-1-logs.zip` | 33117 | 12 | `9450f9120045d9a6ed8b0d531cd230c062ce09e9d3b497bd62977097b3996f97` | API 未提供 digest |
| `run-44020265273-attempt-1-logs.zip` | 33355 | 12 | `f2a7c4549665cbee1436bfca348b208399b07be8c703ed51e3e7064843ce107b` | API 未提供 digest |
| `run-44020265369-attempt-1-logs.zip` | 1036337 | 40 | `51f46c97f5ad262fa8cf7688f23c16ecc67965a8bac393247764659f9e2b5850` | API 未提供 digest |

**原对象自然终态与清理边界。** 从 Windows SSH artifact 独立按 `(pid, creation_time)` 核对 21 原对象和 admission/census，而非仅比较 21=21。所有对象均有 first-instruction 前 retained/bound，完整 census、admission closed，无未绑定对象或 fallback detach，debug events 全部 continued。20 个非 master 对象在清理前已自然终态，完整记录前后相等：14 个 exit0、5 个 exit255、1 个 exit1。

| 原件阶段 | state / terminal_proven | active / pending | owned handles | closed | 解释 |
| --- | --- | --- | ---: | --- | --- |
| `ssh-debug-originals.json` | HOLD / false | 1 / 1 | 22 | false | master 仍存活，exit=null，保留原 HOLD |
| `owned-sshd.receipt.json` 内嵌对象 | PASS / true | 0 / 0 | 22 | false | 对象终态已证，handle 清理尚未闭合；observed_exit=null |
| `ssh-debug-cleanup.json` | PASS / true | 0 / 0 | 0 | true | 最终 debug connection/owned handle 归零，master cleanup exit125 |

master 不是清理前自然终态，其 cleanup exit125 不改写为自然 exit0；owned server 的 observed_exit=null 也继续保留。对象终态、直接 reaped、pipe drained 和 handle 最终关闭是分别核对的条件，不能用中间 PASS 或最外层 exit0 代签全部清理。

四个生产操作 probe/resources/processes/sockets 均绑定 exact 原 PowerShell 对象的 birth identity，记录自然 exit0；其 EncodedCommand 按旧 Git 中 common.ps1/operation.ps1 原字节重新组装、UTF-16LE/Base64 后逐参数比对。另一个 direct API artifact 的五份 wire（含 resources-skipped）也逐字节等于重建结果。原 Windows command_line 在 argv0 后保留双空格，已验证只有该 separator 差异，六个固定 argv 和整个编码 payload 精确相同，不宽松折叠 payload。最终私钥临时目录删除、未上传私钥或私有 client config。

关键原件位置为 `downloads/artifact-14300447980.zip::ssh-debug-originals.json:3,323,351`、`::owned-sshd.receipt.json:3,357,358` 与 `::ssh-debug-cleanup.json:3,323,349,350`；`artifact-14300447980.zip::receipt.json:6` 和 `artifact-14301275329.zip::receipt.json:14,15` 保留 native_gui=UNRUN、direct ssh=UNRUN。

**旧工程 Git 输入绑定。** 只执行两个本地只读 Git 读取：`git ls-tree -rz cdf1e171f2f9b179f09db230f4739696d02fe80d` 和 `git cat-file --batch`；均设置 GIT_OPTIONAL_LOCKS=0、GIT_NO_LAZY_FETCH=1，均 exit0，未 fetch。769 输入的路径集合等于旧工程所有非 docs tracked 路径，各 Git blob 的字节数/SHA-256 与 source-inputs 清单相等。重算 aggregate：

`83e2e1b00ba4d373a407030c79538f8a5039347931236344315ad8b70844a5b7`

`source-inputs.json.head` 的 `660645fbe77cee2b8af2740f3277a70e9f968048` 是保留的采集基线元数据；本次没有将其当作 CI 工程，而是按 `cdf1e171f2f9b179f09db230f4739696d02fe80d` 的 769 个实际 blob 重新绑定。当前 HEAD、新 777 输入和父级后续 Git 交付均在范围外。

**发现与严重度。**

| 级别 | 发现总数 | 未关闭 | 状态 |
| --- | ---: | ---: | --- |
| P0 | 0 | 0 | 无 |
| P1 | 0 | 0 | 无 |
| P2 | 0 | 0 | 无 |
| P3 | 1 | 0 | CI-EVIDENCE-P3-001：历史 checksum 覆盖表述/计数，外层说明已实际纠正 |

P3 证据：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/tunnel-ci-completion-20261117/README.md:43` 声称 SHA256SUMS 除自身覆盖全部；`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/tunnel-ci-completion-20261117/finalize.py:276` 按 basename 排除了所有 SHA256SUMS，`:283` 又以 rows+1 报文件数。独立枚举实为 314 件，根表 312 条，未列根自身及 `bounded-snapshot-052139/SHA256SUMS`；根表+自身只有 313 件，不能当作全部输入。影响是只读根表时对历史 checksum 文件少覆盖一件，不是 ZIP/API 原件篡改。

关闭依据：外层 manifest 的第 16/94 行分别列两个 checksum，314 个 TAR 成员与两个 manifest/原输入全部相等，新增 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/docs/testing/records/2026-11-17-tunnel-transport-lifetime-evidence/ci-completion/README.md` 已明确“312 条/314 件”与原 README 的更正。历史 collector 工装/README/快照保持原字节。本项记为已关闭的历史 P3，不冒称原 collector 从来无误。

**执行结果与保留失败。** 独立工装 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/tunnel-ci-final-review-20261117/audit.py` 的 r2 exit0，**13,543 项离线一致性检查通过、0 失败**；这里的检查数量不是产品测试数量。详细逐项检查与逐名库存位于 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/tunnel-ci-final-review-20261117/audit-r2.json`，简明机器结论为 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/tunnel-ci-final-review-20261117/review-result.json`。

审计 r1 exit1，13,535 pass/4 fail，仅因 reviewer 首版对 command_line 要求 canonical 单空格子串，未接受原 Win32 argv0 双空格。失败原件 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/tunnel-ci-final-review-20261117/audit-r1.json` 保留。修正仅发生于本 review 工装，r2 按固定六 argv 与完整 EncodedCommand 核对；未修改任何产品/输入，也未将这一工装失败记为 CI 失败。collector 自己的 77 项检查只是被复核的输入，不用于代替本次独立复算。

本 reviewer 网络 0、Cargo/rustc 0、产品测试/二进制运行 0、共享 target 访问 0、源码/docs/输入写入 0、Git mutation 0、child agent 0。未清理其他目录、未提交/推送。父级管理后续封存与关闭 reviewer。

**验收范围与未验边界。** 本次批准上述旧工程的保留 CI 原件、计数、digest、Git 绑定与所记录自然终态/最终清理证据。两 Windows artifact 均 native_gui=UNRUN；API isolated-SSH skipped 与 ssh=UNRUN 保持；quiet Python 主 discovery 逐名不可得，当前二进制 `--list` 未执行。原生 GUI、IME、辅助技术、安装、签名、公证、发行与完整产品验收均 HOLD/未验证，新 MCP 与 f910 CI/包/解锁桌面观察不在范围内。离线 API 文件的内容一致性不等于重新向 GitHub 取证或服务端签名认证。其他历史 UNKNOWN/FAIL 不从此批 success 追认关闭。
