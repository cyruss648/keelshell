#!/usr/bin/env python3
"""Offline, independent audit of archived CI evidence; writes only beside this file."""

import argparse
import base64
from collections import Counter
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import tarfile
import zipfile


OUT = Path(__file__).resolve().parent
ROOT = OUT.parent.parent
SRC = ROOT / "work/tunnel-ci-completion-20261117"
SEAL = ROOT / "docs/testing/records/2026-11-17-tunnel-transport-lifetime-evidence/ci-completion"
SHA = "cdf1e171f2f9b179f09db230f4739696d02fe80d"
TAR_SHA = "88c25669ca00d7d0a6f6609ecad08e57feffcc06ac0c523248428615abccc4e2"
REPO = "cyruss648/keelshell"
RUNS = (44020265369, 44020265273, 44020265248)
JOBS = {
    44020265369: {
        133827817935: "native (windows-2025)",
        133827818182: "native (ubuntu-24.04)",
        133827818303: "native (macos-26)",
    },
    44020265273: {
        133827817731: "Actual collectors and independent Windows APIs",
        133827819414: "Isolated OpenSSH prerequisites (HOLD until terminal proof)",
    },
    44020265248: {
        133827817472: "Actual Windows OpenSSH and original remote processes",
    },
}
ART_RUNS = {
    14300447980: 44020265248,
    14301275329: 44020265273,
    14300944839: 44020265369,
    14302006704: 44020265369,
}
ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
STAMP = re.compile(r"^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d+Z ?")
RUST_END = re.compile(
    r"^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; "
    r"(\d+) ignored; (\d+) measured; (\d+) filtered out;"
)
CHECKS = []
GIT_COMMANDS = []
MEMBERS = {}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def load(path):
    return json.loads(path.read_text())


def emit(name, value):
    target = OUT / name
    if target.parent != OUT:
        raise ValueError("audit output must stay in the assigned directory")
    target.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def check(name, condition, detail=None):
    row = {"name": name, "passed": bool(condition)}
    if detail is not None:
        row["detail"] = detail
    CHECKS.append(row)


def same(name, actual, expected):
    check(name, actual == expected, None if actual == expected else {"actual": actual, "expected": expected})


def safe_relative(name):
    path = PurePosixPath(name)
    return bool(name) and not path.is_absolute() and ".." not in path.parts and "\\" not in name


def git_read(args, stdin=None):
    env = os.environ.copy()
    env["GIT_OPTIONAL_LOCKS"] = "0"
    env["GIT_NO_LAZY_FETCH"] = "1"
    command = ["git", *args]
    result = subprocess.run(
        command, cwd=ROOT, env=env, input=stdin,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=55, check=False,
    )
    GIT_COMMANDS.append({
        "argv": command, "exit_code": result.returncode,
        "stdout_bytes": len(result.stdout), "stdout_sha256": digest(result.stdout),
        "stderr_bytes": len(result.stderr), "offline": True,
    })
    check("read-only Git command " + args[0], result.returncode == 0)
    if result.returncode:
        raise RuntimeError("local Git object read failed")
    return result.stdout


def normalized(raw):
    return [STAMP.sub("", ANSI.sub("", line)).rstrip("\r") for line in raw.decode("utf-8-sig").splitlines()]


def parse_log(raw, label):
    """Parse libtest and unittest records directly; no parent parser is imported."""
    lines = normalized(raw)
    suites, python, py_names, controllers, commands = [], [], [], [], []
    active = None
    heading = ""
    pending_py = None
    for number, text in enumerate(lines, 1):
        if re.match(r"^\s*(?:Running (?:unittests |tests[/\\])|Doc-tests )", text):
            heading = text.strip()
        if text.startswith("Running: "):
            commands.append({"line": number, "command": text[9:]})
        if "all assertions/scenario groups passed" in text:
            controllers.append({"line": number, "kind": "assertions_complete", "text": text})
        if text.startswith("controller-stage "):
            try:
                event = json.loads(text[len("controller-stage "):])
            except json.JSONDecodeError:
                check(label + f": controller event JSON at {number}", False)
            else:
                if event.get("stage") == "controller" and event.get("phase") == "end":
                    controllers.append({"line": number, "kind": "controller_end", "mode": event.get("mode")})
        declaration = re.fullmatch(r"running (\d+) tests?", text)
        if declaration:
            check(label + f": no unfinished Rust suite at {number}", active is None)
            active = {
                "heading": heading, "doctest": heading.startswith("Doc-tests "),
                "declared": int(declaration[1]), "start_line": number, "names": [],
            }
            continue
        rust_name = re.fullmatch(r"test (.+?) \.\.\. (ok|FAILED|ignored)(?:, (.*))?", text)
        if rust_name and active is not None:
            active["names"].append({
                "name": rust_name[1], "status": rust_name[2],
                "reason": rust_name[3], "line": number,
            })
            continue
        end = RUST_END.match(text)
        if end:
            check(label + f": summary has declared suite at {number}", active is not None)
            if active is None:
                continue
            active.update(dict(zip(
                ["passed", "failed", "ignored", "measured", "filtered_out"],
                map(int, end.groups()[1:]),
            )))
            active["outcome"] = end[1]
            active["end_line"] = number
            counts = Counter(n["status"] for n in active["names"])
            same(label + f": Rust declaration {number}",
                 active["declared"], sum(active[k] for k in ("passed", "failed", "ignored", "measured")))
            same(label + f": Rust named counts {number}",
                 [counts["ok"], counts["FAILED"], counts["ignored"]],
                 [active["passed"], active["failed"], active["ignored"]])
            same(label + f": unique names within suite {number}",
                 len({n["name"] for n in active["names"]}), len(active["names"]))
            check(label + f": Rust recorded success {number}", end[1] == "ok" and active["failed"] == 0)
            suites.append(active)
            active = None
            continue
        py_name = re.fullmatch(
            r"(test\S+)\s+\(([^)]+)\)\s+\.\.\. "
            r"(ok|skipped(?: .*)?|expected failure|unexpected success|FAIL|ERROR)", text,
        )
        if py_name:
            status = "skipped" if py_name[3].startswith("skipped") else py_name[3]
            py_names.append({"name": py_name[1], "id": py_name[2], "status": status, "detail": py_name[3], "line": number})
        ran = re.fullmatch(r"Ran (\d+) tests? in .+", text)
        if ran:
            check(label + f": prior Python summary finished at {number}", pending_py is None)
            pending_py = {"run": int(ran[1]), "summary_line": number, "names": py_names}
            py_names = []
        outcome = re.fullmatch(r"(OK(?: \(([^)]*)\))?|FAILED(?: \(([^)]*)\))?)", text)
        if outcome and pending_py is not None:
            detail = outcome[2] or outcome[3] or ""
            counters = {k: int(v) for k, v in re.findall(r"(\w+)=(\d+)", detail)}
            pending_py.update({
                "outcome": text, "skipped": counters.get("skipped", 0),
                "passed_inferred_from_success": pending_py["run"] - counters.get("skipped", 0),
                "outcome_line": number,
            })
            check(label + f": Python recorded success {number}", text.startswith("OK"))
            if pending_py["names"]:
                same(label + f": Python named total {number}", len(pending_py["names"]), pending_py["run"])
                same(label + f": Python named skips {number}",
                     sum(n["status"] == "skipped" for n in pending_py["names"]), pending_py["skipped"])
                check(label + f": Python named statuses {number}",
                      all(n["status"] in ("ok", "skipped") for n in pending_py["names"]))
            python.append(pending_py)
            pending_py = None
    check(label + ": no unfinished Rust declaration", active is None)
    check(label + ": no unfinished Python summary", pending_py is None)
    check(label + ": no orphan Python named records", not py_names)
    return {
        "raw_sha256": digest(raw), "raw_bytes": len(raw), "line_count": len(lines),
        "source_sha_literal_present": SHA in raw.decode("utf-8-sig"),
        "rust": suites, "python": python, "controller_completions": controllers, "commands": commands,
    }


def compare_inventory(actual, claimed, label):
    for key in ("raw_sha256", "raw_bytes", "line_count", "source_sha_literal_present"):
        same(label + ": " + key, actual[key], claimed[key])
    same(label + ": Rust suite count", len(actual["rust"]), len(claimed["rust"]))
    for index, (a, b) in enumerate(zip(actual["rust"], claimed["rust"])):
        for key in ("declared", "doctest", "passed", "failed", "ignored", "measured", "filtered_out", "start_line", "end_line"):
            same(label + f": suite {index} {key}", a[key], b[key])
        same(label + f": suite {index} complete named inventory", a["names"], b["names"])
    same(label + ": Python run count", len(actual["python"]), len(claimed["python"]))
    for index, (a, b) in enumerate(zip(actual["python"], claimed["python"])):
        for key in ("run", "skipped", "outcome", "passed_inferred_from_success", "summary_line", "names"):
            same(label + f": Python {index} {key}", a[key], b[key])


def totals(suites, doctest):
    selected = [s for s in suites if s["doctest"] is doctest]
    result = {"suites": len(selected)}
    for key in ("passed", "failed", "ignored", "measured", "filtered_out"):
        result[key] = sum(s[key] for s in selected)
    result["declared_total"] = sum(s["declared"] for s in selected)
    result["named_total"] = sum(len(s["names"]) for s in selected)
    return result


def input_files():
    rows = []
    for path in sorted(SRC.rglob("*")):
        if path.is_symlink():
            raise ValueError("input contains a symlink")
        if path.is_file():
            data = path.read_bytes()
            rows.append({
                "path": path.relative_to(SRC).as_posix(), "size": len(data),
                "sha256": digest(data), "mtime_ns": path.stat().st_mtime_ns,
            })
    return rows


def audit():
    baseline = load(OUT / "input-baseline.json")["files"]
    same("initial input bytes and mtimes unchanged", input_files(), baseline)
    baseline_by_name = {r["path"]: r for r in baseline}
    same("input file count", len(baseline), 314)
    same("input logical bytes", sum(r["size"] for r in baseline), 7314736)

    root_rows = []
    for line in (SRC / "SHA256SUMS").read_text().splitlines():
        checksum, path = line.split("  ", 1)
        check("root checksum safe path " + path, safe_relative(path))
        same("root checksum " + path, digest((SRC / path).read_bytes()), checksum)
        root_rows.append(path)
    same("root checksum unique rows", len(set(root_rows)), len(root_rows))
    same("root checksum row count", len(root_rows), 312)
    omitted = sorted(set(baseline_by_name) - set(root_rows))
    same("root checksum precise omissions", omitted, ["SHA256SUMS", "bounded-snapshot-052139/SHA256SUMS"])
    check("historical README overstatement retained",
          "SHA256SUMS` covers every file except itself." in (SRC / "README.md").read_text())

    seal = load(SEAL / "manifest.json")
    archive = (SEAL / "originals.tar.gz").read_bytes()
    same("external archive SHA supplied by parent", digest(archive), TAR_SHA)
    same("external archive SHA in exact manifest", digest(archive), seal["sha256"])
    same("external archive compressed bytes", len(archive), seal["bytes"])
    same("external manifest member count", seal["members"], 314)
    same("external manifest logical bytes", seal["logical_bytes"], 7314736)
    same("external manifest exclusions", seal["excluded"], [])
    seal_rows = {r["member"]: r for r in seal["files"]}
    same("external manifest unique names", len(seal_rows), 314)
    same("external manifest versus input path set", set(seal_rows), set(baseline_by_name))
    with tarfile.open(fileobj=io.BytesIO(archive), mode="r:gz") as tar:
        entries = tar.getmembers()
        same("external TAR unique members", len({m.name for m in entries}), len(entries))
        same("external TAR member count", len(entries), 314)
        same("external TAR logical bytes", sum(m.size for m in entries), 7314736)
        same("external TAR versus exact manifest path set", set(m.name for m in entries), set(seal_rows))
        for member in entries:
            check("external TAR regular safe member " + member.name, member.isfile() and safe_relative(member.name))
            data = tar.extractfile(member).read()
            row = seal_rows[member.name]
            same("external TAR member SHA " + member.name, digest(data), row["sha256"])
            same("external TAR member size " + member.name, len(data), row["bytes"])
            same("external TAR member versus frozen input " + member.name, digest(data), baseline_by_name[member.name]["sha256"])
            same("external manifest source " + member.name, row["source"], "work/tunnel-ci-completion-20261117/" + member.name)

    source = load(SRC / "source-inputs.json")
    inputs = source["inputs"]
    same("old engineering input count", len(inputs), 769)
    same("old engineering unique inputs", len({r["path"] for r in inputs}), 769)
    aggregate = digest(json.dumps(inputs, sort_keys=True, separators=(",", ":")).encode())
    same("old engineering input aggregate", aggregate, source["aggregate_sha256"])
    same("old engineering aggregate expected",
         aggregate, "83e2e1b00ba4d373a407030c79538f8a5039347931236344315ad8b70844a5b7")
    binding = load(SRC / "source-input-binding.json")
    same("source input binding exact SHA", binding["source"], SHA)
    same("source input binding aggregate", binding["aggregate_sha256"], aggregate)
    same("source input binding count", binding["engineering_inputs"], 769)
    tree_raw = git_read(["ls-tree", "-rz", SHA])
    tree = {}
    for entry in tree_raw.split(b"\0"):
        if not entry:
            continue
        metadata, filename = entry.split(b"\t", 1)
        mode, kind, oid = metadata.decode().split()
        tree[filename.decode()] = {"mode": mode, "kind": kind, "oid": oid}
    same("old engineering manifest covers all non-docs tracked paths",
         {r["path"] for r in inputs}, {p for p in tree if not p.startswith("docs/")})
    batch_input = "".join(SHA + ":" + r["path"] + "\n" for r in inputs).encode()
    batch = io.BytesIO(git_read(["cat-file", "--batch"], batch_input))
    source_bytes, git_rows = {}, []
    for row in inputs:
        header = batch.readline().decode().strip().split()
        if len(header) != 3 or header[1] != "blob":
            raise RuntimeError("missing local old engineering Git blob")
        oid, kind, size = header
        data = batch.read(int(size))
        same("Git blob record delimiter " + row["path"], batch.read(1), b"\n")
        same("Git exact old source byte count " + row["path"], len(data), row["bytes"])
        same("Git exact old source SHA256 " + row["path"], digest(data), row["sha256"])
        same("Git tree object binding " + row["path"], oid, tree[row["path"]]["oid"])
        source_bytes[row["path"]] = data
        git_rows.append({"path": row["path"], "git_blob": oid, "bytes": len(data), "sha256": digest(data)})
    same("Git batch fully consumed", batch.read(), b"")

    receipts, receipt_failures = [], []
    for path in sorted(SRC.rglob("*.json")):
        obj = load(path)
        if not isinstance(obj, dict) or "endpoint" not in obj or "method" not in obj:
            continue
        rel = path.relative_to(SRC).as_posix()
        check("API GET receipt " + rel, obj["method"] == "GET")
        check("API repository endpoint " + rel, obj["endpoint"].startswith("repos/" + REPO + "/actions/"))
        if "reaped" in obj:
            check("API subprocess reaped " + rel, obj["reaped"] and not obj["timed_out"])
        receipt_row = {"receipt": rel, "path": obj["path"], "endpoint": obj["endpoint"], "exit_code": obj["exit_code"]}
        receipts.append(receipt_row)
        if obj["exit_code"] == 0:
            check("API receipt safe payload path " + rel, safe_relative(obj["path"]))
            data = (SRC / obj["path"]).read_bytes()
            same("API payload SHA " + rel, digest(data), obj["sha256"])
            same("API payload size " + rel, len(data), obj["bytes"])
        else:
            receipt_failures.append({**receipt_row, "error": obj.get("error")})
    same("API receipt count", len(receipts), 140)
    same("historical retrieval failure count", len(receipt_failures), 1)
    same("historical retrieval failure preserved",
         receipt_failures[0]["exit_code"], 1)
    check("historical retrieval failure was terminal escape guard",
          "terminal escape sequences" in receipt_failures[0]["error"])

    snapshots = sorted(p for p in (SRC / "snapshots").iterdir() if p.is_dir())
    same("API snapshot count", len(snapshots), 14)
    final_snapshot = snapshots[-1]
    same("latest snapshot independently enumerated", final_snapshot.name, "014")
    same("latest.json snapshot pointer", load(SRC / "latest.json")["snapshot"], "snapshots/014")
    runs, history, final_artifacts = [], [], {}
    for snapshot in snapshots:
        for run_id in RUNS:
            run = load(snapshot / f"{run_id}-run.json")
            jobs = load(snapshot / f"{run_id}-jobs.json")
            artifacts = load(snapshot / f"{run_id}-artifacts.json")
            label = f"API snapshot {snapshot.name} run {run_id}"
            same(label + " exact id", run["id"], run_id)
            same(label + " source", run["head_sha"], SHA)
            same(label + " attempt", run["run_attempt"], 1)
            same(label + " repository", run["repository"]["full_name"], REPO)
            same(label + " job cardinality", jobs["total_count"], len(jobs["jobs"]))
            same(label + " job id set", {j["id"] for j in jobs["jobs"]}, set(JOBS[run_id]))
            same(label + " artifact cardinality", artifacts["total_count"], len(artifacts["artifacts"]))
            for job in jobs["jobs"]:
                same(label + f" job {job['id']} source", job["head_sha"], SHA)
                same(label + f" job {job['id']} run", job["run_id"], run_id)
                same(label + f" job {job['id']} attempt", job["run_attempt"], 1)
                same(label + f" job {job['id']} name", job["name"], JOBS[run_id][job["id"]])
                check(label + f" job {job['id']} no failed conclusion",
                      job["conclusion"] in (None, "success", "skipped"))
            history.append({
                "snapshot": snapshot.name, "run_id": run_id, "status": run["status"],
                "conclusion": run["conclusion"],
                "jobs": [{"id": j["id"], "status": j["status"], "conclusion": j["conclusion"]} for j in jobs["jobs"]],
            })
            if snapshot != final_snapshot:
                continue
            same(label + " natural workflow terminal", (run["status"], run["conclusion"]), ("completed", "success"))
            same(label + " recorded push event", run["event"], "push")
            result_jobs = []
            for job in jobs["jobs"]:
                expected = "skipped" if job["id"] == 133827819414 else "success"
                same(label + f" job {job['id']} natural terminal", (job["status"], job["conclusion"]), ("completed", expected))
                check(label + f" job {job['id']} steps terminal",
                      all(s["status"] == "completed" and s["conclusion"] in ("success", "skipped") for s in job["steps"]))
                result_jobs.append({
                    "id": job["id"], "name": job["name"], "status": job["status"], "conclusion": job["conclusion"],
                    "started_at": job["started_at"], "completed_at": job["completed_at"],
                    "steps": job["steps"],
                })
            runs.append({
                "id": run_id, "name": run["name"], "source_sha": run["head_sha"], "run_attempt": run["run_attempt"],
                "status": run["status"], "conclusion": run["conclusion"], "event": run["event"],
                "created_at": run["created_at"], "updated_at": run["updated_at"],
                "metadata_snapshot": "snapshots/014", "jobs": result_jobs,
            })
            for artifact in artifacts["artifacts"]:
                final_artifacts[artifact["id"]] = artifact
    same("final artifact id set", set(final_artifacts), set(ART_RUNS))

    archive_rows = []
    bindings = {r["path"]: r for r in load(SRC / "archive-bindings.json")}
    manifest = {r["path"]: r for r in load(SRC / "archive-manifest.json")}
    zip_paths = sorted((SRC / "downloads").glob("*.zip"))
    same("independently enumerated raw ZIP count", len(zip_paths), 7)
    same("ZIP versus binding path set", {p.relative_to(SRC).as_posix() for p in zip_paths}, set(bindings))
    total_members = 0
    for path in zip_paths:
        relative = path.relative_to(SRC).as_posix()
        data = path.read_bytes()
        members = {}
        with zipfile.ZipFile(io.BytesIO(data)) as archive_zip:
            same("ZIP CRC " + relative, archive_zip.testzip(), None)
            infos = archive_zip.infolist()
            same("ZIP unique names " + relative, len({i.filename for i in infos}), len(infos))
            for info in infos:
                check("ZIP safe regular member " + relative + "::" + info.filename,
                      safe_relative(info.filename) and not info.is_dir() and (info.external_attr >> 16) & 0o170000 != 0o120000)
                payload = archive_zip.read(info)
                members[info.filename] = payload
            member_rows = [{"path": name, "bytes": len(payload), "sha256": digest(payload)} for name, payload in members.items()]
        MEMBERS[path.name] = members
        row = {"path": relative, "bytes": len(data), "sha256": digest(data), "member_count": len(members), "members": member_rows}
        archive_rows.append(row)
        total_members += len(members)
        for claimed in (bindings[relative], manifest[relative]):
            for key in ("bytes", "sha256"):
                same("ZIP claimed " + key + " " + relative, row[key], claimed[key])
            same("ZIP claimed member count " + relative, len(members), claimed["zip_member_count"])
            same("ZIP claimed old source " + relative, claimed["source_sha"], SHA)
        same("ZIP complete member manifest " + relative, member_rows, manifest[relative]["members"])
        receipt = load(path.with_name(path.name + ".receipt.json"))
        same("ZIP download receipt SHA " + relative, row["sha256"], receipt["sha256"])
        if path.name.startswith("artifact-"):
            aid = int(path.stem.split("-")[1])
            meta = load(SRC / f"artifacts/{aid}.json")
            same("artifact final list equals individual metadata " + str(aid), meta, final_artifacts[aid])
            same("artifact API digest " + str(aid), "sha256:" + row["sha256"], meta["digest"])
            same("artifact API byte size " + str(aid), len(data), meta["size_in_bytes"])
            same("artifact API exact run " + str(aid), meta["workflow_run"]["id"], ART_RUNS[aid])
            same("artifact API exact source " + str(aid), meta["workflow_run"]["head_sha"], SHA)
            same("artifact API unexpired at collection " + str(aid), meta["expired"], False)
            row.update({"artifact_id": aid, "run_id": ART_RUNS[aid], "api_digest": meta["digest"], "api_digest_matches": True})
        else:
            run_id = int(re.search(r"run-(\d+)", path.name)[1])
            row.update({"run_id": run_id, "api_digest": None, "api_digest_boundary": "GitHub supplied no run-log ZIP digest"})
    same("independent raw ZIP total members", total_members, 172)

    summary = load(SRC / "summary.json")
    same("parent summary source", summary["engineering_source_sha"], SHA)
    same("parent summary ZIP count", summary["archive_zip_count"], len(zip_paths))
    same("parent summary ZIP member count", summary["archive_member_count"], total_members)
    same("parent summary terminal flag", summary["all_runs_terminal"], True)
    same("parent summary no reported inventory mismatches", summary["inventory_mismatches"], [])
    inventories = {}
    job_totals = []
    for run in runs:
        claimed_run = next(r for r in summary["runs"] if r["id"] == run["id"])
        for key in ("name", "source_sha", "run_attempt", "status", "conclusion", "created_at", "updated_at", "metadata_snapshot"):
            same(f"summary run {run['id']} {key}", run[key], claimed_run[key])
        for job in run["jobs"]:
            jid = job["id"]
            parent_job = next(j for j in claimed_run["jobs"] if j["id"] == jid)
            for key in ("name", "status", "conclusion", "started_at", "completed_at"):
                same(f"summary job {jid} {key}", job[key], parent_job[key])
            claimed_inventory = load(SRC / f"inventories/job-{jid}.json")
            same(f"named inventory job {jid} source", claimed_inventory["source_sha"], SHA)
            if job["conclusion"] == "skipped":
                same(f"skipped job {jid} no inventory", parent_job["inventory_available"], False)
                job_totals.append({"job_id": jid, "conclusion": "skipped", "tests_executed": 0})
                continue
            zipname = f"run-{run['id']}-attempt-1-logs.zip"
            members = MEMBERS[zipname]
            candidates = {}
            for name, raw in members.items():
                if not name.startswith(job["name"] + "/"):
                    continue
                match = re.fullmatch(r"(\d+)_(.+)\.txt", name.split("/", 1)[1])
                if match:
                    candidates[int(match[1])] = (name, raw, match[2])
            expected_steps = {s["number"] for s in job["steps"] if s["conclusion"] == "success"}
            same(f"job {jid} successful API steps match raw ZIP steps", set(candidates), expected_steps)
            parsed_steps = []
            for number, (name, raw, title) in sorted(candidates.items()):
                label = zipname + "::" + name
                parsed = parse_log(raw, label)
                parsed.update({"number": number, "member": name, "name": title, "archive": "downloads/" + zipname})
                parent_step = next(s for s in claimed_inventory["steps"] if s["number"] == number)
                compare_inventory(parsed, parent_step, label)
                parsed_steps.append(parsed)
                parent_counts = next((s for s in parent_job["step_counts"] if s["number"] == number), None)
                if parsed["rust"] or parsed["python"]:
                    check(label + ": parent summary step exists", parent_counts is not None)
                    if parent_counts:
                        for kind, doctest in (("rust", False), ("rustdoc", True)):
                            calculated = totals(parsed["rust"], doctest)
                            for key, value in calculated.items():
                                same(label + ": parent step " + kind + " " + key, value, parent_counts[kind][key])
                        same(label + ": parent step Python sequence",
                             [(s["run"], s["skipped"], s["outcome"]) for s in parsed["python"]],
                             [(s["run"], s["skipped"], s["outcome"]) for s in parent_counts["python"]])
            same(f"job {jid} parent inventory step set", {s["number"] for s in parsed_steps}, {s["number"] for s in claimed_inventory["steps"]})
            checkout = next(raw for number, (name, raw, title) in candidates.items() if title.startswith("Run actions_checkout@"))
            check(f"job {jid} checkout raw log includes exact SHA", SHA.encode() in checkout)
            inventories[str(jid)] = parsed_steps
            if run["id"] == 44020265369:
                gate = next(s for s in parsed_steps if s["number"] == 8)
                ordinary, docs = totals(gate["rust"], False), totals(gate["rust"], True)
                for key, value in ordinary.items():
                    same(f"Quality {jid} summary ordinary {key}", value, parent_job["ordinary_rust"][key])
                for key, value in docs.items():
                    same(f"Quality {jid} summary rustdoc {key}", value, parent_job["rustdoc"][key])
                same(f"Quality {jid} Python main count", gate["python"][0]["run"], parent_job["python_main"]["run"])
                same(f"Quality {jid} Python main skips", gate["python"][0]["skipped"], parent_job["python_main"]["skipped"])
                same(f"Quality {jid} main Python named unavailable", len(gate["python"][0]["names"]), 0)
                same(f"Quality {jid} ordinary suite count", ordinary["suites"], 95)
                same(f"Quality {jid} rustdoc passed", docs["passed"], 14)
                same(f"Quality {jid} main Python run", gate["python"][0]["run"], 526)
                check(f"Quality {jid} three controller invocation records",
                      all(any(flag in c["command"] for c in gate["commands"])
                          for flag in ("--readiness-error-tests", "--observer-io-error-tests", "--controller-small-stack")))
                job_totals.append({
                    "job_id": jid, "name": job["name"], "ordinary_rust": ordinary, "rustdoc": docs,
                    "python_main": {k: gate["python"][0][k] for k in ("run", "skipped", "passed_inferred_from_success")},
                    "python_main_named_inventory_available": False,
                    "auxiliary_python": [
                        {"step": s["number"], "run": p["run"], "skipped": p["skipped"], "named": len(p["names"])}
                        for s in parsed_steps for p in s["python"]
                        if not (s["number"] == 8 and p is s["python"][0])
                    ],
                    "controller_completions": gate["controller_completions"],
                })
            else:
                job_totals.append({
                    "job_id": jid, "name": job["name"],
                    "python": [{"step": s["number"], "run": p["run"], "skipped": p["skipped"], "named": len(p["names"])}
                               for s in parsed_steps for p in s["python"]],
                    "rust": [totals(s["rust"], False) for s in parsed_steps if s["rust"]],
                })
            if jid in (133827818303, 133827818182):
                plaintext = (SRC / f"downloads/job-{jid}-logs.txt").read_bytes()
                consolidated = next(raw for name, raw in members.items()
                                    if "/" not in name and name.endswith("_" + job["name"] + ".txt"))
                same(f"job {jid} independent plaintext equals final consolidated ZIP log", digest(plaintext), digest(consolidated))

    artifact_inventory = {}
    unix_results = []
    for aid in (14300944839, 14302006704):
        members = MEMBERS[f"artifact-{aid}.zip"]
        for name, raw in members.items():
            if not name.endswith("/result.json"):
                continue
            result = json.loads(raw)
            prefix = name.rsplit("/", 1)[0]
            logname = prefix + "/tests.log"
            parsed = parse_log(members[logname], f"artifact-{aid}.zip::{logname}")
            parent = load(SRC / f"inventories/artifact-{aid}-{prefix}.json")
            compare_inventory(parsed, parent, f"artifact {aid} {prefix}")
            same(f"Unix {aid} {prefix} result successful", result["outcome"], "passed")
            check(f"Unix {aid} {prefix} step exits zero", all(s["returncode"] == 0 for s in result["steps"]))
            same(f"Unix {aid} {prefix} passed count", sum(s["passed"] for s in parsed["rust"]), result["passed_tests"])
            same(f"Unix {aid} {prefix} Rust suite count", len(parsed["rust"]), 1)
            cleanup = result["cleanup"]
            check(f"Unix {aid} {prefix} observed owned cleanup",
                  cleanup["observed_processes_stopped"] and cleanup["owned_processes_stopped"]
                  and cleanup["temporary_directory_removed"] and not cleanup["ancestry_unverified"])
            check(f"Unix {aid} {prefix} detached boundary retained", "detached entirely between observations" in cleanup["ownership_boundary"])
            for log, size in result["logs"].items():
                same(f"Unix {aid} {prefix} retained log bytes {log}", len(members[prefix + "/" + log]), size)
            artifact_inventory[f"{aid}/{prefix}"] = parsed
            unix_results.append({"artifact_id": aid, "member": name, "platform": result["platform"], "passed": result["passed_tests"], "cleanup": cleanup})
    same("Unix interop plus forwarding result counts", sorted(r["passed"] for r in unix_results), [6, 6, 18, 18])

    ssh = MEMBERS["artifact-14300447980.zip"]
    direct = MEMBERS["artifact-14301275329.zip"]
    windows_results = {}
    for aid, members in ((14300447980, ssh), (14301275329, direct)):
        root_receipt = json.loads(members["receipt.json"])
        same(f"Windows {aid} artifact status", root_receipt["status"], "PASS")
        same(f"Windows {aid} native GUI remains UNRUN", root_receipt["native_gui"], "UNRUN")
        same(f"Windows {aid} API status", root_receipt["windows_api"], "PASS")
        same(f"Windows {aid} SSH status", root_receipt["ssh"], "PASS" if aid == 14300447980 else "UNRUN")
        terminals = []
        for child in root_receipt["children"]:
            terminal = child["terminal"]
            check(f"Windows {aid} child terminal {child['label']}",
                  terminal["direct_reaped"] and terminal["active_processes"] == 0
                  and terminal["pipes_drained"] and not terminal["errors"] and not child["errors"])
            receipt_name = child["label"] + ".receipt.json"
            if receipt_name in members:
                single = json.loads(members[receipt_name])
                for key in ("pid", "observed_exit", "terminal", "errors", "stdout_bytes", "stderr_bytes"):
                    same(f"Windows {aid} duplicated receipt {child['label']} {key}", child[key], single[key])
            if child["label"] != "owned-sshd":
                same(f"Windows {aid} child recorded exit {child['label']}", child["observed_exit"], 0)
            terminals.append({
                "label": child["label"], "pid": child["pid"], "observed_exit": child["observed_exit"],
                "direct_reaped": terminal["direct_reaped"], "active_processes": terminal["active_processes"],
                "pipes_drained": terminal["pipes_drained"],
            })
        windows_results[str(aid)] = {"status": root_receipt["status"], "ssh": root_receipt["ssh"], "native_gui": root_receipt["native_gui"], "children": terminals}

    wires = {}
    for operation in ("probe", "resources", "resources-skipped", "processes", "sockets"):
        a = json.loads(ssh[operation + ".assembly.json"])
        b = json.loads(direct[operation + ".assembly.json"])
        same("production assembly identical across independent artifacts " + operation, a, b)
        parts = []
        for part in a["parts"]:
            candidates = [p for p in source_bytes if p.endswith("/" + part["file"])]
            same("old source assembly unique part " + operation + " " + part["file"], len(candidates), 1)
            content = source_bytes[candidates[0]]
            same("old source assembly part hash " + operation + " " + part["file"], digest(content), part["sha256"])
            parts.append(content)
        script = a["literal_prefix"].encode() + b"".join(parts) + a["literal_suffix"].encode()
        same("old source exact script hash " + operation, digest(script), a["script_sha256"])
        wire = b"powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand " + base64.b64encode(script.decode().encode("utf-16le"))
        same("old source exact wire hash " + operation, digest(wire), a["wire_command_sha256"])
        same("old source exact wire length " + operation, len(wire), a["wire_command_ascii_bytes"])
        same("direct artifact wire equals reconstructed old source " + operation, direct[operation + ".wire.txt"], wire)
        receipt = json.loads(direct[operation + ".receipt.json"])
        same("direct actual cmd argv equals old source wire " + operation,
             receipt["shell_execution"]["argv"][-1].encode(), wire)
        wires[operation] = wire

    original = json.loads(ssh["ssh-debug-originals.json"])
    cleanup = json.loads(ssh["ssh-debug-cleanup.json"])
    intermediate = json.loads(ssh["owned-sshd.receipt.json"])["terminal"]["native_process_objects"]
    same("original SSH historical seal is HOLD", original["state"], "HOLD")
    same("original SSH historical terminal remains false", original["terminal_proven"], False)
    same("original SSH historical active count", original["job_active_processes"], 1)
    same("original SSH historical handles retained", original["owned_handles_remaining"], 22)
    same("original SSH historical not closed", original["closed"], False)
    for label, seal_obj in (("original", original), ("intermediate", intermediate), ("cleanup", cleanup)):
        same(f"SSH {label} retained original count", len(seal_obj["admissions"]), 21)
        same(f"SSH {label} Job total", seal_obj["job_total_processes"], 21)
        check(f"SSH {label} census and identities",
              seal_obj["complete_original_object_census"] and seal_obj["identities_bound"]
              and seal_obj["admission_closed"] and seal_obj["admission_phase_closed"]
              and not seal_obj["incomplete_census_observations"] and not seal_obj["errors"])
        same(f"SSH {label} debug events continued", seal_obj["debug_events_received"], seal_obj["debug_events_continued"])
        same(f"SSH {label} no pending debug event", seal_obj["pending_debug_event"], False)
        same(f"SSH {label} no fallback detach", seal_obj["fallback_detaches"], 0)
        same(f"SSH {label} unique original birth identities",
             len({(p["pid"], p["creation_time"]) for p in seal_obj["admissions"]}), 21)
        for proc in seal_obj["admissions"]:
            check(f"SSH {label} original admission identity {proc['pid']}",
                  proc["retained_before_first_instruction"] and proc["identity_bound_before_first_continue"])
    before = {(p["pid"], p["creation_time"]): p for p in original["admissions"]}
    after = {(p["pid"], p["creation_time"]): p for p in cleanup["admissions"]}
    same("SSH same original object identity set after cleanup", set(before), set(after))
    nonmaster = [p for p in original["admissions"] if not p["is_master"]]
    master = [p for p in original["admissions"] if p["is_master"]]
    same("SSH non-master count", len(nonmaster), 20)
    same("SSH master count", len(master), 1)
    for proc in nonmaster:
        check(f"SSH non-master naturally terminal {proc['pid']}",
              proc["natural_terminal_before_cleanup"] and proc["original_signaled"]
              and proc["exit_event_received"] and proc["exit_event_continued"]
              and proc["exit_event_code"] == proc["exit_code"])
        same(f"SSH non-master original record preserved {proc['pid']}", after[(proc["pid"], proc["creation_time"])], proc)
    check("SSH master not naturally terminal in historical seal",
          not master[0]["natural_terminal_before_cleanup"] and not master[0]["original_signaled"]
          and master[0]["exit_code"] is None)
    final_master = next(p for p in cleanup["admissions"] if p["is_master"])
    same("SSH master cleanup exit is 125", final_master["exit_code"], 125)
    same("SSH master cleanup is not natural", final_master["natural_terminal_before_cleanup"], False)
    same("SSH intermediate still retained 22 handles", intermediate["owned_handles_remaining"], 22)
    same("SSH intermediate is not closed", intermediate["closed"], False)
    same("SSH final state PASS", cleanup["state"], "PASS")
    check("SSH final exact cleanup complete",
          cleanup["terminal_proven"] and cleanup["closed"]
          and cleanup["job_active_processes"] == 0 and cleanup["pending_process_objects"] == 0
          and cleanup["debug_connections"] == 0 and cleanup["owned_handles_remaining"] == 0)
    same("SSH owned server observed_exit stays unknown",
         json.loads(ssh["owned-sshd.receipt.json"])["observed_exit"], None)
    same("SSH recorded source-head", ssh["source-head.stdout"].decode().strip(), SHA)
    same("SSH recorded source-status clean", ssh["source-status.stdout"], b"")
    parsed_native = parse_log(ssh["native-ssh-client.stdout"], "artifact-14300447980.zip::native-ssh-client.stdout")
    compare_inventory(parsed_native, load(SRC / "inventories/artifact-14300447980-native-ssh.json"), "native SSH Rust")
    same("native SSH Rust passed", sum(s["passed"] for s in parsed_native["rust"]), 1)
    binary = json.loads(ssh["test-binary.json"])
    expected_test = "actual_windows_openssh_monitor_matches_owned_fixture"
    same("native SSH binary single-test recorded inventory", binary["inventory"], [expected_test])
    same("native SSH binary single-test executed", binary["executed"], expected_test)
    inventory_text = ssh["live-test-inventory.stdout"].decode()
    same("native SSH raw list named inventory",
         re.findall(r"^(.+): test$", inventory_text, re.M), [expected_test])
    same("native SSH stdout named inventory", [p["name"] for p in parsed_native["rust"][0]["names"]], [expected_test])
    operations = json.loads(ssh["ssh-production-binding.json"])["operations"]
    same("SSH production exact operation set", {p["operation"] for p in operations}, {"probe", "resources", "processes", "sockets"})
    for operation in operations:
        key = (operation["pid"], operation["creation_time"])
        check("SSH production original identity exists " + operation["operation"], key in before)
        proc = before[key]
        same("SSH production actual wire digest " + operation["operation"],
             digest(wires[operation["operation"]]), operation["wire_sha256"])
        # Native Windows records preserve the argv0 separator verbatim. Its two
        # spaces are distinct from the canonical wire string's one space; the
        # fixed flags and entire EncodedCommand payload must still match exactly.
        command_match = re.fullmatch(
            r"powershell\.exe( +)(-NoLogo -NoProfile -NonInteractive -EncodedCommand [A-Za-z0-9+/=]+)",
            proc["command_line"],
        )
        check("SSH production original has exactly six fixed arguments " + operation["operation"],
              command_match is not None)
        canonical = "powershell.exe " + command_match[2] if command_match else ""
        same("SSH production original fixed argv and encoded source exact " + operation["operation"],
             canonical.encode(), wires[operation["operation"]])
        operation["original_command_sha256"] = digest(proc["command_line"].encode())
        operation["original_command_chars"] = len(proc["command_line"])
        operation["argv0_separator_spaces"] = len(command_match[1]) if command_match else None
        check("SSH production actual original natural exit0 " + operation["operation"],
              proc["natural_terminal_before_cleanup"] and proc["exit_code"] == 0 and operation["exit_code"] == 0)
    temp_cleanup = json.loads(ssh["ssh-cleanup.json"])
    check("SSH private temporary directory removed and not uploaded",
          temp_cleanup["temporary_directory_removed"] and not temp_cleanup["private_config_uploaded"] and not temp_cleanup["keys_uploaded"])
    windows_results["originals"] = {
        "historical_seal": {k: original[k] for k in (
            "state", "terminal_proven", "job_total_processes", "job_active_processes",
            "owned_handles_remaining", "pending_process_objects", "closed",
        )},
        "non_master_natural_terminal_count": len(nonmaster),
        "non_master_exit_codes": dict(Counter(str(p["exit_code"]) for p in nonmaster)),
        "intermediate_seal": {k: intermediate[k] for k in (
            "state", "terminal_proven", "owned_handles_remaining", "closed",
        )},
        "final_cleanup": {k: cleanup[k] for k in (
            "state", "terminal_proven", "job_total_processes", "job_active_processes",
            "owned_handles_remaining", "pending_process_objects", "closed",
        )},
        "master_cleanup_exit": final_master["exit_code"],
        "master_natural_terminal_before_cleanup": False,
        "owned_server_observed_exit": None,
        "production_operations": operations,
        "private_temporary_cleanup": temp_cleanup,
        "original_objects": [
            {k: p[k] for k in (
                "pid", "creation_time", "is_master", "natural_terminal_before_cleanup",
                "exit_code", "exit_event_code", "original_signaled", "exit_event_received",
                "exit_event_continued", "retained_before_first_instruction", "identity_bound_before_first_continue",
            )} for p in original["admissions"]
        ],
    }
    artifact_inventory["native_ssh"] = parsed_native

    historical = load(SRC / "bounded-snapshot-052139/summary.json")
    history_rows = [{
        "id": r["id"], "status": r["status"], "conclusion": r["conclusion"],
        "jobs": [{"id": j["id"], "status": j["status"], "conclusion": j["conclusion"]} for j in r["jobs"]],
    } for r in historical["runs"]]
    check("historical bounded snapshot incomplete status preserved", not historical["all_runs_terminal"])
    check("historical Quality incomplete status preserved",
          next(r for r in history_rows if r["id"] == 44020265369)["status"] != "completed")

    scan_hits = []
    patterns = {
        "github_token": re.compile(rb"(?:gh[pousr]_[A-Za-z0-9]{24,}|github_pat_[A-Za-z0-9_]{24,})"),
        "private_key_marker": re.compile(rb"-----BEGIN (?:OPENSSH |RSA |EC |DSA |ENCRYPTED )?PRIVATE KEY-----"),
    }
    for path in sorted((SRC / "downloads").iterdir()):
        if path.is_file() and path.suffix != ".zip":
            for name, pattern in patterns.items():
                if pattern.search(path.read_bytes()):
                    scan_hits.append({"path": path.relative_to(SRC).as_posix(), "pattern": name})
    for zipname, members in MEMBERS.items():
        for member, raw in members.items():
            for name, pattern in patterns.items():
                if pattern.search(raw):
                    scan_hits.append({"archive": zipname, "member": member, "pattern": name})
    same("bounded token/private-key marker scan no hits", scan_hits, [])
    final_input = input_files()
    same("final input bytes and mtimes unchanged", final_input, baseline)
    same("external seal archive unchanged after audit", digest((SEAL / "originals.tar.gz").read_bytes()), TAR_SHA)

    return {
        "schema": 1, "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "reviewer_role": "independent non-author offline artifact reviewer",
        "source_sha": SHA, "input": str(SRC), "review_directory": str(OUT),
        "input_files": len(baseline), "input_logical_bytes": sum(r["size"] for r in baseline),
        "input_unchanged": final_input == baseline,
        "external_seal": {
            "directory": str(SEAL), "archive_sha256": digest(archive),
            "archive_bytes": len(archive), "members": 314, "logical_bytes": 7314736,
            "all_members_exact": True,
        },
        "root_checksum": {"rows": len(root_rows), "omitted": omitted, "outer_manifest_covers_both": True},
        "source_binding": {
            "sha": SHA, "count": len(inputs), "aggregate_sha256": aggregate,
            "source_inputs_recorded_baseline_head": source["head"],
            "covers_all_non_docs_tracked_paths_at_old_sha": True, "git_blobs": git_rows,
        },
        "runs": runs, "job_totals": job_totals, "archives": archive_rows,
        "api_receipts": {
            "count": len(receipts), "exit_codes": dict(Counter(str(r["exit_code"]) for r in receipts)),
            "failures_preserved": receipt_failures, "failed_download_recovered_by_raw_retry": True,
        },
        "api_history": history,
        "historical_bounded_snapshot": {"all_runs_terminal": historical["all_runs_terminal"], "runs": history_rows},
        "job_inventories": inventories, "artifact_inventories": artifact_inventory,
        "unix_openssh": unix_results, "windows": windows_results,
        "git_read_commands": GIT_COMMANDS,
        "execution_boundaries": {
            "network_requests_by_reviewer": 0, "cargo_invocations": 0, "rustc_invocations": 0,
            "local_product_tests_executed": 0, "product_binaries_executed": 0, "shared_target_accesses": 0,
            "source_or_docs_mutations": 0, "input_mutations": 0, "git_mutations": 0,
            "child_agents_created": 0, "native_gui_accepted": False,
        },
        "checks_passed": sum(c["passed"] for c in CHECKS),
        "checks_failed": sum(not c["passed"] for c in CHECKS),
        "checks": CHECKS,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--revision", default="r1")
    args = parser.parse_args()
    if not re.fullmatch(r"r\d+", args.revision):
        raise ValueError("revision must be r followed by digits")
    try:
        result = audit()
    except Exception as error:
        result = {
            "audit_incomplete": True, "error_type": type(error).__name__, "error": str(error),
            "checks_passed": sum(c["passed"] for c in CHECKS),
            "checks_failed": sum(not c["passed"] for c in CHECKS),
            "checks": CHECKS, "git_read_commands": GIT_COMMANDS,
        }
    emit("audit-" + args.revision + ".json", result)
    failures = [c for c in CHECKS if not c["passed"]]
    print(json.dumps({
        "result": str(OUT / ("audit-" + args.revision + ".json")),
        "audit_incomplete": result.get("audit_incomplete", False),
        "error": result.get("error"), "checks_passed": result["checks_passed"],
        "checks_failed": result["checks_failed"], "failure_examples": failures[:12],
    }, ensure_ascii=False, indent=2, default=str))
    return 1 if result.get("audit_incomplete") or failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
