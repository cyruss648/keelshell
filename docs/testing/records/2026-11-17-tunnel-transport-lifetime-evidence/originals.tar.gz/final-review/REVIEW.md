审查结论：**APPROVE，限定本批 r2 七个工程文件的源审、下述独立复跑和已完成父级回执复核。P0=0、P1=0、P2=0、P3=0。** Pauli 唯一历史 P2 已关闭。完整工程门禁 r2 仍由父级另验，本结论可供父级继续收口本批，不构成完整工程、跨平台、原生桌面或发行签署。

审查身份：本批新非作者，当前会话；未参与实现，也未修改发现。审查日期：2026-11-17，Asia/Shanghai。工作区为 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`。基线及审查首尾 HEAD 均为 `660645fbe77cee2b8af2740f3277a70e9f968048`；审查对象是该 HEAD 上的工作区候选，包含两个尚未跟踪的 Rust 文件。

**冻结绑定与 r2 补核。** 已分别独立枚举 Git cached/others/exclude-standard 中除 `docs/` 外的全部工程输入，复算每个文件字节数、SHA-256、清单集合及 aggregate。r1 首次读取的 769 输入与 `candidate-inputs-r1.json` 完全一致，aggregate 为 `79cdd56f1f38a720b7e4800b0ee65bd9346b683a43a5996c1db0080ab42e5bec`。用户追加 r2 后，保留 r1 分析，只补核唯一 helper 差分。

最终绑定 [candidate-inputs-r2.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/tunnel-lifecycle-20261117/candidate-inputs-r2.json)：

- 输入数：769；审查目录保存的清单原件 SHA-256 为 `0dda219e081d4c136f25560afdbd129f509ca73821c5978e1e396adfa3ddc7b8`。
- aggregate：`83e2e1b00ba4d373a407030c79538f8a5039347931236344315ad8b70844a5b7`。
- r2 验证前后两次全量比对均相等；末次核对时间为 `2026-11-17T04:35:14.866170+00:00`，即北京时间 12:35:14。
- r1→r2 只有 `crates/keelshell-session/tests/forwarding_openssh.rs` 一个输入改变；完整逐项记录为本目录 `r1-to-r2.json`、`r1-to-r2.diff`。
- `forwarding_openssh.rs:57` 将 `loop { let Ok(count) = read.await else { break }; ... }` 改为 `while let Ok(count) = read.await { ... }`。正常读写继续、读取错误退出、EOF 退出、写入错误退出的行为相同；4096 字节缓冲区、短路条件、流所有权、取消和回收代码未改。该补核没有重做未变的全部源审。

七个工程文件的最终摘要如下；正文路径和行号均指 r2 当前 checkout。

| 文件 | r2 SHA-256 |
| --- | --- |
| `crates/keelshell-session/src/forwarding.rs` | `3a2c014d001df1ecba12eb520c41ee21e5bfadac5d772cb77eaccc62f6a07572` |
| `crates/keelshell-session/src/forwarding/local_lifecycle_tests.rs` | `7b6ce1c2f5b7ccc6d82db16d2cf262cc23bebe2b9539cee73a3c45dc128a1976` |
| `crates/keelshell-session/tests/forwarding_openssh.rs` | `dc29204e94b2c046ea38c1c198f88536a93360d3cfeda3bdc58159bea83b3789` |
| `scripts/openssh_interop.py` | `909ccb5393c4598ff2c409b07096358d3240a27ffae2a8c6f0894b54a1b6698d` |
| `scripts/test_openssh_interop.py` | `842a1da89da11f7ea298e9f7b4d499c72c89b71ff5db5249328bba9976f008dd` |
| `.github/workflows/ci.yml` | `a33e1e1c21739949361991a8ccc89f98dfb90cd6af1939118c9d9bf7857774c8` |
| `Cargo.lock` | `80c2295fd4d8d24f1c31a5e517daa59ea947d9c158746f239d9b536e776c5953` |

已完整读取这七个文件的相关实现、全部新增 Rust/Python 测试和差分。五个已跟踪文件的 Git diff 保存在本目录；两个新增 Rust 文件的完整原字节也在 `snapshot/` 和 `snapshot-r2/`，因此本轮覆盖超出普通 tracked-only diff。依约先读了 RTK、AGENTS、HANDOFF、ROADMAP 和 SHARED_TARGET；采用 rust-best-practices 的所有权、错误和测试检查项。另读取未改动的 `ssh.rs`、`ssh/lifecycle.rs` 及本机已下载的 Tokio 1.54.1 watch/JoinSet 源码，仅用于核对调用契约。

**发现计数。**

| P0 | P1 | P2 | P3 | 当前未关闭发现 |
| ---: | ---: | ---: | ---: | ---: |
| 0 | 0 | 0 | 0 | 0 |

没有需提交给作者修改的新增问题，因此不存在新增缺陷的触发/影响条目。以下列出实质追踪过的触发、行为及证据，以便复核本结论的范围。

| 重点与触发 | 源码追踪与复核结果 |
| --- | --- |
| Closing 时协议 worker 尚未关闭 | [forwarding.rs:316](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/forwarding.rs:316) 同时要求状态为 Connected 且 `is_closed()==false`；[ssh.rs:1034](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/ssh.rs:1034) 在等待断连前发布 Closing，而 `is_closed` 只观察协议/transport。这一窗口不会被当作可分配 listener；[local_lifecycle_tests.rs:275](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/forwarding/local_lifecycle_tests.rs:275) 明确断言 Closing 且尚未 is_closed，在已占地址上仍应返回 Closed。 |
| bind 前、bind 等待中或返回瞬间关闭 | [forwarding.rs:347](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/forwarding.rs:347) 先订阅、admission，再用 shutdown 优先的 select 等 bind，之后再次 admission；[forwarding.rs:441](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/forwarding.rs:441) 在返回 owner 前再校验并在失败时关闭 owner。关闭路径会 drop 已绑定 listener；[local_lifecycle_tests.rs:326](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/forwarding/local_lifecycle_tests.rs:326) 及 343 两例实际控制完成时变状态和 pending bind，随后重绑原地址。Connected 时真实 AddrInUse 仍保留为 Io，不关闭共享 SSH，见 308。 |
| watch 新订阅的当前值已经 seen；发送者丢失或重复 Connected 更新 | [forwarding.rs:324](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/forwarding.rs:324) 每轮先 `borrow_and_update` 检查当前状态，再等 changed；Ref 临时值在进入 await 前结束。changed 错误直接退出，Connected 更新继续等待。[local_lifecycle_tests.rs:513](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/forwarding/local_lifecycle_tests.rs:513)、531、544 分别覆盖这些条件。未看到跨 await 持有 watch 读锁或遗漏已经 seen 的终态。 |
| lifecycle 回调落后于 transport 终止 | [forwarding.rs:331](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/forwarding.rs:331) 每轮也检查 `session.is_closed()`，50ms sleep 作为库内后备唤醒。[local_lifecycle_tests.rs:565](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/forwarding/local_lifecycle_tests.rs:565) 使用始终 Connected 且发送者仍存活的独立 watch，先 poll 为 Pending，再实际 cut TCP；5 秒内返回。这证明后备路径可进展，没有测得严格的 50ms 延迟上界。 |
| idle listener、accept、pending channel-open、已建立 stream 遇到 shutdown | [forwarding.rs:385](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/forwarding.rs:385) 将 shutdown 固定在 worker 内并优先 poll；accept 后、子任务 channel-open 前和 open 后都校验 admission；open 有 session timeout。自然退出先 drop listener，再 shutdown/reap 自己的 JoinSet。用例 365、377、396、413 分别验证 retained owner、remote disconnect、TCP loss 及 gate 阻塞的 channel-open；最后一例在 5 秒内释放，早于 session 的 30 秒 channel deadline。 |
| 局部停止不影响已经建立的 sibling | [forwarding.rs:233](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/forwarding.rs:233) 的 close 只 abort 此 owner 的 task；worker 的 JoinSet 也局部持有，局部停止未调用 session.close 或 routes.cancel_all。[local_lifecycle_tests.rs:442](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/forwarding/local_lifecycle_tests.rs:442) 在停止前先建立两路，停止后同一 sibling 双端再交换；另外核对被停流两端关闭、原地址重绑、共享 session 保持 Connected。真实 OpenSSH local/remote 修复见下文。 |
| 一个 SSH 关闭不影响另一 SSH；新旧 owner 分离 | [local_lifecycle_tests.rs:462](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/forwarding/local_lifecycle_tests.rs:462) 用两个 `same_connection==false` 的 session 和预先建立的双流验证隔离；491 观察实际连接数为 1→2，旧 owner 保持 closed，并显式新建转发。真实 OpenSSH [forwarding_openssh.rs:225](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/forwarding_openssh.rs:225) 在新 session 上显式用旧地址建立 fresh owner 后，再关闭旧 owner，fresh 仍可交换内容。实现捕获的是原 SshSession 克隆，没有 profile 查找或自动重连路径。 |
| 仅本套件开放 TCP forwarding | [openssh_interop.py:416](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/openssh_interop.py:416) 使用互斥 suite；442 选择 forwarding_openssh；510 仅 forwarding 打开 AllowTcpForwarding，PermitOpen/PermitListen 为 127.0.0.1:*，GatewayPorts no，其他转发限制保留。新增 [test_openssh_interop.py:19](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_openssh_interop.py:19) 覆盖默认策略和互斥拒绝；原独立工装控制也在本轮复跑。 |
| CI 与 lock 范围 | [ci.yml:85](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/.github/workflows/ci.yml:85) 为 macOS/Linux 增加独立 forwarding 步骤，沿用 always 上传回执；本轮只审配置。逐项 TOML 对比 [Cargo.lock:9095](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/Cargo.lock:9095) 证明只有 uuid 包的 version/checksum 从 1.29.2 改到 1.29.3，依赖边及其他包均未变。 |

**Pauli P2 关闭。** 原发现的触发是 first.close 错误中止同 SSH 上其他已建立流，但 sibling listener 仍能接受新流；旧断言在 close 后才连 sibling，可能漏报该影响。当前 r2：

- local：[forwarding_openssh.rs:156](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/forwarding_openssh.rs:156) 在停止前建立 sibling，并用 marker 0xa3 完成 70,031 字节交换；168 关闭 first，169–170 验被停流/端点释放；171 在同一个 sibling 上用不同 marker 0x64 再交换；174 验 second 自己关闭后的 stream 终止。
- remote：[forwarding_openssh.rs:307](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/forwarding_openssh.rs:307) 在停止前建立 sibling 并以 0xe7 交换；309 关闭 first；312 在原 sibling 上以 0xf8 再交换；315 验 second 自己关闭后 stream 终止。

这两处均会捕捉历史描述的“误断已有 sibling”回归。修复在 r1 已存在，r2 唯一 helper 语法变更没有削弱它。父级 r1 和 r2 的真实 OpenSSH 逐名结果均包含这两例且通过。旧报告 [REVIEW.md](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/tunnel-lifecycle-harness-review-20261117/REVIEW.md) 原字节保留，当前 SHA-256 仍是 `6aa02f04a1d70f0a0524846164c1901f62f9ae4338da0650749c1e91847298c0`；本目录还保存了一份原件。历史 REQUEST_CHANGES 未被改写，本报告记录该 P2 已关闭。

**独立执行与计数。** 以下 7 条实质验证命令均由本目录 `audit.py capture <name> ...` 启动，每条有独立 argv、stdout、stderr、SHA-256、exit、elapsed 和 reaped 回执；工作目录均为当前 checkout，外层超时 60 秒，超时后只 kill 并 wait 自己的直接子进程。实际均未超时，returncode=0、reaped=true。Python 禁止写 pycache，TMPDIR 限定在本报告目录。

表中 `R` 表示绝对目录 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/tunnel-lifecycle-final-review-20261117`；完整原始 argv 以对应 JSON 为准。

| 回执名 | 实际子命令 | 结果与计数 | elapsed 秒 |
| --- | --- | --- | ---: |
| `python-unittest.json` | `python3 -B -m unittest discover -s work/tunnel-lifecycle-final-review-20261117/snapshot/scripts -p test_openssh_interop.py -v` | 33 run / 33 passed / 0 failed/errors / 0 skipped | 0.147225 |
| `harness-controls.json` | `python3 -B -m unittest discover -s work/tunnel-lifecycle-final-review-20261117 -p test_review_controls.py -v` | 原 Pauli 独立控制原字节复制到自有目录后复跑，12 run / 12 passed / 0 failed/errors / 0 skipped | 0.110164 |
| `session-lib-list.json` | `R/prebuilt/session-lib --list` | 完整库存 424 tests / 0 benchmarks；新增生命周期 16 个名字与 r2 源码逐名相等 | 0.301247 |
| `forwarding-openssh-list.json` | `R/prebuilt/forwarding-openssh --list` | 库存 6 tests / 0 benchmarks，逐名匹配源码；实际 SSH 测试运行 0 | 0.166444 |
| `local-lifecycle-prebuilt.json` | `R/prebuilt/session-lib forwarding::local_lifecycle_tests:: --test-threads=4` | 16 passed / 0 failed / 0 ignored / 408 filtered out | 0.084323 |
| `offline-evidence.json` | `python3 -B work/tunnel-lifecycle-final-review-20261117/verify_evidence.py` | 冻结源码/编译库存/父级及独立通过名字、37包/113声明与锁边、uuid 单包双字段差分、22份保存文件摘要及 r1 SSH 回执一致性全部通过 | 0.137899 |
| `parent-r2-receipt.json` | `python3 -B work/tunnel-lifecycle-final-review-20261117/capture_r2_receipt.py` | 已完成的父级 r2 SSH 原件复制、6 个测试名字/结果、日志字节数、清理字段及临时目录不存在核对通过；未启动 SSH | 0.024199 |

Python 共执行 2 条 unittest 命令、45 项全部通过；这些是工装/mock 控制，外部 SSH/信号均被 mock。Python 文件在 r1/r2 间未变，故 r1 快照中的 33 项结果适用于相同字节的 r2 工装。

Rust 实际独立执行 1 条预编译测试命令、16 项通过，使用真实 loopback russh/TCP fixture；它们不是 OpenSSH 服务器或原生 UI 测试。fixture 断言有 5 秒等待边界，session channel deadline 为 30 秒，本次进程另有 60 秒外层限时。fixture Drop 对其保留 socket 执行 Shutdown::Both 并 abort 自有父 task；退出进程已 wait/reaped。没有把 Drop abort 叙述成每个 fixture 都取得了独立优雅回收回执。

预编译证据在首次 `--list` 及运行之前记录摘要并复制到自有目录，读取源文件前后和副本 SHA-256 相等；不在共享 target 内运行：

- session lib：来源 `work/recovery-batch-integration-20261115/target/debug/build/keelshell-session/4448e1344a19a2cc/out/keelshell_session-4448e1344a19a2cc`，45,465,408 字节，SHA-256 `25e00f444949ac82215c777b6e38bb4eb45b580a7f1e3f1342804bb25d1f3931`。
- forwarding integration 库存副本：来源 `work/recovery-batch-integration-20261115/target/debug/build/keelshell-session/916540c0e1e336b6/out/forwarding_openssh-916540c0e1e336b6`，18,351,120 字节，SHA-256 `daf43095f68b2920f96fd9507edf460cc8dc8372ed73c77aabc81cea3be22f35`。只执行 `--list`，没有用它重放真实 SSH。

这些是父级提供的已有产物，本轮**没有独立重新编译**。父级 local-lifecycle-r1 原日志显示在此 checkout 实际 Compiling keelshell-session、随后 16 passed；本轮核对其逐名结果与副本库存、本次通过结果及 r2 未变的 library 源码一致。库存和摘要提供明确关联，但不扩大成独立可复现构建证明。

**父级已完成的真实 OpenSSH 与门禁证据。** 本轮没有重跑 openssh_interop.py，也没有启动 ssh/sshd。已保存并复核 `openssh-forwarding-r1` 与新完成的 [openssh-forwarding-r2/result.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/tunnel-lifecycle-20261117/openssh-forwarding-r2/result.json)：

- r2 为 Darwin，6 passed / 0 failed / 0 ignored / 0 filtered out；Rust 输出 0.41 秒，工装总耗时 2.197 秒；五个步骤 returncode 均为 0，测试日志显示当前 checkout 的 keelshell-session 实际编译。
- 六个通过名字与 r2 六个 opt-in 用例逐名相等，覆盖 local 局部停止、local 主动 session.close 后无 app poller 的释放、已关闭 session 拒绝 listener、新旧 owner、SOCKS 协商/载荷/停止、remote 局部停止及 sibling。
- 每例最外层 25 秒 timeout；stream_closed、owner closed、echo 显式回收用 3 秒 timeout；内容交换逐字节校验 70,031 字节，停止后 sibling 使用不同 marker，SOCKS 校验 greeting 与 IPv4 CONNECT 成功响应。
- r2 回执记录 observed_processes_stopped=true、owned_processes_stopped=true、ancestry_unverified=[]、tracked_process_identities=18、temporary_directory_removed=true。本轮另观察原 temporary_directory 确实不存在，所有日志字节数与回执相等。
- 这里只对已有回执、源码中的有界回收和当前目录状态作独立核对，没有重建历史 18 个 PID 的 birth-identity census。工装自身也保留“观察间隙完全脱离的后代”所有权边界，不将回执扩大成超出该边界的穷尽进程证明。

原完整门禁 [final-gate-r1/result.json](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/tunnel-lifecycle-20261117/final-gate-r1/result.json) 保持失败事实：`31.610392s / returncode 1 / wrapper_exit 1 / reaped=true`，严格 Clippy 在 `forwarding_openssh.rs` 的 while_let_loop 停止；内层 Clippy exit 101。r2 正是对此 helper 作上述等价修正，不能以语法源审补签完整门禁成功。本轮观察 `final-gate-r2/result.json` 尚不存在；按用户要求不等待父级串行完整门禁，也未运行或干预它。

**依赖复核范围。** 父级官方全量记录 `dependency-freshness-r2.json` 的查询窗口为 `2026-11-17T04:19:54Z` 至 `04:20:31Z`，status=passed，37 个 registry 包、113 个声明均 passed，errors=[]。本轮离线重新读取当前 manifest，使用现有检查器的 collect_dependencies/LockGraph 取得 113 个精确声明及每个 direct lock edge，与该回执逐项匹配，并核对各来源为 crates.io API。没有重新查询网络上的最新版本；freshness 结论只绑定该已保存查询窗口。r1→r2 不涉及 Cargo.toml/Cargo.lock，因此该依赖原件继续适用。

**只读边界、原件与建议。** 本会话只在 `work/tunnel-lifecycle-final-review-20261117/` 写入报告、快照、自有审计脚本、原件副本、预编译副本和临时数据；受控源码/文档编辑、Cargo、fmt、Clippy、共享 target 写入/clean、commit、push、GUI 均为 0。用户授权范围内的 fixture 自有临时目录由其自身回收。父级在并行维护 `docs/`，末次 status 比最初额外列出 CAPABILITIES 及 Zmodem CI 文档；这些原状态文本均保存，769 个冻结工程输入前后仍完全相等，不据此宣称整个工作区无变化。

未验边界：独立 Rust 重编译、完整工程门禁 r2、该差分精确提交的 CI、Linux/Windows 实际 forwarding、跨平台原生桌面、安装和发行；压力下严格 50ms 关停上界、OpenSSH peer 主动突然断链及网络丢包/黑洞亦没有本次独立执行证据。真实 OpenSSH 的 disconnect 用例由主动 SshSession.close 驱动；另有 loopback russh 的 remote disconnect 和 TCP cut 用例，二者分别记账。源码审查、Python mock、预编译 loopback、父级真实 OpenSSH 和原生验收保持各自证据范围。

建议父级：以本报告限定批准 r2 七文件并关闭 Pauli 历史 P2；保留 r1 Clippy 失败与全部旧原件，完成正在串行进行的 r2 全门禁后再决定整批交付。本轮独立审查已完成，无新增发现要求作者修复，无需等待未变工程全门禁后再出具源审结论。

报告原件入口为本目录 `originals/`；七文件 r1/r2 快照为 `snapshot/`、`snapshot-r2/`；冻结完整逐项比对为 `integrity.before.json`、`integrity.r2-before.json`、`integrity.r2-after.json`；预编译与原件摘要为 `evidence-manifest.json`、`parent-r2-verification.json`；实际命令原件为上述七组 JSON/stdout/stderr；机器可读结论另存 `final.json`。
