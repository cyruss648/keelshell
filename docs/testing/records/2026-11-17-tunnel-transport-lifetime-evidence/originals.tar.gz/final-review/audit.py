"""Independent read-only review capture; all output stays beside this script."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
BASE = "660645fbe77cee2b8af2740f3277a70e9f968048"
EXPECTED = "79cdd56f1f38a720b7e4800b0ee65bd9346b683a43a5996c1db0080ab42e5bec"
SCOPE = [
    "crates/keelshell-session/src/forwarding.rs",
    "crates/keelshell-session/src/forwarding/local_lifecycle_tests.rs",
    "crates/keelshell-session/tests/forwarding_openssh.rs",
    "scripts/openssh_interop.py",
    "scripts/test_openssh_interop.py",
    ".github/workflows/ci.yml",
    "Cargo.lock",
]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write("\n")


def git(*args):
    return subprocess.check_output(
        ["git", "--no-optional-locks", *args], cwd=ROOT
    )


def snapshot(label, manifest_name="candidate-inputs-r1.json", expected=EXPECTED):
    manifest_path = ROOT / "work/tunnel-lifecycle-20261117" / manifest_name
    manifest_data = manifest_path.read_bytes()
    manifest = json.loads(manifest_data)
    names = git("ls-files", "--cached", "--others", "--exclude-standard", "-z")
    names = sorted({
        name for name in names.decode().split("\0")
        if name and not name.startswith("docs/")
    })
    rows = []
    for name in names:
        path = ROOT / name
        if path.is_symlink() or not path.is_file():
            raise RuntimeError(f"Unexpected input type: {name}")
        data = path.read_bytes()
        rows.append({"path": name, "bytes": len(data), "sha256": digest(data)})
    aggregate = digest(json.dumps(rows, sort_keys=True, separators=(",", ":")).encode())
    expected_rows = manifest["inputs"]
    expected_by_name = {row["path"]: row for row in expected_rows}
    current_by_name = {row["path"]: row for row in rows}
    changes = [
        name for name in sorted(expected_by_name.keys() | current_by_name.keys())
        if expected_by_name.get(name) != current_by_name.get(name)
    ]
    record = {
        "checked_utc": datetime.now(timezone.utc).isoformat(),
        "head": git("rev-parse", "HEAD").decode().strip(),
        "expected_head": BASE,
        "count": len(rows),
        "manifest_count": manifest["count"],
        "manifest_sha256": digest(manifest_data),
        "aggregate_sha256": aggregate,
        "expected_aggregate_sha256": expected,
        "manifest_aggregate_sha256": manifest["aggregate_sha256"],
        "changes": changes,
        "rows_equal": rows == expected_rows,
        "scope": [current_by_name[name] for name in SCOPE],
        "inputs": rows,
    }
    status = git("status", "--porcelain=v1", "--untracked-files=all")
    (OUT / f"status.{label}.txt").write_bytes(status)
    write_json(OUT / f"integrity.{label}.json", record)
    if label in ("before", "r2-before"):
        destination = OUT / "originals/work/tunnel-lifecycle-20261117"
        destination.mkdir(parents=True, exist_ok=True)
        (destination / manifest_path.name).write_bytes(manifest_data)
        for name in SCOPE:
            target = OUT / ("snapshot" if label == "before" else "snapshot-r2") / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes((ROOT / name).read_bytes())
        diff = git("diff", "--no-ext-diff", BASE, "--", *SCOPE)
        (OUT / f"scope.{label}.tracked.diff").write_bytes(diff)
        for name in SCOPE:
            present = subprocess.run(
                ["git", "--no-optional-locks", "cat-file", "-e", f"{BASE}:{name}"],
                cwd=ROOT, capture_output=True
            )
            if present.returncode == 0:
                target = OUT / ("base" if label == "before" else "base-r2") / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(git("show", f"{BASE}:{name}"))
    print(json.dumps({k: v for k, v in record.items() if k not in ("inputs", "scope")}))
    assert record["head"] == BASE
    assert len(rows) == 769 and rows == expected_rows
    assert aggregate == expected == manifest["aggregate_sha256"]


def capture(name, argv):
    started = time.monotonic()
    environment = os.environ.copy()
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    environment["GIT_OPTIONAL_LOCKS"] = "0"
    environment["TMPDIR"] = str(OUT / "tmp")
    (OUT / "tmp").mkdir(exist_ok=True)
    with (OUT / f"{name}.stdout.log").open("xb") as stdout, \
            (OUT / f"{name}.stderr.log").open("xb") as stderr:
        process = subprocess.Popen(
            argv, cwd=ROOT, env=environment, stdout=stdout, stderr=stderr
        )
        expired = False
        try:
            code = process.wait(timeout=60)
        except subprocess.TimeoutExpired:
            expired = True
            process.kill()
            code = process.wait(timeout=5)
    record = {
        "argv": argv, "cwd": str(ROOT), "returncode": code,
        "timeout_seconds": 60, "timed_out": expired, "reaped": True,
        "elapsed_seconds": time.monotonic() - started,
        "stdout_sha256": digest((OUT / f"{name}.stdout.log").read_bytes()),
        "stderr_sha256": digest((OUT / f"{name}.stderr.log").read_bytes()),
        "environment_overrides": {
            key: environment[key]
            for key in ("PYTHONDONTWRITEBYTECODE", "GIT_OPTIONAL_LOCKS", "TMPDIR")
        },
    }
    write_json(OUT / f"{name}.json", record)
    print(json.dumps(record))
    raise SystemExit(code)


if __name__ == "__main__":
    if sys.argv[1] == "snapshot":
        snapshot(sys.argv[2], *sys.argv[3:])
    elif sys.argv[1] == "capture":
        capture(sys.argv[2], sys.argv[3:])
    else:
        raise SystemExit("Expected snapshot or capture")
