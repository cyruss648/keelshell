"""Capture the already completed parent r2 SSH run; never start OpenSSH or Cargo."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
SOURCE = ROOT / "work/tunnel-lifecycle-20261117/openssh-forwarding-r2"
DESTINATION = OUT / "originals/work/tunnel-lifecycle-20261117/openssh-forwarding-r2"
DESTINATION.mkdir(parents=True)
records = []
for source in sorted(SOURCE.iterdir()):
    if source.is_file() and source.suffix in (".log", ".json"):
        data = source.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        with (DESTINATION / source.name).open("xb") as target:
            target.write(data)
        assert hashlib.sha256(source.read_bytes()).hexdigest() == digest
        records.append({"name": source.name, "bytes": len(data), "sha256": digest})
receipt = json.loads((DESTINATION / "result.json").read_text())
log = (DESTINATION / "tests.log").read_text()
source = (OUT / "snapshot-r2/crates/keelshell-session/tests/forwarding_openssh.rs").read_text()
expected = sorted(re.findall(r"#\[tokio::test\]\s+#\[ignore[^\n]*\]\s+async fn (\w+)", source))
passed = sorted(re.findall(r"^test (\S+) \.\.\. ok$", log, re.M))
assert expected == passed and len(passed) == 6
assert "test result: ok. 6 passed; 0 failed; 0 ignored;" in log
assert receipt["outcome"] == "passed" and receipt["passed_tests"] == 6
assert all(row["returncode"] == 0 for row in receipt["steps"])
assert all(receipt["cleanup"][key] is True for key in (
    "observed_processes_stopped", "owned_processes_stopped", "temporary_directory_removed"
))
assert receipt["cleanup"]["ancestry_unverified"] == []
assert not Path(receipt["temporary_directory"]).exists()
for name, size in receipt["logs"].items():
    assert (DESTINATION / name).stat().st_size == size
record = {
    "checked_utc": datetime.now(timezone.utc).isoformat(),
    "status": "passed",
    "independently_executed_ssh_tests": 0,
    "parent_executed_ssh_tests": len(passed),
    "source_and_pass_names_equal": True,
    "elapsed_seconds": receipt["elapsed_seconds"],
    "receipt_steps": receipt["steps"],
    "cleanup_receipt": receipt["cleanup"],
    "temporary_directory_absent_now": True,
    "process_identity_census_independently_reconstructed": False,
    "records": records,
}
with (OUT / "parent-r2-verification.json").open("x") as stream:
    json.dump(record, stream, indent=2)
    stream.write("\n")
print(json.dumps({key: value for key, value in record.items() if key != "records"}))
