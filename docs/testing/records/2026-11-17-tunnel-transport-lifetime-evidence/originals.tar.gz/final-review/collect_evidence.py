"""Copy authorized evidence and stable prebuilt executables without touching target."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
AUTHOR = ROOT / "work/tunnel-lifecycle-20261117"
records = []


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def copy(source, destination):
    before = sha(source)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with source.open("rb") as original, destination.open("xb") as saved:
        shutil.copyfileobj(original, saved)
    after = sha(source)
    saved = sha(destination)
    assert before == after == saved, str(source)
    records.append({
        "source": str(source.relative_to(ROOT)), "copy": str(destination.relative_to(OUT)),
        "bytes": destination.stat().st_size, "sha256": saved,
        "source_unchanged_during_copy": True,
    })


for directory in (
    "local-lifecycle-r1", "openssh-forwarding-r1", "forwarding-compile-r1",
    "dependency-freshness-r2", "final-gate-r1",
):
    for source in sorted((AUTHOR / directory).iterdir()):
        if source.is_file() and source.suffix in (".json", ".log"):
            copy(source, OUT / "originals" / source.relative_to(ROOT))
for filename in ("dependency-freshness-r2.json",):
    source = AUTHOR / filename
    copy(source, OUT / "originals" / source.relative_to(ROOT))
pauli = ROOT / "work/tunnel-lifecycle-harness-review-20261117"
for filename in ("REVIEW.md", "final.json", "test_review_controls.py"):
    source = pauli / filename
    copy(source, OUT / "originals" / source.relative_to(ROOT))
copy(pauli / "test_review_controls.py", OUT / "test_review_controls.py")

build = ROOT / "work/recovery-batch-integration-20261115/target/debug/build/keelshell-session"
for directory, filename, label in (
    ("4448e1344a19a2cc", "keelshell_session-4448e1344a19a2cc", "session-lib"),
    ("916540c0e1e336b6", "forwarding_openssh-916540c0e1e336b6", "forwarding-openssh"),
):
    source = build / directory / "out" / filename
    destination = OUT / "prebuilt" / label
    copy(source, destination)
    destination.chmod(0o700)

record = {
    "captured_utc": datetime.now(timezone.utc).isoformat(),
    "independent_compilation": False,
    "records": records,
}
with (OUT / "evidence-manifest.json").open("x") as stream:
    json.dump(record, stream, indent=2)
    stream.write("\n")
print(json.dumps({
    "files": len(records),
    "bytes": sum(row["bytes"] for row in records),
    "prebuilt": [row for row in records if row["copy"].startswith("prebuilt/")],
}))
