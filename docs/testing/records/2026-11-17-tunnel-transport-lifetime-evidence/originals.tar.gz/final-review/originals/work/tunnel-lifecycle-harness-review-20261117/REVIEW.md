审查结论：REQUEST_CHANGES，仅针对本批四个验收文件的最终差分。P0=0、P1=0、P2=1、P3=0；一项发现涉及 local/remote 两处断言。未修复发现。

审查日期：2026-11-17。身份：本批独立非作者。checkout：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`。基线和审查时 HEAD 均为 `660645fbe77cee2b8af2740f3277a70e9f968048`；审查对象是其上的工作区差分，包含尚未跟踪的完整 `forwarding_openssh.rs`。只批准/否决这四文件的验收逻辑，不批准生产 `forwarding.rs`。

已读 RTK、当前 HANDOFF/ROADMAP、`rust-best-practices` 的 Automated Testing 章节。仅在本报告目录写快照、独立控制测试与回执。原生状态维持 locked，GUI 操作 0。

**[P2] 局部停止用例未验证停止前已建立的 sibling 流继续存活。**

位置：

- [forwarding_openssh.rs:167](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/forwarding_openssh.rs:167)，相关行 152–173。
- [forwarding_openssh.rs:307](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/forwarding_openssh.rs:307)，相关行 296–313。

两处都先 `first.close()`，之后才建立 `second` 的 TCP 客户端。若停止 first 错误地 abort 同一 SSH 上所有已经建立的转发流，但保留 second 的 listener，两个用例依然会通过：它们只检查了新 sibling 连接与新 exec channel。这个 green 无法证明“只停止自己的流”，会漏掉已有 sibling 业务连接被误断的回归。这是验收断言缺口，不是对未审生产实现存在该缺陷的认定。

建议：在停止 first 前，分别建立 first 与 second 的流并完成各自内容交换；停止 first 后，验证 first 流关闭、listener 释放，再使用**同一个已存在的 sibling stream**交换不同内容，最后停止 second 并验证其流关闭。可以保留当前停止后新建连接检查作为附加断言。local/remote 两处都需覆盖。

其余已核对内容：

- 六个 Rust 用例静态覆盖 local 停止、主动关闭 session、已关闭 session 拒绝分配、独立新旧连接及旧 owner 再关闭、SOCKS 停止、remote 停止。replacement 使用两次独立连接和 `same_connection` 否定断言，并要求旧地址释放、显式启动 fresh owner 后旧 owner 关闭不影响新转发。
- SOCKS 包含协商、IPv4 CONNECT 成功响应与实际内容交换；local/remote/SOCKS 内容均核对 70,031 字节。每个测试有 25 秒外层 deadline，流关闭、owner 关闭标记及 echo 回收各有 3 秒 deadline。这里只确认源码中的边界，未执行 Rust。
- `--forwarding` 与其他专用套件互斥，选中 `--test forwarding_openssh --ignored --test-threads=1`。默认、monitor、Zmodem 仍为 `AllowTcpForwarding no`；仅 forwarding 为 yes。`ListenAddress`、`PermitOpen`、`PermitListen` 限制为 `127.0.0.1`，`GatewayPorts no`，stream-local/tunnel/agent 转发仍禁止。所有新增测试 listener/destination 都显式使用 IPv4 loopback。
- 工装保留总超时 15–300 秒及 12 秒回收预算。独立控制确认：无摘要、0/5 项通过、ignored/failed、进程非零退出、sshd 提前退出、回收失败均不能得到 passed。
- CI 新增 macOS/Linux 专用步骤，沿用 always 上传回执；Windows 不运行该步骤。此次没有执行或验收 CI。

验证命令共 **2 条 unittest 命令**，均从本报告目录执行，设置 `PYTHONDONTWRITEBYTECODE=1`、`TMPDIR=<本报告目录>/tmp`，每条进程外层超时 60 秒：

```text
python3 -B -m unittest discover -s snapshot/scripts -p test_openssh_interop.py -v
python3 -B -m unittest -v test_review_controls
```

| 命令 | run | passed | failed/errors | skipped | exit |
| --- | ---: | ---: | ---: | ---: | ---: |
| 四文件快照中的 Python unittest | 33 | 33 | 0 | 0 | 0 |
| 本审查自写的独立工装控制 | 12 | 12 | 0 | 0 | 0 |
| 合计 | 45 | 45 | 0 | 0 | 两次均 0 |

上述 45 项都是 Python 工装/进程 mock 测试，真实 SSH 会话数为 **0**；不能作为六项真实 OpenSSH 用例通过的凭据。实际解释器和完整命令见两个 JSON 回执。静态 Rust 库存为六个 test、六个 opt-in ignore；不是编译后库存，Rust 实际执行数为 0。

输入核对：四文件 SHA-256 在快照与测试后完全一致，HEAD 未变；详见 `manifest.before.json`、`integrity.after.json`。`scope.diff` 包含新增 Rust 文件，其 SHA-256 为 `a7fb574fb9f3467a075e3e154df4cd864d6d2aa17d2de60e4413ba0baf43af25`。范围外工作区状态出现文档和生产侧测试文件的并行变化；已保存前后状态，未读取/审查其源码，也未覆盖这些变化。

未验证：生产 forwarding 实现、Rust 编译及编译后库存、真实 OpenSSH/macOS/Linux 结果、Windows forwarding、CI 终态、原生 UI、发行。现有新增 disconnect 用例通过主动 `SshSession::close()` 驱动，没有覆盖 peer 侧突然断开/网络丢失；这也不能由本次 mock 控制补签。Cargo、fmt、Clippy、依赖门禁、sshd/ssh 启动、GUI、commit/push、共享资源清理均执行 0 次。

父级建议：先补足唯一 P2，再安排授权的真实 OpenSSH 六例执行和精确库存/回收原件核对；当前不签署“局部停止完整验收通过”。报告、快照和原始日志均保留于此目录。
