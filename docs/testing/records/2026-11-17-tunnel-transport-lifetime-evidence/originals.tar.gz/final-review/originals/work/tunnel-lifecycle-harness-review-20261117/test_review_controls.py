"""Independent harness controls. Every external process and signal is mocked."""

import contextlib
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import MagicMock, patch

REVIEW = Path(__file__).resolve().parent
sys.path.insert(0, str(REVIEW / "snapshot" / "scripts"))
import openssh_interop as interop


class ReviewControls(unittest.TestCase):
    def run_harness(
        self,
        *,
        flags=("--forwarding",),
        summary="test result: ok. 6 passed; 0 failed; 0 ignored;\n",
        test_exit=0,
        server_exit=None,
        cleanup=True,
    ):
        with tempfile.TemporaryDirectory(dir=REVIEW / "tmp", prefix="control-") as temporary:
            root = Path(temporary)
            output = root / "receipt"
            observed = {}
            server = MagicMock(pid=10_101, returncode=server_exit)
            server.poll.return_value = server_exit
            tests = MagicMock(pid=10_102, returncode=test_exit)
            tests.poll.return_value = test_exit

            def popen(command, **kwargs):
                self.assertNotIn("shell", kwargs)
                if command[0] == "/fixture-sshd":
                    observed["config"] = Path(command[-1]).read_text()
                    return server
                self.assertEqual(command[0], "/fixture-cargo")
                observed["test_command"] = command
                kwargs["stdout"].write(summary.encode())
                kwargs["stdout"].flush()
                return tests

            with contextlib.ExitStack() as stack:
                stack.enter_context(patch.object(interop, "ROOT", root))
                stack.enter_context(patch.object(interop.platform, "system", return_value="Darwin"))
                stack.enter_context(patch.object(sys, "argv", [
                    "openssh_interop.py", "--output", str(output), *flags,
                ]))
                stack.enter_context(patch.object(interop.os, "umask"))
                stack.enter_context(patch.object(interop.signal, "signal", return_value=None))
                stack.enter_context(patch.object(interop, "executable", side_effect=lambda name, *args: "/fixture-" + name))
                stack.enter_context(patch.object(interop, "reserve_port", return_value=33_333))
                stack.enter_context(patch.object(interop, "zmodem_peers", return_value={}))
                stack.enter_context(patch.object(interop.Runner, "run"))
                stack.enter_context(patch.object(interop.Runner, "capture_owned"))
                stack.enter_context(patch.object(interop, "process_info", return_value=(1, 1, ("fixture", 7), "R")))
                stack.enter_context(patch.object(interop, "wait_for_server"))
                stopped = stack.enter_context(patch.object(interop, "stop_owned", return_value=cleanup))
                stack.enter_context(patch.object(interop.subprocess, "Popen", side_effect=popen))
                no_run = stack.enter_context(patch.object(interop.subprocess, "run", side_effect=AssertionError("unmocked subprocess.run")))
                no_signal = stack.enter_context(patch.object(interop.os, "kill", side_effect=AssertionError("real signal")))
                no_ssh = stack.enter_context(patch.object(interop.socket, "create_connection", side_effect=AssertionError("real SSH socket")))
                stack.enter_context(contextlib.redirect_stdout(io.StringIO()))
                stack.enter_context(contextlib.redirect_stderr(io.StringIO()))
                code = interop.main()
                no_run.assert_not_called()
                no_signal.assert_not_called()
                no_ssh.assert_not_called()
            receipt = json.loads((output / "result.json").read_text())
            self.assertEqual(stopped.call_count, 2)
            self.assertTrue(receipt["cleanup"]["temporary_directory_removed"])
            return code, receipt, observed

    def assert_rejected(self, **kwargs):
        code, receipt, _ = self.run_harness(**kwargs)
        self.assertEqual(code, 1)
        self.assertEqual(receipt["outcome"], "failed")

    def test_six_passes_dispatch_only_forwarding(self):
        code, receipt, observed = self.run_harness()
        self.assertEqual(code, 0)
        self.assertEqual(receipt["passed_tests"], 6)
        command = observed["test_command"]
        self.assertEqual(command[command.index("--test") + 1], "forwarding_openssh")
        self.assertIn("--ignored", command)
        self.assertIn("--test-threads=1", command)

    def test_missing_summary_is_rejected(self):
        self.assert_rejected(summary="finished without a libtest summary\n")

    def test_zero_passes_are_rejected(self):
        self.assert_rejected(summary="test result: ok. 0 passed; 0 failed; 0 ignored;\n")

    def test_fewer_than_six_passes_are_rejected(self):
        self.assert_rejected(summary="test result: ok. 5 passed; 0 failed; 0 ignored;\n")

    def test_ignored_case_is_rejected(self):
        self.assert_rejected(summary="test result: ok. 6 passed; 0 failed; 1 ignored;\n")

    def test_failed_case_is_rejected(self):
        self.assert_rejected(summary="test result: FAILED. 6 passed; 1 failed; 0 ignored;\n")

    def test_nonzero_process_with_green_summary_is_rejected(self):
        self.assert_rejected(test_exit=101)

    def test_dead_sshd_with_green_summary_is_rejected(self):
        self.assert_rejected(server_exit=0)

    def test_failed_owned_cleanup_overrides_green_summary(self):
        self.assert_rejected(cleanup=False)

    def test_default_policy_keeps_forwarding_disabled(self):
        code, _, observed = self.run_harness(flags=())
        self.assertEqual(code, 0)
        self.assertIn("AllowTcpForwarding no", observed["config"].splitlines())
        self.assertNotIn("AllowTcpForwarding yes", observed["config"].splitlines())

    def test_monitor_policy_keeps_forwarding_disabled(self):
        code, _, observed = self.run_harness(flags=("--monitor-darwin",))
        self.assertEqual(code, 0)
        self.assertIn("AllowTcpForwarding no", observed["config"].splitlines())

    def test_zmodem_policy_keeps_forwarding_disabled(self):
        code, _, observed = self.run_harness(flags=("--zmodem",))
        self.assertEqual(code, 0)
        self.assertIn("AllowTcpForwarding no", observed["config"].splitlines())
        self.assertIn("PermitTTY yes", observed["config"].splitlines())


if __name__ == "__main__":
    unittest.main()
