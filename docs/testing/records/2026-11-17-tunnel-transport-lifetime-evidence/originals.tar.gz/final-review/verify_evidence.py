"""Offline cross-check of source inventory, stored receipts and lock-only delta."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
import tomllib

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
AUTHOR = OUT / "originals/work/tunnel-lifecycle-20261117"


def load(path):
    return json.loads(path.read_text())


def source_tests(path):
    return re.findall(r"#\[tokio::test\]\s+(?:#\[ignore[^\n]*\]\s+)?async fn (\w+)", path.read_text())


def libtest_names(path, suffix):
    return [line.removesuffix(suffix) for line in path.read_text().splitlines() if line.endswith(suffix)]


def passed_names(path):
    return re.findall(r"^test (\S+) \.\.\. ok$", path.read_text(), re.M)


spec = importlib.util.spec_from_file_location(
    "review_dependency_checker", ROOT / "scripts/check_dependencies.py"
)
checker = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = checker
spec.loader.exec_module(checker)
snapshot = checker.Snapshot()
inventory = checker.collect_dependencies(ROOT, snapshot)
lock = checker.LockGraph(snapshot.read(ROOT / "Cargo.lock"), inventory)
dependency_receipt = load(AUTHOR / "dependency-freshness-r2.json")
current_rows = [requirement.report() for requirement in inventory.requirements]
saved_rows = dependency_receipt["rust"]
assert len(current_rows) == len(saved_rows) == 113
assert Counter(json.dumps(row, sort_keys=True) for row in current_rows) == Counter(
    json.dumps({key: row[key] for key in current_rows[0]}, sort_keys=True)
    for row in saved_rows
)
direct_versions = []
for requirement in inventory.requirements:
    expected = requirement.report()
    matches = [row for row in saved_rows if all(row[key] == value for key, value in expected.items())]
    assert len(matches) == 1, expected
    saved = matches[0]
    versions = lock.direct_versions(requirement)
    assert saved["locked_versions"] == versions
    assert saved["status"] == "passed" and saved["errors"] == []
    assert saved["url"].startswith("https://crates.io/api/v1/crates/")
    direct_versions.append({"owner": expected["owner"], "package": requirement.name, "versions": versions})
snapshot.verify()
assert dependency_receipt["status"] == "passed" and dependency_receipt["errors"] == []
assert dependency_receipt["counts"] == {
    "registry_packages": 37, "requirements": 113, "local_packages": 6, "workspace_members": 6
}
before = tomllib.loads((OUT / "base/Cargo.lock").read_text())
after = tomllib.loads((OUT / "snapshot-r2/Cargo.lock").read_text())
lock_changes = []
assert before.keys() == after.keys()
for key in before:
    if key != "package":
        assert before[key] == after[key]
assert len(before["package"]) == len(after["package"])
for old, new in zip(before["package"], after["package"]):
    if old != new:
        lock_changes.append({
            "name": new["name"], "changed_fields": sorted(k for k in old.keys() | new.keys() if old.get(k) != new.get(k)),
            "before": old, "after": new,
        })
assert len(lock_changes) == 1 and lock_changes[0]["name"] == "uuid"
assert lock_changes[0]["changed_fields"] == ["checksum", "version"]
assert lock_changes[0]["before"]["version"] == "1.29.2"
assert lock_changes[0]["after"]["version"] == "1.29.3"

prefix = "forwarding::local_lifecycle_tests::"
local_names = sorted(prefix + name for name in source_tests(
    OUT / "snapshot-r2/crates/keelshell-session/src/forwarding/local_lifecycle_tests.rs"
))
compiled_local = sorted(
    name for name in libtest_names(OUT / "session-lib-list.stdout.log", ": test")
    if name.startswith(prefix)
)
parent_local = sorted(passed_names(AUTHOR / "local-lifecycle-r1/command.log"))
independent_local = sorted(passed_names(OUT / "local-lifecycle-prebuilt.stdout.log"))
assert len(local_names) == 16
assert local_names == compiled_local == parent_local == independent_local
local_receipt = load(AUTHOR / "local-lifecycle-r1/result.json")
assert all(local_receipt[k] is True for k in ("cleanup_confirmed", "reaped"))
assert local_receipt["returncode"] == local_receipt["wrapper_exit"] == 0

ssh_source = sorted(source_tests(OUT / "snapshot-r2/crates/keelshell-session/tests/forwarding_openssh.rs"))
ssh_compiled = sorted(libtest_names(OUT / "forwarding-openssh-list.stdout.log", ": test"))
ssh_passed = sorted(passed_names(AUTHOR / "openssh-forwarding-r1/tests.log"))
ssh_receipt = load(AUTHOR / "openssh-forwarding-r1/result.json")
assert len(ssh_source) == 6 and ssh_source == ssh_compiled == ssh_passed
assert ssh_receipt["outcome"] == "passed" and ssh_receipt["passed_tests"] == 6
assert all(step["returncode"] == 0 for step in ssh_receipt["steps"])
cleanup = ssh_receipt["cleanup"]
assert all(cleanup[key] is True for key in (
    "observed_processes_stopped", "owned_processes_stopped", "temporary_directory_removed"
))
assert cleanup["ancestry_unverified"] == []
temporary_directory_absent = not Path(ssh_receipt["temporary_directory"]).exists()
assert temporary_directory_absent
for name, size in ssh_receipt["logs"].items():
    assert (AUTHOR / "openssh-forwarding-r1" / name).stat().st_size == size

files = load(OUT / "evidence-manifest.json")
assert all(
    hashlib.sha256((OUT / row["copy"]).read_bytes()).hexdigest() == row["sha256"]
    for row in files["records"]
)
result = {
    "checked_utc": datetime.now(timezone.utc).isoformat(),
    "status": "passed",
    "independent_network_dependency_queries": 0,
    "dependency_receipt_matches_current_manifests_and_direct_lock_edges": True,
    "dependency_counts": dependency_receipt["counts"],
    "dependency_checked_at_utc": dependency_receipt["checked_at_utc"],
    "lock_changes": lock_changes,
    "local_source_compiled_parent_and_independent_names_equal": True,
    "local_test_count": len(local_names),
    "openssh_r2_source_r1_binary_and_r1_pass_names_equal": True,
    "openssh_r1_test_count": len(ssh_source),
    "openssh_r1_temporary_directory_absent_now": temporary_directory_absent,
    "openssh_r1_cleanup_receipt_consistent": True,
    "openssh_process_identity_census_independently_reconstructed": False,
    "copied_evidence_files_unchanged": len(files["records"]),
    "source_names": {"local": local_names, "openssh": ssh_source},
}
with (OUT / "offline-evidence-verification.json").open("x") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
print(json.dumps({key: value for key, value in result.items() if key not in ("lock_changes", "source_names")}))
