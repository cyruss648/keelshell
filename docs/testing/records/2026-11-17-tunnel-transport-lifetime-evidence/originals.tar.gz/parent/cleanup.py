"""Remove only task-owned, exact-Git-archived evidence after successful delivery."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[2]
SOURCE = sys.argv[1]
assert re.fullmatch(r"[0-9a-f]{40}", SOURCE)
MAIN = "docs/testing/records/2026-11-17-tunnel-transport-lifetime-evidence"
CI = "docs/testing/records/2026-11-17-independent-zmodem-peers-evidence/ci-completion"
ALLOWED = {
    "work/tunnel-lifecycle-20261117",
    "work/tunnel-lifecycle-harness-review-20261117",
    "work/tunnel-lifecycle-final-review-20261117",
    "work/zmodem-peer-ci-completion-20261117",
    "work/zmodem-peer-ci-review-20261117",
    "work/zmodem-independent-finalize-20261117",
}


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def git_bytes(path):
    return subprocess.check_output(
        ["git", "show", f"{SOURCE}:{path}"], cwd=ROOT, timeout=30
    )


def resources(baseline):
    target = (ROOT / baseline["target"]).stat()
    assert (target.st_dev, target.st_ino) == (baseline["device"], baseline["inode"])
    package_names = {row["path"].split(".app/", 1)[0] + ".app" for row in baseline["existing_package_files"]}
    assert len(package_names) == 1
    package = ROOT / next(iter(package_names))
    assert {str(path.relative_to(ROOT)) for path in package.rglob("*") if path.is_file()} == {
        row["path"] for row in baseline["existing_package_files"]
    }
    files = []
    for row in baseline["existing_package_files"]:
        path = ROOT / row["path"]
        raw = path.read_bytes()
        assert len(raw) == row["bytes"] and digest(raw) == row["sha256"]
        files.append({"path": row["path"], "bytes": len(raw), "sha256": digest(raw)})
    return {"target_device": target.st_dev, "target_inode": target.st_ino, "package_files": files}


manifest_files = {}
selections = []
archives = []
baseline = None
for directory in (MAIN, CI):
    archive_path = directory + "/originals.tar.gz"
    manifest_path = directory + "/manifest.json"
    raw = git_bytes(archive_path)
    metadata = git_bytes(manifest_path)
    assert raw == (ROOT / archive_path).read_bytes()
    assert metadata == (ROOT / manifest_path).read_bytes()
    manifest = json.loads(metadata)
    assert len(raw) == manifest["bytes"] and digest(raw) == manifest["sha256"]
    with tarfile.open(ROOT / archive_path) as archive:
        members = archive.getmembers()
        expected = {row["member"]: row for row in manifest["files"]}
        assert len(members) == len(expected) == manifest["members"]
        assert len({member.name for member in members}) == len(members)
        assert {member.name for member in members} == set(expected)
        for member in members:
            assert member.isfile()
            row = expected[member.name]
            content = archive.extractfile(member).read()
            assert len(content) == row["bytes"] and digest(content) == row["sha256"]
            assert row["source"] not in manifest_files
            manifest_files[row["source"]] = row
            if member.name == "parent/resources-before.json":
                baseline = json.loads(content)
            if member.name == "parent/final-gate-r2/result.json":
                gate = json.loads(content)
                assert gate["wrapper_exit"] == gate["returncode"] == 0 and gate["reaped"]
                assert gate["cleanup_confirmed"]
    selections.extend(manifest["selection"])
    archives.append({"path": archive_path, "sha256": digest(raw), "git_source": SOURCE})

assert baseline is not None
assert {row["source"] for row in selections} == ALLOWED
assert len(selections) == len(ALLOWED)
protected_before = resources(baseline)
planned = []
for selection in selections:
    root = ROOT / selection["source"]
    assert root.is_dir() and not root.is_symlink()
    descendants = list(root.rglob("*"))
    assert not any(path.is_symlink() for path in descendants)
    files = sorted(path for path in descendants if path.is_file())
    expected = {
        name: row for name, row in manifest_files.items()
        if name.startswith(selection["source"] + "/")
    }
    assert {str(path.relative_to(ROOT)) for path in files} == set(expected)
    assert len(files) == selection["files"]
    for path in files:
        row = expected[str(path.relative_to(ROOT))]
        raw = path.read_bytes()
        assert len(raw) == row["bytes"] and digest(raw) == row["sha256"]
    planned.append((root, files, descendants))

# All sources are verified before the first deletion. No process, branch,
# worktree, container, target cache or installed application is removed.
removed = []
for root, files, descendants in planned:
    count = len(files)
    size = sum(path.stat().st_size for path in files)
    for path in files:
        path.unlink()
    for path in sorted(
        (path for path in descendants if path.is_dir()),
        key=lambda path: len(path.parts), reverse=True,
    ):
        path.rmdir()
    root.rmdir()
    removed.append({"path": str(root.relative_to(ROOT)), "files": count, "logical_bytes": size})
protected_after = resources(baseline)
assert protected_before == protected_after
result = {
    "git_source": SOURCE, "archives": archives, "removed": removed,
    "files": sum(row["files"] for row in removed),
    "logical_bytes": sum(row["logical_bytes"] for row in removed),
    "protected_before": protected_before, "protected_after": protected_after,
    "all_sources_verified_before_deletion": True,
    "boundary": "Only exact archived task-owned files; no disk-space delta claim.",
}
destination = ROOT / MAIN / "delivery"
destination.mkdir(exist_ok=True)
with (destination / "cleanup-result.json").open("x") as output:
    json.dump(result, output, indent=2)
    output.write("\n")
print(json.dumps({key: result[key] for key in ("git_source", "files", "logical_bytes", "all_sources_verified_before_deletion")}))
