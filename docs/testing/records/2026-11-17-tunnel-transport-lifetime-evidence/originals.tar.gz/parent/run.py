"""Task-local bounded process runner; no credentials are recorded."""
from contextlib import ExitStack
from datetime import datetime, timezone
import json
from pathlib import Path
import signal
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "scripts"))
from openssh_interop import Runner, stop_owned


def main():
    name, seconds, *command = sys.argv[1:]
    output = Path(__file__).resolve().parent / name
    output.mkdir()
    started = time.monotonic()
    deadline = started + float(seconds)
    requested = []
    def interrupt(signum, _):
        requested.append(signum)
    def check():
        if requested:
            raise RuntimeError("interrupted")
    old = {sig: signal.signal(sig, interrupt) for sig in (signal.SIGINT, signal.SIGTERM)}
    report = {
        "name": name, "argv": command, "steps": [], "processes": [],
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "timeout_seconds": float(seconds),
    }
    code = 1
    with ExitStack() as stack:
        runner = Runner(output, deadline - 8, stack, report, check)
        try:
            runner.run("command", command)
            code = 0
        except Exception as error:
            report["failure_type"] = type(error).__name__
        finally:
            for sig in old:
                signal.signal(sig, signal.SIG_IGN)
            results = []
            for process in reversed(runner.processes):
                results.append(stop_owned(process, deadline, runner.owned[process]))
                process.wait(timeout=max(0.01, deadline - time.monotonic()))
            report["cleanup_confirmed"] = all(results)
            if not all(results):
                code = 1
            report["returncode"] = runner.processes[0].returncode if runner.processes else None
            report["reaped"] = all(process.returncode is not None for process in runner.processes)
            report["elapsed_seconds"] = time.monotonic() - started
            report["wrapper_exit"] = code
            (output / "result.json").write_text(json.dumps(report, indent=2) + "\n")
            for sig, handler in old.items():
                signal.signal(sig, handler)
    print(json.dumps({key: report[key] for key in ("name", "returncode", "reaped", "cleanup_confirmed", "elapsed_seconds", "wrapper_exit")}))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
