"""Seal task-owned evidence as exact bytes; never remove a source."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[2]
destination = ROOT / sys.argv[1]
destination.mkdir(parents=True, exist_ok=True)
archive = destination / "originals.tar.gz"
rows = []
selection = []
for spec in sys.argv[2:]:
    prefix, directory = spec.split(":", 1)
    source = ROOT / directory
    assert source.is_dir() and not source.is_symlink()
    files = sorted(path for path in source.rglob("*") if path.is_file())
    for path in files:
        assert not path.is_symlink()
        member = str(Path(prefix) / path.relative_to(source))
        raw = path.read_bytes()
        rows.append({
            "member": member, "source": str(path.relative_to(ROOT)),
            "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
        })
    selection.append({"prefix": prefix, "source": directory, "files": len(files)})
assert len({row["member"] for row in rows}) == len(rows)
with archive.open("xb") as target:
    with gzip.GzipFile(filename="", fileobj=target, mode="wb", mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w") as output:
            for row in rows:
                raw = (ROOT / row["source"]).read_bytes()
                assert hashlib.sha256(raw).hexdigest() == row["sha256"]
                info = tarfile.TarInfo(row["member"])
                info.size = len(raw)
                info.mode = 0o600
                output.addfile(info, io.BytesIO(raw))
raw = archive.read_bytes()
report = {
    "archive": archive.name, "bytes": len(raw),
    "sha256": hashlib.sha256(raw).hexdigest(),
    "members": len(rows), "logical_bytes": sum(row["bytes"] for row in rows),
    "selection": selection, "files": rows,
}
with (destination / "manifest.json").open("x") as output:
    json.dump(report, output, indent=2)
    output.write("\n")
print(json.dumps({key: value for key, value in report.items() if key not in ("files", "selection")}))
