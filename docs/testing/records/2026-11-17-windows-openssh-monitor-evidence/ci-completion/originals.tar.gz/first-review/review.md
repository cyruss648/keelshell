# Windows 首轮远端 CI 原件只读复核

结论：限定 **APPROVE**，仅批准所供本地原件的摘要、精确 SHA 绑定、Quality 计数及失败边界表述。新增完整性/计数发现 P0=0、P1=0、P2=0、P3=0。
真实 Windows SSH 首轮继续 **FAIL**；本报告不批准四文件修复，不代签修复后的 CI，不阻止父级及时提交。

唯一基线：`41671be1a7fdfd96cec3a57f876519aeab2fa0d5`。只使用本机已取回原件，无在线真实性刷新。

| 原 run | 状态 | 边界 |
|---|---|---|
| Quality 43990824137 | completed/success，三平台成功 | Windows 的真实 SSH 用例仍 ignored |
| Direct API 43990824533 | completed/success | API/独立对照及 capture replay；前置 SSH job skipped |
| OpenSSH 43990824640 | completed/failure，步骤 6 失败/exit 1 | 父 receipt FAIL / SSH FAIL / API PARTIAL |

| Quality | 普通 Rust passed/failed/ignored | 逐名=声明=汇总 | rustdoc passed | Python 主 run/skips | 包装 run/skips |
|---|---|---|---|---|---|
| windows-2025 | 3394/0/58 | 3452（94 套件） | 14 | 493/38 | 57/4 |
| macos-26 | 3407/0/60 | 3467（94 套件） | 14 | 493/3 | 57/0 |
| ubuntu-24.04 | 3400/0/61 | 3461（94 套件） | 14 | 493/3 | 57/0 |

各平台 rustdoc 均为 6 个子运行/14 项；声明、逐名结果和摘要相等。macOS/Linux 各另见嵌套 Python helper 30 run/0 skips；主 discovery、包装、嵌套 helper 和两个自定义 Rust harness 分列，不混加。原 `summarize_tests.py` revision 4 直接解析 ZIP 内 gate，逐套件结果摘要见 `quality-counts.json`，没有重跑测试。

SSH 的四个 PowerShell 原对象均在首条指令前保留并绑定身份，EXIT_PROCESS 事件已接收/继续、原 handle 已 signaled，且 cleanup 前自然 exit 0：

| 操作 | PID | 原对象 creation_time | exit event / exit code |
|---|---|---|---|
| probe | 1552 | 134393504113601598 | 0 / 0 |
| resources | 8696 | 134393504163468409 | 0 / 0 |
| processes | 5636 | 134393504213907915 | 0 / 0 |
| sockets | 3580 | 134393504240792771 | 0 / 0 |

四份 encoded payload 仅在内存解码并核对 assembly script SHA-256；观察到 argv0 后两个 ASCII 空格，归一化该一处空格后，wire 摘要及长度逐项相等。原命令行、script 和 wire 的摘要在 `summary.json`；未输出完整 Base64。

最终 snapshot：21 admissions/21 job 累计；20 个非 master 均有自然终态，退出码分布 0×14、255×5、1×1，不能概括为全部 exit 0。四个 PowerShell 以外含 sshd、cmd、conhost。master 最终 exit 125，不是 cleanup 前自然终态。debug 事件 1352 received/1352 continued，owned_handles_remaining=0、job_active_processes=0。

同时原件明确 `complete_original_object_census=false`、`admission_closed=false`、`terminal_proven=false`、`state=HOLD`，errors 为 `debug_admissions_job_census_incomplete`、`direct_termination_failed`；父 receipt 为 `OwnershipError`/`cleanup_failure=true`，owned-sshd terminal=null。exceptions 仅计数 263。最终 21/21、无活动进程和无未关闭句柄不能补签首次 census 失败。

首次失败的分项 census/时间点未记录，**精确首次失败子条件 UNKNOWN**。不能从最终 snapshot 或 argv0 双空格反推根因。Rust 子结果 PASS（22 个 assertion 全 true）及独立对照4 端点/排除 2 连接/3 接口/2 固定卷，只保留其完成的采集范围；Rust 自身也注明独立 oracle NOT_RUN_BY_RUST、原进程终态由父级证明。

Direct API 仅批准原 receipt 的 API PASS/SSH UNRUN/native GUI UNRUN、6 子进程 exit0/reaped、独立 Win32 对照和 1 passed/9 filtered 的 capture replay。job 133730642814 的前置 SSH 为 skipped。

ZIP：全部 5 份现有 ZIP / 140 成员的字节数、SHA-256、成员集合及 CRC 均匹配 fetch receipt；已有解包副本也逐字节匹配。SSH artifact 14287312342 的 GitHub digest 为 `87301385ce6ba76011476175fc566a3cefa6c435ab563c3e781b6c03f9ebbdec`；API artifact 14287416838 为 `f32b40a9680eb1273af7926766451815dbaf8ade27ece083ca9495d9e6596752`，两份均与原 ZIP 相等。logs ZIP 无 GitHub artifact digest，只核本机 fetch receipt。

**未核验范围**：Quality 元数据列出两个 interop artifact 14289351037/macOS、14288573317/Linux，所供目录没有其 ZIP；仅核元数据 SHA/run 绑定，无法核其内容与 GitHub digest。因此 artifact 摘要覆盖是所供 2/2、全部列出 artifact 2/4；不声称全部 Quality artifact 已复核，也不以日志替代其原件。

精确证据定位：`inputs.json` 列出原路径/字节/摘要；`zip-members.json` 列出全部成员摘要；`summary.json` 中的 bundle/jobs、Quality log_member、SSH 原对象字段及 digest 可复算上述结论。关键 SSH 成员为 `receipt.json`、`ssh-debug-cleanup.json`、`rust-client.json`；失败日志为 OpenSSH logs.zip 内步骤 6 第 17 行。

执行边界：真实 Windows 新执行 **0**，Cargo **0**，测试重跑 **0**，网络 **0**，委派 **0**，新 chat/worktree **0**。仅在本 review 目录写入，审计钩子禁止网络/子进程及目录外写入；所读原件和 parser 前后摘要相等。父级并行修改的产品/文档/Git/target 未冻结、未审查、未写入；本报告不是父级修复 full gate 或当前 checkout 清洁证明。实际离线执行 exit code/耗时/输出摘要见 `execution-r2-receipt.json`。复核工具首轮因 macOS 包装日志在 Ran 与 OK 之间交错一行 stdout 而停止，其 exit1 回执/原输出保留于 `execution-receipt.json` 和 `execution.stderr`；仅修正本目录解析器后复算，未改原件、未重跑产品测试。
