"""Offline first-CI evidence review; never launches Cargo, tests, or network I/O.

Run with python3 -B verify_originals.py. For another calculation without
overwriting evidence, use --output recompute-r2 (inside this review directory).
"""

import argparse
import base64
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath, PureWindowsPath
import re
import runpy
import sys
import zipfile

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
ORIGINALS = REPO / "work/windows-ssh-ci-originals-20261117"
PARSER = REPO / (
    "docs/testing/records/2026-11-17-windows-openssh-monitor-evidence/"
    "summarize_tests.py"
)
HEAD = "41671be1a7fdfd96cec3a57f876519aeab2fa0d5"
EXPECTED = {
    "quality-r1": (43990824137, "success"),
    "direct-api": (43990824533, "success"),
    "openssh-r1": (43990824640, "failure"),
}
WRITES = set()


def audit(event, args):
    """Enforce the permitted write set and prevent process/network execution."""
    target = None
    if event == "open":
        path, mode, flags = args
        if isinstance(path, (str, bytes, os.PathLike)) and (
            (isinstance(mode, str) and any(c in mode for c in "wax+"))
            or flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND)
        ):
            target = Path(os.fsdecode(path)).resolve()
    elif event in ("os.mkdir", "os.remove", "os.rmdir", "os.chmod", "os.utime"):
        target = Path(os.fsdecode(args[0])).resolve()
    elif event in ("os.rename", "os.link", "os.symlink"):
        raise PermissionError("Review does not rename, link, or remove evidence")
    elif event.startswith("socket.") or event in (
        "subprocess.Popen", "os.system", "os.posix_spawn", "os.exec", "os.fork",
    ):
        raise PermissionError("Review forbids network and child processes")
    if target is not None:
        if not target.is_relative_to(HERE):
            raise PermissionError("Write outside the authorized review directory")
        WRITES.add(str(target.relative_to(REPO)))


sys.addaudithook(audit)


def require(condition, label):
    if not condition:
        raise ValueError(label)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()


def load(path):
    return json.loads(path.read_bytes())


def rel(path):
    return str(path.relative_to(REPO))


def snapshot():
    paths = [PARSER]
    for label in EXPECTED:
        paths.extend(p for p in (ORIGINALS / label).rglob("*") if p.is_file())
    return [
        {"path": rel(p), "bytes": p.stat().st_size, "sha256": sha(p.read_bytes())}
        for p in sorted(paths)
    ]


def write_json(output, name, value):
    with (output / name).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def zip_review(label, fetch, artifacts):
    directory = ORIGINALS / label
    artifact_by_id = {a["id"]: a for a in artifacts["artifacts"]}
    inventories, totals = [], []
    downloaded_ids = set()
    require(
        {p.name for p in directory.glob("*.zip")} == {d["zip"] for d in fetch["downloads"]},
        f"{label}: ZIP inventory differs from fetch receipt",
    )
    for download in fetch["downloads"]:
        path = directory / download["zip"]
        raw = path.read_bytes()
        require(len(raw) == download["bytes"], f"{label}: ZIP byte count mismatch")
        require(sha(raw) == download["sha256"], f"{label}: ZIP SHA-256 mismatch")
        digest_match = None
        if "id" in download:
            downloaded_ids.add(download["id"])
            meta = artifact_by_id[download["id"]]
            require(download["name"] == meta["name"], f"{label}: artifact name mismatch")
            require(meta["size_in_bytes"] == len(raw), f"{label}: artifact size mismatch")
            require(
                meta["digest"] == download["github_digest"] == "sha256:" + sha(raw),
                f"{label}: artifact GitHub digest mismatch",
            )
            digest_match = True
        else:
            require(download["github_digest"] is None, f"{label}: unexpected logs digest")
        expected_members = {m["path"]: m for m in download["members"]}
        require(len(expected_members) == len(download["members"]), "Duplicate receipt member")
        members, extracted_count = [], 0
        with zipfile.ZipFile(path) as archive:
            names = archive.namelist()
            require(len(names) == len(set(names)), "Duplicate ZIP member")
            require(set(names) == set(expected_members), f"{label}: ZIP member set mismatch")
            for info in archive.infolist():
                require(not info.is_dir(), "Unexpected directory entry")
                name = PurePosixPath(info.filename)
                require(not name.is_absolute() and ".." not in name.parts, "Unsafe ZIP member")
                data = archive.read(info)  # zipfile also verifies CRC.
                actual = {"path": info.filename, "bytes": len(data), "sha256": sha(data)}
                require(actual == expected_members[info.filename], f"{label}: member mismatch")
                extracted = path.with_suffix("") / info.filename
                if extracted.is_file():
                    require(extracted.read_bytes() == data, f"{label}: extracted copy mismatch")
                    extracted_count += 1
                members.append(actual)
        inventories.append({"zip": rel(path), "members": members})
        totals.append({
            "zip": rel(path), "bytes": len(raw), "sha256": sha(raw),
            "members_checked": len(members), "member_mismatches": 0,
            "extracted_copies_checked": extracted_count,
            "github_digest": download["github_digest"],
            "github_digest_matched": digest_match,
        })
    missing = [
        {"id": a["id"], "name": a["name"], "github_digest": a["digest"],
         "reason": "ZIP absent from supplied local bundle; not fetched"}
        for a in artifacts["artifacts"] if a["id"] not in downloaded_ids
    ]
    return inventories, totals, missing


def python_summaries(raw, normalize):
    lines = normalize(raw).splitlines()
    rows = []
    for index, line in enumerate(lines):
        match = re.fullmatch(r"Ran (\d+) tests? in ([\d.]+)s", line)
        if match:
            following = [
                s for s in lines[index + 1:index + 8]
                if s.startswith("OK") or s.startswith("FAILED")
            ]
            require(bool(following), "Python summary lacks outcome")
            outcome = re.fullmatch(r"OK(?: \(skipped=(\d+)\))?", following[0])
            require(outcome is not None, "Python outcome is not OK")
            run, skipped = int(match[1]), int(outcome[1] or 0)
            rows.append({
                "line": index + 1, "run": run, "skipped": skipped,
                "passed": run - skipped, "failed": 0, "outcome": "OK",
            })
    return rows


def rust_counts(rows):
    totals = {
        key: sum(row["summary"][key] for row in rows)
        for key in ("passed", "failed", "ignored", "measured", "filtered")
    }
    declared = sum(row["declared_tests"] for row in rows)
    named = sum(len(row["results"]) for row in rows)
    require(declared == named == sum(totals[k] for k in ("passed", "failed", "ignored")),
            "Rust named/declared/summary total mismatch")
    return {"suites": len(rows), "declared": declared, "named": named, **totals}


def quality_review(parser):
    platforms, detail = {}, {}
    with zipfile.ZipFile(ORIGINALS / "quality-r1/logs.zip") as archive:
        for platform in ("windows-2025", "macos-26", "ubuntu-24.04"):
            member = f"native ({platform})/8_Rust quality gate.txt"
            raw = archive.read(member)
            result = parser["summarize"](raw)
            require(not result["inventory_result_summary_mismatches"], "Parser mismatch")
            rows = result["suites"] + result["doctest_runs_unassigned"]
            python = python_summaries(raw, parser["normalize"])
            require(python and python[0]["run"] == 493, "Unexpected primary Python run")
            docs = rust_counts(result["doctest_runs_unassigned"])
            require(docs["passed"] == 14 and docs["failed"] == docs["ignored"] == 0,
                    "Unexpected rustdoc count")
            important = {}
            for row in result["suites"]:
                header = row["suite"].replace("\\", "/")
                if (
                    ("unittests src/main.rs " in header and "keelshell_app" in header)
                    or ("unittests src/lib.rs " in header and "keelshell_session" in header)
                    or "tests/windows_monitor.rs " in header
                    or "tests/windows_openssh_monitor.rs " in header
                ):
                    important[header] = {
                        "declared": row["declared_tests"], **row["summary"],
                    }
            platforms[platform] = {
                "log_member": member, "log_sha256": sha(raw),
                "ordinary": rust_counts(result["suites"]), "rustdoc": docs,
                "named_declared_summary_equal": True,
                "python_main": python[0], "python_embedded_helpers": python[1:],
                "python_packaging": python_summaries(
                    archive.read(f"native ({platform})/4_Packaging regression tests.txt"),
                    parser["normalize"],
                ),
                "custom_harness_headers": result["custom_harness_headers"],
                "important_suites": important,
            }
            detail[platform] = {
                "raw_sha256": result["raw_sha256"], "parser_revision": result["parser_revision"],
                "rustdoc_headers": result["doctest_headers_unassigned"],
                "suites": [
                    {
                        "suite": row["suite"], "kind": row["kind"],
                        "header_line_in_workspace": row["header_line_in_workspace"],
                        "start_line_in_workspace": row["start_line_in_workspace"],
                        "declared": row["declared_tests"], "named": len(row["results"]),
                        "summary": row["summary"],
                        "name_result_sha256": sha(canonical(row["results"])),
                    }
                    for row in rows
                ],
            }
    return platforms, detail


def ssh_review():
    with zipfile.ZipFile(ORIGINALS / "openssh-r1/artifact-14287312342.zip") as archive:
        read = lambda name: json.loads(archive.read(name))
        receipt, debug, rust = map(read, (
            "receipt.json", "ssh-debug-cleanup.json", "rust-client.json",
        ))
        require(archive.read("source-head.stdout").decode().strip() == HEAD, "SSH source mismatch")
        require(archive.read("source-status.stdout") == b"", "SSH source was dirty")
        require(receipt["source"] == HEAD, "SSH receipt source mismatch")
        require((receipt["status"], receipt["ssh"], receipt["windows_api"]) ==
                ("FAIL", "FAIL", "PARTIAL"), "SSH failure boundary changed")
        require(receipt["cleanup_failure"] is True and receipt["reason"] == "OwnershipError",
                "SSH ownership failure missing")
        assemblies = {
            read(name)["script_sha256"]: read(name)
            for name in archive.namelist() if name.endswith(".assembly.json")
        }
        admissions = debug["admissions"]
        nonmasters = [a for a in admissions if not a["is_master"]]
        powershell = []
        for admission in admissions:
            if PureWindowsPath(admission["image"]).name.lower() != "powershell.exe":
                continue
            command = admission["command_line"]
            match = re.search(r"-EncodedCommand\s+([A-Za-z0-9+/=]+)\s*$", command, re.I)
            require(match is not None, "PowerShell command lacks encoded payload")
            script = base64.b64decode(match[1], validate=True).decode("utf-16le")
            assembly = assemblies[sha(script.encode())]
            require(command.startswith("powershell.exe  -NoLogo "), "Unexpected argv0 spacing")
            wire = command.replace("powershell.exe  ", "powershell.exe ", 1).encode("ascii")
            require(sha(wire) == assembly["wire_command_sha256"], "PowerShell wire mismatch")
            require(len(wire) == assembly["wire_command_ascii_bytes"], "Wire length mismatch")
            fields = (
                "pid", "creation_time", "retained_before_first_instruction",
                "identity_bound_before_first_continue", "exit_event_received",
                "exit_event_code", "exit_event_continued", "original_signaled",
                "exit_code", "natural_terminal_before_cleanup", "is_master",
            )
            require(all(admission[k] is True for k in (
                "retained_before_first_instruction", "identity_bound_before_first_continue",
                "exit_event_received", "exit_event_continued", "original_signaled",
                "natural_terminal_before_cleanup",
            )), "PowerShell original object lacks natural terminal proof")
            require(admission["exit_event_code"] == admission["exit_code"] == 0,
                    "PowerShell exit was nonzero")
            powershell.append({
                "operation": assembly["operation"], **{k: admission[k] for k in fields},
                "command_chars": len(command), "command_sha256": sha(command.encode()),
                "script_sha256": sha(script.encode()), "wire_sha256": sha(wire),
                "argv0_spaces": 2, "normalized_wire_matches_assembly": True,
            })
        require(len(powershell) == 4, "Expected four original PowerShell processes")
        require({p["operation"] for p in powershell} ==
                {"probe", "resources", "processes", "sockets"}, "Unexpected SSH operations")
        require(len(admissions) == debug["job_total_processes"] == 21, "Admission count mismatch")
        require(len(nonmasters) == 20 and all(
            a["natural_terminal_before_cleanup"] and a["original_signaled"]
            and a["exit_event_received"] and a["exit_event_continued"]
            for a in nonmasters
        ), "Nonmaster natural terminal evidence mismatch")
        require(debug["complete_original_object_census"] is False
                and debug["terminal_proven"] is False and debug["state"] == "HOLD",
                "Incomplete census must remain HOLD")
        require(rust["status"] == "PASS" and not rust["errors"]
                and all(a["passed"] for a in rust["assertion_evidence"]), "Rust partial evidence")
        comparison = read("comparison.json")
        owned = next(c for c in receipt["children"] if c["label"] == "owned-sshd")
        selected = (
            "evidence_kind", "state", "terminal_proven", "job_total_processes",
            "job_active_processes", "complete_original_object_census", "admission_closed",
            "admission_phase_closed", "identities_bound", "pending_process_objects",
            "debug_events_received", "debug_events_continued", "pending_debug_event",
            "debug_connections", "fallback_detaches", "owned_handles_remaining", "closed",
        )
        return {
            "status": receipt["status"], "ssh": receipt["ssh"],
            "windows_api": receipt["windows_api"], "native_gui": receipt["native_gui"],
            "source": receipt["source"], "reason": receipt["reason"],
            "cleanup_failure": receipt["cleanup_failure"],
            "powershell_originals": powershell,
            "final_debug": {k: debug[k] for k in selected},
            "admissions": len(admissions), "nonmasters": len(nonmasters),
            "nonmaster_natural_terminal": len(nonmasters),
            "nonmaster_exit_codes": dict(Counter(str(a["exit_code"]) for a in nonmasters)),
            "all_originals_retained_and_bound_before_continue": all(
                a["retained_before_first_instruction"]
                and a["identity_bound_before_first_continue"] for a in admissions
            ),
            "image_counts": dict(Counter(PureWindowsPath(a["image"]).name for a in admissions)),
            "exception_count_only": len(debug["exceptions"]),
            "debug_errors": debug["errors"],
            "owned_sshd": {
                "pid": owned["pid"], "observed_exit": owned["observed_exit"],
                "terminal": owned["terminal"], "errors": owned["errors"],
            },
            "master_exit_codes": [a["exit_code"] for a in admissions if a["is_master"]],
            "rust_partial": {
                "status": rust["status"], "assertions": len(rust["assertion_evidence"]),
                "all_assertions_passed": True, "errors": len(rust["errors"]),
                "test": rust["test"], "identity": rust["identity"],
                "independent_oracle_status": rust["independent_oracle_status"],
            },
            "comparison": {
                "owned_endpoints_matched": comparison["owned"]["owned_endpoints_matched"],
                "connected_tcp_excluded": comparison["owned"]["connected_tcp_excluded"],
                "networks_matched": comparison["resources"]["networks_matched"],
                "fixed_volume_count": len(comparison["resources"]["capacity_tolerances"]),
            },
            "first_failed_census_subcondition": "UNKNOWN",
            "first_failed_census_snapshot": "NOT_RECORDED_IN_SUPPLIED_ORIGINALS",
            "causal_inference_from_final_snapshot_or_argv0_spacing": "NOT_PERMITTED",
            "temporary_cleanup": read("ssh-cleanup.json"),
            "acceptance": "FAIL; final cleanup and Rust PASS do not override it",
        }


def direct_review(parser):
    with zipfile.ZipFile(ORIGINALS / "direct-api/artifact-14287416838.zip") as archive:
        receipt = json.loads(archive.read("receipt.json"))
        require((receipt["status"], receipt["windows_api"], receipt["ssh"]) ==
                ("PASS", "PASS", "UNRUN"), "Direct API scope changed")
        children = receipt["children"]
        require(len(children) == 6 and all(
            c["observed_exit"] == 0 and not c["errors"]
            and c["terminal"]["direct_reaped"] and c["terminal"]["pipes_drained"]
            and c["terminal"]["active_processes"] == 0 and not c["terminal"]["errors"]
            for c in children
        ), "Direct API child terminal mismatch")
        comparison = json.loads(archive.read("comparison.json"))
        result = {
            "status": receipt["status"], "windows_api": receipt["windows_api"],
            "ssh": receipt["ssh"], "native_gui": receipt["native_gui"],
            "scope": receipt["scope"], "children_reaped_exit_zero": len(children),
            "comparison": {
                "owned_endpoints_matched": comparison["owned"]["owned_endpoints_matched"],
                "connected_tcp_excluded": comparison["owned"]["connected_tcp_excluded"],
                "networks_matched": comparison["resources"]["networks_matched"],
                "fixed_volume_count": len(comparison["resources"]["capacity_tolerances"]),
            },
        }
    with zipfile.ZipFile(ORIGINALS / "direct-api/logs.zip") as archive:
        member = next(n for n in archive.namelist() if "/6_Captured API frames" in n)
        text = parser["normalize"](archive.read(member))
        require("test captured_windows_api_frames_are_accepted_through_authenticated_monitor_routing"
                " ... ok" in text, "Direct API routing replay lacks named PASS")
        require("1 passed; 0 failed; 0 ignored; 0 measured; 9 filtered out" in text,
                "Direct API replay counts changed")
        result["capture_replay"] = {
            "passed": 1, "failed": 0, "ignored": 0, "filtered": 9, "log_member": member,
        }
    return result


def render_report(summary):
    lines = [
        "# Windows 首轮远端 CI 原件只读复核",
        "",
        "结论：限定 **APPROVE**，仅批准所供本地原件的摘要、精确 SHA 绑定、"
        "Quality 计数及失败边界表述。新增完整性/计数发现 P0=0、P1=0、P2=0、P3=0。",
        "真实 Windows SSH 首轮继续 **FAIL**；本报告不批准四文件修复，不代签修复后的 CI，"
        "不阻止父级及时提交。",
        "",
        f"唯一基线：`{HEAD}`。只使用本机已取回原件，无在线真实性刷新。",
        "",
        "| 原 run | 状态 | 边界 |",
        "|---|---|---|",
        "| Quality 43990824137 | completed/success，三平台成功 | Windows 的真实 SSH 用例仍 ignored |",
        "| Direct API 43990824533 | completed/success | API/独立对照及 capture replay；前置 SSH job skipped |",
        "| OpenSSH 43990824640 | completed/failure，步骤 6 失败/exit 1 | 父 receipt FAIL / SSH FAIL / API PARTIAL |",
        "",
        "| Quality | 普通 Rust passed/failed/ignored | 逐名=声明=汇总 | rustdoc passed | Python 主 run/skips | 包装 run/skips |",
        "|---|---|---|---|---|---|",
    ]
    for platform, data in summary["quality"].items():
        r, p, packaging = data["ordinary"], data["python_main"], data["python_packaging"][0]
        lines.append(
            f"| {platform} | {r['passed']}/{r['failed']}/{r['ignored']} | "
            f"{r['named']}（{r['suites']} 套件） | {data['rustdoc']['passed']} | "
            f"{p['run']}/{p['skipped']} | {packaging['run']}/{packaging['skipped']} |"
        )
    lines.extend([
        "",
        "各平台 rustdoc 均为 6 个子运行/14 项；声明、逐名结果和摘要相等。"
        "macOS/Linux 各另见嵌套 Python helper 30 run/0 skips；主 discovery、包装、"
        "嵌套 helper 和两个自定义 Rust harness 分列，不混加。"
        "原 `summarize_tests.py` revision 4 直接解析 ZIP 内 gate，"
        "逐套件结果摘要见 `quality-counts.json`，没有重跑测试。",
        "",
        "SSH 的四个 PowerShell 原对象均在首条指令前保留并绑定身份，"
        "EXIT_PROCESS 事件已接收/继续、原 handle 已 signaled，且 cleanup 前自然 exit 0：",
        "",
        "| 操作 | PID | 原对象 creation_time | exit event / exit code |",
        "|---|---|---|---|",
    ])
    for row in summary["openssh"]["powershell_originals"]:
        lines.append(f"| {row['operation']} | {row['pid']} | {row['creation_time']} | 0 / 0 |")
    ssh = summary["openssh"]
    lines.extend([
        "",
        "四份 encoded payload 仅在内存解码并核对 assembly script SHA-256；"
        "观察到 argv0 后两个 ASCII 空格，归一化该一处空格后，wire 摘要及长度逐项相等。"
        "原命令行、script 和 wire 的摘要在 `summary.json`；未输出完整 Base64。",
        "",
        "最终 snapshot：21 admissions/21 job 累计；20 个非 master 均有自然终态，"
        "退出码分布 0×14、255×5、1×1，不能概括为全部 exit 0。"
        "四个 PowerShell 以外含 sshd、cmd、conhost。master 最终 exit 125，"
        "不是 cleanup 前自然终态。debug 事件 1352 received/1352 continued，"
        "owned_handles_remaining=0、job_active_processes=0。",
        "",
        "同时原件明确 `complete_original_object_census=false`、`admission_closed=false`、"
        "`terminal_proven=false`、`state=HOLD`，errors 为 "
        "`debug_admissions_job_census_incomplete`、`direct_termination_failed`；"
        "父 receipt 为 `OwnershipError`/`cleanup_failure=true`，owned-sshd terminal=null。"
        f"exceptions 仅计数 {ssh['exception_count_only']}。"
        "最终 21/21、无活动进程和无未关闭句柄不能补签首次 census 失败。",
        "",
        "首次失败的分项 census/时间点未记录，**精确首次失败子条件 UNKNOWN**。"
        "不能从最终 snapshot 或 argv0 双空格反推根因。"
        "Rust 子结果 PASS（22 个 assertion 全 true）及独立对照"
        "4 端点/排除 2 连接/3 接口/2 固定卷，只保留其完成的采集范围；"
        "Rust 自身也注明独立 oracle NOT_RUN_BY_RUST、原进程终态由父级证明。",
        "",
        "Direct API 仅批准原 receipt 的 API PASS/SSH UNRUN/native GUI UNRUN、"
        "6 子进程 exit0/reaped、独立 Win32 对照和 1 passed/9 filtered 的 capture replay。"
        "job 133730642814 的前置 SSH 为 skipped。",
        "",
        f"ZIP：全部 {summary['integrity']['zip_count']} 份现有 ZIP / "
        f"{summary['integrity']['member_count']} 成员的字节数、SHA-256、成员集合及 CRC "
        "均匹配 fetch receipt；已有解包副本也逐字节匹配。"
        "SSH artifact 14287312342 的 GitHub digest 为 "
        "`87301385ce6ba76011476175fc566a3cefa6c435ab563c3e781b6c03f9ebbdec`；"
        "API artifact 14287416838 为 "
        "`f32b40a9680eb1273af7926766451815dbaf8ade27ece083ca9495d9e6596752`，"
        "两份均与原 ZIP 相等。logs ZIP 无 GitHub artifact digest，只核本机 fetch receipt。",
        "",
        "**未核验范围**：Quality 元数据列出两个 interop artifact "
        "14289351037/macOS、14288573317/Linux，所供目录没有其 ZIP；"
        "仅核元数据 SHA/run 绑定，无法核其内容与 GitHub digest。"
        "因此 artifact 摘要覆盖是所供 2/2、全部列出 artifact 2/4；"
        "不声称全部 Quality artifact 已复核，也不以日志替代其原件。",
        "",
        "精确证据定位：`inputs.json` 列出原路径/字节/摘要；"
        "`zip-members.json` 列出全部成员摘要；`summary.json` 中的 bundle/jobs、"
        "Quality log_member、SSH 原对象字段及 digest 可复算上述结论。"
        "关键 SSH 成员为 `receipt.json`、`ssh-debug-cleanup.json`、`rust-client.json`；"
        "失败日志为 OpenSSH logs.zip 内步骤 6 第 17 行。",
        "",
        "执行边界：真实 Windows 新执行 **0**，Cargo **0**，测试重跑 **0**，网络 **0**，"
        "委派 **0**，新 chat/worktree **0**。仅在本 review 目录写入，"
        "审计钩子禁止网络/子进程及目录外写入；所读原件和 parser 前后摘要相等。"
        "父级并行修改的产品/文档/Git/target 未冻结、未审查、未写入；"
        "本报告不是父级修复 full gate 或当前 checkout 清洁证明。"
        "实际离线执行 exit code/耗时/输出摘要见 `execution-r2-receipt.json`。"
        "复核工具首轮因 macOS 包装日志在 Ran 与 OK 之间交错一行 stdout 而停止，"
        "其 exit1 回执/原输出保留于 `execution-receipt.json` 和 `execution.stderr`；"
        "仅修正本目录解析器后复算，未改原件、未重跑产品测试。",
        "",
    ])
    return "\n".join(lines)


def main():
    args = argparse.ArgumentParser(description=__doc__)
    args.add_argument("--output", default=".", help="New destination within this review directory")
    options = args.parse_args()
    output = (HERE / options.output).resolve()
    require(output.is_relative_to(HERE), "Output must remain inside the permitted write set")
    output.mkdir(parents=True, exist_ok=True)
    before = snapshot()
    parser = runpy.run_path(str(PARSER))
    bundles, all_members, all_zips, missing = {}, [], [], []
    for label, (run_id, conclusion) in EXPECTED.items():
        directory = ORIGINALS / label
        run, jobs, artifacts, fetch = (load(directory / name) for name in (
            "run.json", "jobs.json", "artifacts.json", "fetch-receipt.json",
        ))
        require(run["id"] == fetch["run_id"] == run_id, f"{label}: run mismatch")
        require(run["head_sha"] == fetch["source"] == HEAD, f"{label}: source mismatch")
        require(run["status"] == fetch["status"] == "completed", f"{label}: incomplete run")
        require(run["conclusion"] == fetch["conclusion"] == conclusion, f"{label}: conclusion")
        require(run["run_attempt"] == 1, f"{label}: not first attempt")
        require(jobs["total_count"] == len(jobs["jobs"]), f"{label}: incomplete jobs")
        projected_jobs = [
            {k: job[k] for k in ("id", "name", "status", "conclusion")} for job in jobs["jobs"]
        ]
        require(projected_jobs == fetch["jobs"], f"{label}: job receipt mismatch")
        require(all(j["head_sha"] == HEAD and j["run_id"] == run_id for j in jobs["jobs"]),
                f"{label}: job head/run mismatch")
        if label == "quality-r1":
            require(all(j["status"] == "completed" and j["conclusion"] == "success"
                        for j in jobs["jobs"]), "Quality jobs are not all successful")
        if label == "openssh-r1":
            require(len(jobs["jobs"]) == 1 and jobs["jobs"][0]["conclusion"] == "failure",
                    "SSH job failure missing")
            require(any(s["number"] == 6 and s["conclusion"] == "failure"
                        for s in jobs["jobs"][0]["steps"]), "SSH failed step mismatch")
        require(artifacts["total_count"] == len(artifacts["artifacts"]), "Artifact count mismatch")
        require(all(a["workflow_run"]["id"] == run_id
                    and a["workflow_run"]["head_sha"] == HEAD for a in artifacts["artifacts"]),
                f"{label}: artifact head/run mismatch")
        member_data, zip_data, unavailable = zip_review(label, fetch, artifacts)
        all_members.extend(member_data)
        all_zips.extend(zip_data)
        missing.extend({"bundle": label, **a} for a in unavailable)
        bundles[label] = {
            "run_id": run_id, "head_sha": HEAD, "run_attempt": 1,
            "status": run["status"], "conclusion": conclusion, "jobs": projected_jobs,
            "non_success_steps": [
                {"job_id": j["id"], "number": s["number"], "name": s["name"],
                 "status": s["status"], "conclusion": s["conclusion"]}
                for j in jobs["jobs"] for s in j.get("steps", []) if s["conclusion"] != "success"
            ],
        }
    direct_jobs = bundles["direct-api"]["jobs"]
    require(len(direct_jobs) == 2 and direct_jobs[1]["id"] == 133730642814
            and direct_jobs[1]["conclusion"] == "skipped", "SSH prerequisite must remain skipped")
    quality, quality_detail = quality_review(parser)
    summary = {
        "schema": 1, "created_utc": datetime.now(timezone.utc).isoformat(),
        "verdict": "LIMITED_APPROVE",
        "approval_scope": "supplied offline originals, counts, digest and failure boundaries only",
        "new_findings": {"P0": 0, "P1": 0, "P2": 0, "P3": 0},
        "baseline_head_sha": HEAD, "bundles": bundles,
        "quality": quality, "openssh": ssh_review(), "direct_api": direct_review(parser),
        "integrity": {
            "zip_count": len(all_zips), "member_count": sum(z["members_checked"] for z in all_zips),
            "zip_and_member_mismatches": 0, "zips": all_zips,
            "github_artifact_digest_verified": sum(z["github_digest_matched"] is True for z in all_zips),
            "github_artifacts_enumerated": 4, "unavailable_artifacts": missing,
            "complete_enumerated_artifact_coverage": not missing,
        },
        "execution_boundary": {
            "real_windows_new_executions": 0, "cargo_invocations": 0, "test_replays": 0,
            "network_calls": 0, "delegations": 0, "new_chats_or_worktrees": 0,
            "write_set": rel(HERE), "audited_write_paths_before_results": sorted(WRITES),
            "source_fix_review": "NOT_PERFORMED", "post_fix_ci": "NOT_SIGNED",
            "parent_commit_blocked_by_this_review": False,
        },
        "recompute": {
            "script": rel(Path(__file__).resolve()), "script_sha256": sha(Path(__file__).read_bytes()),
            "parser": rel(PARSER), "parser_sha256": sha(PARSER.read_bytes()),
            "parser_revision": 4,
            "command": "python3 -B work/windows-ssh-first-ci-review-20261117/verify_originals.py "
                       "--output recompute-r2",
        },
    }
    after = snapshot()
    require(before == after, "Read evidence changed during review")
    summary["integrity"]["input_files_checked_before_and_after"] = len(before)
    summary["integrity"]["input_aggregate_sha256"] = sha(canonical(before))
    summary["integrity"]["inputs_unchanged"] = True
    write_json(output, "inputs.json", before)
    write_json(output, "zip-members.json", all_members)
    write_json(output, "quality-counts.json", quality_detail)
    write_json(output, "summary.json", summary)
    with (output / "review.md").open("x", encoding="utf-8") as stream:
        stream.write(render_report(summary))
    print(json.dumps({
        "verdict": summary["verdict"], "new_findings": summary["new_findings"],
        "head_sha": HEAD, "zips": len(all_zips),
        "zip_members": summary["integrity"]["member_count"],
        "github_digests_verified": summary["integrity"]["github_artifact_digest_verified"],
        "unavailable_quality_artifacts": len(missing),
        "real_windows_new_executions": 0, "test_replays": 0, "inputs_unchanged": True,
        "write_paths": sorted(WRITES),
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
