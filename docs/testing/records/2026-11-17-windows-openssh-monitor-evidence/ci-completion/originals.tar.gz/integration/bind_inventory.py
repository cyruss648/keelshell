"""Bind independently listed test names to the actual final workspace run."""
import json
from pathlib import Path
import re

base=Path(__file__).resolve().parent
summary=json.loads((base/'gate-summary-r1.json').read_text())
settings={
 'app':('app-inventory-final-r1',lambda row:'unittests src/main.rs ' in row['suite'] and 'keelshell_app' in row['suite']),
 'session':('session-inventory-final-r1',lambda row:'unittests src/lib.rs ' in row['suite'] and 'keelshell_session' in row['suite']),
 'windows-routing':('windows-routing-inventory-final-r2',lambda row:'Running tests/windows_monitor.rs ' in row['suite']),
 'windows-ssh':('windows-ssh-inventory-final-r1',lambda row:'Running tests/windows_openssh_monitor.rs ' in row['suite']),
}
report={'targets':{},'mismatches':[]}
for name,(label,select) in settings.items():
 rows=[row for row in summary['suites'] if select(row)]
 assert len(rows)==1,(name,len(rows))
 row=rows[0]
 names=re.findall(r'^(\S+): test$',(base/(label+'.log')).read_text(),re.MULTILINE)
 results=dict(row['results'])
 assert len(names)==len(set(names))==len(results)
 assert set(names)==set(results)
 required={key:state for key,state in results.items() if 'windows' in key.lower() and state=='ok'}
 if name=='windows-ssh':
  assert results=={'actual_windows_openssh_monitor_matches_owned_fixture':'ignored'}
  required=dict(results)
 report['targets'][name]={'log':'integration/'+label+'.log','suite':row['suite'],'count':len(names),'required':required}
with (base/'inventory-bindings-r1.json').open('x') as output:
 json.dump(report,output,indent=2);output.write('\n')
print(json.dumps({'compiled_inventories':{k:v['count'] for k,v in report['targets'].items()},'mismatches':[]}))
