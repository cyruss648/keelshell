"""Remove only closed-agent/source-stage copies verified against committed evidence."""
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

root=Path.cwd();base=root/'work/windows-ssh-integration-20261117'
source='41671be1a7fdfd96cec3a57f876519aeab2fa0d5'
archive_path='docs/testing/records/2026-11-17-windows-openssh-monitor-evidence/originals.tar.gz'
raw=subprocess.check_output(['git','show',source+':'+archive_path],timeout=20)
assert raw==(root/archive_path).read_bytes()
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as archive:
 files={m.name:archive.extractfile(m).read() for m in archive.getmembers()}
selection=json.loads(files['selection.json'])
roots=[root/'work'/name for name in (
 'windows-ssh-rust-author-20261117','windows-ssh-debug-author-20261117',
 'windows-ssh-source-review-20261117','windows-ssh-lifecycle-review-20261117',
 'windows-ssh-official-research-20261117','windows-ssh-seal-20261117')]
expected={row['source']:row for row in selection['copied']+selection['upstream_reference_only']}
for name,content in files.items():
 expected['work/windows-ssh-seal-20261117/'+name]={'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest()}
plan=[]
for directory in roots:
 assert directory.is_dir() and not directory.is_symlink()
 for path in sorted(directory.rglob('*')):
  assert not path.is_symlink(),path
  if path.is_dir():continue
  name=str(path.relative_to(root));assert name in expected,name
  content=path.read_bytes();reference=expected[name]
  assert len(content)==reference['bytes'] and hashlib.sha256(content).hexdigest()==reference['sha256'],name
  plan.append({'path':name,'bytes':len(content),'sha256':reference['sha256']})
with (base/'cleanup-plan-r1.json').open('x') as output:json.dump({'source':source,'roots':[str(p.relative_to(root)) for p in roots],'entries':plan},output,indent=2);output.write('\n')
for directory in roots:shutil.rmtree(directory)
protected=json.loads((base/'protected-resources-before.json').read_text())
st=(root/protected['target']).stat()
assert {'device':st.st_dev,'inode':st.st_ino}==protected['target_directory_identity']
for row in protected['package_files']:
 path=root/row['path'];digest=hashlib.sha256()
 with path.open('rb') as stream:
  for chunk in iter(lambda:stream.read(1024*1024),b''):digest.update(chunk)
 assert path.stat().st_size==row['bytes'] and digest.hexdigest()==row['sha256']
record={'source':source,'removed_roots':len(roots),'removed_files':len(plan),'removed_bytes':sum(r['bytes'] for r in plan),'all_roots_absent':all(not p.exists() for p in roots),'all_bytes_verified_before_removal':True,'normal_package_unchanged':True,'shared_target_directory_identity_unchanged':True,'shared_target_cleaned':False,'other_worktrees_or_containers_touched':False,'parent_integration_and_active_ci_preserved':True}
with (base/'cleanup-result-r1.json').open('x') as output:json.dump(record,output,indent=2);output.write('\n')
print(json.dumps(record))
