"""Remove closed, Git-bound copies and the terminated native run's private state."""
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
evidence = "docs/testing/records/2026-11-17-windows-openssh-monitor-evidence/repair/"
source = "660e90d6f7c7111853db7b73f4ca2344f633700d"
raw = subprocess.check_output(["git", "show", source + ":" + evidence + "originals.tar.gz"],
                              cwd=ROOT, timeout=20)
assert raw == (ROOT / evidence / "originals.tar.gz").read_bytes()
manifest = json.loads(subprocess.check_output(
    ["git", "show", source + ":" + evidence + "manifest.json"], cwd=ROOT, timeout=20,
))
assert hashlib.sha256(raw).hexdigest() == manifest["archive_sha256"]
with tarfile.open(fileobj=io.BytesIO(raw), mode="r:gz") as archive:
    originals = {member.name: archive.extractfile(member).read() for member in archive.getmembers()}
assert len(originals) == manifest["count"]
planned = []
for name, prefix in [
    ("windows-ssh-repair-seal-20261117", ""),
    ("windows-ssh-repair-review-20261117", "review/"),
]:
    directory = ROOT / "work" / name
    assert directory.is_dir() and not directory.is_symlink()
    rows = []
    for path in directory.rglob("*"):
        assert not path.is_symlink()
        if path.is_file():
            relative = path.relative_to(directory).as_posix()
            assert path.read_bytes() == originals[prefix + relative], relative
            rows.append({"path": relative, "bytes": path.stat().st_size,
                         "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
    planned.append({"directory": str(directory.relative_to(ROOT)), "files": rows,
                    "basis": "closed reviewer/stage; exact repair archive from committed Git"})
runtime = ROOT / "work/native-toolbar-20261117/runtime"
native = json.loads((runtime.parent / "native-receipt.json").read_text())
assert native["observed_exit"] == native["controller_exit"] == 0
assert native["terminal"]["direct_reaped"] and native["terminal"]["active_processes"] == 0
assert json.loads((runtime.parent / "post-close-cleanup.json").read_text())["terminated"]
program = str(ROOT / "work/windows-monitor-delivery-20261117/package-r2/KeelShell.app/Contents/MacOS/keelshell-app")
processes = subprocess.check_output(["ps", "-axo", "pid=,command="], text=True, timeout=10)
assert not any(row.strip().endswith(program) for row in processes.splitlines())
rows = []
for path in runtime.rglob("*"):
    assert not path.is_symlink()
    if path.is_file():
        rows.append({"path": path.relative_to(runtime).as_posix(), "bytes": path.stat().st_size})
planned.append({"directory": str(runtime.relative_to(ROOT)), "files": rows,
                "basis": "created empty by this isolated run; original reaped and extra launch terminated; private content not archived"})
with (BASE / "repair-copy-cleanup-plan-r1.json").open("x") as output:
    json.dump(planned, output, indent=2)
    output.write("\n")
for entry in planned:
    shutil.rmtree(ROOT / entry["directory"])
    assert not (ROOT / entry["directory"]).exists()
protected = json.loads((BASE / "protected-resources-before.json").read_text())
target = (ROOT / protected["target"]).stat()
assert {"device": target.st_dev, "inode": target.st_ino} == protected["target_directory_identity"]
for row in protected["package_files"]:
    data = (ROOT / row["path"]).read_bytes()
    assert len(data) == row["bytes"] and hashlib.sha256(data).hexdigest() == row["sha256"]
result = {
    "completed_utc": datetime.now(timezone.utc).isoformat(),
    "directories": [entry["directory"] for entry in planned],
    "files": sum(len(entry["files"]) for entry in planned),
    "bytes": sum(row["bytes"] for entry in planned for row in entry["files"]),
    "normal_package_unchanged": True, "normal_package_was_launched_isolated": True,
    "target_directory_identity_unchanged": True, "other_resources_deleted": False,
}
with (BASE / "repair-copy-cleanup-result-r1.json").open("x") as output:
    json.dump(result, output, indent=2)
    output.write("\n")
print(json.dumps(result))
