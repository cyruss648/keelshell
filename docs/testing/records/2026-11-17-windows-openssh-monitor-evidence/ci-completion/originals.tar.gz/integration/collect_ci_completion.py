"""Seal completed exact-source CI and closed reviewers without replaying tests."""
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import runpy
import shutil

ROOT = Path.cwd()
BASE = ROOT / "work/windows-ssh-integration-20261117"
STAGE = ROOT / "work/windows-ssh-ci-completion-stage-20261117"
SOURCE = "660e90d6f7c7111853db7b73f4ca2344f633700d"
assert not STAGE.exists()
STAGE.mkdir()
summarizer = runpy.run_path(str(
    ROOT / "docs/testing/records/2026-11-17-windows-openssh-monitor-evidence/summarize_tests.py"))


def copy_files(source, destination, *, only_original_zips=False):
    """Retain immutable originals; expanded ZIP copies are redundant."""
    destination.mkdir(parents=True, exist_ok=True)
    for path in sorted(source.rglob("*")):
        if not path.is_file() or "__pycache__" in path.parts:
            continue
        relative = path.relative_to(source)
        if only_original_zips and len(relative.parts) != 1:
            continue
        assert not path.is_symlink()
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as output:
            output.write(path.read_bytes())


runs = {
    "openssh-r1": (43997403565, "openssh-repair-r1"),
    "openssh-repeat": (43998970900, "openssh-repair-repeat-r1"),
    "direct-api": (43997403484, "direct-api-repair-r1"),
    "quality": (43997403533, "quality-repair-r2"),
}
originals = ROOT / "work/windows-ssh-ci-originals-20261117"
for label, (identifier, directory) in runs.items():
    origin = originals / directory
    receipt = json.loads((origin / "fetch-receipt.json").read_text())
    assert receipt["run_id"] == identifier and receipt["source"] == SOURCE
    assert receipt["status"] == "completed" and receipt["conclusion"] == "success"
    copy_files(origin, STAGE / "ci" / label, only_original_zips=True)

counts = {}
details = {}
for platform in ("windows-2025", "macos-26", "ubuntu-24.04"):
    raw = (originals / "quality-repair-r2/logs" /
           f"native ({platform})/8_Rust quality gate.txt").read_bytes()
    report = summarizer["summarize"](raw)
    assert not report["inventory_result_summary_mismatches"]
    assert all(row["summary"]["failed"] == 0
               for row in report["suites"] + report["doctest_runs_unassigned"])
    section = summarizer["normalize"](raw).split("Running: cargo fmt --all --check", 1)[0]
    runs_found = list(re.finditer(r"^Ran (\d+) tests in [\d.]+s$", section, re.MULTILINE))
    outcomes = list(re.finditer(r"^OK(?: \(skipped=(\d+)\))?$", section, re.MULTILINE))
    assert len(runs_found) == len(outcomes) == 1
    assert outcomes[0].start() > runs_found[0].end()
    assert not re.search(r"^(?:FAIL:|ERROR:|FAILED\b)", section, re.MULTILINE)
    counts[platform] = {
        "ordinary_rust": {key: sum(row["summary"][key] for row in report["suites"])
                          for key in ("passed", "failed", "ignored")},
        "rustdoc_passed": sum(row["summary"]["passed"] for row in report["doctest_runs_unassigned"]),
        "python": {"run": int(runs_found[0][1]), "skipped": int(outcomes[0][1] or 0)},
    }
    details[platform] = report

copy_files(ROOT / "work/windows-ssh-repair-ci-review-20261117", STAGE / "review")
copy_files(ROOT / "work/windows-ssh-first-ci-review-20261117", STAGE / "first-review")
baseline_agents = json.loads((BASE / "agent-lifecycle-final.json").read_text())["batch_agents"]
repair_agents = json.loads((BASE / "repair-agent-lifecycle.json").read_text())["repair_source_reviewers"]
additional = [
    ("Faraday", "01a1e724-d4c2-7dd3-af79-09dc8d2c7fe6", "first CI originals"),
    ("Hume", "01a1e734-70bf-7611-b422-1076fb0f9428", "native toolbar subset"),
    ("Darwin", "01a1e73e-77bd-7663-b06c-23d3e37b91eb", "two repaired SSH runs and direct API"),
]
agents = baseline_agents + repair_agents + [
    {"name": name, "id": identifier, "role": role, "closed": True,
     "close_observation": "Actual close_agent result recorded before this handoff; no new close requested"}
    for name, identifier, role in additional
]
assert len(agents) == len({agent["id"] for agent in agents}) == 8
assert all(agent["closed"] for agent in agents)
acceptance = {
    "source": SOURCE, "runs": {key: value[0] for key, value in runs.items()},
    "quality_counts": counts,
    "source_freeze": "fb78496b8d0b22bd6fc38da46df994d16c144d1f040f83ff468a98c49ff633af",
    "earlier_failure": {
        "run": 43990824640, "conclusion": "failure",
        "first_bad_census_subreadings": "UNKNOWN", "race_proven": False,
    },
    "native_desktop_acceptance": False,
}
for name, value in {
    "acceptance.json": acceptance,
    "quality-detailed-summary.json": details,
    "agent-lifecycle.json": {
        "observed_utc": datetime.now(timezone.utc).isoformat(),
        "all_owned_agents_closed": True, "agents": agents,
        "new_user_chats": 0, "new_worktrees": 0, "new_containers": 0,
    },
    "analysis-failure-r1.json": {
        "kind": "evidence-parser-error", "accepted": False,
        "exception": "IndexError: list index out of range",
        "input": "quality-repair-r1/logs/native (macos-26)/8_Rust quality gate.txt",
        "cause": "Merged child stdout appears between unittest Ran and OK on stderr.",
        "resolution": "Require one ordered Ran/OK pair before fmt; reject FAIL/ERROR.",
        "quality_r1_artifact_selection": "Wrong prefix interoperability selected no artifacts; r2 used actual openssh-interop names.",
        "product_test_failures": 0,
    },
}.items():
    with (STAGE / name).open("x") as output:
        json.dump(value, output, indent=2)
        output.write("\n")

# Preserve all completed parent receipts, including failed instrumentation and
# superseded observations. No runtime, packages or private key data live here.
copy_files(BASE, STAGE / "integration")
for directory in ("windows-ssh-ci-repair-watch-20261117", "windows-ssh-repeat-watch-20261117"):
    origin = ROOT / "work" / directory
    if origin.exists():
        copy_files(origin, STAGE / "observations" / directory)
print(json.dumps({"source": SOURCE, "quality": counts,
                  "stage_members": sum(path.is_file() for path in STAGE.rglob("*")),
                  "agents_closed": len(agents), "product_tests_replayed": 0}))
