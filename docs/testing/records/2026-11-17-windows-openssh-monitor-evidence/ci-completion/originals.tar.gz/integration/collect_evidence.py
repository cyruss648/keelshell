"""Copy stable, owned receipts; retain upstream references without manual copies."""
import hashlib
import json
from pathlib import Path

ROOT = Path.cwd()
stage = ROOT / 'work/windows-ssh-seal-20261117'
stage.mkdir(exist_ok=False)
sources = {
    'integration': ROOT / 'work/windows-ssh-integration-20261117',
    'rust-author': ROOT / 'work/windows-ssh-rust-author-20261117',
    'debug-author': ROOT / 'work/windows-ssh-debug-author-20261117',
    'source-review': ROOT / 'work/windows-ssh-source-review-20261117',
    'lifecycle-review': ROOT / 'work/windows-ssh-lifecycle-review-20261117',
    'official-research': ROOT / 'work/windows-ssh-official-research-20261117',
}
# Their fixed upstream blob/hash receipts are retained. Repeated upstream prose
# and successful API response bodies are research inputs, not test originals.
reference_names = {
    'debug-author': {'official-github-docs.json'},
    'official-research': {'debug-events.json', 'process-creation-flags.json',
                          'openssh-configuration.json', 'openssh-config.json'},
}
selection = {'copied': [], 'upstream_reference_only': [], 'excluded_runtime': []}
for label, source in sources.items():
    assert source.is_dir()
    for path in sorted(source.rglob('*')):
        relative = path.relative_to(source)
        if any(part in {'__pycache__', 'runtime-tmp', 'check-temporary'} for part in relative.parts):
            if path.is_file(): selection['excluded_runtime'].append(str(path.relative_to(ROOT)))
            continue
        if path.is_dir(): continue
        assert path.is_file() and not path.is_symlink(), path
        raw = path.read_bytes()
        row = {'source': str(path.relative_to(ROOT)), 'path': label + '/' + relative.as_posix(),
               'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
        upstream = (path.name in reference_names.get(label, set())
                    or label == 'official-research' and path.suffix == '.md'
                    or label == 'debug-author' and path.name.startswith('github-') and path.suffix == '.md'
                    or label == 'lifecycle-review' and path.name in {
                        'get-exit-code-process-api.md', 'terminating-a-process.md',
                        'terminate-process-api.md', 'sync-objects.md', 'exit-process-debug-info.md'})
        if upstream:
            selection['upstream_reference_only'].append(row)
            continue
        destination = stage / row['path']
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open('xb') as output: output.write(raw)
        assert path.read_bytes() == destination.read_bytes()
        selection['copied'].append(row)
with (stage / 'selection.json').open('x') as output:
    json.dump(selection, output, indent=2); output.write('\n')
print(json.dumps({'stage': str(stage.relative_to(ROOT)),
                  'copied': len(selection['copied']),
                  'upstream_references': len(selection['upstream_reference_only']),
                  'excluded_runtime': len(selection['excluded_runtime'])}))
