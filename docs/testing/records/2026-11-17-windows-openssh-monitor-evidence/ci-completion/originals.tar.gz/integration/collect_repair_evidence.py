"""Collect the exact four-file repair and preserve the first Windows failure."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
DEST = ROOT / "work/windows-ssh-repair-seal-20261117"
DEST.mkdir(exist_ok=False)
paths = []


def copy(source, relative):
    source = Path(source)
    target = DEST / relative
    assert source.is_file() and not source.is_symlink()
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    assert source.read_bytes() == target.read_bytes()
    paths.append({
        "source": str(source.relative_to(ROOT)), "archive": relative,
        "bytes": source.stat().st_size,
        "sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
    })


labels = [
    "repair-python-r1", "repair-windows-integration-r1", "full-gate-r2",
    "quality-watch-first-r1", "fetch-quality-first-r1",
]
for label in labels:
    for suffix in (".json", ".log"):
        copy(BASE / (label + suffix), "integration/" + label + suffix)
for name in [
    "full-gate-inputs-r2.json", "full-gate-inputs-after-r2.json",
    "repair-candidate-inputs-r1.json", "gate-summary-r2.json",
    "windows-ssh-failure-analysis-r1.json", "repair-agent-lifecycle.json",
    "run_command.py", "snapshot_inputs.py", "fetch_run.py",
]:
    copy(BASE / name, "integration/" + name)
review = ROOT / "work/windows-ssh-repair-review-20261117"
for source in sorted(review.rglob("*")):
    if source.is_file() and "__pycache__" not in source.parts:
        copy(source, "review/" + source.relative_to(review).as_posix())
for label in ("quality-r1", "direct-api", "openssh-r1"):
    source = ROOT / "work/windows-ssh-ci-originals-20261117" / label
    receipt = json.loads((source / "fetch-receipt.json").read_text())
    for name in ("run.json", "jobs.json", "artifacts.json", "fetch-receipt.json"):
        copy(source / name, "first-ci/" + label + "/" + name)
    for download in receipt["downloads"]:
        copy(source / download["zip"], "first-ci/" + label + "/" + download["zip"])

baseline = "41671be1a7fdfd96cec3a57f876519aeab2fa0d5"
changed = subprocess.check_output(
    ["git", "diff", "--name-only", baseline, "--", ".", ":!docs", ":!.hallmark"],
    cwd=ROOT, text=True, timeout=20,
).splitlines()
assert len(changed) == 4 and all(name.endswith(".py") for name in changed)
patch = subprocess.check_output(
    ["git", "--no-pager", "diff", "--no-ext-diff", baseline, "--", *changed],
    cwd=ROOT, timeout=20,
)
(DEST / "repair.diff").write_bytes(patch)
acceptance = {
    "baseline_source": baseline,
    "changed_engineering_inputs": sorted(changed),
    "commands": [{"path": "integration/" + label, "expected_exit": 0} for label in labels],
    "python_discovery": {"run": 501, "skipped": 3},
    "rust_inventory_source": "../originals.tar.gz, original independent compiled inventories",
    "rust_inputs_unchanged": True,
    "repair_windows_ssh_acceptance": False,
    "native_desktop_acceptance": False,
}
(DEST / "acceptance.json").write_text(json.dumps(acceptance, indent=2) + "\n")
(DEST / "selection.json").write_text(json.dumps({
    "collected_utc": datetime.now(timezone.utc).isoformat(),
    "entries": paths, "first_ci_failure_preserved": True,
}, indent=2) + "\n")
print(json.dumps({"directory": str(DEST), "copied": len(paths),
                  "changed_inputs": changed}))
