"""Dispatch one additional exact-source native run for the timing repair."""
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import time

BASE = Path(__file__).resolve().parent
SOURCE = "660e90d6f7c7111853db7b73f4ca2344f633700d"
BRANCH = "feature/editor-unicode-codec-20261114"
API = "repos/cyruss648/keelshell/"
started = datetime.now(timezone.utc)
head = subprocess.check_output(
    ["git", "ls-remote", "--heads", "origin", "refs/heads/" + BRANCH],
    text=True, timeout=40,
).split()[0]
assert head == SOURCE
result = subprocess.run(
    ["gh", "workflow", "run", "windows-monitor-ssh.yml", "--ref", BRANCH],
    capture_output=True, text=True, timeout=40, check=False,
)
(BASE / "ssh-repeat-dispatch.stdout").write_text(result.stdout)
(BASE / "ssh-repeat-dispatch.stderr").write_text(result.stderr)
assert result.returncode == 0
for attempt in range(1, 9):
    raw = subprocess.check_output([
        "gh", "api", "--method", "GET",
        API + "actions/workflows/windows-monitor-ssh.yml/runs?head_sha=" + SOURCE + "&per_page=30",
    ], timeout=35)
    (BASE / f"ssh-repeat-find-{attempt}.json").write_bytes(raw)
    runs = [
        run for run in json.loads(raw)["workflow_runs"]
        if run["head_sha"] == SOURCE and run["event"] == "workflow_dispatch"
        and datetime.fromisoformat(run["created_at"].replace("Z", "+00:00")) >=
        started.replace(microsecond=0)
    ]
    if runs:
        assert len(runs) == 1
        value = {key: runs[0][key] for key in (
            "id", "name", "event", "head_sha", "status", "conclusion",
            "run_attempt", "created_at", "html_url",
        )}
        (BASE / "ssh-repeat-dispatch.json").write_text(json.dumps(value, indent=2) + "\n")
        print(json.dumps(value))
        break
    time.sleep(2)
else:
    raise RuntimeError("Dispatched run identity was not observed")
