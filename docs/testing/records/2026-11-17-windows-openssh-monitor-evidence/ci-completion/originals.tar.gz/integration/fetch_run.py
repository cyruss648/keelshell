"""Preserve exact GitHub run metadata/logs and selected original artifact ZIPs."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys
import zipfile

run_id, directory, *prefixes=sys.argv[1:]
assert run_id.isdecimal()
base=Path(directory);base.mkdir(parents=True,exist_ok=False)
repo='repos/cyruss648/keelshell/'

def request(label,endpoint):
 p=base/(label+'.json');e=base/(label+'.stderr')
 with p.open('xb') as output,e.open('xb') as error:
  result=subprocess.run(['gh','api','--method','GET',repo+endpoint],stdout=output,stderr=error,timeout=45,check=False)
 assert result.returncode==0,(label,result.returncode)
 return label,json.loads(p.read_bytes())

with ThreadPoolExecutor(max_workers=3) as pool:
 futures=[pool.submit(request,label,endpoint) for label,endpoint in [
  ('run','actions/runs/'+run_id),('jobs','actions/runs/'+run_id+'/jobs?per_page=100'),
  ('artifacts','actions/runs/'+run_id+'/artifacts?per_page=100')]]
 values=dict(f.result() for f in futures)
assert str(values['run']['id'])==run_id


def zipped(label,endpoint,digest=None):
 p=base/(label+'.zip');e=base/(label+'.stderr')
 with p.open('xb') as output,e.open('xb') as error:
  result=subprocess.run(['gh','api','--method','GET',repo+endpoint],stdout=output,stderr=error,timeout=90,check=False)
 assert result.returncode==0,(label,result.returncode)
 actual=hashlib.sha256(p.read_bytes()).hexdigest()
 if digest is not None:assert digest=='sha256:'+actual,(label,'artifact digest mismatch')
 destination=base/label;destination.mkdir()
 rows=[]
 with zipfile.ZipFile(p) as archive:
  entries=archive.infolist();assert len(entries)<=1000
  assert sum(i.file_size for i in entries)<=128*1024*1024
  for item in entries:
   name=PurePosixPath(item.filename)
   assert not name.is_absolute() and '..' not in name.parts and '\\' not in item.filename
   if item.is_dir():continue
   content=archive.read(item)
   target=destination/name;target.parent.mkdir(parents=True,exist_ok=True)
   with target.open('xb') as output:output.write(content)
   rows.append({'path':str(name),'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest()})
 return {'zip':p.name,'bytes':p.stat().st_size,'sha256':actual,'github_digest':digest,'members':rows}

records=[]
if values['run']['status']=='completed':records.append(zipped('logs','actions/runs/'+run_id+'/logs'))
for artifact in values['artifacts']['artifacts']:
 if any(artifact['name'].startswith(prefix) for prefix in prefixes):
  assert not artifact['expired']
  records.append({'id':artifact['id'],'name':artifact['name'],**zipped('artifact-'+str(artifact['id']),'actions/artifacts/'+str(artifact['id'])+'/zip',artifact.get('digest'))})
receipt={'run_id':int(run_id),'source':values['run']['head_sha'],'status':values['run']['status'],'conclusion':values['run']['conclusion'],'jobs':[{key:j[key] for key in ('id','name','status','conclusion')} for j in values['jobs']['jobs']],'downloads':records}
with (base/'fetch-receipt.json').open('x') as output:json.dump(receipt,output,indent=2);output.write('\n')
print(json.dumps({key:value for key,value in receipt.items() if key!='downloads'}))
print(json.dumps({'downloaded_archives':len(records),'downloaded_bytes':sum(r['bytes'] for r in records)}))
