"""Verify the complete frozen input set and staged evidence bytes before commit."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import subprocess

base=Path(__file__).resolve().parent
freeze=json.loads((base/'full-gate-inputs-r1.json').read_text())
subprocess.run(['git','diff','--cached','--check'],check=True,timeout=30)
names=sorted(n.decode() for n in subprocess.check_output(['git','ls-files','-z'],timeout=20).split(b'\0') if n and not n.startswith((b'docs/',b'.hallmark/')))
assert names==[r['path'] for r in freeze['inputs']]
delta=[n.decode() for n in subprocess.check_output(['git','diff','--cached','--name-only','-z'],timeout=20).split(b'\0') if n]
rows={r['path']:r for r in freeze['inputs']}
for name in delta:
 raw=Path(name).read_bytes()
 rows[name]={'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def verify(row):
 raw=subprocess.check_output(['git','show',':'+row['path']],timeout=20)
 assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'],row['path']
with ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(verify,rows.values()))
assert not subprocess.check_output(['git','diff','--name-only'],timeout=20)
record={'engineering_inputs':len(freeze['inputs']),'staged_changed_paths':len(delta),'unique_inputs_and_changed_docs':len(rows),'all_git_index_blobs_match':True,'unstaged_tracked_changes':0,'source_aggregate_sha256':freeze['aggregate_sha256']}
with (base/'git-index-verification-r1.json').open('x') as output:json.dump(record,output,indent=2);output.write('\n')
print(json.dumps(record))
