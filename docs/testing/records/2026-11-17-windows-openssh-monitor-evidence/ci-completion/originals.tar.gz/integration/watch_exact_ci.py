"""Observe exact-source workflow states through bounded, authenticated GETs."""
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import subprocess
import sys
import time

source, output = sys.argv[1:]
assert re.fullmatch(r"[0-9a-f]{40}", source)
base = Path(output)
base.mkdir(parents=True, exist_ok=False)
required = {"Quality", "Windows monitor integration", "Windows OpenSSH monitor integration"}
end = time.monotonic() + 2400
previous = None
iteration = 0
while time.monotonic() < end:
    iteration += 1
    result = subprocess.run([
        "gh", "api", "--method", "GET",
        "repos/cyruss648/keelshell/actions/runs?head_sha=" + source + "&per_page=50",
    ], capture_output=True, timeout=35, check=False)
    prefix = base / f"poll-{iteration:03d}"
    prefix.with_suffix(".stdout.json").write_bytes(result.stdout)
    prefix.with_suffix(".stderr").write_bytes(result.stderr)
    snapshot = {"observed_utc": datetime.now(timezone.utc).isoformat(), "source": source,
                "iteration": iteration, "api_exit": result.returncode, "runs": []}
    if result.returncode == 0:
        value = json.loads(result.stdout)
        for run in value["workflow_runs"]:
            if run["head_sha"] == source:
                snapshot["runs"].append({key: run[key] for key in (
                    "id", "name", "head_sha", "status", "conclusion", "run_attempt", "html_url")})
    else:
        snapshot["api_read_failed"] = True
    selected = {row["name"]: row for row in snapshot["runs"] if row["name"] in required}
    snapshot["missing"] = sorted(required - set(selected))
    snapshot["all_required_complete"] = not snapshot["missing"] and all(
        row["status"] == "completed" for row in selected.values())
    snapshot["all_required_success"] = snapshot["all_required_complete"] and all(
        row["conclusion"] == "success" for row in selected.values())
    prefix.with_suffix(".state.json").write_text(json.dumps(snapshot, indent=2) + "\n")
    staging = base / "latest.pending"
    staging.write_text(json.dumps(snapshot, indent=2) + "\n")
    staging.replace(base / "latest.json")
    status = [(r["name"], r["status"], r["conclusion"]) for r in snapshot["runs"]]
    if status != previous:
        print(json.dumps({"iteration": iteration, "runs": status, "missing": snapshot["missing"]}), flush=True)
        previous = status
    terminal_failure = any(r["status"] == "completed" and r["conclusion"] != "success"
                           for r in selected.values())
    if terminal_failure or snapshot["all_required_complete"]:
        sys.exit(0 if snapshot["all_required_success"] else 1)
    time.sleep(min(20, max(0, end - time.monotonic())))
raise SystemExit(124)
