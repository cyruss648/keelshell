#!/usr/bin/env python3
"""Record an actual, reaped, offline verifier subprocess without product execution."""

import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time


folder = Path(__file__).resolve().parent
script = folder / "recompute.py"
argv = [sys.executable, "-B", str(script)]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
clock = time.monotonic()
result = subprocess.run(argv, cwd=folder.parent.parent, capture_output=True, timeout=120)
elapsed = time.monotonic() - clock
attempt = 1
while (folder / f"attempt-{attempt:02d}-execution-receipt.json").exists():
    attempt += 1
(folder / "execution.stdout.json").write_bytes(result.stdout)
(folder / "execution.stderr.txt").write_bytes(result.stderr)
receipt = {
    "command": argv, "source": "660e90d6f7c7111853db7b73f4ca2344f633700d",
    "started_utc": started, "finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "elapsed_seconds": elapsed, "exit_code": result.returncode, "reaped": True,
    "script_sha256": hashlib.sha256(script.read_bytes()).hexdigest(),
    "stdout_bytes": len(result.stdout), "stderr_bytes": len(result.stderr),
    "stdout_sha256": hashlib.sha256(result.stdout).hexdigest(),
    "stderr_sha256": hashlib.sha256(result.stderr).hexdigest(),
    "native_new_executions": 0, "product_tests_replayed": 0, "network_calls": 0,
    "parent_verifier_executed": False,
    "attempt": attempt,
}
(folder / "execution-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
(folder / f"attempt-{attempt:02d}-execution-receipt.json").write_text(
    json.dumps(receipt, indent=2) + "\n")
(folder / f"attempt-{attempt:02d}-execution.stdout.json").write_bytes(result.stdout)
(folder / f"attempt-{attempt:02d}-execution.stderr.txt").write_bytes(result.stderr)
print(json.dumps(receipt))
if result.stdout:
    print(result.stdout.decode().strip())
if result.stderr:
    print(result.stderr.decode().strip(), file=sys.stderr)
sys.exit(result.returncode)
