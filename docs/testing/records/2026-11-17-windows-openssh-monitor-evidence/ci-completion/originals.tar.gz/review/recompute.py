#!/usr/bin/env python3
"""Offline evidence review. No repository modules, product tests, or network calls."""

import base64
import collections
import datetime
import hashlib
import json
import math
import ntpath
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import zipfile


OUT = Path(__file__).resolve().parent
ROOT = OUT.parent.parent
ORIGINALS = ROOT / "work/windows-ssh-ci-originals-20261117"
SOURCE = "660e90d6f7c7111853db7b73f4ca2344f633700d"
RUNS = {
    "openssh-repair-r1": (43997403565, 14290995772, 46, 133752726874),
    "openssh-repair-repeat-r1": (43998970900, 14291880367, 46, 133757978816),
    "direct-api-repair-r1": (43997403484, 14289254506, 34, 133752727681),
}
TEST = "actual_windows_openssh_monitor_matches_owned_fixture"
REPLAY = "captured_windows_api_frames_are_accepted_through_authenticated_monitor_routing"
CHECKS = []
INPUTS = {}
GIT_READS = 0
SCOPE = {
    "kind": "independent_offline_review_of_existing_originals",
    "source": SOURCE,
    "ssh_runs": [43997403565, 43998970900],
    "direct_api_replay_run": 43997403484,
    "quality_43997403533": "NOT_COVERED",
    "new_native_executions": 0,
    "new_product_tests": 0,
    "cargo_full_gates_gui_network_delegation": 0,
}
BOUNDARIES = [
    "Only local downloaded ZIPs, API metadata and logs were examined; no live GitHub verification.",
    "Quality 43997403533 is excluded, regardless of its current status.",
    "No new native execution, product test, replay, Cargo command, full gate or GUI action.",
    "ZIP/member/invariant checks are evidence checks, never product test counts.",
    "Direct API run signs API/capture replay only; its isolated SSH prerequisite job is skipped.",
    "Old run 43990824640 remains FAIL; its first bad census subreadings and exact cause remain UNKNOWN.",
    "Success of these two repaired runs does not prove the old failure was a race.",
    "No desktop GUI, installation, release, complete product or other host acceptance.",
    "Native executable hashes are original runner measurements, not locally rehashed executable downloads.",
    "No independent server authentication audit log is present; wrong-pin evidence is Rust ChangedHostKey plus pinned source ordering.",
    "Debug/Job evidence covers the admitted owned OpenSSH chain, not arbitrary external broker processes.",
]


class EvidenceMismatch(Exception):
    pass


def need(condition, name):
    CHECKS.append({"check": name, "passed": bool(condition)})
    if not condition:
        raise EvidenceMismatch(name)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def strict_json(raw):
    def pairs(rows):
        result = {}
        for key, value in rows:
            if key in result:
                raise EvidenceMismatch("duplicate_json_key")
            result[key] = value
        return result

    def invalid_constant(_):
        raise EvidenceMismatch("nonfinite_json_number")

    return json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid_constant)


def read(path):
    need(path.is_file() and not path.is_symlink(), "input.regular_file." + str(path.relative_to(ROOT)))
    raw = path.read_bytes()
    INPUTS[str(path.relative_to(ROOT))] = {"bytes": len(raw), "sha256": sha(raw)}
    return raw


def document(path):
    return strict_json(read(path))


def save(name, value):
    path = OUT / name
    if path.parent != OUT:
        raise RuntimeError("output_outside_review_directory")
    raw = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, indent=2) + "\n"
    path.write_text(raw, encoding="utf-8")


def git(*args):
    global GIT_READS
    GIT_READS += 1
    env = dict(os.environ, GIT_OPTIONAL_LOCKS="0")
    return subprocess.check_output(
        ["git", *args], cwd=ROOT, env=env, timeout=30, stderr=subprocess.PIPE,
    )


def source_bytes(name):
    raw = git("show", SOURCE + ":" + name)
    need((ROOT / name).read_bytes() == raw, "source.current_matches_pinned." + name)
    return raw


def protected_snapshot():
    paths = git("ls-files", "-z").decode().split("\0")
    files = []
    for name in paths:
        if not name or name.startswith("work/"):
            continue
        path = ROOT / name
        if path.is_symlink():
            raw = os.readlink(path).encode()
            mode = "symlink"
        elif path.is_file():
            raw = path.read_bytes()
            mode = stat.S_IMODE(path.stat().st_mode)
        else:
            raw = b""
            mode = "missing"
        files.append((name, mode, len(raw), sha(raw)))
    gitdir = Path(git("rev-parse", "--absolute-git-dir").decode().strip())
    common = Path(git("rev-parse", "--git-common-dir").decode().strip())
    if not common.is_absolute():
        common = ROOT / common
    metadata = {}
    candidates = [gitdir / "HEAD", gitdir / "index", common / "packed-refs", common / "config"]
    for base in (gitdir / "refs", common / "refs"):
        if base.exists():
            candidates.extend(p for p in base.rglob("*") if p.is_file())
    for path in sorted(set(candidates)):
        if path.is_file():
            metadata[str(path)] = sha(path.read_bytes())
    return {
        "head": git("rev-parse", "HEAD").decode().strip(),
        "tracked_status": git("status", "--porcelain=v1", "--untracked-files=no").decode(),
        "tracked_files": len(files),
        "tracked_bytes_mode_aggregate_sha256": sha(json.dumps(files).encode()),
        "git_metadata": metadata,
    }


def production_commands():
    # The command recipe comes from Rust production code, not the lab assembler
    # or the parent's verifier. Decode Rust's ordinary string literals as JSON.
    rust = source_bytes("crates/keelshell-session/src/monitor/windows.rs").decode()
    string = r'("(?:[^"\\]|\\.)*")'
    constants = {}
    for name in ("COMMAND_PREFIX", "SUFFIX"):
        matched = re.search(r"const " + name + r": &str = " + string + ";", rust)
        need(matched is not None, "source.rust_literal." + name)
        constants[name] = json.loads(matched[1])
    need(constants["COMMAND_PREFIX"] ==
         "powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand ",
         "source.fixed_production_options")
    need('script.encode_utf16().flat_map(u16::to_le_bytes)' in rust
         and "STANDARD.encode(bytes)" in rust, "source.utf16le_standard_base64")
    recipe = re.findall(string + r',\s*include_str!\("windows/([^"]+)"\)', rust)
    need(len(recipe) == 5, "source.five_fixed_rust_operation_variants")
    common = source_bytes("crates/keelshell-session/src/monitor/windows/common.ps1")
    commands, scripts, assemblies = {}, {}, {}
    for literal, body_name in recipe:
        prefix = json.loads(literal)
        matched = re.fullmatch(r"\$op='(probe|resources|processes|sockets)';\$skip=\$(false|true);\n",
                               prefix)
        need(matched is not None, "source.fixed_operation_prefix")
        operation = matched[1] + ("-skipped" if matched[2] == "true" else "")
        body = source_bytes("crates/keelshell-session/src/monitor/windows/" + body_name)
        script = prefix.encode() + common + body + constants["SUFFIX"].encode()
        encoded = base64.b64encode(script.decode("utf-8").encode("utf-16-le")).decode()
        command = constants["COMMAND_PREFIX"] + encoded
        need(command.isascii() and len(command) < 8000, "source.command_bound." + operation)
        commands[operation] = command
        scripts[operation] = script
        assemblies[operation] = {
            "operation": operation,
            "parts": [{"file": "common.ps1", "sha256": sha(common)},
                      {"file": body_name, "sha256": sha(body)}],
            "join": "verbatim", "literal_prefix": prefix,
            "literal_suffix": constants["SUFFIX"],
            "script_sha256": sha(script),
            "wire_command_sha256": sha(command.encode("ascii")),
            "wire_command_ascii_bytes": len(command),
        }
    need(set(commands) == {"probe", "resources", "resources-skipped", "processes", "sockets"},
         "source.operation_set")
    ssh = source_bytes("crates/keelshell-session/src/ssh.rs").decode()
    auth = ssh.split("async fn authenticate_stream<R>", 1)[1]
    need(auth.index("client::connect_stream(") < auth.index(".await?;") <
         auth.index("let accepted = match &options.auth"),
         "source.host_key_handshake_before_user_authentication")
    check_key = ssh.split("async fn check_server_key(", 1)[1].split(
        "async fn server_channel_open_forwarded_tcpip", 1)[0]
    need("Some(expected) if *expected != fingerprint => Err(SessionError::ChangedHostKey" in check_key,
         "source.wrong_pin_fails_closed")
    test = source_bytes("crates/keelshell-session/tests/windows_openssh_monitor.rs").decode()
    need("reject_changed_key(&config, session, report).await?;" in test
         and "*session = Some(" in test and "SshSession::connect(options(" in test,
         "source.public_live_rust_route_and_wrong_pin")
    workflow = source_bytes(".github/workflows/windows-monitor-ssh.yml").decode()
    need("runs-on: windows-2025" in workflow and '--source "$env:GITHUB_SHA"' in workflow
         and "--test windows_openssh_monitor --no-run" in workflow,
         "source.ssh_workflow_pinned_native_build")
    direct = source_bytes(".github/workflows/windows-monitor.yml").decode()
    need("captured_windows_api_frames_are_accepted_through_authenticated_monitor_routing" in direct
         and "if: github.event_name == 'workflow_dispatch'" in direct,
         "source.direct_workflow_scope")
    # Read the actual phase and exception protocol for interpreting the raw receipts.
    debug = source_bytes("scripts/windows_monitor/debug_job.py").decode()
    need("if complete and all(row.natural" in debug
         and "self._last_active == 1" in debug
         and "self.prepare_terminal(budget)" in debug
         and 'self._fail("debug_admission_changed_during_cleanup_barrier")' in debug,
         "source.complete_live_master_census_precedes_seal")
    need("status = DBG_CONTINUE if initial else DBG_EXCEPTION_NOT_HANDLED" in debug,
         "source.only_initial_breakpoint_is_consumed")
    source_bytes("scripts/windows_monitor/ssh.py")
    return commands, scripts, assemblies


def verify_archives(label, spec):
    run_id, artifact_id, member_count, job_id = spec
    folder = ORIGINALS / label
    run = document(folder / "run.json")
    jobs = document(folder / "jobs.json")
    artifacts = document(folder / "artifacts.json")
    fetched = document(folder / "fetch-receipt.json")
    need(run["id"] == fetched["run_id"] == run_id, label + ".run_id")
    need(run["head_sha"] == fetched["source"] == SOURCE, label + ".exact_source")
    need(run["status"] == fetched["status"] == "completed"
         and run["conclusion"] == fetched["conclusion"] == "success", label + ".run_success")
    need(run["run_attempt"] == 1, label + ".run_attempt")
    need(run["path"] == (".github/workflows/windows-monitor.yml" if label.startswith("direct")
                         else ".github/workflows/windows-monitor-ssh.yml"), label + ".workflow_path")
    need(jobs["total_count"] == len(jobs["jobs"]), label + ".complete_jobs_api")
    expected_jobs = {job_id: "success"}
    if label.startswith("direct"):
        expected_jobs[133752729988] = "skipped"
    need({job["id"]: job["conclusion"] for job in jobs["jobs"]} == expected_jobs,
         label + ".exact_job_set")
    need({row["id"]: row["conclusion"] for row in fetched["jobs"]} == expected_jobs,
         label + ".fetch_job_set")
    for job in jobs["jobs"]:
        need(job["run_id"] == run_id and job["head_sha"] == SOURCE
             and job["status"] == "completed", label + ".job_source." + str(job["id"]))
        if job["conclusion"] == "success":
            need(job["steps"] and all(s["status"] == "completed" and s["conclusion"] == "success"
                                    for s in job["steps"]), label + ".all_job_steps_success")
        else:
            need(job["steps"] == [] and "OpenSSH prerequisites" in job["name"],
                 label + ".ssh_prerequisites_skipped")
    need(artifacts["total_count"] == len(artifacts["artifacts"]) == 1,
         label + ".one_artifact")
    artifact = artifacts["artifacts"][0]
    need(artifact["id"] == artifact_id and artifact["expired"] is False,
         label + ".artifact_id")
    need(artifact["workflow_run"]["id"] == run_id
         and artifact["workflow_run"]["head_sha"] == SOURCE, label + ".artifact_source")
    expected_zips = {"logs.zip", "artifact-" + str(artifact_id) + ".zip"}
    need({p.name for p in folder.glob("*.zip")} == expected_zips
         and {row["zip"] for row in fetched["downloads"]} == expected_zips,
         label + ".complete_zip_set")
    result, zip_summary = {}, []
    for entry in fetched["downloads"]:
        path = folder / entry["zip"]
        raw = read(path)
        need(len(raw) == entry["bytes"] and sha(raw) == entry["sha256"],
             label + ".zip_digest." + path.name)
        if path.name.startswith("artifact-"):
            need(len(raw) == artifact["size_in_bytes"]
                 and artifact["digest"] == entry["github_digest"] == "sha256:" + sha(raw),
                 label + ".github_artifact_digest")
            destination = folder / path.stem
        else:
            need(entry["github_digest"] is None, label + ".logs_have_no_github_digest")
            destination = folder / "logs"
        with zipfile.ZipFile(path) as archive:
            rows = archive.infolist()
            names = [row.filename for row in rows if not row.is_dir()]
            need(len(names) == len(set(names)) == len(entry["members"]),
                 label + ".unique_zip_members." + path.name)
            manifest = {item["path"]: item for item in entry["members"]}
            need(set(names) == set(manifest), label + ".member_set." + path.name)
            need(set(names) == {str(p.relative_to(destination)) for p in destination.rglob("*")
                                if p.is_file()}, label + ".extracted_set." + path.name)
            content = {}
            for row in rows:
                need(not PurePosixPath(row.filename).is_absolute()
                     and ".." not in PurePosixPath(row.filename).parts,
                     label + ".safe_member_name")
                if row.is_dir():
                    continue
                member = archive.read(row)
                recorded = manifest[row.filename]
                need(len(member) == recorded["bytes"] == row.file_size
                     and sha(member) == recorded["sha256"],
                     label + ".member_digest." + path.name + "." + row.filename)
                need(read(destination / row.filename) == member,
                     label + ".extracted_bytes." + path.name + "." + row.filename)
                need(b"-----BEGIN OPENSSH PRIVATE KEY-----" not in member
                     and b"-----BEGIN PRIVATE KEY-----" not in member,
                     label + ".no_private_key_marker." + path.name + "." + row.filename)
                content[row.filename] = member
            need(archive.testzip() is None, label + ".zip_crc." + path.name)
        expected_count = member_count if path.name.startswith("artifact-") else 12
        need(len(content) == expected_count, label + ".member_count." + path.name)
        result["artifact" if path.name.startswith("artifact-") else "logs"] = content
        zip_summary.append({"zip": path.name, "bytes": len(raw), "sha256": sha(raw),
                            "members": len(content),
                            "github_digest_checked": path.name.startswith("artifact-")})
    for p in sorted(folder.glob("*.stderr")):
        need(not read(p), label + ".download_stderr_empty." + p.name)
    checkout = next(raw for name, raw in result["logs"].items()
                    if "/2_Run actions_checkout@" in name)
    need(SOURCE.encode() in checkout
         and re.search(rb"\[command\].*git.*log -1 --format=%H", checkout) is not None,
         label + ".checkout_log_exact_source")
    need(artifact["name"].endswith(str(run_id) + "-1"), label + ".artifact_run_name")
    return result, {
        "run_id": run_id, "job_id": job_id, "source": SOURCE,
        "conclusion": "success", "artifact_id": artifact_id, "zips": zip_summary,
        "jobs": [{"id": row["id"], "conclusion": row["conclusion"]} for row in jobs["jobs"]],
    }


def member_json(files, name):
    return strict_json(files[name])


def terminal(receipt, label, allow_controlled_master=False):
    need(receipt["errors"] == [], label + ".child_errors_empty")
    if not allow_controlled_master:
        need(receipt["observed_exit"] == 0, label + ".observed_exit0")
    term = receipt["terminal"]
    need(term["direct_reaped"] is True and term["active_processes"] == 0
         and term["pipes_drained"] is True and term["errors"] == [], label + ".terminal")
    native = term["native_process_objects"]
    need(native["admission_closed"] is True and native["identities_bound"] is True
         and native["pending_process_objects"] == 0, label + ".native_originals")
    if not allow_controlled_master:
        need(native["original_handles_checked"] ==
             native["known_direct_handles"] + native["retained_processes"]
             and native["verified_extra_handles"] == 0, label + ".all_original_handles_checked")


def socket_key(row):
    return tuple(row[k] for k in ("protocol", "address", "port", "pid"))


def recompute_owned(fixture, processes, sockets, oracle, label):
    need(len(fixture["endpoints"]) == 4 and len(fixture["connected_only"]) == 2,
         label + ".fixture_endpoint_count")
    need({(row["protocol"], row["address"]) for row in fixture["endpoints"]} ==
         {("tcp", "127.0.0.1"), ("udp", "127.0.0.1"), ("tcp", "::1"), ("udp", "::1")},
         label + ".four_dual_stack_owned_endpoints")
    pid = fixture["pid"]
    need(all(row["pid"] == str(pid) for row in fixture["endpoints"] + fixture["connected_only"]),
         label + ".fixture_pid_binding")
    need(len(processes["processes"]) == processes["count"], label + ".process_vector_count")
    need(len(sockets["sockets"]) == sockets["count"], label + ".socket_vector_count")
    owned = [row for row in processes["processes"] if row["pid"] == str(pid)]
    need(len(owned) == 1 and oracle["process"]["pid"] == pid, label + ".owned_process_unique")
    need(owned[0]["name"].casefold() == oracle["process"]["name"].casefold()
         and oracle["process"]["source"] ==
         "OpenProcess/QueryFullProcessImageNameW/GetProcessMemoryInfo", label + ".independent_image")
    difference = abs(int(owned[0]["working_set_bytes"]) - oracle["process"]["working_set_bytes"])
    tolerance = max(16 * 1024 * 1024, oracle["process"]["working_set_bytes"] // 2)
    need(difference <= tolerance, label + ".working_set")
    actual = {socket_key(row) for row in sockets["sockets"]}
    independent = {socket_key(row) for row in oracle["sockets"]
                   if row["state"] in ("LISTEN", "BOUND")}
    all_states = {socket_key(row): row["state"] for row in oracle["sockets"]}
    for i, row in enumerate(fixture["endpoints"]):
        need(socket_key(row) in actual & independent, label + ".owned_endpoint." + str(i))
    need({row["address"] for row in fixture["connected_only"]} == {"127.0.0.1", "::1"},
         label + ".negative_dual_stack")
    for i, row in enumerate(fixture["connected_only"]):
        need(socket_key(row) not in actual
             and all_states.get(socket_key(row)) == "CONNECTED_OR_OTHER",
             label + ".connected_tcp_excluded." + str(i))
    return {"pid": pid, "owned_endpoints_matched": 4, "connected_tcp_excluded": 2,
            "working_set_difference_bytes": difference, "working_set_tolerance_bytes": tolerance}


def identity(row, facility):
    if facility == "network":
        return (row["interface_guid"], row["interface_luid"], row["interface_index"], row["name"])
    return (row["mount"].casefold(), row["volume_guid"].casefold(), row["volume_serial"])


def inventory(rows, before, after, facility, label):
    first = {identity(row, facility): row for row in before}
    last = {identity(row, facility): row for row in after}
    need(len(first) == len(before) and len(last) == len(after), label + ".unique_independent")
    need(set(first) == set(last), label + ".stable_full_independent_set")
    field = "name" if facility == "network" else "mount"
    normalize = (lambda v: v) if facility == "network" else str.casefold
    actual = {normalize(row[field]): row for row in rows}
    required = {normalize(first[key][field]): key for key in first}
    need(len(actual) == len(rows) and len(required) == len(first), label + ".unique_labels")
    need(set(actual) == set(required), label + ".complete_stable_coverage")
    matched = [(actual[key], first[required[key]], last[required[key]]) for key in sorted(required)]
    return matched, {
        "required": sorted(required), "production": sorted(actual),
        "stable_identities": [list(key) for key in sorted(first)],
        "before_only": [], "after_only": [],
    }


def recompute_resources(data, oracle, label):
    before, after = oracle["before"], oracle["after"]
    need(data["network_count"] == len(data["networks"]), label + ".network_vector_count")
    need(data["filesystem_count"] == len(data["filesystems"]), label + ".filesystem_vector_count")
    need(before["capacity_issues"] == after["capacity_issues"] == [], label + ".capacity_no_issues")
    expected_apis = ("GlobalMemoryStatusEx", "GetTickCount64", "GetLogicalDriveStringsW",
                     "GetDriveTypeW", "GetVolumeInformationW", "GetVolumeNameForVolumeMountPointW",
                     "GetDiskFreeSpaceExW", "GetAdaptersAddresses", "GetIfTable2")
    need(all(api in before["source"] and api in after["source"] for api in expected_apis),
         label + ".independent_win32_apis")
    need(before["wall_unix"] < after["wall_unix"]
         and before["uptime_seconds"] < after["uptime_seconds"], label + ".ordered_bracket")
    memory_tolerance = max(1024 * 1024, after["memory_total_bytes"] // 200)
    free_tolerance = max(256 * 1024 * 1024, after["memory_total_bytes"] // 10)
    need(abs(int(data["memory_total_bytes"]) - after["memory_total_bytes"]) <= memory_tolerance,
         label + ".memory_total")
    need(min(before["memory_free_bytes"], after["memory_free_bytes"]) - free_tolerance <=
         int(data["memory_free_bytes"]) <=
         max(before["memory_free_bytes"], after["memory_free_bytes"]) + free_tolerance,
         label + ".memory_free")
    need(abs(int(data["boot_time"]) - after["boot_unix"]) <= 120
         and before["uptime_seconds"] - 120 <= data["uptime_seconds"] <= after["uptime_seconds"] + 120,
         label + ".boot_uptime")
    matched, networks = inventory(data["networks"], before["networks"], after["networks"],
                                  "network", label + ".network")
    need(len(matched) == 3, label + ".three_stable_interfaces")
    for index, (row, earlier, later) in enumerate(matched):
        for field in ("received_bytes", "transmitted_bytes"):
            need(earlier[field] <= int(row[field]) <= later[field],
                 label + ".network_counter." + str(index) + "." + field)
    capacities = {"status": "not_compared", "reason": data["capacity_status"]}
    tolerances = []
    if data["capacity_status"] == "ok":
        disks, capacities = inventory(data["filesystems"], before["filesystems"], after["filesystems"],
                                      "capacity", label + ".capacity")
        need(len(disks) == 2, label + ".two_stable_fixed_volumes")
        for stage, resources in (("before", before), ("after", after)):
            fixed = [row for row in resources["drive_inventory"] if row["drive_type"] == 3]
            need(len(fixed) == 2 and all(row["ready"] for row in fixed)
                 and {identity(row, "capacity") for row in fixed} ==
                 {identity(row, "capacity") for row in resources["filesystems"]},
                 label + ".independent_fixed_drive_inventory." + stage)
        for index, (row, earlier, later) in enumerate(disks):
            need(earlier["total_bytes"] == later["total_bytes"] == int(row["total_bytes"]),
                 label + ".capacity_total." + str(index))
            tolerance = max(256 * 1024 * 1024, later["total_bytes"] // 100)
            for field in ("total_free_bytes", "available_bytes"):
                need(min(earlier[field], later[field]) - tolerance <= int(row[field]) <=
                     max(earlier[field], later[field]) + tolerance,
                     label + ".capacity_free." + str(index) + "." + field)
            tolerances.append({"mount": row["mount"], "bytes": tolerance})
    else:
        need(data["capacity_status"] == "skipped" and data["filesystems"] == [],
             label + ".explicit_skipped_capacity")
    deltas = [b - a for a, b in zip(oracle["cpu_before"], oracle["cpu_after"])]
    total = deltas[1] + deltas[2]
    need(all(d >= 0 for d in deltas) and total > 0 and deltas[0] <= total,
         label + ".independent_cpu_counters")
    native_cpu = 100 * (total - deltas[0]) / total
    return {
        "memory_total_tolerance_bytes": memory_tolerance,
        "memory_free_tolerance_bytes": free_tolerance, "uptime_tolerance_seconds": 120,
        "capacity_tolerances": tolerances, "networks_matched": len(data["networks"]),
        "network_inventory": networks, "capacity_inventory": capacities,
        "independent_cpu_percent": native_cpu, "production_cpu_percent": data["cpu_percent"],
        "cpu_difference_is_informational": True,
        "cpu_reason": "CIM LoadPercentage and GetSystemTimes cover different sampling windows",
        "capacity_status": data["capacity_status"],
    }


def census(snapshot, label, active):
    rows = snapshot["admissions"]
    need(snapshot["evidence_kind"] == "NATIVE_WINDOWS"
         and snapshot["errors"] == [], label + ".native_no_errors")
    need(snapshot["complete_original_object_census"] is True
         and snapshot["admission_closed"] is True
         and snapshot["admission_phase_closed"] is True
         and snapshot["identities_bound"] is True, label + ".complete_sealed_bound")
    need(len(rows) == snapshot["job_total_processes"] == 21
         and len({(r["pid"], r["creation_time"]) for r in rows}) == len(rows)
         and len({r["pid"] for r in rows}) == len(rows), label + ".identity_census")
    need(sum(r["is_master"] for r in rows) == 1, label + ".one_master")
    need(all(r["retained_before_first_instruction"] is True
             and r["identity_bound_before_first_continue"] is True
             and r["pid"] > 0 and r["creation_time"] > 0 for r in rows),
         label + ".every_original_retained_and_bound_before_continue")
    live = [r for r in rows if not r["original_signaled"]]
    need(snapshot["job_active_processes"] == snapshot["pending_process_objects"] == len(live) == active,
         label + ".actual_live_object_count")
    need(all(r["is_master"] for r in live), label + ".only_master_live")
    last = snapshot["last_census_observation"]
    need(last["total_before"] == last["total_after"] == last["admitted"] ==
         last["sealed_total"] == len(rows), label + ".stable_native_total_reads")
    need(last["active_before"] == last["active_after"] == len(last["current_pids"]) == active
         and set(last["current_pids"]) == {r["pid"] for r in live}
         and last["complete"] is True and last["unknown_pids"] == []
         and last["unbound_originals"] == 0 and last["settling"] is False,
         label + ".complete_final_native_census")
    need(snapshot["debug_events_received"] == snapshot["debug_events_continued"]
         and snapshot["pending_debug_event"] is False and snapshot["fallback_detaches"] == 0,
         label + ".all_events_continued")
    for row in rows:
        if active and row["is_master"]:
            need(row["exit_code"] is None and not row["exit_event_received"]
                 and not row["natural_terminal_before_cleanup"], label + ".master_alive_at_seal")
        else:
            need(row["original_signaled"] and row["exit_event_received"]
                 and row["exit_event_continued"] and row["exit_code"] == row["exit_event_code"],
                 label + ".original_exit_event." + str(row["pid"]))
            if not row["is_master"]:
                need(row["natural_terminal_before_cleanup"] is True,
                     label + ".natural_nonmaster." + str(row["pid"]))
    known = {(r["pid"], r["creation_time"]) for r in rows}
    for index, event in enumerate(snapshot["exceptions"]):
        initial = event["initial_breakpoint"]
        need((event["pid"], event["creation_time"]) in known
             and event["first_chance"] is True, label + ".exception_identity_first_chance." + str(index))
        need(event["continue_status"] == (65538 if initial else 2147549185)
             and (not initial or event["code"] == 2147483651),
             label + ".exception_forwarding." + str(index))
    need(len([e for e in snapshot["exceptions"] if e["initial_breakpoint"]]) == len(rows),
         label + ".one_initial_breakpoint_each")
    return rows


def ssh_review(label, bundle, commands, scripts):
    files = bundle["artifact"]
    top = member_json(files, "receipt.json")
    need(top["source"] == SOURCE and top["status"] == top["ssh"] == top["windows_api"] == "PASS"
         and top["native_gui"] == "UNRUN" and top["ssh_client_started"] is True,
         label + ".top_receipt")
    need(top["system"] == "Windows" and top["architecture"] == "AMD64"
         and top["build"] == "10.0.26100", label + ".native_windows_identity")
    need(files["source-head.stdout"].strip() == SOURCE.encode()
         and files["source-status.stdout"] == b"", label + ".clean_pinned_engineering_inputs")
    need(len(top["children"]) == 9, label + ".nine_owned_children")
    for child in top["children"]:
        name = child["label"]
        saved = member_json(files, name + ".receipt.json")
        need(saved == {k: v for k, v in child.items() if k != "label"},
             label + ".child_receipt_identity." + name)
        terminal(saved, label + "." + name, name == "owned-sshd")
        need(saved["stdout_bytes"] == len(files[name + ".stdout"])
             and saved["stderr_bytes"] == len(files[name + ".stderr"]),
             label + ".child_stream_lengths." + name)
    client = member_json(files, "rust-client.json")
    need(client["schema"] == 1 and client["test"] == TEST and client["status"] == "PASS"
         and client["errors"] == [], label + ".rust_test_pass")
    need(client["identity"]["platform"] == "Windows"
         and client["identity"]["runtime"] == "WindowsPowerShell"
         and client["identity"]["runtime_version"] == "5.1.26100.33648",
         label + ".independent_powershell_identity")
    binary = member_json(files, "test-binary.json")
    need(binary["inventory"] == [TEST] and binary["executed"] == TEST
         and re.fullmatch(r"[0-9a-f]{64}", binary["sha256"]) is not None,
         label + ".native_binary_record_and_inventory")
    inventory_text = files["live-test-inventory.stdout"].decode()
    need(re.findall(r"^(\S+): test$", inventory_text, re.M) == [TEST]
         and "1 test, 0 benchmarks" in inventory_text, label + ".raw_native_inventory")
    result_text = files["native-ssh-client.stdout"].decode()
    need("test " + TEST + " ... ok" in result_text
         and "1 passed; 0 failed; 0 ignored;" in result_text, label + ".raw_single_rust_result")
    need(client["elapsed_seconds"] < client["budget_seconds"] == 90, label + ".bounded_client")
    assertions = client["assertion_evidence"]
    need(len(assertions) == 22 and all(r["passed"] is True for r in assertions),
         label + ".twenty_two_original_assertion_records")
    by_name = collections.defaultdict(list)
    for row in assertions:
        by_name[row["assertion"]].append(row["evidence"])
    wrong = by_name["wrong_pin_rejected_before_authenticated_session"]
    need(len(wrong) == 1 and wrong[0]["error"] == "ChangedHostKey"
         and wrong[0]["actual_matches_fixture_pin"] is True
         and wrong[0]["authenticated_session_returned"] is False, label + ".wrong_pin_rejected")
    fresh = by_name["fresh_monitor_is_unknown_and_clone_shares_its_authority"]
    need(len(fresh) == 1 and fresh[0]["authenticated_connections"] == 1,
         label + ".one_public_authenticated_session")
    need(client["api_calls"] == {"snapshot": 1, "processes": 1, "listening_sockets": 1},
         label + ".api_calls_once")
    caches = by_name["cache_reads_and_clone_preserve_observations_and_authority"]
    need(len(caches) == 3 and all(r["collector_invoked"] is False
                                and r["checked_at_equality_included"] is True for r in caches),
         label + ".three_cache_reads_no_recollection")
    for name in ("pause_revokes_old_report_but_preserves_completed_observations",
                 "clone_revocation_is_shared_and_old_reports_stay_revoked",
                 "explicit_reset_clears_shared_cache_without_redetection"):
        need(len(by_name[name]) == 1 and by_name[name][0]["collector_invoked"] is False,
             label + "." + name)
    def unknown_cache(cache):
        return cache["environment_present"] is False and all(
            cache[k]["checked"] is False and cache[k]["state"] == "unknown"
            and cache[k]["age_millis_at_report_read"] is None and cache[k]["reason"] is None
            for k in ("resources", "processes", "sockets", "filesystems"))
    need(unknown_cache(fresh[0]["initial_cache"])
         and unknown_cache(by_name["explicit_reset_clears_shared_cache_without_redetection"][0]
                           ["cache_after_reset"]), label + ".unknown_initial_and_reset_cache")
    authority = client["authority"][0]
    need(authority["old_report_accepted"] is False
         and authority["current_report_accepted_by_both_clones"] is True
         and authority["observations_unchanged"] is True, label + ".revoked_report_authority")
    need(all(client["disconnect"][k] is True
             for k in ("attempted", "request_succeeded", "local_transport_closed")),
         label + ".explicit_disconnect")
    semantics = client["sample_semantics"]
    need(all(semantics[k] is None for k in (
        "load_average", "memory_available_bytes", "memory_used_bytes", "swap_free_bytes",
        "swap_total_bytes", "derived_cpu_iowait_percent")), label + ".unknown_values_preserved")
    need(semantics["cpu_source"] == "reported_percent"
         and semantics["derived_cpu_busy_percent"] == semantics["cpu_percent"]
         and semantics["disk_io_missing"] is True
         and semantics["derived_disk_rate_count"] == semantics["derived_network_rate_count"] == 0,
         label + ".cpu_gauge_no_invented_rates")
    fixture = member_json(files, "fixture.json")
    need(client["fixture"] == fixture == strict_json(files["live-fixture.stdout"]),
         label + ".rust_and_original_fixture_match")
    oracle = member_json(files, "independent.json")
    before = member_json(files, "independent-before.json")
    need(before == {"resources": oracle["before"], "cpu": oracle["cpu_before"]},
         label + ".before_original_binding")
    compared = {
        "owned": recompute_owned(fixture, client["windows_processes"], client["windows_sockets"],
                                  oracle, label),
        "resources": recompute_resources(client["windows_resources"], oracle, label + ".resources"),
    }
    need(compared == member_json(files, "comparison.json"), label + ".comparison_independently_recomputed")
    seal = member_json(files, "ssh-debug-originals.json")
    final = member_json(files, "ssh-debug-cleanup.json")
    earlier = census(seal, label + ".seal", 1)
    later = census(final, label + ".cleanup", 0)
    stable_fields = ("pid", "creation_time", "image", "command_line", "is_master")
    identities = lambda rows: {tuple(r[k] for k in stable_fields) for r in rows}
    need(identities(earlier) == identities(later), label + ".post_seal_full_identity_set_unchanged")
    need(seal["state"] == "HOLD" and seal["terminal_proven"] is False
         and seal["closed"] is False, label + ".seal_is_not_final_terminal")
    need(final["state"] == "PASS" and final["terminal_proven"] is True and final["closed"] is True,
         label + ".final_terminal_pass")
    need(final["owned_handles_remaining"] == final["debug_connections"] ==
         final["pending_process_objects"] == final["job_active_processes"] == 0,
         label + ".final_job_connections_handles_empty")
    master = next(row for row in later if row["is_master"])
    need(master["exit_code"] == 125 and master["natural_terminal_before_cleanup"] is False
         and ntpath.normcase(master["image"]) ==
         ntpath.normcase(r"C:\Windows\System32\OpenSSH\sshd.exe"), label + ".controlled_master_exit")
    mid = member_json(files, "owned-sshd.receipt.json")["terminal"]["native_process_objects"]
    need(identities(mid["admissions"]) == identities(later)
         and mid["admissions"] == later
         and mid["job_total_processes"] == 21 and mid["job_active_processes"] == 0
         and mid["terminal_proven"] is True and mid["owned_handles_remaining"] == 22
         and mid["closed"] is False, label + ".pre_close_vs_final_handle_receipt")
    ps_rows = [r for r in earlier if ntpath.basename(r["image"]).casefold() == "powershell.exe"]
    need(len(ps_rows) == 4, label + ".four_original_powershells")
    bound = []
    spacing = []
    for row in ps_rows:
        need(ntpath.normcase(row["image"]) ==
             ntpath.normcase(r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"),
             label + ".production_powershell_image")
        match = re.fullmatch(
            r'(?:"([^"\r\n]+)"|([^"\s]+))( +)'
            r"(-NoLogo -NoProfile -NonInteractive -EncodedCommand ([A-Za-z0-9+/]+=*))",
            row["command_line"])
        need(match is not None, label + ".fixed_options_and_base64_only")
        program = match[1] or match[2]
        need(ntpath.normcase(program) in (
            "powershell.exe", ntpath.normcase(row["image"])), label + ".original_argv0_image")
        command = "powershell.exe " + match[4]
        matches = [name for name, expected in commands.items() if expected == command]
        need(len(matches) == 1 and matches[0] != "resources-skipped", label + ".exact_command_bytes")
        operation = matches[0]
        decoded = base64.b64decode(match[5], validate=True)
        need(decoded == scripts[operation].decode().encode("utf-16-le")
             and base64.b64encode(decoded).decode() == match[5],
             label + ".base64_decoded_source_bytes." + operation)
        need(row["exit_code"] == row["exit_event_code"] == 0
             and row["original_signaled"] and row["exit_event_continued"]
             and row["natural_terminal_before_cleanup"], label + ".natural_powershell_exit0." + operation)
        bound.append({"operation": operation, "pid": row["pid"], "creation_time": row["creation_time"],
                      "exit_code": 0, "wire_sha256": sha(command.encode("ascii"))})
        spacing.append(len(match[3]))
    need(sorted(r["operation"] for r in bound) == ["probe", "processes", "resources", "sockets"],
         label + ".one_process_each_production_operation")
    binding = member_json(files, "ssh-production-binding.json")
    need(binding == {"operations": bound, "source_exact": True,
                     "original_processes_naturally_terminal": True},
         label + ".production_binding_recomputed")
    cleanup = member_json(files, "ssh-cleanup.json")
    need(cleanup == {"temporary_directory_removed": True, "private_config_uploaded": False,
                     "keys_uploaded": False, "fixture_started": True}, label + ".temporary_keys_removed")
    server = member_json(files, "isolated-server.json")
    need(server["listen"] == "127.0.0.1" and 49152 <= server["port"] <= 65535
         and server["protected_temporary_directory"] is True
         and server["private_keys_outside_output"] is True
         and all(server[k] is False for k in ("forced_command", "installed_service_changed",
                                             "registry_changed", "firewall_changed")),
         label + ".isolated_ephemeral_sshd")
    need(member_json(files, "default-shell.json") ==
         {"registry_values": {}, "changed": False, "inherited_default": "cmd.exe"},
         label + ".actual_default_shell_unchanged")
    transient = {}
    for name, snap in (("seal", seal), ("pre_handle_close", mid), ("final", final)):
        transient[name] = snap["incomplete_census_observations"]
        need(isinstance(transient[name], list), label + ".diagnostics_present." + name)
    # Keep any raw transient diagnostic values in a small separate file, never
    # overwrite/remove originals or reinterpret their existence as old root cause.
    save(label + "-census-diagnostics.json", transient)
    exceptions = collections.Counter((e["code"], e["first_chance"], e["initial_breakpoint"],
                                      e["continue_status"]) for e in final["exceptions"])
    return {
        "rust_original_result": {"passed": 1, "failed": 0, "ignored": 0},
        "original_assertion_records": len(assertions), "api_calls": client["api_calls"],
        "admitted": len(later), "natural_nonmasters": len(later) - 1,
        "nonmaster_exit_codes": dict(collections.Counter(str(r["exit_code"]) for r in later
                                                       if not r["is_master"])),
        "powershell_natural_exit0": 4, "argv0_spaces": spacing,
        "job_empty": True, "all_handles_closed": True, "temporary_directory_removed": True,
        "owned_endpoints": 4, "connected_tcp_excluded": 2,
        "working_set_difference_bytes": compared["owned"]["working_set_difference_bytes"],
        "working_set_tolerance_bytes": compared["owned"]["working_set_tolerance_bytes"],
        "stable_interfaces": 3, "fixed_volumes": 2,
        "debug_events_received_and_continued": final["debug_events_received"],
        "exception_count": len(final["exceptions"]),
        "exception_groups": [
            {"code": key[0], "first_chance": key[1], "initial_breakpoint": key[2],
             "continue_status": key[3], "count": count}
            for key, count in sorted(exceptions.items())
        ],
        "incomplete_census_counts": {key: len(value) for key, value in transient.items()},
        "command_bindings": [{"operation": row["operation"], "wire_sha256": row["wire_sha256"]}
                             for row in bound],
        "sshd_stderr_bytes": len(files["owned-sshd.stderr"]),
        "sshd_stderr_summary": "one kex readiness-disconnect diagnostic; preserved original",
        "server_auth_log": "NOT_AVAILABLE; no separate server authentication-log claim",
        "native_executable_hash": binary["sha256"],
    }


def direct_review(label, bundle, commands):
    files = bundle["artifact"]
    top = member_json(files, "receipt.json")
    need(top["mode"] == "direct" and top["status"] == top["windows_api"] == "PASS"
         and top["ssh"] == top["native_gui"] == "UNRUN", label + ".api_only_receipt")
    need(top["system"] == "Windows" and top["release"] == "2025Server"
         and top["architecture"] == "AMD64", label + ".native_windows_identity")
    need(len(top["children"]) == 6, label + ".six_owned_children")
    for child in top["children"]:
        name = child["label"]
        original = member_json(files, name + ".receipt.json")
        need(all(original[k] == value for k, value in child.items() if k != "label"),
             label + ".child_receipt_binding." + name)
        terminal(original, label + "." + name)
        need(original["stdout_bytes"] == len(files[name + ".stdout"])
             and original["stderr_bytes"] == len(files[name + ".stderr"]),
             label + ".stream_lengths." + name)
    frames = {}
    for operation, command in commands.items():
        need(files[operation + ".wire.txt"] == command.encode("ascii"),
             label + ".wire_bytes." + operation)
        result = member_json(files, operation + ".receipt.json")
        shell = result["shell_execution"]
        need(shell["argv"] == [r"C:\Windows\System32\cmd.exe", "/d", "/s", "/c", command],
             label + ".cmd_argv." + operation)
        need(shell["serialized_command_line"] == subprocess.list2cmdline(shell["argv"])
             and result["command_sha256"] == sha(shell["serialized_command_line"].encode())
             and result["command_chars"] == len(shell["serialized_command_line"]),
             label + ".serialized_shell_bytes." + operation)
        need(shell["production_command_ascii_bytes"] == len(command)
             and shell["complete_original_object_census"] is True
             and shell["job_total_processes"] == 2, label + ".shell_census." + operation)
        need(shell["required_image"].casefold() ==
             r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe".casefold(),
             label + ".required_powershell_image." + operation)
        objects = shell["powershell_original_objects"]
        need(len(objects) == 1 and objects[0]["retained_while_live"] is True
             and objects[0]["natural_terminal_before_cleanup"] is True
             and objects[0]["exit_code"] == 0, label + ".natural_powershell_exit0." + operation)
        raw = files[operation + ".stdout"]
        need(files[operation + ".stderr"] == b""
             and raw.startswith(b"{") and raw.endswith((b"}\n", b"}\r\n", b"}")),
             label + ".raw_frame_envelope." + operation)
        frame = strict_json(raw)
        need(set(frame) == {"version", "operation", "platform", "runtime", "runtime_version",
                            "units", "status", "data"}
             and frame["version"] == 1 and frame["operation"] == operation.replace("-skipped", "")
             and frame["status"] == "ok" and frame["platform"] == "Windows"
             and frame["runtime"] == "WindowsPowerShell"
             and frame["runtime_version"] == "5.1.26100.33648"
             and frame["units"] == "bytes seconds percent", label + ".frame_identity." + operation)
        frames[operation] = frame["data"]
    need(frames["probe"] == {"os": "Win32NT"}, label + ".probe_os")
    oracle = member_json(files, "independent.json")
    need(member_json(files, "independent-before.json") ==
         {"resources": oracle["before"], "cpu": oracle["cpu_before"]}, label + ".before_binding")
    fixture = member_json(files, "fixture.json")
    need(strict_json(files["fixture.stdout"]) == fixture, label + ".fixture_original")
    compared = {
        "owned": recompute_owned(fixture, frames["processes"], frames["sockets"], oracle, label),
        "resources": recompute_resources(frames["resources"], oracle, label + ".resources"),
        "resources_skipped": recompute_resources(frames["resources-skipped"], oracle,
                                                 label + ".resources_skipped"),
    }
    need(compared == member_json(files, "comparison.json"), label + ".comparison_recomputed")
    replay = next(raw.decode() for name, raw in bundle["logs"].items() if "/6_Captured API" in name)
    need("test " + REPLAY + " ... ok" in replay
         and "1 passed; 0 failed; 0 ignored; 0 measured; 9 filtered out;" in replay,
         label + ".original_authenticated_capture_replay_result")
    return {
        "scope": "direct production API frames and authenticated capture replay only",
        "source_binding": "run/jobs/artifact.workflow_run/checkout log; direct receipt has no source field",
        "powershell_natural_exit0": 5, "shell_originals_per_operation": 2,
        "original_replay_result": {"passed": 1, "failed": 0, "ignored": 0, "filtered_out": 9},
        "ssh": "UNRUN", "ssh_prerequisite_job": "skipped",
        "owned_endpoints": 4, "connected_tcp_excluded": 2,
        "working_set_difference_bytes": compared["owned"]["working_set_difference_bytes"],
        "stable_interfaces": 3, "fixed_volumes": 2, "skip_capacity_preserved": True,
        "all_child_terminals": True,
    }


def main():
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    before = protected_snapshot()
    need(before["head"] == SOURCE, "checkout.exact_source_head")
    engineering_status = git(
        "status", "--porcelain=v1", "--untracked-files=all", "--",
        "crates", "scripts", ".github", "Cargo.toml", "Cargo.lock",
    ).decode()
    need(engineering_status == "", "checkout.clean_pinned_engineering_inputs")
    commands, scripts, assemblies = production_commands()
    results = {}
    findings = []
    for label, spec in RUNS.items():
        try:
            bundle, metadata = verify_archives(label, spec)
            for operation, assembly in assemblies.items():
                need(member_json(bundle["artifact"], operation + ".assembly.json") == assembly,
                     label + ".rust_assembly_recomputed." + operation)
            detail = (direct_review(label, bundle, commands) if label.startswith("direct") else
                      ssh_review(label, bundle, commands, scripts))
            results[label] = dict(metadata, evidence=detail)
        except EvidenceMismatch as error:
            findings.append({"priority": "P2", "scope": label, "check": str(error)})
    # Re-hash every examined original and the read-only source/Git snapshot.
    for name, record in list(INPUTS.items()):
        path = ROOT / name
        need(path.is_file() and not path.is_symlink()
             and path.stat().st_size == record["bytes"] and sha(path.read_bytes()) == record["sha256"],
             "readonly.input_unchanged." + name)
    after = protected_snapshot()
    need(before == after, "readonly.tracked_source_docs_git_metadata_unchanged")
    priorities = {key: sum(r["priority"] == key for r in findings) for key in ("P0", "P1", "P2", "P3")}
    approved = not findings and len(results) == 3
    summary = {
        "schema": 1, "source": SOURCE, "review": "APPROVE_LIMITED" if approved else "FINDINGS",
        "started_utc": started, "finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "scope": SCOPE, "runs": results, "findings_by_priority": priorities, "findings": findings,
        "evidence_checks": {"total": len(CHECKS), "passed": sum(r["passed"] for r in CHECKS),
                            "failed": sum(not r["passed"] for r in CHECKS),
                            "are_product_tests": False},
        "archive_counts": {
            "zips": sum(len(v["zips"]) for v in results.values()),
            "artifact_members": sum(z["members"] for r in results.values() for z in r["zips"]
                                    if z["github_digest_checked"]),
            "log_members": sum(z["members"] for r in results.values() for z in r["zips"]
                               if not z["github_digest_checked"]),
        },
        "new_executions": {"native": 0, "product_tests": 0, "replay": 0, "cargo": 0,
                           "full_gate": 0, "gui": 0, "network": 0, "delegated_agents": 0},
        "old_failed_run": {"id": 43990824640, "status": "FAIL",
                           "first_bad_census_subreadings": "UNKNOWN", "exact_root_cause": "UNKNOWN",
                           "race_proven": False, "basis": "user instruction + HANDOFF/ADR0157; not re-signed"},
        "quality": {"id": 43997403533, "covered": False, "waited_or_refreshed": False},
        "boundaries": BOUNDARIES,
        "read_only": {"tracked_source_docs_and_git_metadata_unchanged": True,
                      "tracked_files_hashed": before["tracked_files"],
                      "target_accessed_or_modified": False,
                      "tracked_status_at_verifier_start": before["tracked_status"],
                      "original_input_files_hashed": len(INPUTS),
                      "write_set": str(OUT.relative_to(ROOT)) + "/",
                      "git_read_commands": GIT_READS},
        "independence": {
            "parent_verifier_executed": False, "repository_modules_imported": False,
            "command_recipe": "independently parsed pinned production Rust string literals",
            "oracle_recalculation": "raw process/socket/full independent inventory and numeric samples",
        },
    }
    decision = {"approved": approved, "decision": "APPROVE" if approved else "CHANGES_REQUESTED",
                "qualification": "LIMITED_TO_SPECIFIED_ORIGINAL_EVIDENCE",
                "source": SOURCE, "findings_by_priority": priorities, "findings": findings,
                "scope": SCOPE, "boundaries": BOUNDARIES, "new_native_executions": 0,
                "new_product_tests": 0}
    save("summary.json", summary)
    save("decision.json", decision)
    save("checks.json", {"are_product_tests": False, "checks": CHECKS})
    save("inputs-manifest.json", {"source": SOURCE, "files": INPUTS,
                                 "protected_before": before, "protected_after": after})
    if approved:
        review = f"""# 限定 APPROVE

新非作者只读复核 source `{SOURCE}` 的已下载原件；P0/P1/P2/P3 = **0/0/0/0**。
本次只签指定的两次真实 Windows OpenSSH 和一次直接 API/capture replay 证据。

| 范围 | run / artifact | 原件结论 |
|---|---|---|
| OpenSSH 修复首轮 | 43997403565 / 14290995772 | success；21 接纳、20 非 master 自然终态、4 PowerShell 自然 exit0 |
| OpenSSH 重复轮 | 43998970900 / 14291880367 | success；21 接纳、20 非 master 自然终态、4 PowerShell 自然 exit0 |
| 直接 API/replay | 43997403484 / 14289254506 | success；5 个生产 PowerShell 自然 exit0、原 replay 1 passed；SSH 前置 job skipped |

逐原 ZIP 对照本地 fetch 回执、所有成员/CRC/解压字节及 GitHub artifacts API digest；
共 **6 ZIP、126 artifact 成员、36 log 成员**。三组 run/jobs/artifact 的精确 source 均相等，
checkout 日志对应精确 source；SSH 另有干净 engineering source 回执。
直接 API receipt 不含 source，来源以 run/jobs/artifact/checkout 日志组合绑定。

独立从 pinned Rust 生产字面量和 PS1 原字节重建 UTF-16LE/Base64；
两次各 4 个原 PowerShell 的选项和 Base64 完全相等，仅 argv0 后两个空格被单独识别。
Rust 原件各 1 passed、22 条断言记录，公开认证成功，错误 pin 返回 ChangedHostKey，
snapshot/processes/listening_sockets 各一次，三次缓存读取、暂停/clone 撤权和 reset 未重复采集。
无独立服务器认证审计日志，错误 pin 的判断限于 Rust 回执及源中握手先于用户认证的顺序。

未调用父校验器或产品模块。由原始 Win32 读数独立重算每组四自有双栈端点、两排除连接、
进程身份/工作集及完整前后 inventory 的 **3 稳定接口、2 固定卷**，数值/容差与 comparison 一致；
CPU 跨窗口差异仅为信息。未知指标和 skip-capacity 保持原语义。

两次 seal 均完整 census、仅 master 活跃；seal 的 HOLD 正确表示尚未清理。
封闭前后 21 个 PID/创建时刻/image/command 身份集合不变；所有非 master 在强制清理前自然终态。
非 master 原退出码保留 0×14、255×5、1×1，未冒称全部 exit0；master 单独受控 exit125。
最终 Job 空、所有原对象 signaled/退出事件继续、无 pending/debug connection/detach，
handles 从关闭前 22 到关闭后 0，子进程 pipes drained/reaped，临时私钥目录删除。
每次 263 条异常记录均为 first-chance；21 初始断点被继续，其余 242 按 NOT_HANDLED 转交，
未将整批异常内容展开或认定为真实崩溃。
两次 seal/关闭前/final 的 incomplete census 计数均 **0**；原诊断数组另存，原件不变。
sshd 各有 55 字节 kex/readiness 断连诊断，保留，不冒称 stderr 全空。

本次离线证据校验 **{len(CHECKS)} 项通过**，不是产品测试数；**native 新执行=0、产品测试重跑=0**。
Quality **43997403533 不覆盖、不等待**；原失败 **43990824640 仍 FAIL**，
首次坏 census 分项和精确原因 **UNKNOWN**，不以新成功推定旧失败已证实 race。
GUI/安装/发行/完整产品及任意外部 broker 进程不在本次签署范围。
Windows 可执行文件 SHA 是 runner 原始测量，本地未下载/重哈希 exe。

唯一写集 `work/windows-ssh-repair-ci-review-20261117/`；
本次完整 verifier 执行前后源代码/docs/Git 元数据和所有已读原件摘要相等，未访问 target。
执行前本地已有两份无关文档修改（`docs/design/HALLMARK_NATIVE.md`、`docs/testing/README.md`），
本 reviewer 未写这些路径；固定 engineering 输入仍干净。首次本地校验因过宽的全 checkout
clean guard 停止，保留 attempt-01 回执；这不是原 CI 或产品失败。
独立脚本 `recompute.py`，逐项 `checks.json`，输入绑定 `inputs-manifest.json`，
真实进程执行回执 `execution-receipt.json`；结构化结论见 `summary.json`、`decision.json`。
"""
    else:
        review = "# 真实发现\n\n" + json.dumps(findings, ensure_ascii=False, indent=2) + "\n"
    save("review.md", review)
    print(json.dumps({"source": SOURCE, "approved": approved,
                      "findings_by_priority": priorities, "evidence_checks": summary["evidence_checks"],
                      "archive_counts": summary["archive_counts"], "native_new_executions": 0,
                      "quality_covered": False}, ensure_ascii=False))
    return 0 if approved else 1


if __name__ == "__main__":
    try:
        sys.exit(main())
    except EvidenceMismatch as error:
        print(json.dumps({"verification_completed": False, "failed_check": str(error),
                          "native_new_executions": 0}), file=sys.stderr)
        sys.exit(1)
