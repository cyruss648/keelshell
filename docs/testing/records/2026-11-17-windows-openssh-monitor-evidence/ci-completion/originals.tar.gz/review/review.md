# 限定 APPROVE

新非作者只读复核 source `660e90d6f7c7111853db7b73f4ca2344f633700d` 的已下载原件；P0/P1/P2/P3 = **0/0/0/0**。
本次只签指定的两次真实 Windows OpenSSH 和一次直接 API/capture replay 证据。

| 范围 | run / artifact | 原件结论 |
|---|---|---|
| OpenSSH 修复首轮 | 43997403565 / 14290995772 | success；21 接纳、20 非 master 自然终态、4 PowerShell 自然 exit0 |
| OpenSSH 重复轮 | 43998970900 / 14291880367 | success；21 接纳、20 非 master 自然终态、4 PowerShell 自然 exit0 |
| 直接 API/replay | 43997403484 / 14289254506 | success；5 个生产 PowerShell 自然 exit0、原 replay 1 passed；SSH 前置 job skipped |

逐原 ZIP 对照本地 fetch 回执、所有成员/CRC/解压字节及 GitHub artifacts API digest；
共 **6 ZIP、126 artifact 成员、36 log 成员**。三组 run/jobs/artifact 的精确 source 均相等，
checkout 日志对应精确 source；SSH 另有干净 engineering source 回执。
直接 API receipt 不含 source，来源以 run/jobs/artifact/checkout 日志组合绑定。

独立从 pinned Rust 生产字面量和 PS1 原字节重建 UTF-16LE/Base64；
两次各 4 个原 PowerShell 的选项和 Base64 完全相等，仅 argv0 后两个空格被单独识别。
Rust 原件各 1 passed、22 条断言记录，公开认证成功，错误 pin 返回 ChangedHostKey，
snapshot/processes/listening_sockets 各一次，三次缓存读取、暂停/clone 撤权和 reset 未重复采集。
无独立服务器认证审计日志，错误 pin 的判断限于 Rust 回执及源中握手先于用户认证的顺序。

未调用父校验器或产品模块。由原始 Win32 读数独立重算每组四自有双栈端点、两排除连接、
进程身份/工作集及完整前后 inventory 的 **3 稳定接口、2 固定卷**，数值/容差与 comparison 一致；
CPU 跨窗口差异仅为信息。未知指标和 skip-capacity 保持原语义。

两次 seal 均完整 census、仅 master 活跃；seal 的 HOLD 正确表示尚未清理。
封闭前后 21 个 PID/创建时刻/image/command 身份集合不变；所有非 master 在强制清理前自然终态。
非 master 原退出码保留 0×14、255×5、1×1，未冒称全部 exit0；master 单独受控 exit125。
最终 Job 空、所有原对象 signaled/退出事件继续、无 pending/debug connection/detach，
handles 从关闭前 22 到关闭后 0，子进程 pipes drained/reaped，临时私钥目录删除。
每次 263 条异常记录均为 first-chance；21 初始断点被继续，其余 242 按 NOT_HANDLED 转交，
未将整批异常内容展开或认定为真实崩溃。
两次 seal/关闭前/final 的 incomplete census 计数均 **0**；原诊断数组另存，原件不变。
sshd 各有 55 字节 kex/readiness 断连诊断，保留，不冒称 stderr 全空。

本次离线证据校验 **4018 项通过**，不是产品测试数；**native 新执行=0、产品测试重跑=0**。
Quality **43997403533 不覆盖、不等待**；原失败 **43990824640 仍 FAIL**，
首次坏 census 分项和精确原因 **UNKNOWN**，不以新成功推定旧失败已证实 race。
GUI/安装/发行/完整产品及任意外部 broker 进程不在本次签署范围。
Windows 可执行文件 SHA 是 runner 原始测量，本地未下载/重哈希 exe。

唯一写集 `work/windows-ssh-repair-ci-review-20261117/`；
本次完整 verifier 执行前后源代码/docs/Git 元数据和所有已读原件摘要相等，未访问 target。
执行前本地已有两份无关文档修改（`docs/design/HALLMARK_NATIVE.md`、`docs/testing/README.md`），
本 reviewer 未写这些路径；固定 engineering 输入仍干净。首次本地校验因过宽的全 checkout
clean guard 停止，保留 attempt-01 回执；这不是原 CI 或产品失败。
独立脚本 `recompute.py`，逐项 `checks.json`，输入绑定 `inputs-manifest.json`，
真实进程执行回执 `execution-receipt.json`；结构化结论见 `summary.json`、`decision.json`。
