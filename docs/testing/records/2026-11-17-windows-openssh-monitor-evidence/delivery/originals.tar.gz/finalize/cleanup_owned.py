"""Plan or remove only this batch's byte-verified, Git-preserved work copies."""
import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import tarfile
import zipfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
OWNED = (
    "native-toolbar-20261117",
    "native-toolbar-review-20261117",
    "windows-ssh-ci-completion-stage-20261117",
    "windows-ssh-ci-originals-20261117",
    "windows-ssh-ci-repair-watch-20261117",
    "windows-ssh-exact-ci-20261117",
    "windows-ssh-first-ci-review-20261117",
    "windows-ssh-integration-20261117",
    "windows-ssh-repair-ci-review-20261117",
)
ARCHIVES = (
    "docs/testing/records/2026-11-17-windows-openssh-monitor-evidence",
    "docs/testing/records/2026-11-17-windows-openssh-monitor-evidence/repair",
    "docs/testing/records/2026-11-17-windows-openssh-monitor-evidence/ci-completion",
    "docs/testing/records/2026-11-17-native-toolbar-evidence",
)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def git_bytes(source, path):
    return subprocess.check_output(
        ["git", "show", source + ":" + path], cwd=ROOT, timeout=30)


def protected():
    directory = ROOT / "work/windows-monitor-delivery-20261117/package-r2"
    files = []
    for path in sorted(directory.rglob("*")):
        if path.is_file():
            assert not path.is_symlink()
            raw = path.read_bytes()
            files.append({"path": str(path.relative_to(ROOT)), "bytes": len(raw),
                          "sha256": digest(raw)})
    assert len(files) == 6
    target = ROOT / "work/recovery-batch-integration-20261115/target"
    state = target.stat()
    return {"package_files": files, "target_device": state.st_dev, "target_inode": state.st_ino}


def known_contents(source, extra):
    known = {}

    def retain(raw, origin):
        known.setdefault((len(raw), digest(raw)), origin)

    for archive_path in (*ARCHIVES, *extra):
        manifest = json.loads(git_bytes(source, archive_path + "/manifest.json"))
        raw = git_bytes(source, archive_path + "/originals.tar.gz")
        assert len(raw) == manifest["archive_bytes"] and digest(raw) == manifest["archive_sha256"]
        assert raw == (ROOT / archive_path / "originals.tar.gz").read_bytes()
        with tarfile.open(fileobj=io.BytesIO(raw), mode="r:gz") as archive:
            members = archive.getmembers()
            assert len(members) == manifest["count"]
            rows = {row["path"]: row for row in manifest["entries"]}
            assert len(rows) == len(members)
            for member in members:
                assert member.isfile() and not PurePosixPath(member.name).is_absolute()
                assert ".." not in PurePosixPath(member.name).parts
                content = archive.extractfile(member).read()
                row = rows.pop(member.name)
                assert len(content) == row["bytes"] and digest(content) == row["sha256"]
                origin = archive_path + "/originals.tar.gz:" + member.name
                retain(content, origin)
                if member.name.endswith(".zip"):
                    with zipfile.ZipFile(io.BytesIO(content)) as zipped:
                        entries = zipped.infolist()
                        assert len(entries) <= 1000 and sum(entry.file_size for entry in entries) <= 128 * 1024 * 1024
                        for entry in entries:
                            if entry.is_dir():
                                continue
                            retain(zipped.read(entry), origin + ":" + entry.filename)
            assert not rows
    return known


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source")
    parser.add_argument("label")
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--extra-archive", action="append", default=[])
    options = parser.parse_args()
    assert subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True, timeout=10).strip() == options.source
    output = BASE / (options.label + ".json")
    assert not output.exists()
    before = protected()
    known = known_contents(options.source, options.extra_archive)
    result = {"source": options.source, "observed_utc": datetime.now(timezone.utc).isoformat(),
              "apply": options.apply, "directories": [], "protected_before": before,
              "bytes_removed": 0, "files_removed": 0, "directories_removed": 0}
    for name in OWNED:
        directory = ROOT / "work" / name
        if not directory.exists():
            continue
        assert directory.resolve() == directory and directory.parent == ROOT / "work"
        entries = []
        unmatched = []
        bytecode = []
        for path in sorted(directory.rglob("*")):
            assert not path.is_symlink(), path
            if not path.is_file():
                continue
            relative = str(path.relative_to(ROOT))
            raw = path.read_bytes()
            key = (len(raw), digest(raw))
            row = {"path": relative, "bytes": len(raw), "sha256": key[1]}
            if "__pycache__" in path.parts and path.suffix == ".pyc":
                row["derived_python_bytecode"] = True
                bytecode.append(row)
            elif key in known:
                row["git_preserved_as"] = known[key]
                entries.append(row)
            else:
                unmatched.append(row)
        record = {"path": str(directory.relative_to(ROOT)), "preserved": entries,
                  "unmatched": unmatched, "derived_bytecode": bytecode, "removed": False}
        if options.apply and not unmatched:
            for row in entries + bytecode:
                raw = (ROOT / row["path"]).read_bytes()
                assert len(raw) == row["bytes"] and digest(raw) == row["sha256"]
            shutil.rmtree(directory)
            assert not directory.exists()
            record["removed"] = True
            result["directories_removed"] += 1
            result["files_removed"] += len(entries) + len(bytecode)
            result["bytes_removed"] += sum(row["bytes"] for row in entries + bytecode)
        result["directories"].append(record)
    result["protected_after"] = protected()
    assert result["protected_after"] == result["protected_before"]
    with output.open("x") as handle:
        json.dump(result, handle, indent=2)
        handle.write("\n")
    print(json.dumps({
        "source": options.source, "apply": options.apply,
        "directories_removed": result["directories_removed"],
        "files_removed": result["files_removed"], "bytes_removed": result["bytes_removed"],
        "protected_unchanged": True,
        "remaining_unmatched": {
            row["path"]: len(row["unmatched"]) for row in result["directories"] if row["unmatched"]
        },
    }))


if __name__ == "__main__":
    main()
