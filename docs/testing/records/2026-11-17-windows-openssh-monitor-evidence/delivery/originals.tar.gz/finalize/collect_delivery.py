"""Preserve final readback, cleanup and remaining supplemental originals."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
STAGE = ROOT / "work/windows-ssh-delivery-stage-20261117"
assert not STAGE.exists()
STAGE.mkdir()
cleanup = json.loads((BASE / "cleanup-result-state-r1.json").read_text())
supplemental = []
for directory in cleanup["directories"]:
    for row in directory["unmatched"]:
        path = ROOT / row["path"]
        raw = path.read_bytes()
        assert len(raw) == row["bytes"] and hashlib.sha256(raw).hexdigest() == row["sha256"]
        target = STAGE / "supplemental" / row["path"]
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as output:
            output.write(raw)
        supplemental.append(row)
for path in sorted(BASE.iterdir()):
    if not path.is_file():
        continue
    assert not path.is_symlink()
    target = STAGE / "finalize" / path.name
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("xb") as output:
        output.write(path.read_bytes())
acceptance = {
    "sealed_utc": datetime.now(timezone.utc).isoformat(),
    "documentation_source": cleanup["source"],
    "engineering_source": "660e90d6f7c7111853db7b73f4ca2344f633700d",
    "first_cleanup": {
        key: cleanup[key] for key in ("directories_removed", "files_removed", "bytes_removed")
    },
    "supplemental_files": supplemental,
    "remaining_owned_work_copies": [
        {"path": row["path"],
         "files": sum(len(row[key]) for key in ("preserved", "unmatched", "derived_bytecode")),
         "bytes": sum(item["bytes"] for key in ("preserved", "unmatched", "derived_bytecode")
                      for item in row[key])}
        for row in cleanup["directories"] if not row["removed"]
    ],
    "final_cleanup_rule": "Recheck every work file against committed archives before deletion.",
    "new_product_tests": 0,
}
with (STAGE / "acceptance.json").open("x") as output:
    json.dump(acceptance, output, indent=2)
    output.write("\n")
print(json.dumps({
    "documentation_source": acceptance["documentation_source"],
    "supplemental_files": len(supplemental),
    "stage_members": sum(path.is_file() for path in STAGE.rglob("*")),
    "first_cleanup": acceptance["first_cleanup"],
}))
