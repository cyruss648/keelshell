"""Read local, tracking, remote and worktree state without modifying Git."""
import json
from pathlib import Path
import subprocess
import sys

expected,label=sys.argv[1:]
commands={
 'local':['git','rev-parse','HEAD'],
 'tracking':['git','rev-parse','refs/remotes/origin/feature/editor-unicode-codec-20261114'],
 'remote':['git','ls-remote','--heads','origin','refs/heads/feature/editor-unicode-codec-20261114'],
 'status':['git','status','--porcelain=v1'],
}
results={}
for name,command in commands.items():
 r=subprocess.run(command,capture_output=True,text=True,timeout=40,check=False)
 results[name]={'command':command,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
all_ok=all(r['exit']==0 for r in results.values())
local=results['local']['stdout'].strip();tracking=results['tracking']['stdout'].strip()
remote=results['remote']['stdout'].split()[0] if results['remote']['stdout'].split() else None
record={'expected_source':expected,'all_commands_passed':all_ok,'three_shas_match':expected==local==tracking==remote,'working_tree_clean':not results['status']['stdout'],'shas':{'local':local,'tracking':tracking,'remote':remote},'commands':results}
with (Path(__file__).resolve().parent/(label+'.json')).open('x') as output:json.dump(record,output,indent=2);output.write('\n')
print(json.dumps({k:v for k,v in record.items() if k!='commands'}))
assert all_ok and record['three_shas_match'] and record['working_tree_clean']
