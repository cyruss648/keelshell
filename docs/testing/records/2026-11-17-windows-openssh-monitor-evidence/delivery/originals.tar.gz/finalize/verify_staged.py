"""Bind a documentation-only index to the existing repair freeze."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import re
import runpy
import subprocess
import sys
from urllib.parse import unquote

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
SOURCE = "660e90d6f7c7111853db7b73f4ca2344f633700d"
common = runpy.run_path(str(
    ROOT / "docs/testing/records/2026-11-17-windows-openssh-monitor-evidence/repair/verify.py"))
freeze = json.loads(common["unpack"](common["BASE"])["integration/full-gate-inputs-r2.json"])
output = BASE / sys.argv[1]
assert not output.exists()
subprocess.run(["git", "diff", "--cached", "--check"], cwd=ROOT, check=True, timeout=30)
names = sorted(name.decode() for name in subprocess.check_output(
    ["git", "ls-files", "-z"], cwd=ROOT, timeout=20,
).split(b"\0") if name and not name.startswith((b"docs/", b".hallmark/")))
assert names == [row["path"] for row in freeze["inputs"]]
delta = [name.decode() for name in subprocess.check_output(
    ["git", "diff", "--cached", "--name-only", "-z"], cwd=ROOT, timeout=20,
).split(b"\0") if name]
assert delta and all(name.startswith("docs/") for name in delta)
rows = {row["path"]: row for row in freeze["inputs"]}
links = 0
for name in delta:
    path = ROOT / name
    raw = path.read_bytes()
    rows[name] = {"path": name, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
    if path.suffix == ".md":
        for target in re.findall(r"\]\(([^)\n]+)\)", raw.decode()):
            target = unquote(target.split("#", 1)[0].split(" ", 1)[0].strip("<>"))
            if not target or ":" in target:
                continue
            assert (path.parent / target).exists(), (name, target)
            links += 1


def verify(row):
    raw = subprocess.check_output(
        ["git", "show", ":" + row["path"]], cwd=ROOT, timeout=20)
    assert len(raw) == row["bytes"] and hashlib.sha256(raw).hexdigest() == row["sha256"], row["path"]


with ThreadPoolExecutor(max_workers=4) as pool:
    list(pool.map(verify, rows.values()))
assert not subprocess.check_output(["git", "diff", "--name-only"], cwd=ROOT, timeout=20)
record = {
    "engineering_source": SOURCE, "engineering_inputs": len(freeze["inputs"]),
    "staged_changed_docs": len(delta), "all_git_index_blobs_match": True,
    "unstaged_tracked_changes": 0, "local_links_checked": links,
    "source_aggregate_sha256": freeze["aggregate_sha256"], "product_tests_replayed": 0,
}
with output.open("x") as handle:
    json.dump(record, handle, indent=2)
    handle.write("\n")
print(json.dumps(record))
