"""Seal only public native observations, excluding the isolated runtime."""
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
DEST = ROOT / "docs/testing/records/2026-11-17-native-toolbar-evidence"
DEST.mkdir(exist_ok=True)
assert not (DEST / "originals.tar.gz").exists()
payloads = {}
selection = []
observation = json.loads((BASE / "observation.json").read_text())
names = [
    "package-binding.json", "package-manifest.json", "native-process.json",
    "native-receipt.json", "native.stdout", "native.stderr",
    "post-close-processes.json", "post-close-cleanup.json", "observation.json",
    "observation-metadata-r1-invalid.json", "run_native.py", "record_observation.py",
]
names += [entry[key] for entry in observation["captures"] for key in ("image", "ax")]
for name in names:
    path = BASE / name
    assert path.is_file() and not path.is_symlink()
    raw = path.read_bytes()
    payloads["native/" + name] = raw
    selection.append({"source": str(path.relative_to(ROOT)), "archive": "native/" + name})
review = ROOT / "work/native-toolbar-review-20261117"
for path in sorted(review.rglob("*")):
    if path.is_file() and "__pycache__" not in path.parts:
        assert not path.is_symlink()
        name = "review/" + path.relative_to(review).as_posix()
        payloads[name] = path.read_bytes()
        selection.append({"source": str(path.relative_to(ROOT)), "archive": name})
payloads["agent-lifecycle.json"] = (json.dumps({
    "agent": "01a1e734-70bf-7611-b422-1076fb0f9428", "name": "Hume",
    "closed": True, "close_observation": "close_agent returned completed scoped approval",
}, indent=2) + "\n").encode()
payloads["selection.json"] = (json.dumps(selection, indent=2) + "\n").encode()
rows = [{"path": name, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
        for name, raw in sorted(payloads.items())]
buffer = io.BytesIO()
with gzip.GzipFile(fileobj=buffer, mode="wb", filename="", mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as archive:
        for row in rows:
            member = tarfile.TarInfo(row["path"])
            member.size, member.mode = row["bytes"], 0o644
            archive.addfile(member, io.BytesIO(payloads[row["path"]]))
raw = buffer.getvalue()
manifest = {
    "sealed_utc": datetime.now(timezone.utc).isoformat(),
    "count": len(rows), "archive_bytes": len(raw),
    "archive_sha256": hashlib.sha256(raw).hexdigest(), "entries": rows,
    "excluded": ["runtime/", "Application binaries", "Global application data",
                 "Post-close auto-launched application's accessibility tree"],
}
(DEST / "originals.tar.gz").write_bytes(raw)
with (DEST / "manifest.json").open("x") as output:
    json.dump(manifest, output, indent=2)
    output.write("\n")
print(json.dumps({key: value for key, value in manifest.items() if key != "entries"}))
