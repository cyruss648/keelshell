# Windows SSH debug owner 作者交接 — 2026-11-17

作者实现与本机专项已完成，等待父级整合及新的非作者评审；真实 Windows ABI、继承调试链和 Windows OpenSSH 验收仍为 **UNRUN / HOLD**。本机是 Darwin，离线控制不签 native 成功。

基线及最终只读 HEAD 均为 `bfbea7bcc84ff433d28a635e85daed9cca337fb0`。直接使用共享 checkout，未提交。父级 SSH、workflow、文档及 Rust 测试的并行修改已保留，不计入本作者改动或成绩。

## 写集与最终差分

仅修改下列三个源码文件；本目录存放本轮日志、研究原件和报告。

| 文件 | 改动 |
| --- | --- |
| `scripts/windows_monitor/debug_job.py` | 新增 907 行，提供 `WindowsDebugJob(WindowsJob)`、原对象 admission、有限 debug pump、自然终态、seal 和独立 cleanup。 |
| `scripts/test_windows_ssh_debug_job.py` | 新增 1147 行，49 项控制，包含一个需要真实 Windows 的测试。 |
| `scripts/windows_native_crash.py` | 相对基线 +38 / -16；受限 creation flag、debug process factory／未注册创建失败清理 hook，以及最终关闭失败的 receipt 保留。 |

两个新增文件与基类修改合计 +2092 / -16。基类完整差分见 [windows-native-crash.diff](windows-native-crash.diff)，最终三文件摘要见 [source-manifest-r7.json](source-manifest-r7.json)。

`WindowsJob.spawn` 默认 flags、普通 `WindowsProcess` 和 Job assignment-before-resume 行为保持。新增 keyword-only `creation_flags=0` 只接受精确整数 `0` 或 `DEBUG_PROCESS=1`，拒绝 bool、`DEBUG_ONLY_THIS_PROCESS`、breakaway 和任意其他组合。私有 factory／创建注册失败 hook 只为 debug owner 提供会泵事件的失败清理。

最终 lifecycle 修正位于 `finish_owned`：捕获 `owner.close()` 的异常为 `owned_close_failed`，在 finally 中逐一关闭没有活跃读取线程的流；某一流关闭异常记录 `owned_stream_close_failed` 后继续其他流。返回错误集合及已有 `terminal.errors` 同步包含这些失败，避免关闭失败越过 `Evidence.keep_child` 的 stdout、stderr、receipt 保存。已存在的失败不转为成功，普通成功路径的错误集合仍为空。

新增四项实际路径控制覆盖：生产 `WindowsDebugJob.close()` 的 owned handle 关闭失败、真实 `Evidence.keep_child` 保存失败 receipt 和两份捕获、流关闭异常后的继续收口，以及完整成功路径。证据保存测试使用 `tempfile.TemporaryDirectory()`，所有证据断言均在 context 内；源码没有作者 work 路径依赖。r7 运行器只为本轮将 TMPDIR 指向本目录，退出后该测试临时目录为 0。r6 的旧版控制原件保留在 `keep-child-close-error-4d54d4eabb5d42058946d40f12e1dc96/`，属于本轮历史原件，当前测试不会再生成这种固定路径。

`_refresh_original` 内 `debug_original_exit_query_failed` 的 `_fail` 调用只有一处；先前看到的重复是阅读窗口重叠。

## 父级接口与证据合同

```python
owner = WindowsDebugJob()
process = owner.spawn(command, cwd, env, budget, merge_error=False)
owner.pump_debug(budget)
before = owner.seal_admission(budget, settle_seconds=3)
# 父级在关闭 SSH 服务前核对固定命令、非 master 自然终态及完整 census。
terminal, errors = finish_owned(owner, process, pumps, budget, capture)
after = owner.terminal_evidence()
```

- `spawn` 继承原调用签名，原始 root 创建使用 `DEBUG_PROCESS | CREATE_SUSPENDED`，Job assignment 在 resume 之前完成。每个 CREATE 在成功 Continue 前 DuplicateHandle、核对／加入 Job、核对无 breakaway／保留 kill-on-close、读取原对象 image、u64 `GetProcessTimes` creation time 和原 command line。
- `admissions` 是只读 mapping 快照组成的 tuple。每项含 `pid`、`image`、`creation_time`、`command_line`、`retained_before_first_instruction`、`identity_bound_before_first_continue`、完整 boolean `is_master`、EXIT event、原对象 signaled／exit code 及 `natural_terminal_before_cleanup`。主对象按原对象身份绑定，不随 PID 重用漂移。
- `pump_debug(budget)` 是零超时 WaitForDebugEvent；每片最多 64 events，native 调用之间最多约 10ms，再有界刷新最多 64 个原对象。所有控制必须在创建线程进行，一个线程只允许本模块一个 debug owner。原始 budget 不会被调用者的新 budget 延长。
- 初始 first-chance breakpoint 只消费一次；其他异常默认 `DBG_EXCEPTION_NOT_HANDLED`。真实异常不会被当作已处理吞掉。
- EXIT 先记录并 Continue，再查询原 Duplicate 对象。只有原对象 signaled 且 `GetExitCodeProcess` 与 EXIT code 一致，才能建立终态；仅收到 EXIT、仅 Job active=0、仅退出码 259 都不替代原对象证明。
- `seal_admission` 在同一 budget 内有限等待非 master 自然退出，保留 cleanup reserve。只剩活 master 时设置并读回 Job `ACTIVE_PROCESS_LIMIT=1`，核对总 census，再将 `admission_closed` 标真。setter 失败或未生效不签封闭；封闭／cleanup 后迟到 CREATE 仍记录、保留 handle 并 HOLD，在安全终止请求之前不作正常 Continue。
- `terminal_evidence(budget=None)` 返回独立 JSON 快照：`errors`、`complete_original_object_census`、`admission_closed`、`admission_phase_closed`、`job_total_processes`、`job_active_processes`、`identities_bound`、`pending_process_objects`、`pending_debug_event`、`debug_connections`、`debug_events_received`、`debug_events_continued`、`fallback_detaches`、`owned_handles_remaining`、`closed`、`terminal_proven`、`exceptions` 和 `admissions` 等。后续 cleanup 不能修改父级先前保存的 admission 身份集合。
- live master 的总 terminal 仍为 HOLD；清理前通过的是完整 census、admission seal 和全部非 master 自然终态。清理后父级应另取快照，要求 native、无 errors、`terminal_proven`、`closed`、pending 0、自有 handles 0、fallback detach 0，并逐项比较前后 admission 身份集合。
- 原始 debug CREATE／CREATE_THREAD 的 process/thread handle 属于调试 API，不显式 CloseHandle；Duplicate、原始 CreateProcess 返回 handles 和事件 `hFile` 属于自有 inventory。cleanup 的 `terminate`／`active`／process `poll`／`wait`／`wait_retained`／`close` 独立泵事件，不依赖父循环。detach 仅为失败资源释放尝试，始终 HOLD，不作为终态证明。

未绑定命令行、遗漏 admission、重复身份、未知事件、不完整 Job total census、继续失败、关闭失败和过期 deadline 都保留失败。class 60 pre-continue 参数不可用时采取严格 HOLD；没有以 argv 或后读值伪称首指令前绑定成功。

## 实际验证与计数

本作者的验证命令共 **11 次**：7 次下列 Python 作者专项、2 次仅三写集文件的 AST／内存 compile／空白检查、2 次仅三写集文件的 `git diff --check`。此处是验证命令计数，不把只读检索、读文件和生成回执算成测试。Cargo、全仓门禁、真实 Windows 执行、Git 写均为 **0**。

```sh
python3 -B -m unittest discover -s scripts -p test_windows_ssh_debug_job.py -v
git diff --no-ext-diff --check -- scripts/windows_monitor/debug_job.py scripts/test_windows_ssh_debug_job.py scripts/windows_native_crash.py
```

| 专项轮次 | exit | 实际摘要 | 运行器秒数 |
| --- | --- | --- | --- |
| r1 | 124 | 60 秒 timeout，无完整 suite 摘要，不计为通过 | 60.005464 |
| r2 | 0 | 32 run = 31 passed + 1 native skipped | 0.092578 |
| r3 | 0 | 41 run = 40 passed + 1 native skipped | 0.166113 |
| r4 | 0 | 45 run = 44 passed + 1 native skipped | 0.127807 |
| r5 | 0 | 45 run = 44 passed + 1 native skipped | 0.107433 |
| r6 | 0 | 49 run = 48 passed + 1 native skipped | 0.540152 |
| **r7 最终** | **0** | **49 run = 48 passed + 1 native skipped；suite 0.029 秒** | **0.122686** |

最后两次语法检查均三文件通过，不写 pyc；两次 scoped diff check 均 exit 0。Git diff 不覆盖未跟踪文件的内容，因此两个新增文件同时单独核查末尾空白。最终源码摘要与 r7 receipt 相等。

准确回执入口：

- [validation-final.json](validation-final.json)：最终命令数与逐轮摘要；之前的 `validation-index.json` 仅为 r6 中间快照。
- [python-special-r7.json](python-special-r7.json)、[python-special-r7.log](python-special-r7.log)：最终专项和源码绑定。
- [syntax-check-r7.json](syntax-check-r7.json)、[diff-check-r7.json](diff-check-r7.json)、[diff-check-r7.log](diff-check-r7.log)：最终检查。原 r6 检查未覆盖写。
- [python-special-r1.json](python-special-r1.json)、[python-special-r1.log](python-special-r1.log)：原始 timeout。原因是 CREATE 失败后的 EXIT 没有正常 admission，cleanup 曾等待不推进；修复为保留失败原对象／借用 handle 的清理信息，安全终止后继续事件，失败保持 sticky。

控制覆盖遗漏 admission、PID 重用与重复原对象身份、pre-continue 顺序、class60 长度／指针／读取失败、异常分派、未 signaled 的 EXIT、exit query／code 不一致、完整 Job census、seal races、cleanup 迟到创建、有限事件片／原 deadline、Continue 失败、关闭失败、终止 fallback、创建注册中断与普通 spawn 默认行为。边界注入向生产 owner 提供故障观察，不实现第二套 admission 算法；匿名宿主管道与 BytesIO 控制均为离线控制。

## 官方原文与保留失败

已核实官方 MicrosoftDocs 原件，不再联网重试。作者历史只读 HTTP 共 **23 次**：14 次 learn.microsoft.com URLError、1 次 curl exit 35、8 次官方 MicrosoftDocs GitHub 原文成功。父级另外提供的 GET／blob 回执不计入作者请求数。

- [official-docs.json](official-docs.json)：14 次原始失败。
- [curl-failure.txt](curl-failure.txt)：原始 curl 失败。
- [official-github-docs.json](official-github-docs.json)、[official-research-index.json](official-research-index.json) 与本目录 `github-*.md`：8 份官方原件及成功回执。
- 父级 `work/windows-ssh-official-research-20261117/debug-events.md`：25727 bytes，SHA256 `c0dc0eaeb21e029dce783ab1625d5553a95152e5ce6ced9b8cbe9faf88b9cd0a`。
- 父级 `work/windows-ssh-official-research-20261117/process-creation-flags.md`：24458 bytes，SHA256 `b635fc05c1e416c6ccfed2cbe55e3971fa33f82637ac84b643b229a8e134bcd2`。

官方合同用于核对：CREATE 在 user mode 执行前产生；EXIT Continue 时系统关闭 debug 借用 process/thread handles；调试器关闭事件 hFile；Duplicate + Continue + 原对象 signaled 才能确认 kernel shutdown；DEBUG_PROCESS 继承与创建线程约束。`NtQueryInformationProcess` 为内部 API，官方资料不提供 class 60 跨版本稳定承诺，本实现明确保留其不可用／参数尚未初始化的 HOLD。

## 最终源码 SHA256 与未验证边界

| 文件 | SHA256 |
| --- | --- |
| `scripts/windows_monitor/debug_job.py` | `8bc7cd4e9d909cbcde98dbec1d492eaae864facb7688a52ebe78ea4755491b13` |
| `scripts/test_windows_ssh_debug_job.py` | `776e838e7ef47dfb3d5f19877a0224ad0fec4a20d4b2295ca0e0f236059b3cef` |
| `scripts/windows_native_crash.py` | `702e2214d6772bbd1841135ba17e30c57053f7165099206448451f19068ad0a4` |

所有新标量原型使用固定 Windows 16／32 位及 pointer-width 类型。当前 ctypes size 控制仅证明此宿主的布局运算，不证明 Windows 32／64 ABI、WOW64 或 ARM64。真实 `WaitForDebugEvent`／Continue／Duplicate 权限和句柄生命周期、class60 首次停顿读取、Job ActiveProcessLimit seal 在原生并发下的行为、继承 DEBUG_PROCESS 的实际子链均未运行。

唯一 native 控制将创建真实 Python root 与真实 Python 子进程并验证原对象自然终态，在本机 skipped；实际 sshd.exe -D／OpenSSH／固定 PowerShell 生产命令由父级后续真实 Windows 集成验收。原生 API 调用之间受 budget 约束，未证明内核调用异常停滞时可被 Python deadline 抢占。Job 与继承调试链也不证明无关联外部 broker／WMI 创建的进程。

父级须保留上述 HOLD，并执行新的非作者评审。作者没有修改父级文件、创建额外 agent／chat／worktree／容器，也没有运行 Cargo、全仓门禁或执行 Git 写。
