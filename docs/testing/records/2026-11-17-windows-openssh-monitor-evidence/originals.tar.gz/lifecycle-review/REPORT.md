**Windows 真实 OpenSSH 调试接纳与清理：独立非作者复核 — 2026-11-17**

结论为 **APPROVE，限定本次源审与受影响 Python 离线证据规则**。确认发现为 **P0=0、P1=0、P2=0、P3=0**。本结论允许父级继续冻结和运行 full gate；真实 Windows OpenSSH、Win32 ABI、原生桌面及发行均未由本复核接纳。新 full gate 与 Windows 执行仍待父级分别取得证据。

复核 cwd 为 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`。用户指定基线及本次读回 HEAD 均为 `bfbea7bcc84ff433d28a635e85daed9cca337fb0`。当前工程为未提交候选，不能仅凭 HEAD 签署新增文件；本报告绑定实际文件 SHA256。

已读取 `AGENTS.md`、`/Users/hdh/.codex/RTK.md`、`docs/HANDOFF.md`、ADR0157 及其范围约束。核心写集是 `debug_job.py`、其专项测试和 `windows_native_crash.py` 相对基线的新差分；联读 `ssh.py` 的 seal／清理消费及 `windows_monitor_lab.OwnedChild`。已读作者最终 `HANDOFF.md`、`validation-final.json` 和 r7 摘要。没有将作者或父级的执行次数算入本人的独立运行次数。

父级候选 `candidate-inputs-r1.json` 声明 **765** 个输入，aggregate 为 `71872297a9a7b067fd85723de4e5c9c10f908dcc6a7e63ab91eeed6cb902db3a`。另读回 `review-candidate-r1.json` 的 10 个变化文件摘要；本报告只签所列源审范围，不借该整批 manifest 扩大 Rust、workflow 或产品验收范围。完整文件身份与原件入口见 `source-final-r3.json` 及 `source-binding-r4.json`。

最终核心三文件 SHA256 与作者 r7 一致：

| 文件 | SHA256 |
| --- | --- |
| `scripts/windows_monitor/debug_job.py` | `8bc7cd4e9d909cbcde98dbec1d492eaae864facb7688a52ebe78ea4755491b13` |
| `scripts/test_windows_ssh_debug_job.py` | `776e838e7ef47dfb3d5f19877a0224ad0fec4a20d4b2295ca0e0f236059b3cef` |
| `scripts/windows_native_crash.py` | `702e2214d6772bbd1841135ba17e30c57053f7165099206448451f19068ad0a4` |

相关消费源码为 `scripts/windows_monitor/ssh.py` SHA256 `d0684ffd9c6f8dd6fb614fcd2315ab0cab8f19cdac5770ee25dfaaa62b98f421`，`scripts/windows_monitor_lab.py` SHA256 `22f349d06996f61a78dc19b7a9f355ad36704b62e45e8a4bafa4a24374a9bafa`。这些身份由本次实际读取计算，并与候选对应项核对。

没有确认需逐项开出的 P0–P3 发现，因而没有伪造缺陷的触发／影响／修复清单。重点检查及实际证据如下；所有源码路径均为当前 checkout 的绝对路径：

| 检查 | 源码证据 | 结论及实际边界 |
| --- | --- | --- |
| Win32 标量、pointer widths、结构及原型 | `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/debug_job.py:31`、`:252` | 固定 16/32 位整数、pointer-sized 字段与 HANDLE，显式声明函数原型，校验 DEBUG_EVENT 布局。宿主 ctypes 运算通过；未证明任一真实 Windows ABI。 |
| DEBUG_PROCESS 与 assignment-before-resume | `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_native_crash.py:262`、`:328`；`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/debug_job.py:329` | 精确允许 0 或 1，拒绝 bool、only-this、breakaway。默认普通 WindowsProcess 路径保留；挂起 root 先加入 Job 再 resume。 |
| 同线程 pump 及有限事件片 | `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/debug_job.py:285`、`:589` | 创建线程检查、一个线程一个 owner、零超时 event wait，最多 64 events／有限刷新。不能把 Python budget 宣称为可抢占卡住的内核调用。 |
| 首次 Continue 前原对象与身份 | `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/debug_job.py:437` | Duplicate 原对象，绑定 PID、创建时间、image、原 command line、Job membership 后才成功 Continue。未借后读 PID 替代原对象。 |
| class 60 fail-closed | `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/debug_job.py:409` | 对 size/status、返回长度、UTF-16、buffer 范围及 NUL 检查。内部 NT 类不可用／首停顿参数未初始化均 HOLD；没有 argv fallback。跨版本可用性仍未验证。 |
| borrowed 与 owned handles | `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/debug_job.py:290`、`:504`、`:834` | 独立登记 CreateProcess／Duplicate／事件 hFile；不主动 CloseHandle 调试 API 的 process/thread 借用句柄。关闭失败留 inventory 和 sticky 错误。 |
| EXCEPTION 不吞 | `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/debug_job.py:480`、`:607` | 一次初始 first-chance breakpoint 控制之外传递 NOT_HANDLED；未知 admission 的 exception 也保持该默认值。真实 loader／异常分派仍需 Windows 控制。 |
| CREATE、EXIT 失败及中断 | `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/debug_job.py:310`、`:541`、`:557` | 失败 pending 保留原对象／借用 handle；安全终止请求后才推进失败事件；未注册创建有专门回收。Continue 失败、detach fallback 与中断不签成功。 |
| PID 复用 | `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/debug_job.py:460`、`:792` | 旧原对象保留到自身终态，重复身份和提前覆盖拒绝；原对象列表不依赖 PID 字典覆盖。SSH 消费额外拒绝 PID 歧义。 |
| 终态必须双重一致 | `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/debug_job.py:632`、`:871` | EXIT 已 Continue、原 Duplicate signaled、退出码一致及完整 census 才能成为 terminal。EOF、Job active=0、仅有退出码均不能替代该证明。 |
| natural、Job census、封接纳和 late admission | `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/debug_job.py:663`、`:688`、`:715`、`:752` | 自然非 master 退出先于强制清理；Job 累计 total 与所有 admissions 一致，读回 ACTIVE_PROCESS_LIMIT。迟到 CREATE 留证并 HOLD，清理不制造 natural。 |
| 原预算和 cleanup reserve | `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/debug_job.py:141`、`:724` | shared budget 取原预算与调用方预算最小值；自然 settle 保留 5 秒 cleanup reserve，不能用新 budget 延长。 |
| 父级 seal／cleanup 消费 | `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/ssh.py:263`、`:298`、`:459` | 固定四条生产 PowerShell 原命令、自然 exit0、前后身份集合、最终无 pending／owned handles／fallback detach。`keep_child` 抛异常时 nested finally 仍保存 debug cleanup 原件。 |

用户预告的 `finish_owned` 已知问题未重复计为新发现。最终修正在 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_native_crash.py:633`：owner.close 异常入 errors；逐 stream finally 收口；流关闭失败继续处理其他流；已有 terminal.errors 同步失败。独立窄跑新增四控制实际 **4 passed**。测试证据目录已改 `TemporaryDirectory`，本人只通过 TMPDIR 指向 reviewer 自有目录，无测试源码／`__file__` 重定向。`runtime-tmp/` 在结束时 **0** 个条目。

额外要求的 `_refresh_original` 早退专项，结论与详细触发事实见 `notice-early-signal-r2.md`。离线 early-signal→EXIT 注入确会漏更新 natural 或漏补一条冲突诊断，但保持自然 seal HOLD／冲突终态不通过。官方 Debugging Events 先要求 Continue，再完成内核退出并等待 Duplicate 句柄 signaled；本次另以官方进程终止与同步对象文档核对该语义。没有证据把注入顺序认定为此受管同线程实现正常 Win32 链上的可达 race，故不据猜测开 P1/P2/P3。将来真实原件若出现该顺序，继续 HOLD 并基于原件修复持续核对；不得放宽一致性。

本人的 Python 验证命令 **6 次**，全部带 `-B`、退出码 **0**。每条均有外层 subprocess timeout，stdout/stderr 原件、实际 argv、逐名库存和 SHA。当前 Python 为 `/opt/homebrew/opt/python@3.15/bin/python3.15`，host 为 Darwin arm64。统一 cwd 为本文所列 checkout；统一环境覆盖 `PYTHONPATH=/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts`、`PYTHONDONTWRITEBYTECODE=1`、`TMPDIR=/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-ssh-lifecycle-review-20261117/runtime-tmp`。

| 实际命令，`python3` 为上列实际解释器 | run | passed | failed | errors | skipped | 外层秒数 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `python3 -B -m unittest -v test_windows_ssh_debug_job` | 45 | 44 | 0 | 0 | 1 | 0.104167 |
| `python3 -B -m unittest -v test_windows_ssh_lab` | 39 | 39 | 0 | 0 | 0 | 0.222287 |
| `python3 -B -m unittest -v test_windows_native_crash` | 72 | 70 | 0 | 0 | 2 | 6.133883 |
| `python3 -B -m unittest -v test_windows_monitor_lab.LifecycleTests` | 9 | 9 | 0 | 0 | 0 | 2.583531 |
| `python3 -B -m unittest -v test_windows_ssh_debug_job.FinishOwnedControls` | 4 | 4 | 0 | 0 | 0 | 0.092432 |
| `python3 -B /Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-ssh-lifecycle-review-20261117/early_signal_controls.py` | 4 | 4 | 0 | 0 | 0 | 0.085633 |
| **本人总计** | **173** | **170** | **0** | **0** | **3** | 各命令单列 |

其中仓库受影响专项为 **169 run / 166 passed / 0 failed / 0 errors / 3 skipped**；reviewer 自备额外控制为 **4 run / 4 passed**。debug 模块的原 45 项与新增 4 项合计覆盖作者最终 49 项，未重复计数。三个跳过项精确为：真实 Windows inherited child debug/ABI、Windows exclusive record handle、Windows native Job admission barrier。其余真实宿主子进程控制属于 Darwin／POSIX 证据，不提升为 Windows 成功。

初轮 `special-r1.json` 的简单行计数漏了两个带 unittest docstring 换行的 passed；原日志和原计数保留。`special-r1-counts-reconciled.json` 对 165 个逐名结果和每套 `Ran` 总数重新核对，确认 **162 passed / 0 failed / 0 errors / 3 skipped**。这是报告解析修正，没有测试失败或测试重跑。最终总数使用该逐名核对结果。

执行回执入口：

- `special-r1.json`、四份 `special-r1-*.log`：初轮实际 argv、退出码、时长与原日志摘要。
- `special-r1-counts-reconciled.json`：初轮精确逐名库存和准确计数。
- `special-delta-r2.json`、`known-fix-delta-r2.log`：已知修复的四项窄复核。
- `early_signal_controls.py`、`early_signal_controls.json`、`early-signal-r2.log`：独立续接控制及实际观察。
- `early-signal-official-receipt.json`：5 次官方 MicrosoftDocs GitHub GET 的 blob、SHA256 与出处；5 份 Markdown 原件同目录保存。
- `source-before-r1.json`、`source-before-delta-r2.json`、`source-final-r3.json`、`source-binding-r4.json`：不同阶段输入身份及候选绑定。
- `review-final-receipt.json`：最终验证计数、报告／日志／通知／源码绑定文件摘要。

父级所报 integrated 271 run / 0 failed / 3 skipped 只作为交接背景，没有计为本人重跑或本次独立证明。本人没有运行 Cargo、全仓门禁、CI 或 Windows native；也没有修改、格式化、提交、推送、切换、清理任何源码／Git 状态／共享 target／他人资源。所有写入均在 `work/windows-ssh-lifecycle-review-20261117/`，临时数据也在此目录。只读导航中缺失的 reviewer 初始目录、无额外 scripts/AGENTS.md 命中，以及首次误将父级 list manifest 当 dict 的回执读取错误，均为非测试诊断失败，不混入 passed/failed；未据此改动工程。

必须保留的原生边界：

- Windows x86/x64/ARM64、WOW64 的真实布局、调用约定、handle 权限与系统自动关闭语义均未执行；宿主结构大小检查不代签。
- 首次 CREATE 停顿的 class60 可用性、实际 OpenSSH token／broker 子链、默认 shell 和四条生产命令的真实路径尚待 Windows 原件。缺失／逃逸／无法解释的外部 broker 继续 HOLD；Job census 只覆盖接纳到的对象，不能证明不存在独立 broker 创建的进程。
- ACTIVE_PROCESS_LIMIT、Job 与 debug event 的并发、真实异常／中断／迟到创建／管道终态均需 native 运行；本机 fault injection 只签代码与证据规则。
- full gate、真实 Windows SSH、原生 GPUI Kit 桌面、安装与发行各自独立，没有合并接纳。

建议父级按当前精确摘要继续 full gate，并在真实 Windows 执行后逐项核对四条固定命令的原对象自然 exit0、完整 OpenSSH 执行链、原集合不变以及最终 Job／event／pipe／handle 收口。当前无需为本次复核新增源码修订。
