"""Reviewer-only observations of the production owner; no native Win32 claims."""

import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "scripts"))

import windows_native_crash as lifecycle
from test_windows_ssh_debug_job import SealAndBudgetControls


OBSERVATIONS = []


class EarlySignalControls(unittest.TestCase):
    def setup_owner(self):
        owner, api, master = SealAndBudgetControls().master()
        child = api.object(pid=42)
        owner.pump_debug(owner._budget)

        def release():
            try:
                owner.close()
            except lifecycle.OwnershipError:
                pass

        self.addCleanup(release)
        return owner, api, master, child

    def observe(self, label, owner):
        value = owner.terminal_evidence()
        OBSERVATIONS.append({
            "case": label,
            "evidence_kind": value["evidence_kind"],
            "child": value["admissions"][1],
            "errors": value["errors"],
            "terminal_proven": value["terminal_proven"],
            "census_complete": value["complete_original_object_census"],
        })
        return value["admissions"][1]

    def test_documented_continue_then_signal_allows_natural_seal(self):
        owner, api, _, child = self.setup_owner()
        api.exit(child, 0)
        owner.pump_debug(owner._budget)
        row = self.observe("EXIT continued, then object signaled", owner)
        self.assertTrue(row["exit_event_continued"])
        self.assertTrue(row["original_signaled"])
        self.assertTrue(row["natural_terminal_before_cleanup"])
        self.assertTrue(owner.seal_admission(
            owner._budget, settle_seconds=0)["admission_closed"])

    def test_synthetic_early_signal_matching_later_exit_stays_non_natural(self):
        owner, api, _, child = self.setup_owner()
        child.signaled, child.exited, child.code = True, True, 0
        first = self.observe("injected early signal, no EXIT event", owner)
        self.assertEqual(first["exit_code"], 0)
        self.assertFalse(first["exit_event_continued"])
        api.exit(child, 0)
        owner.pump_debug(owner._budget)
        row = self.observe("injected early signal, later matching EXIT", owner)
        self.assertTrue(row["exit_event_continued"])
        self.assertFalse(row["natural_terminal_before_cleanup"])
        with self.assertRaisesRegex(
                lifecycle.OwnershipError, "non_master_natural_settle_expired"):
            owner.seal_admission(owner._budget, settle_seconds=0)

    def test_synthetic_early_signal_mismatching_later_exit_does_not_pass(self):
        owner, api, _, child = self.setup_owner()
        child.signaled, child.exited, child.code = True, True, 7
        self.observe("injected early signal caches exit 7", owner)
        api.exit(child, 0)
        owner.pump_debug(owner._budget)
        row = self.observe("injected cached exit 7, later EXIT 0", owner)
        self.assertEqual(row["exit_code"], 7)
        self.assertEqual(row["exit_event_code"], 0)
        self.assertFalse(row["natural_terminal_before_cleanup"])
        self.assertFalse(owner.terminal_evidence()["terminal_proven"])
        with self.assertRaises(lifecycle.OwnershipError):
            owner.seal_admission(owner._budget, settle_seconds=0)

    def test_normal_exit_mismatch_records_error_after_continue(self):
        owner, api, _, child = self.setup_owner()
        api.exit(child, 0)
        child.code = 7
        with self.assertRaisesRegex(
                lifecycle.OwnershipError, "exit_code_disagrees_with_original"):
            owner.pump_debug(owner._budget)
        row = self.observe("normal EXIT 0, retained object exit 7", owner)
        self.assertFalse(row["natural_terminal_before_cleanup"])
        self.assertFalse(owner.terminal_evidence()["terminal_proven"])


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(EarlySignalControls)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    output = Path(__file__).with_suffix(".json")
    output.write_text(json.dumps({
        "native_windows_acceptance": False,
        "early_signal_is_synthetic_not_a_proven_Win32_interleaving": True,
        "observations": OBSERVATIONS,
        "run": result.testsRun,
        "passed": result.testsRun - len(result.failures) - len(result.errors)
                  - len(result.skipped),
        "failed": len(result.failures),
        "errors": len(result.errors),
        "skipped": len(result.skipped),
    }, ensure_ascii=False, indent=2) + "\n")
    raise SystemExit(not result.wasSuccessful())
