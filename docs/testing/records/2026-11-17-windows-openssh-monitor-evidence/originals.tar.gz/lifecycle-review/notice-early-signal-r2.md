**专项通知：`_refresh_original` 早退的定级 — 2026-11-17**

结论：没有确认新的 P0/P1/P2/P3 缺陷；不阻塞本候选的限定源审批准。所测“先 original signaled，再收到／Continue EXIT”的顺序来自离线边界注入，尚无证据说明它是本实现正常受管 Win32 调试链的可达顺序。若要改进该注入状态下的可恢复性，可作为 P3 级防御性加固建议；本报告不将其计作已证实的平台缺陷。

代码事实在 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/debug_job.py:632`：一旦 `row.exit_code` 已记录，后续刷新早退。注入 early signal 后再投递匹配的 EXIT，`exit_continued` 会变成 true，`natural_terminal_before_cleanup` 仍为 false。投递不匹配的 EXIT，则不会再增加 `debug_exit_code_disagrees_with_original` 诊断。这个代码事实已独立复现，没有以测试缺失代替运行证据。

证据规则仍然拒绝上述注入状态：自然 seal 不通过；终态聚合还在 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/debug_job.py:873` 比较原退出码和 EXIT 退出码，因此不匹配者不能成为 `terminal_proven`。SSH 层也要求非 master 的 natural 为 true。

定级所依据的官方语义：

- 已有官方 `github-debugging-events.md:24` 说明，EXIT 必须 Continue，内核侧退出才能完成，并给出 Duplicate → Continue → 等待复制句柄 signaled 的证明步骤。
- 本复核 GET 的 `terminating-a-process.md:24` 说明 process object 在进程终止时变为 signaled。
- `terminate-process-api.md:91` 说明外部 TerminateProcess 是异步请求，必须等待进程句柄确认终止；不能把返回成功当作已经 signaled。
- 本实现 `_continue_pending` 在成功 Continue 后先设置 `exit_continued`，再刷新原对象；正常刷新又由创建线程执行。官方语义与该顺序不支持将离线 early-signal 注入直接认作真实 Windows race。

官方 GET 原件及 Git blob/SHA256 在 `early-signal-official-receipt.json`。独立续接控制在 `early_signal_controls.py`、`early_signal_controls.json`、`early-signal-r2.log`，实际 **4 run / 4 passed / 0 failed / 0 errors / 0 skipped**。四项分别是正常 Continue→signal、注入 early signal 后匹配 EXIT、注入 early signal 后冲突 EXIT、正常顺序下的退出码冲突。全部调用生产 owner；不是另一套 admission 实现，也不是 Win32 模拟验收。

真实 Windows 后续若出现该顺序，应保留事件、原句柄、Continue 结果和对象状态原件，继续 HOLD，再按实际可达时序修正持续核对；不能为了取得 PASS 放宽 natural 或退出码一致性规则。源码未修改。

通知通道记录：向父 chat 的 `send_message_to_thread` 调用被工具以 native ancestor 限制拒绝，未发送消息；本通知保存在授权 reviewer 目录，并已在 commentary 给出结论。未使用其他服务绕过该限制。
