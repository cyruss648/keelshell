# Windows OpenSSH Rust 集成测试作者交接 — 2026-11-17

结论：指定测试文件已新增并完成自身静态检查，尚未编译、运行 Rust 测试或进行真实 Windows 验收。没有提交、推送、创建 chat/worktree 或运行 Cargo；没有修改其他生产源码、现有测试、依赖、workflow 或 docs。共享 checkout 中父作者／debug 作者的改动保留。

## 精确写集与入口

- 唯一源码写集：`crates/keelshell-session/tests/windows_openssh_monitor.rs`。
- 作者记录仅在本目录：本文件、`static-check-r1.json`、`static-check-r2.json`。
- 初始 HEAD 与指定基线均为 `bfbea7bcc84ff433d28a635e85daed9cca337fb0`。
- 测试文件 SHA-256：`883694c29ad190aef7c8097b7d674a6d81fd02d0729fe3b873b31ddba3f00424`。
- integration test target：`windows_openssh_monitor`。
- 唯一测试名：`actual_windows_openssh_monitor_matches_owned_fixture`。
- 测试显式 `#[ignore]`，使用 current-thread Tokio runtime。非 Windows 显式返回 `WindowsRequired`；Windows 缺少输入显式返回配置错误。
- 已读取 AGENTS、HANDOFF、ROADMAP、RTK 和 Rust best practices 第 1、2、4、5、8 章；本任务的禁止构建／Git 写边界优先，不运行 skill 提议的 Cargo gate。

父编排执行已编译二进制的入口：

```text
<windows_openssh_monitor test binary> actual_windows_openssh_monitor_matches_owned_fixture --ignored --exact --test-threads=1 --nocapture
```

## 私有输入合同

`KEELSHELL_WINDOWS_SSH_LAB` 是配置 JSON 的绝对本地盘路径。顶层字段严格为：

| 字段 | 约束 |
| --- | --- |
| `schema` | 整数 `1` |
| `host` | 精确 `127.0.0.1` |
| `port` | `u16`，且 `49152..=65535` |
| `username` | 非空、无控制字符、无首尾空白，与 runner 的 `USERNAME` 或 `USERDOMAIN\USERNAME` 忽略 ASCII 大小写相同；父仍负责 Win32 token 身份证明 |
| `private_key` | 绝对本地盘路径，canonical 后位于 runner `temp_dir()`，普通文件；OpenSSH 格式、无密码、Ed25519 |
| `host_fingerprint` | `SHA256:` 加规范无 padding Base64，精确 32 字节 digest |
| `fixture` | 直接嵌入 `owned_fixture.py` 的完整 ready 对象，不是文件路径 |
| `output_path` | 已存在父目录下的新绝对本地盘 `.json` 文件；允许父证据目录，不要求放在临时凭据目录 |

配置也必须 canonical 后位于 runner `temp_dir()`，读取限 32 KiB；私钥读取限 16 KiB。配置、fixture、endpoint 的额外字段和重复字段由直接 typed serde 反序列化拒绝。路径拒绝相对路径、UNC／设备路径、父目录 traversal、控制字符、ADS；输出通过 `create_new(true)` 预留，不能覆盖任何现有文件。

`fixture` 严格字段为 `version`, `pid`, `endpoints`, `connected_only`。每行严格字段为 `protocol`, `address`, `port`, `pid`；PID 主字段是数值，行 PID／port 是规范十进制字符串。验证 version 1、PID 非零、4 条 tcp/udp × IPv4/IPv6 loopback 正控、2 条双栈 TCP connected-only 反控、PID 一致、所有行唯一且正反控不重叠。原进程身份仍由父保留的进程对象验证。

配置不实现 Debug／Serialize。错误仅包含固定标签／I/O error kind；不打印 serde 错误、SSH credential 原始错误、私钥路径／内容或任意环境。配置／私钥输入 buffer 使用 `Zeroizing`。

## 父编排可直接读取的报告字段

成功时顶层 `schema: 1`、`status: "PASS"`；失败为 `"FAIL"`，返回非零测试结果。三个 `windows_*` 是 data 对象，未包装 wire frame：

| 报告字段 | 精确 data 字段 |
| --- | --- |
| `windows_resources` | `boot_time`, `uptime_seconds`, `cpu_percent`, `memory_total_bytes`, `memory_free_bytes`, `network_count`, `networks`, `capacity_status`, `filesystem_count`, `filesystems` |
| `windows_resources.networks[]` | `name`, `received_bytes`, `transmitted_bytes` |
| `windows_resources.filesystems[]` | `source`, `mount`, `total_bytes`, `total_free_bytes`, `available_bytes` |
| `windows_processes` | `count`, `processes` |
| `windows_processes.processes[]` | `pid`, `name`, `working_set_bytes` |
| `windows_sockets` | `count`, `sockets` |
| `windows_sockets.sockets[]` | `protocol`, `address`, `port`, `pid` |

counter／PID／port 按现有 oracle 合同输出十进制字符串；count 是 JSON 整数，uptime／CPU 是 JSON 数值，未知 CPU／工作集仍为 null。缺失观测阶段输出对应顶层 null，不拼装空数据来冒充已采集。

`identity` 独立提供 `platform`, `runtime`, `runtime_version`, `source`。成功 runtime 为 `WindowsPowerShell`，版本字符串来自 capability 中独立 production probe 的 `[major, minor, build, revision]`，要求前两段为 5.1。不从本机环境、资源内容或固定常量填入实际版本。

来源和转换已保存在 `data_provenance`：

- `boot_time` 直接来自 `Snapshot.boot_time`，是生产 CIM Unix boot estimate。
- `memory_free_bytes` 直接来自 `Snapshot.memory.free_bytes`；不以 available／used 替换。
- `total_free_bytes` 是 checked `total_bytes - used_bytes`，与生产 parser 的 `used = total - total_free` 精确互逆；同时检查 available／total／used_percent 关系。
- `capacity_status` 来自首次 snapshot 后的 filesystem capability。未知状态不会伪装成 skipped；PASS 要求实际 Available，映射为 `"ok"`。
- 进程 `name` 来自 `ProcessInfo.command`，Windows 此字段是 ProcessName，不是命令行。
- socket owner 从实际 `SocketInfo.process` 的规范 `pid=` 字段读取；缺失则失败，不能补 PID 0。地址从实际 numeric `local` 去掉 IPv6 方括号，保留 scope；无额外 exec。

因此父不需要改动现有三个 oracle 的 data 合同，可直接调用：

```python
for operation in ("resources", "processes", "sockets"):
    lab.validate_data(operation, report["windows_" + operation])
lab.compare_resources(report["windows_resources"], before, after, cpu_before, cpu_after)
lab.compare_owned(owned, report["windows_processes"], report["windows_sockets"],
                  native_process, native_sockets)
runtime_version = report["identity"]["runtime_version"]
```

其他 evidence 字段：

- `test`, `expected_identity`, `stage`, `stage_evidence`, `assertion_evidence[]`（实际 bool 与阶段）、`errors[]`（失败原阶段和脱敏错误）。
- `fixture` 是已验证 ready 对象，不含凭据。
- `sample_semantics` 保存 CPU gauge／unknown、memory available／used／swap、load、disk I/O 和不生成 network／disk／iowait rates 的实际语义。
- `capabilities` 是采集后的最后观测；`authority[]` 单列 pause／reset 后的状态和报告权威，reset 后 Unknown 不覆盖先前采集证据。
- `api_calls` 仅为本测试发起的 API 调用，三个值各 1；不是 exec 数量证明。
- `disconnect` 保存 request 是否成功、`is_closed()` 是否观察到本地关闭及公开 connection state。
- `independent_oracle_status: "NOT_RUN_BY_RUST"`，`elapsed_seconds`, `budget_seconds: 90`。

## 真实采集与撤权边界

先用同一配置／key／fixture 将 digest 一字节变更为另一个规范指纹，要求精确 `SessionError::ChangedHostKey`，且 actual 等于父给定的固定 host pin，不接受任意 transport／auth 失败代替。没有返回 authenticated session；父仍核对 server auth 及原进程。

随后只进行一次实际认证连接、一次 `snapshot()`、一次 `processes()`、一次 `listening_sockets()`。Windows 身份探测和所有远端命令均由 `LinuxMonitor` 生产公开路由自行发出。预期父看到 4 个固定 PowerShell 命令：probe/resources/processes/sockets；另有生产路由原有 POSIX identity selector。测试不直接调用 exec，不增加 raw capture、uname、whoami、主动 TCP 探测、进程 inspect／signal 或自定义命令。

资源与进程 unknown 字段、可用能力／观测时间、fixture PID／真实正工作集、全部 4 个监听／UDP 绑定和 2 个 connected-only 端点排除都由 typed assertion 实际检查。所有 TCP 必须 LISTEN，UDP 必须 BOUND，peer 为生产未知标记 `*`。

缓存阶段只读取 capabilities／capability_report、核对 clone 的公开权威与 checked_at 完全相等，然后执行 invalidate／clone revoke／reset 并核对旧报告失效、完成观测保留／reset 归 Unknown。之后不再次调用 collector；不把 invalidate 误解为永久禁止新采集。revision 数值是私有 API，不编造；原 exec 数量和自然 exit0 由父 debug owner 证明。

## 预算、失败报告与清理

唯一原始 monotonic deadline 为测试开始后 90 秒，外层 `timeout_at` 覆盖全部工作。采集最多到第 78 秒，给 disconnect／本地关闭观察留到第 88 秒，给报告 write／flush／sync 留到第 90 秒；不续约。

session／output owner 留在可取消 observe future 外。采集和 typed assertion 失败／超时之后仍尝试 `close()`，同时用公开本地 `is_closed()` 观察完成。close 错误和关闭等待超时均计入失败，即使随后关闭也不擦掉原错误。意外认证成功的错误指纹负控也进入同一清理路径。测试不使用会在持有连接时 panic 的 assert／unwrap／expect。

若已安全预留报告，会在采集／断开失败后写 FAIL，保留原失败阶段。非 Windows、缺 env、严格 JSON 解析失败或不安全输出路径不能取得报告位置，因此这些前置错误仅返回脱敏 typed error。报告写入／flush／sync 错误也导致非零；父必须同时要求测试进程 exit0 和报告 PASS，不能仅以残留文件状态验收。外部原进程／fixture／sshd 清理仍属父。

## 自身验证和未验证边界

`static-check-r2.json`：35 项静态检查通过，0 失败，绑定上述精确源码哈希。包括：

- 独立单文件 `rustfmt --edition 2024 --check` 退出 0；此前只格式化本新增文件。
- 与 Python `validate_data` AST 中现有字段集合逐项对照（resources／network／filesystem／process／socket）。
- 采集 API 各一个调用点、两个 connect 调用点、无额外 remote／active API 或 child／controlled server。
- strict 配置、错误拒绝、绝对预算、错误后清理、create-new 报告、敏感数据不序列化、无 panic／unwrap。
- Git no-index whitespace diagnostics 为空，独立 whitespace／EOF 检查通过。

`static-check-r1.json` 原 FAIL 保留：检查器把新文件 `git diff --no-index --check` 的差异退出码 1 误判为失败；r2 修正验证器解释，保留原退出码／空 stdout、stderr，并另查行末空白。两轮间源码未变。不是修复／隐藏 Rust 编译失败。

Cargo 执行 0、编译／Rust tests／真实 Windows SSH 执行均 0、Clippy／完整 gate／原生验收均未做。静态词法／schema 对照不代替 Rust 类型检查、测试执行、独立 Win32 oracle、debug 原进程终态或全产品验收。父持有唯一 target，应由父完成后续编译／检查／真实 Windows 运行。
