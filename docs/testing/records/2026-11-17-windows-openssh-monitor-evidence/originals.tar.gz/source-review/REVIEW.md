**独立审查结论：限定 source APPROVE。P0＝0、P1＝0、P2＝0、P3＝0。**

审查日期：2026-11-17，Asia/Shanghai。审查期间 HEAD 一直为基线
`bfbea7bcc84ff433d28a635e85daed9cca337fb0`。审查对象是下列六个文件的未提交候选内容；
本结论绑定其 SHA-256，不能只凭基线 HEAD 复用。审查者未参与这些文件的实现。

未发现本写集中可以确认的正确性、安全、异常清理或报告契约缺陷，因此没有需要列出触发条件、
影响与修复建议的 P0–P3 发现。建议父接受本写集的源码审查；最终完整工程门禁和真实
Windows 执行仍由父完成。该结论不签署 debug_job.py 作者写集，也不签署 Windows 验收。

**范围、版本和只读边界**

已先读 AGENTS.md、`/Users/hdh/.codex/RTK.md`、docs/HANDOFF.md、ADR0157，
并读取共享 target 合同及 Rust best-practices 的错误处理／测试章节。
windows_monitor_lab.py 仅审查 `OwnedChild.start(environment=None)` 的显式环境小改，
其余部分作为现有 oracle／生命周期接口读取。

| 文件 | 字节数 | 审查 SHA-256 |
| --- | ---: | --- |
| crates/keelshell-session/tests/windows_openssh_monitor.rs | 45577 | `883694c29ad190aef7c8097b7d674a6d81fd02d0729fe3b873b31ddba3f00424` |
| scripts/windows_monitor/ssh.py | 27248 | `d0684ffd9c6f8dd6fb614fcd2315ab0cab8f19cdac5770ee25dfaaa62b98f421` |
| scripts/windows_monitor_ssh.py | 727 | `48d0e9293250dcb8da19aebf378a49dfb138f2213b99ad90cda464c68ddd21ea` |
| scripts/test_windows_ssh_lab.py | 19956 | `101932df1678c492069f1236282f0252d183aebbad947eaf6009c22a7848c855` |
| .github/workflows/windows-monitor-ssh.yml | 2539 | `65d7aa9b16fca91533b23b25ac68234d5bba553b3dd0d8ea5dd91631109197a9` |
| scripts/windows_monitor_lab.py | 66899 | `22f349d06996f61a78dc19b7a9f355ad36704b62e45e8a4bafa4a24374a9bafa` |

六文件开始／结束摘要一致，并与父 review-candidate-r1.json 的 10 文件候选摘要逐项相等。
审查者另以只读方式重列、读取并散列父候选的全部 765 个工程输入，完整列表及 aggregate
与 candidate-inputs-r1.json 一致：
`71872297a9a7b067fd85723de4e5c9c10f908dcc6a7e63ab91eeed6cb902db3a`。
最后绑定时间为 `2026-11-17T00:27:36.101283+00:00`。
765 项是来源完整性绑定数量，不是额外代码审查或测试数量。

审查者写入均在本报告目录内。Cargo 调用 0、Rust 测试执行 0、Git mutation 0、
新建 worktree 0、共享 target 写入 0；未运行清理命令。Python 专项的临时测试数据被限制在
本目录 check-temporary/；TemporaryDirectory 按专项自身的正常退出路径收口。
未修改源码、文档交接、依赖或父作者原始回执。

**审查依据与精确位置**

下表是已核对的实现依据，不是缺陷清单。路径全部指向本次实际审查的工作区。

| 关注点 | 绝对路径与行号 | 观察 |
| --- | --- | --- |
| wrong-pin fail closed | [windows_openssh_monitor.rs:547](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/windows_openssh_monitor.rs:547) | 变更 digest 一字节；要求精确 ChangedHostKey，expected 等于错误 pin、actual 等于父固定 pin。意外认证成功保留 session 后转入同一 disconnect。结合生产 check_server_key 在认证前拒绝变化 pin 的调用顺序阅读。 |
| 真实公开 API 与生产路由 | [windows_openssh_monitor.rs:902](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/windows_openssh_monitor.rs:902)、[windows_openssh_monitor.rs:1041](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/windows_openssh_monitor.rs:1041) | 负控之后调用公开 SshSession::connect；snapshot／processes／listening_sockets 各一个实际调用点，无测试注入 collector、直接 exec 或本批主动诊断。 |
| 报告字段与单位 | [windows_openssh_monitor.rs:641](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/windows_openssh_monitor.rs:641)、[ssh.py:212](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/ssh.py:212) | data 对象交给现有 validate_data；字节／PID／port 为规范十进制字符串，count 为整数，未知 CPU／working set 保留 null。total_free 是 checked total−used，未替换 available/free；socket 从实际公开结果还原 owner 和地址。 |
| 未知值、缓存与撤权 | [windows_openssh_monitor.rs:762](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/windows_openssh_monitor.rs:762)、[windows_openssh_monitor.rs:823](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/windows_openssh_monitor.rs:823) | 检查 CPU gauge／缺失字段，clone 的观测和 checked_at 相等，pause／再次撤权使旧报告失效，reset 回到 Unknown。未把 invalidate 当永久禁止新工作，也未用自报 API 计数代替 exec 原对象计数。 |
| 预算与连接清理 | [windows_openssh_monitor.rs:1077](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/windows_openssh_monitor.rs:1077)、[windows_openssh_monitor.rs:1136](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/windows_openssh_monitor.rs:1136)、[ssh.py:287](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/ssh.py:287) | Rust 90 秒绝对预算，采集截止 78 秒，断开截止 88 秒，报告截止 90 秒。session/output owner 位于可取消 observation 外；close 请求与本地 is_closed 分开检查。父子 Budget 以同一外层 end 为上限，drain 执行子预算检查。 |
| fixture 与独立 oracle | [ssh.py:405](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/ssh.py:405)、[ssh.py:445](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/ssh.py:445) | 父先取得 retained fixture 的 ready 对象，再要求 Rust 回报完全相等。process/socket 比较使用独立 Win32 结果；资源由 oracle 独立枚举并前后采样，稳定漏项失败、变化／不完整 HOLD。Rust 正控逐个检查 4 端点，反控检查 2 个 connected-only 端点。 |
| 生产命令原对象终态 | [ssh.py:298](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/ssh.py:298)、[ssh.py:459](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/ssh.py:459) | 消费 debug 接口的完整 census、关闭接纳、身份绑定、首次 Continue 前保留、自然终态；将实际 PowerShell image 和 argv 与当前生产装配逐字节对应，要求 probe/resources/processes/sockets 各一且 exit0。其他非 master 也必须自然终止。 |
| 清理失败证据 | [ssh.py:263](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/ssh.py:263)、[ssh.py:464](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/ssh.py:464) | 已纳入父通知的内层 try/finally：keep_child 异常仍尝试保存 ssh-debug-cleanup.json。成功路径核对清理前后 PID＋creation_time 集合一致、非 master 自然终态及最终句柄／对象为零；fixture 位于最外层 finally。 |
| 私有材料与上传范围 | [ssh.py:165](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/ssh.py:165)、[ssh.py:415](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/ssh.py:415)、[windows_openssh_monitor.rs:459](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/windows_openssh_monitor.rs:459)、[windows-monitor-ssh.yml:47](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/.github/workflows/windows-monitor-ssh.yml:47) | 私钥／client.json 放在私有 TemporaryDirectory；workflow 上传限定 Evidence 输出目录。Rust 不 Debug/Serialize 配置，敏感输入 buffer 使用 Zeroizing，错误使用固定标签，输出 create_new。Windows 实际 DACL、路径隔离和删除结果仍需原生回执。 |
| source 与测试库存 | [ssh.py:124](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/ssh.py:124)、[ssh.py:152](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/ssh.py:152)、[ssh.py:366](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/ssh.py:366)、[windows-monitor-ssh.yml:26](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/.github/workflows/windows-monitor-ssh.yml:26) | workflow 从本次 Cargo JSON 选择唯一 exact test target executable；父校验 native 文件外形、独立 --list 精确用例存在一次、记录 binary SHA256，再 exact 运行并同时要求 exit0、harness 单项成功和结构化 PASS。source 必须为精确 HEAD 且工程输入干净。本地现有 inventory 单名与源码单名一致；没有 Windows 编译原件可签。 |
| 显式 environment 小改 | [windows_monitor_lab.py:321](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor_lab.py:321) | None 延续继承语义，显式 mapping 先复制，再传 owner.spawn，不修改父进程环境。独立运行的专项含实际宿主 child 控制。 |
| CI 非零 HOLD | [ssh.py:492](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/ssh.py:492)、[windows-monitor-ssh.yml:41](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/.github/workflows/windows-monitor-ssh.yml:41) | Hold 返回 78，普通失败返回 1；终态失败将结果改为 FAIL。workflow 直接 exit LASTEXITCODE，未设置 continue-on-error；always 上传供复核，缺少条件不能成为绿色成功。 |

**审查者实际执行**

| 验证 | 实际数量／结果 | 原件 |
| --- | --- | --- |
| 父专项 r1 | 39 run，39 passed，0 failed，0 skipped；exit0；外层 0.272184625s | parent-unit.json、parent-unit.stderr.log |
| 父专项 r2 | 同样 39 run 全通过；exit0；外层 0.230634250s；输入前后哈希相等 | parent-unit-r2.json、parent-unit-r2.stderr.log |
| 父编排异常控制 | 2 cases，2 passed，0 failed | cleanup-controls.json、cleanup-control-hold/、cleanup-control-close-error/ |
| 静态契约检查 | 14 checks，14 passed，0 failed | source-contract-checks.json |
| 静态库存／父原件摘要回读 | 12 checks，12 passed，0 failed | static-and-original-readback.json |
| 稳定候选绑定 | 765 工程输入完整相等，六审查文件分别匹配 10 文件候选清单 | candidate-binding.json |

r2 的原因是审查期间 Aquinas 更新了不属于本写集的 windows_native_crash.py 生命周期接口，
故重跑父专项确认当前调用兼容；没有扩大为该实现的独立源码批准。
39 是唯一 unittest 数量；两轮合计 78 次用例执行，不能称 78 个不同测试。
14／12 项是静态和完整性检查，不混入行为测试数量。

两次 unittest 的实际子命令均为：

```text
/opt/homebrew/opt/python@3.15/bin/python3.15 -B -m unittest discover -s scripts -p test_windows_ssh_lab.py -v
```

宿主为 macOS 27.2.1 arm64，Python 3.15.2。启动器为 `python3 -B - <<'PY'`，
使用 subprocess.run(capture_output=True, timeout=50)，显式设置 PYTHONDONTWRITEBYTECODE=1，
TMPDIR／TEMP／TMP 均指向本目录 check-temporary/。详细 argv、cwd、环境覆盖、耗时、
stdout/stderr SHA-256 保存在各轮 JSON 中。专项包含真实宿主子进程显式环境检查，
以及非 Windows CLI 返回 78／HOLD 且 children 为空的检查。

另外三次 `python3 -B - <<'PY'` 内联检查分别执行源码契约检查、已有原件摘要／库存回读、
以及父编排故障控制；对应 JSON 保留各条件、实际计数和结果。最后另一次内联只读命令用
`git --no-optional-locks ls-files --cached --others --exclude-standard -z` 重列工程输入，
依父规则排除 docs/ 和 .hallmark/，散列各文件并复算 path＋NUL＋SHA256＋换行的 aggregate。

故障控制只替换进程／Win32 依赖，不启动 Windows 或 SSH：
一例在 oracle 阶段刻意抛 Hold，结果 78／HOLD；另一例使 owned-sshd 的 keep_child
刻意抛 LabError，结果 1／FAIL。两例均保留 OFFLINE_CONTROL_NOT_NATIVE
调试清理原件、尝试 fixture 清理、记录临时目录已删除。它们仅证明 Python finally 路由，
不证明真实 owner.close、Windows 句柄或原进程终态。

**只读取的父原件**

已分别复算以下原日志字节数与 SHA-256，均与父 JSON 回执一致。
没有把它们计作本审查者重新编译、重新运行或原生验收。

| 父原件 | 原始结果 |
| --- | --- |
| windows-ssh-rust-inventory-r1 | exit0；日志列出精确测试名一次，1 test／0 benchmarks；属于库存枚举，没有执行测试 |
| windows-ssh-rust-clippy-r1 | exit0；本机既有 Clippy 回执 |
| windows-ssh-rust-nonwindows-r1 | exit101；原日志为 0 passed／1 failed，错误 WindowsRequired；是父刻意运行的非 Windows 拒绝边界，原失败保留 |
| windows-ssh-python-integration-r1 | exit0／reaped；外层 8.922646375s；271 run＝268 passed＋3 skipped，0 failed；这是父运行的全部 test_windows_*.py |

上述原件位于
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-ssh-integration-20261117/`。
最后一项命令为 `python3 -B -m unittest discover -s scripts -p test_windows_*.py -v`。
其日志 SHA-256：
`8216337fcddc8a77000880a586a30051c46e266523dd0d2b51655862a2801b09`。

**未签署边界和后续**

debug_job.py、windows_native_crash.py 及 test_windows_ssh_debug_job.py 仅作为调用／证据接口读取，
由其作者和另一独立审查负责；本报告不替其源码签字。接口收尾状态由父提供，本报告实际观察到
父专项在最终接口哈希 `702e2214d6772bbd1841135ba17e30c57053f7165099206448451f19068ad0a4`
下通过，且运行前后输入一致。

Windows 原生 ABI、真实 OpenSSH 公钥认证／默认 shell、token/broker 执行链是否被完整接纳、
独立 Win32 读数、真实自然 exit0、Job 终态／实际句柄关闭、ACL／私钥删除和实际 artifact 内容，
均未由审查者执行。765 输入绑定和本机库存不代替 Windows 编译产物来源及真实执行证据。
最终 full gate、精确提交 Windows CI、原生 GUI、发布和安装也均不在本结论内。

父可以继续冻结后的最终完整门禁与真实 Windows 验收；本报告不要求等待其他审查后才接受
本六文件写集的 source approve。任一审查文件摘要变化时，应先对变化部分重新复核。
