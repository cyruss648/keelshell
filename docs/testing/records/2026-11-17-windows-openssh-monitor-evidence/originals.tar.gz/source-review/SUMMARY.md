**限定源码审查 APPROVE：P0＝0、P1＝0、P2＝0、P3＝0。**

基线 `bfbea7bcc84ff433d28a635e85daed9cca337fb0`。
六个指定文件摘要在审查期间未变，且分别匹配父的 10 文件稳定候选清单。
只读复算 765 个工程输入与父冻结完全一致，aggregate：
`71872297a9a7b067fd85723de4e5c9c10f908dcc6a7e63ab91eeed6cb902db3a`。

- 审查者实际父专项：39 个唯一 unittest 全通过；因共享生命周期接口收尾更新，重跑一次仍全通过。两轮共 78 次执行，各 0 failed／0 skipped。
- 审查者补充：两个 Python 父编排故障控制均通过；14 项静态契约检查、12 项静态／原件完整性检查均通过，分开计数。
- 父原件回读：已有 Rust 库存、Clippy、非 Windows 拒绝原日志均与其回执摘要一致；父整合专项 271 run＝268 passed＋3 skipped，exit0／reaped。均不计作本审查者重跑。
- 审查者 Cargo／Rust tests／真实 Windows 执行均为 0；没有 Git mutation、源码修改、worktree 创建、清理命令或共享 target 写入。
- debug_job.py 及 Aquinas 的其他写集仅按接口读取，不代签其源码。full gate、Windows ABI／真实 SSH／Win32／进程原对象终态及原生 GUI／发行继续由父单独完成。

完整绝对路径行号、检查命令、source SHA-256、实际计数和边界见
[REVIEW.md](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-ssh-source-review-20261117/REVIEW.md)；
机器摘要为 summary.json，冻结绑定为 candidate-binding.json。
