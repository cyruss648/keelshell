"""Independent read-only fault controls. These are NOT native Windows acceptance."""
from contextlib import contextmanager
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re
import sys
import unittest
from unittest import mock
import zipfile

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "scripts"))
import test_windows_ssh_debug_job as boundary
import test_windows_ssh_lab as fixtures
from windows_monitor import debug_job as debug, ssh
import windows_monitor_lab as lab
import windows_native_crash as lifecycle

ORIGINALS = ROOT / "work/windows-ssh-ci-originals-20261117/openssh-r1"
ARTIFACT = ORIGINALS / "artifact-14287312342"
AGGREGATE = "fb78496b8d0b22bd6fc38da46df994d16c144d1f040f83ff468a98c49ff633af"


@contextmanager
def master_owner():
    owner, api = boundary.fixture()
    master = api.object(pid=41)
    owner.process = type("RootIdentity", (), {"pid": master.pid})()
    owner.pump_debug(owner._budget)
    try:
        yield owner, api, master
    finally:
        try:
            owner.close()
        except (lifecycle.OwnershipError, TimeoutError):
            pass  # Expected fault evidence remains sticky; no native objects exist.


class Clock:
    def __init__(self):
        self.now = 1000.0

    def monotonic(self):
        return self.now

    def sleep(self, duration):
        self.now += duration


class IndependentControls(unittest.TestCase):
    def test_frozen_765_inputs_match_exact_aggregate_and_current_bytes(self):
        frozen = json.loads((ROOT / "work/windows-ssh-integration-20261117/repair-candidate-inputs-r1.json").read_bytes())
        rows = frozen["inputs"]
        self.assertEqual((frozen["count"], len(rows)), (765, 765))
        self.assertEqual(len({row["path"] for row in rows}), 765)
        aggregate = hashlib.sha256("".join(
            f"{row['path']}\0{row['sha256']}\n" for row in rows
        ).encode()).hexdigest()
        self.assertEqual(aggregate, AGGREGATE)
        self.assertEqual(frozen["aggregate_sha256"], AGGREGATE)
        for row in rows:
            raw = (ROOT / row["path"]).read_bytes()
            self.assertEqual((len(raw), hashlib.sha256(raw).hexdigest()),
                             (row["bytes"], row["sha256"]), row["path"])

    def test_original_artifact_zip_digest_and_every_extracted_member(self):
        receipt = json.loads((ORIGINALS / "fetch-receipt.json").read_bytes())
        download = next(row for row in receipt["downloads"] if row.get("id") == 14287312342)
        raw = (ORIGINALS / download["zip"]).read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        self.assertEqual((len(raw), digest), (download["bytes"], download["sha256"]))
        self.assertEqual(download["github_digest"], "sha256:" + digest)
        with zipfile.ZipFile(ORIGINALS / download["zip"]) as archive:
            self.assertEqual(set(archive.namelist()), {row["path"] for row in download["members"]})
            for row in download["members"]:
                packed = archive.read(row["path"])
                self.assertEqual(packed, (ARTIFACT / row["path"]).read_bytes())
                self.assertEqual((len(packed), hashlib.sha256(packed).hexdigest()),
                                 (row["bytes"], row["sha256"]))

    def test_persistent_unknown_pid_expires_original_three_second_settle(self):
        clock = Clock()
        with mock.patch.object(debug.time, "monotonic", clock.monotonic), \
                mock.patch.object(debug.time, "sleep", clock.sleep), master_owner() as (owner, api, _):
            api.pids_override = [9999]
            start = clock.now
            with self.assertRaisesRegex(lifecycle.OwnershipError, "census_incomplete"):
                owner.seal_admission(owner._budget, settle_seconds=3)
            self.assertAlmostEqual(clock.now - start, 3.0, places=6)
            self.assertGreater(owner._census_checks, 16)
            self.assertEqual(len(owner._census_observations), 16)
            self.assertFalse(owner.admission_closed or owner.terminal_prepared)
            self.assertFalse(any(call[0] == "job_set" for call in api.calls))
            api.pids_override = None
            self.assertFalse(owner.terminal_evidence()["terminal_proven"])

    def test_persistent_missing_cumulative_admission_cannot_expire_into_success(self):
        clock = Clock()
        with mock.patch.object(debug.time, "monotonic", clock.monotonic), \
                mock.patch.object(debug.time, "sleep", clock.sleep), master_owner() as (owner, api, _):
            api.total_override = 2
            with self.assertRaisesRegex(lifecycle.OwnershipError, "census_incomplete"):
                owner.seal_admission(owner._budget, settle_seconds=3)
            self.assertAlmostEqual(clock.now, 1003.0, places=6)
            self.assertFalse(owner.admission_closed or owner.terminal_prepared)
            self.assertEqual(owner._last_census["admitted"], 1)
            self.assertEqual(owner._last_census["total_after"], 2)

    def test_asynchronous_zero_accounting_never_hides_inconsistent_census(self):
        for before, after, pids in ((1, 0, []), (0, 1, []), (1, 1, []),
                                    (0, 0, [41]), (0, 0, [9999])):
            with self.subTest(before=before, after=after, pids=pids), master_owner() as (owner, _, _):
                owner.seal_admission(owner._budget, settle_seconds=0)
                owner.terminate()
                accounting = owner.accounting
                calls = 0

                def readings(budget):
                    nonlocal calls
                    result = accounting(budget)
                    result.ActiveProcesses = before if calls == 0 else after
                    calls += 1
                    return result

                with mock.patch.object(owner, "accounting", side_effect=readings), \
                        mock.patch.object(owner, "process_ids", return_value=pids):
                    self.assertGreater(owner.active(owner._budget), 0)
                    self.assertFalse(owner._update_evidence()["terminal_proven"])
                self.assertEqual(owner.active(owner._budget), 0)
                self.assertTrue(owner.terminal_evidence()["terminal_proven"])

    def test_sealed_total_before_or_after_change_fails_immediately_and_sticks(self):
        for before, after in ((2, 1), (1, 2), (0, 1), (1, 0)):
            with self.subTest(before=before, after=after), master_owner() as (owner, _, _):
                owner.seal_admission(owner._budget, settle_seconds=0)
                owner.terminate()
                accounting = owner.accounting
                calls = 0

                def readings(budget):
                    nonlocal calls
                    result = accounting(budget)
                    result.TotalProcesses = before if calls == 0 else after
                    calls += 1
                    return result

                with mock.patch.object(owner, "accounting", side_effect=readings):
                    with self.assertRaisesRegex(lifecycle.OwnershipError, "census_incomplete"):
                        owner.active(owner._budget)
                self.assertFalse(owner.terminal_evidence()["terminal_proven"])

    def test_late_admission_in_active_is_bound_retained_and_never_continued(self):
        with master_owner() as (owner, api, _):
            owner.seal_admission(owner._budget, settle_seconds=0)
            api.object(pid=42)
            with self.assertRaisesRegex(lifecycle.OwnershipError, "creation_after_admission_seal"):
                owner.active(owner._budget)
            self.assertEqual(len(owner.admissions), 2)
            self.assertTrue(owner.admissions[-1]["identity_bound_before_first_continue"])
            self.assertFalse(any(call[:2] == ("continue", 42) for call in api.calls))
            self.assertFalse(owner.terminal_evidence()["terminal_proven"])

    def test_terminal_evidence_stays_strict_during_unsettled_active_read(self):
        with master_owner() as (owner, api, _):
            owner.seal_admission(owner._budget, settle_seconds=0)
            owner.terminate()
            api.active_override = 1
            evidence = owner.terminal_evidence()
            self.assertIn("debug_admissions_job_census_incomplete", evidence["errors"])
            self.assertFalse(evidence["terminal_proven"])
            api.active_override = None
            self.assertFalse(owner.terminal_evidence()["terminal_proven"])

    def test_prepare_terminal_stays_strict_and_does_not_install_barrier(self):
        with master_owner() as (owner, api, _):
            api.active_override = 2
            with self.assertRaisesRegex(lifecycle.OwnershipError, "census_incomplete"):
                owner.prepare_terminal(owner._budget)
            self.assertFalse(owner.admission_closed or owner.terminal_prepared)
            self.assertFalse(any(call[0] == "job_set" for call in api.calls))

    def test_first_sixteen_plus_last_are_bounded_and_deeply_isolated(self):
        with master_owner() as (owner, api, master):
            for number in range(1000):
                api.pids_override = [5000 + number]
                self.assertFalse(owner._census(owner._budget, settling=True))
            self.assertEqual(owner._census_checks, 1000)
            self.assertEqual(len(owner._census_observations), 16)
            self.assertEqual(owner._census_observations[0]["unknown_pids"], [5000])
            self.assertEqual(owner._census_observations[-1]["unknown_pids"], [5015])
            snapshot = owner._update_evidence()
            self.assertEqual(snapshot["last_census_observation"]["unknown_pids"], [5999])
            snapshot["incomplete_census_observations"][0]["current_pids"].clear()
            snapshot["incomplete_census_observations"][0]["unknown_pids"].clear()
            snapshot["last_census_observation"]["current_pids"].clear()
            snapshot["last_census_observation"]["unknown_pids"].clear()
            fresh = owner._update_evidence()
            self.assertEqual(fresh["incomplete_census_observations"][0]["unknown_pids"], [5000])
            self.assertEqual(fresh["last_census_observation"]["current_pids"], [5999])
            api.pids_override = None
            final = owner.terminal_evidence()
            self.assertTrue(final["last_census_observation"]["complete"])
            self.assertEqual(final["last_census_observation"]["current_pids"], [master.pid])
            self.assertEqual(len(final["incomplete_census_observations"]), 16)

    def test_only_ascii_argv0_spaces_are_normalized_and_source_hashes_stay_exact(self):
        for program in ("powershell.exe", '"powershell.exe"', fixtures.PS, '"' + fixtures.PS + '"'):
            for spaces in (1, 2, 8):
                with self.subTest(program=program, spaces=spaces):
                    value = fixtures.snapshot()
                    for row in value["admissions"][1:]:
                        row["command_line"] = program + " " * spaces + row["command_line"].split(" ", 1)[1]
                    result = ssh.validate_powershell_admissions(value, fixtures.commands(), fixtures.PS)
                    for row in result["operations"]:
                        source = fixtures.commands()[row["operation"]]
                        self.assertEqual(row["wire_sha256"], hashlib.sha256(source.encode("ascii")).hexdigest())

    def test_boundary_controls_flags_payload_and_injection_are_rejected(self):
        source = fixtures.snapshot()["admissions"][1]["command_line"]
        arguments = source.split(" ", 1)[1]
        payload = arguments.rsplit(" ", 1)[1]
        changed_payload = ("A" if payload[0] != "A" else "B") + payload[1:]
        changes = ["powershell.exe" + separator + arguments
                   for separator in ("\t", " \t ", "\r\n", "\u00a0", "\u2003", "\0", "")]
        changes += ["powershell.exe  " + arguments.replace(old, new, 1) for old, new in (
            ("-NoLogo -NoProfile", "-NoLogo  -NoProfile"),
            ("-NoLogo", "-nologo"),
            ("-EncodedCommand ", "-EncodedCommand\t"),
            ("-EncodedCommand ", "-Command "),
            (payload, changed_payload),
            (payload, payload[:4] + " " + payload[4:]),
        )]
        changes += ["powershell.exe  " + arguments + suffix
                    for suffix in (" ", "\n", '"', ";exit 0", " & calc.exe", "\0")]
        for changed in changes:
            with self.subTest(case=changes.index(changed)):
                value = fixtures.snapshot()
                value["admissions"][1]["command_line"] = changed
                with self.assertRaises(lab.LabError):
                    ssh.validate_powershell_admissions(value, fixtures.commands(), fixtures.PS)

    def test_real_failed_run_stays_rejected_and_double_space_is_separately_reproducible(self):
        original = json.loads((ARTIFACT / "ssh-debug-cleanup.json").read_bytes())
        receipt = json.loads((ARTIFACT / "receipt.json").read_bytes())
        self.assertEqual(receipt["status"], "FAIL")
        self.assertEqual(len(original["admissions"]), original["job_total_processes"])
        self.assertEqual(len(original["admissions"]), 21)
        self.assertFalse(original["admission_closed"] or original["terminal_proven"])
        self.assertEqual(original["errors"],
                         ["debug_admissions_job_census_incomplete", "direct_termination_failed"])
        with self.assertRaises(lab.Hold):
            ssh.validate_powershell_admissions(original, fixtures.commands(), fixtures.PS)
        powershell = [row for row in original["admissions"] if row["image"].lower() == fixtures.PS.lower()]
        self.assertEqual(len(powershell), 4)
        for row in powershell:
            match = re.fullmatch(r'(powershell\.exe)( +)(-NoLogo .+)', row["command_line"])
            self.assertIsNotNone(match)
            self.assertEqual(len(match[2]), 2)
            self.assertTrue(row["natural_terminal_before_cleanup"])
            self.assertEqual(row["exit_code"], 0)
        # Counterfactual parser-only control: never saved or reported as native PASS.
        parser_only = deepcopy(original)
        parser_only.update(errors=[], complete_original_object_census=True, admission_closed=True)
        checked = ssh.validate_powershell_admissions(parser_only, fixtures.commands(), fixtures.PS)
        self.assertEqual(len(checked["operations"]), 4)


if __name__ == "__main__":
    unittest.main()
