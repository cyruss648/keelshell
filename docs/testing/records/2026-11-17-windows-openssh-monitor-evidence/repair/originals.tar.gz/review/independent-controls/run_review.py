"""Run only the review controls; write receipts and temporary data under this directory."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
BASE = "41671be1a7fdfd96cec3a57f876519aeab2fa0d5"
SCOPE = ["scripts/windows_monitor/debug_job.py", "scripts/windows_monitor/ssh.py",
         "scripts/test_windows_ssh_debug_job.py", "scripts/test_windows_ssh_lab.py"]


def readback():
    frozen = json.loads((ROOT / "work/windows-ssh-integration-20261117/repair-candidate-inputs-r1.json").read_bytes())
    rows = []
    for expected in frozen["inputs"]:
        raw = (ROOT / expected["path"]).read_bytes()
        rows.append({"path": expected["path"], "bytes": len(raw),
                     "sha256": hashlib.sha256(raw).hexdigest()})
    return {
        "head": subprocess.check_output(["git", "--no-optional-locks", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
        "count": len(rows),
        "aggregate": hashlib.sha256("".join(f"{r['path']}\0{r['sha256']}\n" for r in rows).encode()).hexdigest(),
        "drift": [r["path"] for r, expected in zip(rows, frozen["inputs"]) if r != expected],
        "scope": [r for r in rows if r["path"] in SCOPE],
        "tracked_status": subprocess.check_output(
            ["git", "--no-optional-locks", "status", "--porcelain=v1", "--untracked-files=no"],
            cwd=ROOT, text=True).splitlines(),
    }


def main():
    (OUT / "tmp").mkdir(exist_ok=True)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONPATH=str(ROOT / "scripts"),
               TMPDIR=str(OUT / "tmp"), TMP=str(OUT / "tmp"), TEMP=str(OUT / "tmp"))
    receipt = {"captured_utc": datetime.now(timezone.utc).isoformat(),
               "host": sys.platform, "python": sys.version, "evidence_kind": "OFFLINE_REVIEW_NOT_NATIVE",
               "before": readback(), "commands": []}
    commands = [
        ("risk-classes", ["python3", "-B", "-m", "unittest", "-v",
                          "test_windows_ssh_debug_job.SealAndBudgetControls",
                          "test_windows_ssh_lab.AdmissionEvidenceTests"]),
        ("independent", ["python3", "-B", str(OUT / "review_controls.py"), "-v"]),
        ("diff-check", ["git", "--no-pager", "diff", "--check", BASE, "--", *SCOPE]),
    ]
    for name, command in commands:
        start = time.monotonic()
        run = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, timeout=60, check=False)
        (OUT / (name + ".stdout")).write_bytes(run.stdout)
        (OUT / (name + ".stderr")).write_bytes(run.stderr)
        summary = {"name": name, "argv": command, "exit_code": run.returncode,
                   "reaped": True, "elapsed_seconds": time.monotonic() - start}
        text = run.stderr.decode("utf-8", errors="replace")
        count = re.search(r"Ran (\d+) tests? in", text)
        if count:
            summary["run"] = int(count[1])
            summary["skipped"] = len(re.findall(r" \.\.\. skipped ", text))
            summary["failures"] = len(re.findall(r"^FAIL: ", text, re.M))
            summary["errors"] = len(re.findall(r"^ERROR: ", text, re.M))
            summary["passed"] = summary["run"] - summary["skipped"] - summary["failures"] - summary["errors"]
        receipt["commands"].append(summary)
    receipt["after"] = readback()
    receipt["unchanged"] = receipt["before"] == receipt["after"]
    receipt["status"] = "PASS" if (receipt["unchanged"] and not receipt["after"]["drift"]
                                  and all(row["exit_code"] == 0 for row in receipt["commands"])) else "FAIL"
    (OUT / "execution-receipt-r1.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({k: v for k, v in receipt.items() if k not in ("before", "after")}, indent=2))
    return 0 if receipt["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
