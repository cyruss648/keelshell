**Windows 真实 OpenSSH 首轮失败修复：独立只读审查，2026-11-17**

结论为 **LIMITED APPROVE FOR PARENT FINAL FULL GATE**。限定四文件 diff 内未确认可报告缺陷，P0=0、P1=0、P2=0、P3=0；允许父级继续最终 full gate。修复后的真实 Windows OpenSSH 成功仍须后续绑定精确提交的 Windows CI。本报告不改变 run `43990824640` 的 FAIL，也不把原 Quality 或本机离线控制计为修复后的 Windows 验收。

本 reviewer 非作者，独立完成审查，未委派。先读取 AGENTS.md、`/Users/hdh/.codex/RTK.md`、docs/HANDOFF.md。审查只覆盖以下命令的四文件增量；读取相关文件上下文、冻结清单和原 CI 作证据核验。唯一写集为当前审查目录内的报告、独立控制、日志及 notice。未执行 Git mutation、Cargo、整仓重跑、共享 target 操作、chat/worktree 创建或用户 chat 消息工具。

```text
git --no-pager diff --no-ext-diff 41671be1a7fdfd96cec3a57f876519aeab2fa0d5 -- scripts/windows_monitor/debug_job.py scripts/windows_monitor/ssh.py scripts/test_windows_ssh_debug_job.py scripts/test_windows_ssh_lab.py
```

HEAD／基线 source SHA 均为 `41671be1a7fdfd96cec3a57f876519aeab2fa0d5`。修复是该 HEAD 上尚未提交的工作树差异，不能把基线 SHA 当成修复提交。候选完整 765 输入 aggregate 为 `fb78496b8d0b22bd6fc38da46df994d16c144d1f040f83ff468a98c49ff633af`；独立逐项核对大小、SHA-256、聚合算法，测试前后再次读回相等、漂移 0。tracked status 前后相等；已有文档改动保留。

| 限定文件 | 字节 | 当前 SHA-256 |
| --- | ---: | --- |
| scripts/windows_monitor/debug_job.py | 42395 | b59f3b2f8ea50d52161701934efb47329e7c88872b3f9dae3c66ab2eee5aa8e0 |
| scripts/windows_monitor/ssh.py | 27313 | 12d17617a36fba00e4e05a65007b2c2b6672854c5018d7309a68c19cd773e8ea |
| scripts/test_windows_ssh_debug_job.py | 56022 | b579bbb4915d2054989e3414353e8d505bb853525f7d670e92190561f973ff4c |
| scripts/test_windows_ssh_lab.py | 20743 | 2ba0e97cfb1fca2fbe4cd57e893fe9dfbb67bd4c18d1fe04f852a5c793e0bc63 |

风险核查结果如下。表内是通过的约束核验，没有降级为建议后遗留的阻断项。

| 风险 | 当前源码与独立证据 |
| --- | --- |
| 放宽完整 census、漏接纳、未知 PID | [debug_job.py:668](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/debug_job.py:668) 仍要求 before/after 累计 total 均等于全部原对象数、所有对象 bound/member、每个 PID 已知、before/after active 均等于 PID 数。settling 只允许重试，未把不完整读数设为 complete。持续未知 PID 与累计漏接纳两个独立控制都失败退出；恢复后的相等计数不能清除已记录错误。 |
| 重试截止与原预算 | [debug_job.py:743](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/debug_job.py:743) 使用原 `_SharedBudget`、一次计算的 settle end 与 cleanup reserve。[ssh.py:460](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/ssh.py:460) 调用仍为 3 秒。独立确定性时钟使持续不一致恰在 3 秒处失败，未安装 barrier；这是离线控制，不是 Windows 计时测量。 |
| 非 master 自然终态、仅 master active、barrier 双核对 | [debug_job.py:765](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/debug_job.py:765) 仍需 complete 且每个非 master natural、active=1、PID 列表仅 master。[debug_job.py:716](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/debug_job.py:716) 的 prepare_terminal 前后 retain/census、设置与读回 barrier、total 不变检查仍严格。风险专项覆盖 live nonmaster、setter 失败/忽略、seal race。 |
| 封闭后累计 total 变化、迟到接纳 | [debug_job.py:679](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/debug_job.py:679) 对 before 或 after 任一个偏离 sealed total 立即记录错误。独立覆盖 `(2,1)/(1,2)/(0,1)/(1,0)`，active 均立即抛错且错误持续。迟到 CREATE 仍先绑定和保留原对象，再以 admission seal 错误停止，未发首次 Continue。 |
| 异步 kill 的 false zero、旧 complete 缓存 | [debug_job.py:811](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/debug_job.py:811) 每次重新 census，并把 before active、after active、PID 数、pending、连接、pending event 与 `int(not complete)` 一起取 max。五组不一致读数均保持大于零／terminal false，恢复后需新鲜完整读取才能返回零。 |
| 诊断内存与可变快照 | [debug_job.py:686](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/debug_job.py:686) 只保留前 16 个不完整观察和最后观察。[debug_job.py:903](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/debug_job.py:903) 对输出使用 deepcopy。独立注入 1000 次不完整 census，验证保留 16 条、最后观察更新，调用方清空 PID/unknown PID 列表不能修改内部历史。未对 Windows 运行时内存作测量。 |
| PowerShell 参数注入、Base64／固定参数被归一化 | [ssh.py:335](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/ssh.py:335) 只允许 argv0 后 ASCII 空格重复；固定参数和 Base64 仍 fullmatch 并逐字节匹配来源命令。独立覆盖四种 argv0 表示与 1/2/8 空格，wire SHA 仍等于来源命令；19 类控制变更（制表符、Unicode 空白、换行/NUL、flag 大小写/间隔/替换、payload 单字节变化/插空白、尾随内容等）全部拒绝。 |
| 严格 terminal_evidence／prepare_terminal | [debug_job.py:931](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/debug_job.py:931) 与 prepare_terminal 仍使用非 settling census。两个独立控制分别验证不完整读数导致持续 HOLD，以及 prepare_terminal 在安装 barrier 前失败。 |

本 reviewer 在 Darwin／Python 3.15.2 执行两个风险相关测试类和自备控制，合计 **49 run／49 passed／0 failed／0 errors／0 skipped**。13 个自备 unittest 方法包含输入／原件核验及故障控制，方法内参数化组合不膨胀成单独测试数。未调用 NativeWindowsControl，本 reviewer 真实 Windows 执行次数为 0。

| 实际命令 | run / passed / failed / skipped | exit / reaped / 墙钟秒 |
| --- | --- | --- |
| `python3 -B -m unittest -v test_windows_ssh_debug_job.SealAndBudgetControls test_windows_ssh_lab.AdmissionEvidenceTests` | 36 / 36 / 0 / 0 | 0 / true / 0.185917 |
| `python3 -B /Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-ssh-repair-review-20261117/independent-controls/review_controls.py -v` | 13 / 13 / 0 / 0 | 0 / true / 0.261720 |
| `git --no-pager diff --check 41671be1a7fdfd96cec3a57f876519aeab2fa0d5 --` 后接上述四文件 | 不计测试数 | 0 / true / 0.016446 |

可复算入口为 [run_review.py](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-ssh-repair-review-20261117/independent-controls/run_review.py)。cwd 固定为本 checkout；其子命令设置 `PYTHONDONTWRITEBYTECODE=1`、`PYTHONPATH=<checkout>/scripts`，TMPDIR/TMP/TEMP 均指向本审查目录的 independent-controls/tmp。精确 argv、原始测试日志及前后源指纹见 [执行回执](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-ssh-repair-review-20261117/independent-controls/execution-receipt-r1.json)、[风险专项日志](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-ssh-repair-review-20261117/independent-controls/risk-classes.stderr)、[独立控制日志](/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-ssh-repair-review-20261117/independent-controls/independent.stderr)。

父级 repair-windows-integration-r1 单独记为父执行证据：`python3 -B -m unittest discover -s scripts -p test_windows_*.py -v`，observed/controller exit 均 0、direct_reaped=true、active_processes=0、pipes_drained=true、errors=[]，墙钟 8.971764667 秒。读取原 log 独立计数为 **279 run／276 passed／3 skipped／0 failures**；54267 字节和 SHA-256 `15ddfb01d9ff7ff3e2d6e0d072bcb95c067bd9c6446e3b494e42afb9297ed0ea` 均与父回执相等。这些 279 项没有由本 reviewer 重跑，也没有加进独立执行的 49 项。

原 Windows run `43990824640` 的 artifact ZIP 为 29884 字节，SHA-256 `87301385ce6ba76011476175fc566a3cefa6c435ab563c3e781b6c03f9ebbdec`，与 fetch-receipt 中 GitHub digest 相等。独立核对 ZIP 全部 **44 成员**的大小／SHA 与解包目录逐字节相等。本次从本地原件复核，未重新访问 GitHub。

原 Rust client status=PASS，三个 API 各 1 次；最终 21 admitted／job total 21、20 个非 master 自然终态、4 个 PowerShell 自然 exit0。原整体仍 FAIL，cleanup errors 为 `debug_admissions_job_census_incomplete` 和 `direct_termination_failed`；admission_closed=false、terminal_proven=false。最终 pending 对象 0、owned handles 0、debug 连接 0、closed=true 不补足首次 census 证明。原实现没有保存首次坏 census 的 before／IDs／after，精确失败子条件继续 **UNKNOWN**。

四个原 PowerShell 的 argv0 后实际均为双空格，且候选 validator 在保持来源内容精确的 parser-only 控制中接受它们。该控制仅在内存副本上移除生命周期门槛以隔离解析规则，不保存为原 run 成功证据；未改写的原快照仍被候选 validator 拒绝。

最终建议：父级可对上述冻结候选运行最终 full gate。门禁后提交、推送和新的精确 Windows CI 应绑定实际修复提交及工程输入；实际 Win32 census 异步时序、debug ABI、OpenSSH 调试链和真实 Windows cleanup 是否通过均仍待后续 CI。旧 run 与旧 Quality 不替代这一步。未审查四文件增量之外的产品功能、Rust 改动、原生桌面或发行范围。
