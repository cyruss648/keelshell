"""Record final owned artifacts and concurrent path/status changes honestly."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parents[2]
base = root / "work/monitor-stack-ci-20261117"
evidence = root / "docs/testing/records/2026-11-17-monitor-render-stack-evidence/ci-completion"
record_path = "docs/testing/records/2026-11-17-monitor-render-stack.md"
audit_path = "work/monitor-stack-ci-20261117/scope-after-r1.json"
assert not (root / audit_path).exists()
original = json.loads((base / "original-inputs-r1.json").read_text())
for row in original["entries"]:
    raw = (base / row["path"]).read_bytes()
    assert len(raw) == row["bytes"] and hashlib.sha256(raw).hexdigest() == row["sha256"], row["path"]
before = json.loads((base / "scope-before-r1.json").read_text())
protected = []
for row in before["protected_documents"]:
    raw = (root / row["path"]).read_bytes()
    unchanged = len(raw) == row["bytes"] and hashlib.sha256(raw).hexdigest() == row["sha256"]
    protected.append(dict(
        row, unchanged=unchanged, observed_bytes=len(raw),
        observed_sha256=hashlib.sha256(raw).hexdigest(),
    ))
head = subprocess.check_output(
    ["git", "--no-optional-locks", "rev-parse", "HEAD"], cwd=root, text=True, timeout=10,
).strip()
status = subprocess.check_output(
    ["git", "--no-optional-locks", "status", "--porcelain=v1", "--untracked-files=no"],
    cwd=root, text=True, timeout=20,
)


def outside_owned(text):
    return {
        line for line in text.splitlines()
        if line[3:] != record_path
        and not line[3:].startswith(
            "docs/testing/records/2026-11-17-monitor-render-stack-evidence/ci-completion/"
        )
    }


old, new = outside_owned(before["tracked_status"]), outside_owned(status)
checked = subprocess.run(
    ["git", "--no-optional-locks", "diff", "--check", "--", record_path],
    cwd=root, capture_output=True, text=True, timeout=15,
)
assert checked.returncode == 0, (checked.stdout, checked.stderr)
manifest = json.loads((evidence / "manifest.json").read_text())
raw = (evidence / "originals.tar.gz").read_bytes()
assert len(raw) == manifest["archive_bytes"]
assert hashlib.sha256(raw).hexdigest() == manifest["archive_sha256"]
assert (evidence / "verify.py").read_bytes() == (base / "sealed-verifier-r1.py").read_bytes()
original_paths = {row["path"] for row in original["entries"]}
new_files = [
    path for path in base.rglob("*")
    if path.is_file() and path.relative_to(base).as_posix() not in original_paths
]
new_files += sorted(path for path in evidence.iterdir() if path.is_file())
new_files.append(root / record_path)
paths = sorted(path.relative_to(root).as_posix() for path in new_files)
assert audit_path not in paths
rows = []
for path in sorted(new_files):
    raw = path.read_bytes()
    rel = path.relative_to(root).as_posix()
    assert rel.startswith((
        "work/monitor-stack-ci-20261117/",
        "docs/testing/records/2026-11-17-monitor-render-stack-evidence/ci-completion/",
    )) or rel == record_path, rel
    rows.append({"path": rel, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()})
audit = {
    "observed_utc": datetime.now(timezone.utc).isoformat(),
    "head": head, "head_unchanged": head == before["head"],
    "originals_unchanged": len(original["entries"]), "protected_documents": protected,
    "tracked_status": status, "non_owned_tracked_status_unchanged": old == new,
    "concurrent_non_owned_status_added": sorted(new - old),
    "concurrent_non_owned_status_removed": sorted(old - new),
    "concurrent_change_policy": (
        "Keep other authors' status changes; do not certify, modify, or revert those paths."
    ),
    "working_source_contents_certified": False,
    "status_check_limit": (
        "Path/status observations only; no working-source byte equivalence is claimed."
    ),
    "modified_or_added_paths": sorted([*paths, audit_path]),
    "payloads_except_this_self_record": rows,
    "diff_check": {"exit": checked.returncode, "stdout": checked.stdout, "stderr": checked.stderr},
    "original_failures_retained": {"collect-terminal-r1": 1, "collect-terminal-r2": 1},
    "initial_scope_audit_failure_retained": "scope-audit-diagnostic-r1.json",
    "network_requests": 0, "ci_reruns": 0, "tests_replayed": 0, "cargo_commands": 0,
    "target_accesses": 0, "commits": 0, "pushes": 0,
    "own_active_children": 0, "own_watchers_created": 0, "ready_for_parent_collection": True,
}
with (root / audit_path).open("x") as output:
    json.dump(audit, output, indent=2)
    output.write("\n")
print(json.dumps({
    "head": head, "head_unchanged": audit["head_unchanged"],
    "originals_unchanged": len(original["entries"]),
    "protected_documents_unchanged": all(row["unchanged"] for row in protected),
    "modified_or_added_paths": len(audit["modified_or_added_paths"]),
    "concurrent_non_owned_status_added": audit["concurrent_non_owned_status_added"],
    "diff_check_exit": 0, "ready_for_parent_collection": True,
}))
