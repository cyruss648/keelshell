# 监控栈修复精确 CI 终态派生封存报告

结论：完成，待父收取关闭。非当前 Windows 作者独立执行本地派生及封存验证；
只签工程 `bbd4eaccfa8bba2feb487ff43e0423567428bc82` 的
Quality `43955379234`，三平台均 `completed/success`。
已读 AGENTS、RTK、HANDOFF、本批记录及同类 ci-completion 格式。
本地 HEAD 保持 `4209e272260aff6374e6216423ce8e0157bea2f4`。

| 平台 / job | 普通 Rust passed / failed / ignored | app passed / failed / ignored | rustdoc passed / failed / ignored | Python 主 discovery run / passed / failed / skipped |
| --- | --- | --- | --- | --- |
| Windows / 133608443190 | 3312 / 0 / 56 | 1364 / 0 / 2 | 14 / 0 / 0 | 293 / 259 / 0 / 34 |
| macOS / 133608443592 | 3325 / 0 / 58 | 1375 / 0 / 2 | 14 / 0 / 0 | 293 / 291 / 0 / 2 |
| Ubuntu / 133608443616 | 3318 / 0 / 59 | 1376 / 0 / 2 | 14 / 0 / 0 | 293 / 291 / 0 / 2 |

每平台 92 个普通 suite、6 个 rustdoc subrun 的声明、唯一逐名结果和摘要相等。
app 声明分别为 1366／1377／1378；普通 Rust 已包含 app。
Python 包装回归另为57 run：Windows `53/0/4 skipped`，macOS／Ubuntu各`57/0/0`；
workspace 内嵌 helper 在 macOS／Ubuntu各`30/0/0`，Windows未报告该 subrun。
未将 Python 或两个自定义 harness 计入普通 Rust；未把六个 rustdoc subrun
强行按五个提前到达的 crate header 分配。

原失败两名在三平台 app 全部逐名 `ok`，共六项：

- `monitor::tests::independent_disk_monitor::independent_disk_samples_survive_production_theme_buttons_and_focused_input`
- `monitor::tests::disk_monitor_minimum_workspace_languages_themes_scroll_and_selection_are_stable`

三个 Rust gate 与包装步骤成功；Windows filesystem／archive codec／session backend
预检成功，macOS／Ubuntu 标准 OpenSSH 及回执保存成功。
42 个步骤共 `32 success / 10 skipped`：
Windows `11/3`、macOS `10/4`、Ubuntu `11/3`。
全部 step 名称、编号、终态与开始／结束时间均在 `terminal-summary-offline-r1.json`。
状态原件 `updatedAt=2026-11-16T21:31:17Z`，即北京时间 `2026-11-17 05:31:17`；
该时间不是本次封存时间，也不倒填为原下载时间。

新增纯派生 helper `derive_terminal_offline.py`，只在 app 选择处使用
`suite.replace('\\', '/')`，不调用原下载脚本。
三个原日志经未改 parser 重算，与三份既存 suites JSON 完全相等。
731 个完整工程路径、bytes、SHA-256 已逐项绑定上述精确 Git blob，
零 mismatch；aggregate
`2ea283af87af7e0af2fa912ebc28f9360e0c5113cd40e1111502f8cdd6d8551e`。
freeze 内的 `head=262a642605ffdb52ef4d6bef075aef17cc910149` 仅为原采集基线元数据，
没有将其或当前 HEAD 当作 CI 源码。

37 成员 `originals.tar.gz` 为 **800,304 字节**，SHA-256
`f5c06c21bbe58879d25e9e0066ee97b952d4d65f1cacfb401bf256328fdd4737`。
原有29文件摘要全部保持；28文本原件封存，既有bytecode只留摘要／原位，不执行或再生成。
原状态、原 job 日志、suites、freeze、两次失败和当时脚本均封存；
manifest保存逐项bytes／SHA。封存后验证回执及本报告在work原位保留。

| 本次命令回执 | exit / 回收 / 耗时 | 结果 |
| --- | --- | --- |
| derive-terminal-offline-r1 | 0 / reaped / 2.126181s | 三平台完整派生及731精确Git输入绑定通过 |
| seal-offline-r1 | 0 / reaped / 0.086484s | 37成员封存成功 |
| verify-ci-completion-r1 | 0 / reaped / 2.147902s | archive／成员／派生／731输入独立重算零mismatch |

只读复验命令：

```sh
python3 -B docs/testing/records/2026-11-17-monitor-render-stack-evidence/ci-completion/verify.py
```

修改路径限定在用户授权的三处：

- `work/monitor-stack-ci-20261117/`：本报告；纯派生helper、受限本地回执runner；
  `original-inputs-r1.json`、`scope-before-r1.json`、`scope-after-r1.json`；
  `terminal-summary-offline-r1.json`、`exact-source-binding-offline-r1.json`；
  `sealed-verifier-r1.py`；上述三组执行 `.json/.log` 回执；
  `audit_scope.py`、`scope-audit-diagnostic-r1.json/.log`。
  精确新增路径清单见scope-after。
- `docs/testing/records/2026-11-17-monitor-render-stack-evidence/ci-completion/`：
  新增 `README.md`、`manifest.json`、`originals.tar.gz`、`verify.py`。
- `docs/testing/records/2026-11-17-monitor-render-stack.md`：
  更新当前状态并追加本地纯派生终态，原运行中快照和历史失败保持其时点。

限制与原失误：

- `collect-terminal-r1=1` 原样保留：gh拒绝ANSI，三个下载输出0字节和完整stderr均在。
- `collect-terminal-r2=1` 原样保留：原日志／parser输出已保存成功，外层Windows
  `src\main.rs`选择抛出`StopIteration`。原r2未完成聚合摘要，也未保存独立逐job
  下载exit／耗时回执；本次不补造，成功回执仅属于离线派生和封存验证。
- CI没有独立app `--list`库存或Python主discovery逐名`-v`库存；
  现有运行声明／逐名Rust结果／摘要不能代替这些缺失证据。
- 本次网络请求、CI重跑、测试重放、Cargo命令、target读写、commit、push均为0；
  未创建watcher、子agent或新工作树，所有本次受控子进程已reap。
- HANDOFF／ROADMAP与开始时bytes／SHA相等。本任务只写上述三处，
  不把当前dirty Windows源码纳入731输入签署；代码内容未作本次验收。
- 首轮只读scope核对因并行任务新增4个非本片dirty路径而exit1，未写出scope-after；
  完整stderr和失败谓词另存`scope-audit-diagnostic-r1.json/.log`。
  这些路径为`README.md`、`README.en.md`、`docs/product/HOST_RESOURCE_TRENDS.md`、
  `docs/product/MONITOR_CAPABILITIES.md`。最终审计保留并发状态差异，
  没有修改、还原或签署这些路径；此诊断发生在成功封存验证后，不在37成员archive内。
- 原`43945988599`失败、依赖最新版本在线复查UNKNOWN保持。
  不代签原生桌面、正常应用包、安装、签名、公证、发行或完整产品。
