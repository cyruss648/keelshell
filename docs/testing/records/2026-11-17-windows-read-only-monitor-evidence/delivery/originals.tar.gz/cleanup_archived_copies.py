"""Remove only owned files after exact Git or retained-byte verification."""
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
SOURCE = "5d2df2fc5ac8566fe11182b7f4337076296dfa54"
EVIDENCE = "docs/testing/records/2026-11-17-windows-read-only-monitor-evidence"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git_bytes(name):
    return subprocess.check_output(
        ["git", "show", f"{SOURCE}:{name}"], cwd=ROOT, timeout=30
    )


def archived(prefix):
    manifest = json.loads(git_bytes(prefix + "/manifest.json"))
    data = git_bytes(prefix + "/originals.tar.gz")
    assert len(data) == manifest["archive_bytes"] and sha(data) == manifest["archive_sha256"]
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as archive:
        files = {m.name: archive.extractfile(m).read() for m in archive.getmembers()}
    assert len(files) == manifest["count"]
    for row in manifest["entries"]:
        assert len(files[row["path"]]) == row["bytes"]
        assert sha(files[row["path"]]) == row["sha256"]
    return files


def main():
    files = archived(EVIDENCE)
    candidate = archived(EVIDENCE + "/candidate-r1")
    previous_prefix = "docs/testing/records/2026-11-17-monitor-render-stack-evidence/ci-completion"
    previous = archived(previous_prefix)
    previous_by_sha = {sha(data): name for name, data in previous.items()}
    selection = json.loads(files["selection.json"])
    proof = {}
    for row in selection["entries"]:
        data = files[row["path"]]
        assert len(data) == row["bytes"] and sha(data) == row["sha256"]
        proof[row["source"]] = {
            "bytes": row["bytes"], "sha256": row["sha256"],
            "kind": "archive", "member": row["path"],
        }
    for row in selection["source_snapshot_references"]:
        proof[row["source"]] = {
            "bytes": row["bytes"], "sha256": row["sha256"],
            "kind": row["kind"], "member": row["canonical"],
        }

    normal = BASE / "package-r2"
    package_rows = []
    for path in sorted(normal.rglob("*")):
        if path.is_file():
            data = path.read_bytes()
            package_rows.append({
                "path": path.relative_to(normal).as_posix(),
                "bytes": len(data), "sha256": sha(data),
            })
    target = ROOT / "work/recovery-batch-integration-20261115/target"
    target_before = target.stat()
    old_package = json.loads(files["integration/normal-package-precommit-r1.json"])
    new_manifest = json.loads((normal / "package-manifest.json").read_text())
    assert new_manifest["build"]["commit"] == SOURCE
    assert new_manifest["files"] == old_package["manifest"]["files"]
    old_package_rows = {r["path"]: r for r in old_package["files"]}
    integration = "work/windows-monitor-integration-20261117"
    roots = [
        integration, "work/windows-monitor-review-source-20261117",
        "work/windows-monitor-review-function-20261117",
        "work/windows-monitor-oracle-fix-20261117",
        "work/windows-monitor-evidence-stage-20261117",
        "work/windows-monitor-evidence-stage-r2-20261117",
        "work/monitor-stack-ci-20261117",
    ]
    planned = []
    retained = []
    for root_name in roots:
        root = ROOT / root_name
        assert root.is_dir() and not root.is_symlink()
        for path in sorted(root.rglob("*")):
            if not path.is_file():
                continue
            assert not path.is_symlink()
            relative = path.relative_to(ROOT).as_posix()
            local = path.relative_to(root).as_posix()
            data = path.read_bytes()
            digest = sha(data)
            entry = {"path": relative, "bytes": len(data), "sha256": digest}
            if relative in proof:
                binding = proof[relative]
                assert (len(data), digest) == (binding["bytes"], binding["sha256"])
                entry["proof"] = binding
            elif root_name.endswith("evidence-stage-20261117"):
                assert data == candidate[local]
                entry["proof"] = {"kind": "candidate-r1-archive", "member": local}
            elif root_name.endswith("evidence-stage-r2-20261117"):
                assert data == files[local]
                entry["proof"] = {"kind": "final-archive", "member": local}
            elif root_name == integration and local.startswith("package-r1/"):
                package_name = path.relative_to(root / "package-r1").as_posix()
                row = old_package_rows[package_name]
                assert (len(data), digest) == (row["bytes"], row["sha256"])
                if package_name != "package-manifest.json":
                    assert data == (normal / package_name).read_bytes()
                entry["proof"] = {
                    "kind": "replaced-by-exact-source-package",
                    "member": "integration/normal-package-precommit-r1.json",
                }
            elif root_name == "work/monitor-stack-ci-20261117":
                if digest in previous_by_sha:
                    entry["proof"] = {
                        "kind": "previous-ci-exact-git-archive",
                        "archive": previous_prefix, "member": previous_by_sha[digest],
                    }
                elif path.suffix == ".pyc" and "__pycache__" in path.parts:
                    entry["proof"] = {"kind": "owned-regenerable-bytecode"}
                else:
                    destination = BASE / "cleanup-retained" / relative
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    with destination.open("xb") as output:
                        output.write(data)
                    assert destination.read_bytes() == data
                    retained.append({
                        **entry, "retained_as": destination.relative_to(BASE).as_posix(),
                    })
                    entry["proof"] = {
                        "kind": "retained-original",
                        "member": destination.relative_to(BASE).as_posix(),
                    }
            else:
                raise AssertionError(("Unbound owned file; nothing removed", relative))
            planned.append(entry)
    with (BASE / "cleanup-plan-r1.json").open("x") as output:
        json.dump({"source": SOURCE, "entries": planned, "retained": retained}, output, indent=2)
        output.write("\n")
    for row in planned:
        path = ROOT / row["path"]
        assert len(path.read_bytes()) == row["bytes"] and sha(path.read_bytes()) == row["sha256"]
    for row in planned:
        (ROOT / row["path"]).unlink()
    for root_name in roots:
        root = ROOT / root_name
        for path in sorted(root.rglob("*"), key=lambda p: len(p.parts), reverse=True):
            assert path.is_dir()
            path.rmdir()
        root.rmdir()
    for row in package_rows:
        data = (normal / row["path"]).read_bytes()
        assert len(data) == row["bytes"] and sha(data) == row["sha256"]
    target_after = target.stat()
    assert (target_before.st_dev, target_before.st_ino) == (target_after.st_dev, target_after.st_ino)
    result = {
        "observed_utc": datetime.now(timezone.utc).isoformat(), "source": SOURCE,
        "removed_files": len(planned), "removed_bytes": sum(r["bytes"] for r in planned),
        "removed_roots": roots, "all_roots_absent": all(not (ROOT / n).exists() for n in roots),
        "retained_original_count": len(retained), "normal_package_files": package_rows,
        "normal_package_unchanged": True, "shared_target_identity_unchanged": True,
        "shared_target_cleaned": False, "other_worktrees_or_containers_touched": False,
    }
    with (BASE / "cleanup-result-r1.json").open("x") as output:
        json.dump(result, output, indent=2)
        output.write("\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
