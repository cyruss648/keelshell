"""Remove only task-owned copies byte-bound to committed evidence archives."""
import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
EVIDENCE = "docs/testing/records/2026-11-17-windows-read-only-monitor-evidence"
SOURCE = "5d2df2fc5ac8566fe11182b7f4337076296dfa54"


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def write_once(name, value):
    with (BASE / name).open("x") as output:
        json.dump(value, output, indent=2)
        output.write("\n")


def git_bytes(commit, path):
    return subprocess.check_output(
        ["git", "--no-optional-locks", "show", f"{commit}:{path}"],
        cwd=ROOT, timeout=30,
    )


def originals(commit, name):
    manifest = json.loads(git_bytes(commit, f"{EVIDENCE}/{name}/manifest.json"))
    raw = git_bytes(commit, f"{EVIDENCE}/{name}/originals.tar.gz")
    assert len(raw) == manifest["archive_bytes"] and digest(raw) == manifest["archive_sha256"]
    assert (ROOT / EVIDENCE / name / "originals.tar.gz").read_bytes() == raw
    with tarfile.open(fileobj=io.BytesIO(raw), mode="r:gz") as archive:
        members = archive.getmembers()
        assert all(m.isfile() and not PurePosixPath(m.name).is_absolute()
                   and ".." not in PurePosixPath(m.name).parts for m in members)
        files = {m.name: archive.extractfile(m).read() for m in members}
    assert len(files) == len(members) == manifest["count"]
    assert set(files) == {r["path"] for r in manifest["entries"]}
    for row in manifest["entries"]:
        assert len(files[row["path"]]) == row["bytes"]
        assert digest(files[row["path"]]) == row["sha256"]
    return files


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("delivery_commit")
    args = parser.parse_args()
    commit = args.delivery_commit
    assert len(commit) == 40 and all(c in "0123456789abcdef" for c in commit)
    assert subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True, timeout=10,
    ).strip() == commit
    assert subprocess.check_output(
        ["git", "status", "--porcelain=v1"], cwd=ROOT, timeout=10,
    ) == b""
    ci = originals(commit, "ci-completion")
    delivery = originals(commit, "delivery")
    readback = json.loads((BASE / "git-readback-r1.json").read_text())
    assert readback["expected_source"] == commit
    assert readback["three_shas_match"] and readback["all_commands_passed"]
    assert readback["working_tree_clean"]
    lifecycle = json.loads(delivery["agent-lifecycle-final.json"])
    assert lifecycle["all_owned_agents_closed"]
    for label in ("exact-ci-watch-r1", "derive-terminal-ci-r1", "ci-evidence-verify-r1"):
        receipt = json.loads(delivery[label + ".json"])
        assert receipt["observed_exit"] == 0
        assert receipt["terminal"]["direct_reaped"]
        assert receipt["terminal"]["active_processes"] == 0
    package_root = ROOT / "work/windows-monitor-delivery-20261117/package-r2"
    package = json.loads(delivery["normal-source-package-r2.json"])
    assert package["source"] == SOURCE
    retained_package = []
    for row in package["files"]:
        path = package_root / row["path"]
        raw = path.read_bytes()
        assert len(raw) == row["bytes"] and digest(raw) == row["sha256"]
        retained_package.append(path)
    assert set(retained_package) == {p for p in package_root.rglob("*") if p.is_file()}
    target = ROOT / "work/recovery-batch-integration-20261115/target"
    target_identity = (target.stat().st_dev, target.stat().st_ino)
    roots = [
        ("work/windows-monitor-ci-20261117", ci, ""),
        ("work/windows-monitor-api-evidence-review-20261117", delivery,
         "windows-api-independent-review/"),
        ("work/windows-monitor-delivery-20261117", delivery, ""),
    ]
    planned = []
    directories = []
    for relative_root, stored, prefix in roots:
        root = ROOT / relative_root
        assert root.is_dir() and not root.is_symlink()
        for path in sorted(root.rglob("*")):
            assert not path.is_symlink()
            if path == package_root or package_root in path.parents:
                continue
            if path.is_dir():
                directories.append(path)
                continue
            assert path.is_file()
            name = prefix + path.relative_to(root).as_posix()
            raw = path.read_bytes()
            assert name in stored and raw == stored[name], path
            planned.append({
                "path": path.relative_to(ROOT).as_posix(), "bytes": len(raw),
                "sha256": digest(raw), "archive": "ci-completion" if stored is ci else "delivery",
                "member": name,
            })
        if root != package_root.parent:
            directories.append(root)
    assert len({row["path"] for row in planned}) == len(planned)
    write_once("cleanup-plan-r1.json", {
        "source": SOURCE, "delivery_commit": commit, "entries": planned,
        "retained_package_files": package["files"], "target_identity": target_identity,
    })
    for row in planned:
        path = ROOT / row["path"]
        raw = path.read_bytes()
        assert len(raw) == row["bytes"] and digest(raw) == row["sha256"], path
        path.unlink()
    for directory in sorted(set(directories), key=lambda p: len(p.parts), reverse=True):
        directory.rmdir()
    assert all(not (ROOT / row["path"]).exists() for row in planned)
    assert not (ROOT / roots[0][0]).exists() and not (ROOT / roots[1][0]).exists()
    for row in package["files"]:
        raw = (package_root / row["path"]).read_bytes()
        assert len(raw) == row["bytes"] and digest(raw) == row["sha256"]
    assert (target.stat().st_dev, target.stat().st_ino) == target_identity
    result = {
        "observed_utc": datetime.now(timezone.utc).isoformat(),
        "source": SOURCE, "delivery_commit": commit,
        "removed_files": len(planned), "removed_bytes": sum(r["bytes"] for r in planned),
        "archive_binding": "exact committed Git blobs, per-member bytes equal",
        "all_planned_files_absent": True, "ci_and_reviewer_roots_absent": True,
        "delivery_contains_only_current_package": True,
        "normal_package_unchanged": True, "shared_target_identity_unchanged": True,
        "shared_target_cleaned": False, "other_resources_touched": False,
    }
    write_once("cleanup-result-r1.json", result)
    print(json.dumps(result))


if __name__ == "__main__":
    main()
