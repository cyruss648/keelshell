"""Download terminal job originals and derive exact-source results, without reruns."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
CI = BASE.parent / "windows-monitor-ci-20261117"
SOURCE = "5d2df2fc5ac8566fe11182b7f4337076296dfa54"
sys.path.insert(0, str(BASE))
from summarize_tests import normalize, summarize


def collect(item):
    workflow, job = item
    assert job["status"] == "completed"
    if job["conclusion"] == "skipped":
        return {
            "workflow": workflow, "job_id": job["databaseId"], "name": job["name"],
            "status": "completed", "conclusion": "skipped", "logs_downloaded": False,
            "actual_windows_ssh": "UNRUN/HOLD",
        }
    job_id = job["databaseId"]
    log = CI / f"job-{job_id}.log"
    stderr = CI / f"job-{job_id}-download.stderr.log"
    command = [
        "gh", "api", "--allow-escape-sequences", "--method", "GET",
        f"repos/cyruss648/keelshell/actions/jobs/{job_id}/logs",
    ]
    download_path = CI / f"job-{job_id}-download.json"
    if download_path.exists():
        download = json.loads(download_path.read_text())
        raw = log.read_bytes()
        assert download["command"] == command and download["exit"] == 0
        assert len(raw) == download["raw_bytes"]
        assert hashlib.sha256(raw).hexdigest() == download["raw_sha256"]
        assert hashlib.sha256(stderr.read_bytes()).hexdigest() == download["stderr_sha256"]
    else:
        started = time.monotonic()
        with log.open("xb") as output, stderr.open("xb") as error:
            result = subprocess.run(command, stdout=output, stderr=error, timeout=120, check=False)
        raw = log.read_bytes()
        download = {
            "command": command, "exit": result.returncode,
            "seconds": time.monotonic() - started, "raw_log": log.name,
            "raw_bytes": len(raw), "raw_sha256": hashlib.sha256(raw).hexdigest(),
            "stderr_bytes": stderr.stat().st_size,
            "stderr_sha256": hashlib.sha256(stderr.read_bytes()).hexdigest(),
        }
        with download_path.open("x") as output:
            json.dump(download, output, indent=2)
            output.write("\n")
        assert result.returncode == 0
    row = {
        "workflow": workflow, "job_id": job_id, "name": job["name"],
        "status": job["status"], "conclusion": job["conclusion"], "download": download,
        "steps": job["steps"], "tests_replayed": 0,
    }
    text = normalize(raw)
    if workflow == "Quality":
        parsed = summarize(raw)
        parsed_path = CI / f"job-{job_id}-suites.json"
        if parsed_path.exists():
            assert json.loads(parsed_path.read_text()) == parsed
        else:
            with parsed_path.open("x") as output:
                json.dump(parsed, output, indent=2)
                output.write("\n")
        row["ordinary"] = {
            key: sum(s["summary"][key] for s in parsed["suites"])
            for key in ("passed", "failed", "ignored")
        }
        row["rustdoc"] = {
            key: sum(s["summary"][key] for s in parsed["doctest_runs_unassigned"])
            for key in ("passed", "failed", "ignored")
        }
        app = next(s for s in parsed["suites"]
                   if "unittests src/main.rs " in s["suite"].replace("\\", "/")
                   and "keelshell_app" in s["suite"])
        session = next(s for s in parsed["suites"]
                       if "unittests src/lib.rs " in s["suite"].replace("\\", "/")
                       and "keelshell_session" in s["suite"])
        route = next(s for s in parsed["suites"]
                     if "tests/windows_monitor.rs " in s["suite"].replace("\\", "/"))
        row.update(
            ordinary_suites=len(parsed["suites"]), app=app["summary"],
            session=session["summary"], windows_routing=route["summary"],
        )
        windows = [(n, outcome) for n, outcome in app["results"]
                   if n.startswith("monitor::tests::windows::")]
        assert len(windows) == 23 and all(outcome == "ok" for _, outcome in windows)
        row["windows_app_regressions"] = windows
        gate = text.split("##[group]Run python scripts/check.py", 1)[1]
        gate = gate.split("\n##[group]Run ", 1)[0]
        python_section = gate.split("Running: cargo fmt --all --check", 1)[0]
        match = re.search(
            r"Ran (\d+) tests in ([\d.]+)s\s+OK \(skipped=(\d+)\)", python_section
        )
        assert match
        row["python_main"] = {
            "run": int(match[1]), "seconds": float(match[2]), "skipped": int(match[3]),
            "passed": int(match[1]) - int(match[3]), "failed": 0,
        }
        row["python_auxiliary_runs"] = re.findall(
            r"Ran (\d+) tests? in ([\d.]+)s", gate
        )[1:]
    else:
        captured = "captured_windows_api_frames_are_accepted_through_authenticated_monitor_routing"
        assert re.search(rf"test {captured} \.\.\. ok", text)
        assert "1 passed; 0 failed; 0 ignored" in text
        python_results = re.findall(
            r"^(test_\S+ \([^)]+\)) \.\.\. (ok|skipped)(?: [^\n]*)?$",
            text, re.MULTILINE,
        )
        assert len(python_results) == len({name for name, _ in python_results}) == 111
        match = re.search(r"Ran (\d+) tests in ([\d.]+)s\s+OK \(skipped=(\d+)\)", text)
        assert match and int(match[1]) == 111 and int(match[3]) == 3
        assert sum(value == "ok" for _, value in python_results) == 108
        assert sum(value == "skipped" for _, value in python_results) == 3
        row["capture_replay"] = {
            "name": captured, "passed": 1, "failed": 0, "ignored": 0,
            "real_windows_ssh_acceptance": False,
        }
        row["lab_python_tests"] = {
            "run": 111, "passed": 108, "failed": 0, "skipped": 3,
            "seconds": float(match[2]), "results": python_results,
        }
    return row


def main():
    partial = sys.argv[1:] == ["--completed-only"]
    assert not sys.argv[1:] or partial
    runs = []
    for run_id, name in ((43972364934, "Quality"), (43972365007, "Windows monitor integration")):
        run = json.loads((CI / f"run-{run_id}-latest.json").read_text())
        assert run["headSha"] == SOURCE and run["databaseId"] == run_id
        assert run["workflowName"] == name
        assert partial or run["status"] == "completed"
        runs.append(run)
    inputs = [(run["workflowName"], job) for run in runs for job in run["jobs"]
              if not partial or job["status"] == "completed"]
    with ThreadPoolExecutor(max_workers=4) as pool:
        jobs = list(pool.map(collect, inputs))
    result = {
        "source": SOURCE,
        "runs": [
            {key: run[key] for key in ("databaseId", "workflowName", "status", "conclusion", "headSha", "url")}
            for run in runs
        ],
        "jobs": jobs, "partial": partial, "tests_replayed": 0, "manual_reruns": 0,
        "native_desktop_acceptance": False, "actual_windows_ssh": "UNRUN/HOLD",
    }
    output_name = "completed-jobs-summary-r1.json" if partial else "terminal-summary-r1.json"
    with (CI / output_name).open("x") as output:
        json.dump(result, output, indent=2)
        output.write("\n")
    for row in jobs:
        print(json.dumps({
            key: row[key] for key in (
                "workflow", "job_id", "name", "status", "conclusion", "ordinary",
                "app", "session", "windows_routing", "rustdoc", "python_main",
                "capture_replay",
            ) if key in row
        }))
    if not partial:
        assert all(run["conclusion"] == "success" for run in runs)


if __name__ == "__main__":
    main()
