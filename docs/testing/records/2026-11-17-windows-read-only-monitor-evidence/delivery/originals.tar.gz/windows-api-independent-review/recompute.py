"""Offline receipt derivation only. No production module import or test execution."""
import base64
import hashlib
import io
import json
import math
import re
import subprocess
import traceback
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
BASE = ROOT / "work/windows-monitor-ci-20261117"
CAP = BASE / "direct-artifact-r1"
SHA = "5d2df2fc5ac8566fe11182b7f4337076296dfa54"
DIGEST = "b2afa96f9ada2ae38d8e1d21b8b05587db512da3b43f0ba4ae071aa0a2914af9"
CHECKS, GIT_COMMANDS = [], []


def hash_bytes(data):
    return hashlib.sha256(data).hexdigest()


def check(name, value):
    CHECKS.append({"check": name, "passed": bool(value)})
    if not value:
        raise ValueError("independent evidence mismatch: " + name)


def pairs(items):
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError("duplicate JSON key: " + key)
        result[key] = value
    return result


def parse(data):
    def reject(value):
        raise ValueError("nonfinite JSON value: " + value)
    return json.loads(data.decode("utf-8-sig"), object_pairs_hook=pairs,
                      parse_constant=reject)


def read_json(path):
    return parse(path.read_bytes())


def git(*arguments):
    argv = ["git", "--no-optional-locks", *arguments]
    result = subprocess.run(argv, cwd=ROOT, capture_output=True)
    GIT_COMMANDS.append({"argv": argv, "exit": result.returncode,
                         "stdout_sha256": hash_bytes(result.stdout),
                         "stderr_sha256": hash_bytes(result.stderr)})
    if result.returncode:
        (OUT / "git-failure-r2.stdout").write_bytes(result.stdout)
        (OUT / "git-failure-r2.stderr").write_bytes(result.stderr)
        raise ValueError("read-only Git command failed")
    return result.stdout


def evidence(path, token):
    lines = path.read_text(encoding="utf-8-sig").splitlines()
    return str(path) + ":" + str(next(i for i, s in enumerate(lines, 1) if token in s))


def socket_key(row):
    return row["protocol"], row["address"], int(row["port"]), int(row["pid"])


def main():
    head_start = git("rev-parse", "HEAD").decode().strip()
    top = ["direct-api-artifact-r1.zip", "direct-api-artifact-download-r1.json",
           "artifact-validation-r1.json", "run-43972365007-latest.json",
           "job-133667526984.log", "job-133667526984-download.json",
           "completed-jobs-summary-r1.json"]
    paths = [BASE / name for name in top] + sorted(p for p in CAP.rglob("*") if p.is_file())
    manifest = [{"path": str(p.relative_to(ROOT)), "bytes": len(p.read_bytes()),
                 "sha256": hash_bytes(p.read_bytes())} for p in paths]
    check("41 input files: seven outer originals and 34 extracted members", len(paths) == 41)
    archive = paths[0].read_bytes()
    download, parent, run = [read_json(p) for p in paths[1:4]]
    log_raw = paths[4].read_bytes()
    # Normalize CRLF only in the derived text used for matching, never in originals/hashes.
    log = log_raw.decode("utf-8-sig").replace("\r\n", "\n")
    log_download, summary = [read_json(p) for p in paths[5:7]]
    artifact = download["artifact"]
    check("ZIP bytes/hash equal user digest, saved official metadata and download receipt",
          hash_bytes(archive) == DIGEST == download["archive_sha256"]
          and len(archive) == 46825 == artifact["size_in_bytes"] == download["archive_bytes"]
          and artifact["digest"] == download["expected_github_digest"] == "sha256:" + DIGEST
          and download["exit"] == 0 and download["matches_github_digest"] is True)
    check("artifact id/name/run/source binding", artifact["id"] == 14279316541
          and artifact["workflow_run"]["id"] == 43972365007
          and artifact["workflow_run"]["head_sha"] == SHA
          and artifact["name"] == "windows-monitor-direct-43972365007-1"
          and artifact["expired"] is False)
    members = []
    with zipfile.ZipFile(io.BytesIO(archive)) as zipped:
        names = zipped.namelist()
        check("34 unique flat ZIP entries; CRC intact",
              len(names) == len(set(names)) == 34 and zipped.testzip() is None
              and all("/" not in name and "\\" not in name and name not in (".", "..")
                      for name in names))
        check("ZIP/extracted member inventories equal",
              set(names) == {p.name for p in paths[7:]})
        for info in zipped.infolist():
            data = zipped.read(info)
            check("ZIP/extracted exact bytes: " + info.filename,
                  data == (CAP / info.filename).read_bytes())
            members.append({"name": info.filename, "bytes": len(data),
                            "sha256": hash_bytes(data), "crc32": f"{info.CRC:08x}"})
    check("completed/success exact workflow; direct success and SSH skipped",
          run["headSha"] == SHA and run["databaseId"] == 43972365007
          and run["status"] == "completed" and run["conclusion"] == "success"
          and {(j["databaseId"], j["status"], j["conclusion"]) for j in run["jobs"]}
          == {(133667526984, "completed", "success"), (133667529467, "completed", "skipped")})
    check("raw job log download byte/hash/exit/empty stderr",
          len(log_raw) == log_download["raw_bytes"] == 91173
          and hash_bytes(log_raw) == log_download["raw_sha256"]
          and log_download["exit"] == 0 and log_download["stderr_bytes"] == 0
          and log_download["stderr_sha256"] == hash_bytes(b""))
    check("raw log binds source/artifact count/id/upload digest",
          SHA in log and "34 files uploaded" in log and "Artifact ID 14279316541" in log
          and "SHA256 digest of uploaded artifact is " + DIGEST in log)
    suite = re.findall(r"^.*?Z (test_\w+) \((test_windows_monitor_lab\.[^)]+)\) \.\.\. (.*)$",
                       log, re.M)
    check("raw Python per-name inventory: 111 run, 108 ok, three skipped",
          len(suite) == len({r[1] for r in suite}) == 111
          and sum(r[2] == "ok" for r in suite) == 108
          and sum(r[2].startswith("skipped ") for r in suite) == 3
          and "Ran 111 tests in 2.453s" in log and "OK (skipped=3)" in log)
    replay = "captured_windows_api_frames_are_accepted_through_authenticated_monitor_routing"
    check("raw named capture replay: one passed, zero failed/ignored, nine filtered",
          len(re.findall(r"Z test " + replay + r" \.\.\. ok", log)) == 1
          and "test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 9 filtered out;" in log)
    check("summary preserves unfinished Quality independently",
          summary["source"] == SHA and summary["partial"] is True
          and any(r["databaseId"] == 43972364934 and r["status"] == "in_progress"
                  and not r["conclusion"] for r in summary["runs"]))
    sources = ["scripts/windows_monitor_lab.py", "scripts/windows_native_crash.py",
               "scripts/windows_monitor/owned_fixture.py",
               "crates/keelshell-session/src/monitor/windows.rs",
               "crates/keelshell-session/tests/windows_monitor.rs",
               ".github/workflows/windows-monitor.yml"]
    sources += ["crates/keelshell-session/src/monitor/windows/" + name + ".ps1"
                for name in ["common", "probe", "resources", "processes", "sockets"]]
    source_bytes = {p: git("show", SHA + ":" + p) for p in sources}
    source_manifest = []
    for path, data in source_bytes.items():
        check("current source equals fixed Git bytes: " + path, (ROOT / path).read_bytes() == data)
        source_manifest.append({"path": path, "bytes": len(data), "sha256": hash_bytes(data),
                                "git_source": SHA, "current_equal_fixed": True})
    original = read_json(CAP / "receipt.json")
    runtime = read_json(CAP / "runtime.json")
    fixture = read_json(CAP / "fixture.json")
    native = read_json(CAP / "independent.json")
    before_file = read_json(CAP / "independent-before.json")
    comparison = read_json(CAP / "comparison.json")
    check("recorded Server 2025 AMD64 WindowsPowerShell 5.1.26100.33648 scope",
          original["status"] == original["windows_api"] == "PASS"
          and original["system"] == "Windows" and original["release"] == "2025Server"
          and original["architecture"] == "AMD64" and original["build"] == "10.0.26100"
          and runtime["runtime"] == "WindowsPowerShell"
          and runtime["runtime_version"] == "5.1.26100.33648"
          and runtime == parent["runtime"]
          and original["ssh"] == original["native_gui"] == "UNRUN")
    assembly = {"probe": ("$op='probe';$skip=$false;\n", "probe"),
                "resources": ("$op='resources';$skip=$false;\n", "resources"),
                "processes": ("$op='processes';$skip=$false;\n", "processes"),
                "sockets": ("$op='sockets';$skip=$false;\n", "sockets"),
                "resources-skipped": ("$op='resources';$skip=$true;\n", "resources")}
    rust = source_bytes[sources[3]].decode()
    prefix = re.search(r'const COMMAND_PREFIX: &str = "([^"]*)";', rust)[1]
    suffix = json.loads('"' + re.search(r'const SUFFIX: &str = "([^"]*)";', rust)[1] + '"')
    frames, command_records, terminal_records = {}, [], []
    for operation, (literal, body) in assembly.items():
        common = source_bytes["crates/keelshell-session/src/monitor/windows/common.ps1"]
        body_bytes = source_bytes["crates/keelshell-session/src/monitor/windows/" + body + ".ps1"]
        script = literal + common.decode() + body_bytes.decode() + suffix
        wire = prefix + base64.b64encode(script.encode("utf-16le")).decode()
        binding = read_json(CAP / (operation + ".assembly.json"))
        child = read_json(CAP / (operation + ".receipt.json"))
        shell, terminal = child["shell_execution"], child["terminal"]
        objects = terminal["native_process_objects"]
        check(operation + ": literal production assembly, wire and all part/script hashes",
              literal.replace("\n", "\\n") in rust
              and wire.encode("ascii") == (CAP / (operation + ".wire.txt")).read_bytes()
              and binding["literal_prefix"] == literal and binding["literal_suffix"] == suffix
              and binding["join"] == "verbatim"
              and binding["parts"] == [{"file": "common.ps1", "sha256": hash_bytes(common)},
                                       {"file": body + ".ps1", "sha256": hash_bytes(body_bytes)}]
              and binding["script_sha256"] == hash_bytes(script.encode())
              and binding["wire_command_sha256"] == hash_bytes(wire.encode())
              and binding["wire_command_ascii_bytes"] == len(wire) < 8000)
        argv = [r"C:\Windows\System32\cmd.exe", "/d", "/s", "/c", wire]
        serialized = subprocess.list2cmdline(argv)
        check(operation + ": exact cmd argv/serialization/bounds/PowerShell image",
              shell["argv"] == argv and shell["serialized_command_line"] == serialized
              and shell["shell"] == argv[0] and shell["required_image"] == runtime["executable"]
              and shell["production_command_ascii_bytes"] == len(wire)
              and child["command_chars"] == len(serialized) < 8191
              and child["command_sha256"] == hash_bytes(serialized.encode()))
        check(operation + ": original live retention, natural exit0, full census, no leak",
              child["observed_exit"] == 0 and not child["errors"]
              and terminal["direct_reaped"] is True and terminal["active_processes"] == 0
              and terminal["pipes_drained"] is True and not terminal["errors"]
              and objects["admission_closed"] is True and objects["identities_bound"] is True
              and objects["pending_process_objects"] == 0
              and objects["retained_processes"] == shell["job_total_processes"] == 2
              and objects["original_handles_checked"] == 3
              and objects["known_direct_handles"] == 1 and objects["verified_extra_handles"] == 0
              and shell["complete_original_object_census"] is True
              and len(shell["powershell_original_objects"]) == 1
              and all(o["retained_while_live"] is True
                      and o["natural_terminal_before_cleanup"] is True and o["exit_code"] == 0
                      for o in shell["powershell_original_objects"]))
        stdout = (CAP / (operation + ".stdout")).read_bytes()
        stderr = (CAP / (operation + ".stderr")).read_bytes()
        frame = parse(stdout)
        check(operation + ": original frame, empty stderr, byte counts, parent child equality",
              not stderr and child["stdout_bytes"] == len(stdout) and child["stderr_bytes"] == 0
              and frame["operation"] == body and frame["status"] == "ok" and frame["version"] == 1
              and frame["runtime"] == runtime["runtime"]
              and frame["runtime_version"] == runtime["runtime_version"]
              and frame["platform"] == "Windows" and frame["units"] == "bytes seconds percent"
              and next(c for c in original["children"] if c["label"] == operation)
              == {"label": operation, **child})
        frames[operation] = frame["data"]
        command_records.append({"operation": operation, "wire_ascii_bytes": len(wire),
                                "serialized_cmd_chars": len(serialized),
                                "wire_sha256": hash_bytes(wire.encode()),
                                "stdout_bytes": len(stdout), "stdout_sha256": hash_bytes(stdout),
                                "powershell_original_pid": shell["powershell_original_objects"][0]["pid"],
                                "job_total_processes": 2, "complete_census": True, "natural_exit": 0})
        terminal_records.append({"operation": operation, "direct_pid": child["pid"],
                                 "terminal": terminal,
                                 "original_powershell_objects": shell["powershell_original_objects"]})
    fixture_receipt = read_json(CAP / "fixture.receipt.json")
    ft = fixture_receipt["terminal"]
    fo = ft["native_process_objects"]
    check("fixture original direct handle terminal, natural stop exit0, no pipe/process leak",
          fixture_receipt["pid"] == fixture["pid"] == 9920
          and fixture_receipt["observed_exit"] == 0 and not fixture_receipt["errors"]
          and ft["direct_reaped"] is True and ft["active_processes"] == 0
          and ft["pipes_drained"] is True and not ft["errors"]
          and fo["admission_closed"] is True and fo["identities_bound"] is True
          and fo["pending_process_objects"] == 0
          and fo["known_direct_handles"] == fo["original_handles_checked"] == 1
          and parse((CAP / "fixture.stdout").read_bytes()) == fixture
          and fixture_receipt["stdout_bytes"] == len((CAP / "fixture.stdout").read_bytes())
          and not (CAP / "fixture.stderr").read_bytes()
          and next(c for c in original["children"] if c["label"] == "fixture")
          == {"label": "fixture", **fixture_receipt})
    check("six exact children and parent five command lengths/hashes/natural exits match",
          len(original["children"]) == 6 and len(parent["production_commands"]) == 5
          and all(p["operation"] == r["operation"] and p["stdout_sha256"] == r["stdout_sha256"]
                  and p["command_ascii_bytes"] == r["wire_ascii_bytes"]
                  and p["serialized_cmd_chars"] == r["serialized_cmd_chars"]
                  and p["original_powershell_pid"] == r["powershell_original_pid"]
                  and p["natural_terminal"] is True and p["current_production_assembly_matches"] is True
                  for p, r in zip(parent["production_commands"], command_records)))
    check("separate independent-before file equals before bracket",
          before_file["resources"] == native["before"] and before_file["cpu"] == native["cpu_before"])
    processes, sockets = frames["processes"], frames["sockets"]
    owned = [r for r in processes["processes"] if int(r["pid"]) == fixture["pid"]]
    np = native["process"]
    check("complete observed row counts, sorted unique PIDs and socket identities",
          processes["count"] == len(processes["processes"]) == 146
          and sockets["count"] == len(sockets["sockets"]) == 62
          and len(native["sockets"]) == 109
          and [int(r["pid"]) for r in processes["processes"]]
          == sorted({int(r["pid"]) for r in processes["processes"]})
          and len({socket_key(r) for r in sockets["sockets"]}) == 62)
    check("owned independent PID/name/working-set agree",
          len(owned) == 1 and np["pid"] == fixture["pid"]
          and owned[0]["name"].casefold() == np["name"].casefold()
          and int(owned[0]["working_set_bytes"]) == np["working_set_bytes"] == 25767936)
    actual = {socket_key(r) for r in sockets["sockets"]}
    expected = {socket_key(r) for r in native["sockets"] if r["state"] in ("LISTEN", "BOUND")}
    all_native = {socket_key(r): r["state"] for r in native["sockets"]}
    check("four owned dual-stack TCP/UDP endpoints present in independent and production sets",
          len(fixture["endpoints"]) == len({socket_key(r) for r in fixture["endpoints"]}) == 4
          and {(r["protocol"], r["address"]) for r in fixture["endpoints"]}
          == {("tcp", "127.0.0.1"), ("tcp", "::1"), ("udp", "127.0.0.1"), ("udp", "::1")}
          and all(socket_key(r) in actual & expected and int(r["pid"]) == fixture["pid"]
                  for r in fixture["endpoints"]))
    check("two connected-only TCP controls independently observed and excluded",
          len(fixture["connected_only"]) == 2
          and {r["address"] for r in fixture["connected_only"]} == {"127.0.0.1", "::1"}
          and all(r["protocol"] == "tcp" and socket_key(r) not in actual
                  and all_native.get(socket_key(r)) == "CONNECTED_OR_OTHER"
                  for r in fixture["connected_only"]))
    delta = [b - a for a, b in zip(native["cpu_before"], native["cpu_after"])]
    total = delta[1] + delta[2]
    check("independent idle/kernel/user CPU counter monotonic bracket",
          len(delta) == 3 and min(delta) >= 0 and total > 0 and delta[0] <= total)
    cpu = 100 * (total - delta[0]) / total
    resource_records = []
    for label in ["resources", "resources-skipped"]:
        data, before, after = frames[label], native["before"], native["after"]
        comp = comparison["resources" if label == "resources" else "resources_skipped"]
        def network_index(rows):
            return {(r["interface_guid"], r["interface_luid"], r["interface_index"], r["name"]): r
                    for r in rows}
        na, nb = network_index(before["networks"]), network_index(after["networks"])
        production = {r["name"]: r for r in data["networks"]}
        stable = set(na) & set(nb)
        check(label + ": complete stable independent network identity coverage",
              len(na) == len(nb) == len(stable) == 3 and set(na) == set(nb)
              and set(production) == {i[3] for i in stable}
              and data["network_count"] == len(data["networks"]) == 3
              and comp["network_inventory"]["stable_identities"] == [list(i) for i in sorted(stable)]
              and comp["network_inventory"]["required"] == comp["network_inventory"]["production"]
              == sorted(production) and not comp["network_inventory"]["before_only"]
              and not comp["network_inventory"]["after_only"])
        check(label + ": every cumulative network counter inside bracket",
              all(na[i][f] <= int(production[i[3]][f]) <= nb[i][f]
                  for i in stable for f in ["received_bytes", "transmitted_bytes"]))
        mt = max(1024 * 1024, after["memory_total_bytes"] // 200)
        mf = max(256 * 1024 * 1024, after["memory_total_bytes"] // 10)
        check(label + ": memory/wall-clock uptime/boot agree within saved tolerances",
              abs(int(data["memory_total_bytes"]) - after["memory_total_bytes"]) <= mt
              and min(before["memory_free_bytes"], after["memory_free_bytes"]) - mf
              <= int(data["memory_free_bytes"])
              <= max(before["memory_free_bytes"], after["memory_free_bytes"]) + mf
              and abs(int(data["boot_time"]) - after["boot_unix"]) <= 120
              and before["uptime_seconds"] - 120 <= data["uptime_seconds"] <= after["uptime_seconds"] + 120
              and comp["memory_total_tolerance_bytes"] == mt and comp["memory_free_tolerance_bytes"] == mf
              and comp["uptime_tolerance_seconds"] == 120)
        check(label + ": independent/CIM CPU values and informational-only boundary",
              math.isfinite(data["cpu_percent"]) and 0 <= data["cpu_percent"] <= 100
              and comp["independent_cpu_percent"] == cpu
              and comp["production_cpu_percent"] == data["cpu_percent"]
              and comp["cpu_difference_is_informational"] is True
              and "different sampling windows" in comp["cpu_reason"])
        if label == "resources":
            def volume_index(rows):
                return {(r["mount"].casefold(), r["volume_guid"].casefold(), r["volume_serial"]): r
                        for r in rows}
            va, vb = volume_index(before["filesystems"]), volume_index(after["filesystems"])
            disks = {r["mount"].casefold(): r for r in data["filesystems"]}
            check("complete stable independently enumerated ready fixed-volume coverage",
                  set(va) == set(vb) and len(va) == 2
                  and set(disks) == {i[0] for i in va}
                  and data["filesystem_count"] == len(disks) == 2
                  and not before["capacity_issues"] and not after["capacity_issues"]
                  and data["capacity_status"] == comp["capacity_status"] == "ok"
                  and all({(r["mount"].casefold(), r["volume_guid"], r["volume_serial"])
                           for r in snap["drive_inventory"] if r["drive_type"] == 3 and r["ready"] is True}
                          == set(va) for snap in [before, after])
                  and comp["capacity_inventory"]["stable_identities"] == [list(i) for i in sorted(va)]
                  and not comp["capacity_inventory"]["before_only"]
                  and not comp["capacity_inventory"]["after_only"])
            tolerances = []
            for identity in sorted(va):
                row = disks[identity[0]]
                tolerance = max(256 * 1024 * 1024, vb[identity]["total_bytes"] // 100)
                tolerances.append({"mount": row["mount"], "bytes": tolerance})
                check("volume total/free/available bracket: " + identity[0],
                      va[identity]["total_bytes"] == vb[identity]["total_bytes"] == int(row["total_bytes"])
                      and all(min(va[identity][f], vb[identity][f]) - tolerance <= int(row[f])
                              <= max(va[identity][f], vb[identity][f]) + tolerance
                              for f in ["total_free_bytes", "available_bytes"]))
            check("saved capacity comparison equals recomputed complete set",
                  comp["capacity_tolerances"] == tolerances
                  and comp["capacity_inventory"]["required"] == comp["capacity_inventory"]["production"]
                  == sorted(disks))
        else:
            check("capacity skip exempts volume comparison only; all core checks retained",
                  data["capacity_status"] == comp["capacity_status"] == "skipped"
                  and data["filesystem_count"] == 0 and data["filesystems"] == []
                  and comp["capacity_tolerances"] == []
                  and comp["capacity_inventory"] == {"status": "not_compared", "reason": "skipped"})
        resource_records.append({"operation": label, "network_count": 3,
                                 "fixed_volume_count_compared": 2 if label == "resources" else 0,
                                 "capacity_status": data["capacity_status"],
                                 "independent_cpu_percent": cpu, "CIM_cpu_percent": data["cpu_percent"],
                                 "CPU_difference_informational_only": True,
                                 "memory_total_tolerance_bytes": mt, "memory_free_tolerance_bytes": mf})
    check("owned comparison exactly equals independent recomputation",
          comparison["owned"] == {"pid": fixture["pid"], "owned_endpoints_matched": 4,
                                  "connected_tcp_excluded": 2, "working_set_difference_bytes": 0,
                                  "working_set_tolerance_bytes": max(16 * 1024 * 1024, np["working_set_bytes"] // 2)})
    check("parent validation identity and narrow scope agree with raw originals",
          parent["source"] == SHA and parent["run_id"] == 43972365007
          and parent["job_id"] == 133667526984 and parent["artifact_id"] == 14279316541
          and parent["status"] == "PASS" and parent["owned_endpoint_count"] == 4
          and parent["connected_tcp_excluded"] == 2 and parent["stable_networks"] == 3
          and parent["stable_fixed_volumes"] == 2 and parent["fixture_terminal"] is True
          and parent["commands_reexecuted_locally"] == 0
          and parent["real_windows_ssh"] == parent["native_desktop"] == "UNRUN")
    check("all original inputs unchanged at end",
          all((ROOT / m["path"]).stat().st_size == m["bytes"]
              and hash_bytes((ROOT / m["path"]).read_bytes()) == m["sha256"] for m in manifest))
    check("all inspected product source bytes remain fixed",
          all((ROOT / p).read_bytes() == data for p, data in source_bytes.items()))
    head_end = git("rev-parse", "HEAD").decode().strip()
    (OUT / "read-path-error-r1.stderr").write_text(
        "sed: scripts/windows-monitor/owned_fixture.py: No such file or directory\n")
    result = {
        "conclusion": "APPROVE", "review_date": "2026-11-17",
        "observed_utc": datetime.now(timezone.utc).isoformat(), "source": SHA,
        "head_start": head_start, "head_end": head_end, "findings": [],
        "severity_counts": {"P0": 0, "P1": 0, "P2": 0, "P3": 0},
        "mode": "strictly read-only offline evidence recomputation",
        "artifact_id": 14279316541, "workflow_run": 43972365007, "direct_job": 133667526984,
        "ssh_job": {"id": 133667529467, "conclusion": "skipped"},
        "archive_bytes": len(archive), "archive_sha256": DIGEST,
        "input_file_count": len(manifest), "input_total_bytes": sum(m["bytes"] for m in manifest),
        "input_manifest": manifest, "zip_member_count": len(members),
        "zip_uncompressed_bytes": sum(m["bytes"] for m in members), "zip_members": members,
        "fixed_source_file_count": len(source_manifest), "fixed_source_manifest": source_manifest,
        "recorded_host": {"release": original["release"], "build": original["build"],
                          "architecture": original["architecture"], "powershell": runtime},
        "production_commands": command_records, "child_terminal_records": terminal_records,
        "fixture_receipt": fixture_receipt, "resources": resource_records, "cpu_counter_deltas": delta,
        "raw_log": {"bytes": len(log_raw), "sha256": hash_bytes(log_raw),
                    "capture_replay": {"name": replay, "passed": 1, "failed": 0, "ignored": 0,
                                       "filtered_out": 9,
                                       "test_evidence": evidence(paths[4], "Z test " + replay + " ... ok"),
                                       "result_evidence": evidence(paths[4], "test result: ok. 1 passed;")},
                    "python_lab": {"run": 111, "ok": 108, "skipped": 3, "failed": 0,
                                   "names": [{"name": row[1], "result": row[2]} for row in suite]}},
        "checks": CHECKS,
        "independent_recomputation": {
            "attempts": 2, "successful_attempts": 1, "failed_attempts": 1,
            "r1_failure": "review parser compared raw CRLF ok\\r with ok; originals were correct",
            "r1_preserved": ["recompute-attempt-r1.json", "recompute-failure-r1.stderr"],
            "r2_assertions": len(CHECKS), "r2_passed": len(CHECKS), "r2_failed": 0,
            "r2_git_read_commands": GIT_COMMANDS, "windows_API_executions": 0,
            "powershell_executions": 0, "cargo_executions": 0, "tests_executed": 0,
            "remote_operations": 0, "gui_operations": 0, "target_access": 0, "git_writes": 0,
            "chats_worktrees_subagents_created": 0, "CI_reruns_or_cancels": 0,
            "write_scope": str(OUT)},
        "scope_limits": [
            "Saved GitHub response snapshots/raw log only; no fresh remote GET.",
            "One Windows Server 2025 AMD64 runner, WindowsPowerShell 5.1.26100.33648.",
            "Capture replay is controlled authenticated routing, not actual Windows OpenSSH/default remote shell.",
            "Real Windows SSH remains UNRUN/HOLD; native GUI/other Windows versions/architectures/releases unsigned.",
            "Quality43972364934 not reviewed or signed; supplied snapshot in_progress.",
            "Independent CPU versus CIM difference is informational; CPU accuracy equality not certified."],
        "review_read_error": {"exit": 1, "stderr": "read-path-error-r1.stderr",
                              "corrected_path": "scripts/windows_monitor/owned_fixture.py",
                              "classification": "review-only path typo, not an evidence failure"},
        "parent_may_close_reviewer": True}
    (OUT / "receipt.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    rows = "".join(f"| {r['operation']} | {r['wire_ascii_bytes']} | {r['serialized_cmd_chars']} | "
                   f"{r['powershell_original_pid']} | 自然退出0 |\n" for r in command_records)
    report = f"""# Windows API 原件限定独立复核

结论：**APPROVE**。固定源码 `{SHA}`；**P0=0、P1=0、P2=0、P3=0**，未发现此范围内需整改的问题，故无缺陷触发／影响项。仅签已观察 Windows API 原件及指定 capture replay 的证据一致性。**父可关闭本复核者。**

- **41 个输入文件**：7 个外层原件＋34 个解压成员，合计 {result['input_total_bytes']:,} 字节；逐文件 SHA-256／长度在 `receipt.json`。ZIP 34 个唯一成员 CRC 全通过，与解压件逐字节相等；解压总计 {result['zip_uncompressed_bytes']:,} 字节，输入前后哈希不变。
- ZIP **46,825 字节**，SHA-256 `{DIGEST}`，等于用户给定 digest、保存的官方 artifact 元数据及 raw job 上传日志。artifact14279316541／workflow43972365007／指定源码 SHA 绑定一致；direct job133667526984 completed/success、SSH job133667529467 skipped。证据：`{evidence(paths[1], '"artifact":')}`、`{evidence(paths[3], '"headSha"')}`、`{evidence(paths[4], 'SHA256 digest of uploaded artifact')}`。
- 范围为 **Windows Server 2025／10.0.26100／AMD64，Windows PowerShell5.1.26100.33648**。本次只核对保存的官方响应与原日志，没有重新联网取证。

| 生产操作 | wire ASCII 字节 | cmd 序列化字符 | 原PowerShell PID | 清理前终态 |
| --- | ---: | ---: | ---: | --- |
{rows}
五类从固定 Git 生产 literal／PS1 原字节重算 UTF-16LE＋Base64；wire、部件／脚本哈希、cmd `/d /s /c` argv 与序列化哈希全相等，分别小于8000／8191上限。核对11个相关源码文件与固定提交／当前字节相等，未扩展为全产品源码复审。证据：`{evidence(ROOT / sources[3], 'pub(super) fn command')}`、`{evidence(ROOT / sources[0], 'def cmd_argv')}`及各 `*.assembly.json`／`*.wire.txt`／`*.receipt.json`。

五条原 child 回执均为 **retained_while_live=true、natural_terminal_before_cleanup=true、exit_code=0**；各 Job total=2、retained=2、complete census=true，original handle检查=3（包括direct handle，不代表3个进程），pending=0、active=0、pipes drained=true、errors=[]。main 六条 child 与分项逐项相等。fixture PID9920 stop后exit0、direct原handle已检查，pending／active=0、管道排空，stdout与fixture.json相等、stderr空。证据：`{evidence(CAP / 'probe.receipt.json', '"powershell_original_objects"')}`、`{evidence(CAP / 'fixture.receipt.json', '"terminal"')}`；语义仅定位 `{evidence(ROOT / sources[0], 'def drain')}`／`{evidence(ROOT / sources[0], 'def _finish')}`与 `{evidence(ROOT / sources[2], 'return 0 if stop.is_set() else 4')}`。

独立 before／after 对照覆盖 **3个稳定接口**（GUID＋LUID＋index＋名称）、**2个ready fixed卷**（GUID＋serial＋mount），完整集合相等，无遗漏；网络累计字节位于夹取区间，卷总容量相等，free／available位于保存容差内。capacity skip **仅豁免卷容量**，仍复核内存、wall-clock uptime／boot、三接口及CPU gauge。独立 CPU idle／kernel／user差值 `{delta}`，推导 **{cpu:.12f}%**，CIM两帧 **8%／1%**；不同采样窗口的差值仅信息性，未签CPU精度一致。证据：`{evidence(CAP / 'comparison.json', '"network_inventory"')}`、`{evidence(CAP / 'comparison.json', '"capacity_inventory"')}`、`{evidence(CAP / 'comparison.json', '"cpu_difference_is_informational"')}`。

生产process146行、socket62行，独立socket109行；fixture PID／名称／工作集25,767,936字节相等。**4个IPv4／IPv6 TCP Listen／UDP bound** 同时见于生产与独立集合；**2个connected-only TCP** 在独立表为CONNECTED_OR_OTHER且不在生产监听集合。证据：`{evidence(CAP / 'fixture.json', '"endpoints"')}`、`{evidence(CAP / 'independent.json', '"process"')}`、`{evidence(CAP / 'comparison.json', '"owned"')}`及原processes／sockets.stdout。

原job日志 **91,173字节**，SHA-256 `{hash_bytes(log_raw)}`，下载exit0／stderr0。逐名核对 **Python111 run＝108 ok＋3 skipped、0 failed**；`{replay}` 为 **1 passed／0 failed／0 ignored，9 filtered out**。证据：`{evidence(paths[4], 'Ran 111 tests')}`、`{evidence(paths[4], 'OK (skipped=3)')}`、`{evidence(paths[4], 'Z test ' + replay + ' ... ok')}`、`{evidence(paths[4], 'test result: ok. 1 passed;')}`。固定capture测试 `{evidence(ROOT / sources[4], 'async fn captured_windows_api_frames')}`证明这是受控认证peer的routing replay；不移签真实Windows SSH／默认远端shell／native GUI。

本次仅文件读取、只读Git与离线字节／集合复算。独立复算脚本 **2次尝试：r1因审查器CRLF结果匹配错误停止，原异常／中间回执保留；r2共{len(CHECKS)}项断言全通过**。这些是复算计数，不是Windows API或单测执行次数。另一次fixture路径拼写读取exit1的原stderr保存在 `read-path-error-r1.stderr`，已改读正确路径。**Cargo／target访问／PowerShell／测试重跑／真实远端／GUI／Git写／chat／worktree／subagent／CI rerun或cancel均0**，仅写本目录。

**未执行／未签**：Quality43972364934（已提供快照仍in_progress）、真实Windows OpenSSH、原生桌面、其他Windows版本／架构、发行与全产品验收。不重复父门禁／全量代码复核。
"""
    (OUT / "report.md").write_text(report)
    return {"conclusion": result["conclusion"], "input_file_count": len(manifest),
            "input_total_bytes": result["input_total_bytes"], "zip_member_count": len(members),
            "fixed_source_files": len(source_manifest), "independent_assertions_passed": len(CHECKS),
            "report": str(OUT / "report.md"), "receipt": str(OUT / "receipt.json")}


if __name__ == "__main__":
    try:
        result = main()
        output = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
        (OUT / "recompute-r2.stdout").write_text(output)
        (OUT / "recompute-r2.stderr").write_bytes(b"")
        print(output, end="")
    except BaseException:
        failure = traceback.format_exc()
        (OUT / "recompute-failure-r2.stderr").write_text(failure)
        (OUT / "recompute-attempt-r2-failed.json").write_text(
            json.dumps({"checks": CHECKS, "git_commands": GIT_COMMANDS},
                       ensure_ascii=False, indent=2) + "\n")
        raise
