# Windows API 原件限定独立复核

结论：**APPROVE**。固定源码 `5d2df2fc5ac8566fe11182b7f4337076296dfa54`；**P0=0、P1=0、P2=0、P3=0**，未发现此范围内需整改的问题，故无缺陷触发／影响项。仅签已观察 Windows API 原件及指定 capture replay 的证据一致性。**父可关闭本复核者。**

- **41 个输入文件**：7 个外层原件＋34 个解压成员，合计 357,443 字节；逐文件 SHA-256／长度在 `receipt.json`。ZIP 34 个唯一成员 CRC 全通过，与解压件逐字节相等；解压总计 205,780 字节，输入前后哈希不变。
- ZIP **46,825 字节**，SHA-256 `b2afa96f9ada2ae38d8e1d21b8b05587db512da3b43f0ba4ae071aa0a2914af9`，等于用户给定 digest、保存的官方 artifact 元数据及 raw job 上传日志。artifact14279316541／workflow43972365007／指定源码 SHA 绑定一致；direct job133667526984 completed/success、SSH job133667529467 skipped。证据：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-monitor-ci-20261117/direct-api-artifact-download-r1.json:17`、`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-monitor-ci-20261117/run-43972365007-latest.json:5`、`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-monitor-ci-20261117/job-133667526984.log:1003`。
- 范围为 **Windows Server 2025／10.0.26100／AMD64，Windows PowerShell5.1.26100.33648**。本次只核对保存的官方响应与原日志，没有重新联网取证。

| 生产操作 | wire ASCII 字节 | cmd 序列化字符 | 原PowerShell PID | 清理前终态 |
| --- | ---: | ---: | ---: | --- |
| probe | 3778 | 3817 | 6672 | 自然退出0 |
| resources | 7954 | 7993 | 1568 | 自然退出0 |
| processes | 4394 | 4433 | 3452 | 自然退出0 |
| sockets | 4762 | 4801 | 3324 | 自然退出0 |
| resources-skipped | 7954 | 7993 | 2308 | 自然退出0 |

五类从固定 Git 生产 literal／PS1 原字节重算 UTF-16LE＋Base64；wire、部件／脚本哈希、cmd `/d /s /c` argv 与序列化哈希全相等，分别小于8000／8191上限。核对11个相关源码文件与固定提交／当前字节相等，未扩展为全产品源码复审。证据：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/windows.rs:83`、`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor_lab.py:1029`及各 `*.assembly.json`／`*.wire.txt`／`*.receipt.json`。

五条原 child 回执均为 **retained_while_live=true、natural_terminal_before_cleanup=true、exit_code=0**；各 Job total=2、retained=2、complete census=true，original handle检查=3（包括direct handle，不代表3个进程），pending=0、active=0、pipes drained=true、errors=[]。main 六条 child 与分项逐项相等。fixture PID9920 stop后exit0、direct原handle已检查，pending／active=0、管道排空，stdout与fixture.json相等、stderr空。证据：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-monitor-ci-20261117/direct-artifact-r1/probe.receipt.json:38`、`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-monitor-ci-20261117/direct-artifact-r1/fixture.receipt.json:4`；语义仅定位 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor_lab.py:342`／`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor_lab.py:396`与 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor/owned_fixture.py:70`。

独立 before／after 对照覆盖 **3个稳定接口**（GUID＋LUID＋index＋名称）、**2个ready fixed卷**（GUID＋serial＋mount），完整集合相等，无遗漏；网络累计字节位于夹取区间，卷总容量相等，free／available位于保存容差内。capacity skip **仅豁免卷容量**，仍复核内存、wall-clock uptime／boot、三接口及CPU gauge。独立 CPU idle／kernel／user差值 `[158750000, 177031250, 20468750]`，推导 **19.620253164557%**，CIM两帧 **8%／1%**；不同采样窗口的差值仅信息性，未签CPU精度一致。证据：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-monitor-ci-20261117/direct-artifact-r1/comparison.json:24`、`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-monitor-ci-20261117/direct-artifact-r1/comparison.json:58`、`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-monitor-ci-20261117/direct-artifact-r1/comparison.json:84`。

生产process146行、socket62行，独立socket109行；fixture PID／名称／工作集25,767,936字节相等。**4个IPv4／IPv6 TCP Listen／UDP bound** 同时见于生产与独立集合；**2个connected-only TCP** 在独立表为CONNECTED_OR_OTHER且不在生产监听集合。证据：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-monitor-ci-20261117/direct-artifact-r1/fixture.json:4`、`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-monitor-ci-20261117/direct-artifact-r1/independent.json:152`、`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-monitor-ci-20261117/direct-artifact-r1/comparison.json:2`及原processes／sockets.stdout。

原job日志 **91,173字节**，SHA-256 `56c1af39793f33761dc662bf5c1b6ad4bbb4f5d03f57926486891a7754324be6`，下载exit0／stderr0。逐名核对 **Python111 run＝108 ok＋3 skipped、0 failed**；`captured_windows_api_frames_are_accepted_through_authenticated_monitor_routing` 为 **1 passed／0 failed／0 ignored，9 filtered out**。证据：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-monitor-ci-20261117/job-133667526984.log:460`、`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-monitor-ci-20261117/job-133667526984.log:462`、`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-monitor-ci-20261117/job-133667526984.log:972`、`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-monitor-ci-20261117/job-133667526984.log:974`。固定capture测试 `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/windows_monitor.rs:687`证明这是受控认证peer的routing replay；不移签真实Windows SSH／默认远端shell／native GUI。

本次仅文件读取、只读Git与离线字节／集合复算。独立复算脚本 **2次尝试：r1因审查器CRLF结果匹配错误停止，原异常／中间回执保留；r2共102项断言全通过**。这些是复算计数，不是Windows API或单测执行次数。另一次fixture路径拼写读取exit1的原stderr保存在 `read-path-error-r1.stderr`，已改读正确路径。**Cargo／target访问／PowerShell／测试重跑／真实远端／GUI／Git写／chat／worktree／subagent／CI rerun或cancel均0**，仅写本目录。

**未执行／未签**：Quality43972364934（已提供快照仍in_progress）、真实Windows OpenSSH、原生桌面、其他Windows版本／架构、发行与全产品验收。不重复父门禁／全量代码复核。
