# Windows monitor oracle omission fix — 2026-11-17

Implementation is ready for the parent's narrow Gauss review. The complete
current offline Python suite is **111 passed / 0 failed / 0 skipped, exit 0**.
This report does not sign actual Windows API execution or Windows ABI,
cmd/PowerShell admission, real SSH, native GUI, Rust integration or release.
Parent owns the final concentrated gate and independent approval.

## Scope and reviewable inputs

The only implementation/documentation edits are:

- `scripts/windows_monitor_lab.py`
- `scripts/test_windows_monitor_lab.py`
- `scripts/windows_monitor/README.md` (13 explanatory lines)

All local evidence and baseline copies are in this directory. No Cargo,
target access, Git command, other production-source edit, actual remote
operation, SSH scope expansion, new worktree or application launch occurred.
The parent-owned SSH channel cancellation work was not touched.

`oracle-fix.diff` is a unified comparison against the exact saved pre-edit
files, generated using Python `difflib`, without Git. `final-manifest.json`
binds the delivered files:

| File | SHA256 |
| --- | --- |
| `scripts/windows_monitor_lab.py` | `9158fa37a0f0e7cab6a7208770ad3ffe23322247f9ddfa6105b758429580c327` |
| `scripts/test_windows_monitor_lab.py` | `32efa9d8c3e0c0d0e9799ec1bc629d9fd164cee1e72e9efb5ad6c557363c29e0` |
| `scripts/windows_monitor/README.md` | `5f340efe4800d4784f9fe70e5b44728eaf4537125116c0547d934d203c5c2413` |

Required AGENTS/RTK, HANDOFF, ADR0156, integration CONTRACT/lab report,
independent r1 interim review and original omission-control script were read.
Current contracts and actual source govern this implementation.

## Change and invariants

The disk oracle no longer accepts production mounts. Both calls in
`direct_gate` use `oracle.resources()` with no arguments. Independent
`GetLogicalDriveStringsW`/`GetDriveTypeW` enumeration selects local fixed roots.
`GetVolumeInformationW` checks readiness and observes a serial;
`GetVolumeNameForVolumeMountPointW` observes the volume GUID; capacity remains
three independent `GetDiskFreeSpaceExW` outputs. The reader avoids removable,
optical, RAM and network drives. Thread critical-error dialog suppression is
temporary and its original mode must be restored.

For networks, independent `GetAdaptersAddresses` enumeration selects the
IP-enabled inventory. It uses AF_UNSPEC and INCLUDE_WINS/INCLUDE_GATEWAYS,
without INCLUDE_ALL_INTERFACES; requiring every extra non-IP MIB row would be
an invalid coverage expectation for the production .NET collector. The oracle
joins that independent LUID set with `GetIfTable2`, retaining interface
GUID/LUID/index, alias and byte counters. A disappearing member between the
two native calls cannot become a successful partial inventory.

`resource_coverage` requires every before/after stable identity to appear in
production. Matching row counts are insufficient: each required name/root is
checked, along with its independent identity bracket and metrics. Missing all
rows, missing only one stable row and substituting a same-count different
resource fail. Inventory order and Windows drive-root casing do not affect
coverage. Parser acceptance of complete legal empty arrays is unchanged.
If both independent inventories are genuinely empty, empty production rows
remain a valid comparison.

Interface rename, GUID/LUID/index replacement, added/removed interfaces,
counter reset, volume replacement or resizing and incomplete/ambiguous
identity observations produce HOLD. Stable omissions are checked even when
another resource appears or disappears. Known not-ready fixed roots are
recorded as such, rather than invented as ready resources. Access/identity/
capacity failures retain incomplete evidence and cannot sign full capacity.
Raw independent before/after evidence is saved before comparison, including
on omission/churn failure.

The fixed capacity-skipped variant bypasses capacity only. It still checks
network coverage, counters, memory, uptime and CPU-counter validity. The
ordinary resource variant still makes typed capacity failure an overall HOLD
after core comparison and fixture terminal verification.

Production PowerShell files, wire format/parser, complete encoded cmd command,
GetIfTable2/IfRow and existing process/socket ABI declarations, original-object
terminal barrier, budgets and SSH prerequisite behavior are preserved.
Additional native declarations have not been executed on Windows.

## Executed evidence

Actual host: macOS 27.2.1, arm64; Python used `-B`.
All unit fixtures and child controls used temporary data inside this evidence
directory. The runner uses the existing owned-child lifecycle, a 45-second
absolute child budget within a 50-second outer budget, and a 2 MiB combined
output bound. Both commands completed naturally within the bound, with original
direct child reaped, zero active processes, pipes drained and no terminal
errors. No Windows API call was made.

| Run | Passed | Failed | Skipped | unittest time | Outer time | Actual exit | Terminal |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `omission-controls-baseline-r1` | 0 | 4 | 0 | 0.001 s | 0.142380 s | 1 | proven/reaped |
| `lab-unit-tests-r1` | 111 | 0 | 0 | 2.516 s | 2.663933 s | 0 | proven/reaped |

The baseline run loads the saved old lab and applies the four new all/partial
network/volume omission assertions. **All four fail with `LabError not
raised`**, proving that the old comparator accepted the omissions. They do
not fail because of import/setup errors. These same tests pass in the full
current suite because the corrected comparator rejects missing stable rows.

The complete current run is equivalent to:

```text
python3 -B -m unittest discover -s scripts -p test_windows_monitor_lab.py -v
```

Actual bounded invocation:

```text
python3 -B work/windows-monitor-oracle-fix-20261117/run-python-checks.py --label lab-unit-tests-r1
```

The 111 tests include the previous 70, identity-bearing inventory fixtures,
all/partial/equal-count substitution negatives, changes/replacement/reset HOLD
controls, capacity-skip/core controls, explicit legal empty frames, bounded
adapter enumeration/error paths, fake native-buffer readers, and direct-gate
routing with offline doubles. The latter checks no production mounts are
passed, real source assembly still occurs, omission fails and cleanup evidence
is retained. It is not actual cmd/PowerShell or Win32 execution.

Real-source assembly tests read all actual production `.ps1` files verbatim,
check UTF-16LE/Base64, fixed cmd argument and length limits, hashes, and the
fixed normal/skipped literal difference. Measured complete command bytes remain:
probe 3778; resources 7954; resources-skipped 7954; processes 4394; sockets 4762.

Each run directory contains `combined.log`, original `unittest.stdout`,
`unittest.stderr`, `unittest.receipt.json` and `summary.json`. Full per-test
names and results are retained. `baseline-manifest.json` and readback establish
that the original integration `lab-unit-tests-r1.log`, independent r1 interim
review, omission-control script and original control output remain byte-identical.
No r1 failure was overwritten.

## Outstanding acceptance and handoff

New Windows declarations, WCHAR/pointer/alignment behavior and the mapping
between native IP-enabled adapter enumeration, MIB identities and production
.NET aliases remain **UNVERIFIED on Windows**. Offline ctypes buffer/layout
tests validate Python logic on this macOS host, not Windows ABI. Any actual
unresolved identity/readiness or sampling ambiguity stays HOLD; no fallback
relaxes the comparison.

Actual Windows API/cmd execution, runner workflow, authenticated capture replay,
real Windows SSH, native desktop and release acceptance remain outside this
delivery. No SSH listener or remote action was introduced. Parent should give
Gauss the two delivered source hashes, `oracle-fix.diff`, both exact run
directories and this report for immediate narrow independent review, then
perform the parent-owned final concentrated gate.
