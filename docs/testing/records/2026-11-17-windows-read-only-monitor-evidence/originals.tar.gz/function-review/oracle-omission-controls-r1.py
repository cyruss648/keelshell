"""Reviewer-only synthetic omission controls; no native Windows claim."""
from pathlib import Path
import copy,json,sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'scripts'))
import windows_monitor_lab as lab

def main():
    data={"boot_time":"1000","uptime_seconds":10,"cpu_percent":None,
          "memory_total_bytes":"1073741824","memory_free_bytes":"536870912",
          "network_count":1,"networks":[{"name":"Ethernet","received_bytes":"101","transmitted_bytes":"201"}],
          "capacity_status":"ok","filesystem_count":1,"filesystems":[{"source":"C:\\","mount":"C:\\",
          "total_bytes":"1000000000","total_free_bytes":"600000000","available_bytes":"500000000"}]}
    before={"memory_total_bytes":1073741824,"memory_free_bytes":536870910,"boot_unix":1000,"uptime_seconds":9,
            "networks":[{"name":"Ethernet","received_bytes":100,"transmitted_bytes":200}],"filesystems":[]}
    after=copy.deepcopy(before);after.update(uptime_seconds=12,memory_free_bytes=536870914)
    after["networks"][0].update(received_bytes=102,transmitted_bytes=202)
    after["filesystems"]=[{"mount":"C:\\","total_bytes":1000000000,"total_free_bytes":600000000,"available_bytes":500000000}]
    results=[]
    for name,field,count in [("omitted_all_networks","networks","network_count"),("omitted_all_fixed_volumes","filesystems","filesystem_count")]:
        candidate=copy.deepcopy(data);candidate[field]=[];candidate[count]=0
        lab.validate_data("resources",candidate)
        try:
            comparison=lab.compare_resources(candidate,before,after,[10,20,20],[15,30,30])
            results.append({"control":name,"independent_rows":len(after[field]),"production_rows":0,
                            "comparison_accepted":True,"comparison":comparison})
        except lab.LabError as error:
            results.append({"control":name,"comparison_accepted":False,"reason":str(error)})
    print(json.dumps({"scope":"synthetic offline omission controls only; Windows API executions=0","controls":results},indent=2))

if __name__=="__main__":main()
