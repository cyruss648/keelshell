"""Independent synthetic before/after controls; zero native Windows executions."""

import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "scripts"))
import windows_monitor_lab as repaired

baseline_path = OUT / "source-snapshot-r1/scripts/windows_monitor_lab.py"
spec = importlib.util.spec_from_file_location("review_original_lab", baseline_path)
original = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = original
spec.loader.exec_module(original)


def example():
    networks = [
        {"name": name, "received_bytes": 100 + index, "transmitted_bytes": 200 + index,
         "interface_index": index + 1, "interface_luid": index + 100,
         "interface_guid": f"00000000-0000-0000-0000-{index + 1:012d}"}
        for index, name in enumerate(("Ethernet", "本地网络"))
    ]
    volumes = [
        {"mount": mount, "total_bytes": 1_000_000_000, "total_free_bytes": 600_000_000,
         "available_bytes": 500_000_000, "volume_serial": index + 1,
         "volume_guid": f"\\\\?\\Volume{{00000000-0000-0000-0000-{index + 1:012d}}}\\"}
        for index, mount in enumerate(("C:\\", "D:\\"))
    ]
    before = {
        "memory_total_bytes": 1_073_741_824, "memory_free_bytes": 536_870_912,
        "boot_unix": 1000, "uptime_seconds": 9,
        "networks": networks, "filesystems": volumes, "capacity_issues": [],
    }
    after = copy.deepcopy(before)
    after["uptime_seconds"] = 12
    for row in after["networks"]:
        row["received_bytes"] += 2
        row["transmitted_bytes"] += 2
    data = {
        "boot_time": "1000", "uptime_seconds": 10, "cpu_percent": None,
        "memory_total_bytes": "1073741824", "memory_free_bytes": "536870912",
        "network_count": 2,
        "networks": [
            {"name": row["name"], "received_bytes": str(row["received_bytes"] + 1),
             "transmitted_bytes": str(row["transmitted_bytes"] + 1)}
            for row in networks
        ],
        "capacity_status": "ok", "filesystem_count": 2,
        "filesystems": [
            {"source": row["mount"], "mount": row["mount"],
             **{field: str(row[field]) for field in
                ("total_bytes", "total_free_bytes", "available_bytes")}}
            for row in volumes
        ],
    }
    return data, before, after


def alter(label, data, before, after):
    if label in ("all_networks_omitted", "partial_network_omission"):
        data["networks"] = [] if label.startswith("all") else data["networks"][:1]
        data["network_count"] = len(data["networks"])
    elif label in ("all_volumes_omitted", "partial_volume_omission"):
        data["filesystems"] = [] if label.startswith("all") else data["filesystems"][:1]
        data["filesystem_count"] = len(data["filesystems"])
    elif label.startswith("capacity_skipped"):
        data.update(capacity_status="skipped", filesystems=[], filesystem_count=0)
        if label.endswith("network_omission"):
            data.update(networks=[], network_count=0)
    elif label == "honest_stable_empty":
        data.update(networks=[], network_count=0, filesystems=[], filesystem_count=0)
        for sample in (before, after):
            sample.update(networks=[], filesystems=[])
    elif label == "network_identity_replaced":
        after["networks"][0]["interface_luid"] += 1000
    elif label == "volume_identity_replaced":
        after["filesystems"][0]["volume_serial"] += 1000
    elif label == "capacity_evidence_incomplete":
        after["capacity_issues"] = [{"mount": "E:\\", "reason": "readiness_unconfirmed"}]


expected = {
    "honest_full": "PASS",
    "all_networks_omitted": "FAIL",
    "partial_network_omission": "FAIL",
    "all_volumes_omitted": "FAIL",
    "partial_volume_omission": "FAIL",
    "capacity_skipped": "PASS",
    "capacity_skipped_network_omission": "FAIL",
    "honest_stable_empty": "PASS",
    "network_identity_replaced": "HOLD",
    "volume_identity_replaced": "HOLD",
    "capacity_evidence_incomplete": "HOLD",
}
results = []
for label, required in expected.items():
    data, before, after = example()
    alter(label, data, before, after)
    states = {}
    for name, module in (("original", original), ("repaired", repaired)):
        module.validate_data("resources", data)
        try:
            comparison = module.compare_resources(
                data, before, after, [10, 20, 20], [15, 30, 30])
            states[name] = {"status": "PASS", "comparison": comparison}
        except module.Hold as error:
            states[name] = {"status": "HOLD", "reason": str(error)}
        except module.LabError as error:
            states[name] = {"status": "FAIL", "reason": str(error)}
    assert states["repaired"]["status"] == required, (label, states)
    if required == "FAIL":
        assert states["original"]["status"] == "PASS", (label, states)
    results.append({
        "case": label, "expected_repaired": required, "observed": states,
        "production_counts": [len(data["networks"]), len(data["filesystems"])],
        "independent_before_counts": [len(before["networks"]), len(before["filesystems"])],
        "independent_after_counts": [len(after["networks"]), len(after["filesystems"])],
    })

print(json.dumps({
    "scope": "Reviewer-authored synthetic controls only, not Windows API or SSH acceptance",
    "cases": len(results), "all_expected_outcomes": True,
    "omission_cases_rejected": sum(item["expected_repaired"] == "FAIL" for item in results),
    "honest_or_skip_success_cases": sum(item["expected_repaired"] == "PASS" for item in results),
    "uncertain_inventory_hold_cases": sum(item["expected_repaired"] == "HOLD" for item in results),
    "independent_compilations": 0, "windows_api_executions": 0,
    "sources": [
        {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
        for path in (baseline_path, ROOT / "scripts/windows_monitor_lab.py", Path(__file__).resolve())
    ],
    "results": results,
}, ensure_ascii=False, indent=2))
