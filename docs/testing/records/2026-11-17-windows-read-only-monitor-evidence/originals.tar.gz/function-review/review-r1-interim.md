# Windows monitor independent function/UI and lab review — r1 interim

Decision: REQUEST_CHANGES (r1); r2 prebuilt functional rerun pending. No final product, native Windows or GUI acceptance.

Baseline HEAD: `4209e272260aff6374e6216423ce8e0157bea2f4`, plus uncommitted Windows monitor changes. Reviewer writes only this directory; independent Cargo/build/fmt/clean count = 0. No target writes, source edits, production profile, Git writes or real remote operations.

## Reproduced additional finding

**[P2] Resource oracle accepts omitted interface/volume inventories.**

- `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/windows_monitor_lab.py:779`: network checks only iterate `data["networks"]`; empty or omitted members never require a corresponding stable independent row.
- Same file `:788`: volume checks only iterate `data["filesystems"]`; an explicit empty success gets no volume assertion.
- Same file `:878`: independent disk reads receive only production-reported mounts, so a missing volume cannot enter the comparison at all.
- Trigger/impact: production reports count=0 and an empty resource array (or drops a stable member) while independent APIs observed those resources. The resource comparison still succeeds and direct-gate can return PASS. This is an oracle blind spot, not evidence that current collector scripts actually omit data, and not a request to reject valid empty JSON at the production parser.
- Reproduction: `oracle-omission-controls-r1.py` calls unchanged production validation/comparison with two synthetic omission controls; both accepted. `oracle-omission-controls-r1.stdout.json` preserves inputs' independent/nonempty versus production/empty row counts and returned comparisons. Windows API execution count = 0.
- Suggested repair: independently enumerate fixed/ready local drive roots and stable interface identity sets, enforce appropriate before/after stable intersection or a known required resource, and assert omission negative controls fail. Keep the deliberate skipped-capacity variant exempt only for capacity, retain unknown CPU semantics and allow legitimate platform changes explicitly.

## Independent executed r1 evidence

Python: `python3 -B -m unittest discover -s scripts -p test_windows_monitor_lab.py -v` with PYTHONDONTWRITEBYTECODE=1 and TMPDIR/TMP/TEMP inside this review directory. **70 passed / 0 failed / 0 skipped**, exit 0; unittest 2.535s, outer 2.613557s. Log and receipt: `python-lab-tests-r1.*`.

Prebuilt: SHA256 `6d93ae7c43fe48219e716af7a64d77a3e7a678031c0b90382a6072942f643534`, 275704320 bytes. Independently hashed all 758 parent-frozen engineering inputs: zero mismatch, parent aggregate `8fb57190dce44f49d1398584cac96509eb075f419d6f5d2c2b69a77a2c7a6928`. Independent `--list` inventory = 1400 total / 101 monitor / 23 Windows; full name set matches parent.

Run: supplied exclusive prebuilt `monitor:: --test-threads=4`, with RUST_MIN_STACK=2097152, CARGO_MANIFEST_DIR set to app crate and isolated KEELSHELL_DATA_DIR/temp. **98 passed / 3 failed / 0 ignored**; Windows **21/2/0**, legacy monitor **77/1/0**. Exit **101**, elapsed **41.165920s**, original child reaped inside a 180s budget, no timeout. Full per-name stdout, stderr and independent receipt preserved as `app-monitor-r1.*`; `app-monitor-summary-r1.json` matches list and actual executed names.

Three failures independently reproduced (parent has announced fixes; not marked resolved yet):

1. `monitor::tests::capabilities::pausing_recheck_between_commands_cancels_unsent_ps_and_ss`: UI wait times out after 4s; held Linux fixture increments disk_samples only after permit release. Test synchronization defect; not proof of a production cancellation bug.
2. `monitor::tests::windows::unconfirmed_environment_stays_unknown_without_starting_windows_collectors`: environment-status assertion after pause overwrote status; `monitor_tests/windows.rs:1138` in the frozen r1 snapshot. Test ordering defect.
3. `monitor::tests::windows::windows_resource_negative_cache_retries_only_after_explicit_recheck`: disk sample count 2 rather than 1 at `monitor_tests/windows.rs:678`; confirmed Windows permission-denied resources retry before explicit recheck. P2 behavior mismatch with the agreed typed Windows negative-cache policy; POSIX transient-error behavior must be preserved.

## Static review and boundaries

Known source labels, provider CPU first sample/idle zero versus unavailable, history gaps, MCP cached sharing, independent facilities, read-only Windows actions, stale generation/connection authority, theme-token reuse and bilingual compact models have been examined. Source snapshots and exact SHA256 inventory are `source-snapshot-r1/` and `source-manifest-r1.json` (54 files; aggregate `96ed95dc85ab631dc3df44d9eeff9985cdef33bf464653cd545bdf143d7801cd`).

The cmd launcher uses the complete fixed UTF-16LE/Base64 command as one `/c` argument. Raw command output is stored before frame parsing; retained Job members and original process object signals gate cleanup. Capture replay checks receipt and files, and exercises the public monitor routing with controlled frames; it cannot establish real Windows SSH/default shell/authentication. Dispatch-only SSH prerequisite HOLD is intentional and is not itself a finding; no unsafe SSH enablement is requested.

Actual Windows ctypes/API, live cmd/PowerShell process proof, Windows ACL/key preflight, workflow execution, real Windows OpenSSH, native desktop/screenshots and releases remain UNVERIFIED. Prebuilt controlled SSH/model/geometry tests run on macOS and do not replace these acceptance layers. No independent compilation was performed. Final decision awaits corrected source binding, r2 prebuilt execution, and disposition of the resource oracle gap.
