# Windows monitor independent review — r2 functional checkpoint

R2 app/model/controlled-SSH functional scope: **APPROVE**, 101 passed / 0 failed / 0 ignored; Windows 23 and previous monitor groups 78. The overall feature/lab decision remains pending subsequent fixes. Independent compilations = 0.

Binary SHA256: `00b216a713b0526b2215b53b40ee457caae495569807af88a09c36d15ddef5bb`, size 275704800. Parent 758-input aggregate `bf7b4bec90c4e1fb9969281b04ceb2ad93d935f2637303fc4ac2b33ead374f77`; independent per-file verification zero mismatch. Independent --list = 1400 total, monitor 101, Windows 23; full names equal r1. All 101 actual executed names equal the independent selected list.

Execution: supplied exclusive r2 prebuilt, `monitor:: --test-threads=4`, RUST_MIN_STACK=2097152, CARGO_MANIFEST_DIR at the app crate, isolated KEELSHELL_DATA_DIR and TMPDIR/TMP/TEMP. Exit 0, 41.644672s outer elapsed, original PID 49430 reaped, 180s budget, no timeout. All stdout/stderr and bounded execution receipt remain under app-monitor-r2.*. R1 98/3/0 and exit101 remain unchanged.

Reviewed Rust r1→r2 deltas: Linux resource fixture increments its admission count before waiting on the held response; unknown-environment test checks the status before pausing; snapshot negative-cache routing retains typed Windows failures until explicit recheck without changing POSIX transient behavior; the session integration test adds a controlled permission-denied cache/age/clone/reset regression. README Chinese/English changes are documentation, not a Rust binary mismatch. Exact diffs are in reviewed-deltas/.

Resolved in this checkpoint: the r1 two fixture/order failures and Windows typed resource negative-cache mismatch. No extra app/model/UI P0/P1/P2/P3 finding in the r2 slice. Three theme families × light/dark × two languages × compact/large layout, source/unknown labels and local paging are controlled GPUI tests, not a real desktop acceptance.

Still pending, explicitly not signed by r2:

1. Reviewer oracle-omission P2, accepted by parent; Euler is changing only scripts/windows_monitor_lab.py and scripts/test_windows_monitor_lab.py. Follow-up will inspect exact delta and rerun affected offline controls/suite using -B and private logs.
2. Parent-reported P2 between SSH channel admission await and actual exec dispatch: session guarded-exec and delayed-admission regression are in progress. Await actual r3 source freeze and exclusive prebuilt, then independently execute relevant cancellation/authority regressions. No unnecessary repeat of unchanged full101 is planned.

Current review snapshot: 54 files, aggregate `0df459a146443ec24302f7668dd2377eebf8e80196f75a5c16fe8159dfda1ec5`, zero current drift when recorded. HEAD remains4209e272260aff6374e6216423ce8e0157bea2f4. Source-manifest-r2.json pins exact absolute paths and SHA256 values. Parent r2 results are not represented as independent session execution; independent app compilation, native Windows API, real Windows SSH, GUI/screenshots, full gate and release remain zero.
