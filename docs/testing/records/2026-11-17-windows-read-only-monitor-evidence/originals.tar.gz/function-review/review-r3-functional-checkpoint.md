# Windows monitor independent review — r3 functional checkpoint

R3 app/model/controlled-SSH functional scope: **APPROVE**. Independent app
monitor execution is **101 passed / 0 failed / 0 ignored**, Windows 23 and
previous monitor groups 78. The routing default suite is **9 passed / 0 failed /
1 ignored**. Independent compilations remain **0**. This checkpoint does not
close the separately changing Python oracle or sign a final engineering freeze.

The supplied exclusive app binary is
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-monitor-integration-20261117/prebuilt-review-function-r3/keelshell_app-b346129c444bf193`,
SHA256 `650e7cff27a4245773bc99bc59f9cfe270bb497c3647e65912c3e2bfcfba8cb6`,
275754448 bytes. Independent `--list` is 1400 total names, monitor 101 and
Windows 23. Every one of the 101 selected names appears exactly once in the
execution output and passes. `monitor:: --test-threads=4` exits 0 in 41.425499s,
original PID 60451 reaped, 180s budget, no timeout or cleanup signal. List PID
60441 also exits 0 and is reaped. SHA matches before and after execution.

The supplied exclusive routing binary is
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-monitor-integration-20261117/prebuilt-review-function-r3/windows_monitor-a3c72accc572cd55`,
SHA256 `68a9b3f1c0af137799c0f8907cda05a1353ef1c9b409fe28c4948957b9494cea`,
21039136 bytes. The preserved independent `--list` contains 10 names; all 10
appear once in default execution. The suite exits 0 in 0.052642s, original PID
58286 reaped, 180s budget, no timeout. The following new regressions actually
executed and passed:

- `revoked_identity_channel_admission_never_dispatches_posix_or_windows_probe`
- `revoked_cached_collector_channel_admission_never_dispatches_any_read_operation`

`captured_windows_api_frames_are_accepted_through_authenticated_monitor_routing`
is explicitly ignored because genuine Windows lab frames are unavailable.
No real Windows API capture, real Windows SSH or remote termination is implied
by these controlled local SSH fixtures.

Both suites use `RUST_MIN_STACK=2097152`, the appropriate crate's
`CARGO_MANIFEST_DIR`, and reviewer-owned data/temp directories. Original
stdout, stderr, exact argv, environment overrides, SHA and bounded terminal
receipts are retained in `app-list-r3.*`, `app-monitor-r3.*`,
`routing-list-r3.*` and `routing-default-r3.*`. Name reconciliation is in
`app-monitor-summary-r3.json` and `routing-default-summary-r3.json`. R1 98/3/0
and r2 101/0/0 evidence remain unchanged.

Source binding uses the parent's 758-input intermediate r3 observation,
aggregate `0006bc3d1b511346897aceb3dabd5eb8c9d4b8916bcda7f1977fbc6e54a560d5`.
At the first observation all 758 members matched. Immediately before the app
run, the recheck found only `scripts/windows_monitor_lab.py` changed by the
authorized oracle implementer. All Rust/crate files, manifests and lockfile
still matched. This Python delta does not invalidate the Rust binary binding;
the aggregate is explicitly not the final engineering freeze.

Static inspection confirms a guard after awaited SSH channel admission and
before `channel.exec`, with unsent revoked requests returning cancellation.
Monitor read paths retain their post-response generation check. The Linux
termination path checks generation and review age before dispatch and retains
the real result of an already sent operation. The two passing delayed-admission
tests support closing the parent-reported channel-open P2 within this controlled
functional boundary. Source reviewer's independent static follow-up remains
separate.

The oracle omission P2 remains pending final lab/test changes and independent
re-execution. Native GUI/screenshots, actual Windows cmd/PowerShell/ctypes API
execution, genuine capture replay, real Windows SSH, workflow execution, full
gate and release acceptance remain unverified by this reviewer.
