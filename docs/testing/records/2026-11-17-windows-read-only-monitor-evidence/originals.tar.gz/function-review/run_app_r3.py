"""Independent bounded execution of the supplied exclusive app r3 prebuilt."""

import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time


ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
BIN = ROOT / "work/windows-monitor-integration-20261117/prebuilt-review-function-r3/keelshell_app-b346129c444bf193"
EXPECTED_SHA = "650e7cff27a4245773bc99bc59f9cfe270bb497c3647e65912c3e2bfcfba8cb6"
EXPECTED_BYTES = 275754448


def digest(path):
    return hashlib.file_digest(path.open("rb"), "sha256").hexdigest()


def save(name, value):
    path = OUT / name
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


inputs = json.loads((OUT / "parent-review-inputs-r3.json").read_text())
mismatches = []
for item in inputs["inputs"]:
    path = ROOT / item["path"]
    actual = digest(path) if path.is_file() else None
    if actual != item["sha256"]:
        mismatches.append({"path": item["path"], "expected": item["sha256"], "actual": actual})
rust_drift = [
    item for item in mismatches
    if item["path"].startswith("crates/") or item["path"].endswith(("Cargo.toml", "Cargo.lock"))
]
save("r3-input-recheck-before-app.json", {
    "parent_aggregate": inputs["aggregate_sha256"],
    "files_checked": len(inputs["inputs"]),
    "mismatches": mismatches,
    "rust_manifest_lock_mismatches": rust_drift,
    "scope": "Intermediate r3 observation, not final engineering freeze",
})
assert not rust_drift, rust_drift
assert BIN.stat().st_size == EXPECTED_BYTES
assert digest(BIN) == EXPECTED_SHA
save("app-binding-r3.json", {
    "binary": str(BIN),
    "sha256": EXPECTED_SHA,
    "bytes": EXPECTED_BYTES,
    "parent_receipt": str(OUT / "parent-review-prebuilt-r3.json"),
    "independent_compilations": 0,
})

for child in ("tmp", "runtime-r3"):
    (OUT / child).mkdir(exist_ok=True)
overrides = {
    "RUST_MIN_STACK": "2097152",
    "CARGO_MANIFEST_DIR": str(ROOT / "crates/keelshell-app"),
    "KEELSHELL_DATA_DIR": str(OUT / "runtime-r3"),
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": str(OUT / "tmp"),
    "TMP": str(OUT / "tmp"),
    "TEMP": str(OUT / "tmp"),
}
environment = dict(os.environ, **overrides)


def run(label, arguments, budget):
    argv = [str(BIN), *arguments]
    started = time.monotonic()
    timed_out = False
    signals = []
    with (OUT / f"{label}.stdout.log").open("xb") as stdout:
        with (OUT / f"{label}.stderr.log").open("xb") as stderr:
            process = subprocess.Popen(
                argv, cwd=ROOT, env=environment, stdout=stdout, stderr=stderr,
                start_new_session=True,
            )
            try:
                exit_code = process.wait(timeout=budget)
            except subprocess.TimeoutExpired:
                timed_out = True
                os.killpg(process.pid, signal.SIGTERM)
                signals.append("SIGTERM")
                try:
                    exit_code = process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    signals.append("SIGKILL")
                    exit_code = process.wait(timeout=5)
    receipt = {
        "argv": argv,
        "exit_code": exit_code,
        "elapsed_seconds": round(time.monotonic() - started, 6),
        "pid": process.pid,
        "original_process_reaped": process.returncode is not None,
        "timeout_seconds": budget,
        "timed_out": timed_out,
        "cleanup_signals": signals,
        "binary_sha256": digest(BIN),
        "independent_compilations": 0,
        "environment_overrides": overrides,
    }
    save(f"{label}.receipt.json", receipt)
    print(json.dumps({"label": label, **receipt}), flush=True)
    assert not timed_out and exit_code == 0, receipt
    assert receipt["binary_sha256"] == EXPECTED_SHA
    return receipt


run("app-list-r3", ["--list"], 45)
inventory = [
    match[1]
    for line in (OUT / "app-list-r3.stdout.log").read_text().splitlines()
    if (match := re.fullmatch(r"(.+): test", line))
]
selected = [name for name in inventory if "monitor::" in name]
windows = [name for name in selected if "::windows::" in name]
assert (len(inventory), len(selected), len(windows)) == (1400, 101, 23)
receipt = run("app-monitor-r3", ["monitor::", "--test-threads=4"], 180)
observed = {}
for line in (OUT / "app-monitor-r3.stdout.log").read_text().splitlines():
    match = re.fullmatch(r"test (.+) \.\.\. (ok|FAILED|ignored)(?:,.*)?", line)
    if match:
        assert match[1] not in observed, match[1]
        observed[match[1]] = match[2]
assert set(observed) == set(selected)
passed = [name for name, state in observed.items() if state == "ok"]
failed = [name for name, state in observed.items() if state == "FAILED"]
ignored = [name for name, state in observed.items() if state == "ignored"]
summary = {
    "inventory_total": len(inventory),
    "inventory_monitor": len(selected),
    "inventory_windows": len(windows),
    "matched_executed_inventory": set(observed) == set(selected),
    "passed": len(passed),
    "failed": len(failed),
    "ignored": len(ignored),
    "windows_passed": len(set(windows) & set(passed)),
    "legacy_passed": len(set(passed) - set(windows)),
    "failed_names": failed,
    "ignored_names": ignored,
    "names": observed,
    "independent_compilations": 0,
    "execution_receipt": receipt,
}
save("app-monitor-summary-r3.json", summary)
print(json.dumps({key: value for key, value in summary.items() if key not in ("names", "execution_receipt")}), flush=True)
assert (len(passed), len(failed), len(ignored)) == (101, 0, 0)
