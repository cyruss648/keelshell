"""Reviewer-owned runner for the repaired offline Windows monitor lab suite."""

import ast
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import signal
import subprocess
import sys
import time


ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
LABEL = "python-lab-tests-oracle-r1"
PATHS = [
    "scripts/windows_monitor_lab.py",
    "scripts/test_windows_monitor_lab.py",
    "scripts/windows_monitor/owned_fixture.py",
    "scripts/windows_monitor/README.md",
    "scripts/windows_native_crash.py",
    ".github/workflows/windows-monitor.yml",
    *[
        str(path.relative_to(ROOT))
        for path in sorted((ROOT / "crates/keelshell-session/src/monitor/windows").glob("*.ps1"))
    ],
]


def hashes():
    return [
        {"path": str(ROOT / relative), "relative_path": relative,
         "bytes": (ROOT / relative).stat().st_size,
         "sha256": hashlib.sha256((ROOT / relative).read_bytes()).hexdigest()}
        for relative in PATHS
    ]


before = hashes()
snapshot = OUT / "source-snapshot-oracle-r1"
for item in before:
    destination = snapshot / item["relative_path"]
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(Path(item["path"]).read_bytes())
tree = ast.parse((ROOT / "scripts/test_windows_monitor_lab.py").read_text())
inventory = [
    f"test_windows_monitor_lab.{node.name}.{method.name}"
    for node in tree.body if isinstance(node, ast.ClassDef)
    for method in node.body
    if isinstance(method, ast.FunctionDef) and method.name.startswith("test_")
]
overrides = {
    "PYTHONDONTWRITEBYTECODE": "1",
    "TMPDIR": str(OUT / "tmp"),
    "TMP": str(OUT / "tmp"),
    "TEMP": str(OUT / "tmp"),
    "KEELSHELL_DATA_DIR": str(OUT / "runtime-python-oracle-r1"),
}
for name in ("tmp", "runtime-python-oracle-r1"):
    (OUT / name).mkdir(exist_ok=True)
argv = [sys.executable, "-B", "-m", "unittest", "discover",
        "-s", "scripts", "-p", "test_windows_monitor_lab.py", "-v"]
started = time.monotonic()
timed_out = False
signals = []
with (OUT / f"{LABEL}.stdout.log").open("xb") as stdout:
    with (OUT / f"{LABEL}.stderr.log").open("xb") as stderr:
        process = subprocess.Popen(argv, cwd=ROOT, env=dict(os.environ, **overrides),
                                   stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            exit_code = process.wait(timeout=120)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGTERM)
            signals.append("SIGTERM")
            try:
                exit_code = process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                signals.append("SIGKILL")
                exit_code = process.wait(timeout=5)
elapsed = round(time.monotonic() - started, 6)
combined = (
    (OUT / f"{LABEL}.stdout.log").read_bytes()
    + (OUT / f"{LABEL}.stderr.log").read_bytes()
)
(OUT / f"{LABEL}.log").write_bytes(combined)
text = combined.decode("utf-8", errors="replace")
observed = {
    match[1]: match[2]
    for line in text.splitlines()
    if (match := re.fullmatch(r"test_\S+ \((test_windows_monitor_lab\..+)\) \.\.\. (.+)", line))
}
run = re.search(r"^Ran (\d+) tests? in ([0-9.]+)s$", text, re.MULTILINE)
after = hashes()
receipt = {
    "argv": argv,
    "cwd": str(ROOT),
    "host": platform.platform(),
    "python": sys.version,
    "exit_code": exit_code,
    "elapsed_seconds": elapsed,
    "unittest_seconds": float(run[2]) if run else None,
    "pid": process.pid,
    "original_process_reaped": process.returncode is not None,
    "timeout_seconds": 120,
    "timed_out": timed_out,
    "cleanup_signals": signals,
    "environment_overrides": overrides,
    "source_before": before,
    "source_after": after,
    "source_drift": before != after,
    "inventory_count": len(inventory),
    "reported_count": int(run[1]) if run else None,
    "matched_executed_inventory": set(inventory) == set(observed),
    "passed": sum(value == "ok" for value in observed.values()),
    "failed_or_error": sum(value in ("FAIL", "ERROR") for value in observed.values()),
    "skipped": sum(value.startswith("skipped") for value in observed.values()),
    "observed_names": observed,
    "independent_compilations": 0,
    "windows_api_executions": 0,
    "windows_abi": "UNVERIFIED: host mocks and conditional Windows layout assertions are distinct",
}
(OUT / f"{LABEL}.receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({
    key: value for key, value in receipt.items()
    if key not in ("source_before", "source_after", "observed_names", "environment_overrides", "python")
}, indent=2))
assert not timed_out and exit_code == 0
assert before == after, "Source changed during this observation; retain evidence and recheck the delta."
assert run and int(run[1]) == len(inventory) == len(observed)
assert set(inventory) == set(observed)
assert all(value == "ok" for value in observed.values())
