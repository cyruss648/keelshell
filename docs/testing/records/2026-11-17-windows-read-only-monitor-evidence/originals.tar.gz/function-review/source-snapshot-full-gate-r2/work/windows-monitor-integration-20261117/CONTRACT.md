# Windows monitor integration contract — 2026-11-17

Base: `4209e272260aff6374e6216423ce8e0157bea2f4`. Shared checkout,
disjoint file ownership, no agent Cargo/target access or commits. Parent owns
session public types/routing, final integration/gates/docs and Git delivery.
Existing Linux/Darwin collectors and authorization remain intact.

## Public session types (parent implementation)

- `MonitorPlatform::{Linux,Darwin,Windows}`.
- `CpuSample::{Unavailable,Counters(CpuCounters),ReportedPercent(f64)}`, with
  `cumulative(&self)->Option<&CpuCounters>` and
  `reported_percent(&self)->Option<f64>`; no fabricated Windows ticks.
- `Snapshot.cpu: CpuSample`, `.load_average: Option<[f64;3]>`; remaining fields
  preserved. Windows uptime is a CIM system clock estimate; network rates
  remain unknown although actual cumulative bytes are present.
- `ProcessInfo.user: Option<String>`, `.cpu_percent: Option<f64>`,
  `.memory_percent: Option<f64>`, `.working_set_bytes: Option<u64>`;
  `.pid: u32` and `.command: String` preserved. Windows command is ProcessName,
  not a command line. Windows PID 0 may be an observed process, never actionable.
- `MonitorRuntime::{Posix,WindowsPowerShell{version:[u32;4]}}`,
  `MonitorEnvironment { platform: MonitorPlatform, runtime: MonitorRuntime }`.
- `MonitorCapabilities.environment: Option<MonitorEnvironment>` participates in
  the same authenticated connection/generation/revision as facility results.
- `MonitorError::Cancelled` means this collection's authority was revoked.
  `MonitorError::EnvironmentUnconfirmed` leaves both platform and runtime unknown.

## Private Windows module APIs (collector agent)

Own only `crates/keelshell-session/src/monitor/windows.rs` and the
`crates/keelshell-session/src/monitor/windows/` subtree (PS scripts + tests).
Parent registers the module and adapts existing Unix construction sites/tests.

```rust
pub(super) enum Operation { Probe, Resources { skip_capacity: bool }, Processes, Sockets }
pub(super) fn command(operation: Operation) -> MonitorResult<String>;
pub(super) fn parse_probe(output: ExecOutput) -> MonitorResult<[u32; 4]>;
pub(super) fn parse_resources(output: ExecOutput) -> MonitorResult<(Snapshot, CapabilityState)>;
pub(super) fn parse_processes(output: ExecOutput) -> MonitorResult<Vec<ProcessInfo>>;
pub(super) fn parse_sockets(output: ExecOutput) -> MonitorResult<Vec<SocketInfo>>;
```

Always fixed `powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand`
with UTF-16LE Base64, no user interpolation. Entire command must fit below 8000
ASCII bytes (cmd default shell limit). Scripts themselves need explicit array
wrapping, Console UTF-8, typed fixed error frames, bounded counts and no raw
diagnostic echo. Required script files: probe.ps1, resources.ps1, processes.ps1,
sockets.ps1; a common prefix is allowed. Agent reports exact assembly rules for
the independent Windows lab before final delivery.

Envelope JSON (all fields required; deny unknown/duplicate keys):

```json
{"version":1,"operation":"resources","platform":"Windows","runtime":"WindowsPowerShell","runtime_version":"5.1.26100.123","units":"bytes seconds percent","status":"ok","data":{}}
```

Other `operation` values: probe/processes/sockets. `status`: ok,
command_missing, permission_denied, command_failed, unsupported_options.
Error envelope has `data:null` and nonzero exit; success requires exit 0 and a
complete single frame, empty stderr, bounded combined output. Absent exit, bad
frame, trailing garbage, invalid units/runtime/version, duplicates, overflow or
truncation fail closed. LF/CRLF permitted; unrelated whitespace/banners are not.
No dependence on localized stderr for Windows classification.

Probe data: `{"os":"Win32NT"}`; only actual Desktop Windows PowerShell 5.1 is
in scope. Four numeric runtime version components, version[0..2] == [5,1].

Resources data: boot_time (canonical unsigned decimal string, Unix UTC seconds),
uptime_seconds (finite nonnegative JSON number), cpu_percent (finite 0..100 JSON
number or null), memory_total_bytes/memory_free_bytes (canonical u64 strings),
network_count (integer), networks array of
`{name,received_bytes,transmitted_bytes}`, capacity_status (ok/skipped or typed
failure above), filesystem_count and filesystems array of
`{source,mount,total_bytes,total_free_bytes,available_bytes}`.
All byte counters are canonical u64 decimal strings. Networks max 256; ready
fixed volumes max 512. Capacity failure leaves valid core resources intact;
skipped capacity is requested by fixed compile-time variant, not user content.
CPU: Win32_Processor.LoadPercentage, weighted by valid logical processor counts;
all unavailable samples -> null, partial provider data -> fail collection
rather than silently average a subset. Memory: Win32_OperatingSystem
TotalVisibleMemorySize/FreePhysicalMemory * 1024 with checked boundaries;
available/used remain unknown. Uptime: same CIM object's LocalDateTime minus
LastBootUpTime, explicitly a wall-clock estimate.
Networks: actual .NET GetIPStatistics cumulative bytes, no rate estimation.
DriveInfo TotalFreeSpace and AvailableFreeSpace stay distinct; used = total -
total_free, percentage computed from these bytes. Do not invent disk I/O/load.

Processes data: `{"count":N,"processes":[{"pid":"0","name":"Idle","working_set_bytes":null}]}`.
Get-Process, ProcessName and optional WorkingSet64 only; no owner lookup, command
line, process CPU seconds interpreted as percentage, or privilege escalation.
Canonical u32 PID strings, PID order, max 20000, duplicate PID rejected.

Sockets data: `{"count":N,"sockets":[{"protocol":"tcp","address":"127.0.0.1","port":"1234","pid":"4"}]}`.
Get-NetTCPConnection -State Listen and Get-NetUDPEndpoint. Both must complete
successfully, else entire sockets facility fails. Max 20000, numeric IPv4/IPv6
(scope IDs if explicit and validated), nonzero u16 port, canonical u32 PID.
Map TCP to LISTEN, UDP to BOUND, peer "*" (unknown, not a fabricated remote
endpoint), PID display metadata only. Full successful explicit empty array is
the only empty success. No probes, inspect or terminate on Windows.

All display strings bounded and reject control/escape text. No added registry
dependencies. Test legal/empty/singleton/Unicode/CRLF; duplicate keys/counts/IDs,
wrong units/operations, wide integers, malformed/truncated/oversize frames,
partial failures, unknown metrics, invalid addresses and command length.

## Parent routing/cache

Lazy deduplicated fixed POSIX identity probe first; if it cannot establish an
identity and transport completed, bounded Windows probe next. Both failure
means environment unconfirmed, not Windows/missing command. New session gets a
new cache, clones share, explicit reset clears identity and facility results.
Transport failures never negative-cache an unsupported platform. Generation is
checked before every SSH command and cache publication; stale probes cannot
restart a collector or populate reset state.

## App agent ownership (after parent dispatch)

Only app monitor files/tests, including monitor_view.rs/monitor_sockets.rs.
Adapt new types, both languages and three themes, gauge first sample/history
gaps, unknown fields, working set, platform/source labels and Linux action
guards. Add controlled SSH fixture routes for POSIX probe and Windows scripts.
Rendering/theme/language/paging remains zero SSH; new tests cover cancellation,
cached errors, socket-first, resource-failure-independent processes and all
themes/languages. Parent owns session fixtures outside app.

## Windows lab agent ownership

Only new scripts/windows_monitor_lab.py, scripts/test_windows_monitor_lab.py,
scripts/windows_monitor/ fixtures, and new
.github/workflows/windows-monitor.yml. Use actual production collectors on an
isolated Windows runner, with owned child process/TCP/UDP fixtures and bounded
cleanup/receipts. Direct API collection and real isolated OpenSSH are distinct
gates. Do not modify existing services/registry/firewall or use developer keys.
Missing/unsafe SSH setup -> explicit HOLD, not a synthetic success. The workflow
must not run on docs-only pushes and must preserve actual receipts on failure.
No existing CI/check.py edits. No Cargo/target access or claims of native GUI.
