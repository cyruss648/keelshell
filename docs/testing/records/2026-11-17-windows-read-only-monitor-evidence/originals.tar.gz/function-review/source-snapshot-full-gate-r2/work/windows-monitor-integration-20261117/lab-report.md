# Windows monitor lab delivery — 2026-11-17

Implemented the owned lab, fixtures, independent Win32 oracle and separate
Windows workflow. Final offline suite: **70 passed / 0 failed / 0 skipped,
exit 0, 2.512 seconds** on the actual macOS host. No local Windows commands,
Cargo, application, Git or target operations were executed. This report does
not sign Windows API, capture replay, real SSH, native GUI or release acceptance.
Files are ready for parent integration; no commit was made.

## Owned change paths

- `scripts/windows_monitor_lab.py`
- `scripts/test_windows_monitor_lab.py`
- `scripts/windows_monitor/__init__.py`
- `scripts/windows_monitor/owned_fixture.py`
- `scripts/windows_monitor/README.md`
- `.github/workflows/windows-monitor.yml`
- This report and `lab-unit-tests-r1.log`, `lab-unit-tests-r2.log`,
  `lab-unit-tests-r3.log` under `work/windows-monitor-integration-20261117/`.

No existing production collectors, existing lifecycle helper, CI, check.py,
Cargo manifests, Git state or target files were changed by this lab task.
The initial pending assembly manifest was removed after the production
`windows/ASSEMBLY.md` became available; there is no pending assembly override.

## Production assembly and actual shell path

The lab follows production `crates/keelshell-session/src/monitor/windows/ASSEMBLY.md`
verbatim: fixed operation prefix, `common.ps1`, fixed body file, then
`}catch{F (E $_) $null 1}` and LF. No separator insertion, normalization,
minification, user content or execution-policy override. UTF-16LE without BOM,
standard padded Base64 and the exact production PowerShell command prefix.
The fixed resources-with-capacity-skipped variant is also assembled and run
under a separate label.

The final local unit run read actual production files and recorded:

| Operation | Entire production command, ASCII bytes |
| --- | ---: |
| probe | 3778 |
| resources | 7954 |
| resources-skipped | 7954 |
| processes | 4394 |
| sockets | 4762 |

These are static command checks, **not a Windows cmd acceptance result**.
Every production collector in the Windows direct gate executes through actual
`cmd.exe /d /s /c <complete-production-command>`, with the complete command
preserved as the single `/c` argument. It does not bypass cmd using a direct
PowerShell argv launch. The receipt records shell, full argv, serialized command
line and length, production command length, root exit, raw stdout/stderr and
original PowerShell process evidence. The serialized launch is also checked
against 8191 characters.

## Owned fixtures, oracle and lifecycle

The short lived Python fixture holds IPv4 and IPv6 TCP LISTEN sockets, UDP
bindings, separate connected TCP client endpoints and resident memory. Fixture
readiness PID must match the original direct child, and all endpoints must be
loopback endpoints of that PID. Both connected client ports must appear in the
independent full TCP table as non-LISTEN and be absent from production listeners.

Independent readings use direct Win32 APIs:

- IP Helper `GetExtendedTcpTable` and `GetExtendedUdpTable`, IPv4 and IPv6;
  TCP native state 2 alone maps to LISTEN.
- Process image and working set from `OpenProcess`,
  `QueryFullProcessImageNameW`, `GetProcessMemoryInfo`.
- `GlobalMemoryStatusEx`, `GetTickCount64`, `GetSystemTimes`,
  `GetDiskFreeSpaceExW` and `GetIfTable2`.

Resource comparisons save their tolerances and both independent samples.
Memory visible/physical differences and changing free bytes have explicit
tolerances; cumulative interface counters must fall within the independent
bracket. Disk total/free/quota-available remain distinct. Independent CPU uses
a different sampling window, so its difference is informational and saved,
not an exact equality claim. Unknown production CPU remains null. Capacity
failure keeps raw core frames but makes the overall API gate HOLD.

Lifecycle implementation reuses `WindowsJob`, `Pump`, `finish_owned` and
deferred-interrupt handling from existing `scripts/windows_native_crash.py`.
Children are suspended, assigned to the owned Job, then resumed. The lab does
not copy the existing CreateProcess/Job implementation.

For cmd-launched production commands, the lab retains Job members during
execution and binds the PowerShell image to an original process handle while
live. Successful collection requires a complete historical admitted-process
census, exactly one identified production PowerShell process and that original
object's natural zero exit **before** cleanup. A missed short lived child,
unknown process image, missing object terminal, failed pipe drain, lost output,
timeout or cleanup failure cannot produce success. The existing terminal
barrier additionally requires retained original objects terminal, active Job
count zero, drained pipes and a reaped direct root within the original budget.
Pipe/channel closure supplies no PowerShell terminal proof.

## Capture and workflow integration

Fixed raw-byte capture paths inside the lab output directory:

- `probe.stdout`
- `resources.stdout`
- `processes.stdout`
- `sockets.stdout`

`resources-skipped.stdout` is additional. Each command also writes `.stderr`,
`.receipt.json`, `.assembly.json` and `.wire.txt`; fixture, independent readings,
comparison, runtime and final `receipt.json` are kept. OS/build/architecture,
Python, actual PS runtime/version and binary hash are recorded. Raw captures
are written before successful frame acceptance, so failing/truncated/error
output remains evidence and cannot silently become a replay input.

The independent `Windows monitor integration` workflow has two `windows-2025`
jobs, both using the existing `setup-build` action. Push/PR docs-only and
Markdown-only changes do not trigger it. The existing Quality workflow is
unchanged. Each job always uploads its own output directory, including failures.

After direct API acceptance the workflow runs the parent-owned target:

```text
KEELSHELL_WINDOWS_MONITOR_CAPTURE_DIR=<direct-output-directory>
cargo test --locked -p keelshell-session --test windows_monitor captured_windows_api_frames_are_accepted_through_authenticated_monitor_routing -- --ignored --exact --test-threads=1
```

The replay step uses `if: always()`. Missing/HOLD/failed direct API receipt or
missing raw files explicitly emits `CAPTURE_REPLAY_HOLD` and exits 78, rather
than silently skipping. That Rust command exists only in the new workflow;
it was not run locally. This gate is capture replay through the public
authenticated monitor route, not Windows SSH acceptance.

## Isolated OpenSSH boundary

The SSH job checks existing OpenSSH binary availability without installing,
starting, stopping or changing a service. If available, it prepares a new
private temporary directory with a protected inheritable DACL for the current
identity and SYSTEM, generates fresh host/client Ed25519 keys, reserves a
loopback high port, writes an explicit authorized-keys/configuration file and
runs owned, bounded `sshd -t -f <private-config>`. No developer key, default
authorized-keys file, registry or firewall change is involved. Private keys
remain outside the artifact output directory and are removed before the final
receipt; configuration checks and cleanup have separate receipts.

**Real SSH is HOLD and has no success path in this version.** No listener is
started and no authenticated remote command is claimed. Windows OpenSSH
token/broker descendant admission and original remote PowerShell terminal have
not been proven. Even successful config validation exits 78 for the SSH gate.
The workflow therefore deliberately cannot become a green full SSH acceptance
run with this implementation. A future reviewed admission/identity protocol is
required before enabling actual remote SSH acceptance. This does not block
the separately recorded direct API/capture gate from reporting its own result.

## Actual Python runs

All runs used only the new suite:

```text
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s scripts -p test_windows_monitor_lab.py -v
```

| Log | Result | unittest elapsed | Actual outer exit |
| --- | --- | ---: | ---: |
| `lab-unit-tests-r1.log` | 66 run, 65 passed, 1 failed, 0 skipped | 2.508s | 1 |
| `lab-unit-tests-r2.log` | 67 run, 67 passed, 0 failed, 0 skipped | 2.497s | 0 |
| `lab-unit-tests-r3.log` | 70 run, 70 passed, 0 failed, 0 skipped | 2.512s | 0 |

First failure was
`LifecycleTests.test_output_overflow_still_reaps_real_child`: the existing
bounded pump queue overflowed before the test's expected total-capture limit,
so the receipt correctly reported pipe loss rather than the single error
label expected by the test. Original-process cleanup was established. The
test now explicitly lowers the capture budget while remaining below the pump
queue size, so it deterministically covers that distinct capture limit. The
first failing log remains intact.

Full per-test names and results are preserved in the verbose logs. Relevant
named checks include:

- `AssemblyTests.test_actual_production_assembly_is_verbatim_and_below_limit`
- `AssemblyTests.test_exact_utf16le_base64_and_file_hash_binding`
- `AssemblyTests.test_fixed_skip_capacity_variant`
- `AssemblyTests.test_complete_production_command_is_one_actual_cmd_argument`
- `AssemblyTests.test_cmd_boundary_rejects_extra_text_and_oversize`
- `FrameTests.test_successful_probe_lf_crlf_and_no_newline`
- `FrameTests.test_empty_arrays_and_singletons`
- `FrameTests.test_unicode_process_and_network_names`
- `FrameTests.test_duplicate_top_level_key_rejected`
- `FrameTests.test_duplicate_nested_key_rejected`
- `FrameTests.test_noncanonical_and_overwide_pid_rejected`
- `FrameTests.test_nonfinite_json_rejected`
- `FrameTests.test_partial_capacity_failure_and_skip_preserve_core`
- `ComparisonTests.test_connected_tcp_is_never_a_listener`
- `ComparisonTests.test_connected_negative_control_must_exist_in_independent_table`
- `ComparisonTests.test_cumulative_network_bytes_must_be_bracketed`
- `LifecycleTests.test_real_child_preserves_raw_bytes_and_actual_exit`
- `LifecycleTests.test_stream_closure_does_not_prove_process_exit`
- `LifecycleTests.test_live_child_timeout_has_bounded_original_process_terminal`
- `LifecycleTests.test_parent_and_real_descendant_share_owned_cleanup`
- `LifecycleTests.test_real_dual_stack_fixture_and_natural_exit`
- `LifecycleTests.test_output_overflow_still_reaps_real_child`
- `LifecycleTests.test_evidence_preserves_fixed_capture_filename_bytes_and_receipt`
- `SafetyAndWorkflowTests.test_shell_process_proof_cannot_fall_back_to_posix`
- `SafetyAndWorkflowTests.test_cli_records_nonwindows_hold_without_running_commands`
- `SafetyAndWorkflowTests.test_workflow_replay_uses_exact_capture_and_cannot_silently_skip_hold`

## Remaining acceptance

Native Windows API execution, cmd/PowerShell original-object capture, Win32 ABI,
Windows ACL/key/config preflight, workflow execution and parent Rust capture
replay are **UNRUN locally**. The Windows-specific ctypes declarations and
identity tracking require the actual Windows runner; static/offline success
cannot substitute for it. Real OpenSSH is explicitly HOLD as above.
No runner result can sign native GUI acceptance; no desktop operations or
screenshots were performed. Parent owns concentrated compilation, integration,
final review, documentation, Git and subsequent cleanup.
