#!/usr/bin/env python3
"""Offline contract tests and actual host child controls, not Windows emulation."""

import base64
import copy
import ctypes
import json
import os
from pathlib import Path
import socket
import sys
import tempfile
import time
import unittest
from unittest import mock

import windows_monitor_lab as lab


def resource_data():
    return {"boot_time": "1000", "uptime_seconds": 10.5, "cpu_percent": None,
            "memory_total_bytes": "1073741824", "memory_free_bytes": "536870912",
            "network_count": 1, "networks": [{"name": "本地网络", "received_bytes": "101",
                                            "transmitted_bytes": "201"}],
            "capacity_status": "ok", "filesystem_count": 1, "filesystems": [{
                "source": "C:\\", "mount": "C:\\", "total_bytes": "1000000000",
                "total_free_bytes": "600000000", "available_bytes": "500000000"}]}


def frame(operation="probe", data=None):
    if data is None:
        data = {"probe": {"os": "Win32NT"}, "resources": resource_data(),
                "processes": {"count": 0, "processes": []},
                "sockets": {"count": 0, "sockets": []}}[operation]
    return {"version": 1, "operation": operation, "platform": "Windows",
            "runtime": "WindowsPowerShell", "runtime_version": "5.1.26100.123",
            "units": "bytes seconds percent", "status": "ok", "data": data}


def raw(value):
    return json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(",", ":")).encode("utf-8")


def fixture_value(pid=1234):
    return {"version": 1, "pid": pid, "endpoints": [
        {"protocol": protocol, "address": address, "port": str(40000 + index), "pid": str(pid)}
        for index, (protocol, address) in enumerate([
            ("tcp", "127.0.0.1"), ("udp", "127.0.0.1"), ("tcp", "::1"), ("udp", "::1")])],
        "connected_only": [{"protocol": "tcp", "address": address, "port": str(41000 + index),
                            "pid": str(pid)} for index, address in enumerate(("127.0.0.1", "::1"))]}


class FrameTests(unittest.TestCase):
    def parse(self, value, operation=None, suffix=b"", stderr=b"", code=0):
        return lab.parse_frame(raw(value) + suffix, stderr, code, operation or value["operation"])

    def test_successful_probe_lf_crlf_and_no_newline(self):
        for suffix in (b"", b"\n", b"\r\n"):
            with self.subTest(suffix=suffix):
                self.assertEqual(self.parse(frame(), suffix=suffix)["data"], {"os": "Win32NT"})

    def test_empty_arrays_and_singletons(self):
        for operation, key, singleton in (
            ("processes", "processes", {"pid": "0", "name": "Idle", "working_set_bytes": None}),
            ("sockets", "sockets", {"protocol": "udp", "address": "::1", "port": "65535", "pid": "0"}),
        ):
            for rows in ([], [singleton]):
                with self.subTest(operation=operation, rows=rows):
                    self.parse(frame(operation, {"count": len(rows), key: rows}))

    def test_unicode_process_and_network_names(self):
        self.parse(frame("resources"))
        self.parse(frame("processes", {"count": 1, "processes": [
            {"pid": "1", "name": "中文进程 α", "working_set_bytes": "18446744073709551615"}]}))

    def test_duplicate_top_level_key_rejected(self):
        payload = raw(frame()).replace(b'"version":1', b'"version":1,"version":1')
        with self.assertRaises(lab.LabError):
            lab.parse_frame(payload, b"", 0, "probe")

    def test_duplicate_nested_key_rejected(self):
        payload = raw(frame()).replace(b'"os":"Win32NT"', b'"os":"Win32NT","os":"Win32NT"')
        with self.assertRaises(lab.LabError):
            lab.parse_frame(payload, b"", 0, "probe")

    def test_unknown_field_wrong_operation_units_and_platform_rejected(self):
        for field, value in (("extra", 1), ("operation", "sockets"), ("platform", "Linux"),
                             ("runtime", "PowerShellCore"), ("units", "kilobytes"),
                             ("version", True), ("version", 2)):
            with self.subTest(field=field, value=value):
                item = frame()
                item[field] = value
                with self.assertRaises(lab.LabError):
                    self.parse(item, operation="probe")

    def test_invalid_runtime_versions_rejected(self):
        for version in ("7.1.1.1", "5.1", "5.1.1", "05.1.1.1", "5.1.01.1",
                        "5.1.4294967296.1", "5.1.1.1\n"):
            with self.subTest(version=version):
                item = frame()
                item["runtime_version"] = version
                with self.assertRaises(lab.LabError):
                    self.parse(item)

    def test_absent_nonzero_and_boolean_exits_rejected(self):
        for code in (None, 1, -1, True):
            with self.subTest(code=code):
                with self.assertRaises(lab.LabError):
                    self.parse(frame(), code=code)

    def test_stderr_invalid_utf8_and_bom_rejected(self):
        for payload, stderr in ((raw(frame()), b"warning"), (b"\xff", b""),
                                (b"\xef\xbb\xbf" + raw(frame()), b""),
                                (raw(frame()).replace(b"Win32NT", b"Win32\xffNT"), b"")):
            with self.subTest(payload=payload, stderr=stderr):
                with self.assertRaises(lab.LabError):
                    lab.parse_frame(payload, stderr, 0, "probe")

    def test_banners_trailing_space_extra_frame_and_truncation_rejected(self):
        valid = raw(frame())
        for payload in (b"banner\n" + valid, b" " + valid, valid + b" ", valid + b"\n\n",
                        valid + valid, valid + b"\nnoise", valid[:-1], b""):
            with self.subTest(payload=payload):
                with self.assertRaises(lab.LabError):
                    lab.parse_frame(payload, b"", 0, "probe")

    def test_combined_output_limit_rejected(self):
        with self.assertRaises(lab.LabError):
            lab.parse_frame(b"{" + b"x" * lab.MAX_FRAME, b"", 0, "probe")

    def test_all_typed_failures_are_non_success(self):
        for status in lab.FAILURES:
            for code in (0, 1):
                with self.subTest(status=status, code=code):
                    item = frame()
                    item.update(status=status, data=None)
                    with self.assertRaises(lab.LabError):
                        self.parse(item, code=code)

    def test_count_type_and_mismatch_rejected(self):
        for count in (1, -1, True, "0", 20001):
            with self.subTest(count=count):
                with self.assertRaises(lab.LabError):
                    self.parse(frame("processes", {"count": count, "processes": []}))

    def test_duplicate_or_unsorted_process_pids_rejected(self):
        for ids in (("1", "1"), ("2", "1")):
            rows = [{"pid": pid, "name": "python", "working_set_bytes": None} for pid in ids]
            with self.assertRaises(lab.LabError):
                self.parse(frame("processes", {"count": 2, "processes": rows}))

    def test_noncanonical_and_overwide_pid_rejected(self):
        for pid in ("01", "-1", "+1", "4294967296", "1.0", " 1", 1):
            with self.subTest(pid=pid):
                with self.assertRaises(lab.LabError):
                    self.parse(frame("processes", {"count": 1, "processes": [
                        {"pid": pid, "name": "python", "working_set_bytes": None}]}))

    def test_invalid_working_set_rejected(self):
        for value in ("18446744073709551616", "-1", 123, "00"):
            with self.subTest(value=value):
                with self.assertRaises(lab.LabError):
                    self.parse(frame("processes", {"count": 1, "processes": [
                        {"pid": "1", "name": "python", "working_set_bytes": value}]}))

    def test_control_escape_and_overlong_display_rejected(self):
        for name in ("a\x1b[31m", "a\n", "a\u0085", "a\u202e", "", "x" * 513):
            with self.subTest(name=name):
                with self.assertRaises(lab.LabError):
                    self.parse(frame("processes", {"count": 1, "processes": [
                        {"pid": "1", "name": name, "working_set_bytes": None}]}))

    def test_numeric_ipv4_ipv6_and_scopes(self):
        for address in ("127.0.0.1", "::1", "fe80::1%12", "::ffff:127.0.0.1"):
            with self.subTest(address=address):
                self.parse(frame("sockets", {"count": 1, "sockets": [
                    {"protocol": "tcp", "address": address, "port": "1", "pid": "4"}]}))

    def test_invalid_ip_scope_port_and_protocol_rejected(self):
        row = {"protocol": "tcp", "address": "::1", "port": "1", "pid": "4"}
        for field, value in (
            ("address", "localhost"), ("address", "127.0.0.1%2"), ("address", "::1%eth0"),
            ("address", "::1%0"), ("address", "::1%01"), ("address", "::1%4294967296"),
            ("address", "1.2.3.4/24"), ("port", "0"), ("port", "65536"), ("port", "01"),
            ("protocol", "established"), ("pid", "4294967296"),
        ):
            with self.subTest(field=field, value=value):
                with self.assertRaises(lab.LabError):
                    self.parse(frame("sockets", {"count": 1, "sockets": [{**row, field: value}]}))

    def test_duplicate_socket_rejected(self):
        row = {"protocol": "tcp", "address": "::1", "port": "1", "pid": "4"}
        with self.assertRaises(lab.LabError):
            self.parse(frame("sockets", {"count": 2, "sockets": [row, row]}))

    def test_unknown_cpu_is_preserved(self):
        result = self.parse(frame("resources"))
        self.assertIsNone(result["data"]["cpu_percent"])

    def test_partial_capacity_failure_and_skip_preserve_core(self):
        for status in lab.FAILURES | {"skipped"}:
            with self.subTest(status=status):
                data = resource_data()
                data.update(capacity_status=status, filesystems=[], filesystem_count=0)
                self.parse(frame("resources", data))

    def test_capacity_failure_cannot_carry_success_rows(self):
        data = resource_data()
        data["capacity_status"] = "permission_denied"
        with self.assertRaises(lab.LabError):
            self.parse(frame("resources", data))

    def test_invalid_resource_metrics_rejected(self):
        for field, value in (("boot_time", "01"), ("uptime_seconds", -1),
                             ("cpu_percent", 100.1), ("cpu_percent", True),
                             ("memory_total_bytes", "0"), ("memory_free_bytes", "1073741825"),
                             ("memory_total_bytes", "18446744073709551616"),
                             ("network_count", 0), ("filesystem_count", True),
                             ("capacity_status", "invented")):
            with self.subTest(field=field, value=value):
                data = resource_data()
                data[field] = value
                with self.assertRaises(lab.LabError):
                    self.parse(frame("resources", data))

    def test_nonfinite_json_rejected(self):
        for token in (b"NaN", b"Infinity", b"-Infinity", b"1e999"):
            payload = raw(frame("resources")).replace(b'"cpu_percent":null', b'"cpu_percent":' + token)
            with self.subTest(token=token):
                with self.assertRaises(lab.LabError):
                    lab.parse_frame(payload, b"", 0, "resources")

    def test_duplicate_network_and_filesystem_rejected(self):
        for rows, count in (("networks", "network_count"), ("filesystems", "filesystem_count")):
            data = resource_data()
            data[rows] *= 2
            data[count] = 2
            with self.assertRaises(lab.LabError):
                self.parse(frame("resources", data))

    def test_free_and_quota_available_are_distinct(self):
        result = self.parse(frame("resources"))
        disk = result["data"]["filesystems"][0]
        self.assertNotEqual(disk["total_free_bytes"], disk["available_bytes"])
        data = resource_data()
        data["filesystems"][0]["available_bytes"] = "600000001"
        with self.assertRaises(lab.LabError):
            self.parse(frame("resources", data))


class AssemblyTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="keelshell-monitor-assembly-test-")
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name)
        for name, text in (("common.ps1", "# 前缀\r\n"), ("probe.ps1", "# probe\n")):
            (self.directory / name).write_bytes(text.encode("utf-8"))

    def test_exact_utf16le_base64_and_file_hash_binding(self):
        command, evidence = lab.assemble("probe", self.directory)
        decoded = base64.b64decode(command[len(lab.POWERSHELL):]).decode("utf-16le")
        self.assertEqual(decoded, "$op='probe';$skip=$false;\n# 前缀\r\n# probe\n" + lab.SUFFIX)
        self.assertEqual(evidence["wire_command_ascii_bytes"], len(command))
        self.assertEqual([row["file"] for row in evidence["parts"]], ["common.ps1", "probe.ps1"])

    def test_fixed_skip_capacity_variant(self):
        (self.directory / "resources.ps1").write_bytes(b"# resources\n")
        command, _ = lab.assemble("resources-skipped", self.directory)
        decoded = base64.b64decode(command[len(lab.POWERSHELL):]).decode("utf-16le")
        self.assertTrue(decoded.startswith("$op='resources';$skip=$true;\n"))

    def test_unknown_operation_rejected(self):
        with self.assertRaises(lab.LabError):
            lab.assemble("arbitrary", self.directory)

    def test_path_escape_rejected(self):
        with self.assertRaises(lab.LabError):
            lab.assemble("../probe", self.directory)

    def test_missing_part_rejected(self):
        (self.directory / "common.ps1").unlink()
        with self.assertRaises(lab.LabError):
            lab.assemble("probe", self.directory)

    def test_wire_command_must_be_strictly_below_8000_bytes(self):
        (self.directory / "common.ps1").write_bytes(b"#" * 4000)
        with self.assertRaisesRegex(lab.LabError, "cmd.exe"):
            lab.assemble("probe", self.directory)

    def test_actual_production_assembly_is_verbatim_and_below_limit(self):
        for operation, (prefix, body) in lab.ASSEMBLY.items():
            with self.subTest(operation=operation):
                command, evidence = lab.assemble(operation)
                decoded = base64.b64decode(command[len(lab.POWERSHELL):]).decode("utf-16le")
                expected = prefix + (lab.COLLECTORS / "common.ps1").read_bytes().decode("utf-8")
                expected += (lab.COLLECTORS / body).read_bytes().decode("utf-8") + lab.SUFFIX
                self.assertEqual(decoded, expected)
                self.assertLess(evidence["wire_command_ascii_bytes"], 8000)
                print(f"PRODUCTION_COMMAND {operation} ascii_bytes={evidence['wire_command_ascii_bytes']}")

    def test_complete_production_command_is_one_actual_cmd_argument(self):
        for operation in lab.ASSEMBLY:
            command, _ = lab.assemble(operation)
            argv = lab.cmd_argv(command, r"C:\Windows\System32\cmd.exe")
            self.assertEqual(argv, [r"C:\Windows\System32\cmd.exe", "/d", "/s", "/c", command])
            self.assertLess(len(lab.subprocess.list2cmdline(argv)), 8191)

    def test_cmd_boundary_rejects_extra_text_and_oversize(self):
        for command in ("echo not-a-production-command", lab.POWERSHELL + "x" * 8000,
                        lab.POWERSHELL + "abc\n"):
            with self.assertRaises(lab.LabError):
                lab.cmd_argv(command, "cmd.exe")


class ComparisonTests(unittest.TestCase):
    def setUp(self):
        self.fixture = fixture_value()
        self.processes = {"count": 1, "processes": [
            {"pid": "1234", "name": "python", "working_set_bytes": "20000000"}]}
        self.native_process = {"pid": 1234, "name": "Python", "working_set_bytes": 21000000}
        self.sockets = {"count": 4, "sockets": copy.deepcopy(self.fixture["endpoints"])}
        self.native_sockets = [
            {**row, "state": "LISTEN" if row["protocol"] == "tcp" else "BOUND"}
            for row in self.fixture["endpoints"]
        ] + [{**row, "state": "CONNECTED_OR_OTHER"} for row in self.fixture["connected_only"]]

    def compare(self):
        return lab.compare_owned(self.fixture, self.processes, self.sockets,
                                 self.native_process, self.native_sockets)

    def test_owned_pid_endpoints_and_independent_apis_agree(self):
        result = self.compare()
        self.assertEqual(result["owned_endpoints_matched"], 4)
        self.assertEqual(result["connected_tcp_excluded"], 2)

    def test_connected_tcp_is_never_a_listener(self):
        self.sockets["sockets"].append(self.fixture["connected_only"][0])
        with self.assertRaisesRegex(lab.LabError, "connected TCP"):
            self.compare()

    def test_connected_negative_control_must_exist_in_independent_table(self):
        self.native_sockets = self.native_sockets[:4]
        with self.assertRaisesRegex(lab.LabError, "connected TCP"):
            self.compare()

    def test_production_listener_missing(self):
        self.sockets["sockets"].pop()
        with self.assertRaises(lab.LabError):
            self.compare()

    def test_independent_listener_missing(self):
        self.native_sockets.pop(0)
        with self.assertRaises(lab.LabError):
            self.compare()

    def test_owned_pid_and_process_name_are_required(self):
        for field, value in (("pid", 9999), ("name", "unrelated")):
            with self.subTest(field=field):
                original = dict(self.native_process)
                self.native_process[field] = value
                with self.assertRaises(lab.LabError):
                    self.compare()
                self.native_process = original

    def test_unknown_or_divergent_working_set_fails(self):
        for value in (None, "999999999"):
            with self.subTest(value=value):
                self.processes["processes"][0]["working_set_bytes"] = value
                with self.assertRaises(lab.LabError):
                    self.compare()

    def test_fixture_pid_must_match_original_process(self):
        with self.assertRaises(lab.LabError):
            lab.validate_fixture(self.fixture, 9999)

    def test_fixture_requires_dual_stack_and_connected_controls(self):
        for field in ("endpoints", "connected_only"):
            value = copy.deepcopy(self.fixture)
            value[field].pop()
            with self.assertRaises(lab.LabError):
                lab.validate_fixture(value, 1234)

    def test_fixture_rejects_nonloopback_or_foreign_pid(self):
        for field, value in (("address", "0.0.0.0"), ("pid", "9999")):
            item = copy.deepcopy(self.fixture)
            item["endpoints"][0][field] = value
            with self.assertRaises(lab.LabError):
                lab.validate_fixture(item, 1234)

    def resources(self):
        data = resource_data()
        before = {"memory_total_bytes": 1073741824, "memory_free_bytes": 536870910,
                  "boot_unix": 1000, "uptime_seconds": 9,
                  "networks": [{"name": "本地网络", "received_bytes": 100, "transmitted_bytes": 200}],
                  "filesystems": []}
        after = copy.deepcopy(before)
        after.update(memory_free_bytes=536870914, uptime_seconds=12)
        after["networks"][0].update(received_bytes=102, transmitted_bytes=202)
        after["filesystems"] = [{"mount": "C:\\", "total_bytes": 1000000000,
                                 "total_free_bytes": 600000000, "available_bytes": 500000000}]
        return data, before, after

    def test_independent_resources_and_unknown_cpu(self):
        result = lab.compare_resources(*self.resources(), [10, 20, 20], [15, 30, 30])
        self.assertEqual(result["independent_cpu_percent"], 75)
        self.assertIsNone(result["production_cpu_percent"])
        self.assertTrue(result["cpu_difference_is_informational"])

    def test_cpu_counter_regression_fails(self):
        with self.assertRaises(lab.LabError):
            lab.compare_resources(*self.resources(), [10, 20, 20], [9, 30, 30])

    def test_cumulative_network_bytes_must_be_bracketed(self):
        data, before, after = self.resources()
        data["networks"][0]["received_bytes"] = "99"
        with self.assertRaisesRegex(lab.LabError, "bracket"):
            lab.compare_resources(data, before, after, [10, 20, 20], [15, 30, 30])

    def test_missing_independent_interface_fails(self):
        data, before, after = self.resources()
        after["networks"] = []
        with self.assertRaises(lab.LabError):
            lab.compare_resources(data, before, after, [10, 20, 20], [15, 30, 30])

    def test_independent_memory_uptime_and_capacity_mismatches_fail(self):
        for field, value in (("memory_total_bytes", "1"), ("boot_time", "0"),
                             ("uptime_seconds", 9999)):
            with self.subTest(field=field):
                data, before, after = self.resources()
                data[field] = value
                with self.assertRaises(lab.LabError):
                    lab.compare_resources(data, before, after, [10, 20, 20], [15, 30, 30])
        data, before, after = self.resources()
        after["filesystems"][0]["total_bytes"] += 1
        with self.assertRaises(lab.LabError):
            lab.compare_resources(data, before, after, [10, 20, 20], [15, 30, 30])


class LifecycleTests(unittest.TestCase):
    def child(self, source, seconds=12):
        child = lab.OwnedChild([sys.executable, "-u", "-c", source], lab.Budget(seconds))
        self.addCleanup(child.close)
        child.start()
        return child

    def test_real_child_preserves_raw_bytes_and_actual_exit(self):
        child = self.child("import os;os.write(1,b'\\xff\\r\\n');os.write(2,b'error\\n');raise SystemExit(7)")
        self.assertEqual(child.wait(), 7)
        receipt = child.close()
        self.assertEqual(bytes(child.stdout), b"\xff\r\n")
        self.assertEqual(bytes(child.stderr), b"error\n")
        self.assertEqual(receipt["observed_exit"], 7)
        self.assertTrue(lab.terminal_ok(receipt))

    def test_stream_closure_does_not_prove_process_exit(self):
        child = self.child("import os,time;os.close(1);os.close(2);time.sleep(40)", seconds=6)
        with self.assertRaises(TimeoutError):
            child.wait()
        receipt = child.close()
        self.assertIsNone(receipt["observed_exit"])
        self.assertTrue(lab.terminal_ok(receipt))

    def test_live_child_timeout_has_bounded_original_process_terminal(self):
        started = time.monotonic()
        child = self.child("import time;time.sleep(40)", seconds=6)
        with self.assertRaises(TimeoutError):
            child.wait()
        receipt = child.close()
        self.assertLess(time.monotonic() - started, 8)
        self.assertTrue(lab.terminal_ok(receipt))
        self.assertIsNotNone(child.process.returncode)

    def test_parent_and_real_descendant_share_owned_cleanup(self):
        child = self.child(
            "import subprocess,sys,time;"
            "p=subprocess.Popen([sys.executable,'-c','import time;time.sleep(40)']);"
            "print(p.pid,flush=True);time.sleep(40)")
        while b"\n" not in child.stdout:
            child.drain()
            time.sleep(0.01)
        self.assertGreater(int(bytes(child.stdout).strip()), 0)
        receipt = child.close()
        self.assertTrue(lab.terminal_ok(receipt))
        if os.name == "nt":
            self.assertGreaterEqual(receipt["terminal"]["native_process_objects"]["retained_processes"], 2)

    def test_real_dual_stack_fixture_and_natural_exit(self):
        if not socket.has_ipv6:
            self.skipTest("host has no IPv6")
        try:
            with socket.socket(socket.AF_INET6, socket.SOCK_STREAM) as check:
                check.bind(("::1", 0))
        except OSError:
            self.skipTest("host IPv6 loopback unavailable")
        child = lab.OwnedChild([sys.executable, "-u", str(lab.FIXTURES / "owned_fixture.py"),
                                "--seconds", "10"], lab.Budget(14))
        self.addCleanup(child.close)
        child.start()
        ready = child.ready()
        self.assertEqual(ready["pid"], child.process.pid)
        self.assertEqual(len(ready["endpoints"]), 4)
        self.assertEqual(len(ready["connected_only"]), 2)
        self.assertEqual(child.stop_fixture(), 0)
        self.assertTrue(lab.terminal_ok(child.close()))

    def test_output_overflow_still_reaps_real_child(self):
        child = self.child("import os,time;os.write(1,b'x'*100000);time.sleep(40)")
        with mock.patch.object(lab, "MAX_FRAME", 8192):
            with self.assertRaises(lab.LabError):
                child.wait()
            receipt = child.close()
        self.assertIn("output_budget_exceeded", receipt["errors"])
        self.assertEqual(len(child.stdout) + len(child.stderr), 8192)
        self.assertTrue(receipt["terminal"]["direct_reaped"])
        self.assertEqual(receipt["terminal"]["active_processes"], 0)

    def test_evidence_preserves_fixed_capture_filename_bytes_and_receipt(self):
        with tempfile.TemporaryDirectory(prefix="keelshell-monitor-evidence-test-") as directory:
            evidence = lab.Evidence(Path(directory) / "output", 20)
            result = evidence.run("probe", [sys.executable, "-c",
                                           "import os;os.write(1,b'\\xff\\r\\n')"], 12)
            self.assertEqual((evidence.path / "probe.stdout").read_bytes(), b"\xff\r\n")
            self.assertEqual(result.stdout, b"\xff\r\n")
            self.assertTrue(lab.terminal_ok(evidence.children[0]))
            self.assertEqual(json.loads((evidence.path / "probe.receipt.json").read_text())["observed_exit"], 0)

    def test_terminal_missing_or_cleanup_errors_never_sign_success(self):
        for receipt in ({"errors": [], "terminal": None},
                        {"errors": ["failure"], "terminal": {"direct_reaped": True,
                         "active_processes": 0, "pipes_drained": True, "errors": []}}):
            self.assertFalse(lab.terminal_ok(receipt))

    def test_budget_never_extends_parent_deadline(self):
        deadline = time.monotonic() + 2
        budget = lab.Budget(10, deadline)
        self.assertEqual(budget.end, deadline)
        with self.assertRaises(TimeoutError):
            budget.remaining(reserve=3)


class SafetyAndWorkflowTests(unittest.TestCase):
    def test_shell_process_proof_cannot_fall_back_to_posix(self):
        if os.name == "nt":
            self.skipTest("negative non-Windows boundary only")
        with self.assertRaises(lab.Hold):
            lab.OwnedChild(["unexecuted"], lab.Budget(10), required_image="powershell.exe")

    def test_nonwindows_native_oracle_is_hold(self):
        if os.name == "nt":
            self.skipTest("negative non-Windows boundary only")
        with self.assertRaises(lab.Hold):
            lab.NativeOracle(lab.Budget(10))

    def test_cli_records_nonwindows_hold_without_running_commands(self):
        if os.name == "nt":
            self.skipTest("negative non-Windows boundary only")
        for mode in ("direct", "ssh"):
            with tempfile.TemporaryDirectory(prefix="keelshell-monitor-hold-test-") as directory:
                output = Path(directory) / "output"
                with mock.patch.object(lab.Evidence, "run", side_effect=AssertionError("no commands")):
                    self.assertEqual(lab.run_lab(mode, output, 10), lab.HOLD_EXIT)
                receipt = json.loads((output / "receipt.json").read_text())
                self.assertEqual(receipt["status"], "HOLD")
                self.assertEqual(receipt["reason"], "native_windows_required")
                self.assertEqual(receipt["children"], [])

    def test_existing_evidence_directory_is_never_overwritten(self):
        with tempfile.TemporaryDirectory(prefix="keelshell-monitor-existing-test-") as directory:
            with self.assertRaises(FileExistsError):
                lab.Evidence(directory)

    def test_evidence_path_escape_rejected(self):
        with tempfile.TemporaryDirectory(prefix="keelshell-monitor-path-test-") as directory:
            evidence = lab.Evidence(Path(directory) / "output")
            with self.assertRaises(lab.LabError):
                evidence.write_bytes("../escape", b"")

    def test_ssh_config_is_explicit_loopback_keys_and_forced_no_execution(self):
        config = lab.ssh_config(Path("owned-private"), 55001)
        for expected in ("Port 55001", "ListenAddress 127.0.0.1", "StrictModes yes",
                         'AuthorizedKeysFile "owned-private/authorized_keys"',
                         "PasswordAuthentication no", "DisableForwarding yes",
                         "ForceCommand cmd.exe /c exit 125"):
            self.assertIn(expected, config)
        for forbidden in ("Include ", "Match ", ".ssh/", "administrators_authorized_keys"):
            self.assertNotIn(forbidden, config)

    def test_ssh_config_rejects_low_port_and_path_injection(self):
        with self.assertRaises(lab.LabError):
            lab.ssh_config(Path("owned-private"), 22)
        with self.assertRaises(lab.Hold):
            lab.ssh_config(Path('owned"\nInclude dangerous'), 55001)

    def test_fixed_width_native_table_layouts(self):
        # These are ABI declarations, not Win32 calls or a native acceptance.
        self.assertEqual(ctypes.sizeof(lab.Tcp4), 24)
        self.assertEqual(ctypes.sizeof(lab.Tcp6), 56)
        self.assertEqual(ctypes.sizeof(lab.Udp4), 12)
        self.assertEqual(ctypes.sizeof(lab.Udp6), 28)
        self.assertEqual(ctypes.sizeof(lab.MemoryStatus), 64)
        if os.name == "nt":
            self.assertEqual(ctypes.sizeof(lab.IfRow), 1352)
            self.assertEqual(lab.IfRow.in_octets.offset, 1208)

    def test_workflow_has_independent_gates_setup_upload_and_docs_filter(self):
        text = (lab.ROOT / ".github/workflows/windows-monitor.yml").read_text()
        self.assertEqual(text.count("runs-on: windows-2025"), 2)
        self.assertEqual(text.count("uses: ./.github/actions/setup-build"), 2)
        self.assertIn("direct-api:", text)
        self.assertIn("isolated-ssh:", text)
        self.assertEqual(text.count("if: always()"), 3)
        self.assertIn("paths-ignore: ['docs/**', '**/*.md']", text)
        self.assertIn("persist-credentials: false", text)
        self.assertNotIn("continue-on-error", text)
        self.assertNotIn("cancel-in-progress", text)

    def test_workflow_replay_uses_exact_capture_and_cannot_silently_skip_hold(self):
        text = (lab.ROOT / ".github/workflows/windows-monitor.yml").read_text()
        self.assertIn("KEELSHELL_WINDOWS_MONITOR_CAPTURE_DIR:", text)
        self.assertIn("captured_windows_api_frames_are_accepted_through_authenticated_monitor_routing"
                      " -- --ignored --exact --test-threads=1", text)
        self.assertIn("CAPTURE_REPLAY_HOLD:", text)
        for operation in lab.OPERATIONS:
            self.assertIn(operation + ".stdout", text)


if __name__ == "__main__":
    unittest.main(verbosity=2)
