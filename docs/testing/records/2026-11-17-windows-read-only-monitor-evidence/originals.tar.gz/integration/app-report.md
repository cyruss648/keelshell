# Windows monitor GPUI implementation report — 2026-11-17

## Conclusion and validation boundary

The app changes and controlled SSH fixtures are ready for parent integration.
The seven owned Rust files pass a direct, restricted `rustfmt --check` with
`skip_children=true`. Source inspection finds 22 new tests: 5 ordinary unit tests
and 17 GPUI tests. **Compilation, compiled test inventory and test execution are
NOT_RUN by this agent.** The parent owns those centralized gates.

No target directory was accessed, no Cargo command or prebuilt test binary was
run, and no Git operation, dependency change, installation or native desktop
operation was performed. Controlled fixture code is not evidence of actual
Windows PowerShell, OpenSSH or native Windows GUI acceptance.

## Files changed

- `crates/keelshell-app/src/monitor.rs`: recognize the authenticated environment
  independently of resources; let that environment override retained snapshot
  platform for Linux action authorization. Windows blocks Probe, Inspect and
  Terminate before worker creation, including without resource samples. Reject
  stale inspection adoption on non-Linux panels, report Windows refresh
  semantics honestly, and translate `Cancelled` / `EnvironmentUnconfirmed`.
  A revoked resource/process collection stops the remaining refresh sequence.
- `crates/keelshell-app/src/monitor_view.rs`: add Windows read-only identity;
  display CIM CPU provider one-second-average and CIM wall-clock-estimated uptime
  provenance; retain unknown load, used/available memory, swap, rates, iowait and
  disk I/O explicitly. Show total/free memory separately. Windows process rows
  show optional working sets and process names, with unknown owner/percentages;
  PID 0 remains display-only. Capacity labels distinguish account-available
  bytes from total-free bytes. Hide Linux process confirmation on non-Linux
  environments. Continue the existing private `AnyElement` builder boundaries,
  Palette, component tokens, theme registry and bilingual text.
- `crates/keelshell-app/src/monitor_sockets.rs`: explain Windows TCP/UDP sources
  and display-only PIDs; hide unknown `*` peer arrows; prevent stale probe-result
  rendering outside Linux; give explicit empty/error messages accessible IDs.
- `crates/keelshell-app/src/monitor_capabilities.rs`: adopt environment through
  the existing authenticated report, revoke cached Linux action UI on non-Linux,
  display actual Windows PowerShell runtime version, and use DriveInfo /
  Get-Process capability labels on Windows. Unconfirmed environment stays unknown.
- `crates/keelshell-app/src/monitor_history.rs`: accept provider percentages on
  the first valid receipt while retaining interruption, boot, receipt-time,
  remote-time and counter continuity rules for line segments. Unavailable CPU
  stays absent; a legitimate idle zero stays visible. Adapt the existing in-file
  Linux/Darwin tests to `CpuSample` and optional load averages.
- `crates/keelshell-app/src/monitor_tests.rs`: register the new Windows test
  module; extend only this owned shared SSH fixture with platform flags,
  counters and routing. POSIX identity replies use the complete fixed frame.
- New `crates/keelshell-app/src/monitor_tests/windows.rs`: own Windows fixture
  JSON and new tests. No existing file under `monitor_tests/` was edited.

No source, script or fixture belonging to the Windows collector/parser agent
was changed.

## Fixture interoperability

The POSIX branch precedes all collector matching and returns exit 0 with:

```text
@@KS:monitor-platform:1@@
platform	Linux
runtime	posix
@@KS:end@@
```

The existing Darwin flag substitutes `Darwin`; a trailing LF is included.
Windows / deliberately unconfirmed fixtures fail this POSIX attempt without
pretending to be a POSIX host.

Windows matching accepts the exact fixed
`powershell.exe -NoLogo -NoProfile -NonInteractive -EncodedCommand ` prefix,
decodes standard Base64 to UTF-16LE and identifies the actual script prefix:
`$op='OPERATION';$skip=$false;` plus LF, or the fixed resource
`$op='resources';$skip=$true;` variant. This agrees with the collector agent's
`windows/ASSEMBLY.md` as read during implementation. Command length is asserted
below 8000 ASCII bytes by the fixture.

Replies follow the CONTRACT JSON envelope with typed nonzero failure frames.
Fixtures include Unicode process/interface names, nullable CPU / working set,
PID 0, 8 process rows, 15 socket rows, actual cumulative byte counters, distinct
total-free and account-available capacity, capacity skipping, successful empty
lists, independent failures and held replies. `cpu_percent:null` is expected to
parse to the parent's `CpuSample::Unavailable`.

## New tests — declarations only, all NOT_RUN

All names below are in `monitor::tests::windows`.

### Ordinary unit tests — 5

- `windows_provider_first_sample_and_idle_zero_need_no_counter_baseline`
- `windows_provider_values_survive_interruptions_without_joining_history_gaps`
- `windows_unavailable_cpu_breaks_history_without_inventing_an_idle_zero`
- `windows_provider_percentages_cannot_bypass_receipt_and_uptime_validation`
- `windows_unknown_environment_and_cancelled_errors_have_explicit_bilingual_text`

### GPUI tests — 17

- `windows_first_ssh_sample_exposes_provider_cpu_and_matching_mcp_current_point`
- `windows_null_cpu_and_real_idle_zero_remain_distinct_in_ui_mcp_and_history`
- `windows_resource_failure_preserves_independent_processes_and_known_read_only_environment`
- `windows_socket_first_collection_establishes_environment_without_a_resource_sample`
- `windows_resource_negative_cache_retries_only_after_explicit_recheck`
- `windows_process_and_socket_failures_are_independent_cached_and_rechecked`
- `windows_capacity_failure_keeps_core_resources_and_skips_cached_drive_collection`
- `windows_refresh_failure_keeps_old_points_and_recovers_with_a_visible_new_segment`
- `windows_pause_aba_discards_held_refresh_and_preserves_completed_environment`
- `windows_suspension_discards_held_resources_before_sending_process_collection`
- `windows_pause_aba_discards_late_socket_rows_and_capability_results`
- `windows_expired_outcome_cannot_publish_cpu_mcp_or_process_receipts`
- `windows_stale_resources_do_not_discard_a_fresh_independent_process_response`
- `unconfirmed_environment_stays_unknown_without_starting_windows_collectors`
- `windows_environment_blocks_even_a_retained_linux_snapshot_and_reviewed_sigterm`
- `windows_explicit_empty_lists_are_distinct_from_failed_collection`
- `windows_three_theme_bilingual_compact_layout_and_paging_add_zero_ssh_commands`

The layout test declares Frost / Graphite / Lavender through the registry,
Light / Dark, Chinese / English, and 900×580 / 1440×960 surfaces. It drives real
scroll and process/socket pagination events, checks accessible source and
unknown-value labels, and asserts zero additional SSH commands or sample
changes. These are intended test assertions, not observed native results.

The stale SIGTERM guard test obtains an actual reviewed identity only from an
isolated controlled Linux SSH fixture, then passes it to the Windows panel's
blocked dispatcher. It asserts zero termination commands to either fixture.

## Commands actually executed

1. Read-only file inspection with `cat`, `sed`, `rg`, `wc`, and `pwd`, restricted
   to project guidance/source, the Rust skill, relevant memory and GPUI test API
   source. The parent-provided CONTRACT and collector assembly guide were read.
2. Direct `rustfmt --edition 2024 --config skip_children=true` on exactly the
   seven owned Rust files during editing; each invocation returned exit 0.
3. Final restricted check, exit 0:

```sh
rustfmt --check --edition 2024 --config skip_children=true \
  crates/keelshell-app/src/monitor.rs \
  crates/keelshell-app/src/monitor_view.rs \
  crates/keelshell-app/src/monitor_sockets.rs \
  crates/keelshell-app/src/monitor_capabilities.rs \
  crates/keelshell-app/src/monitor_history.rs \
  crates/keelshell-app/src/monitor_tests.rs \
  crates/keelshell-app/src/monitor_tests/windows.rs
```

4. An inline Python source-only inspection, exit 0, counted the new test
   declarations, rejected duplicate names and checked trailing whitespace in
   the seven owned files. Its output was:

```text
Source declarations only: 22 tests; 5 unit, 17 GPUI; no test execution.
Seven owned files: no trailing whitespace.
```

No Rust compiler, Clippy, dependency gate, test executable or native GUI was run.
The compiled test inventory is unknown until the parent builds these sources.

## Parent integration follow-up

The following existing file is outside this agent's ownership and was left
unchanged. The parent was notified during implementation:

`crates/keelshell-app/src/monitor_tests/capabilities.rs`

- `pausing_recheck_between_commands_cancels_unsent_ps_and_ss`: explicit reset
  now sends identity before resources. Its `commands + 1` wait can awaken on
  identity before the held resource request. Wait on the resource counter /
  actual held collection, and account for the additional identity command.
- `recheck_pause_aba_and_retirement_discard_held_capability_responses`: full
  reset now has identity + resources + processes + sockets, so its existing
  `commands + 3` wait / final assertion needs the fourth command.
- `compact_capability_reasons_ages_and_recheck_are_keyboard_accessible`: its
  final keyboard-triggered reset assertion also needs the identity command
  (`commands + 3` becomes `commands + 4`).

Other parent-owned session construction sites and fixtures must use the new
public types and platform probe as already assigned. Run centralized compilation,
fresh compiled inventory, relevant new and existing Linux/Darwin regressions,
small-stack combined monitor rendering, and the full parent gates. Actual
Windows collection / SSH and three-platform native GUI acceptance remain
separate, unverified boundaries.
