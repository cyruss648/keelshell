"""Stage owned text receipts; omit packages, prebuilt binaries and source copies."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
SUFFIXES = {
    ".py", ".json", ".jsonl", ".log", ".md", ".txt", ".diff", ".patch",
    ".rs", ".ps1", ".stdout", ".stderr", ".yml",
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("destination", type=Path)
    args = parser.parse_args()
    destination = args.destination.resolve()
    assert not destination.exists()
    selections = [
        (BASE, Path("integration"), set()),
        (ROOT / "work/windows-monitor-review-source-20261117", Path("source-review"),
         {"source-r1", "source-r2", "source-r3", "supporting-source-r1"}),
        (ROOT / "work/windows-monitor-review-function-20261117", Path("function-review"),
         {"source-snapshot-r1", "source-snapshot-r2", "source-snapshot-r3",
          "source-snapshot-final", "source-snapshot-oracle-r1"}),
        (ROOT / "work/windows-monitor-oracle-fix-20261117", Path("oracle-fix"), set()),
    ]
    planned = []
    omitted = []
    source_references = []
    historical = {}
    git_names = {
        name.decode() for name in subprocess.check_output(
            ["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"],
            cwd=ROOT, timeout=30,
        ).split(b"\0") if name
    }
    for base, prefix, skip in selections:
        for path in sorted(base.rglob("*")):
            relative = path.relative_to(base)
            if not path.is_file():
                continue
            assert not path.is_symlink()
            if any(part == "__pycache__" or part == "runtime-tmp"
                   or part.startswith(("prebuilt-", "package-"))
                   for part in relative.parts[:-1]):
                omitted.append((prefix / relative).as_posix())
                continue
            assert path.suffix in SUFFIXES or path.name == "Dockerfile", relative
            data = path.read_bytes()
            # Every accepted member is text; binary packages and keys are excluded.
            data.decode("utf-8")
            assert re.search(
                rb"(?m)^-----BEGIN (?:OPENSSH |RSA |EC )?PRIVATE KEY-----\r?$", data
            ) is None, relative
            if relative.parts[0] in skip:
                canonical = Path(*relative.parts[1:]).as_posix()
                sha = hashlib.sha256(data).hexdigest()
                reference = {
                    "original": (prefix / relative).as_posix(),
                    "source": path.relative_to(ROOT).as_posix(),
                    "bytes": len(data), "sha256": sha,
                }
                if canonical in git_names and (ROOT / canonical).read_bytes() == data:
                    reference.update(kind="git", canonical=canonical)
                else:
                    saved = historical.get(sha)
                    if saved is None:
                        saved = Path("historical-snapshots") / (sha + path.suffix)
                        historical[sha] = saved
                        planned.append((path, saved, data))
                    reference.update(kind="archive", canonical=saved.as_posix())
                source_references.append(reference)
                continue
            planned.append((path, prefix / relative, data))
    destination.mkdir(parents=True)
    records = []
    for source, relative, data in planned:
        assert source.read_bytes() == data, source
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as output:
            output.write(data)
        records.append({
            "path": relative.as_posix(), "source": source.relative_to(ROOT).as_posix(),
            "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
        })
    assert all(source.read_bytes() == data for source, _, data in planned)
    manifest = {
        "selected_count": len(records), "selected_bytes": sum(r["bytes"] for r in records),
        "entries": records, "omitted_count": len(omitted), "omitted": omitted,
        "source_snapshot_references": source_references,
        "historical_distinct_versions": len(historical),
        "exclusions": ["prebuilt test binaries", "normal application package",
                       "unchanged source snapshots referenced by exact Git bytes",
                       "Python bytecode"],
    }
    with (destination / "selection.json").open("x") as output:
        json.dump(manifest, output, indent=2)
        output.write("\n")
    print(json.dumps({key: value for key, value in manifest.items()
                      if key not in ("entries", "omitted", "source_snapshot_references")}))


if __name__ == "__main__":
    main()
