"""Run the existing official checker with bounded, individually recorded retries."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import threading
import time

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "scripts"))
import check_dependencies as check

capture = BASE / "official-metadata-r3"
capture.mkdir(exist_ok=False)
ledger = []
lock = threading.Lock()


def fetch(url, timeout):
    package = url.removeprefix(check.API_ROOT)
    check.valid_name(package)
    for attempt in range(1, 4):
        started = time.monotonic()
        row = dict(
            package=package, url=url, attempt=attempt,
            started_utc=datetime.now(timezone.utc).isoformat(),
        )
        try:
            metadata = check.fetch_json(url, timeout)
        except check.CheckFailure as error:
            row.update(status="failed", code=str(error), seconds=time.monotonic() - started)
            with lock:
                ledger.append(row)
            if attempt == 3:
                raise
        else:
            # This is parsed JSON re-encoding, not a byte-identical HTTP body.
            raw = (json.dumps(metadata, separators=(",", ":"), ensure_ascii=True) + "\n").encode()
            (capture / f"{package}.json").write_bytes(raw)
            row.update(
                status="passed", seconds=time.monotonic() - started,
                parsed_metadata_sha256=hashlib.sha256(raw).hexdigest(),
                parsed_metadata_bytes=len(raw), content_scope="official parsed metadata",
            )
            with lock:
                ledger.append(row)
            return metadata
    raise check.CheckFailure("registry_request_failed")


report = check.run_check(ROOT, fetch=fetch, timeout=8.0, jobs=3)
with (BASE / "dependency-freshness-report-r3.json").open("x") as output:
    json.dump(report, output, indent=2)
    output.write("\n")
with (BASE / "dependency-freshness-requests-r3.json").open("x") as output:
    json.dump(ledger, output, indent=2)
    output.write("\n")
print(json.dumps(dict(
    status=report["status"], counts=report.get("counts"),
    official_requests=len(ledger),
    failed_packages=sorted({r["package"] for r in report["rust"] if r["status"] != "passed"}),
)))
sys.exit(0 if report["status"] == "passed" else 1)
