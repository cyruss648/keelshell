# Windows 只读监控 collector / strict parser 交接

记录时间：`2026-11-17T05:31:38.032325+08:00`。本任务的 Rust 文件已稳定，供父级集中编译；
本报告只签署本任务实际执行的格式与静态验证。没有运行 Cargo、Rust 单元测试、
Windows PowerShell 或 SSH；没有访问 target、执行 Git、修改 Cargo/依赖或提交。

## 实现与范围

- 精确提供合同中的 `Operation`、`command`、`parse_probe`、`parse_resources`、
  `parse_processes`、`parse_sockets` API。公共类型、module registration、路由、
  缓存、Linux/Darwin 迁移和构建均由父级负责。
- PowerShell 5.1 使用固定前导、公共前缀、四个操作脚本与固定 catch 后缀；
  UTF-16LE 无 BOM / 标准带 padding Base64 / 固定 powershell.exe 参数。
  逐字节组装规则已提前写入 `windows/ASSEMBLY.md`，父级已确认转交 lab。
- 直接反序列化 typed envelope 和每层 typed records，所有对象 deny unknown/duplicate
  keys，不经过会吞掉重复键的 `serde_json::Value` 中间层。成功必须 exit 0、空 stderr、
  单个完整 UTF-8 JSON frame；只允许无结束换行或一个 LF/CRLF，无 banner/外围空白。
- 版本、runtime、units、operation、status/data/exit 一致性、合计 2 MiB、计数/上限、
  canonical u64/u32/u16、地址和作用域、PID 顺序/重复、显示文本与所有子记录均校验。
  错误仅使用固定文本或 `CapabilityReason`，不回显远端诊断。
- `Frame<T>.data`、`Resources.cpu_percent`、`Process.working_set_bytes` 均标记
  `#[serde(deserialize_with = "nullable")]`，不加 `default`；仅显式 null 可接受，
  字段缺失拒绝。集中 missing-vs-null 负例与逐字段缺失负例均已写入。
- 资源使用 CIM 同一个 OS 对象中的启动/当前时间作墙钟估计；CPU 按有效 logical
  processor counts 加权，仅全部不可用时发 null，有效/缺失混杂时整体失败。
  内存 KiB × 1024 走 decimal 和 checked u64 边界；只填 free，不构造 available/used。
  网络是实际 GetIPStatistics 累计字节；本模块不推断速率、CPU ticks、load 或 disk I/O。
- 容量独立 try/catch。typed failure/skipped 必须 count=0 / filesystems=[]，保留核心资源。
  total_free 与 quota-aware available 分开，used=total-total_free，百分比用 u128 整数除法
  向下取整，避免 u64 × 100 溢出；格式/数值损坏仍拒绝整帧，不能把坏数据当可用。
- Get-Process 只读 ProcessName、可选 WorkingSet64；owner/CPU%/memory% 留 None。
  PID 0 是观察值；本模块没有 inspect、terminate、TCP probe 等动作。
- sockets 两条命令均完成才发成功；TCP→LISTEN、UDP→BOUND、peer="*"。
  IPv4/IPv6（可选 canonical numeric u32 scope）正规化，PID 元数据格式 `pid=42`。
- 名称/路径限 1024 UTF-8 bytes，地址限 128 ASCII bytes；拒绝控制/escape、bidi 和隐藏文本。
  networks≤256、ready fixed volumes≤512、processes/sockets≤20000。

### 公共合同问题及父级决议

曾提前通知：原 `CpuSample::ReportedPercent(f64)` 无法表达 cpu_percent:null。
父级明确新增 `CpuSample::Unavailable`，本实现已按该决议映射。未自行修改公共类型或协议，
没有 NaN、零百分比或虚构 ticks 退路。本任务没有其他待决 wire/schema 变更。

## 变更路径

- `crates/keelshell-session/src/monitor/windows.rs`
- `crates/keelshell-session/src/monitor/windows/ASSEMBLY.md`
- `crates/keelshell-session/src/monitor/windows/common.ps1`
- `crates/keelshell-session/src/monitor/windows/fixtures/probe.json`
- `crates/keelshell-session/src/monitor/windows/fixtures/processes-empty.json`
- `crates/keelshell-session/src/monitor/windows/fixtures/processes.json`
- `crates/keelshell-session/src/monitor/windows/fixtures/resources-unknown.json`
- `crates/keelshell-session/src/monitor/windows/fixtures/resources.json`
- `crates/keelshell-session/src/monitor/windows/fixtures/sockets-empty.json`
- `crates/keelshell-session/src/monitor/windows/fixtures/sockets-permission-denied.json`
- `crates/keelshell-session/src/monitor/windows/fixtures/sockets.json`
- `crates/keelshell-session/src/monitor/windows/probe.ps1`
- `crates/keelshell-session/src/monitor/windows/processes.ps1`
- `crates/keelshell-session/src/monitor/windows/resources.ps1`
- `crates/keelshell-session/src/monitor/windows/sockets.ps1`
- `crates/keelshell-session/src/monitor/windows/static-receipt.json`
- `crates/keelshell-session/src/monitor/windows/tests.rs`
- `crates/keelshell-session/src/monitor/windows/verify_static.py`
- `work/windows-monitor-integration-20261117/collector-report.md`（本报告，用户明确授权）

其余文件均未由本任务编辑；共享 checkout 的其他变化属于父级/其他工作者，不能据此推断归属。

## 实际命令与结果

| 实际命令/检查 | 结果与范围 |
| --- | --- |
| `rustfmt --edition 2024 --config skip_children=true crates/keelshell-session/src/monitor/windows.rs crates/keelshell-session/src/monitor/windows/tests.rs` | 两次 exit 0；只格式化自有两个 Rust 文件 |
| `rustfmt --check --edition 2024 --config skip_children=true crates/keelshell-session/src/monitor/windows.rs crates/keelshell-session/src/monitor/windows/tests.rs` | exit 0；最终只读格式检查 |
| `python3 -B crates/keelshell-session/src/monitor/windows/verify_static.py` | exit 0；5 个固定命令组装/长度/编码 round-trip、8 个 JSON fixture、44 个源码声明测试名通过静态检查 |
| `zsh -c 'command -v pwsh \|\| command -v powershell'` | 实际 shell 逻辑为 OR；exit 1，无路径输出，本机没有可用的 PowerShell 可执行文件 |
| 自有文件逐行 trailing-whitespace 扫描 | exit 0，无尾空白 |
| Microsoft 官方文档只读抓取 | 9 个不同官方页面 HTTP 200；链接/事实记于 ASSEMBLY.md；不代表 Windows 执行 |
| Cargo / Clippy / Rust tests / target / Git / Windows / SSH | 本任务执行 0；父级负责后续工程门禁与 lab |

早期静态组装曾测得两个 resources 变体各 8106 ASCII bytes，未满足上限；已通过缩短固定
前缀与重复校验表达式修正，并保留本段失败证据。最终所有变体严格小于 8000：

| Operation | skip_capacity | UTF-16 units | 整条命令 ASCII bytes |
| --- | --- | --- | --- |
| probe | `false` | 1391 | 3778 |
| resources | `false` | 2958 | 7954 |
| resources | `true` | 2957 | 7954 |
| processes | `false` | 1622 | 4394 |
| sockets | `false` | 1760 | 4762 |

`windows/static-receipt.json` 保存命令 SHA-256、全部 fixture 哈希、当前两份 Rust 与五份
PS 的 SHA-256，以及实际 exit codes。静态检查不是编译库存或单元测试执行凭据。

## 新增 Rust 单元测试名（源码声明 44 项，执行 0）

- `commands_are_fixed_ascii_under_default_shell_bound`
- `encoded_commands_round_trip_exact_production_files_without_bom`
- `fixed_scripts_use_read_only_sources_and_both_socket_commands`
- `probe_accepts_complete_lf_crlf_and_unterminated_json`
- `probe_requires_actual_windows_identity_and_four_desktop_version_components`
- `every_envelope_field_is_required_and_unknown_fields_fail_closed`
- `duplicate_envelope_fields_are_rejected_before_value_normalization`
- `envelope_rejects_wrong_units_versions_operations_runtime_and_types`
- `complete_frame_rejects_banners_unrelated_whitespace_and_multiple_frames`
- `malformed_truncated_non_utf8_and_oversize_frames_fail_closed`
- `no_exit_or_success_stderr_never_establishes_a_collection`
- `typed_failures_require_null_data_nonzero_exit_and_empty_stderr`
- `malformed_error_frames_cannot_claim_a_localized_capability_reason`
- `required_nullable_fields_accept_explicit_null_and_reject_absence`
- `combined_output_accepts_exact_byte_bound_and_rejects_one_extra`
- `resources_preserve_unicode_wide_counters_and_reported_cpu_provenance`
- `unknown_cpu_available_memory_load_swap_and_disk_stay_unknown`
- `capacity_uses_total_free_for_used_and_keeps_quota_available_distinct`
- `capacity_percent_uses_checked_wide_integer_arithmetic`
- `typed_capacity_failure_preserves_core_and_never_reports_empty_available`
- `empty_successful_capacity_is_distinct_from_skipped_and_partial_failure`
- `resources_require_every_field_including_nullable_cpu`
- `nested_resources_reject_unknown_missing_and_duplicate_keys`
- `resources_reject_noncanonical_overflow_and_numeric_byte_counters`
- `resources_reject_invalid_percent_uptime_memory_and_capacity_boundaries`
- `resources_accept_zero_uptime_and_cpu_percentage_endpoints`
- `resources_validate_counts_duplicates_and_independent_array_bounds`
- `exact_network_and_filesystem_limits_accept_and_one_extra_rejects`
- `display_fields_reject_controls_escape_bidi_and_hidden_text`
- `display_bounds_count_utf8_bytes_and_preserve_safe_unicode`
- `processes_preserve_pid_zero_unicode_and_optional_working_set_only`
- `processes_accept_explicit_empty_singleton_and_maximum_pid`
- `processes_reject_duplicate_unordered_overflow_and_noncanonical_pids`
- `processes_reject_missing_nullable_working_set_and_duplicate_record_fields`
- `processes_reject_bad_counts_null_arrays_and_working_set_overflow`
- `processes_accept_exact_inventory_bound_and_reject_one_extra`
- `sockets_preserve_numeric_endpoints_and_display_only_pid_metadata`
- `sockets_require_explicit_empty_success_and_accept_singleton_crlf`
- `sockets_accept_ipv4_ipv6_wildcards_scopes_and_numeric_pid_boundaries`
- `sockets_reject_names_injection_invalid_addresses_and_invalid_scopes`
- `sockets_reject_invalid_protocol_port_and_pid_fields`
- `sockets_reject_partial_mismatched_duplicate_and_missing_records`
- `sockets_normalize_addresses_for_duplicates_and_keep_distinct_owners`
- `sockets_accept_exact_inventory_bound_and_reject_one_extra`

## Frame fixtures 与样例

均为明确的人工合成 parser/UI 夹具，不是任何真实 Windows 主机的观测值。成功须空 stderr；
错误样例为非零 exit 与空 stderr，不能从本地化 stderr 推断失败原因。

| fixture | exec exit | UTF-8 bytes（含 LF） |
| --- | --- | --- |
| `probe.json` | 0 | 189 |
| `processes-empty.json` | 0 | 203 |
| `processes.json` | 0 | 324 |
| `resources-unknown.json` | 0 | 413 |
| `resources.json` | 0 | 619 |
| `sockets-empty.json` | 0 | 199 |
| `sockets-permission-denied.json` | nonzero | 194 |
| `sockets.json` | 0 | 331 |

### probe.json

```json
{"version":1,"operation":"probe","platform":"Windows","runtime":"WindowsPowerShell","runtime_version":"5.1.26100.123","units":"bytes seconds percent","status":"ok","data":{"os":"Win32NT"}}
```

### resources.json

```json
{"version":1,"operation":"resources","platform":"Windows","runtime":"WindowsPowerShell","runtime_version":"5.1.26100.123","units":"bytes seconds percent","status":"ok","data":{"boot_time":"1794787200","uptime_seconds":3600.25,"cpu_percent":12.5,"memory_total_bytes":"17179869184","memory_free_bytes":"4294967296","network_count":1,"networks":[{"name":"以太网 适配器","received_bytes":"9007199254740993","transmitted_bytes":"18446744073709551615"}],"capacity_status":"ok","filesystem_count":1,"filesystems":[{"source":"C:\\","mount":"C:\\","total_bytes":"1000","total_free_bytes":"400","available_bytes":"300"}]}}
```

### resources-unknown.json

```json
{"version":1,"operation":"resources","platform":"Windows","runtime":"WindowsPowerShell","runtime_version":"5.1.26100.123","units":"bytes seconds percent","status":"ok","data":{"boot_time":"1794787200","uptime_seconds":3600.25,"cpu_percent":null,"memory_total_bytes":"17179869184","memory_free_bytes":"4294967296","network_count":0,"networks":[],"capacity_status":"skipped","filesystem_count":0,"filesystems":[]}}
```

### processes.json

```json
{"version":1,"operation":"processes","platform":"Windows","runtime":"WindowsPowerShell","runtime_version":"5.1.26100.123","units":"bytes seconds percent","status":"ok","data":{"count":2,"processes":[{"pid":"0","name":"Idle","working_set_bytes":null},{"pid":"42","name":"编辑器","working_set_bytes":"9007199254740993"}]}}
```

### sockets.json

```json
{"version":1,"operation":"sockets","platform":"Windows","runtime":"WindowsPowerShell","runtime_version":"5.1.26100.123","units":"bytes seconds percent","status":"ok","data":{"count":2,"sockets":[{"protocol":"tcp","address":"127.0.0.1","port":"1234","pid":"4"},{"protocol":"udp","address":"fe80::1%12","port":"65535","pid":"42"}]}}
```

### sockets-permission-denied.json

```json
{"version":1,"operation":"sockets","platform":"Windows","runtime":"WindowsPowerShell","runtime_version":"5.1.26100.123","units":"bytes seconds percent","status":"permission_denied","data":null}
```

## 未验边界与交接状态

- Rust 编译、44 项实际执行库存、严格 Clippy、完整 workspace/跨平台 gate 由父级确认；
  未把 rustfmt 的解析成功称为编译/测试成功。测试夹具 unwrap/expect 仅在测试模块中按项目惯例
  使用带理由的 `#[expect]`，生产路径没有 unwrap/expect。
- 本任务没有 Windows PowerShell 5.1 的 parser AST 检查或实际执行，没有受控 provider 故障、
  权限、CIM 时钟/UTC、.NET 网络、真实 TCP/UDP/进程、SSH shell 边界或 Windows GUI 证据。
  当前只有源代码静态检查；Windows lab/direct 与实际隔离 OpenSSH 应分别验收。
- .NET working-set getter 不可读时仅该字段为 null；Get-Process 或任一 sockets cmdlet 整体失败
  必须 typed failure。容量异常仅降级容量。父级仍须验证 cache/generation/Cancelled 与 Linux
  action guards，不属于本模块的动作授权实现。
- 未安装/覆盖应用、改服务/registry/firewall、持久化凭据、上报数据或启动外部设施。
- Rust 写入已稳定；仅等待父级回收/报告编译问题。不声称实际 Windows 执行通过。
