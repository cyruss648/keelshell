"""Observe only the exact pushed commit; preserve every bounded GET receipt."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source")
    parser.add_argument("destination", type=Path)
    parser.add_argument("--seconds", type=int, default=3600)
    args = parser.parse_args()
    assert len(args.source) == 40 and all(c in "0123456789abcdef" for c in args.source)
    base = args.destination.resolve()
    base.mkdir(parents=True, exist_ok=False)
    raw_dir = base / "api-originals"
    raw_dir.mkdir()
    deadline = time.monotonic() + args.seconds
    requests = []
    observations = []
    targets = {}
    previous = None
    expected = {"Quality", "Windows monitor integration"}

    def query(arguments):
        command = ["gh", *arguments]
        started = time.monotonic()
        row = {"command": command, "started_utc": datetime.now(timezone.utc).isoformat()}
        try:
            result = subprocess.run(
                command, capture_output=True,
                timeout=min(45, max(1, deadline - time.monotonic())), check=False,
            )
            row.update(exit=result.returncode, timed_out=False)
            for label, data in (("stdout", result.stdout), ("stderr", result.stderr)):
                sha = hashlib.sha256(data).hexdigest()
                path = raw_dir / (sha + ".txt")
                if not path.exists():
                    with path.open("xb") as output:
                        output.write(data)
                row[label] = {
                    "path": path.relative_to(base).as_posix(),
                    "bytes": len(data), "sha256": sha,
                }
            row["seconds"] = time.monotonic() - started
            requests.append(row)
            assert result.returncode == 0, ("GitHub GET failed", result.returncode)
            return json.loads(result.stdout)
        except subprocess.TimeoutExpired:
            row.update(timed_out=True, seconds=time.monotonic() - started)
            requests.append(row)
            raise

    reason = "deadline"
    try:
        while time.monotonic() < deadline:
            if set(targets) != expected:
                listed = query([
                    "run", "list", "--repo", "cyruss648/keelshell", "--commit", args.source,
                    "--limit", "30", "--json",
                    "databaseId,headSha,status,conclusion,workflowName,url,event",
                ])
                for run in listed:
                    if run["workflowName"] in expected and run["event"] == "push":
                        assert run["headSha"] == args.source
                        prior = targets.get(run["workflowName"])
                        assert prior is None or prior == run["databaseId"]
                        targets[run["workflowName"]] = run["databaseId"]
            current = []
            for name, run_id in sorted(targets.items()):
                run = query([
                    "run", "view", str(run_id), "--repo", "cyruss648/keelshell",
                    "--json", "databaseId,headSha,status,conclusion,jobs,url,event,workflowName",
                ])
                assert run["headSha"] == args.source
                assert run["databaseId"] == run_id and run["workflowName"] == name
                with (base / f"run-{run_id}-latest.json").open("w") as output:
                    json.dump(run, output, indent=2)
                    output.write("\n")
                current.append(run)
            compact = [
                {"name": r["workflowName"], "id": r["databaseId"], "status": r["status"],
                 "conclusion": r["conclusion"], "jobs": [
                     {"name": j["name"], "status": j["status"], "conclusion": j["conclusion"],
                      "steps": [(s["number"], s["conclusion"]) for s in j.get("steps", [])]}
                     for j in r["jobs"]]}
                for r in current
            ]
            if compact != previous:
                observations.append({
                    "observed_utc": datetime.now(timezone.utc).isoformat(), "runs": compact,
                })
                print(json.dumps(observations[-1]), flush=True)
                previous = compact
            if len(current) == 2 and all(r["status"] == "completed" for r in current):
                reason = "terminal"
                break
            time.sleep(min(20, max(0, deadline - time.monotonic())))
    except (AssertionError, OSError, ValueError, subprocess.TimeoutExpired):
        reason = "observation-error"
        raise
    finally:
        final = {
            "source": args.source, "targets": targets, "reason": reason,
            "observations": observations, "requests": requests,
            "remote_mutations": 0, "manual_reruns": 0, "manual_cancellations": 0,
        }
        with (base / "watch.json").open("x") as output:
            json.dump(final, output, indent=2)
            output.write("\n")
    assert reason == "terminal", "Exact CI terminal state was not observed"
    return 0 if all(r["conclusion"] == "success" for r in current) else 1


if __name__ == "__main__":
    raise SystemExit(main())
