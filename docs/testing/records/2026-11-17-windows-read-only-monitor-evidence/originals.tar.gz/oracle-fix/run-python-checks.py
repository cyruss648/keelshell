#!/usr/bin/env python3
"""Bounded local Python evidence only; no Cargo, Git, target or remote access."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
OUTPUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "scripts"))
import windows_monitor_lab as lab


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--label", required=True)
    parser.add_argument("--baseline", action="store_true")
    args = parser.parse_args()
    if not re.fullmatch(r"[a-z0-9-]+", args.label):
        raise ValueError("invalid label")
    temporary = OUTPUT / (args.label + "-tmp")
    temporary.mkdir(exist_ok=False)
    for key in ("TMPDIR", "TMP", "TEMP"):
        os.environ[key] = str(temporary)
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    evidence = lab.Evidence(OUTPUT / args.label, 50)
    if args.baseline:
        code = """
import importlib.util, pathlib, sys, unittest
root = pathlib.Path.cwd()
sys.path.insert(0, str(root / "scripts"))
path = root / "work/windows-monitor-oracle-fix-20261117/baseline/scripts/windows_monitor_lab.py"
spec = importlib.util.spec_from_file_location("windows_monitor_lab", path)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
names = [
    "test_windows_monitor_lab.ResourceInventoryTests.test_all_networks_omitted_fail_against_nonempty_independent_inventory",
    "test_windows_monitor_lab.ResourceInventoryTests.test_partial_network_omission_fails_by_identity",
    "test_windows_monitor_lab.ResourceInventoryTests.test_all_ready_fixed_volumes_omitted_fail_against_independent_inventory",
    "test_windows_monitor_lab.ResourceInventoryTests.test_partial_ready_fixed_volume_omission_fails_by_identity",
]
result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromNames(names))
raise SystemExit(not result.wasSuccessful())
"""
        command = [sys.executable, "-B", "-c", code]
    else:
        command = [sys.executable, "-B", "-m", "unittest", "discover",
                   "-s", "scripts", "-p", "test_windows_monitor_lab.py", "-v"]
    started = time.monotonic()
    child = lab.OwnedChild(command, lab.Budget(45, evidence.budget.end))
    execution_error = None
    try:
        child.start()
        child.wait()
    except BaseException as error:
        execution_error = type(error).__name__
    finally:
        terminal = evidence.keep_child("unittest", child)
    text = (bytes(child.stderr) + bytes(child.stdout)).decode("utf-8", errors="replace")
    match = re.search(r"^Ran (\d+) tests? in ([0-9.]+)s$", text, re.MULTILINE)
    result_line = re.search(r"^(OK|FAILED)(?: \(([^)]*)\))?$", text, re.MULTILINE)
    counts = {}
    if result_line:
        counts = {key: int(value) for key, value in
                  re.findall(r"(failures|errors|skipped|expected failures|unexpected successes)=(\d+)",
                             result_line[2] or "")}
    total = int(match[1]) if match else None
    failed = counts.get("failures", 0) + counts.get("errors", 0) + counts.get("unexpected successes", 0)
    skipped = counts.get("skipped", 0)
    sources = []
    for path in (ROOT / "scripts/windows_monitor_lab.py", ROOT / "scripts/test_windows_monitor_lab.py",
                 ROOT / "scripts/windows_monitor/README.md", *sorted(lab.COLLECTORS.glob("*.ps1"))):
        value = path.read_bytes()
        sources.append({"path": str(path.relative_to(ROOT)), "bytes": len(value),
                        "sha256": hashlib.sha256(value).hexdigest()})
    summary = {"scope": "offline Python on actual macOS host; no native Windows calls",
               "label": args.label, "baseline_negative_control": args.baseline,
               "command": command, "cwd": str(ROOT), "host": platform.platform(),
               "python": sys.version, "outer_seconds": round(time.monotonic() - started, 6),
               "unittest_seconds": float(match[2]) if match else None,
               "total": total, "passed": total - failed - skipped if total is not None else None,
               "failed": failed, "skipped": skipped,
               "exit_code": terminal["observed_exit"], "terminal_proven": lab.terminal_ok(terminal),
               "execution_error": execution_error, "log_budget_bytes": lab.MAX_FRAME,
               "sources": sources, "windows_api_executions": 0, "windows_abi": "UNVERIFIED"}
    evidence.write_json("summary.json", summary)
    evidence.write_bytes("combined.log", text.encode("utf-8"))
    print(json.dumps({key: value for key, value in summary.items()
                      if key not in {"command", "sources", "python"}}, ensure_ascii=False, indent=2))
    if execution_error or not lab.terminal_ok(terminal) or total is None or result_line is None:
        return 2
    return terminal["observed_exit"]


if __name__ == "__main__":
    raise SystemExit(main())
