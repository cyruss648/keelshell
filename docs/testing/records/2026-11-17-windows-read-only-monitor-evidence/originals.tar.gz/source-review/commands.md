# 实际命令记录

范围：本轮源码审查、父级 r2 负缓存 delta 与最终 r3 channel-admission/fixture delta；全部在指定 cwd 执行。
下表保留真实命令形式及目的；长 Python here-doc 的原样代码保留在本审查工具调用记录中，
此处描述它实际做了什么，不将文本/哈希分析算成测试。

| 序号 | 实际命令/调用 | 结果 |
| --- | --- | --- |
| 1 | `pwd` | exit 0，指定 checkout |
| 2 | `cat /Users/hdh/.codex/RTK.md` | exit 0 |
| 3 | `rg -n 'KeelShell\|read.only\|严格只读\|SHARED_TARGET\|Windows\|monitor' /Users/hdh/.codex/memories/MEMORY.md` | exit 0；仅取相关只读审查格式约定 |
| 4 | `cat` 两项 Rust skill 的绝对路径 `SKILL.md` | exit 0 |
| 5 | `rg --files`，筛选 AGENTS/HANDOFF/ADR/CONTRACT/SHARED_TARGET/monitor/ps1 | exit 0 |
| 6 | `cat AGENTS.md docs/HANDOFF.md docs/adr/0156-windows-read-only-monitor.md work/windows-monitor-integration-20261117/CONTRACT.md` | exit 0 |
| 7 | `python3 -B`/标准库读取内存指定行段（最初调用使用 `python3`，无本地模块导入） | exit 0；无写入 |
| 8 | `cat` Rust skill 的相关章节与 async/error-handling references | exit 0；长输出有截断 |
| 9 | `GIT_OPTIONAL_LOCKS=0 git status --porcelain=v1 --untracked-files=all` | exit 0 |
| 10 | `python3 -B` 初始快照、SHA、`git rev-parse HEAD`、`git diff --no-ext-diff --no-textconv`、status | exit 0；仅报告目录写入 |
| 11 | `nl -ba` 固定快照 platform.rs / capabilities.rs | exit 0 |
| 12 | `nl -ba` 固定快照 windows.rs | exit 0 |
| 13 | `python3 -B` 逐行输出固定生产 ps1 与 ASSEMBLY.md | exit 0；只读 |
| 14 | `rg -n` monitor.rs 符号定位 | exit 0 |
| 15 | `sed -n '1,420p'` 固定 monitor.rs | exit 0 |
| 16 | `sed -n '421,900p'` 固定 monitor.rs | exit 0 |
| 17 | `sed -n '901,1310p'` 固定 monitor.rs | exit 0 |
| 18 | `nl -ba` 固定 session/tests/windows_monitor.rs | exit 0 |
| 19 | `git --no-optional-locks diff --no-ext-diff --no-textconv 4209e272260aff6374e6216423ce8e0157bea2f4 --` monitor.rs / capabilities.rs | exit 0 |
| 20 | `nl -ba` 固定 windows/tests.rs | exit 0；输出部分截断 |
| 21 | `rg -n` app 授权/取消调用链；试读 `session/src/exec.rs`、`session/src/session.rs`；`rg --files` 定位 | 文件不存在诊断，批次 exit 1；后续改读真实 ssh.rs |
| 22 | `cat` 固定 capabilities/tests.rs | exit 0 |
| 23 | `sed` 固定 app monitor.rs / monitor_capabilities.rs 相关区间 | exit 0 |
| 24 | `rg --files` / `rg -n` 定位真实 ssh.rs、ssh/channel.rs 调用链 | exit 0 |
| 25 | `sed` 补读 windows/tests.rs 中段；`cat` verify_static.py 与已有 static-receipt.json | exit 0；只读取，没有执行验证脚本 |
| 26 | `nl -ba` / `sed` ssh.rs:700–790、channel.rs:145–240；`python3 -B` 静态统计测试声明 | exit 0；没有运行测试 |
| 27 | `python3 -B` 核对 r1 漂移、重建 5 个固定命令、保存 supporting-source-r1；`nl -ba` / `sed` 当前 monitor.rs | exit 0；仅报告目录写入 |
| 28 | `python3 -B` 固定 r2 变化文件、生成 r1/r2 文本 diff | exit 0；仅报告目录写入 |
| 29 | `python3 -B` 读取父级 review-inputs-r2.json 的键、count、aggregate 和首项 | exit 0；只读 |
| 30 | `python3 -B` 核对审查范围与 r2 冻结、保存原清单和 freeze-binding-r2.json | exit 0；39 匹配、0 mismatch、0 drift；仅报告目录写入 |
| 31 | `python3 -B` 最后读回 HEAD/r2 文件 SHA，并核对报告所列生产 SHA | exit 0；HEAD 保持指定基线、0 drift；只读 |
| 32 | `python3 -B` 固定 r3 的 44 项输入、SHA 和原件，生成 `changes-r2-r3.patch` | exit 0；仅报告目录写入；6 项变化/新增纳入最终复核 |
| 33 | `pwd`；`sed` 读取现有 report/commands 与 MEMORY.md 指定行段 | exit 0；确认审查进度和历史呈现约定 |
| 34 | `sed` r2/r3 patch；`nl -ba`/`sed` ssh.rs 与 ssh/channel.rs | exit 0；核对 guarded admission、旧公共路径和有界关闭所有权 |
| 35 | `nl -ba`/`sed` platform.rs、monitor.rs；`rg -n` 全部监控 exec/authority 调用；`git diff --no-ext-diff --no-textconv BASE --` 两项 Linux fixture 文件 | exit 0；读取六项修正覆盖和 base fixture delta |
| 36 | `nl -ba`/`sed` windows_monitor.rs、两项 Linux fixture/test 文件 | exit 0；整体输出部分截断，关键 fixture 区间下一调用单独重读 |
| 37 | `nl -ba`/`sed` fixture 前部及 forced 路径、capabilities cache；读取 r3 manifest；`rg -n` 集成证据文件；`cat RTK.md` | exit 0；仅源代码及报告目录证据读取 |
| 38 | `python3 -B` 重核 HEAD/44 个 r3 文件；AST 只计算 fixture 两项字符串常量并逐字节比较生产探针；读取 Linux binding 和既有 lab-report | exit 0；0 drift；450 字节完全相同；只写 `binding-r3-current.json`；未 import/执行工程模块 |
| 39 | `python3 -B` 输出相关 r3 SHA、manifest SHA，保留 `report-r2.md` 并读回旧发现 | exit 0；仅报告目录写入 |
| 40 | `python3 -B` 最终核对 HEAD/44 个 r3 文件，保存 `final-binding-r3.json` 和当前 Git status；核对报告 SHA 表；`sed` 读回报告 | exit 0；源码 0 drift；发现报告手工表一行 SHA 录入错误，继续窄核对 |
| 41 | `python3 -B`/`rg -n` 核对 windows/tests.rs 的 r1/r2/r3 manifest、快照及 freeze-binding-r2 | exit 0；均为 d37c75fa…，确认仅旧报告摘要录入错误，已在当前 report.md 纠正并说明 |

| 42 | `python3 -B` 最后重核 44 项源码、HEAD 与修正后的报告 15 行 SHA；更新 final-binding-r3.json | exit 0；44/44 匹配、0 drift、报告 SHA mismatch 0、HEAD 未变；仅报告目录写入 |

报告/发现文件用 `apply_patch` 写入指定报告目录；没有对上述生产文件应用 patch。
公开文档查询使用网页只读工具；桌面列表/父级身份定位只读，
向原生父级的消息发送被工具拒绝，没有成功发送。

独立测试命令总数 **0**；Cargo/build/fmt/Clippy **0**；
PowerShell/cmd/真实 SSH/真实远端操作 **0**。
父级集中专项的 7/0/1 ignored 与 101/0/0 不计入本审查执行数。
guard 修复新增 2 项/10 场景仅做源码审查；没有执行。
