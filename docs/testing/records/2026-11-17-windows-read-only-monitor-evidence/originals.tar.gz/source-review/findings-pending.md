# Windows monitor source review — pending production finding

**Update r3 / 2026-11-17: this P2 is CLOSED in source review.**
`report.md` now records APPROVE with remaining P0=0/P1=0/P2=0/P3=0.
The original finding below is retained as historical evidence; current source
hashes, guard locations and the ten delayed-open scenarios are in `report.md`
and `source-manifest-r3.json`. Independent tests executed remain **0**.

Base/HEAD: `4209e272260aff6374e6216423ce8e0157bea2f4`.
Initial source binding: `source-manifest-r1.json`. Static source review only;
Cargo/build/fmt/test/real-remote executions: **0**.

## P2 — Recheck monitor authority after SSH channel admission

- Primary location:
  `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/platform.rs:97`
  (POSIX probe), `:109` (Windows probe), and
  `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor.rs:663`
  (Windows resource collector; process/socket collectors have the same pattern).
- Supporting implementation:
  `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/ssh.rs:712`
  opens/awaits a session channel; only afterward does `:715` send `channel.exec`.
  No generation or cancellation check exists between those two operations.
- Trigger: a monitor task passes `ensure_current(generation)` and waits for a
  delayed channel-open reply. The panel is paused/retired or capabilities reset.
  The reply then arrives. The old task sends the probe/collector although its
  generation has already been revoked.
- Impact: explicit pause/reset cannot prevent an old task from starting a new
  remote command. Post-response generation checking suppresses cache/results,
  but cannot undo the command that was sent. This contradicts ADR0156's
  before-every-command authority boundary.
- Suggested fix: use a monitor-specific guarded exec path that checks the
  generation after acquiring the SSH channel and immediately before sending
  `channel.exec`, with normal bounded channel cleanup on cancellation.
  `diagnostic_exec_until` in `ssh.rs:777` already demonstrates an admission-time
  cancellation check for another subsystem.
- Regression requested: hold `channel_open_session` confirmation, invalidate or
  reset the monitor, then release the open. Assert **zero `exec_request`** and
  `MonitorError::Cancelled`, including an initial probe and a warmed-cache
  collector. The current Windows delayed-probe case holds `exec_request`
  response after the command has already been sent, so it cannot detect this.
- Evidence limit: this is a static control-flow finding. No SSH peer, Windows,
  Rust test, or native application was executed by this reviewer.

The parent-announced Windows resource negative-cache change and associated
session regression remain queued for narrow follow-up review. Old fixture
adaptations, fixture-count timing and pause-status assertion changes are not
assumed to be production defects.

Messaging limitation: the desktop `send_message_to_thread` tool rejected a
message to the native ancestor and directed use of native collaboration tools;
no native collaboration messaging tool is exposed in this reviewer session.
This report file and reviewer commentary are the available immediate handoff.
