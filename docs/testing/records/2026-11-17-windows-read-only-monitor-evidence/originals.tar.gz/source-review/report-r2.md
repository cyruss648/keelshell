# Windows 远端只读监控：独立非作者源码审查

**结论：REQUEST_CHANGES。当前未关闭发现为 P0=0、P1=0、P2=1、P3=0。**

审查日期：2026-11-17（Asia/Shanghai）。本报告审查当前未提交 diff 与新增文件，
不是基线提交本身的功能签署。独立编译 **0**，实际执行测试 **0**，真实远端操作 **0**。
Windows 资源负缓存的父级补丁已纳入窄复核；下述 SSH 通道获准后的撤销窗口仍存在。

## 源码身份与范围

- cwd：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`。
- 起始及 r2 核对 HEAD/base：`4209e272260aff6374e6216423ce8e0157bea2f4`。
- 初始静态快照：`source-manifest-r1.json`，40 个文件；逐文件原件保存在 `source-r1/`。
- 窄复核快照：`source-manifest-r2.json`。相对 r1 仅变化
  `session/src/monitor.rs`、`session/tests/windows_monitor.rs` 与
  `app/src/monitor_tests/windows.rs`；具体文本见 `changes-r1-r2.patch`。
- 父级冻结：`review-inputs-r2.json`，声明 758 个工程输入，
  aggregate `bf7b4bec90c4e1fb9969281b04ceb2ad93d935f2637303fc4ac2b33ead374f77`。
  该清单原件 SHA-256 为
  `9dfd1f9eb6eb66351573bc6c21fcf7bac92f80a64f89daaad8e8ff57ec416dd9`。
- 已独立逐字节核对冻结清单内本次审查涉及的 **39** 个文件，mismatch **0**；
  r2 审查源码相对实时工作区 drift **0**，见 `freeze-binding-r2.json`。
  **未独立重算其余工程输入或整份 aggregate**，不把 758 项清单等同于全仓源码审查。
- 读取并遵循本轮 AGENTS、RTK、HANDOFF、ADR0156、集成 CONTRACT 和
  `rust-best-practices` / `rust-engineer` skills。历史记忆只用于只读审查呈现约定，
  生产结论均来自本轮固定源码。

主要审查文件的 SHA-256（r2）：

| 文件（相对 cwd） | SHA-256 |
| --- | --- |
| `crates/keelshell-session/src/monitor.rs` | `3ecc7265a315c5efb2d545b8b9f09be8b370f0cac443fbd206830f54eea65af0` |
| `crates/keelshell-session/src/monitor/platform.rs` | `dc050e290ecba796f1cfa95ff06f271ccd2c0301fb792578ab85d46a5e0a3116` |
| `crates/keelshell-session/src/monitor/capabilities.rs` | `052827cbffde222b2b8bf894cdf78328168a9dd90800fdd5432b85dae15e8a0e` |
| `crates/keelshell-session/src/monitor/windows.rs` | `67b89e608abde6e7a3d9f207803f7eb52b46f8a7b1dc3984cb95350a252aa1a9` |
| `crates/keelshell-session/src/monitor/windows/common.ps1` | `f08ce95a93bd6a38f4955934dedc7edcb28fc9da8faa0c57a0273bd164cf15d8` |
| `crates/keelshell-session/src/monitor/windows/probe.ps1` | `52ab610daaabf4bdc74c392a4116fceeb6e3ac7f8ad43b56fc1f3667a3dcb9c2` |
| `crates/keelshell-session/src/monitor/windows/resources.ps1` | `1417e9e4724245fdea7522498303ac8848078abe8b216aa413272459b25c1e54` |
| `crates/keelshell-session/src/monitor/windows/processes.ps1` | `c3b48289177189fadc802a7d7e046863af8f14e4090d1b5c088122c821bec130` |
| `crates/keelshell-session/src/monitor/windows/sockets.ps1` | `f01e786fdfa1fede950c9c865ea604749ec6710f9aab50ee3e29a10f6405d492` |
| `crates/keelshell-session/src/monitor/windows/tests.rs` | `36c2bb6babca42633c065ad1f8a78ad4abbeca3e1ad4fcea7f52e1045a687cb7` |
| `crates/keelshell-session/tests/windows_monitor.rs` | `cb253efbe8ad810262a8e24d5f1fe0ef090f67e57d0344c714f04d91e830c659` |
| `crates/keelshell-session/src/ssh.rs`（调用链支撑） | `9e811abd68ae834570a715b1c6b093df123e1fb1620cb1f590bf4d12f2f1f440` |
| `crates/keelshell-session/src/ssh/channel.rs`（调用链支撑） | `d1f89dd1c86ba161d03c7b7fa9279c5ced59d04a77d36fc3b54714aad3fa16aa` |

## P2 — 在 SSH channel-open 获准后重新核对监控 generation

主位置：
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/platform.rs:97`
和 `:109`（两类身份探针）；
同模式出现在
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor.rs:675`
的 Windows 资源采集以及进程、端口采集调用中。

支撑位置：
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/ssh.rs:712`
先等待 `open_session(self)`；
`:715` 才发送 `channel.exec(true, command)`。
两个动作之间没有 generation / cancellation 检查。

**触发顺序：**

1. 旧监控任务通过 `ensure_current(generation)`，进入 `exec_limited()`。
2. SSH 服务端延迟该 session channel 的 open confirmation，客户端正在 await。
3. 用户暂停/退役面板，或显式 reset；generation 已被撤销。
4. 通道打开回复抵达，`exec_limited()` 继续发送旧探针/collector。
5. 响应返回之后的 generation 检查可以拒绝结果，却已经无法撤销发送的命令。

**影响：** ADR0156 所要求的“每条新 SSH 命令发送前检查 generation”没有覆盖真正
发送之前的异步等待窗口。已撤销任务仍可启动远端 PowerShell/探针；缓存不被污染
不等于命令没有发送。这是生产行为问题，独立于 fixture 计数或 test-only cfg。

**建议：** 为监控增加受 generation 保护的 exec 路径，在 SSH 通道获准之后、
`channel.exec` 之前核对 generation；撤销时按已有有界机制关闭通道并返回
`MonitorError::Cancelled`。保留结果后的检查。
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/ssh.rs:777`
的 `diagnostic_exec_until` 已有通道获准后的取消检查，可参考其时点，
不必把监控状态传播到不相关公共调用。

**所需专项：** 在受控 SSH fixture 中阻塞 `channel_open_session` 的 confirmation，
分别覆盖首次身份探针与已确认 Windows 路由下的采集；暂停或 reset 后放行，
断言远端 `exec_request` 数量为 **0**、返回 `Cancelled` 且缓存没有新观察。
现有 `windows_pending_identity_cannot_start_a_collector_after_reset`
在收到 `exec_request` 后阻塞其响应，能够验证后续 collector 和缓存，
不能覆盖本发现的通道打开窗口。

**证据强度：** 源码控制流推导；本审查未运行受控 SSH、Rust、PowerShell 或真实远端。
没有把该触发序列描述为已执行的动态复现。

## 父级 r2 delta 窄复核

`monitor.rs:637` 新分支先经 `cached_reason` 排除 Transport，再确认已缓存路由是
`WindowsPowerShell`；仅该路由对其余非 Transport 负观察早退。
Linux/POSIX 的资源权限、格式及普通失败继续走原重试路径；
原 UnsupportedPlatform/CommandMissing 的早退保持。早退不调用 record，
所以失败观察时间和报告 revision 不被伪更新。

新增 `windows_resource_permission_cache_preserves_age_until_explicit_recheck`
覆盖失败后的 clone 重读、命令数、观察及报告不变、独立进程采集、reset 后再探针和恢复。
本轮对该补丁及专例的静态 delta **未另发现 P0–P3 问题**。
app unconfirmed 状态文案的断言移到 pause 前属于测试时点适配。

父级提供的结果为 Windows routing 专项 **7 passed / 0 failed / 1 ignored**，
app 专项 r2 **101 / 0 / 0**。这是父级提供的测试结果，**本审查执行数仍为 0**，
不把这些结果转记为独立执行或完整门禁。

## 其余重点的静态核对结果

- **固定命令及长度：** 仅使用 operation 固定字面量、common/body/suffix，
  UTF-16LE 后标准 Base64，无用户内容插值。独立从实际脚本原件重建五种命令，
  ASCII 字节长度为 probe **3778**、resources **7954**、
  resources/skip **7954**、processes **4394**、sockets **4762**，
  均严格小于 8000；命令 SHA 见 `command-assembly-r1.json`。
  该核对没有执行任何命令字符串。
- **严格帧：** 直接类型化反序列化 envelope 与嵌套记录，保留重复键拒绝能力；
  nullable data/CPU/working-set 字段显式必需。检查 operation、单位、Windows/runtime、
  四段 5.1 版本、exit、空 stderr、总输出、规范十进制宽整数、计数、重复身份、
  地址与显示字符串边界。成功空数组与 typed failure/null data 分开。
- **数据来源：** CPU gauge/Unavailable 与 Unix 累计 ticks 分开，内存 free 不冒充
  available/used，Windows load、swap、iowait、disk I/O、网络速率继续未知。
  容量 typed failure 清空容量行并保留 core；used 采用 total-total-free，
  quota-aware available 单独保存。进程只提供 PID/name/可选 working set。
- **Windows API 语义：** 对照 Microsoft 一手文档核对 API 选型及单位含义；
  这不能验证 PowerShell 5.1 的实际脚本行为、权限组合、CIM 实值或空查询行为。
  TCP 与 UDP 两个调用必须都成功才能输出 sockets 成功帧，未把其中一项失败合并成空成功。
- **缓存与迟到：** clone 共享连接级缓存，reset 同时清路由与设施；
  pause 的 invalidate 保留已完成身份；新 monitor 获得新缓存。
  report 绑定缓存对象、generation、revision，旧探针响应不能继续进入 collector
  或写回 reset 缓存。真正的 SSH admission/send 边界另见上述 P2。
- **Linux 动作权威：** probe/inspect 在发动作命令前要求独立确认 Linux；
  Windows PID 0 仅显示。ProcessIdentity 不能通过 Windows 进程列表直接构造，
  终止仍保留连接身份、PID/start-tick 和显式确认合同。
  没有把本次只读 Windows 支持扩展成 Windows 操作授权。
- **平台一致性与阻塞：** 资源平台必须匹配身份，Unix sockets 必须匹配原始平台帧；
  Windows 解析器强制 Windows/WindowsPowerShell。探针 gate 有界，
  每条 SSH 传输沿用有界 deadline/输出。app 在拥有的 transport worker 上 block_on，
  未见本次新增的 UI 线程阻塞 I/O。绘制不执行采集。

上述项目除 P2 外没有新增可定性的 P0–P3 发现；不是对所有平台、所有运行路径的动态通过声明。
近期已集中修复的旧 fixture、remote-only test-only cfg、新 socket 身份匹配不默认列为生产缺陷。

## 实际命令、测试数与读写边界

本轮实际使用 `pwd`、`rg`/`rg --files`、`cat`、`nl -ba`、`sed`、
`git rev-parse`、`git status --porcelain=v1 --untracked-files=all`、
`git diff --no-ext-diff --no-textconv`，以及 `python3 -B` 标准库脚本读取文件、
计算 SHA/长度、固定快照、生成文本 diff 和核对指定冻结成员。
Git 调用关闭 optional locks。命令与结果分组详见 `commands.md`。

| 验证/操作 | 本审查实际执行 |
| --- | ---: |
| Cargo / build / fmt / Clippy | 0 |
| Rust 单元、集成、预编译测试 | 0 |
| Python 测试、仓库 gate、verify_static | 0 |
| PowerShell / cmd / 真实 SSH / 真实远端 | 0 |
| GUI / 原生桌面操作 | 0 |
| commit / push / clean | 0 |
| 独立命令装配字节分析 | 5 个固定变体，均 <8000 |
| 本次涉及文件对父级冻结绑定 | 39 匹配 / 0 mismatch |

一次路径定位 rg 批次尝试了并不存在的 `src/exec.rs`、`src/session.rs`，
输出明确的文件不存在错误并 exit 1；随后已从 `src/ssh.rs` 和
`src/ssh/channel.rs` 找到并读取真实调用链。其余静态命令没有报告执行失败。
原始大文本输出有工具截断；关键生产函数均另按文件或分段读取，不以截断摘要定性发现。

审查方的文件写入限定在
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-monitor-review-source-20261117/`。
未写源文件、项目文档或 target；未运行仓库脚本以规避间接写入；未触碰父级集中编译。
父级同时修改文件和运行专项，不能把全工作区在审查期间的变化误归为审查方写入。

## 官方事实来源及未验边界

以下为本轮实际读取的一手资料，限于文档事实，不是平台执行回执：

1. Microsoft Learn, about_PowerShell_exe（5.1）：EncodedCommand 的 UTF-16LE 编码及调用参数。
   `https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_powershell_exe?view=powershell-5.1`
2. Microsoft Learn, Cmd.exe command-line string limitation：8191 字符限制。
   `https://learn.microsoft.com/en-us/troubleshoot/windows-client/shell-experience/command-line-string-limitation`
3. Microsoft Learn, Win32_Processor / Win32_OperatingSystem：CPU、内存和日期属性。
   `https://learn.microsoft.com/en-us/windows/win32/cimwin32prov/win32-processor`
   `https://learn.microsoft.com/en-us/windows/win32/cimwin32prov/win32-operatingsystem`
4. Microsoft Learn, NetworkInterface.GetIPStatistics：方法及 .NET Framework 4.5–4.8.1 适用性。
   `https://learn.microsoft.com/en-us/dotnet/api/system.net.networkinformation.networkinterface.getipstatistics?view=net-10.0`
5. Microsoft Learn, DriveInfo.AvailableFreeSpace / Process.WorkingSet64：quota-aware 空间与物理 working-set 字节。
   `https://learn.microsoft.com/en-us/dotnet/api/system.io.driveinfo.availablefreespace?view=netframework-4.8.1`
   `https://learn.microsoft.com/en-us/dotnet/api/system.diagnostics.process.workingset64?view=netframework-4.8.1`
6. Microsoft Learn, Get-NetTCPConnection / Get-NetUDPEndpoint：Listen 过滤、UDP 绑定和 OwningProcess 元数据。
   `https://learn.microsoft.com/en-us/powershell/module/nettcpip/get-nettcpconnection?view=windowsserver2025-ps`
   `https://learn.microsoft.com/en-us/powershell/module/nettcpip/get-netudpendpoint?view=windowsserver2025-ps`

部分文档路径初次查询不可达，后续只使用成功读取的官方页面；没有据此推断 API 缺失。
本轮 **未验证** 默认 Windows shell 对 7954 字节命令的实际接收、真实 PowerShell 5.1
语法与 API 返回、空 TCP/UDP 查询、权限和本地化差异、真实 Windows OpenSSH 认证链、
远端 PowerShell 终态或清理、Windows/Linux/macOS 原生桌面、发行与完整产品验收。
关闭 SSH 通道不证明远端 PowerShell 已终止；缺少终态继续为 UNKNOWN/HOLD。

## 交回父级

首次发现已同步到 `findings-pending.md` 及审查 commentary。
桌面 `send_message_to_thread` 明确拒绝向本审查的 native ancestor 发消息，
并要求使用原生协作消息工具；本会话未暴露该工具，因此没有声称消息已发送成功。

**当前 r2 冻结不建议批准/进入作为最终交付的完整门禁；先关闭上述 P2。**
报告已可供父级审阅。等待父级提供最终修复/变动后，仅对相应 delta、源文件 SHA
和专项证据边界做窄复核；不重跑全仓测试、不自行关闭或清理父级资源。
