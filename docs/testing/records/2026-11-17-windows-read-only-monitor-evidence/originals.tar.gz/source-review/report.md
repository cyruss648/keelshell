# Windows 远端只读监控：独立非作者源码审查

**结论：APPROVE（限定为下述 r3 固定源码的独立只读审查）。剩余发现为 P0=0、P1=0、P2=0、P3=0。**

审查日期：2026-11-17（Asia/Shanghai）。本报告审查当前未提交 diff 与新增文件，
不是基线提交本身的功能签署。独立编译 **0**，实际执行测试 **0**，真实远端操作 **0**。
Windows 资源负缓存、SSH 通道获准后的发送前 guard、两项 delayed-channel-open 专例及
Linux ForceCommand identity fixture 修正均已纳入窄复核。原 P2 已在源码层面关闭；
修复专项及完整门禁仍由父级执行，不把源码批准表述为 Windows 运行验收。

## 源码身份与范围

- cwd：`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell`。
- 起始、r2、r3 核对 HEAD/base：`4209e272260aff6374e6216423ce8e0157bea2f4`。
- 初始静态快照：`source-manifest-r1.json`，40 个文件；逐文件原件保存在 `source-r1/`。
- 窄复核快照：`source-manifest-r2.json`。相对 r1 仅变化
  `session/src/monitor.rs`、`session/tests/windows_monitor.rs` 与
  `app/src/monitor_tests/windows.rs`；具体文本见 `changes-r1-r2.patch`。
- 父级冻结：`review-inputs-r2.json`，声明 758 个工程输入，
  aggregate `bf7b4bec90c4e1fb9969281b04ceb2ad93d935f2637303fc4ac2b33ead374f77`。
  该清单原件 SHA-256 为
  `9dfd1f9eb6eb66351573bc6c21fcf7bac92f80a64f89daaad8e8ff57ec416dd9`。
- 已独立逐字节核对冻结清单内本次审查涉及的 **39** 个文件，mismatch **0**；
  r2 审查源码相对实时工作区 drift **0**，见 `freeze-binding-r2.json`。
  **未独立重算其余工程输入或整份 aggregate**，不把 758 项清单等同于全仓源码审查。
- r3 快照：`source-manifest-r3.json`，**44** 个输入及逐文件 `source-r3/` 原件。
  采集时间为 `2026-11-16T22:03:24.381244+00:00`；相对已审 r2 的源码变化见
  `changes-r2-r3.patch`。r3 新增纳入的两项 Linux fixture 文件另从 base diff 读取。
- r3 相对前次审查变化/新增范围为 `session/src/monitor.rs`、
  `session/src/monitor/platform.rs`、`session/src/ssh.rs`、
  `session/tests/windows_monitor.rs`、`scripts/monitor_recovery/fixture.py` 和
  `scripts/test_monitor_recovery_lab.py`。其余已审文件（包括 Windows Rust 解析器、
  capabilities、生产 ps1 和 app r2 测试）未变化。
- `binding-r3-current.json` 在 `2026-11-16T22:06:03.174915+00:00`
  再核对 **44** 个 r3 文件，drift **0**。r3 含 r2 冻结后的有意修复，
  **不声称 r3 仍等于父级旧 r2 aggregate**。历史 REQUEST_CHANGES 原件保存在
  `report-r2.md`，不覆盖其原发现证据。
- `final-binding-r3.json` 在最终交回前再次读回 HEAD 和全部 **44** 个输入，
  核对结果见该文件；源码清单 SHA-256 为
  `f588c3c863d70fa7920fd4d2af659258b1b6c8691b945d8e5899b7a5544939ff`。
  最后读回时纠正了旧报告手工 SHA 表中 `windows/tests.rs` 的录入错误；
  r1/r2/r3 原始 manifest、快照和冻结核对记录一致为下表 `d37c75fa…`，
  这是报告摘要纠错，源码没有因此发生变化。
- 读取并遵循本轮 AGENTS、RTK、HANDOFF、ADR0156、集成 CONTRACT 和
  `rust-best-practices` / `rust-engineer` skills。历史记忆只用于只读审查呈现约定，
  生产结论均来自本轮固定源码。

主要审查文件的 SHA-256（r3）：

| 文件（相对 cwd） | SHA-256 |
| --- | --- |
| `crates/keelshell-session/src/monitor.rs` | `931ac018e003317f07f7de2266e5d467c036609d83c907918e8f5b51a8ef1279` |
| `crates/keelshell-session/src/monitor/platform.rs` | `6c14b3dec6cd1dd71f46672ee92f38fe3f9137f40fc20833516231ad42b30cef` |
| `crates/keelshell-session/src/monitor/capabilities.rs` | `052827cbffde222b2b8bf894cdf78328168a9dd90800fdd5432b85dae15e8a0e` |
| `crates/keelshell-session/src/monitor/windows.rs` | `67b89e608abde6e7a3d9f207803f7eb52b46f8a7b1dc3984cb95350a252aa1a9` |
| `crates/keelshell-session/src/monitor/windows/common.ps1` | `f08ce95a93bd6a38f4955934dedc7edcb28fc9da8faa0c57a0273bd164cf15d8` |
| `crates/keelshell-session/src/monitor/windows/probe.ps1` | `52ab610daaabf4bdc74c392a4116fceeb6e3ac7f8ad43b56fc1f3667a3dcb9c2` |
| `crates/keelshell-session/src/monitor/windows/resources.ps1` | `1417e9e4724245fdea7522498303ac8848078abe8b216aa413272459b25c1e54` |
| `crates/keelshell-session/src/monitor/windows/processes.ps1` | `c3b48289177189fadc802a7d7e046863af8f14e4090d1b5c088122c821bec130` |
| `crates/keelshell-session/src/monitor/windows/sockets.ps1` | `f01e786fdfa1fede950c9c865ea604749ec6710f9aab50ee3e29a10f6405d492` |
| `crates/keelshell-session/src/monitor/windows/tests.rs` | `d37c75fa413909999b9c649c45d4156724a18c3620e7f90909323530f8a3b153` |
| `crates/keelshell-session/tests/windows_monitor.rs` | `324dac7f94c3490290e2feec6e1e31ff0099049f6ce67b50ba8a341390d6e1f6` |
| `crates/keelshell-session/src/ssh.rs`（调用链支撑） | `4d63d7ad0ec131cf9321d4d83a55736393ce778c956fb0f2cabdee900734776a` |
| `crates/keelshell-session/src/ssh/channel.rs`（调用链支撑） | `d1f89dd1c86ba161d03c7b7fa9279c5ced59d04a77d36fc3b54714aad3fa16aa` |
| `scripts/monitor_recovery/fixture.py` | `5b414f93b24105dcb5fe126e461334ca1aeb53ab90a65e078eb43c798f8a1bff` |
| `scripts/test_monitor_recovery_lab.py` | `091d4c990118a02d82a825b47ae4075a61f6f860e24b7075201c72ba23d4d54d` |

## 原 P2 已关闭 — SSH channel-open 获准后重新核对 generation

原触发及影响：旧任务在通过 generation 检查后等待 SSH open confirmation，
暂停/reset 已撤销 generation，迟到 confirmation 仍能启动新远端命令。
原始定位、完整触发与修复建议见 `report-r2.md`。以下行号均为 r3 当前源码。

- `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/ssh.rs:722`
  引入 crate-private `exec_limited_guarded`，`:731` await 通道获准，`:732`
  执行 `FnOnce` guard，false 在 `:733` 主动有界 close 并返回 `None`，
  只有 true 才到 `:738` 的 `channel.exec`。原公共 `exec_limited` 在 `:711`
  使用恒 true 路径，签名、输出上限和原接收/状态处理未改变。
- `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/ssh/channel.rs:34`
  的 `PendingChannel::close` 维持 owner 直到 await 完成；`:161` 沿用
  2 秒 close budget 和失败时的连接关闭/中止。guard false 不丢弃裸通道。
  该 cleanup 仍仅说明协议端所有权，不宣称远端进程终止。
- `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor/platform.rs:77`
  的 `exec_current` 在入口、guard 和成功返回后检查 generation。
  两个 identity probe（`:114`、`:125`）及 monitor 的 Windows/POSIX
  resources（`:675`、`:684`）、processes（`:743`、`:753`）、
  sockets（`:791`、`:801`）、TCP connect（`:841`）、inspect（`:861`）
  全部走该 helper。对 monitor 生产目录搜索未见遗漏的直接 `exec_limited` 读调用。
- `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/src/monitor.rs:897`
  的 terminate 保留合法 PID、同一认证连接及初始 60 秒时效核对；
  `:905` 取得 generation 并独立确认 Linux，`:915` 的 guard 再查 generation
  与 60 秒时效。只有 guard 未发送返回 None 才在 `:920` 判定
  Cancelled/ReviewExpired；已发送返回 Some 后不再以 generation 丢弃实际结果，
  原 ProcessChanged/checked receipt 处理保持。

**新回归的静态证据：**

- `/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/crates/keelshell-session/tests/windows_monitor.rs:172`
  在 `reply.accept()` 前阻塞 channel-open，单次等待 3 秒有界。
- 同文件 `:490` 的 identity 专例为 POSIX/PowerShell × pause/reset **4 场景**：
  放行后断言 Cancelled、被撤销 probe 的 exec 为 0、collector 为 0、无身份或资源新观察。
  PowerShell 场景允许先前已完成的 1 次 POSIX probe，不把总命令数误写为 0。
- 同文件 `:528` 的缓存 collector 专例为 resources/processes/sockets × pause/reset
  **6 场景**：预热缓存后阻塞下一通道，放行后命令数不增加、旧 report 已撤销；
  reset 得默认缓存，pause 保留原缓存。两个测试整体分别有 20/25 秒 timeout。

**本轮判断：** 修复命中了原 P2 的异步等待窗口，并补充对应测试源码，关闭原发现。
本轮没有新增可定性的 P0–P3 问题。上述是源码和测试设计审查；
审查方未运行这两项测试，也未独立验证 SIGTERM 已发送/未发送分支的动态执行。

## 父级 r2 delta 窄复核

`monitor.rs:637` 新分支先经 `cached_reason` 排除 Transport，再确认已缓存路由是
`WindowsPowerShell`；仅该路由对其余非 Transport 负观察早退。
Linux/POSIX 的资源权限、格式及普通失败继续走原重试路径；
原 UnsupportedPlatform/CommandMissing 的早退保持。早退不调用 record，
所以失败观察时间和报告 revision 不被伪更新。

新增 `windows_resource_permission_cache_preserves_age_until_explicit_recheck`
覆盖失败后的 clone 重读、命令数、观察及报告不变、独立进程采集、reset 后再探针和恢复。
本轮对该补丁及专例的静态 delta **未另发现 P0–P3 问题**。
app unconfirmed 状态文案的断言移到 pause 前属于测试时点适配。

父级提供的结果为 Windows routing 专项 **7 passed / 0 failed / 1 ignored**，
app 专项 r2 **101 / 0 / 0**。这是父级提供的测试结果，**本审查执行数仍为 0**，
不把这些结果转记为独立执行或完整门禁。

## Linux identity fixture 修正的窄复核

`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/monitor_recovery/fixture.py:74`
的 `PLATFORM_PROBE` 由固定字符串与已有 selector 拼接。
通过 Python AST 只计算这两个字符串常量，独立核对其与生产 `POSIX_PROBE`
**完全相同，450 个 UTF-8 字节**，SHA-256：
`c21c2b796f96a47b4fb9b4c3c2fd690ce06480bc25393504100d27bae46d7232`。
没有 import/执行 fixture，也没有执行其测试。原样比较结果在 `binding-r3-current.json`。

同文件 `:116` 仅增加精确 allowlist 键，`:121` 的解析仍先要求完整字典键匹配；
identity 不能进入资源 selector 包装分支。追加命令或修改 probe 字节均不在 allowlist。
`:213`/`:215` 将 identity 请求记在独立 `requests.identity`，
probe=None 不增加 df/ps/ss 探测计数；`:283` 初始化独立计数。
实际执行仍为已许可的固定字符串经 `/bin/sh`，没有扩大为任意调用者 shell 文本。

`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/scripts/test_monitor_recovery_lab.py:268`
新增精确字节匹配、完整 admission、追加 `id` 和修改平台分支的拒绝例；
`:314` 更新 allowlist 集合预期。对此 delta 未发现 P0–P3。
父级说明的 Linux lab r1 failure/清理保留为父级证据，不据 fixture 修复静态成立
推定真实 Linux 重跑成功。只读取了 `linux-recovery-binding-r2.json`，
没有访问或运行其中所指预编译二进制。

## 其余重点的静态核对结果

- **固定命令及长度：** 仅使用 operation 固定字面量、common/body/suffix，
  UTF-16LE 后标准 Base64，无用户内容插值。独立从实际脚本原件重建五种命令，
  ASCII 字节长度为 probe **3778**、resources **7954**、
  resources/skip **7954**、processes **4394**、sockets **4762**，
  均严格小于 8000；命令 SHA 见 `command-assembly-r1.json`。
  该核对没有执行任何命令字符串。
- **严格帧：** 直接类型化反序列化 envelope 与嵌套记录，保留重复键拒绝能力；
  nullable data/CPU/working-set 字段显式必需。检查 operation、单位、Windows/runtime、
  四段 5.1 版本、exit、空 stderr、总输出、规范十进制宽整数、计数、重复身份、
  地址与显示字符串边界。成功空数组与 typed failure/null data 分开。
- **数据来源：** CPU gauge/Unavailable 与 Unix 累计 ticks 分开，内存 free 不冒充
  available/used，Windows load、swap、iowait、disk I/O、网络速率继续未知。
  容量 typed failure 清空容量行并保留 core；used 采用 total-total-free，
  quota-aware available 单独保存。进程只提供 PID/name/可选 working set。
- **Windows API 语义：** 对照 Microsoft 一手文档核对 API 选型及单位含义；
  这不能验证 PowerShell 5.1 的实际脚本行为、权限组合、CIM 实值或空查询行为。
  TCP 与 UDP 两个调用必须都成功才能输出 sockets 成功帧，未把其中一项失败合并成空成功。
- **缓存与迟到：** clone 共享连接级缓存，reset 同时清路由与设施；
  pause 的 invalidate 保留已完成身份；新 monitor 获得新缓存。
  report 绑定缓存对象、generation、revision，旧探针响应不能继续进入 collector
  或写回 reset 缓存。SSH admission/send 边界已按上述 r3 guard 关闭原 P2。
- **Linux 动作权威：** probe/inspect 在发动作命令前要求独立确认 Linux；
  Windows PID 0 仅显示。ProcessIdentity 不能通过 Windows 进程列表直接构造，
  终止仍保留连接身份、PID/start-tick 和显式确认合同。
  没有把本次只读 Windows 支持扩展成 Windows 操作授权。
- **平台一致性与阻塞：** 资源平台必须匹配身份，Unix sockets 必须匹配原始平台帧；
  Windows 解析器强制 Windows/WindowsPowerShell。探针 gate 有界，
  每条 SSH 传输沿用有界 deadline/输出。app 在拥有的 transport worker 上 block_on，
  未见本次新增的 UI 线程阻塞 I/O。绘制不执行采集。

上述项目及最终 delta 均没有剩余可定性的 P0–P3 发现；不是对所有平台、所有运行路径的动态通过声明。
近期已集中修复的旧 fixture、remote-only test-only cfg、新 socket 身份匹配不默认列为生产缺陷。

## 实际命令、测试数与读写边界

本轮实际使用 `pwd`、`rg`/`rg --files`、`cat`、`nl -ba`、`sed`、
`git rev-parse`、`git status --porcelain=v1 --untracked-files=all`、
`git diff --no-ext-diff --no-textconv`，以及 `python3 -B` 标准库脚本读取文件、
计算 SHA/长度、固定快照、生成文本 diff 和核对指定冻结成员。
Git 调用关闭 optional locks。命令与结果分组详见 `commands.md`。

| 验证/操作 | 本审查实际执行 |
| --- | ---: |
| Cargo / build / fmt / Clippy | 0 |
| Rust 单元、集成、预编译测试 | 0 |
| Python 测试、仓库 gate、verify_static | 0 |
| PowerShell / cmd / 真实 SSH / 真实远端 | 0 |
| GUI / 原生桌面操作 | 0 |
| commit / push / clean | 0 |
| 独立命令装配字节分析 | 5 个固定变体，均 <8000 |
| 本次涉及文件对父级冻结绑定 | 39 匹配 / 0 mismatch |
| r3 固定文件对当前源码核对 | 44 匹配 / 0 drift |
| 新 delayed-open 测试源码审查 | 2 项 / 10 场景；实际运行 0 |
| Linux identity 探针字节核对 | 450 字节，完全相同；实际远端运行 0 |

一次路径定位 rg 批次尝试了并不存在的 `src/exec.rs`、`src/session.rs`，
输出明确的文件不存在错误并 exit 1；随后已从 `src/ssh.rs` 和
`src/ssh/channel.rs` 找到并读取真实调用链。其余静态命令没有报告执行失败。
原始大文本输出有工具截断；关键生产函数均另按文件或分段读取，不以截断摘要定性发现。

审查方的文件写入限定在
`/Users/hdh/.codex/worktrees/editor-unicode-codec-20261114/keelshell/work/windows-monitor-review-source-20261117/`。
未写源文件、项目文档或 target；未运行仓库脚本以规避间接写入；未触碰父级集中编译。
父级同时修改文件和运行专项，不能把全工作区在审查期间的变化误归为审查方写入。

## 官方事实来源及未验边界

以下为本轮实际读取的一手资料，限于文档事实，不是平台执行回执：

1. Microsoft Learn, about_PowerShell_exe（5.1）：EncodedCommand 的 UTF-16LE 编码及调用参数。
   `https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_powershell_exe?view=powershell-5.1`
2. Microsoft Learn, Cmd.exe command-line string limitation：8191 字符限制。
   `https://learn.microsoft.com/en-us/troubleshoot/windows-client/shell-experience/command-line-string-limitation`
3. Microsoft Learn, Win32_Processor / Win32_OperatingSystem：CPU、内存和日期属性。
   `https://learn.microsoft.com/en-us/windows/win32/cimwin32prov/win32-processor`
   `https://learn.microsoft.com/en-us/windows/win32/cimwin32prov/win32-operatingsystem`
4. Microsoft Learn, NetworkInterface.GetIPStatistics：方法及 .NET Framework 4.5–4.8.1 适用性。
   `https://learn.microsoft.com/en-us/dotnet/api/system.net.networkinformation.networkinterface.getipstatistics?view=net-10.0`
5. Microsoft Learn, DriveInfo.AvailableFreeSpace / Process.WorkingSet64：quota-aware 空间与物理 working-set 字节。
   `https://learn.microsoft.com/en-us/dotnet/api/system.io.driveinfo.availablefreespace?view=netframework-4.8.1`
   `https://learn.microsoft.com/en-us/dotnet/api/system.diagnostics.process.workingset64?view=netframework-4.8.1`
6. Microsoft Learn, Get-NetTCPConnection / Get-NetUDPEndpoint：Listen 过滤、UDP 绑定和 OwningProcess 元数据。
   `https://learn.microsoft.com/en-us/powershell/module/nettcpip/get-nettcpconnection?view=windowsserver2025-ps`
   `https://learn.microsoft.com/en-us/powershell/module/nettcpip/get-netudpendpoint?view=windowsserver2025-ps`

部分文档路径初次查询不可达，后续只使用成功读取的官方页面；没有据此推断 API 缺失。
本轮 **未验证** 默认 Windows shell 对 7954 字节命令的实际接收、真实 PowerShell 5.1
语法与 API 返回、空 TCP/UDP 查询、权限和本地化差异、真实 Windows OpenSSH 认证链、
远端 PowerShell 终态或清理、Windows/Linux/macOS 原生桌面、发行与完整产品验收。
关闭 SSH 通道不证明远端 PowerShell 已终止；缺少终态继续为 UNKNOWN/HOLD。

## 交回父级

首次发现已同步到 `findings-pending.md` 及审查 commentary。
桌面 `send_message_to_thread` 明确拒绝向本审查的 native ancestor 发消息，
并要求使用原生协作消息工具；本会话未暴露该工具，因此没有声称消息已发送成功。

**当前 r3 固定源码可批准（APPROVE）；剩余 P0/P1/P2/P3 均为 0。**
父级可继续其已负责的专项、完整门禁及真实 Darwin/Linux 联调。r3 修复专项尚未向
本审查提供新结果，不将先前的 r2 成功结果当作 r3 编译、测试或运行证据。
若后续 fmt 或门禁修正改变上述输入，只对新 delta 和源文件 SHA 再复核。
父级负责最终关闭；审查方不关闭、清理父级资源，也不运行额外测试。
